#include "csiso_8859_7.h"

zend_class_entry *TPlISO_8859_7_ce_ptr = NULL;

SB_PHP_METHOD(TPlISO_8859_7, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlISO_8859_7_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1802254570, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_8859_7, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlISO_8859_7_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2008522250, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_8859_7, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_8859_7_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_8859_7, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_8859_7_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_8859_7, CreateForFinalize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_8859_7_CreateForFinalize(&hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlTableCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_8859_7_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_8859_7_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_8859_7_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_8859_7___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_8859_7_CreateForFinalize, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlISO_8859_7_methods[] = {
	PHP_ME(TPlISO_8859_7, GetCategory, arginfo_TPlISO_8859_7_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_8859_7, GetDescription, arginfo_TPlISO_8859_7_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_8859_7, ClassType, arginfo_TPlISO_8859_7_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlISO_8859_7, __construct, arginfo_TPlISO_8859_7___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_8859_7, CreateForFinalize, arginfo_TPlISO_8859_7_CreateForFinalize, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TPlISO_8859_7(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlISO_8859_7_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlISO_8859_7", TPlISO_8859_7_methods);
	if (NULL == TPlASCII_ce_ptr)
		Register_TPlASCII(TSRMLS_C);
	TPlISO_8859_7_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlASCII_ce_ptr);
}

