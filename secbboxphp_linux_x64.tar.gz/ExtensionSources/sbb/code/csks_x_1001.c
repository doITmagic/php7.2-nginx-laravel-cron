#include "csks_x_1001.h"

zend_class_entry *TPlKS_X_1001_ce_ptr = NULL;

SB_PHP_METHOD(TPlKS_X_1001, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlKS_X_1001_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlKS_X_1001, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlKS_X_1001_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlKS_X_1001, CreateForFinalize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlKS_X_1001_CreateForFinalize(&hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlTableCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlKS_X_1001_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlKS_X_1001___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlKS_X_1001_CreateForFinalize, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlKS_X_1001_methods[] = {
	PHP_ME(TPlKS_X_1001, ClassType, arginfo_TPlKS_X_1001_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlKS_X_1001, __construct, arginfo_TPlKS_X_1001___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TPlKS_X_1001, CreateForFinalize, arginfo_TPlKS_X_1001_CreateForFinalize, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TPlKS_X_1001(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlKS_X_1001_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlKS_X_1001", TPlKS_X_1001_methods);
	if (NULL == TPlTableCharset_ce_ptr)
		Register_TPlTableCharset(TSRMLS_C);
	TPlKS_X_1001_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlTableCharset_ce_ptr);
}

