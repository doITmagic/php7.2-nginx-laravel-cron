#include "csuhc.h"

zend_class_entry *TPlUHC_ce_ptr = NULL;

SB_PHP_METHOD(TPlUHC, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlUHC_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlUHC, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlUHC_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlUHC, CreateForFinalize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlUHC_CreateForFinalize(&hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlTableCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlUHC_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlUHC___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlUHC_CreateForFinalize, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlUHC_methods[] = {
	PHP_ME(TPlUHC, ClassType, arginfo_TPlUHC_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlUHC, __construct, arginfo_TPlUHC___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TPlUHC, CreateForFinalize, arginfo_TPlUHC_CreateForFinalize, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TPlUHC(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlUHC_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlUHC", TPlUHC_methods);
	if (NULL == TPlTableCharset_ce_ptr)
		Register_TPlTableCharset(TSRMLS_C);
	TPlUHC_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlTableCharset_ce_ptr);
}

