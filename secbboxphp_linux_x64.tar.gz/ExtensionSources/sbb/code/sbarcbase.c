#include "sbarcbase.h"

zend_class_entry *TSBArcReplaceMode_ce_ptr = NULL;

void SB_CALLBACK TSBArcReadEventRaw(void * _ObjectData, TObjectHandle Sender, uint8_t pBuffer[], int32_t * szBuffer, int32_t Index, int32_t * Written, int8_t * Last)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zBuffer;
	SBArrayZValInfo aiBuffer;
	zval * zIndex;
	zval * zWritten;
	zval * zLast;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zBuffer, 1);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zBuffer), pBuffer, *szBuffer);
	SB_EVENT_INIT_ZVAL(zIndex, 2);
	ZVAL_LONG(zIndex, (sb_zend_long)Index);
	SB_EVENT_INIT_ZVAL_REF(zWritten, 3);
	ZVAL_LONG(Z_REFVAL_P(zWritten), (sb_zend_long)*Written);
	SB_EVENT_INIT_ZVAL_REF(zLast, 4);
	ZVAL_BOOL(Z_REFVAL_P(zLast), (zend_bool)*Last);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	if (SBGetByteArrayFromZVal(zBuffer, &aiBuffer TSRMLS_CC))
		SBCheckError(SBSetEventReturnBuffer(2, aiBuffer.data, aiBuffer.len) TSRMLS_CC);
	SBFreeArrayZValInfo(&aiBuffer);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zIndex);
	convert_to_long(Z_REFVAL_P(zWritten));
	*Written = (int32_t)Z_LVAL_P(Z_REFVAL_P(zWritten));
	SB_EVENT_CLEAR_ZVAL(zWritten);
	convert_to_boolean(Z_REFVAL_P(zLast));
	*Last = (int8_t)SB_BVAL_P(Z_REFVAL_P(zLast));
	SB_EVENT_CLEAR_ZVAL(zLast);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBArcWriteEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t Size)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zBuffer;
	zval * zIndex;
	zval * zSize;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 1);
	SB_ZVAL_STRINGL_DUP(zBuffer, pBuffer, szBuffer);
	SB_EVENT_INIT_ZVAL(zIndex, 2);
	ZVAL_LONG(zIndex, (sb_zend_long)Index);
	SB_EVENT_INIT_ZVAL(zSize, 3);
	ZVAL_LONG(zSize, (sb_zend_long)Size);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zIndex);
	SB_EVENT_CLEAR_ZVAL(zSize);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElBaseArchive_ce_ptr = NULL;

SB_PHP_METHOD(TElBaseArchive, Open)
{
	char *sFileName;
	sb_str_size sFileName_len;
	zend_bool bReadOnly;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sb", &sFileName, &sFileName_len, &bReadOnly) == SUCCESS)
	{
		SBCheckError(TElBaseArchive_Open(SBGetObjectHandle(getThis() TSRMLS_CC), sFileName, (int32_t)sFileName_len, (int8_t)bReadOnly) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElBaseArchive_Open_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, bool) or (\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBaseArchive, Close)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElBaseArchive_Close(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBaseArchive, get_Opened)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElBaseArchive_get_Opened(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBaseArchive, get_IsReadOnly)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElBaseArchive_get_IsReadOnly(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBaseArchive, get_OnProgress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBProgressEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElBaseArchive_get_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBaseArchive, set_OnProgress)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElBaseArchive_set_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBProgressEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBProgressEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBaseArchive, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElBaseArchive_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBaseArchive_Open, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, FileName_or_Stream, 0, 1)
	ZEND_ARG_INFO(0, ReadOnly)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBaseArchive_Close, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBaseArchive_get_Opened, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBaseArchive_get_IsReadOnly, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBaseArchive_get_OnProgress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBaseArchive_set_OnProgress, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBaseArchive___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElBaseArchive_methods[] = {
	PHP_ME(TElBaseArchive, Open, arginfo_TElBaseArchive_Open, ZEND_ACC_PUBLIC)
	PHP_ME(TElBaseArchive, Close, arginfo_TElBaseArchive_Close, ZEND_ACC_PUBLIC)
	PHP_ME(TElBaseArchive, get_Opened, arginfo_TElBaseArchive_get_Opened, ZEND_ACC_PUBLIC)
	PHP_ME(TElBaseArchive, get_IsReadOnly, arginfo_TElBaseArchive_get_IsReadOnly, ZEND_ACC_PUBLIC)
	PHP_ME(TElBaseArchive, get_OnProgress, arginfo_TElBaseArchive_get_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElBaseArchive, set_OnProgress, arginfo_TElBaseArchive_set_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElBaseArchive, __construct, arginfo_TElBaseArchive___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElBaseArchive(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElBaseArchive_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElBaseArchive", TElBaseArchive_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElBaseArchive_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElArchiveDirectoryEntry_ce_ptr = NULL;

SB_PHP_METHOD(TElArchiveDirectoryEntry, get_FileName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElArchiveDirectoryEntry_get_FileName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1319029840, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, set_FileName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElArchiveDirectoryEntry_set_FileName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, get_FileSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElArchiveDirectoryEntry_get_FileSize(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, set_FileSize)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElArchiveDirectoryEntry_set_FileSize(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, get_FileDateCreated)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElArchiveDirectoryEntry_get_FileDateCreated(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, set_FileDateCreated)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElArchiveDirectoryEntry_set_FileDateCreated(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, get_FileDateModified)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElArchiveDirectoryEntry_get_FileDateModified(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, set_FileDateModified)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElArchiveDirectoryEntry_set_FileDateModified(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, get_FileDateAccessed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElArchiveDirectoryEntry_get_FileDateAccessed(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, set_FileDateAccessed)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElArchiveDirectoryEntry_set_FileDateAccessed(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, get_CompressedSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElArchiveDirectoryEntry_get_CompressedSize(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, set_CompressedSize)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElArchiveDirectoryEntry_set_CompressedSize(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, get_IsDirectory)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElArchiveDirectoryEntry_get_IsDirectory(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, set_IsDirectory)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElArchiveDirectoryEntry_set_IsDirectory(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, get_EntriesCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElArchiveDirectoryEntry_get_EntriesCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArchiveDirectoryEntry, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElArchiveDirectoryEntry_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TElBaseArchive_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElArchiveDirectoryEntry_Create_1(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElBaseArchive)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_get_FileName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_set_FileName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_get_FileSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_set_FileSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_get_FileDateCreated, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_set_FileDateCreated, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_get_FileDateModified, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_set_FileDateModified, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_get_FileDateAccessed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_set_FileDateAccessed, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_get_CompressedSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_set_CompressedSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_get_IsDirectory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_set_IsDirectory, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry_get_EntriesCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArchiveDirectoryEntry___construct, 0, 0, 0)
	ZEND_ARG_OBJ_INFO(0, Owner, TElBaseArchive, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElArchiveDirectoryEntry_methods[] = {
	PHP_ME(TElArchiveDirectoryEntry, get_FileName, arginfo_TElArchiveDirectoryEntry_get_FileName, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, set_FileName, arginfo_TElArchiveDirectoryEntry_set_FileName, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, get_FileSize, arginfo_TElArchiveDirectoryEntry_get_FileSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, set_FileSize, arginfo_TElArchiveDirectoryEntry_set_FileSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, get_FileDateCreated, arginfo_TElArchiveDirectoryEntry_get_FileDateCreated, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, set_FileDateCreated, arginfo_TElArchiveDirectoryEntry_set_FileDateCreated, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, get_FileDateModified, arginfo_TElArchiveDirectoryEntry_get_FileDateModified, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, set_FileDateModified, arginfo_TElArchiveDirectoryEntry_set_FileDateModified, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, get_FileDateAccessed, arginfo_TElArchiveDirectoryEntry_get_FileDateAccessed, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, set_FileDateAccessed, arginfo_TElArchiveDirectoryEntry_set_FileDateAccessed, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, get_CompressedSize, arginfo_TElArchiveDirectoryEntry_get_CompressedSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, set_CompressedSize, arginfo_TElArchiveDirectoryEntry_set_CompressedSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, get_IsDirectory, arginfo_TElArchiveDirectoryEntry_get_IsDirectory, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, set_IsDirectory, arginfo_TElArchiveDirectoryEntry_set_IsDirectory, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, get_EntriesCount, arginfo_TElArchiveDirectoryEntry_get_EntriesCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElArchiveDirectoryEntry, __construct, arginfo_TElArchiveDirectoryEntry___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElArchiveDirectoryEntry(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElArchiveDirectoryEntry_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElArchiveDirectoryEntry", TElArchiveDirectoryEntry_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElArchiveDirectoryEntry_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElArcProcessingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElArcProcessingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElArcProcessingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArcProcessingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElArcProcessingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArcProcessingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElArcProcessingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArcProcessingUnit, get_OutputStream)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElArcProcessingUnit_get_OutputStream(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStream_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArcProcessingUnit, set_OutputStream)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElArcProcessingUnit_set_OutputStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArcProcessingUnit, get_OutputProcessingUnit)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElArcProcessingUnit_get_OutputProcessingUnit(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElArcProcessingUnit_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArcProcessingUnit, set_OutputProcessingUnit)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElArcProcessingUnit_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElArcProcessingUnit_set_OutputProcessingUnit(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElArcProcessingUnit)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArcProcessingUnit, get_ProcessedData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElArcProcessingUnit_get_ProcessedData(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArcProcessingUnit, set_ProcessedData)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElArcProcessingUnit_set_ProcessedData(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArcProcessingUnit, get_WrittenData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElArcProcessingUnit_get_WrittenData(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArcProcessingUnit, set_WrittenData)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElArcProcessingUnit_set_WrittenData(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArcProcessingUnit, get_OutputEvent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBArcWriteEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElArcProcessingUnit_get_OutputEvent(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArcProcessingUnit, set_OutputEvent)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElArcProcessingUnit_set_OutputEvent(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBArcWriteEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBArcWriteEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElArcProcessingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElArcProcessingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArcProcessingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArcProcessingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArcProcessingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArcProcessingUnit_get_OutputStream, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArcProcessingUnit_set_OutputStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArcProcessingUnit_get_OutputProcessingUnit, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArcProcessingUnit_set_OutputProcessingUnit, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElArcProcessingUnit, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArcProcessingUnit_get_ProcessedData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArcProcessingUnit_set_ProcessedData, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArcProcessingUnit_get_WrittenData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArcProcessingUnit_set_WrittenData, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArcProcessingUnit_get_OutputEvent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArcProcessingUnit_set_OutputEvent, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElArcProcessingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElArcProcessingUnit_methods[] = {
	PHP_ME(TElArcProcessingUnit, InitializeProcessing, arginfo_TElArcProcessingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElArcProcessingUnit, ProcessBlock, arginfo_TElArcProcessingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElArcProcessingUnit, FinalizeProcessing, arginfo_TElArcProcessingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElArcProcessingUnit, get_OutputStream, arginfo_TElArcProcessingUnit_get_OutputStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElArcProcessingUnit, set_OutputStream, arginfo_TElArcProcessingUnit_set_OutputStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElArcProcessingUnit, get_OutputProcessingUnit, arginfo_TElArcProcessingUnit_get_OutputProcessingUnit, ZEND_ACC_PUBLIC)
	PHP_ME(TElArcProcessingUnit, set_OutputProcessingUnit, arginfo_TElArcProcessingUnit_set_OutputProcessingUnit, ZEND_ACC_PUBLIC)
	PHP_ME(TElArcProcessingUnit, get_ProcessedData, arginfo_TElArcProcessingUnit_get_ProcessedData, ZEND_ACC_PUBLIC)
	PHP_ME(TElArcProcessingUnit, set_ProcessedData, arginfo_TElArcProcessingUnit_set_ProcessedData, ZEND_ACC_PUBLIC)
	PHP_ME(TElArcProcessingUnit, get_WrittenData, arginfo_TElArcProcessingUnit_get_WrittenData, ZEND_ACC_PUBLIC)
	PHP_ME(TElArcProcessingUnit, set_WrittenData, arginfo_TElArcProcessingUnit_set_WrittenData, ZEND_ACC_PUBLIC)
	PHP_ME(TElArcProcessingUnit, get_OutputEvent, arginfo_TElArcProcessingUnit_get_OutputEvent, ZEND_ACC_PUBLIC)
	PHP_ME(TElArcProcessingUnit, set_OutputEvent, arginfo_TElArcProcessingUnit_set_OutputEvent, ZEND_ACC_PUBLIC)
	PHP_ME(TElArcProcessingUnit, __construct, arginfo_TElArcProcessingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElArcProcessingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElArcProcessingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElArcProcessingUnit", TElArcProcessingUnit_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElArcProcessingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

SB_PHP_FUNCTION(SBArcBase, GetUseUTCTimeInNewEntries)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBArcBase_GetUseUTCTimeInNewEntries(&bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBArcBase, SetUseUTCTimeInNewEntries)
{
	zend_bool bvalue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bvalue) == SUCCESS)
	{
		SBCheckError(SBArcBase_SetUseUTCTimeInNewEntries((int8_t)bvalue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

void Register_SBArcBase_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBArcReplaceMode", NULL);
	TSBArcReplaceMode_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBArcReplaceMode_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBArcReplaceMode_ce_ptr, "armAlways", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBArcReplaceMode_ce_ptr, "armNever", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBArcReplaceMode_ce_ptr, "armNewer", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBArcReplaceMode_ce_ptr, "armReportError", 3)
}

