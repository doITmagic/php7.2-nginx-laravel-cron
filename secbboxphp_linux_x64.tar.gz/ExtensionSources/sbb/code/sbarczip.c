#include "sbarczip.h"

#ifdef SB_WINDOWS
zend_class_entry *TSBZIPStubSource_ce_ptr = NULL;

void SB_CALLBACK TSBZIPGetStubStreamEventRaw(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream, int8_t * FreeStub)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zStream;
	zval * zFreeStub;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zStream, 1);
	ZVAL_NULL(Z_REFVAL_P(zStream));
	SB_EVENT_INIT_ZVAL_REF(zFreeStub, 2);
	ZVAL_FALSE(Z_REFVAL_P(zFreeStub));

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	*Stream = SBGetObjectHandleCE(zStream, TStream_ce_ptr TSRMLS_CC);
	SBDetachObjectHandleIfUniqueZVal(zStream TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zStream);
	convert_to_boolean(Z_REFVAL_P(zFreeStub));
	*FreeStub = (int8_t)SB_BVAL_P(Z_REFVAL_P(zFreeStub));
	SB_EVENT_CLEAR_ZVAL(zFreeStub);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}
#endif

zend_class_entry *TSBZipAddEntryResult_ce_ptr = NULL;

void SB_CALLBACK TSBZipExtractionFinishedEventRaw(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zEntry;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zEntry, 1);
	SBInitObject(zEntry, TElZipArchiveDirectoryEntry_ce_ptr, Entry TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zEntry);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBZipExtractionMakeDirectoryEventRaw(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zEntry;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zEntry, 1);
	SBInitObject(zEntry, TElZipArchiveDirectoryEntry_ce_ptr, Entry TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zEntry);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBZipPrivateKeyNeededEventRaw(void * _ObjectData, TObjectHandle Sender, void * Param, TElX509CertificateHandle Certificate)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zParam;
	zval * zCertificate;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zParam, 1);
	SBInitPointerObject(zParam, Param TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCertificate, 2);
	SBInitObject(zCertificate, TElX509Certificate_ce_ptr, Certificate TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zParam);
	SB_EVENT_CLEAR_ZVAL(zCertificate);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBZipPasswordNeededEventRaw(void * _ObjectData, TObjectHandle Sender, void * Param, char * pcPassword, int32_t * szPassword, int8_t * Cancel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zParam;
	zval * zPassword;
	zval * zCancel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zParam, 1);
	SBInitPointerObject(zParam, Param TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zPassword, 2);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zPassword), pcPassword, *szPassword);
	SB_EVENT_INIT_ZVAL_REF(zCancel, 3);
	ZVAL_BOOL(Z_REFVAL_P(zCancel), (zend_bool)*Cancel);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zParam);
	convert_to_string(Z_REFVAL_P(zPassword));
	SBCheckError(SBSetEventReturnStringA(3, Z_STRVAL_P(Z_REFVAL_P(zPassword)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zPassword))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zPassword);
	convert_to_boolean(Z_REFVAL_P(zCancel));
	*Cancel = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCancel));
	SB_EVENT_CLEAR_ZVAL(zCancel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBZipProgressEventRaw(void * _ObjectData, TObjectHandle Sender, uint64_t Processed, uint64_t Total, uint64_t OverallProcessed, uint64_t OverallTotal, int8_t * Cancel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(6);
	zval * zSender;
	zval * zProcessed;
	zval * zTotal;
	zval * zOverallProcessed;
	zval * zOverallTotal;
	zval * zCancel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zProcessed, 1);
	ZVAL_LONG(zProcessed, (sb_zend_long)Processed);
	SB_EVENT_INIT_ZVAL(zTotal, 2);
	ZVAL_LONG(zTotal, (sb_zend_long)Total);
	SB_EVENT_INIT_ZVAL(zOverallProcessed, 3);
	ZVAL_LONG(zOverallProcessed, (sb_zend_long)OverallProcessed);
	SB_EVENT_INIT_ZVAL(zOverallTotal, 4);
	ZVAL_LONG(zOverallTotal, (sb_zend_long)OverallTotal);
	SB_EVENT_INIT_ZVAL_REF(zCancel, 5);
	ZVAL_BOOL(Z_REFVAL_P(zCancel), (zend_bool)*Cancel);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 6, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zProcessed);
	SB_EVENT_CLEAR_ZVAL(zTotal);
	SB_EVENT_CLEAR_ZVAL(zOverallProcessed);
	SB_EVENT_CLEAR_ZVAL(zOverallTotal);
	convert_to_boolean(Z_REFVAL_P(zCancel));
	*Cancel = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCancel));
	SB_EVENT_CLEAR_ZVAL(zCancel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBZipExtractionStartEventRaw(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry, int8_t * Extract)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zEntry;
	zval * zExtract;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zEntry, 1);
	SBInitObject(zEntry, TElZipArchiveDirectoryEntry_ce_ptr, Entry TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zExtract, 2);
	ZVAL_BOOL(Z_REFVAL_P(zExtract), (zend_bool)*Extract);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zEntry);
	convert_to_boolean(Z_REFVAL_P(zExtract));
	*Extract = (int8_t)SB_BVAL_P(Z_REFVAL_P(zExtract));
	SB_EVENT_CLEAR_ZVAL(zExtract);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBZipUserActionNeededEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ForEvent, const char * pcDescription, int32_t szDescription, TElZipArchiveDirectoryEntryHandle Param, int32_t * UserAction)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zForEvent;
	zval * zDescription;
	zval * zParam;
	zval * zUserAction;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zForEvent, 1);
	ZVAL_LONG(zForEvent, (sb_zend_long)ForEvent);
	SB_EVENT_INIT_ZVAL(zDescription, 2);
	SB_ZVAL_STRINGL_DUP(zDescription, pcDescription, szDescription);
	SB_EVENT_INIT_ZVAL(zParam, 3);
	SBInitObject(zParam, TElZipArchiveDirectoryEntry_ce_ptr, Param TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zUserAction, 4);
	ZVAL_LONG(Z_REFVAL_P(zUserAction), (sb_zend_long)*UserAction);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zForEvent);
	SB_EVENT_CLEAR_ZVAL(zDescription);
	SB_EVENT_CLEAR_ZVAL(zParam);
	convert_to_long(Z_REFVAL_P(zUserAction));
	*UserAction = (int32_t)Z_LVAL_P(Z_REFVAL_P(zUserAction));
	SB_EVENT_CLEAR_ZVAL(zUserAction);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBZipExtractionStreamNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry, TStreamHandle * Stream)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zEntry;
	zval * zStream;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zEntry, 1);
	SBInitObject(zEntry, TElZipArchiveDirectoryEntry_ce_ptr, Entry TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zStream, 2);
	SBInitObject(zStream, TStream_ce_ptr, *Stream TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zEntry);
	*Stream = SBGetObjectHandleCE(zStream, TStream_ce_ptr TSRMLS_CC);
	SBDetachObjectHandleIfUniqueZVal(zStream TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zStream);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBZipCompressionStartEventRaw(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry, int8_t * Compress)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zEntry;
	zval * zCompress;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zEntry, 1);
	SBInitObject(zEntry, TElZipArchiveDirectoryEntry_ce_ptr, Entry TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zCompress, 2);
	ZVAL_BOOL(Z_REFVAL_P(zCompress), (zend_bool)*Compress);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zEntry);
	convert_to_boolean(Z_REFVAL_P(zCompress));
	*Compress = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCompress));
	SB_EVENT_CLEAR_ZVAL(zCompress);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBZipCompressionStreamNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry, TStreamHandle * Stream)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zEntry;
	zval * zStream;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zEntry, 1);
	SBInitObject(zEntry, TElZipArchiveDirectoryEntry_ce_ptr, Entry TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zStream, 2);
	SBInitObject(zStream, TStream_ce_ptr, *Stream TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zEntry);
	*Stream = SBGetObjectHandleCE(zStream, TStream_ce_ptr TSRMLS_CC);
	SBDetachObjectHandleIfUniqueZVal(zStream TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zStream);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBZipCompressionFinishedEventRaw(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zEntry;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zEntry, 1);
	SBInitObject(zEntry, TElZipArchiveDirectoryEntry_ce_ptr, Entry TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zEntry);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSBZipUnixFileType_ce_ptr = NULL;

#ifdef SB_WINDOWS
void SB_CALLBACK TSBLzmaOnProgressFuncRaw(void * _ObjectData, uint64_t Processed, uint64_t Total, int8_t * Cancel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zProcessed;
	zval * zTotal;
	zval * zCancel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zProcessed, 0);
	ZVAL_LONG(zProcessed, (sb_zend_long)Processed);
	SB_EVENT_INIT_ZVAL(zTotal, 1);
	ZVAL_LONG(zTotal, (sb_zend_long)Total);
	SB_EVENT_INIT_ZVAL_REF(zCancel, 2);
	ZVAL_BOOL(Z_REFVAL_P(zCancel), (zend_bool)*Cancel);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zProcessed);
	SB_EVENT_CLEAR_ZVAL(zTotal);
	convert_to_boolean(Z_REFVAL_P(zCancel));
	*Cancel = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCancel));
	SB_EVENT_CLEAR_ZVAL(zCancel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}
#endif

zend_class_entry *TSBZipFilenameOriginPreference_ce_ptr = NULL;

zend_class_entry *TElZipArchiveDirectoryEntry_ce_ptr = NULL;

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, AddEntry)
{
	char *sAPath;
	sb_str_size sAPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAPath, &sAPath_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_AddEntry(SBGetObjectHandle(getThis() TSRMLS_CC), sAPath, (int32_t)sAPath_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, AddUnparsedEntry)
{
	char *sAPath;
	sb_str_size sAPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAPath, &sAPath_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_AddUnparsedEntry(SBGetObjectHandle(getThis() TSRMLS_CC), sAPath, (int32_t)sAPath_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, AddNewEntry)
{
	char *sAPath;
	sb_str_size sAPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAPath, &sAPath_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_AddNewEntry(SBGetObjectHandle(getThis() TSRMLS_CC), sAPath, (int32_t)sAPath_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, RemoveEntry)
{
	char *sAPath;
	sb_str_size sAPath_len;
	zend_bool bCaseSensitive;
	zval *oEntry;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oEntry, TElZipArchiveDirectoryEntry_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_RemoveEntry(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oEntry TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAPath, &sAPath_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_RemoveEntry_1(SBGetObjectHandle(getThis() TSRMLS_CC), sAPath, (int32_t)sAPath_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sb", &sAPath, &sAPath_len, &bCaseSensitive) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_RemoveEntry_2(SBGetObjectHandle(getThis() TSRMLS_CC), sAPath, (int32_t)sAPath_len, (int8_t)bCaseSensitive, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElZipArchiveDirectoryEntry) or (string) or (string, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, ClearEntries)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_ClearEntries(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, RemoveEntries)
{
	char *sFilter;
	sb_str_size sFilter_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sFilter, &sFilter_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_RemoveEntries(SBGetObjectHandle(getThis() TSRMLS_CC), sFilter, (int32_t)sFilter_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, EntryWithName)
{
	char *sAName;
	sb_str_size sAName_len;
	zend_bool bCaseSensitive;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAName, &sAName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_EntryWithName(SBGetObjectHandle(getThis() TSRMLS_CC), sAName, (int32_t)sAName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sb", &sAName, &sAName_len, &bCaseSensitive) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_EntryWithName_1(SBGetObjectHandle(getThis() TSRMLS_CC), sAName, (int32_t)sAName_len, (int8_t)bCaseSensitive, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, EntryWithPath)
{
	char *sAPath;
	sb_str_size sAPath_len;
	zend_bool bCaseSensitive;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAPath, &sAPath_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_EntryWithPath(SBGetObjectHandle(getThis() TSRMLS_CC), sAPath, (int32_t)sAPath_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sb", &sAPath, &sAPath_len, &bCaseSensitive) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_EntryWithPath_1(SBGetObjectHandle(getThis() TSRMLS_CC), sAPath, (int32_t)sAPath_len, (int8_t)bCaseSensitive, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_LocalHeaderLoaded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_LocalHeaderLoaded(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_CentralHeaderLoaded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_CentralHeaderLoaded(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_StrongEncryptionInfoLoaded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_StrongEncryptionInfoLoaded(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_StrongEncryptionInfoLoaded)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_StrongEncryptionInfoLoaded(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_Parent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_get_Parent(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_Entries)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_get_Entries(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_Path)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipArchiveDirectoryEntry_get_Path(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(670758694, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_Flags)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_Flags(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_Flags)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_Flags(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_CompressionMethod)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_CompressionMethod(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_CompressionMethod)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_CompressionMethod(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_CompressionLevel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_CompressionLevel)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_CRC32)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_CRC32(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_CRC32)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_CRC32(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_VersionToExtract)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_VersionToExtract(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_VersionToExtract)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_VersionToExtract(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_VersionMadeBy)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_VersionMadeBy(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_VersionMadeBy)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_VersionMadeBy(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_FileAttributesCompatibility)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_FileAttributesCompatibility(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_FileAttributesCompatibility)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_FileAttributesCompatibility(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_Encrypted)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_Encrypted(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_Encrypted)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_Encrypted(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_Signed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_Signed(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_StrongEncryption)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_StrongEncryption(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_StrongEncryption)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_StrongEncryption(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_WinZipEncryption)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_WinZipEncryption(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_WinZipEncryption)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_WinZipEncryption(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_WinZipEncryptionVersion)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_WinZipEncryptionVersion(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_WinZipEncryptionVersion)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_WinZipEncryptionVersion(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_WinZipAesKeySize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_WinZipAesKeySize(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_WinZipAesKeySize)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_WinZipAesKeySize(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_LocalHeaderMasked)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_LocalHeaderMasked(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_LocalHeaderMasked)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_LocalHeaderMasked(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_LocalHeaderOffset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_LocalHeaderOffset(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_LocalHeaderOffset)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_LocalHeaderOffset(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_DataOffset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_DataOffset(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_DiskNumberStart)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_DiskNumberStart(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_DiskNumberStart)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_DiskNumberStart(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_StrongEncryptionInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_get_StrongEncryptionInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipStrongEncryptionInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_SignatureCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_SignatureCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_Signatures)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_get_Signatures(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipStrongEncryptionSignatureInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_Process)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_Process(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_Process)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_Process(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_Attributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_get_Attributes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipDosFileAttributes_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_UnixAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_get_UnixAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipUnixFileAttributes_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_Comment)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElZipArchiveDirectoryEntry_get_Comment(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-296923608, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_Comment)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElZipArchiveDirectoryEntry_set_Comment(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_ExtractionPath)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipArchiveDirectoryEntry_get_ExtractionPath(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1908571093, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_ExtractionPath)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_ExtractionPath(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_ExtractionStream)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_get_ExtractionStream(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStream_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_ExtractionStream)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_ExtractionStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_InputPath)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipArchiveDirectoryEntry_get_InputPath(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(596827691, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_InputPath)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_InputPath(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_InputStream)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_get_InputStream(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStream_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_InputStream)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_InputStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_InputData)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElZipArchiveDirectoryEntry_get_InputData(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-2060081593, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_InputData)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElZipArchiveDirectoryEntry_set_InputData(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, get_FreeInputStream)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipArchiveDirectoryEntry_get_FreeInputStream(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, set_FreeInputStream)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipArchiveDirectoryEntry_set_FreeInputStream(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipArchiveDirectoryEntry, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TElBaseArchive_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipArchiveDirectoryEntry_Create_1(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElBaseArchive)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_AddEntry, 0, 0, 1)
	ZEND_ARG_INFO(0, APath)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_AddUnparsedEntry, 0, 0, 1)
	ZEND_ARG_INFO(0, APath)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_AddNewEntry, 0, 0, 1)
	ZEND_ARG_INFO(0, APath)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_RemoveEntry, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Entry_or_APath, 0, 1)
	ZEND_ARG_INFO(0, CaseSensitive)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_ClearEntries, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_RemoveEntries, 0, 0, 1)
	ZEND_ARG_INFO(0, Filter)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_EntryWithName, 0, 0, 1)
	ZEND_ARG_INFO(0, AName)
	ZEND_ARG_INFO(0, CaseSensitive)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_EntryWithPath, 0, 0, 1)
	ZEND_ARG_INFO(0, APath)
	ZEND_ARG_INFO(0, CaseSensitive)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_LocalHeaderLoaded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_CentralHeaderLoaded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_StrongEncryptionInfoLoaded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_StrongEncryptionInfoLoaded, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_Parent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_Entries, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_Path, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_Flags, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_Flags, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_CompressionMethod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_CompressionMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_CompressionLevel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_CompressionLevel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_CRC32, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_CRC32, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_VersionToExtract, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_VersionToExtract, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_VersionMadeBy, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_VersionMadeBy, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_FileAttributesCompatibility, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_FileAttributesCompatibility, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_Encrypted, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_Encrypted, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_Signed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_StrongEncryption, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_StrongEncryption, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_WinZipEncryption, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_WinZipEncryption, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_WinZipEncryptionVersion, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_WinZipEncryptionVersion, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_WinZipAesKeySize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_WinZipAesKeySize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_LocalHeaderMasked, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_LocalHeaderMasked, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_LocalHeaderOffset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_LocalHeaderOffset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_DataOffset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_DiskNumberStart, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_DiskNumberStart, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_StrongEncryptionInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_SignatureCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_Signatures, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_Process, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_Process, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_Attributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_UnixAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_Comment, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_Comment, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_ExtractionPath, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_ExtractionPath, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_ExtractionStream, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_ExtractionStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_InputPath, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_InputPath, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_InputStream, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_InputStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_InputData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_InputData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_get_FreeInputStream, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry_set_FreeInputStream, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipArchiveDirectoryEntry___construct, 0, 0, 0)
	ZEND_ARG_OBJ_INFO(0, Owner, TElBaseArchive, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipArchiveDirectoryEntry_methods[] = {
	PHP_ME(TElZipArchiveDirectoryEntry, Clear, arginfo_TElZipArchiveDirectoryEntry_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, AddEntry, arginfo_TElZipArchiveDirectoryEntry_AddEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, AddUnparsedEntry, arginfo_TElZipArchiveDirectoryEntry_AddUnparsedEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, AddNewEntry, arginfo_TElZipArchiveDirectoryEntry_AddNewEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, RemoveEntry, arginfo_TElZipArchiveDirectoryEntry_RemoveEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, ClearEntries, arginfo_TElZipArchiveDirectoryEntry_ClearEntries, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, RemoveEntries, arginfo_TElZipArchiveDirectoryEntry_RemoveEntries, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, EntryWithName, arginfo_TElZipArchiveDirectoryEntry_EntryWithName, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, EntryWithPath, arginfo_TElZipArchiveDirectoryEntry_EntryWithPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_LocalHeaderLoaded, arginfo_TElZipArchiveDirectoryEntry_get_LocalHeaderLoaded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_CentralHeaderLoaded, arginfo_TElZipArchiveDirectoryEntry_get_CentralHeaderLoaded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_StrongEncryptionInfoLoaded, arginfo_TElZipArchiveDirectoryEntry_get_StrongEncryptionInfoLoaded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_StrongEncryptionInfoLoaded, arginfo_TElZipArchiveDirectoryEntry_set_StrongEncryptionInfoLoaded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_Parent, arginfo_TElZipArchiveDirectoryEntry_get_Parent, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_Entries, arginfo_TElZipArchiveDirectoryEntry_get_Entries, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_Path, arginfo_TElZipArchiveDirectoryEntry_get_Path, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_Flags, arginfo_TElZipArchiveDirectoryEntry_get_Flags, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_Flags, arginfo_TElZipArchiveDirectoryEntry_set_Flags, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_CompressionMethod, arginfo_TElZipArchiveDirectoryEntry_get_CompressionMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_CompressionMethod, arginfo_TElZipArchiveDirectoryEntry_set_CompressionMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_CompressionLevel, arginfo_TElZipArchiveDirectoryEntry_get_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_CompressionLevel, arginfo_TElZipArchiveDirectoryEntry_set_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_CRC32, arginfo_TElZipArchiveDirectoryEntry_get_CRC32, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_CRC32, arginfo_TElZipArchiveDirectoryEntry_set_CRC32, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_VersionToExtract, arginfo_TElZipArchiveDirectoryEntry_get_VersionToExtract, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_VersionToExtract, arginfo_TElZipArchiveDirectoryEntry_set_VersionToExtract, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_VersionMadeBy, arginfo_TElZipArchiveDirectoryEntry_get_VersionMadeBy, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_VersionMadeBy, arginfo_TElZipArchiveDirectoryEntry_set_VersionMadeBy, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_FileAttributesCompatibility, arginfo_TElZipArchiveDirectoryEntry_get_FileAttributesCompatibility, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_FileAttributesCompatibility, arginfo_TElZipArchiveDirectoryEntry_set_FileAttributesCompatibility, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_Encrypted, arginfo_TElZipArchiveDirectoryEntry_get_Encrypted, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_Encrypted, arginfo_TElZipArchiveDirectoryEntry_set_Encrypted, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_Signed, arginfo_TElZipArchiveDirectoryEntry_get_Signed, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_StrongEncryption, arginfo_TElZipArchiveDirectoryEntry_get_StrongEncryption, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_StrongEncryption, arginfo_TElZipArchiveDirectoryEntry_set_StrongEncryption, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_WinZipEncryption, arginfo_TElZipArchiveDirectoryEntry_get_WinZipEncryption, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_WinZipEncryption, arginfo_TElZipArchiveDirectoryEntry_set_WinZipEncryption, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_WinZipEncryptionVersion, arginfo_TElZipArchiveDirectoryEntry_get_WinZipEncryptionVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_WinZipEncryptionVersion, arginfo_TElZipArchiveDirectoryEntry_set_WinZipEncryptionVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_WinZipAesKeySize, arginfo_TElZipArchiveDirectoryEntry_get_WinZipAesKeySize, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_WinZipAesKeySize, arginfo_TElZipArchiveDirectoryEntry_set_WinZipAesKeySize, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_LocalHeaderMasked, arginfo_TElZipArchiveDirectoryEntry_get_LocalHeaderMasked, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_LocalHeaderMasked, arginfo_TElZipArchiveDirectoryEntry_set_LocalHeaderMasked, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_LocalHeaderOffset, arginfo_TElZipArchiveDirectoryEntry_get_LocalHeaderOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_LocalHeaderOffset, arginfo_TElZipArchiveDirectoryEntry_set_LocalHeaderOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_DataOffset, arginfo_TElZipArchiveDirectoryEntry_get_DataOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_DiskNumberStart, arginfo_TElZipArchiveDirectoryEntry_get_DiskNumberStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_DiskNumberStart, arginfo_TElZipArchiveDirectoryEntry_set_DiskNumberStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_StrongEncryptionInfo, arginfo_TElZipArchiveDirectoryEntry_get_StrongEncryptionInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_SignatureCount, arginfo_TElZipArchiveDirectoryEntry_get_SignatureCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_Signatures, arginfo_TElZipArchiveDirectoryEntry_get_Signatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_Process, arginfo_TElZipArchiveDirectoryEntry_get_Process, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_Process, arginfo_TElZipArchiveDirectoryEntry_set_Process, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_Attributes, arginfo_TElZipArchiveDirectoryEntry_get_Attributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_UnixAttributes, arginfo_TElZipArchiveDirectoryEntry_get_UnixAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_Comment, arginfo_TElZipArchiveDirectoryEntry_get_Comment, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_Comment, arginfo_TElZipArchiveDirectoryEntry_set_Comment, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_ExtractionPath, arginfo_TElZipArchiveDirectoryEntry_get_ExtractionPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_ExtractionPath, arginfo_TElZipArchiveDirectoryEntry_set_ExtractionPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_ExtractionStream, arginfo_TElZipArchiveDirectoryEntry_get_ExtractionStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_ExtractionStream, arginfo_TElZipArchiveDirectoryEntry_set_ExtractionStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_InputPath, arginfo_TElZipArchiveDirectoryEntry_get_InputPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_InputPath, arginfo_TElZipArchiveDirectoryEntry_set_InputPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_InputStream, arginfo_TElZipArchiveDirectoryEntry_get_InputStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_InputStream, arginfo_TElZipArchiveDirectoryEntry_set_InputStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_InputData, arginfo_TElZipArchiveDirectoryEntry_get_InputData, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_InputData, arginfo_TElZipArchiveDirectoryEntry_set_InputData, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, get_FreeInputStream, arginfo_TElZipArchiveDirectoryEntry_get_FreeInputStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, set_FreeInputStream, arginfo_TElZipArchiveDirectoryEntry_set_FreeInputStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipArchiveDirectoryEntry, __construct, arginfo_TElZipArchiveDirectoryEntry___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipArchiveDirectoryEntry(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipArchiveDirectoryEntry_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipArchiveDirectoryEntry", TElZipArchiveDirectoryEntry_methods);
	if (NULL == TElArchiveDirectoryEntry_ce_ptr)
		Register_TElArchiveDirectoryEntry(TSRMLS_C);
	TElZipArchiveDirectoryEntry_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElArchiveDirectoryEntry_ce_ptr);
}

zend_class_entry *TElZipDosFileAttributes_ce_ptr = NULL;

SB_PHP_METHOD(TElZipDosFileAttributes, get_RawAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_RawAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, set_RawAttributes)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		SBCheckError(TElZipDosFileAttributes_set_RawAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, get_RawLastModTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_RawLastModTime(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, set_RawLastModTime)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipDosFileAttributes_set_RawLastModTime(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, get_RawLastModDate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_RawLastModDate(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, set_RawLastModDate)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipDosFileAttributes_set_RawLastModDate(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, get_ReadOnly)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_ReadOnly(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, set_ReadOnly)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipDosFileAttributes_set_ReadOnly(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, get_Hidden)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_Hidden(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, set_Hidden)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipDosFileAttributes_set_Hidden(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, get_System)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_System(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, set_System)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipDosFileAttributes_set_System(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, get_VolumeLabel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_VolumeLabel(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, set_VolumeLabel)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipDosFileAttributes_set_VolumeLabel(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, get_Directory)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_Directory(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, set_Directory)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipDosFileAttributes_set_Directory(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, get_Archive)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_Archive(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, set_Archive)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipDosFileAttributes_set_Archive(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, get_ModTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_ModTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, set_ModTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElZipDosFileAttributes_set_ModTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, get_ModifyTimeAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_ModifyTimeAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, get_CreateTimeAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_CreateTimeAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, get_AccessTimeAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_AccessTimeAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, get_CreateTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_CreateTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, set_CreateTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElZipDosFileAttributes_set_CreateTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, get_AccessTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElZipDosFileAttributes_get_AccessTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, set_AccessTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElZipDosFileAttributes_set_AccessTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDosFileAttributes, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipDosFileAttributes_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_RawAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_set_RawAttributes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_RawLastModTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_set_RawLastModTime, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_RawLastModDate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_set_RawLastModDate, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_ReadOnly, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_set_ReadOnly, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_Hidden, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_set_Hidden, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_System, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_set_System, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_VolumeLabel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_set_VolumeLabel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_Directory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_set_Directory, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_Archive, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_set_Archive, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_ModTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_set_ModTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_ModifyTimeAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_CreateTimeAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_AccessTimeAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_CreateTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_set_CreateTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_get_AccessTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes_set_AccessTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDosFileAttributes___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipDosFileAttributes_methods[] = {
	PHP_ME(TElZipDosFileAttributes, get_RawAttributes, arginfo_TElZipDosFileAttributes_get_RawAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, set_RawAttributes, arginfo_TElZipDosFileAttributes_set_RawAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, get_RawLastModTime, arginfo_TElZipDosFileAttributes_get_RawLastModTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, set_RawLastModTime, arginfo_TElZipDosFileAttributes_set_RawLastModTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, get_RawLastModDate, arginfo_TElZipDosFileAttributes_get_RawLastModDate, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, set_RawLastModDate, arginfo_TElZipDosFileAttributes_set_RawLastModDate, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, get_ReadOnly, arginfo_TElZipDosFileAttributes_get_ReadOnly, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, set_ReadOnly, arginfo_TElZipDosFileAttributes_set_ReadOnly, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, get_Hidden, arginfo_TElZipDosFileAttributes_get_Hidden, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, set_Hidden, arginfo_TElZipDosFileAttributes_set_Hidden, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, get_System, arginfo_TElZipDosFileAttributes_get_System, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, set_System, arginfo_TElZipDosFileAttributes_set_System, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, get_VolumeLabel, arginfo_TElZipDosFileAttributes_get_VolumeLabel, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, set_VolumeLabel, arginfo_TElZipDosFileAttributes_set_VolumeLabel, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, get_Directory, arginfo_TElZipDosFileAttributes_get_Directory, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, set_Directory, arginfo_TElZipDosFileAttributes_set_Directory, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, get_Archive, arginfo_TElZipDosFileAttributes_get_Archive, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, set_Archive, arginfo_TElZipDosFileAttributes_set_Archive, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, get_ModTime, arginfo_TElZipDosFileAttributes_get_ModTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, set_ModTime, arginfo_TElZipDosFileAttributes_set_ModTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, get_ModifyTimeAvailable, arginfo_TElZipDosFileAttributes_get_ModifyTimeAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, get_CreateTimeAvailable, arginfo_TElZipDosFileAttributes_get_CreateTimeAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, get_AccessTimeAvailable, arginfo_TElZipDosFileAttributes_get_AccessTimeAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, get_CreateTime, arginfo_TElZipDosFileAttributes_get_CreateTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, set_CreateTime, arginfo_TElZipDosFileAttributes_set_CreateTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, get_AccessTime, arginfo_TElZipDosFileAttributes_get_AccessTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, set_AccessTime, arginfo_TElZipDosFileAttributes_set_AccessTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDosFileAttributes, __construct, arginfo_TElZipDosFileAttributes___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipDosFileAttributes(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipDosFileAttributes_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipDosFileAttributes", TElZipDosFileAttributes_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElZipDosFileAttributes_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElZipUnixFileAttributes_ce_ptr = NULL;

SB_PHP_METHOD(TElZipUnixFileAttributes, get_RawAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_RawAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_RawAttributes)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_RawAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_FileType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipUnixFileTypeRaw fOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_FileType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_FileType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_FileType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBZipUnixFileTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_SUID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_SUID(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_SUID)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_SUID(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_SGID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_SGID(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_SGID)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_SGID(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_StickyBit)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_StickyBit(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_StickyBit)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_StickyBit(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_OwnerRead)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_OwnerRead(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_OwnerRead)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_OwnerRead(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_OwnerWrite)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_OwnerWrite(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_OwnerWrite)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_OwnerWrite(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_OwnerExecute)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_OwnerExecute(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_OwnerExecute)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_OwnerExecute(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_GroupRead)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_GroupRead(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_GroupRead)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_GroupRead(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_GroupWrite)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_GroupWrite(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_GroupWrite)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_GroupWrite(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_GroupExecute)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_GroupExecute(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_GroupExecute)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_GroupExecute(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_OtherRead)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_OtherRead(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_OtherRead)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_OtherRead(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_OtherWrite)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_OtherWrite(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_OtherWrite)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_OtherWrite(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_OtherExecute)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_OtherExecute(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_OtherExecute)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_OtherExecute(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_Permissions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_Permissions(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_Permissions)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_Permissions(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_DOSAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_DOSAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_DOSAttributes)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_DOSAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_UIDAndGIDAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_UIDAndGIDAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_UIDAndGIDAvailable)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_UIDAndGIDAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_UID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_UID(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_UID)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_UID(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_GID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_GID(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_GID)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_GID(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_ModifyTimeAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_ModifyTimeAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_ModifyTimeAvailable)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_ModifyTimeAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_CreateTimeAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_CreateTimeAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_CreateTimeAvailable)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_CreateTimeAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_AccessTimeAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_AccessTimeAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_AccessTimeAvailable)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_AccessTimeAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_ModifyTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_ModifyTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_ModifyTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_ModifyTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_CreateTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_CreateTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_CreateTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_CreateTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, get_AccessTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElZipUnixFileAttributes_get_AccessTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, set_AccessTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElZipUnixFileAttributes_set_AccessTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipUnixFileAttributes, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipUnixFileAttributes_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_RawAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_RawAttributes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_FileType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_FileType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_SUID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_SUID, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_SGID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_SGID, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_StickyBit, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_StickyBit, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_OwnerRead, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_OwnerRead, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_OwnerWrite, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_OwnerWrite, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_OwnerExecute, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_OwnerExecute, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_GroupRead, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_GroupRead, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_GroupWrite, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_GroupWrite, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_GroupExecute, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_GroupExecute, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_OtherRead, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_OtherRead, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_OtherWrite, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_OtherWrite, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_OtherExecute, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_OtherExecute, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_Permissions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_Permissions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_DOSAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_DOSAttributes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_UIDAndGIDAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_UIDAndGIDAvailable, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_UID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_UID, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_GID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_GID, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_ModifyTimeAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_ModifyTimeAvailable, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_CreateTimeAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_CreateTimeAvailable, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_AccessTimeAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_AccessTimeAvailable, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_ModifyTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_ModifyTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_CreateTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_CreateTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_get_AccessTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes_set_AccessTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipUnixFileAttributes___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipUnixFileAttributes_methods[] = {
	PHP_ME(TElZipUnixFileAttributes, get_RawAttributes, arginfo_TElZipUnixFileAttributes_get_RawAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_RawAttributes, arginfo_TElZipUnixFileAttributes_set_RawAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_FileType, arginfo_TElZipUnixFileAttributes_get_FileType, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_FileType, arginfo_TElZipUnixFileAttributes_set_FileType, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_SUID, arginfo_TElZipUnixFileAttributes_get_SUID, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_SUID, arginfo_TElZipUnixFileAttributes_set_SUID, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_SGID, arginfo_TElZipUnixFileAttributes_get_SGID, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_SGID, arginfo_TElZipUnixFileAttributes_set_SGID, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_StickyBit, arginfo_TElZipUnixFileAttributes_get_StickyBit, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_StickyBit, arginfo_TElZipUnixFileAttributes_set_StickyBit, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_OwnerRead, arginfo_TElZipUnixFileAttributes_get_OwnerRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_OwnerRead, arginfo_TElZipUnixFileAttributes_set_OwnerRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_OwnerWrite, arginfo_TElZipUnixFileAttributes_get_OwnerWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_OwnerWrite, arginfo_TElZipUnixFileAttributes_set_OwnerWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_OwnerExecute, arginfo_TElZipUnixFileAttributes_get_OwnerExecute, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_OwnerExecute, arginfo_TElZipUnixFileAttributes_set_OwnerExecute, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_GroupRead, arginfo_TElZipUnixFileAttributes_get_GroupRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_GroupRead, arginfo_TElZipUnixFileAttributes_set_GroupRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_GroupWrite, arginfo_TElZipUnixFileAttributes_get_GroupWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_GroupWrite, arginfo_TElZipUnixFileAttributes_set_GroupWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_GroupExecute, arginfo_TElZipUnixFileAttributes_get_GroupExecute, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_GroupExecute, arginfo_TElZipUnixFileAttributes_set_GroupExecute, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_OtherRead, arginfo_TElZipUnixFileAttributes_get_OtherRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_OtherRead, arginfo_TElZipUnixFileAttributes_set_OtherRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_OtherWrite, arginfo_TElZipUnixFileAttributes_get_OtherWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_OtherWrite, arginfo_TElZipUnixFileAttributes_set_OtherWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_OtherExecute, arginfo_TElZipUnixFileAttributes_get_OtherExecute, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_OtherExecute, arginfo_TElZipUnixFileAttributes_set_OtherExecute, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_Permissions, arginfo_TElZipUnixFileAttributes_get_Permissions, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_Permissions, arginfo_TElZipUnixFileAttributes_set_Permissions, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_DOSAttributes, arginfo_TElZipUnixFileAttributes_get_DOSAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_DOSAttributes, arginfo_TElZipUnixFileAttributes_set_DOSAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_UIDAndGIDAvailable, arginfo_TElZipUnixFileAttributes_get_UIDAndGIDAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_UIDAndGIDAvailable, arginfo_TElZipUnixFileAttributes_set_UIDAndGIDAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_UID, arginfo_TElZipUnixFileAttributes_get_UID, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_UID, arginfo_TElZipUnixFileAttributes_set_UID, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_GID, arginfo_TElZipUnixFileAttributes_get_GID, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_GID, arginfo_TElZipUnixFileAttributes_set_GID, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_ModifyTimeAvailable, arginfo_TElZipUnixFileAttributes_get_ModifyTimeAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_ModifyTimeAvailable, arginfo_TElZipUnixFileAttributes_set_ModifyTimeAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_CreateTimeAvailable, arginfo_TElZipUnixFileAttributes_get_CreateTimeAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_CreateTimeAvailable, arginfo_TElZipUnixFileAttributes_set_CreateTimeAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_AccessTimeAvailable, arginfo_TElZipUnixFileAttributes_get_AccessTimeAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_AccessTimeAvailable, arginfo_TElZipUnixFileAttributes_set_AccessTimeAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_ModifyTime, arginfo_TElZipUnixFileAttributes_get_ModifyTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_ModifyTime, arginfo_TElZipUnixFileAttributes_set_ModifyTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_CreateTime, arginfo_TElZipUnixFileAttributes_get_CreateTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_CreateTime, arginfo_TElZipUnixFileAttributes_set_CreateTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, get_AccessTime, arginfo_TElZipUnixFileAttributes_get_AccessTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, set_AccessTime, arginfo_TElZipUnixFileAttributes_set_AccessTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipUnixFileAttributes, __construct, arginfo_TElZipUnixFileAttributes___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipUnixFileAttributes(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipUnixFileAttributes_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipUnixFileAttributes", TElZipUnixFileAttributes_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElZipUnixFileAttributes_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElZipStrongEncryptionInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElZipStrongEncryptionInfo, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElZipStrongEncryptionInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionInfo_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElZipStrongEncryptionInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionInfo, get_EncryptionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionInfo_get_EncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionInfo, set_EncryptionAlgorithm)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionInfo_set_EncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionInfo, get_KeyLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionInfo_get_KeyLength(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionInfo, set_KeyLength)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionInfo_set_KeyLength(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionInfo, get_UsePassword)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionInfo_get_UsePassword(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionInfo, set_UsePassword)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionInfo_set_UsePassword(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionInfo, get_UseCertificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionInfo_get_UseCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionInfo, set_UseCertificates)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionInfo_set_UseCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionInfo, get_UseOAEP)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionInfo_get_UseOAEP(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionInfo, set_UseOAEP)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionInfo_set_UseOAEP(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionInfo, get_Use3DES)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionInfo_get_Use3DES(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionInfo, set_Use3DES)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionInfo_set_Use3DES(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipStrongEncryptionInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionInfo_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElZipStrongEncryptionInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionInfo_get_EncryptionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionInfo_set_EncryptionAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionInfo_get_KeyLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionInfo_set_KeyLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionInfo_get_UsePassword, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionInfo_set_UsePassword, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionInfo_get_UseCertificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionInfo_set_UseCertificates, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionInfo_get_UseOAEP, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionInfo_set_UseOAEP, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionInfo_get_Use3DES, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionInfo_set_Use3DES, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipStrongEncryptionInfo_methods[] = {
	PHP_ME(TElZipStrongEncryptionInfo, Assign, arginfo_TElZipStrongEncryptionInfo_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionInfo, get_EncryptionAlgorithm, arginfo_TElZipStrongEncryptionInfo_get_EncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionInfo, set_EncryptionAlgorithm, arginfo_TElZipStrongEncryptionInfo_set_EncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionInfo, get_KeyLength, arginfo_TElZipStrongEncryptionInfo_get_KeyLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionInfo, set_KeyLength, arginfo_TElZipStrongEncryptionInfo_set_KeyLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionInfo, get_UsePassword, arginfo_TElZipStrongEncryptionInfo_get_UsePassword, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionInfo, set_UsePassword, arginfo_TElZipStrongEncryptionInfo_set_UsePassword, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionInfo, get_UseCertificates, arginfo_TElZipStrongEncryptionInfo_get_UseCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionInfo, set_UseCertificates, arginfo_TElZipStrongEncryptionInfo_set_UseCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionInfo, get_UseOAEP, arginfo_TElZipStrongEncryptionInfo_get_UseOAEP, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionInfo, set_UseOAEP, arginfo_TElZipStrongEncryptionInfo_set_UseOAEP, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionInfo, get_Use3DES, arginfo_TElZipStrongEncryptionInfo_get_Use3DES, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionInfo, set_Use3DES, arginfo_TElZipStrongEncryptionInfo_set_Use3DES, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionInfo, __construct, arginfo_TElZipStrongEncryptionInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipStrongEncryptionInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipStrongEncryptionInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipStrongEncryptionInfo", TElZipStrongEncryptionInfo_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElZipStrongEncryptionInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElZipStrongEncryptionSignatureInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElZipStrongEncryptionSignatureInfo, get_Issuer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipStrongEncryptionSignatureInfo_get_Issuer(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElRelativeDistinguishedName_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionSignatureInfo, get_SerialNumber)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElZipStrongEncryptionSignatureInfo_get_SerialNumber(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-740874000, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionSignatureInfo, get_SignatureData)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElZipStrongEncryptionSignatureInfo_get_SignatureData(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1139348860, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionSignatureInfo, get_HashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionSignatureInfo_get_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionSignatureInfo, get_ContentHash)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElZipStrongEncryptionSignatureInfo_get_ContentHash(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1634167042, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionSignatureInfo, set_ContentHash)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElZipStrongEncryptionSignatureInfo_set_ContentHash(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionSignatureInfo, get_SigningCertificate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipStrongEncryptionSignatureInfo_get_SigningCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionSignatureInfo, set_SigningCertificate)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionSignatureInfo_set_SigningCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionSignatureInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipStrongEncryptionSignatureInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionSignatureInfo_get_Issuer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionSignatureInfo_get_SerialNumber, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionSignatureInfo_get_SignatureData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionSignatureInfo_get_HashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionSignatureInfo_get_ContentHash, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionSignatureInfo_set_ContentHash, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionSignatureInfo_get_SigningCertificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionSignatureInfo_set_SigningCertificate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionSignatureInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipStrongEncryptionSignatureInfo_methods[] = {
	PHP_ME(TElZipStrongEncryptionSignatureInfo, get_Issuer, arginfo_TElZipStrongEncryptionSignatureInfo_get_Issuer, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionSignatureInfo, get_SerialNumber, arginfo_TElZipStrongEncryptionSignatureInfo_get_SerialNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionSignatureInfo, get_SignatureData, arginfo_TElZipStrongEncryptionSignatureInfo_get_SignatureData, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionSignatureInfo, get_HashAlgorithm, arginfo_TElZipStrongEncryptionSignatureInfo_get_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionSignatureInfo, get_ContentHash, arginfo_TElZipStrongEncryptionSignatureInfo_get_ContentHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionSignatureInfo, set_ContentHash, arginfo_TElZipStrongEncryptionSignatureInfo_set_ContentHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionSignatureInfo, get_SigningCertificate, arginfo_TElZipStrongEncryptionSignatureInfo_get_SigningCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionSignatureInfo, set_SigningCertificate, arginfo_TElZipStrongEncryptionSignatureInfo_set_SigningCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionSignatureInfo, __construct, arginfo_TElZipStrongEncryptionSignatureInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipStrongEncryptionSignatureInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipStrongEncryptionSignatureInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipStrongEncryptionSignatureInfo", TElZipStrongEncryptionSignatureInfo_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElZipStrongEncryptionSignatureInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElZipProcessingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipProcessingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipProcessingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipProcessingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipProcessingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipProcessingUnit, get_CryptoProviderManager)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipProcessingUnit_get_CryptoProviderManager(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoProviderManager_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipProcessingUnit, set_CryptoProviderManager)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCryptoProviderManager_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElZipProcessingUnit_set_CryptoProviderManager(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoProviderManager)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipProcessingUnit, get_ProcessingEntry)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipProcessingUnit_get_ProcessingEntry(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipProcessingUnit, set_ProcessingEntry)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElZipArchiveDirectoryEntry_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElZipProcessingUnit_set_ProcessingEntry(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElZipArchiveDirectoryEntry)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipProcessingUnit, get_CRC32)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipProcessingUnit_get_CRC32(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipProcessingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipProcessingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipProcessingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipProcessingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipProcessingUnit_get_CryptoProviderManager, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipProcessingUnit_set_CryptoProviderManager, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCryptoProviderManager, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipProcessingUnit_get_ProcessingEntry, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipProcessingUnit_set_ProcessingEntry, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElZipArchiveDirectoryEntry, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipProcessingUnit_get_CRC32, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipProcessingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipProcessingUnit_methods[] = {
	PHP_ME(TElZipProcessingUnit, InitializeProcessing, arginfo_TElZipProcessingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipProcessingUnit, FinalizeProcessing, arginfo_TElZipProcessingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipProcessingUnit, get_CryptoProviderManager, arginfo_TElZipProcessingUnit_get_CryptoProviderManager, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipProcessingUnit, set_CryptoProviderManager, arginfo_TElZipProcessingUnit_set_CryptoProviderManager, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipProcessingUnit, get_ProcessingEntry, arginfo_TElZipProcessingUnit_get_ProcessingEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipProcessingUnit, set_ProcessingEntry, arginfo_TElZipProcessingUnit_set_ProcessingEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipProcessingUnit, get_CRC32, arginfo_TElZipProcessingUnit_get_CRC32, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipProcessingUnit, __construct, arginfo_TElZipProcessingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipProcessingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipProcessingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipProcessingUnit", TElZipProcessingUnit_methods);
	if (NULL == TElArcProcessingUnit_ce_ptr)
		Register_TElArcProcessingUnit(TSRMLS_C);
	TElZipProcessingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElArcProcessingUnit_ce_ptr);
}

zend_class_entry *TElZipStoredProcessingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipStoredProcessingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipStoredProcessingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStoredProcessingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElZipStoredProcessingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStoredProcessingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipStoredProcessingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStoredProcessingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipStoredProcessingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStoredProcessingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStoredProcessingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStoredProcessingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStoredProcessingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipStoredProcessingUnit_methods[] = {
	PHP_ME(TElZipStoredProcessingUnit, InitializeProcessing, arginfo_TElZipStoredProcessingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStoredProcessingUnit, ProcessBlock, arginfo_TElZipStoredProcessingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStoredProcessingUnit, FinalizeProcessing, arginfo_TElZipStoredProcessingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStoredProcessingUnit, __construct, arginfo_TElZipStoredProcessingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipStoredProcessingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipStoredProcessingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipStoredProcessingUnit", TElZipStoredProcessingUnit_methods);
	if (NULL == TElZipProcessingUnit_ce_ptr)
		Register_TElZipProcessingUnit(TSRMLS_C);
	TElZipStoredProcessingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipProcessingUnit_ce_ptr);
}

zend_class_entry *TElZipDeflateDecompressingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipDeflateDecompressingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipDeflateDecompressingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDeflateDecompressingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElZipDeflateDecompressingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDeflateDecompressingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipDeflateDecompressingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDeflateDecompressingUnit, get_Deflate64)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipDeflateDecompressingUnit_get_Deflate64(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDeflateDecompressingUnit, set_Deflate64)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipDeflateDecompressingUnit_set_Deflate64(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDeflateDecompressingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipDeflateDecompressingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDeflateDecompressingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDeflateDecompressingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDeflateDecompressingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDeflateDecompressingUnit_get_Deflate64, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDeflateDecompressingUnit_set_Deflate64, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDeflateDecompressingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipDeflateDecompressingUnit_methods[] = {
	PHP_ME(TElZipDeflateDecompressingUnit, InitializeProcessing, arginfo_TElZipDeflateDecompressingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDeflateDecompressingUnit, ProcessBlock, arginfo_TElZipDeflateDecompressingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDeflateDecompressingUnit, FinalizeProcessing, arginfo_TElZipDeflateDecompressingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDeflateDecompressingUnit, get_Deflate64, arginfo_TElZipDeflateDecompressingUnit_get_Deflate64, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDeflateDecompressingUnit, set_Deflate64, arginfo_TElZipDeflateDecompressingUnit_set_Deflate64, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDeflateDecompressingUnit, __construct, arginfo_TElZipDeflateDecompressingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipDeflateDecompressingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipDeflateDecompressingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipDeflateDecompressingUnit", TElZipDeflateDecompressingUnit_methods);
	if (NULL == TElZipProcessingUnit_ce_ptr)
		Register_TElZipProcessingUnit(TSRMLS_C);
	TElZipDeflateDecompressingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipProcessingUnit_ce_ptr);
}

zend_class_entry *TElZipDeflateCompressingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipDeflateCompressingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipDeflateCompressingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDeflateCompressingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElZipDeflateCompressingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDeflateCompressingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipDeflateCompressingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDeflateCompressingUnit, get_CompressionLevel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipDeflateCompressingUnit_get_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDeflateCompressingUnit, set_CompressionLevel)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipDeflateCompressingUnit_set_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDeflateCompressingUnit, get_Deflate64)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipDeflateCompressingUnit_get_Deflate64(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDeflateCompressingUnit, set_Deflate64)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipDeflateCompressingUnit_set_Deflate64(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipDeflateCompressingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipDeflateCompressingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDeflateCompressingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDeflateCompressingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDeflateCompressingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDeflateCompressingUnit_get_CompressionLevel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDeflateCompressingUnit_set_CompressionLevel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDeflateCompressingUnit_get_Deflate64, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDeflateCompressingUnit_set_Deflate64, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipDeflateCompressingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipDeflateCompressingUnit_methods[] = {
	PHP_ME(TElZipDeflateCompressingUnit, InitializeProcessing, arginfo_TElZipDeflateCompressingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDeflateCompressingUnit, ProcessBlock, arginfo_TElZipDeflateCompressingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDeflateCompressingUnit, FinalizeProcessing, arginfo_TElZipDeflateCompressingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDeflateCompressingUnit, get_CompressionLevel, arginfo_TElZipDeflateCompressingUnit_get_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDeflateCompressingUnit, set_CompressionLevel, arginfo_TElZipDeflateCompressingUnit_set_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDeflateCompressingUnit, get_Deflate64, arginfo_TElZipDeflateCompressingUnit_get_Deflate64, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDeflateCompressingUnit, set_Deflate64, arginfo_TElZipDeflateCompressingUnit_set_Deflate64, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipDeflateCompressingUnit, __construct, arginfo_TElZipDeflateCompressingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipDeflateCompressingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipDeflateCompressingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipDeflateCompressingUnit", TElZipDeflateCompressingUnit_methods);
	if (NULL == TElZipProcessingUnit_ce_ptr)
		Register_TElZipProcessingUnit(TSRMLS_C);
	TElZipDeflateCompressingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipProcessingUnit_ce_ptr);
}

#ifdef SB_WINDOWS
zend_class_entry *TElZipLzmaDecompressingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipLzmaDecompressingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipLzmaDecompressingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaDecompressingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElZipLzmaDecompressingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaDecompressingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipLzmaDecompressingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaDecompressingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipLzmaDecompressingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaDecompressingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaDecompressingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaDecompressingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaDecompressingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipLzmaDecompressingUnit_methods[] = {
	PHP_ME(TElZipLzmaDecompressingUnit, InitializeProcessing, arginfo_TElZipLzmaDecompressingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaDecompressingUnit, ProcessBlock, arginfo_TElZipLzmaDecompressingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaDecompressingUnit, FinalizeProcessing, arginfo_TElZipLzmaDecompressingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaDecompressingUnit, __construct, arginfo_TElZipLzmaDecompressingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipLzmaDecompressingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipLzmaDecompressingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipLzmaDecompressingUnit", TElZipLzmaDecompressingUnit_methods);
	if (NULL == TElZipProcessingUnit_ce_ptr)
		Register_TElZipProcessingUnit(TSRMLS_C);
	TElZipLzmaDecompressingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipProcessingUnit_ce_ptr);
}

zend_class_entry *TElZipLzmaCompressingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipLzmaCompressingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipLzmaCompressingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaCompressingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElZipLzmaCompressingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaCompressingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipLzmaCompressingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaCompressingUnit, DoInputData)
{
	sb_zend_long l4index;
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zpBuffer, &l4index, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElZipLzmaCompressingUnit_DoInputData(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4index, (int32_t)l4Size, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaCompressingUnit, get_CompressionLevel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipLzmaCompressingUnit_get_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaCompressingUnit, set_CompressionLevel)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipLzmaCompressingUnit_set_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaCompressingUnit, get_InputStream)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipLzmaCompressingUnit_get_InputStream(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStream_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaCompressingUnit, set_InputStream)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElZipLzmaCompressingUnit_set_InputStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaCompressingUnit, get_DoProgress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBLzmaOnProgressFunc pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipLzmaCompressingUnit_get_DoProgress(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaCompressingUnit, set_DoProgress)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipLzmaCompressingUnit_set_DoProgress(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBLzmaOnProgressFuncRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBLzmaOnProgressFunc|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaCompressingUnit, get_DoInput)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBLzmaInputFunc pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipLzmaCompressingUnit_get_DoInput(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaCompressingUnit, set_DoInput)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipLzmaCompressingUnit_set_DoInput(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBLzmaInputFuncRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBLzmaInputFunc|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaCompressingUnit, get_DoOutput)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBLzmaOutputFunc pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipLzmaCompressingUnit_get_DoOutput(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaCompressingUnit, set_DoOutput)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipLzmaCompressingUnit_set_DoOutput(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBLzmaOutputFuncRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBLzmaOutputFunc|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipLzmaCompressingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipLzmaCompressingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit_DoInputData, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, index)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit_get_CompressionLevel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit_set_CompressionLevel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit_get_InputStream, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit_set_InputStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit_get_DoProgress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit_set_DoProgress, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit_get_DoInput, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit_set_DoInput, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit_get_DoOutput, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit_set_DoOutput, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipLzmaCompressingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipLzmaCompressingUnit_methods[] = {
	PHP_ME(TElZipLzmaCompressingUnit, InitializeProcessing, arginfo_TElZipLzmaCompressingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaCompressingUnit, ProcessBlock, arginfo_TElZipLzmaCompressingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaCompressingUnit, FinalizeProcessing, arginfo_TElZipLzmaCompressingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaCompressingUnit, DoInputData, arginfo_TElZipLzmaCompressingUnit_DoInputData, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaCompressingUnit, get_CompressionLevel, arginfo_TElZipLzmaCompressingUnit_get_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaCompressingUnit, set_CompressionLevel, arginfo_TElZipLzmaCompressingUnit_set_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaCompressingUnit, get_InputStream, arginfo_TElZipLzmaCompressingUnit_get_InputStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaCompressingUnit, set_InputStream, arginfo_TElZipLzmaCompressingUnit_set_InputStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaCompressingUnit, get_DoProgress, arginfo_TElZipLzmaCompressingUnit_get_DoProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaCompressingUnit, set_DoProgress, arginfo_TElZipLzmaCompressingUnit_set_DoProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaCompressingUnit, get_DoInput, arginfo_TElZipLzmaCompressingUnit_get_DoInput, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaCompressingUnit, set_DoInput, arginfo_TElZipLzmaCompressingUnit_set_DoInput, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaCompressingUnit, get_DoOutput, arginfo_TElZipLzmaCompressingUnit_get_DoOutput, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaCompressingUnit, set_DoOutput, arginfo_TElZipLzmaCompressingUnit_set_DoOutput, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipLzmaCompressingUnit, __construct, arginfo_TElZipLzmaCompressingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipLzmaCompressingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipLzmaCompressingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipLzmaCompressingUnit", TElZipLzmaCompressingUnit_methods);
	if (NULL == TElZipProcessingUnit_ce_ptr)
		Register_TElZipProcessingUnit(TSRMLS_C);
	TElZipLzmaCompressingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipProcessingUnit_ce_ptr);
}
#endif

zend_class_entry *TElZipBZip2DecompressingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipBZip2DecompressingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipBZip2DecompressingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipBZip2DecompressingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElZipBZip2DecompressingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipBZip2DecompressingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipBZip2DecompressingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipBZip2DecompressingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipBZip2DecompressingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipBZip2DecompressingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipBZip2DecompressingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipBZip2DecompressingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipBZip2DecompressingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipBZip2DecompressingUnit_methods[] = {
	PHP_ME(TElZipBZip2DecompressingUnit, InitializeProcessing, arginfo_TElZipBZip2DecompressingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipBZip2DecompressingUnit, ProcessBlock, arginfo_TElZipBZip2DecompressingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipBZip2DecompressingUnit, FinalizeProcessing, arginfo_TElZipBZip2DecompressingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipBZip2DecompressingUnit, __construct, arginfo_TElZipBZip2DecompressingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipBZip2DecompressingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipBZip2DecompressingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipBZip2DecompressingUnit", TElZipBZip2DecompressingUnit_methods);
	if (NULL == TElZipProcessingUnit_ce_ptr)
		Register_TElZipProcessingUnit(TSRMLS_C);
	TElZipBZip2DecompressingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipProcessingUnit_ce_ptr);
}

zend_class_entry *TElZipBZip2CompressingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipBZip2CompressingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipBZip2CompressingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipBZip2CompressingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElZipBZip2CompressingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipBZip2CompressingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipBZip2CompressingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipBZip2CompressingUnit, get_CompressionLevel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipBZip2CompressingUnit_get_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipBZip2CompressingUnit, set_CompressionLevel)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipBZip2CompressingUnit_set_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipBZip2CompressingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipBZip2CompressingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipBZip2CompressingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipBZip2CompressingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipBZip2CompressingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipBZip2CompressingUnit_get_CompressionLevel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipBZip2CompressingUnit_set_CompressionLevel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipBZip2CompressingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipBZip2CompressingUnit_methods[] = {
	PHP_ME(TElZipBZip2CompressingUnit, InitializeProcessing, arginfo_TElZipBZip2CompressingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipBZip2CompressingUnit, ProcessBlock, arginfo_TElZipBZip2CompressingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipBZip2CompressingUnit, FinalizeProcessing, arginfo_TElZipBZip2CompressingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipBZip2CompressingUnit, get_CompressionLevel, arginfo_TElZipBZip2CompressingUnit_get_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipBZip2CompressingUnit, set_CompressionLevel, arginfo_TElZipBZip2CompressingUnit_set_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipBZip2CompressingUnit, __construct, arginfo_TElZipBZip2CompressingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipBZip2CompressingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipBZip2CompressingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipBZip2CompressingUnit", TElZipBZip2CompressingUnit_methods);
	if (NULL == TElZipProcessingUnit_ce_ptr)
		Register_TElZipProcessingUnit(TSRMLS_C);
	TElZipBZip2CompressingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipProcessingUnit_ce_ptr);
}

zend_class_entry *TElZipOldStyleEncryptingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipOldStyleEncryptingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipOldStyleEncryptingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleEncryptingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElZipOldStyleEncryptingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleEncryptingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipOldStyleEncryptingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleEncryptingUnit, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipOldStyleEncryptingUnit_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1947991709, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleEncryptingUnit, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZipOldStyleEncryptingUnit_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleEncryptingUnit, get_OnPasswordNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipPasswordNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipOldStyleEncryptingUnit_get_OnPasswordNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleEncryptingUnit, set_OnPasswordNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipOldStyleEncryptingUnit_set_OnPasswordNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipPasswordNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipPasswordNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleEncryptingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipOldStyleEncryptingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleEncryptingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleEncryptingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleEncryptingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleEncryptingUnit_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleEncryptingUnit_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleEncryptingUnit_get_OnPasswordNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleEncryptingUnit_set_OnPasswordNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleEncryptingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipOldStyleEncryptingUnit_methods[] = {
	PHP_ME(TElZipOldStyleEncryptingUnit, InitializeProcessing, arginfo_TElZipOldStyleEncryptingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleEncryptingUnit, ProcessBlock, arginfo_TElZipOldStyleEncryptingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleEncryptingUnit, FinalizeProcessing, arginfo_TElZipOldStyleEncryptingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleEncryptingUnit, get_Password, arginfo_TElZipOldStyleEncryptingUnit_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleEncryptingUnit, set_Password, arginfo_TElZipOldStyleEncryptingUnit_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleEncryptingUnit, get_OnPasswordNeeded, arginfo_TElZipOldStyleEncryptingUnit_get_OnPasswordNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleEncryptingUnit, set_OnPasswordNeeded, arginfo_TElZipOldStyleEncryptingUnit_set_OnPasswordNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleEncryptingUnit, __construct, arginfo_TElZipOldStyleEncryptingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipOldStyleEncryptingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipOldStyleEncryptingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipOldStyleEncryptingUnit", TElZipOldStyleEncryptingUnit_methods);
	if (NULL == TElZipProcessingUnit_ce_ptr)
		Register_TElZipProcessingUnit(TSRMLS_C);
	TElZipOldStyleEncryptingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipProcessingUnit_ce_ptr);
}

zend_class_entry *TElZipOldStyleDecryptingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipOldStyleDecryptingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipOldStyleDecryptingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleDecryptingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElZipOldStyleDecryptingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleDecryptingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipOldStyleDecryptingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleDecryptingUnit, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipOldStyleDecryptingUnit_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1108793960, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleDecryptingUnit, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZipOldStyleDecryptingUnit_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleDecryptingUnit, get_HeaderRead)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipOldStyleDecryptingUnit_get_HeaderRead(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleDecryptingUnit, get_IgnorePasswordCheck)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipOldStyleDecryptingUnit_get_IgnorePasswordCheck(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleDecryptingUnit, set_IgnorePasswordCheck)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipOldStyleDecryptingUnit_set_IgnorePasswordCheck(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleDecryptingUnit, get_OnPasswordNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipPasswordNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipOldStyleDecryptingUnit_get_OnPasswordNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleDecryptingUnit, set_OnPasswordNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipOldStyleDecryptingUnit_set_OnPasswordNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipPasswordNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipPasswordNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipOldStyleDecryptingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipOldStyleDecryptingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleDecryptingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleDecryptingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleDecryptingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleDecryptingUnit_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleDecryptingUnit_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleDecryptingUnit_get_HeaderRead, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleDecryptingUnit_get_IgnorePasswordCheck, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleDecryptingUnit_set_IgnorePasswordCheck, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleDecryptingUnit_get_OnPasswordNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleDecryptingUnit_set_OnPasswordNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipOldStyleDecryptingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipOldStyleDecryptingUnit_methods[] = {
	PHP_ME(TElZipOldStyleDecryptingUnit, InitializeProcessing, arginfo_TElZipOldStyleDecryptingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleDecryptingUnit, ProcessBlock, arginfo_TElZipOldStyleDecryptingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleDecryptingUnit, FinalizeProcessing, arginfo_TElZipOldStyleDecryptingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleDecryptingUnit, get_Password, arginfo_TElZipOldStyleDecryptingUnit_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleDecryptingUnit, set_Password, arginfo_TElZipOldStyleDecryptingUnit_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleDecryptingUnit, get_HeaderRead, arginfo_TElZipOldStyleDecryptingUnit_get_HeaderRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleDecryptingUnit, get_IgnorePasswordCheck, arginfo_TElZipOldStyleDecryptingUnit_get_IgnorePasswordCheck, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleDecryptingUnit, set_IgnorePasswordCheck, arginfo_TElZipOldStyleDecryptingUnit_set_IgnorePasswordCheck, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleDecryptingUnit, get_OnPasswordNeeded, arginfo_TElZipOldStyleDecryptingUnit_get_OnPasswordNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleDecryptingUnit, set_OnPasswordNeeded, arginfo_TElZipOldStyleDecryptingUnit_set_OnPasswordNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipOldStyleDecryptingUnit, __construct, arginfo_TElZipOldStyleDecryptingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipOldStyleDecryptingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipOldStyleDecryptingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipOldStyleDecryptingUnit", TElZipOldStyleDecryptingUnit_methods);
	if (NULL == TElZipProcessingUnit_ce_ptr)
		Register_TElZipProcessingUnit(TSRMLS_C);
	TElZipOldStyleDecryptingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipProcessingUnit_ce_ptr);
}

zend_class_entry *TElZipStrongEncryptionBaseUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipStrongEncryptionBaseUnit, get_OnPasswordNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipPasswordNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipStrongEncryptionBaseUnit_get_OnPasswordNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionBaseUnit, set_OnPasswordNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipStrongEncryptionBaseUnit_set_OnPasswordNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipPasswordNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipPasswordNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionBaseUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipStrongEncryptionBaseUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionBaseUnit_get_OnPasswordNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionBaseUnit_set_OnPasswordNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionBaseUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipStrongEncryptionBaseUnit_methods[] = {
	PHP_ME(TElZipStrongEncryptionBaseUnit, get_OnPasswordNeeded, arginfo_TElZipStrongEncryptionBaseUnit_get_OnPasswordNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionBaseUnit, set_OnPasswordNeeded, arginfo_TElZipStrongEncryptionBaseUnit_set_OnPasswordNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionBaseUnit, __construct, arginfo_TElZipStrongEncryptionBaseUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipStrongEncryptionBaseUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipStrongEncryptionBaseUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipStrongEncryptionBaseUnit", TElZipStrongEncryptionBaseUnit_methods);
	if (NULL == TElZipProcessingUnit_ce_ptr)
		Register_TElZipProcessingUnit(TSRMLS_C);
	TElZipStrongEncryptionBaseUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipProcessingUnit_ce_ptr);
}

zend_class_entry *TElZipStrongEncryptionEncryptingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipStrongEncryptionEncryptingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionEncryptingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionEncryptingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElZipStrongEncryptionEncryptingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionEncryptingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionEncryptingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionEncryptingUnit, get_EncryptionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionEncryptingUnit_get_EncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionEncryptingUnit, set_EncryptionAlgorithm)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionEncryptingUnit_set_EncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionEncryptingUnit, get_EncryptionKeySize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionEncryptingUnit_get_EncryptionKeySize(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionEncryptingUnit, set_EncryptionKeySize)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionEncryptingUnit_set_EncryptionKeySize(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionEncryptingUnit, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipStrongEncryptionEncryptingUnit_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2021658764, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionEncryptingUnit, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionEncryptingUnit_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionEncryptingUnit, get_UseTripleDES)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionEncryptingUnit_get_UseTripleDES(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionEncryptingUnit, set_UseTripleDES)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionEncryptingUnit_set_UseTripleDES(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionEncryptingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipStrongEncryptionEncryptingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionEncryptingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionEncryptingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionEncryptingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionEncryptingUnit_get_EncryptionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionEncryptingUnit_set_EncryptionAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionEncryptingUnit_get_EncryptionKeySize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionEncryptingUnit_set_EncryptionKeySize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionEncryptingUnit_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionEncryptingUnit_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionEncryptingUnit_get_UseTripleDES, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionEncryptingUnit_set_UseTripleDES, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionEncryptingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipStrongEncryptionEncryptingUnit_methods[] = {
	PHP_ME(TElZipStrongEncryptionEncryptingUnit, InitializeProcessing, arginfo_TElZipStrongEncryptionEncryptingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionEncryptingUnit, ProcessBlock, arginfo_TElZipStrongEncryptionEncryptingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionEncryptingUnit, FinalizeProcessing, arginfo_TElZipStrongEncryptionEncryptingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionEncryptingUnit, get_EncryptionAlgorithm, arginfo_TElZipStrongEncryptionEncryptingUnit_get_EncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionEncryptingUnit, set_EncryptionAlgorithm, arginfo_TElZipStrongEncryptionEncryptingUnit_set_EncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionEncryptingUnit, get_EncryptionKeySize, arginfo_TElZipStrongEncryptionEncryptingUnit_get_EncryptionKeySize, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionEncryptingUnit, set_EncryptionKeySize, arginfo_TElZipStrongEncryptionEncryptingUnit_set_EncryptionKeySize, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionEncryptingUnit, get_Password, arginfo_TElZipStrongEncryptionEncryptingUnit_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionEncryptingUnit, set_Password, arginfo_TElZipStrongEncryptionEncryptingUnit_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionEncryptingUnit, get_UseTripleDES, arginfo_TElZipStrongEncryptionEncryptingUnit_get_UseTripleDES, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionEncryptingUnit, set_UseTripleDES, arginfo_TElZipStrongEncryptionEncryptingUnit_set_UseTripleDES, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionEncryptingUnit, __construct, arginfo_TElZipStrongEncryptionEncryptingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipStrongEncryptionEncryptingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipStrongEncryptionEncryptingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipStrongEncryptionEncryptingUnit", TElZipStrongEncryptionEncryptingUnit_methods);
	if (NULL == TElZipStrongEncryptionBaseUnit_ce_ptr)
		Register_TElZipStrongEncryptionBaseUnit(TSRMLS_C);
	TElZipStrongEncryptionEncryptingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipStrongEncryptionBaseUnit_ce_ptr);
}

zend_class_entry *TElZipStrongEncryptionDecryptingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, get_FileCRC32)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_get_FileCRC32(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, set_FileCRC32)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_set_FileCRC32(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, get_FileSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_get_FileSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, set_FileSize)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_set_FileSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipStrongEncryptionDecryptingUnit_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1317876849, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, get_OAEPUsed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_get_OAEPUsed(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, get_TripleDESUsed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_get_TripleDESUsed(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, get_PasswordUsed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_get_PasswordUsed(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, get_PublicKeyUsed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_get_PublicKeyUsed(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, get_Recipient)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_get_Recipient(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, set_Recipient)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_set_Recipient(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, get_OnPrivateKeyNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipPrivateKeyNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_get_OnPrivateKeyNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, set_OnPrivateKeyNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_set_OnPrivateKeyNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipPrivateKeyNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipPrivateKeyNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionDecryptingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipStrongEncryptionDecryptingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_get_FileCRC32, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_set_FileCRC32, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_get_FileSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_set_FileSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_get_OAEPUsed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_get_TripleDESUsed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_get_PasswordUsed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_get_PublicKeyUsed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_get_Recipient, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_set_Recipient, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_get_OnPrivateKeyNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit_set_OnPrivateKeyNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionDecryptingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipStrongEncryptionDecryptingUnit_methods[] = {
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, InitializeProcessing, arginfo_TElZipStrongEncryptionDecryptingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, ProcessBlock, arginfo_TElZipStrongEncryptionDecryptingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, FinalizeProcessing, arginfo_TElZipStrongEncryptionDecryptingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, get_FileCRC32, arginfo_TElZipStrongEncryptionDecryptingUnit_get_FileCRC32, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, set_FileCRC32, arginfo_TElZipStrongEncryptionDecryptingUnit_set_FileCRC32, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, get_FileSize, arginfo_TElZipStrongEncryptionDecryptingUnit_get_FileSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, set_FileSize, arginfo_TElZipStrongEncryptionDecryptingUnit_set_FileSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, get_Password, arginfo_TElZipStrongEncryptionDecryptingUnit_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, set_Password, arginfo_TElZipStrongEncryptionDecryptingUnit_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, get_OAEPUsed, arginfo_TElZipStrongEncryptionDecryptingUnit_get_OAEPUsed, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, get_TripleDESUsed, arginfo_TElZipStrongEncryptionDecryptingUnit_get_TripleDESUsed, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, get_PasswordUsed, arginfo_TElZipStrongEncryptionDecryptingUnit_get_PasswordUsed, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, get_PublicKeyUsed, arginfo_TElZipStrongEncryptionDecryptingUnit_get_PublicKeyUsed, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, get_Recipient, arginfo_TElZipStrongEncryptionDecryptingUnit_get_Recipient, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, set_Recipient, arginfo_TElZipStrongEncryptionDecryptingUnit_set_Recipient, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, get_OnPrivateKeyNeeded, arginfo_TElZipStrongEncryptionDecryptingUnit_get_OnPrivateKeyNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, set_OnPrivateKeyNeeded, arginfo_TElZipStrongEncryptionDecryptingUnit_set_OnPrivateKeyNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionDecryptingUnit, __construct, arginfo_TElZipStrongEncryptionDecryptingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipStrongEncryptionDecryptingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipStrongEncryptionDecryptingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipStrongEncryptionDecryptingUnit", TElZipStrongEncryptionDecryptingUnit_methods);
	if (NULL == TElZipStrongEncryptionBaseUnit_ce_ptr)
		Register_TElZipStrongEncryptionBaseUnit(TSRMLS_C);
	TElZipStrongEncryptionDecryptingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipStrongEncryptionBaseUnit_ce_ptr);
}

zend_class_entry *TElZipStrongEncryptionHashingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipStrongEncryptionHashingUnit, ClearHashFunctions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionHashingUnit_ClearHashFunctions(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionHashingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionHashingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionHashingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElZipStrongEncryptionHashingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionHashingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionHashingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionHashingUnit, get_HashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipStrongEncryptionHashingUnit_get_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionHashingUnit, set_HashAlgorithm)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipStrongEncryptionHashingUnit_set_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionHashingUnit, get_Hash)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElZipStrongEncryptionHashingUnit_get_Hash(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(362641037, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipStrongEncryptionHashingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipStrongEncryptionHashingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionHashingUnit_ClearHashFunctions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionHashingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionHashingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionHashingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionHashingUnit_get_HashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionHashingUnit_set_HashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionHashingUnit_get_Hash, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipStrongEncryptionHashingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipStrongEncryptionHashingUnit_methods[] = {
	PHP_ME(TElZipStrongEncryptionHashingUnit, ClearHashFunctions, arginfo_TElZipStrongEncryptionHashingUnit_ClearHashFunctions, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionHashingUnit, InitializeProcessing, arginfo_TElZipStrongEncryptionHashingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionHashingUnit, ProcessBlock, arginfo_TElZipStrongEncryptionHashingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionHashingUnit, FinalizeProcessing, arginfo_TElZipStrongEncryptionHashingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionHashingUnit, get_HashAlgorithm, arginfo_TElZipStrongEncryptionHashingUnit_get_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionHashingUnit, set_HashAlgorithm, arginfo_TElZipStrongEncryptionHashingUnit_set_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionHashingUnit, get_Hash, arginfo_TElZipStrongEncryptionHashingUnit_get_Hash, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipStrongEncryptionHashingUnit, __construct, arginfo_TElZipStrongEncryptionHashingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipStrongEncryptionHashingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipStrongEncryptionHashingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipStrongEncryptionHashingUnit", TElZipStrongEncryptionHashingUnit_methods);
	if (NULL == TElZipProcessingUnit_ce_ptr)
		Register_TElZipProcessingUnit(TSRMLS_C);
	TElZipStrongEncryptionHashingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipProcessingUnit_ce_ptr);
}

zend_class_entry *TElZipWinZipAesBaseUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipWinZipAesBaseUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipWinZipAesBaseUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWinZipAesBaseUnit, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipWinZipAesBaseUnit_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(477075349, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWinZipAesBaseUnit, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZipWinZipAesBaseUnit_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWinZipAesBaseUnit, get_OnPasswordNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipPasswordNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipWinZipAesBaseUnit_get_OnPasswordNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWinZipAesBaseUnit, set_OnPasswordNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipWinZipAesBaseUnit_set_OnPasswordNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipPasswordNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipPasswordNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWinZipAesBaseUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWinZipAesBaseUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWinZipAesBaseUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWinZipAesBaseUnit_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWinZipAesBaseUnit_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWinZipAesBaseUnit_get_OnPasswordNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWinZipAesBaseUnit_set_OnPasswordNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWinZipAesBaseUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipWinZipAesBaseUnit_methods[] = {
	PHP_ME(TElZipWinZipAesBaseUnit, InitializeProcessing, arginfo_TElZipWinZipAesBaseUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWinZipAesBaseUnit, get_Password, arginfo_TElZipWinZipAesBaseUnit_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWinZipAesBaseUnit, set_Password, arginfo_TElZipWinZipAesBaseUnit_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWinZipAesBaseUnit, get_OnPasswordNeeded, arginfo_TElZipWinZipAesBaseUnit_get_OnPasswordNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWinZipAesBaseUnit, set_OnPasswordNeeded, arginfo_TElZipWinZipAesBaseUnit_set_OnPasswordNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWinZipAesBaseUnit, __construct, arginfo_TElZipWinZipAesBaseUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipWinZipAesBaseUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipWinZipAesBaseUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipWinZipAesBaseUnit", TElZipWinZipAesBaseUnit_methods);
	if (NULL == TElZipProcessingUnit_ce_ptr)
		Register_TElZipProcessingUnit(TSRMLS_C);
	TElZipWinZipAesBaseUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipProcessingUnit_ce_ptr);
}

zend_class_entry *TElZipWinZipAesDecryptingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipWinZipAesDecryptingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipWinZipAesDecryptingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWinZipAesDecryptingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElZipWinZipAesDecryptingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWinZipAesDecryptingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipWinZipAesDecryptingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWinZipAesDecryptingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWinZipAesDecryptingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWinZipAesDecryptingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWinZipAesDecryptingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWinZipAesDecryptingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWinZipAesDecryptingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipWinZipAesDecryptingUnit_methods[] = {
	PHP_ME(TElZipWinZipAesDecryptingUnit, InitializeProcessing, arginfo_TElZipWinZipAesDecryptingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWinZipAesDecryptingUnit, ProcessBlock, arginfo_TElZipWinZipAesDecryptingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWinZipAesDecryptingUnit, FinalizeProcessing, arginfo_TElZipWinZipAesDecryptingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWinZipAesDecryptingUnit, __construct, arginfo_TElZipWinZipAesDecryptingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipWinZipAesDecryptingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipWinZipAesDecryptingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipWinZipAesDecryptingUnit", TElZipWinZipAesDecryptingUnit_methods);
	if (NULL == TElZipWinZipAesBaseUnit_ce_ptr)
		Register_TElZipWinZipAesBaseUnit(TSRMLS_C);
	TElZipWinZipAesDecryptingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipWinZipAesBaseUnit_ce_ptr);
}

zend_class_entry *TElZipWinZipAesEncryptingUnit_ce_ptr = NULL;

SB_PHP_METHOD(TElZipWinZipAesEncryptingUnit, InitializeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipWinZipAesEncryptingUnit_InitializeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWinZipAesEncryptingUnit, ProcessBlock)
{
	int32_t l4SizeRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zaBuffer, &l4Index, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElZipWinZipAesEncryptingUnit_ProcessBlock(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4SizeRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWinZipAesEncryptingUnit, FinalizeProcessing)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipWinZipAesEncryptingUnit_FinalizeProcessing(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWinZipAesEncryptingUnit, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWinZipAesEncryptingUnit_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWinZipAesEncryptingUnit_InitializeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWinZipAesEncryptingUnit_ProcessBlock, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWinZipAesEncryptingUnit_FinalizeProcessing, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWinZipAesEncryptingUnit___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipWinZipAesEncryptingUnit_methods[] = {
	PHP_ME(TElZipWinZipAesEncryptingUnit, InitializeProcessing, arginfo_TElZipWinZipAesEncryptingUnit_InitializeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWinZipAesEncryptingUnit, ProcessBlock, arginfo_TElZipWinZipAesEncryptingUnit_ProcessBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWinZipAesEncryptingUnit, FinalizeProcessing, arginfo_TElZipWinZipAesEncryptingUnit_FinalizeProcessing, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWinZipAesEncryptingUnit, __construct, arginfo_TElZipWinZipAesEncryptingUnit___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipWinZipAesEncryptingUnit(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipWinZipAesEncryptingUnit_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipWinZipAesEncryptingUnit", TElZipWinZipAesEncryptingUnit_methods);
	if (NULL == TElZipWinZipAesBaseUnit_ce_ptr)
		Register_TElZipWinZipAesBaseUnit(TSRMLS_C);
	TElZipWinZipAesEncryptingUnit_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipWinZipAesBaseUnit_ce_ptr);
}

zend_class_entry *TElZipReader_ce_ptr = NULL;

SB_PHP_METHOD(TElZipReader, Open)
{
	char *sFileName;
	sb_str_size sFileName_len;
	zend_bool bReadOnly;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sb", &sFileName, &sFileName_len, &bReadOnly) == SUCCESS)
	{
		SBCheckError(TElZipReader_Open(SBGetObjectHandle(getThis() TSRMLS_CC), sFileName, (int32_t)sFileName_len, (int8_t)bReadOnly) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElZipReader_Open_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, bool) or (\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, Close)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipReader_Close(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, Extract)
{
	char *sMask;
	char *sOutputPath;
	sb_str_size sMask_len;
	sb_str_size sOutputPath_len;
	zval *oEntries;
	zval *oEntry;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!s", &oEntry, TElZipArchiveDirectoryEntry_ce_ptr, &sOutputPath, &sOutputPath_len) == SUCCESS)
	{
		SBCheckError(TElZipReader_Extract(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oEntry TSRMLS_CC), sOutputPath, (int32_t)sOutputPath_len) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!s", &oEntries, TList_ce_ptr, &sOutputPath, &sOutputPath_len) == SUCCESS)
	{
		SBCheckError(TElZipReader_Extract_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oEntries TSRMLS_CC), sOutputPath, (int32_t)sOutputPath_len) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sMask, &sMask_len, &sOutputPath, &sOutputPath_len) == SUCCESS)
	{
		SBCheckError(TElZipReader_Extract_2(SBGetObjectHandle(getThis() TSRMLS_CC), sMask, (int32_t)sMask_len, sOutputPath, (int32_t)sOutputPath_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElZipArchiveDirectoryEntry, string) or (\\TList, string) or (string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, ExtractContents)
{
	uint32_t _err;
	zval *oEntry;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oEntry, TElZipArchiveDirectoryEntry_ce_ptr) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElZipReader_ExtractContents(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oEntry TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1992332420, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElZipArchiveDirectoryEntry)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, ValidateSignature)
{
	sb_zend_long l4SignatureIndex;
	zval *oEntry;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oEntry, TElZipArchiveDirectoryEntry_ce_ptr, &l4SignatureIndex) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipReader_ValidateSignature(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oEntry TSRMLS_CC), (int32_t)l4SignatureIndex, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElZipArchiveDirectoryEntry, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, ValidateDirectorySignature)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipReader_ValidateDirectorySignature(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, CheckEntry)
{
	zval *oEntry;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oEntry, TElZipArchiveDirectoryEntry_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipReader_CheckEntry(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oEntry TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElZipArchiveDirectoryEntry)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, CheckArchive)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipReader_CheckArchive(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_DirectoryCompressed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipReader_get_DirectoryCompressed(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_DirectoryCompressed)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_DirectoryCompressed(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_DirectoryEncrypted)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipReader_get_DirectoryEncrypted(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_DirectoryEncrypted)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_DirectoryEncrypted(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_Directory)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipReader_get_Directory(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipReader_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2082266901, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_ArchiveComment)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipReader_get_ArchiveComment(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1711072523, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_ArchiveComment)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_ArchiveComment(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_SigningCertificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipReader_get_SigningCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_EncryptingCertificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipReader_get_EncryptingCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_IgnorePasswordCheck)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipReader_get_IgnorePasswordCheck(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_IgnorePasswordCheck)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_IgnorePasswordCheck(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_RestoreAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipReader_get_RestoreAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_RestoreAttributes)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_RestoreAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_FilenamesCharset)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipReader_get_FilenamesCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1297193628, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_FilenamesCharset)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_FilenamesCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_IgnoreArchiveErrors)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipReader_get_IgnoreArchiveErrors(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_IgnoreArchiveErrors)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_IgnoreArchiveErrors(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_CaseSensitiveFilenames)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipReader_get_CaseSensitiveFilenames(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_CaseSensitiveFilenames)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_CaseSensitiveFilenames(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_MimeType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipReader_get_MimeType(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1859372729, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

#ifdef SB_WINDOWS
SB_PHP_METHOD(TElZipReader, get_SFXCopyright)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipReader_get_SFXCopyright(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1429643333, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_SFXCopyright)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_SFXCopyright(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_SFXEnabled)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipReader_get_SFXEnabled(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_SFXEnabled)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_SFXEnabled(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_SFXTitle)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipReader_get_SFXTitle(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-437208463, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_SFXTitle)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_SFXTitle(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_StubName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipReader_get_StubName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1900843673, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_StubName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_StubName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_StubSource)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZIPStubSourceRaw fOutResultRaw = 0;
		SBCheckError(TElZipReader_get_StubSource(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_StubSource)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_StubSource(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBZIPStubSourceRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}
#endif

SB_PHP_METHOD(TElZipReader, get_FilenameOriginPreference)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipFilenameOriginPreferenceRaw fOutResultRaw = 0;
		SBCheckError(TElZipReader_get_FilenameOriginPreference(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_FilenameOriginPreference)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_FilenameOriginPreference(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBZipFilenameOriginPreferenceRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_FileSystemAdapter)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipReader_get_FileSystemAdapter(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomFileSystemAdapter_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_FileSystemAdapter)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomFileSystemAdapter_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_FileSystemAdapter(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomFileSystemAdapter)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_CryptoProviderManager)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipReader_get_CryptoProviderManager(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoProviderManager_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_CryptoProviderManager)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCryptoProviderManager_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElZipReader_set_CryptoProviderManager(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoProviderManager)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_OnExtractionStreamNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipExtractionStreamNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipReader_get_OnExtractionStreamNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_OnExtractionStreamNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipReader_set_OnExtractionStreamNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipExtractionStreamNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipExtractionStreamNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_OnExtractionMakeDirectory)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipExtractionMakeDirectoryEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipReader_get_OnExtractionMakeDirectory(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_OnExtractionMakeDirectory)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipReader_set_OnExtractionMakeDirectory(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipExtractionMakeDirectoryEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipExtractionMakeDirectoryEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_OnProgress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipProgressEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipReader_get_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_OnProgress)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipReader_set_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipProgressEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipProgressEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_OnExtractionStart)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipExtractionStartEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipReader_get_OnExtractionStart(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_OnExtractionStart)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipReader_set_OnExtractionStart(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipExtractionStartEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipExtractionStartEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_OnExtractionFinished)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipExtractionFinishedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipReader_get_OnExtractionFinished(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_OnExtractionFinished)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipReader_set_OnExtractionFinished(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipExtractionFinishedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipExtractionFinishedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_OnUserActionNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipUserActionNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipReader_get_OnUserActionNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_OnUserActionNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipReader_set_OnUserActionNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipUserActionNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipUserActionNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_OnPasswordNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipPasswordNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipReader_get_OnPasswordNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_OnPasswordNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipReader_set_OnPasswordNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipPasswordNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipPasswordNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_OnPrivateKeyNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipPrivateKeyNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipReader_get_OnPrivateKeyNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_OnPrivateKeyNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipReader_set_OnPrivateKeyNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipPrivateKeyNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipPrivateKeyNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, get_OnArchiveError)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipArchiveErrorEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipReader_get_OnArchiveError(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, set_OnArchiveError)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipReader_set_OnArchiveError(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipArchiveErrorEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipArchiveErrorEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipReader, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipReader_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_Open, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, FileName_or_Stream, 0, 1)
	ZEND_ARG_INFO(0, ReadOnly)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_Close, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_Extract, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Entry_or_Entries_or_Mask, 0, 1)
	ZEND_ARG_INFO(0, OutputPath)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_ExtractContents, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Entry, TElZipArchiveDirectoryEntry, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_ValidateSignature, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Entry, TElZipArchiveDirectoryEntry, 1)
	ZEND_ARG_INFO(0, SignatureIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_ValidateDirectorySignature, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_CheckEntry, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Entry, TElZipArchiveDirectoryEntry, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_CheckArchive, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_DirectoryCompressed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_DirectoryCompressed, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_DirectoryEncrypted, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_DirectoryEncrypted, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_Directory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_ArchiveComment, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_ArchiveComment, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_SigningCertificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_EncryptingCertificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_IgnorePasswordCheck, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_IgnorePasswordCheck, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_RestoreAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_RestoreAttributes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_FilenamesCharset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_FilenamesCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_IgnoreArchiveErrors, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_IgnoreArchiveErrors, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_CaseSensitiveFilenames, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_CaseSensitiveFilenames, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_MimeType, 0, 0, 0)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_SFXCopyright, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_SFXCopyright, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_SFXEnabled, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_SFXEnabled, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_SFXTitle, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_SFXTitle, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_StubName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_StubName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_StubSource, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_StubSource, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()
#endif

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_FilenameOriginPreference, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_FilenameOriginPreference, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_FileSystemAdapter, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_FileSystemAdapter, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomFileSystemAdapter, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_CryptoProviderManager, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_CryptoProviderManager, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCryptoProviderManager, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_OnExtractionStreamNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_OnExtractionStreamNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_OnExtractionMakeDirectory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_OnExtractionMakeDirectory, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_OnProgress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_OnProgress, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_OnExtractionStart, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_OnExtractionStart, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_OnExtractionFinished, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_OnExtractionFinished, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_OnUserActionNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_OnUserActionNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_OnPasswordNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_OnPasswordNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_OnPrivateKeyNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_OnPrivateKeyNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_get_OnArchiveError, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader_set_OnArchiveError, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipReader___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipReader_methods[] = {
	PHP_ME(TElZipReader, Open, arginfo_TElZipReader_Open, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, Close, arginfo_TElZipReader_Close, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, Extract, arginfo_TElZipReader_Extract, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, ExtractContents, arginfo_TElZipReader_ExtractContents, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, ValidateSignature, arginfo_TElZipReader_ValidateSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, ValidateDirectorySignature, arginfo_TElZipReader_ValidateDirectorySignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, CheckEntry, arginfo_TElZipReader_CheckEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, CheckArchive, arginfo_TElZipReader_CheckArchive, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_DirectoryCompressed, arginfo_TElZipReader_get_DirectoryCompressed, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_DirectoryCompressed, arginfo_TElZipReader_set_DirectoryCompressed, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_DirectoryEncrypted, arginfo_TElZipReader_get_DirectoryEncrypted, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_DirectoryEncrypted, arginfo_TElZipReader_set_DirectoryEncrypted, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_Directory, arginfo_TElZipReader_get_Directory, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_Password, arginfo_TElZipReader_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_Password, arginfo_TElZipReader_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_ArchiveComment, arginfo_TElZipReader_get_ArchiveComment, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_ArchiveComment, arginfo_TElZipReader_set_ArchiveComment, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_SigningCertificates, arginfo_TElZipReader_get_SigningCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_EncryptingCertificates, arginfo_TElZipReader_get_EncryptingCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_IgnorePasswordCheck, arginfo_TElZipReader_get_IgnorePasswordCheck, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_IgnorePasswordCheck, arginfo_TElZipReader_set_IgnorePasswordCheck, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_RestoreAttributes, arginfo_TElZipReader_get_RestoreAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_RestoreAttributes, arginfo_TElZipReader_set_RestoreAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_FilenamesCharset, arginfo_TElZipReader_get_FilenamesCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_FilenamesCharset, arginfo_TElZipReader_set_FilenamesCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_IgnoreArchiveErrors, arginfo_TElZipReader_get_IgnoreArchiveErrors, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_IgnoreArchiveErrors, arginfo_TElZipReader_set_IgnoreArchiveErrors, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_CaseSensitiveFilenames, arginfo_TElZipReader_get_CaseSensitiveFilenames, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_CaseSensitiveFilenames, arginfo_TElZipReader_set_CaseSensitiveFilenames, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_MimeType, arginfo_TElZipReader_get_MimeType, ZEND_ACC_PUBLIC)
#ifdef SB_WINDOWS
	PHP_ME(TElZipReader, get_SFXCopyright, arginfo_TElZipReader_get_SFXCopyright, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_SFXCopyright, arginfo_TElZipReader_set_SFXCopyright, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_SFXEnabled, arginfo_TElZipReader_get_SFXEnabled, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_SFXEnabled, arginfo_TElZipReader_set_SFXEnabled, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_SFXTitle, arginfo_TElZipReader_get_SFXTitle, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_SFXTitle, arginfo_TElZipReader_set_SFXTitle, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_StubName, arginfo_TElZipReader_get_StubName, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_StubName, arginfo_TElZipReader_set_StubName, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_StubSource, arginfo_TElZipReader_get_StubSource, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_StubSource, arginfo_TElZipReader_set_StubSource, ZEND_ACC_PUBLIC)
#endif
	PHP_ME(TElZipReader, get_FilenameOriginPreference, arginfo_TElZipReader_get_FilenameOriginPreference, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_FilenameOriginPreference, arginfo_TElZipReader_set_FilenameOriginPreference, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_FileSystemAdapter, arginfo_TElZipReader_get_FileSystemAdapter, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_FileSystemAdapter, arginfo_TElZipReader_set_FileSystemAdapter, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_CryptoProviderManager, arginfo_TElZipReader_get_CryptoProviderManager, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_CryptoProviderManager, arginfo_TElZipReader_set_CryptoProviderManager, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_OnExtractionStreamNeeded, arginfo_TElZipReader_get_OnExtractionStreamNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_OnExtractionStreamNeeded, arginfo_TElZipReader_set_OnExtractionStreamNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_OnExtractionMakeDirectory, arginfo_TElZipReader_get_OnExtractionMakeDirectory, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_OnExtractionMakeDirectory, arginfo_TElZipReader_set_OnExtractionMakeDirectory, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_OnProgress, arginfo_TElZipReader_get_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_OnProgress, arginfo_TElZipReader_set_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_OnExtractionStart, arginfo_TElZipReader_get_OnExtractionStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_OnExtractionStart, arginfo_TElZipReader_set_OnExtractionStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_OnExtractionFinished, arginfo_TElZipReader_get_OnExtractionFinished, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_OnExtractionFinished, arginfo_TElZipReader_set_OnExtractionFinished, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_OnUserActionNeeded, arginfo_TElZipReader_get_OnUserActionNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_OnUserActionNeeded, arginfo_TElZipReader_set_OnUserActionNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_OnPasswordNeeded, arginfo_TElZipReader_get_OnPasswordNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_OnPasswordNeeded, arginfo_TElZipReader_set_OnPasswordNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_OnPrivateKeyNeeded, arginfo_TElZipReader_get_OnPrivateKeyNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_OnPrivateKeyNeeded, arginfo_TElZipReader_set_OnPrivateKeyNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, get_OnArchiveError, arginfo_TElZipReader_get_OnArchiveError, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, set_OnArchiveError, arginfo_TElZipReader_set_OnArchiveError, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipReader, __construct, arginfo_TElZipReader___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipReader(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipReader_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipReader", TElZipReader_methods);
	if (NULL == TElBaseArchive_ce_ptr)
		Register_TElBaseArchive(TSRMLS_C);
	TElZipReader_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElBaseArchive_ce_ptr);
}

zend_class_entry *TElZipWriter_ce_ptr = NULL;

SB_PHP_METHOD(TElZipWriter, CreateArchive)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipWriter_CreateArchive(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, Add)
{
	char *sFileName;
	char *sPath;
	sb_str_size sFileName_len;
	sb_str_size sPath_len;
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuf;
	TSBZipAddEntryResultRaw fAddResultRaw = 0;
	zval *oParent;
	zval *oStream;
	zval *zaBuf;
	zval *zfAddResult;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!s", &oParent, TElZipArchiveDirectoryEntry_ce_ptr, &sPath, &sPath_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWriter_Add(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParent TSRMLS_CC), sPath, (int32_t)sPath_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!sz", &oParent, TElZipArchiveDirectoryEntry_ce_ptr, &sPath, &sPath_len, &zfAddResult) == SUCCESS) && Z_ISREF_P(zfAddResult) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zfAddResult))))
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWriter_Add_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParent TSRMLS_CC), sPath, (int32_t)sPath_len, &fAddResultRaw, &hoOutResult) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zfAddResult), (sb_zend_long)fAddResultRaw);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sz", &sPath, &sPath_len, &zfAddResult) == SUCCESS) && Z_ISREF_P(zfAddResult) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zfAddResult))))
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWriter_Add_2(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, &fAddResultRaw, &hoOutResult) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zfAddResult), (sb_zend_long)fAddResultRaw);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWriter_Add_3(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oParent, TElZipArchiveDirectoryEntry_ce_ptr, &oStream, TStream_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWriter_Add_4(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParent TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWriter_Add_5(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!s", &oParent, TElZipArchiveDirectoryEntry_ce_ptr, &oStream, TStream_ce_ptr, &sFileName, &sFileName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWriter_Add_6(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParent TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), sFileName, (int32_t)sFileName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!s", &oStream, TStream_ce_ptr, &sFileName, &sFileName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWriter_Add_7(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), sFileName, (int32_t)sFileName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zlls", &oParent, TElZipArchiveDirectoryEntry_ce_ptr, &zaBuf, &l4StartIndex, &l4Count, &sFileName, &sFileName_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuf) || SB_IS_ARRAY_TYPE_RP(zaBuf) || SB_IS_NULL_TYPE_RP(zaBuf)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuf, &aiBuf TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElZipWriter_Add_8(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParent TSRMLS_CC), aiBuf.data, aiBuf.len, (int32_t)l4StartIndex, (int32_t)l4Count, sFileName, (int32_t)sFileName_len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuf);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlls", &zaBuf, &l4StartIndex, &l4Count, &sFileName, &sFileName_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuf) || SB_IS_ARRAY_TYPE_RP(zaBuf) || SB_IS_NULL_TYPE_RP(zaBuf)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuf, &aiBuf TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElZipWriter_Add_9(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuf.data, aiBuf.len, (int32_t)l4StartIndex, (int32_t)l4Count, sFileName, (int32_t)sFileName_len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuf);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElZipArchiveDirectoryEntry, string) or (\\TElZipArchiveDirectoryEntry, string, &integer) or (string, &integer) or (string) or (\\TElZipArchiveDirectoryEntry, \\TStream) or (\\TStream) or (\\TElZipArchiveDirectoryEntry, \\TStream, string) or (\\TStream, string) or (\\TElZipArchiveDirectoryEntry, array of byte|string|NULL, integer, integer, string) or (array of byte|string|NULL, integer, integer, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, AddDirContents)
{
	char *sMask;
	char *sPath;
	sb_str_size sMask_len;
	sb_str_size sPath_len;
	zval *oParent;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		SBCheckError(TElZipWriter_AddDirContents(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!s", &oParent, TElZipArchiveDirectoryEntry_ce_ptr, &sPath, &sPath_len) == SUCCESS)
	{
		SBCheckError(TElZipWriter_AddDirContents_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParent TSRMLS_CC), sPath, (int32_t)sPath_len) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sPath, &sPath_len, &sMask, &sMask_len) == SUCCESS)
	{
		SBCheckError(TElZipWriter_AddDirContents_2(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, sMask, (int32_t)sMask_len) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!ss", &oParent, TElZipArchiveDirectoryEntry_ce_ptr, &sPath, &sPath_len, &sMask, &sMask_len) == SUCCESS)
	{
		SBCheckError(TElZipWriter_AddDirContents_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParent TSRMLS_CC), sPath, (int32_t)sPath_len, sMask, (int32_t)sMask_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (\\TElZipArchiveDirectoryEntry, string) or (string, string) or (\\TElZipArchiveDirectoryEntry, string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, MakeDir)
{
	char *sPath;
	sb_str_size sPath_len;
	zval *oParent;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWriter_MakeDir(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!s", &oParent, TElZipArchiveDirectoryEntry_ce_ptr, &sPath, &sPath_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWriter_MakeDir_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParent TSRMLS_CC), sPath, (int32_t)sPath_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipArchiveDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (\\TElZipArchiveDirectoryEntry, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, Remove)
{
	char *sMask;
	sb_str_size sMask_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sMask, &sMask_len) == SUCCESS)
	{
		SBCheckError(TElZipWriter_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), sMask, (int32_t)sMask_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, BeginCompression)
{
	char *sDestination;
	sb_str_size sDestination_len;
	zval *oDestination;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDestination, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElZipWriter_BeginCompression(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDestination TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sDestination, &sDestination_len) == SUCCESS)
	{
		SBCheckError(TElZipWriter_BeginCompression_1(SBGetObjectHandle(getThis() TSRMLS_CC), sDestination, (int32_t)sDestination_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream) or (string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, UpdateCompression)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipWriter_UpdateCompression(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, EndCompression)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipWriter_EndCompression(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, Compress)
{
	char *sDestination;
	sb_str_size sDestination_len;
	zval *oDestination;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDestination, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElZipWriter_Compress(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDestination TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sDestination, &sDestination_len) == SUCCESS)
	{
		SBCheckError(TElZipWriter_Compress_1(SBGetObjectHandle(getThis() TSRMLS_CC), sDestination, (int32_t)sDestination_len) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipWriter_Compress_2(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream) or (string) or ()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, Close)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZipWriter_Close(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, get_ReplaceMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBArcReplaceModeRaw fOutResultRaw = 0;
		SBCheckError(TElZipWriter_get_ReplaceMode(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, set_ReplaceMode)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElZipWriter_set_ReplaceMode(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBArcReplaceModeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, get_NewArchive)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipWriter_get_NewArchive(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, get_CompressionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipWriter_get_CompressionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, set_CompressionAlgorithm)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipWriter_set_CompressionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, get_CompressionLevel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipWriter_get_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, set_CompressionLevel)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipWriter_set_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, get_Encrypt)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipWriter_get_Encrypt(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, set_Encrypt)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipWriter_set_Encrypt(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, get_StrongEncryption)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipWriter_get_StrongEncryption(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, set_StrongEncryption)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipWriter_set_StrongEncryption(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, get_WinZipEncryption)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipWriter_get_WinZipEncryption(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, set_WinZipEncryption)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipWriter_set_WinZipEncryption(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, get_WinZipAesKeySize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElZipWriter_get_WinZipAesKeySize(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, set_WinZipAesKeySize)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElZipWriter_set_WinZipAesKeySize(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, get_StrongEncryptionInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWriter_get_StrongEncryptionInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElZipStrongEncryptionInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, get_UseUTF8Filenames)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZipWriter_get_UseUTF8Filenames(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, set_UseUTF8Filenames)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZipWriter_set_UseUTF8Filenames(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, get_MimeType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZipWriter_get_MimeType(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1612485505, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, set_MimeType)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZipWriter_set_MimeType(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, get_OnCompressionStreamNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipCompressionStreamNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipWriter_get_OnCompressionStreamNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, set_OnCompressionStreamNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipWriter_set_OnCompressionStreamNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipCompressionStreamNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipCompressionStreamNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, get_OnCompressionStart)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipCompressionStartEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipWriter_get_OnCompressionStart(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, set_OnCompressionStart)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipWriter_set_OnCompressionStart(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipCompressionStartEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipCompressionStartEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, get_OnCompressionFinished)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipCompressionFinishedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipWriter_get_OnCompressionFinished(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, set_OnCompressionFinished)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipWriter_set_OnCompressionFinished(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipCompressionFinishedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipCompressionFinishedEvent|callable|NULL)" TSRMLS_CC);
	}
}

#ifdef SB_WINDOWS
SB_PHP_METHOD(TElZipWriter, get_OnGetStubStream)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZIPGetStubStreamEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZipWriter_get_OnGetStubStream(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZipWriter, set_OnGetStubStream)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZipWriter_set_OnGetStubStream(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZIPGetStubStreamEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZIPGetStubStreamEvent|callable|NULL)" TSRMLS_CC);
	}
}
#endif

SB_PHP_METHOD(TElZipWriter, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZipWriter_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_CreateArchive, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_Add, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Parent_or_Path_or_Stream_or_Buf, 0, 1)
	ZEND_ARG_TYPE_INFO(1, Path_or_AddResult_or_Stream_or_FileName_or_Buf_or_StartIndex, 0, 1)
	ZEND_ARG_INFO(1, AddResult_or_FileName_or_StartIndex_or_Count)
	ZEND_ARG_INFO(0, Count_or_FileName)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_AddDirContents, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Path_or_Parent, 0, 1)
	ZEND_ARG_INFO(0, Path_or_Mask)
	ZEND_ARG_INFO(0, Mask)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_MakeDir, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Path_or_Parent, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, Mask)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_BeginCompression, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Destination, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_UpdateCompression, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_EndCompression, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_Compress, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, Destination, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_Close, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_ReplaceMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_set_ReplaceMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_NewArchive, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_CompressionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_set_CompressionAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_CompressionLevel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_set_CompressionLevel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_Encrypt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_set_Encrypt, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_StrongEncryption, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_set_StrongEncryption, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_WinZipEncryption, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_set_WinZipEncryption, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_WinZipAesKeySize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_set_WinZipAesKeySize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_StrongEncryptionInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_UseUTF8Filenames, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_set_UseUTF8Filenames, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_MimeType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_set_MimeType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_OnCompressionStreamNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_set_OnCompressionStreamNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_OnCompressionStart, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_set_OnCompressionStart, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_OnCompressionFinished, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_set_OnCompressionFinished, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_get_OnGetStubStream, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter_set_OnGetStubStream, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()
#endif

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZipWriter___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElZipWriter_methods[] = {
	PHP_ME(TElZipWriter, CreateArchive, arginfo_TElZipWriter_CreateArchive, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, Add, arginfo_TElZipWriter_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, AddDirContents, arginfo_TElZipWriter_AddDirContents, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, MakeDir, arginfo_TElZipWriter_MakeDir, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, Remove, arginfo_TElZipWriter_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, BeginCompression, arginfo_TElZipWriter_BeginCompression, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, UpdateCompression, arginfo_TElZipWriter_UpdateCompression, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, EndCompression, arginfo_TElZipWriter_EndCompression, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, Compress, arginfo_TElZipWriter_Compress, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, Close, arginfo_TElZipWriter_Close, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, get_ReplaceMode, arginfo_TElZipWriter_get_ReplaceMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, set_ReplaceMode, arginfo_TElZipWriter_set_ReplaceMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, get_NewArchive, arginfo_TElZipWriter_get_NewArchive, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, get_CompressionAlgorithm, arginfo_TElZipWriter_get_CompressionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, set_CompressionAlgorithm, arginfo_TElZipWriter_set_CompressionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, get_CompressionLevel, arginfo_TElZipWriter_get_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, set_CompressionLevel, arginfo_TElZipWriter_set_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, get_Encrypt, arginfo_TElZipWriter_get_Encrypt, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, set_Encrypt, arginfo_TElZipWriter_set_Encrypt, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, get_StrongEncryption, arginfo_TElZipWriter_get_StrongEncryption, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, set_StrongEncryption, arginfo_TElZipWriter_set_StrongEncryption, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, get_WinZipEncryption, arginfo_TElZipWriter_get_WinZipEncryption, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, set_WinZipEncryption, arginfo_TElZipWriter_set_WinZipEncryption, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, get_WinZipAesKeySize, arginfo_TElZipWriter_get_WinZipAesKeySize, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, set_WinZipAesKeySize, arginfo_TElZipWriter_set_WinZipAesKeySize, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, get_StrongEncryptionInfo, arginfo_TElZipWriter_get_StrongEncryptionInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, get_UseUTF8Filenames, arginfo_TElZipWriter_get_UseUTF8Filenames, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, set_UseUTF8Filenames, arginfo_TElZipWriter_set_UseUTF8Filenames, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, get_MimeType, arginfo_TElZipWriter_get_MimeType, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, set_MimeType, arginfo_TElZipWriter_set_MimeType, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, get_OnCompressionStreamNeeded, arginfo_TElZipWriter_get_OnCompressionStreamNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, set_OnCompressionStreamNeeded, arginfo_TElZipWriter_set_OnCompressionStreamNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, get_OnCompressionStart, arginfo_TElZipWriter_get_OnCompressionStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, set_OnCompressionStart, arginfo_TElZipWriter_set_OnCompressionStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, get_OnCompressionFinished, arginfo_TElZipWriter_get_OnCompressionFinished, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, set_OnCompressionFinished, arginfo_TElZipWriter_set_OnCompressionFinished, ZEND_ACC_PUBLIC)
#ifdef SB_WINDOWS
	PHP_ME(TElZipWriter, get_OnGetStubStream, arginfo_TElZipWriter_get_OnGetStubStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElZipWriter, set_OnGetStubStream, arginfo_TElZipWriter_set_OnGetStubStream, ZEND_ACC_PUBLIC)
#endif
	PHP_ME(TElZipWriter, __construct, arginfo_TElZipWriter___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZipWriter(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZipWriter_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZipWriter", TElZipWriter_methods);
	if (NULL == TElZipReader_ce_ptr)
		Register_TElZipReader(TSRMLS_C);
	TElZipWriter_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElZipReader_ce_ptr);
}

void Register_SBArcZip_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBArcZip, ERROR_FACILITY_ZIP, SB_ERROR_FACILITY_ZIP, SB_ERROR_FACILITY_ZIP);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, ERROR_ZIP_ERROR_FLAG, SB_ERROR_ZIP_ERROR_FLAG, SB_ERROR_ZIP_ERROR_FLAG);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_BASE, SB_ZIP_ERROR_BASE, SB_ZIP_ERROR_BASE);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INTERNAL_ERROR, SB_ZIP_ERROR_INTERNAL_ERROR, SB_ZIP_ERROR_INTERNAL_ERROR);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_NO_OUTPUT_STREAM, SB_ZIP_ERROR_NO_OUTPUT_STREAM, SB_ZIP_ERROR_NO_OUTPUT_STREAM);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INVALID_PROPERTY_VALUE, SB_ZIP_ERROR_INVALID_PROPERTY_VALUE, SB_ZIP_ERROR_INVALID_PROPERTY_VALUE);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_ENC_METHOD_NOT_SUPPORTED, SB_ZIP_ERROR_ENC_METHOD_NOT_SUPPORTED, SB_ZIP_ERROR_ENC_METHOD_NOT_SUPPORTED);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_COMP_ALG_NOT_SUPPORTED, SB_ZIP_ERROR_COMP_ALG_NOT_SUPPORTED, SB_ZIP_ERROR_COMP_ALG_NOT_SUPPORTED);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INVALID_STRUCTURE, SB_ZIP_ERROR_INVALID_STRUCTURE, SB_ZIP_ERROR_INVALID_STRUCTURE);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_NO_INPUT, SB_ZIP_ERROR_NO_INPUT, SB_ZIP_ERROR_NO_INPUT);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INVALID_PATH, SB_ZIP_ERROR_INVALID_PATH, SB_ZIP_ERROR_INVALID_PATH);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INVALID_PASSWORD, SB_ZIP_ERROR_INVALID_PASSWORD, SB_ZIP_ERROR_INVALID_PASSWORD);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INVALID_RECIPIENT_KEY, SB_ZIP_ERROR_INVALID_RECIPIENT_KEY, SB_ZIP_ERROR_INVALID_RECIPIENT_KEY);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_NO_ENC_INFO, SB_ZIP_ERROR_NO_ENC_INFO, SB_ZIP_ERROR_NO_ENC_INFO);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_NO_DEC_PASSWORD, SB_ZIP_ERROR_NO_DEC_PASSWORD, SB_ZIP_ERROR_NO_DEC_PASSWORD);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_NO_DEC_CERT, SB_ZIP_ERROR_NO_DEC_CERT, SB_ZIP_ERROR_NO_DEC_CERT);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INV_KEY_SIZE, SB_ZIP_ERROR_INV_KEY_SIZE, SB_ZIP_ERROR_INV_KEY_SIZE);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_DEC_FAILED, SB_ZIP_ERROR_DEC_FAILED, SB_ZIP_ERROR_DEC_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INVALID_PARAMS, SB_ZIP_ERROR_INVALID_PARAMS, SB_ZIP_ERROR_INVALID_PARAMS);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INVALID_ACTION, SB_ZIP_ERROR_INVALID_ACTION, SB_ZIP_ERROR_INVALID_ACTION);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_FILE_EXISTS, SB_ZIP_ERROR_FILE_EXISTS, SB_ZIP_ERROR_FILE_EXISTS);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_CANT_CREATE_FILE, SB_ZIP_ERROR_CANT_CREATE_FILE, SB_ZIP_ERROR_CANT_CREATE_FILE);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INVALID_MAC, SB_ZIP_ERROR_INVALID_MAC, SB_ZIP_ERROR_INVALID_MAC);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_NO_SIGNER_CERT, SB_ZIP_ERROR_NO_SIGNER_CERT, SB_ZIP_ERROR_NO_SIGNER_CERT);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INVALID_INDEX, SB_ZIP_ERROR_INVALID_INDEX, SB_ZIP_ERROR_INVALID_INDEX);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_DIRECTORY_EXISTS, SB_ZIP_ERROR_DIRECTORY_EXISTS, SB_ZIP_ERROR_DIRECTORY_EXISTS);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_ARCHIVE_NOT_OPENED, SB_ZIP_ERROR_ARCHIVE_NOT_OPENED, SB_ZIP_ERROR_ARCHIVE_NOT_OPENED);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_FILE_ALREADY_IN_ARCHIVE, SB_ZIP_ERROR_FILE_ALREADY_IN_ARCHIVE, SB_ZIP_ERROR_FILE_ALREADY_IN_ARCHIVE);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_PARENT_NOT_DIRECTORY, SB_ZIP_ERROR_PARENT_NOT_DIRECTORY, SB_ZIP_ERROR_PARENT_NOT_DIRECTORY);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INVALID_METHOD_SEQUENCE, SB_ZIP_ERROR_INVALID_METHOD_SEQUENCE, SB_ZIP_ERROR_INVALID_METHOD_SEQUENCE);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_NO_OLD_ENC_IN_FIPS, SB_ZIP_ERROR_NO_OLD_ENC_IN_FIPS, SB_ZIP_ERROR_NO_OLD_ENC_IN_FIPS);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INVALID_PARAMETER, SB_ZIP_ERROR_INVALID_PARAMETER, SB_ZIP_ERROR_INVALID_PARAMETER);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_CANT_ADD_MIME_ENTRY, SB_ZIP_ERROR_CANT_ADD_MIME_ENTRY, SB_ZIP_ERROR_CANT_ADD_MIME_ENTRY);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INVALID_SIGNATURE_DATA, SB_ZIP_ERROR_INVALID_SIGNATURE_DATA, SB_ZIP_ERROR_INVALID_SIGNATURE_DATA);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_INVALID_ENCRYPTED_DATA, SB_ZIP_ERROR_INVALID_ENCRYPTED_DATA, SB_ZIP_ERROR_INVALID_ENCRYPTED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, SB_ZIP_ERROR_OPERATION_CANCELLED, SB_ZIP_ERROR_OPERATION_CANCELLED, SB_ZIP_ERROR_OPERATION_CANCELLED);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, ZIP_EVENT_EXTRACTION_FAILED, SB_ZIP_EVENT_EXTRACTION_FAILED, SB_ZIP_EVENT_EXTRACTION_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, ZIP_EVENT_CRC_MISMATCH, SB_ZIP_EVENT_CRC_MISMATCH, SB_ZIP_EVENT_CRC_MISMATCH);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, ZIP_EVENT_INVALID_PASSWORD, SB_ZIP_EVENT_INVALID_PASSWORD, SB_ZIP_EVENT_INVALID_PASSWORD);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, ZIP_EVENT_FILE_ALREADY_EXISTS, SB_ZIP_EVENT_FILE_ALREADY_EXISTS, SB_ZIP_EVENT_FILE_ALREADY_EXISTS);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, ZIP_EVENT_CANNOT_CREATE_FILE, SB_ZIP_EVENT_CANNOT_CREATE_FILE, SB_ZIP_EVENT_CANNOT_CREATE_FILE);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, ZIP_EVENT_DIR_ALREADY_EXISTS, SB_ZIP_EVENT_DIR_ALREADY_EXISTS, SB_ZIP_EVENT_DIR_ALREADY_EXISTS);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, ZIP_EVENT_FILE_ALREADY_ADDED, SB_ZIP_EVENT_FILE_ALREADY_ADDED, SB_ZIP_EVENT_FILE_ALREADY_ADDED);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, ZIP_ACTION_IGNORE, SB_ZIP_ACTION_IGNORE, SB_ZIP_ACTION_IGNORE);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, ZIP_ACTION_ABORT, SB_ZIP_ACTION_ABORT, SB_ZIP_ACTION_ABORT);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, ZIP_ACTION_RETRY, SB_ZIP_ACTION_RETRY, SB_ZIP_ACTION_RETRY);
	SB_REGISTER_LONG_CONSTANT(SBArcZip, ZIP_ACTION_SKIP, SB_ZIP_ACTION_SKIP, SB_ZIP_ACTION_SKIP);
}

void Register_SBArcZip_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
#ifdef SB_WINDOWS
	INIT_CLASS_ENTRY(ce, "TSBZIPStubSource", NULL);
	TSBZIPStubSource_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBZIPStubSource_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPStubSource_ce_ptr, "ssStream", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPStubSource_ce_ptr, "ssFile", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPStubSource_ce_ptr, "ssResource", 2)
	
#endif
	INIT_CLASS_ENTRY(ce, "TSBZipAddEntryResult", NULL);
	TSBZipAddEntryResult_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBZipAddEntryResult_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBZipAddEntryResult_ce_ptr, "aerAdded", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBZipAddEntryResult_ce_ptr, "aerReplaced", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBZipAddEntryResult_ce_ptr, "aerUpdated", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBZipAddEntryResult_ce_ptr, "aerSkipped", 3)
	
	INIT_CLASS_ENTRY(ce, "TSBZipUnixFileType", NULL);
	TSBZipUnixFileType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBZipUnixFileType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBZipUnixFileType_ce_ptr, "uftNamedPipe", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBZipUnixFileType_ce_ptr, "uftCharacterSpecial", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBZipUnixFileType_ce_ptr, "uftDirectory", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBZipUnixFileType_ce_ptr, "uftBlockSpecial", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBZipUnixFileType_ce_ptr, "uftRegularFile", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBZipUnixFileType_ce_ptr, "uftSymbolicLink", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBZipUnixFileType_ce_ptr, "uftSocket", 6)
	
	INIT_CLASS_ENTRY(ce, "TSBZipFilenameOriginPreference", NULL);
	TSBZipFilenameOriginPreference_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBZipFilenameOriginPreference_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBZipFilenameOriginPreference_ce_ptr, "fopHeader", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBZipFilenameOriginPreference_ce_ptr, "fopExtension", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBZipFilenameOriginPreference_ce_ptr, "fopAuto", 2)
}

void Register_SBArcZip_Aliases(TSRMLS_D)
{
	if (NULL == TElZipDosFileAttributes_ce_ptr)
		Register_TElZipDosFileAttributes(TSRMLS_C);
	zend_register_class_alias("ElZipDosFileAttributes", TElZipDosFileAttributes_ce_ptr);
	if (NULL == TElZipStrongEncryptionInfo_ce_ptr)
		Register_TElZipStrongEncryptionInfo(TSRMLS_C);
	zend_register_class_alias("ElZipStrongEncryptionInfo", TElZipStrongEncryptionInfo_ce_ptr);
	if (NULL == TElZipStrongEncryptionSignatureInfo_ce_ptr)
		Register_TElZipStrongEncryptionSignatureInfo(TSRMLS_C);
	zend_register_class_alias("ElZipStrongEncryptionSignatureInfo", TElZipStrongEncryptionSignatureInfo_ce_ptr);
	if (NULL == TElZipArchiveDirectoryEntry_ce_ptr)
		Register_TElZipArchiveDirectoryEntry(TSRMLS_C);
	zend_register_class_alias("ElZipArchiveDirectoryEntry", TElZipArchiveDirectoryEntry_ce_ptr);
	if (NULL == TElZipProcessingUnit_ce_ptr)
		Register_TElZipProcessingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipProcessingUnit", TElZipProcessingUnit_ce_ptr);
	if (NULL == TElZipStoredProcessingUnit_ce_ptr)
		Register_TElZipStoredProcessingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipStoredProcessingUnit", TElZipStoredProcessingUnit_ce_ptr);
	if (NULL == TElZipDeflateDecompressingUnit_ce_ptr)
		Register_TElZipDeflateDecompressingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipDeflateDecompressingUnit", TElZipDeflateDecompressingUnit_ce_ptr);
	if (NULL == TElZipDeflateCompressingUnit_ce_ptr)
		Register_TElZipDeflateCompressingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipDeflateCompressingUnit", TElZipDeflateCompressingUnit_ce_ptr);
#ifdef SB_WINDOWS
	if (NULL == TElZipLzmaDecompressingUnit_ce_ptr)
		Register_TElZipLzmaDecompressingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipLzmaDecompressingUnit", TElZipLzmaDecompressingUnit_ce_ptr);
	if (NULL == TElZipLzmaCompressingUnit_ce_ptr)
		Register_TElZipLzmaCompressingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipLzmaCompressingUnit", TElZipLzmaCompressingUnit_ce_ptr);
#endif
	if (NULL == TElZipBZip2DecompressingUnit_ce_ptr)
		Register_TElZipBZip2DecompressingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipBZip2DecompressingUnit", TElZipBZip2DecompressingUnit_ce_ptr);
	if (NULL == TElZipBZip2CompressingUnit_ce_ptr)
		Register_TElZipBZip2CompressingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipBZip2CompressingUnit", TElZipBZip2CompressingUnit_ce_ptr);
	if (NULL == TElZipOldStyleEncryptingUnit_ce_ptr)
		Register_TElZipOldStyleEncryptingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipOldStyleEncryptingUnit", TElZipOldStyleEncryptingUnit_ce_ptr);
	if (NULL == TElZipOldStyleDecryptingUnit_ce_ptr)
		Register_TElZipOldStyleDecryptingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipOldStyleDecryptingUnit", TElZipOldStyleDecryptingUnit_ce_ptr);
	if (NULL == TElZipStrongEncryptionBaseUnit_ce_ptr)
		Register_TElZipStrongEncryptionBaseUnit(TSRMLS_C);
	zend_register_class_alias("ElZipStrongEncryptionBaseUnit", TElZipStrongEncryptionBaseUnit_ce_ptr);
	if (NULL == TElZipStrongEncryptionEncryptingUnit_ce_ptr)
		Register_TElZipStrongEncryptionEncryptingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipStrongEncryptionEncryptingUnit", TElZipStrongEncryptionEncryptingUnit_ce_ptr);
	if (NULL == TElZipStrongEncryptionDecryptingUnit_ce_ptr)
		Register_TElZipStrongEncryptionDecryptingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipStrongEncryptionDecryptingUnit", TElZipStrongEncryptionDecryptingUnit_ce_ptr);
	if (NULL == TElZipStrongEncryptionHashingUnit_ce_ptr)
		Register_TElZipStrongEncryptionHashingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipStrongEncryptionHashingUnit", TElZipStrongEncryptionHashingUnit_ce_ptr);
	if (NULL == TElZipWinZipAesBaseUnit_ce_ptr)
		Register_TElZipWinZipAesBaseUnit(TSRMLS_C);
	zend_register_class_alias("ElZipWinZipAesBaseUnit", TElZipWinZipAesBaseUnit_ce_ptr);
	if (NULL == TElZipWinZipAesDecryptingUnit_ce_ptr)
		Register_TElZipWinZipAesDecryptingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipWinZipAesDecryptingUnit", TElZipWinZipAesDecryptingUnit_ce_ptr);
	if (NULL == TElZipWinZipAesEncryptingUnit_ce_ptr)
		Register_TElZipWinZipAesEncryptingUnit(TSRMLS_C);
	zend_register_class_alias("ElZipWinZipAesEncryptingUnit", TElZipWinZipAesEncryptingUnit_ce_ptr);
	if (NULL == TElZipReader_ce_ptr)
		Register_TElZipReader(TSRMLS_C);
	zend_register_class_alias("ElZipReader", TElZipReader_ce_ptr);
	if (NULL == TElZipWriter_ce_ptr)
		Register_TElZipWriter(TSRMLS_C);
	zend_register_class_alias("ElZipWriter", TElZipWriter_ce_ptr);
}
