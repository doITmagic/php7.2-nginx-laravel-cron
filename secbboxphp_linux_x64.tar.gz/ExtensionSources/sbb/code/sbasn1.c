#include "sbasn1.h"

zend_class_entry *asn1TagType_ce_ptr = NULL;

void SB_CALLBACK asn1tCallBackFuncRaw(void * _ObjectData, void * Stream, asn1TagTypeRaw TagType, int8_t TagConstrained, void * Tag, int32_t TagSize, int32_t Size, void * Data, int32_t BitRest, int8_t * OutResult)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_INIT_PARAMS(8);
	zval * zStream;
	zval * zTagType;
	zval * zTagConstrained;
	zval * zTag;
	zval * zTagSize;
	zval * zSize;
	zval * zData;
	zval * zBitRest;
	SB_EVENT_DECL_RETVAL_PTR(pzOutResult);
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zStream, 0);
	SBInitPointerObject(zStream, Stream TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTagType, 1);
	ZVAL_LONG(zTagType, (sb_zend_long)TagType);
	SB_EVENT_INIT_ZVAL(zTagConstrained, 2);
	ZVAL_BOOL(zTagConstrained, (zend_bool)TagConstrained);
	SB_EVENT_INIT_ZVAL(zTag, 3);
	SBInitPointerObject(zTag, Tag TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTagSize, 4);
	ZVAL_LONG(zTagSize, (sb_zend_long)TagSize);
	SB_EVENT_INIT_ZVAL(zSize, 5);
	ZVAL_LONG(zSize, (sb_zend_long)Size);
	SB_EVENT_INIT_ZVAL(zData, 6);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBitRest, 7);
	ZVAL_LONG(zBitRest, (sb_zend_long)BitRest);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(pzOutResult), 8, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zStream);
	SB_EVENT_CLEAR_ZVAL(zTagType);
	SB_EVENT_CLEAR_ZVAL(zTagConstrained);
	SB_EVENT_CLEAR_ZVAL(zTag);
	SB_EVENT_CLEAR_ZVAL(zTagSize);
	SB_EVENT_CLEAR_ZVAL(zSize);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zBitRest);
	if (pzOutResult)
	{
		convert_to_boolean(pzOutResult);
		*OutResult = (int8_t)SB_BVAL_P(pzOutResult);
		SB_EVENT_CLEAR_ZVAL(pzOutResult);
	}
}

void SB_CALLBACK TSBASN1ReadEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t * Size)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zBuffer;
	zval * zSize;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 1);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zSize, 2);
	ZVAL_LONG(Z_REFVAL_P(zSize), (sb_zend_long)*Size);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	convert_to_long(Z_REFVAL_P(zSize));
	*Size = (int32_t)Z_LVAL_P(Z_REFVAL_P(zSize));
	SB_EVENT_CLEAR_ZVAL(zSize);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBASN1TagEventRaw(void * _ObjectData, TObjectHandle Sender, asn1TagTypeRaw TagType, int8_t TagConstrained, uint32_t Tag, int64_t Size, void * Data, int32_t BitRest, int8_t * Valid)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(8);
	zval * zSender;
	zval * zTagType;
	zval * zTagConstrained;
	zval * zTag;
	zval * zSize;
	zval * zData;
	zval * zBitRest;
	zval * zValid;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTagType, 1);
	ZVAL_LONG(zTagType, (sb_zend_long)TagType);
	SB_EVENT_INIT_ZVAL(zTagConstrained, 2);
	ZVAL_BOOL(zTagConstrained, (zend_bool)TagConstrained);
	SB_EVENT_INIT_ZVAL(zTag, 3);
	ZVAL_LONG(zTag, (sb_zend_long)Tag);
	SB_EVENT_INIT_ZVAL(zSize, 4);
	ZVAL_LONG(zSize, (sb_zend_long)Size);
	SB_EVENT_INIT_ZVAL(zData, 5);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBitRest, 6);
	ZVAL_LONG(zBitRest, (sb_zend_long)BitRest);
	SB_EVENT_INIT_ZVAL_REF(zValid, 7);
	ZVAL_BOOL(Z_REFVAL_P(zValid), (zend_bool)*Valid);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 8, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zTagType);
	SB_EVENT_CLEAR_ZVAL(zTagConstrained);
	SB_EVENT_CLEAR_ZVAL(zTag);
	SB_EVENT_CLEAR_ZVAL(zSize);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zBitRest);
	convert_to_boolean(Z_REFVAL_P(zValid));
	*Valid = (int8_t)SB_BVAL_P(Z_REFVAL_P(zValid));
	SB_EVENT_CLEAR_ZVAL(zValid);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBASN1TagHeaderEventRaw(void * _ObjectData, TObjectHandle Sender, uint8_t TagID, int64_t TagLen, int32_t HeaderLen, int8_t UndefLen)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zTagID;
	zval * zTagLen;
	zval * zHeaderLen;
	zval * zUndefLen;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTagID, 1);
	ZVAL_LONG(zTagID, (sb_zend_long)TagID);
	SB_EVENT_INIT_ZVAL(zTagLen, 2);
	ZVAL_LONG(zTagLen, (sb_zend_long)TagLen);
	SB_EVENT_INIT_ZVAL(zHeaderLen, 3);
	ZVAL_LONG(zHeaderLen, (sb_zend_long)HeaderLen);
	SB_EVENT_INIT_ZVAL(zUndefLen, 4);
	ZVAL_BOOL(zUndefLen, (zend_bool)UndefLen);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zTagID);
	SB_EVENT_CLEAR_ZVAL(zTagLen);
	SB_EVENT_CLEAR_ZVAL(zHeaderLen);
	SB_EVENT_CLEAR_ZVAL(zUndefLen);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBASN1DataAvailableEventRaw(void * _ObjectData, TObjectHandle Sender, uint8_t TagID, int64_t DataLen, int8_t * ReturnData, TObjectHandle * UserData)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zTagID;
	zval * zDataLen;
	zval * zReturnData;
	zval * zUserData;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTagID, 1);
	ZVAL_LONG(zTagID, (sb_zend_long)TagID);
	SB_EVENT_INIT_ZVAL(zDataLen, 2);
	ZVAL_LONG(zDataLen, (sb_zend_long)DataLen);
	SB_EVENT_INIT_ZVAL_REF(zReturnData, 3);
	ZVAL_BOOL(Z_REFVAL_P(zReturnData), (zend_bool)*ReturnData);
	SB_EVENT_INIT_ZVAL_REF(zUserData, 4);
	SBInitObject(zUserData, TObject_ce_ptr, *UserData TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zTagID);
	SB_EVENT_CLEAR_ZVAL(zDataLen);
	convert_to_boolean(Z_REFVAL_P(zReturnData));
	*ReturnData = (int8_t)SB_BVAL_P(Z_REFVAL_P(zReturnData));
	SB_EVENT_CLEAR_ZVAL(zReturnData);
	*UserData = SBGetObjectHandleCE(zUserData, TObject_ce_ptr TSRMLS_CC);
	SBDetachObjectHandleIfUniqueZVal(zUserData TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zUserData);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBASN1DataEventRaw(void * _ObjectData, TObjectHandle Sender, TObjectHandle UserData, void * Buffer, int32_t Count, int8_t * SkipRest)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zUserData;
	zval * zBuffer;
	zval * zCount;
	zval * zSkipRest;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zUserData, 1);
	SBInitObject(zUserData, TObject_ce_ptr, UserData TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 2);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCount, 3);
	ZVAL_LONG(zCount, (sb_zend_long)Count);
	SB_EVENT_INIT_ZVAL_REF(zSkipRest, 4);
	ZVAL_BOOL(Z_REFVAL_P(zSkipRest), (zend_bool)*SkipRest);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zUserData);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zCount);
	convert_to_boolean(Z_REFVAL_P(zSkipRest));
	*SkipRest = (int8_t)SB_BVAL_P(Z_REFVAL_P(zSkipRest));
	SB_EVENT_CLEAR_ZVAL(zSkipRest);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBASN1DataCompletedEventRaw(void * _ObjectData, TObjectHandle Sender, TObjectHandle UserData)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zUserData;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zUserData, 1);
	SBInitObject(zUserData, TObject_ce_ptr, UserData TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zUserData);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBASN1SkipEventRaw(void * _ObjectData, TObjectHandle Sender, int64_t * Count)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zCount;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zCount, 1);
	ZVAL_LONG(Z_REFVAL_P(zCount), (sb_zend_long)*Count);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	convert_to_long(Z_REFVAL_P(zCount));
	*Count = (int64_t)Z_LVAL_P(Z_REFVAL_P(zCount));
	SB_EVENT_CLEAR_ZVAL(zCount);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElASN1ParserClass_ce_ptr = NULL;

zend_class_entry *TElASN1Parser_ce_ptr = NULL;

SB_PHP_METHOD(TElASN1Parser, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElASN1Parser_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, Parse)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElASN1Parser_Parse(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1Parser_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, get_RaiseOnEOC)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1Parser_get_RaiseOnEOC(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, set_RaiseOnEOC)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElASN1Parser_set_RaiseOnEOC(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, get_MaxDataLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElASN1Parser_get_MaxDataLength(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, set_MaxDataLength)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElASN1Parser_set_MaxDataLength(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, get_MaxSimpleTagLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1Parser_get_MaxSimpleTagLength(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, set_MaxSimpleTagLength)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElASN1Parser_set_MaxSimpleTagLength(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, get_AsyncDataMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1Parser_get_AsyncDataMode(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, set_AsyncDataMode)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElASN1Parser_set_AsyncDataMode(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, get_CurrDepth)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1Parser_get_CurrDepth(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, get_DataBlockSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1Parser_get_DataBlockSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, set_DataBlockSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElASN1Parser_set_DataBlockSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, get_SingleLoad)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1Parser_get_SingleLoad(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, set_SingleLoad)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElASN1Parser_set_SingleLoad(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, get_OnRead)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1ReadEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1Parser_get_OnRead(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, set_OnRead)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1Parser_set_OnRead(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBASN1ReadEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBASN1ReadEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, get_OnTag)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1TagEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1Parser_get_OnTag(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, set_OnTag)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1Parser_set_OnTag(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBASN1TagEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBASN1TagEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, get_OnTagHeader)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1TagHeaderEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1Parser_get_OnTagHeader(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, set_OnTagHeader)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1Parser_set_OnTagHeader(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBASN1TagHeaderEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBASN1TagHeaderEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, get_OnSkip)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1SkipEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1Parser_get_OnSkip(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, set_OnSkip)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1Parser_set_OnSkip(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBASN1SkipEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBASN1SkipEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, get_OnDataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1DataAvailableEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1Parser_get_OnDataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, set_OnDataAvailable)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1Parser_set_OnDataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBASN1DataAvailableEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBASN1DataAvailableEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, get_OnData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1DataEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1Parser_get_OnData(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, set_OnData)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1Parser_set_OnData(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBASN1DataEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBASN1DataEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, get_OnDataCompleted)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1DataCompletedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1Parser_get_OnDataCompleted(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, set_OnDataCompleted)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1Parser_set_OnDataCompleted(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBASN1DataCompletedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBASN1DataCompletedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1Parser, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1Parser_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_Parse, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_get_RaiseOnEOC, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_set_RaiseOnEOC, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_get_MaxDataLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_set_MaxDataLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_get_MaxSimpleTagLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_set_MaxSimpleTagLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_get_AsyncDataMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_set_AsyncDataMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_get_CurrDepth, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_get_DataBlockSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_set_DataBlockSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_get_SingleLoad, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_set_SingleLoad, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_get_OnRead, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_set_OnRead, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_get_OnTag, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_set_OnTag, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_get_OnTagHeader, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_set_OnTagHeader, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_get_OnSkip, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_set_OnSkip, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_get_OnDataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_set_OnDataAvailable, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_get_OnData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_set_OnData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_get_OnDataCompleted, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser_set_OnDataCompleted, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1Parser___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElASN1Parser_methods[] = {
	PHP_ME(TElASN1Parser, Reset, arginfo_TElASN1Parser_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, Parse, arginfo_TElASN1Parser_Parse, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, ClassType, arginfo_TElASN1Parser_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElASN1Parser, get_RaiseOnEOC, arginfo_TElASN1Parser_get_RaiseOnEOC, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, set_RaiseOnEOC, arginfo_TElASN1Parser_set_RaiseOnEOC, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, get_MaxDataLength, arginfo_TElASN1Parser_get_MaxDataLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, set_MaxDataLength, arginfo_TElASN1Parser_set_MaxDataLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, get_MaxSimpleTagLength, arginfo_TElASN1Parser_get_MaxSimpleTagLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, set_MaxSimpleTagLength, arginfo_TElASN1Parser_set_MaxSimpleTagLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, get_AsyncDataMode, arginfo_TElASN1Parser_get_AsyncDataMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, set_AsyncDataMode, arginfo_TElASN1Parser_set_AsyncDataMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, get_CurrDepth, arginfo_TElASN1Parser_get_CurrDepth, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, get_DataBlockSize, arginfo_TElASN1Parser_get_DataBlockSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, set_DataBlockSize, arginfo_TElASN1Parser_set_DataBlockSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, get_SingleLoad, arginfo_TElASN1Parser_get_SingleLoad, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, set_SingleLoad, arginfo_TElASN1Parser_set_SingleLoad, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, get_OnRead, arginfo_TElASN1Parser_get_OnRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, set_OnRead, arginfo_TElASN1Parser_set_OnRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, get_OnTag, arginfo_TElASN1Parser_get_OnTag, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, set_OnTag, arginfo_TElASN1Parser_set_OnTag, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, get_OnTagHeader, arginfo_TElASN1Parser_get_OnTagHeader, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, set_OnTagHeader, arginfo_TElASN1Parser_set_OnTagHeader, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, get_OnSkip, arginfo_TElASN1Parser_get_OnSkip, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, set_OnSkip, arginfo_TElASN1Parser_set_OnSkip, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, get_OnDataAvailable, arginfo_TElASN1Parser_get_OnDataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, set_OnDataAvailable, arginfo_TElASN1Parser_set_OnDataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, get_OnData, arginfo_TElASN1Parser_get_OnData, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, set_OnData, arginfo_TElASN1Parser_set_OnData, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, get_OnDataCompleted, arginfo_TElASN1Parser_get_OnDataCompleted, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, set_OnDataCompleted, arginfo_TElASN1Parser_set_OnDataCompleted, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1Parser, __construct, arginfo_TElASN1Parser___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElASN1Parser(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElASN1Parser_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElASN1Parser", TElASN1Parser_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElASN1Parser_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElASN1ParserFactory_ce_ptr = NULL;

SB_PHP_METHOD(TElASN1ParserFactory, GetASN1Parser)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1ParserFactory_GetASN1Parser(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElASN1Parser_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ParserFactory, ReleaseASN1Parser)
{
	TElClassHandle hoParser;
	zval *oParser;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oParser, TElASN1Parser_ce_ptr) == SUCCESS) && SB_ISREF_OBJECT_P(oParser))
	{
		hoParser = SBGetObjectHandle(oParser TSRMLS_CC);
		SBCheckError(TElASN1ParserFactory_ReleaseASN1Parser(SBGetObjectHandle(getThis() TSRMLS_CC), &hoParser) TSRMLS_CC);
		SBUpdateObjectHandle(oParser, hoParser TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(&\\TElASN1Parser)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ParserFactory, Clear)
{
	zend_bool bForceDestruction;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bForceDestruction) == SUCCESS)
	{
		SBCheckError(TElASN1ParserFactory_Clear(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bForceDestruction) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ParserFactory, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1ParserFactory_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ParserFactory_GetASN1Parser, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ParserFactory_ReleaseASN1Parser, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(1, Parser, TElASN1Parser, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ParserFactory_Clear, 0, 0, 1)
	ZEND_ARG_INFO(0, ForceDestruction)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ParserFactory___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElASN1ParserFactory_methods[] = {
	PHP_ME(TElASN1ParserFactory, GetASN1Parser, arginfo_TElASN1ParserFactory_GetASN1Parser, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ParserFactory, ReleaseASN1Parser, arginfo_TElASN1ParserFactory_ReleaseASN1Parser, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ParserFactory, Clear, arginfo_TElASN1ParserFactory_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ParserFactory, __construct, arginfo_TElASN1ParserFactory___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElASN1ParserFactory(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElASN1ParserFactory_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElASN1ParserFactory", TElASN1ParserFactory_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElASN1ParserFactory_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

SB_PHP_FUNCTION(SBASN1, asn1ParseStream)
{
	SBArrayZValInfo piStream;
	void *pzCallBack;
	zval *zCallBack;
	zval *zpStream;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zpStream, &zCallBack) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpStream) || SB_IS_ARRAY_TYPE_RP(zpStream) || SB_IS_NULL_TYPE_RP(zpStream) || (SB_IS_OBJECT_TYPE_RP(zpStream) && (Z_OBJCE_P(zpStream) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zCallBack) || SB_IS_ARRAY_TYPE_RP(zCallBack) || SB_IS_CALLABLE_TYPE_RP(zCallBack) || SB_IS_NULL_TYPE_RP(zCallBack)))
	{
		if (!SBGetPointerFromZVal(zpStream, &piStream TSRMLS_CC)) RETURN_FALSE;
		pzCallBack = SBSetEventData(zCallBack TSRMLS_CC);
		SBCheckError(SBASN1_asn1ParseStream(piStream.data, pzCallBack ? &asn1tCallBackFuncRaw : NULL, pzCallBack) TSRMLS_CC);
		SBFreePointerZValInfo(&piStream);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, \\asn1tCallBackFunc|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, asn1AddTypeEqu)
{
	sb_zend_long fTagType1;
	sb_zend_long fTagType2;
	sb_zend_long l4TagSize1;
	sb_zend_long l4TagSize2;
	sb_zend_long u1Tag2;
	SBArrayZValInfo piTag1;
	SBArrayZValInfo piTag2;
	zval *zpTag1;
	zval *zpTag2;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzllzl", &fTagType1, &zpTag1, &l4TagSize1, &fTagType2, &zpTag2, &l4TagSize2) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpTag1) || SB_IS_ARRAY_TYPE_RP(zpTag1) || SB_IS_NULL_TYPE_RP(zpTag1) || (SB_IS_OBJECT_TYPE_RP(zpTag1) && (Z_OBJCE_P(zpTag1) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpTag2) || SB_IS_ARRAY_TYPE_RP(zpTag2) || SB_IS_NULL_TYPE_RP(zpTag2) || (SB_IS_OBJECT_TYPE_RP(zpTag2) && (Z_OBJCE_P(zpTag2) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpTag1, &piTag1 TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpTag2, &piTag2 TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBASN1_asn1AddTypeEqu((asn1TagTypeRaw)fTagType1, piTag1.data, (int32_t)l4TagSize1, (asn1TagTypeRaw)fTagType2, piTag2.data, (int32_t)l4TagSize2) TSRMLS_CC);
		SBFreePointerZValInfo(&piTag1);
		SBFreePointerZValInfo(&piTag2);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzll", &fTagType1, &zpTag1, &l4TagSize1, &u1Tag2) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpTag1) || SB_IS_ARRAY_TYPE_RP(zpTag1) || SB_IS_NULL_TYPE_RP(zpTag1) || (SB_IS_OBJECT_TYPE_RP(zpTag1) && (Z_OBJCE_P(zpTag1) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpTag1, &piTag1 TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBASN1_asn1AddTypeEqu_1((asn1TagTypeRaw)fTagType1, piTag1.data, (int32_t)l4TagSize1, (uint8_t)u1Tag2) TSRMLS_CC);
		SBFreePointerZValInfo(&piTag1);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TSBPointer|array of byte|string|NULL, integer, integer, \\TSBPointer|array of byte|string|NULL, integer) or (integer, \\TSBPointer|array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteListSequence)
{
	uint32_t _err;
	zval *oStrings;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStrings, TElByteArrayList_ce_ptr) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1_WriteListSequence(SBGetObjectHandle(oStrings TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1525758728, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElByteArrayList)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WritePrimitiveListSeq)
{
	sb_zend_long u1Tag;
	uint32_t _err;
	zval *oStrings;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &u1Tag, &oStrings, TElByteArrayList_ce_ptr) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1_WritePrimitiveListSeq((uint8_t)u1Tag, SBGetObjectHandle(oStrings TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1046311541, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElByteArrayList)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteExplicit)
{
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = SBASN1_WriteExplicit(aiData.data, aiData.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1409445467, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteInteger)
{
	sb_zend_long l4Number;
	sb_zend_long u1TagID;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaData, &u1TagID) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = SBASN1_WriteInteger(aiData.data, aiData.len, (uint8_t)u1TagID, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1992790702, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4Number, &u1TagID) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1_WriteInteger_1((int32_t)l4Number, (uint8_t)u1TagID, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-732376845, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer) or (integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteOID)
{
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = SBASN1_WriteOID(aiData.data, aiData.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1090962388, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WritePrintableString)
{
	char *sData;
	sb_str_size sData_len;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sData, &sData_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1_WritePrintableString(sData, (int32_t)sData_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-973319837, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = SBASN1_WritePrintableString_1(aiData.data, aiData.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-721553012, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteUTF8String)
{
	char *sData;
	sb_str_size sData_len;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sData, &sData_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1_WriteUTF8String(sData, (int32_t)sData_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-2016027842, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = SBASN1_WriteUTF8String_1(aiData.data, aiData.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1341114533, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteIA5String)
{
	char *sData;
	sb_str_size sData_len;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sData, &sData_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1_WriteIA5String(sData, (int32_t)sData_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1880773778, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = SBASN1_WriteIA5String_1(aiData.data, aiData.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-499697359, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteUTCTime)
{
	char *sData;
	sb_str_size sData_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sData, &sData_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1_WriteUTCTime(sData, (int32_t)sData_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1942559608, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteGeneralizedTime)
{
	uint32_t _err;
	zval *dtT;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtT, php_date_get_date_ce()) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1_WriteGeneralizedTime(SBGetDateTime(dtT TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(155410368, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteSize)
{
	sb_zend_long u4Size;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Size) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1_WriteSize((uint32_t)u4Size, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(520404123, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteBitString)
{
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = SBASN1_WriteBitString(aiData.data, aiData.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(517762275, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteOctetString)
{
	char *sData;
	sb_str_size sData_len;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sData, &sData_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1_WriteOctetString(sData, (int32_t)sData_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(653348048, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = SBASN1_WriteOctetString_1(aiData.data, aiData.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1158981628, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteVisibleString)
{
	char *sData;
	sb_str_size sData_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sData, &sData_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1_WriteVisibleString(sData, (int32_t)sData_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1518160340, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteBoolean)
{
	uint32_t _err;
	zend_bool bData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bData) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1_WriteBoolean((int8_t)bData, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(928009551, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteNULL)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1_WriteNULL(u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1140307095, 0, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WritePrimitive)
{
	sb_zend_long u1Tag;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u1Tag, &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = SBASN1_WritePrimitive((uint8_t)u1Tag, aiData.data, aiData.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(569238472, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, WriteStringPrimitive)
{
	char *sData;
	sb_str_size sData_len;
	sb_zend_long u1Tag;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ls", &u1Tag, &sData, &sData_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1_WriteStringPrimitive((uint8_t)u1Tag, sData, (int32_t)sData_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-497425069, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u1Tag, &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = SBASN1_WriteStringPrimitive_1((uint8_t)u1Tag, aiData.data, aiData.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1929929725, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer, string) or (integer, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1, ASN1ParserFactory)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(SBASN1_ASN1ParserFactory(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElASN1ParserFactory_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

void Register_SBASN1_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1Boolean, SB_asn1Boolean, SB_asn1Boolean);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1Integer, SB_asn1Integer, SB_asn1Integer);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1BitStr, SB_asn1BitStr, SB_asn1BitStr);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1OctetStr, SB_asn1OctetStr, SB_asn1OctetStr);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1NULL, SB_asn1NULL, SB_asn1NULL);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1Object, SB_asn1Object, SB_asn1Object);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1Real, SB_asn1Real, SB_asn1Real);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1Enumerated, SB_asn1Enumerated, SB_asn1Enumerated);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1UTF8String, SB_asn1UTF8String, SB_asn1UTF8String);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1Sequence, SB_asn1Sequence, SB_asn1Sequence);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1Set, SB_asn1Set, SB_asn1Set);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1NumericStr, SB_asn1NumericStr, SB_asn1NumericStr);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1PrintableStr, SB_asn1PrintableStr, SB_asn1PrintableStr);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1T61String, SB_asn1T61String, SB_asn1T61String);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1TeletexStr, SB_asn1TeletexStr, SB_asn1TeletexStr);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1IA5String, SB_asn1IA5String, SB_asn1IA5String);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1UTCTime, SB_asn1UTCTime, SB_asn1UTCTime);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1GeneralizedTime, SB_asn1GeneralizedTime, SB_asn1GeneralizedTime);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1VisibleStr, SB_asn1VisibleStr, SB_asn1VisibleStr);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1GeneralStr, SB_asn1GeneralStr, SB_asn1GeneralStr);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1A0, SB_asn1A0, SB_asn1A0);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1A1, SB_asn1A1, SB_asn1A1);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1A2, SB_asn1A2, SB_asn1A2);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1A3, SB_asn1A3, SB_asn1A3);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1A4, SB_asn1A4, SB_asn1A4);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1A5, SB_asn1A5, SB_asn1A5);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1A6, SB_asn1A6, SB_asn1A6);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1A7, SB_asn1A7, SB_asn1A7);
	SB_REGISTER_LONG_CONSTANT(SBASN1, asn1A8, SB_asn1A8, SB_asn1A8);
	SB_REGISTER_LONG_CONSTANT(SBASN1, ERROR_FACILITY_ASN1, SB_ERROR_FACILITY_ASN1, SB_ERROR_FACILITY_ASN1);
	SB_REGISTER_LONG_CONSTANT(SBASN1, ERROR_ASN1_INVALID_STRUCTURE, SB_ERROR_ASN1_INVALID_STRUCTURE, SB_ERROR_ASN1_INVALID_STRUCTURE);
	SB_REGISTER_LONG_CONSTANT(SBASN1, ERROR_ASN1_INVALID_LENGTH_VALUE, SB_ERROR_ASN1_INVALID_LENGTH_VALUE, SB_ERROR_ASN1_INVALID_LENGTH_VALUE);
	SB_REGISTER_LONG_CONSTANT(SBASN1, ERROR_ASN1_TAG_DEPTH_OVER_LIMIT, SB_ERROR_ASN1_TAG_DEPTH_OVER_LIMIT, SB_ERROR_ASN1_TAG_DEPTH_OVER_LIMIT);
	SB_REGISTER_LONG_CONSTANT(SBASN1, ERROR_ASN1_INVALID_STREAM_DATA, SB_ERROR_ASN1_INVALID_STREAM_DATA, SB_ERROR_ASN1_INVALID_STREAM_DATA);
	SB_REGISTER_LONG_CONSTANT(SBASN1, ERROR_ASN1_UNEXPECTED_STREAM_END, SB_ERROR_ASN1_UNEXPECTED_STREAM_END, SB_ERROR_ASN1_UNEXPECTED_STREAM_END);
	SB_REGISTER_LONG_CONSTANT(SBASN1, ERROR_ASN1_BUFFER_LENGTH_OVER_LIMIT, SB_ERROR_ASN1_BUFFER_LENGTH_OVER_LIMIT, SB_ERROR_ASN1_BUFFER_LENGTH_OVER_LIMIT);
	SB_REGISTER_LONG_CONSTANT(SBASN1, ERROR_ASN1_INTERNAL_ERROR, SB_ERROR_ASN1_INTERNAL_ERROR, SB_ERROR_ASN1_INTERNAL_ERROR);
	SB_REGISTER_LONG_CONSTANT(SBASN1, ERROR_ASN1_OBJECT_NOT_FOUND_IN_POOL, SB_ERROR_ASN1_OBJECT_NOT_FOUND_IN_POOL, SB_ERROR_ASN1_OBJECT_NOT_FOUND_IN_POOL);
	SB_REGISTER_LONG_CONSTANT(SBASN1, ERROR_ASN1_STACK_EMPTY, SB_ERROR_ASN1_STACK_EMPTY, SB_ERROR_ASN1_STACK_EMPTY);
	SB_REGISTER_LONG_CONSTANT(SBASN1, ERROR_ASN1_UNKNOWN_PATH, SB_ERROR_ASN1_UNKNOWN_PATH, SB_ERROR_ASN1_UNKNOWN_PATH);
	SB_REGISTER_LONG_CONSTANT(SBASN1, ERROR_ASN1_TERMINATED, SB_ERROR_ASN1_TERMINATED, SB_ERROR_ASN1_TERMINATED);
	SB_REGISTER_LONG_CONSTANT(SBASN1, ERROR_ASN1_UNSUPPORTED_PATH_FORMAT, SB_ERROR_ASN1_UNSUPPORTED_PATH_FORMAT, SB_ERROR_ASN1_UNSUPPORTED_PATH_FORMAT);
	SB_REGISTER_LONG_CONSTANT(SBASN1, ERROR_ASN1_TAG_READONLY, SB_ERROR_ASN1_TAG_READONLY, SB_ERROR_ASN1_TAG_READONLY);
	SB_REGISTER_STRING_CONSTANT(SBASN1, SMaxDepthExceeded, SB_SMaxDepthExceeded, SB_SMaxDepthExceeded);
	SB_REGISTER_STRING_CONSTANT(SBASN1, SObjectNotFoundInPool, SB_SObjectNotFoundInPool, SB_SObjectNotFoundInPool);
}

void Register_SBASN1_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "asn1TagType", NULL);
	asn1TagType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	asn1TagType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(asn1TagType_ce_ptr, "asn1tUniversal", 0)
	SB_DECLARE_CLASS_LONG_CONST(asn1TagType_ce_ptr, "asn1tApplication", 1)
	SB_DECLARE_CLASS_LONG_CONST(asn1TagType_ce_ptr, "asn1tSpecific", 2)
	SB_DECLARE_CLASS_LONG_CONST(asn1TagType_ce_ptr, "asn1tPrivate", 3)
	SB_DECLARE_CLASS_LONG_CONST(asn1TagType_ce_ptr, "asn1tEOC", 4)
}

void Register_SBASN1_Aliases(TSRMLS_D)
{
	TElASN1ParserClass_ce_ptr = TObject_ce_ptr;
	zend_register_class_alias("TElASN1ParserClass", TElASN1ParserClass_ce_ptr);
}

