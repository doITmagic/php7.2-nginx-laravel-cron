#include "sbasn1tree.h"

zend_class_entry *TSBASN1DisplayFormat_ce_ptr = NULL;

zend_class_entry *TSBASN1DataSourceType_ce_ptr = NULL;

void SB_CALLBACK TSBASN1VirtualDataNeededEventRaw(void * _ObjectData, TObjectHandle Sender, int64_t StartIndex, void * Buffer, int32_t MaxSize, int32_t * Read)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zStartIndex;
	zval * zBuffer;
	zval * zMaxSize;
	zval * zRead;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zStartIndex, 1);
	ZVAL_LONG(zStartIndex, (sb_zend_long)StartIndex);
	SB_EVENT_INIT_ZVAL(zBuffer, 2);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zMaxSize, 3);
	ZVAL_LONG(zMaxSize, (sb_zend_long)MaxSize);
	SB_EVENT_INIT_ZVAL_REF(zRead, 4);
	ZVAL_LONG(Z_REFVAL_P(zRead), (sb_zend_long)*Read);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zStartIndex);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zMaxSize);
	convert_to_long(Z_REFVAL_P(zRead));
	*Read = (int32_t)Z_LVAL_P(Z_REFVAL_P(zRead));
	SB_EVENT_CLEAR_ZVAL(zRead);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSBASN1StreamAccess_ce_ptr = NULL;

void SB_CALLBACK TSBASN1StreamProcessorTagBeginEventRaw(void * _ObjectData, TObjectHandle Sender, TElASN1TagInfoHandle TagInfo, int8_t * Skip)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zTagInfo;
	zval * zSkip;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTagInfo, 1);
	SBInitObject(zTagInfo, TElASN1TagInfo_ce_ptr, TagInfo TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zSkip, 2);
	ZVAL_BOOL(Z_REFVAL_P(zSkip), (zend_bool)*Skip);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zTagInfo);
	convert_to_boolean(Z_REFVAL_P(zSkip));
	*Skip = (int8_t)SB_BVAL_P(Z_REFVAL_P(zSkip));
	SB_EVENT_CLEAR_ZVAL(zSkip);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBASN1StreamProcessorTagEndEventRaw(void * _ObjectData, TObjectHandle Sender, TElASN1TagInfoHandle TagInfo)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zTagInfo;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTagInfo, 1);
	SBInitObject(zTagInfo, TElASN1TagInfo_ce_ptr, TagInfo TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zTagInfo);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBASN1StreamProcessorTagDataEventRaw(void * _ObjectData, TObjectHandle Sender, TElASN1TagInfoHandle TagInfo, void * Buffer, int32_t Count, int8_t * SkipRest)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zTagInfo;
	zval * zBuffer;
	zval * zCount;
	zval * zSkipRest;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTagInfo, 1);
	SBInitObject(zTagInfo, TElASN1TagInfo_ce_ptr, TagInfo TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 2);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCount, 3);
	ZVAL_LONG(zCount, (sb_zend_long)Count);
	SB_EVENT_INIT_ZVAL_REF(zSkipRest, 4);
	ZVAL_BOOL(Z_REFVAL_P(zSkipRest), (zend_bool)*SkipRest);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zTagInfo);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zCount);
	convert_to_boolean(Z_REFVAL_P(zSkipRest));
	*SkipRest = (int8_t)SB_BVAL_P(Z_REFVAL_P(zSkipRest));
	SB_EVENT_CLEAR_ZVAL(zSkipRest);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSBASN1TagPathAction_ce_ptr = NULL;

void SB_CALLBACK TSBASN1TagPathHandlerRaw(void * _ObjectData, TObjectHandle Sender, TElASN1TagPathHandle Path, TElASN1TagInfoHandle TagInfo, TSBASN1TagPathActionRaw * Action)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zPath;
	zval * zTagInfo;
	zval * zAction;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SBInitObject(zPath, TElASN1TagPath_ce_ptr, Path TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTagInfo, 2);
	SBInitObject(zTagInfo, TElASN1TagInfo_ce_ptr, TagInfo TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zAction, 3);
	ZVAL_LONG(Z_REFVAL_P(zAction), (sb_zend_long)*Action);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	SB_EVENT_CLEAR_ZVAL(zTagInfo);
	convert_to_long(Z_REFVAL_P(zAction));
	*Action = (TSBASN1TagPathActionRaw)Z_LVAL_P(Z_REFVAL_P(zAction));
	SB_EVENT_CLEAR_ZVAL(zAction);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElASN1CustomTag_ce_ptr = NULL;

SB_PHP_METHOD(TElASN1CustomTag, LoadFromBuffer)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zend_bool bReadOnly;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1CustomTag_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlb", &zpBuffer, &l4Size, &bReadOnly) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1CustomTag_LoadFromBuffer_1(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, (int8_t)bReadOnly, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer) or (\\TSBPointer|array of byte|string|NULL, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, SaveToBuffer)
{
	int32_t l4SizeRaw;
	SBArrayZValInfo piBuffer;
	zval *zl4Size;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zpBuffer, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElASN1CustomTag_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, CheckType)
{
	sb_zend_long u1TagId;
	zend_bool bConstrained;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &u1TagId, &bConstrained) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1CustomTag_CheckType(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1TagId, (int8_t)bConstrained, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, LoadFromStream)
{
	sb_zend_long l8Count;
	zend_bool bReadOnly;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStream, TStream_ce_ptr, &l8Count) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1CustomTag_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int64_t)l8Count, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!bl", &oStream, TStream_ce_ptr, &bReadOnly, &l8Count) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1CustomTag_LoadFromStream_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int8_t)bReadOnly, (int64_t)l8Count, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, integer) or (\\TStream, bool, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElASN1CustomTag_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, get_TagId)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElASN1CustomTag_get_TagId(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, set_TagId)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		SBCheckError(TElASN1CustomTag_set_TagId(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, get_UndefSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1CustomTag_get_UndefSize(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, set_UndefSize)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElASN1CustomTag_set_UndefSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, get_WriteHeader)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1CustomTag_get_WriteHeader(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, set_WriteHeader)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElASN1CustomTag_set_WriteHeader(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, get_IsConstrained)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1CustomTag_get_IsConstrained(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, get_TagNum)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElASN1CustomTag_get_TagNum(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, get_TagOffset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElASN1CustomTag_get_TagOffset(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, get_TagSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElASN1CustomTag_get_TagSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, get_TagHeaderSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1CustomTag_get_TagHeaderSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, get_TagContentSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElASN1CustomTag_get_TagContentSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, get_Depth)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int16_t l2OutResultRaw = 0;
		SBCheckError(TElASN1CustomTag_get_Depth(SBGetObjectHandle(getThis() TSRMLS_CC), &l2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, get_ReadOnly)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1CustomTag_get_ReadOnly(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1CustomTag, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1CustomTag_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_LoadFromBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, ReadOnly)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_SaveToBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_CheckType, 0, 0, 2)
	ZEND_ARG_INFO(0, TagId)
	ZEND_ARG_INFO(0, Constrained)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_LoadFromStream, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Count_or_ReadOnly)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_get_TagId, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_set_TagId, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_get_UndefSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_set_UndefSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_get_WriteHeader, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_set_WriteHeader, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_get_IsConstrained, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_get_TagNum, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_get_TagOffset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_get_TagSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_get_TagHeaderSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_get_TagContentSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_get_Depth, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag_get_ReadOnly, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1CustomTag___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElASN1CustomTag_methods[] = {
	PHP_ME(TElASN1CustomTag, LoadFromBuffer, arginfo_TElASN1CustomTag_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, SaveToBuffer, arginfo_TElASN1CustomTag_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, CheckType, arginfo_TElASN1CustomTag_CheckType, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, LoadFromStream, arginfo_TElASN1CustomTag_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, SaveToStream, arginfo_TElASN1CustomTag_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, get_TagId, arginfo_TElASN1CustomTag_get_TagId, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, set_TagId, arginfo_TElASN1CustomTag_set_TagId, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, get_UndefSize, arginfo_TElASN1CustomTag_get_UndefSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, set_UndefSize, arginfo_TElASN1CustomTag_set_UndefSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, get_WriteHeader, arginfo_TElASN1CustomTag_get_WriteHeader, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, set_WriteHeader, arginfo_TElASN1CustomTag_set_WriteHeader, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, get_IsConstrained, arginfo_TElASN1CustomTag_get_IsConstrained, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, get_TagNum, arginfo_TElASN1CustomTag_get_TagNum, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, get_TagOffset, arginfo_TElASN1CustomTag_get_TagOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, get_TagSize, arginfo_TElASN1CustomTag_get_TagSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, get_TagHeaderSize, arginfo_TElASN1CustomTag_get_TagHeaderSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, get_TagContentSize, arginfo_TElASN1CustomTag_get_TagContentSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, get_Depth, arginfo_TElASN1CustomTag_get_Depth, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, get_ReadOnly, arginfo_TElASN1CustomTag_get_ReadOnly, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1CustomTag, __construct, arginfo_TElASN1CustomTag___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElASN1CustomTag(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElASN1CustomTag_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElASN1CustomTag", TElASN1CustomTag_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElASN1CustomTag_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElASN1ConstrainedTag_ce_ptr = NULL;

SB_PHP_METHOD(TElASN1ConstrainedTag, CreateInstance_Inst)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1ConstrainedTag_CreateInstance_1(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElASN1ConstrainedTag_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, CreateInstance)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1ConstrainedTag_CreateInstance(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElASN1ConstrainedTag_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, LoadFromBuffer)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zend_bool bReadOnly;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlb", &zpBuffer, &l4Size, &bReadOnly) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1ConstrainedTag_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, (int8_t)bReadOnly, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1ConstrainedTag_LoadFromBuffer_1(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, bool) or (\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, LoadFromBufferSingle)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zend_bool bReadOnly;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlb", &zpBuffer, &l4Size, &bReadOnly) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1ConstrainedTag_LoadFromBufferSingle(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, (int8_t)bReadOnly, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1ConstrainedTag_LoadFromBufferSingle_1(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, bool) or (\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, SaveToBuffer)
{
	int32_t l4SizeRaw;
	SBArrayZValInfo piBuffer;
	zval *zl4Size;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zpBuffer, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElASN1ConstrainedTag_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, SaveContentToBuffer)
{
	int32_t l4SizeRaw;
	SBArrayZValInfo piBuffer;
	zval *zl4Size;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zpBuffer, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElASN1ConstrainedTag_SaveContentToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, LoadFromStream)
{
	sb_zend_long l8Count;
	zend_bool bReadOnly;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!bl", &oStream, TStream_ce_ptr, &bReadOnly, &l8Count) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1ConstrainedTag_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int8_t)bReadOnly, (int64_t)l8Count, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStream, TStream_ce_ptr, &l8Count) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1ConstrainedTag_LoadFromStream_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int64_t)l8Count, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, bool, integer) or (\\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, LoadFromStreamSingle)
{
	sb_zend_long l8Count;
	zend_bool bReadOnly;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!bl", &oStream, TStream_ce_ptr, &bReadOnly, &l8Count) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1ConstrainedTag_LoadFromStreamSingle(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int8_t)bReadOnly, (int64_t)l8Count, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStream, TStream_ce_ptr, &l8Count) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1ConstrainedTag_LoadFromStreamSingle_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int64_t)l8Count, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, bool, integer) or (\\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElASN1ConstrainedTag_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, AddField)
{
	zend_bool bConstrained;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bConstrained) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1ConstrainedTag_AddField(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bConstrained, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, AddSimpleField)
{
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	sb_zend_long l4TagID;
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &l4TagID, &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1ConstrainedTag_AddSimpleField(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4TagID, aiValue.data, aiValue.len, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzll", &l4TagID, &zaValue, &l4StartIndex, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1ConstrainedTag_AddSimpleField_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4TagID, aiValue.data, aiValue.len, (int32_t)l4StartIndex, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, array of byte|string|NULL) or (integer, array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, RemoveField)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1ConstrainedTag_RemoveField(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, GetField)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1ConstrainedTag_GetField(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElASN1CustomTag_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElASN1ConstrainedTag_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, SaveToString)
{
	sb_zend_long fDisplayFormat;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fDisplayFormat) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElASN1ConstrainedTag_SaveToString(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBASN1DisplayFormatRaw)fDisplayFormat, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1804571831, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1ConstrainedTag_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, get_MaxSimpleTagLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1ConstrainedTag_get_MaxSimpleTagLength(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, set_MaxSimpleTagLength)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElASN1ConstrainedTag_set_MaxSimpleTagLength(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, get_StreamAccess)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1StreamAccessRaw fOutResultRaw = 0;
		SBCheckError(TElASN1ConstrainedTag_get_StreamAccess(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, set_StreamAccess)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElASN1ConstrainedTag_set_StreamAccess(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBASN1StreamAccessRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1ConstrainedTag, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1ConstrainedTag_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_CreateInstance_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_CreateInstance, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_LoadFromBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, ReadOnly)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_LoadFromBufferSingle, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, ReadOnly)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_SaveToBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_SaveContentToBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_LoadFromStream, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, ReadOnly_or_Count)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_LoadFromStreamSingle, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, ReadOnly_or_Count)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_AddField, 0, 0, 1)
	ZEND_ARG_INFO(0, Constrained)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_AddSimpleField, 0, 0, 2)
	ZEND_ARG_INFO(0, TagID)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_RemoveField, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_GetField, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_SaveToString, 0, 0, 1)
	ZEND_ARG_INFO(0, DisplayFormat)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_get_MaxSimpleTagLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_set_MaxSimpleTagLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_get_StreamAccess, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag_set_StreamAccess, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1ConstrainedTag___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElASN1ConstrainedTag_methods[] = {
	PHP_ME(TElASN1ConstrainedTag, CreateInstance_Inst, arginfo_TElASN1ConstrainedTag_CreateInstance_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, CreateInstance, arginfo_TElASN1ConstrainedTag_CreateInstance, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElASN1ConstrainedTag, LoadFromBuffer, arginfo_TElASN1ConstrainedTag_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, LoadFromBufferSingle, arginfo_TElASN1ConstrainedTag_LoadFromBufferSingle, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, SaveToBuffer, arginfo_TElASN1ConstrainedTag_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, SaveContentToBuffer, arginfo_TElASN1ConstrainedTag_SaveContentToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, LoadFromStream, arginfo_TElASN1ConstrainedTag_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, LoadFromStreamSingle, arginfo_TElASN1ConstrainedTag_LoadFromStreamSingle, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, SaveToStream, arginfo_TElASN1ConstrainedTag_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, AddField, arginfo_TElASN1ConstrainedTag_AddField, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, AddSimpleField, arginfo_TElASN1ConstrainedTag_AddSimpleField, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, RemoveField, arginfo_TElASN1ConstrainedTag_RemoveField, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, GetField, arginfo_TElASN1ConstrainedTag_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, Clear, arginfo_TElASN1ConstrainedTag_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, SaveToString, arginfo_TElASN1ConstrainedTag_SaveToString, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, get_Count, arginfo_TElASN1ConstrainedTag_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, get_MaxSimpleTagLength, arginfo_TElASN1ConstrainedTag_get_MaxSimpleTagLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, set_MaxSimpleTagLength, arginfo_TElASN1ConstrainedTag_set_MaxSimpleTagLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, get_StreamAccess, arginfo_TElASN1ConstrainedTag_get_StreamAccess, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, set_StreamAccess, arginfo_TElASN1ConstrainedTag_set_StreamAccess, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1ConstrainedTag, __construct, arginfo_TElASN1ConstrainedTag___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElASN1ConstrainedTag(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElASN1ConstrainedTag_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElASN1ConstrainedTag", TElASN1ConstrainedTag_methods);
	if (NULL == TElASN1CustomTag_ce_ptr)
		Register_TElASN1CustomTag(TSRMLS_C);
	TElASN1ConstrainedTag_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElASN1CustomTag_ce_ptr);
}

zend_class_entry *TElASN1DataSource_ce_ptr = NULL;

SB_PHP_METHOD(TElASN1DataSource, Init)
{
	sb_zend_long l4Size;
	sb_zend_long l8Length;
	sb_zend_long l8Offset;
	sb_zend_long l8Size;
	SBArrayZValInfo aiValue;
	SBArrayZValInfo piBuffer;
	zend_bool bUnknownSize;
	zval *oRootTag;
	zval *oStream;
	zval *zaValue;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1DataSource_Init(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!ll", &oStream, TStream_ce_ptr, &l8Offset, &l8Size) == SUCCESS)
	{
		SBCheckError(TElASN1DataSource_Init_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int64_t)l8Offset, (int64_t)l8Size) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oStream, TStream_ce_ptr, &bUnknownSize) == SUCCESS)
	{
		SBCheckError(TElASN1DataSource_Init_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int8_t)bUnknownSize) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1DataSource_Init_3(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!ll", &oRootTag, TElASN1ConstrainedTag_ce_ptr, &l8Offset, &l8Length) == SUCCESS)
	{
		SBCheckError(TElASN1DataSource_Init_4(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oRootTag TSRMLS_CC), (int64_t)l8Offset, (int64_t)l8Length) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL) or (\\TStream, integer, integer) or (\\TStream, bool) or (\\TSBPointer|array of byte|string|NULL, integer) or (\\TElASN1ConstrainedTag, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1DataSource, InitNoCopy)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1DataSource_InitNoCopy(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1DataSource, InitVirtual)
{
	sb_zend_long l8Size;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Size) == SUCCESS)
	{
		SBCheckError(TElASN1DataSource_InitVirtual(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Size) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1DataSource, Read)
{
	sb_zend_long l4Size;
	sb_zend_long l8Offset;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zpBuffer, &l4Size, &l8Offset) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1DataSource_Read(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, (int64_t)l8Offset, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1DataSource, Clone)
{
	zval *oDest;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDest, TElASN1DataSource_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElASN1DataSource_Clone(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDest TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1DataSource)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1DataSource, CloneVirtual)
{
	zval *oDest;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDest, TElASN1DataSource_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElASN1DataSource_CloneVirtual(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDest TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1DataSource)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1DataSource, ToBuffer)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElASN1DataSource_ToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(226961468, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1DataSource, get_Size)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElASN1DataSource_get_Size(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1DataSource, get_UnknownSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1DataSource_get_UnknownSize(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1DataSource, get_SkipVirtualData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1DataSource_get_SkipVirtualData(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1DataSource, set_SkipVirtualData)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElASN1DataSource_set_SkipVirtualData(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1DataSource, get_SourceType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1DataSourceTypeRaw fOutResultRaw = 0;
		SBCheckError(TElASN1DataSource_get_SourceType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1DataSource, get_OnVirtualDataNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1VirtualDataNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1DataSource_get_OnVirtualDataNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1DataSource, set_OnVirtualDataNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1DataSource_set_OnVirtualDataNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBASN1VirtualDataNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBASN1VirtualDataNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1DataSource, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1DataSource_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource_Init, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value_or_Stream_or_Buffer_or_RootTag, 0, 1)
	ZEND_ARG_INFO(0, Offset_or_UnknownSize_or_Size)
	ZEND_ARG_INFO(0, Size_or_Length)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource_InitNoCopy, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource_InitVirtual, 0, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource_Read, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, Offset)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource_Clone, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Dest, TElASN1DataSource, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource_CloneVirtual, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Dest, TElASN1DataSource, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource_ToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource_get_Size, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource_get_UnknownSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource_get_SkipVirtualData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource_set_SkipVirtualData, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource_get_SourceType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource_get_OnVirtualDataNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource_set_OnVirtualDataNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1DataSource___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElASN1DataSource_methods[] = {
	PHP_ME(TElASN1DataSource, Init, arginfo_TElASN1DataSource_Init, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1DataSource, InitNoCopy, arginfo_TElASN1DataSource_InitNoCopy, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1DataSource, InitVirtual, arginfo_TElASN1DataSource_InitVirtual, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1DataSource, Read, arginfo_TElASN1DataSource_Read, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1DataSource, Clone, arginfo_TElASN1DataSource_Clone, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1DataSource, CloneVirtual, arginfo_TElASN1DataSource_CloneVirtual, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1DataSource, ToBuffer, arginfo_TElASN1DataSource_ToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1DataSource, get_Size, arginfo_TElASN1DataSource_get_Size, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1DataSource, get_UnknownSize, arginfo_TElASN1DataSource_get_UnknownSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1DataSource, get_SkipVirtualData, arginfo_TElASN1DataSource_get_SkipVirtualData, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1DataSource, set_SkipVirtualData, arginfo_TElASN1DataSource_set_SkipVirtualData, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1DataSource, get_SourceType, arginfo_TElASN1DataSource_get_SourceType, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1DataSource, get_OnVirtualDataNeeded, arginfo_TElASN1DataSource_get_OnVirtualDataNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1DataSource, set_OnVirtualDataNeeded, arginfo_TElASN1DataSource_set_OnVirtualDataNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1DataSource, __construct, arginfo_TElASN1DataSource___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElASN1DataSource(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElASN1DataSource_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElASN1DataSource", TElASN1DataSource_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElASN1DataSource_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElASN1SimpleTag_ce_ptr = NULL;

SB_PHP_METHOD(TElASN1SimpleTag, CreateInstance_Inst)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1SimpleTag_CreateInstance_1(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElASN1SimpleTag_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, CreateInstance)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1SimpleTag_CreateInstance(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElASN1SimpleTag_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, LoadFromBuffer)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zend_bool bReadOnly;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlb", &zpBuffer, &l4Size, &bReadOnly) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1SimpleTag_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, (int8_t)bReadOnly, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1SimpleTag_LoadFromBuffer_1(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, bool) or (\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, SaveToBuffer)
{
	int32_t l4SizeRaw;
	SBArrayZValInfo piBuffer;
	zval *zl4Size;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zpBuffer, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElASN1SimpleTag_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, LoadFromStream)
{
	sb_zend_long l8Count;
	zend_bool bReadOnly;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!bl", &oStream, TStream_ce_ptr, &bReadOnly, &l8Count) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1SimpleTag_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int8_t)bReadOnly, (int64_t)l8Count, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStream, TStream_ce_ptr, &l8Count) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1SimpleTag_LoadFromStream_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int64_t)l8Count, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, bool, integer) or (\\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElASN1SimpleTag_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, get_Content)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElASN1SimpleTag_get_Content(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1627703137, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, set_Content)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1SimpleTag_set_Content(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, get_DataSource)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1SimpleTag_get_DataSource(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElASN1DataSource_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, get_FragmentSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1SimpleTag_get_FragmentSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, set_FragmentSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElASN1SimpleTag_set_FragmentSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, get_OnContentWriteBegin)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1SimpleTag_get_OnContentWriteBegin(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, set_OnContentWriteBegin)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1SimpleTag_set_OnContentWriteBegin(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, get_OnContentWriteEnd)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1SimpleTag_get_OnContentWriteEnd(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, set_OnContentWriteEnd)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1SimpleTag_set_OnContentWriteEnd(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SimpleTag, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1SimpleTag_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_CreateInstance_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_CreateInstance, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_LoadFromBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, ReadOnly)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_SaveToBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_LoadFromStream, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, ReadOnly_or_Count)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_get_Content, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_set_Content, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_get_DataSource, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_get_FragmentSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_set_FragmentSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_get_OnContentWriteBegin, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_set_OnContentWriteBegin, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_get_OnContentWriteEnd, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag_set_OnContentWriteEnd, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SimpleTag___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElASN1SimpleTag_methods[] = {
	PHP_ME(TElASN1SimpleTag, CreateInstance_Inst, arginfo_TElASN1SimpleTag_CreateInstance_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SimpleTag, CreateInstance, arginfo_TElASN1SimpleTag_CreateInstance, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElASN1SimpleTag, LoadFromBuffer, arginfo_TElASN1SimpleTag_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SimpleTag, SaveToBuffer, arginfo_TElASN1SimpleTag_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SimpleTag, LoadFromStream, arginfo_TElASN1SimpleTag_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SimpleTag, SaveToStream, arginfo_TElASN1SimpleTag_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SimpleTag, get_Content, arginfo_TElASN1SimpleTag_get_Content, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SimpleTag, set_Content, arginfo_TElASN1SimpleTag_set_Content, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SimpleTag, get_DataSource, arginfo_TElASN1SimpleTag_get_DataSource, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SimpleTag, get_FragmentSize, arginfo_TElASN1SimpleTag_get_FragmentSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SimpleTag, set_FragmentSize, arginfo_TElASN1SimpleTag_set_FragmentSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SimpleTag, get_OnContentWriteBegin, arginfo_TElASN1SimpleTag_get_OnContentWriteBegin, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SimpleTag, set_OnContentWriteBegin, arginfo_TElASN1SimpleTag_set_OnContentWriteBegin, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SimpleTag, get_OnContentWriteEnd, arginfo_TElASN1SimpleTag_get_OnContentWriteEnd, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SimpleTag, set_OnContentWriteEnd, arginfo_TElASN1SimpleTag_set_OnContentWriteEnd, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SimpleTag, __construct, arginfo_TElASN1SimpleTag___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElASN1SimpleTag(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElASN1SimpleTag_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElASN1SimpleTag", TElASN1SimpleTag_methods);
	if (NULL == TElASN1CustomTag_ce_ptr)
		Register_TElASN1CustomTag(TSRMLS_C);
	TElASN1SimpleTag_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElASN1CustomTag_ce_ptr);
}

zend_class_entry *TElASN1TagInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElASN1TagInfo, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElASN1TagInfo_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, SaveToString)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElASN1TagInfo_SaveToString(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1175345520, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, SaveToStringFullPath)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElASN1TagInfo_SaveToStringFullPath(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(402467541, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, get_TagID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1TagInfo_get_TagID(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, get_Constrained)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1TagInfo_get_Constrained(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, get_Offset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElASN1TagInfo_get_Offset(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, get_Size)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElASN1TagInfo_get_Size(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, get_UndefSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1TagInfo_get_UndefSize(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, get_HeaderSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1TagInfo_get_HeaderSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, get_ContentOffset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElASN1TagInfo_get_ContentOffset(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, get_ContentSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElASN1TagInfo_get_ContentSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, get_Parent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1TagInfo_get_Parent(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElASN1TagInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, get_Depth)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1TagInfo_get_Depth(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, get_Index)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1TagInfo_get_Index(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, get_Data)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		void * poOutResult = NULL;
		SBCheckError(TElASN1TagInfo_get_Data(SBGetObjectHandle(getThis() TSRMLS_CC), &poOutResult) TSRMLS_CC);
		object_init_ex(return_value, TSBPointer_ce_ptr);
		SBSetPointer(return_value, poOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, set_Data)
{
	SBArrayZValInfo piValue;
	zval *zpValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zpValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpValue) || SB_IS_ARRAY_TYPE_RP(zpValue) || SB_IS_NULL_TYPE_RP(zpValue) || (SB_IS_OBJECT_TYPE_RP(zpValue) && (Z_OBJCE_P(zpValue) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpValue, &piValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1TagInfo_set_Data(SBGetObjectHandle(getThis() TSRMLS_CC), piValue.data) TSRMLS_CC);
		SBFreePointerZValInfo(&piValue);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1TagInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_SaveToString, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_SaveToStringFullPath, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_get_TagID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_get_Constrained, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_get_Offset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_get_Size, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_get_UndefSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_get_HeaderSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_get_ContentOffset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_get_ContentSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_get_Parent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_get_Depth, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_get_Index, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_get_Data, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo_set_Data, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElASN1TagInfo_methods[] = {
	PHP_ME(TElASN1TagInfo, Reset, arginfo_TElASN1TagInfo_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, SaveToString, arginfo_TElASN1TagInfo_SaveToString, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, SaveToStringFullPath, arginfo_TElASN1TagInfo_SaveToStringFullPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, get_TagID, arginfo_TElASN1TagInfo_get_TagID, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, get_Constrained, arginfo_TElASN1TagInfo_get_Constrained, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, get_Offset, arginfo_TElASN1TagInfo_get_Offset, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, get_Size, arginfo_TElASN1TagInfo_get_Size, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, get_UndefSize, arginfo_TElASN1TagInfo_get_UndefSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, get_HeaderSize, arginfo_TElASN1TagInfo_get_HeaderSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, get_ContentOffset, arginfo_TElASN1TagInfo_get_ContentOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, get_ContentSize, arginfo_TElASN1TagInfo_get_ContentSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, get_Parent, arginfo_TElASN1TagInfo_get_Parent, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, get_Depth, arginfo_TElASN1TagInfo_get_Depth, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, get_Index, arginfo_TElASN1TagInfo_get_Index, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, get_Data, arginfo_TElASN1TagInfo_get_Data, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, set_Data, arginfo_TElASN1TagInfo_set_Data, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfo, __construct, arginfo_TElASN1TagInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElASN1TagInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElASN1TagInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElASN1TagInfo", TElASN1TagInfo_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElASN1TagInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElASN1StreamProcessor_ce_ptr = NULL;

SB_PHP_METHOD(TElASN1StreamProcessor, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElASN1StreamProcessor_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1StreamProcessor, ProcessBuffer)
{
	sb_zend_long l4Count;
	sb_zend_long l4Size;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	SBArrayZValInfo piBuffer;
	zend_bool bSingleTag;
	zval *zaBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1StreamProcessor_ProcessBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zllb", &zaBuffer, &l4StartIndex, &l4Count, &bSingleTag) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1StreamProcessor_ProcessBuffer_1(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Count, (int8_t)bSingleTag, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlb", &zpBuffer, &l4Size, &bSingleTag) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1StreamProcessor_ProcessBuffer_2(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, (int8_t)bSingleTag, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, integer) or (array of byte|string|NULL, integer, integer, bool) or (\\TSBPointer|array of byte|string|NULL, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1StreamProcessor, ProcessStream)
{
	sb_zend_long l8Count;
	zend_bool bOnePass;
	zend_bool bSingleTag;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lb", &oStream, TStream_ce_ptr, &l8Count, &bOnePass) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElASN1StreamProcessor_ProcessStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int64_t)l8Count, (int8_t)bOnePass, &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lbb", &oStream, TStream_ce_ptr, &l8Count, &bOnePass, &bSingleTag) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElASN1StreamProcessor_ProcessStream_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int64_t)l8Count, (int8_t)bOnePass, (int8_t)bSingleTag, &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, integer, bool) or (\\TStream, integer, bool, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1StreamProcessor, get_OnTagBegin)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1StreamProcessorTagBeginEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1StreamProcessor_get_OnTagBegin(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1StreamProcessor, set_OnTagBegin)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1StreamProcessor_set_OnTagBegin(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBASN1StreamProcessorTagBeginEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBASN1StreamProcessorTagBeginEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1StreamProcessor, get_OnTagEnd)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1StreamProcessorTagEndEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1StreamProcessor_get_OnTagEnd(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1StreamProcessor, set_OnTagEnd)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1StreamProcessor_set_OnTagEnd(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBASN1StreamProcessorTagEndEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBASN1StreamProcessorTagEndEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1StreamProcessor, get_OnTagData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1StreamProcessorTagDataEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1StreamProcessor_get_OnTagData(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1StreamProcessor, set_OnTagData)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1StreamProcessor_set_OnTagData(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBASN1StreamProcessorTagDataEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBASN1StreamProcessorTagDataEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1StreamProcessor, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1StreamProcessor_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1StreamProcessor_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1StreamProcessor_ProcessBuffer, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex_or_Size)
	ZEND_ARG_INFO(0, Count_or_SingleTag)
	ZEND_ARG_INFO(0, SingleTag)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1StreamProcessor_ProcessStream, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, OnePass)
	ZEND_ARG_INFO(0, SingleTag)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1StreamProcessor_get_OnTagBegin, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1StreamProcessor_set_OnTagBegin, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1StreamProcessor_get_OnTagEnd, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1StreamProcessor_set_OnTagEnd, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1StreamProcessor_get_OnTagData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1StreamProcessor_set_OnTagData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1StreamProcessor___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElASN1StreamProcessor_methods[] = {
	PHP_ME(TElASN1StreamProcessor, Reset, arginfo_TElASN1StreamProcessor_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1StreamProcessor, ProcessBuffer, arginfo_TElASN1StreamProcessor_ProcessBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1StreamProcessor, ProcessStream, arginfo_TElASN1StreamProcessor_ProcessStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1StreamProcessor, get_OnTagBegin, arginfo_TElASN1StreamProcessor_get_OnTagBegin, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1StreamProcessor, set_OnTagBegin, arginfo_TElASN1StreamProcessor_set_OnTagBegin, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1StreamProcessor, get_OnTagEnd, arginfo_TElASN1StreamProcessor_get_OnTagEnd, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1StreamProcessor, set_OnTagEnd, arginfo_TElASN1StreamProcessor_set_OnTagEnd, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1StreamProcessor, get_OnTagData, arginfo_TElASN1StreamProcessor_get_OnTagData, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1StreamProcessor, set_OnTagData, arginfo_TElASN1StreamProcessor_set_OnTagData, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1StreamProcessor, __construct, arginfo_TElASN1StreamProcessor___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElASN1StreamProcessor(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElASN1StreamProcessor_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElASN1StreamProcessor", TElASN1StreamProcessor_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElASN1StreamProcessor_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElASN1TagInfoFactory_ce_ptr = NULL;

SB_PHP_METHOD(TElASN1TagInfoFactory, GetTagInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1TagInfoFactory_GetTagInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElASN1TagInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfoFactory, ReleaseTagInfo)
{
	TElClassHandle hoTagInfo;
	zval *oTagInfo;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oTagInfo, TElASN1TagInfo_ce_ptr) == SUCCESS) && SB_ISREF_OBJECT_P(oTagInfo))
	{
		hoTagInfo = SBGetObjectHandle(oTagInfo TSRMLS_CC);
		SBCheckError(TElASN1TagInfoFactory_ReleaseTagInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoTagInfo) TSRMLS_CC);
		SBUpdateObjectHandle(oTagInfo, hoTagInfo TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(&\\TElASN1TagInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfoFactory, Clear)
{
	zend_bool bForceDestruction;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bForceDestruction) == SUCCESS)
	{
		SBCheckError(TElASN1TagInfoFactory_Clear(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bForceDestruction) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagInfoFactory, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1TagInfoFactory_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfoFactory_GetTagInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfoFactory_ReleaseTagInfo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(1, TagInfo, TElASN1TagInfo, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfoFactory_Clear, 0, 0, 1)
	ZEND_ARG_INFO(0, ForceDestruction)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagInfoFactory___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElASN1TagInfoFactory_methods[] = {
	PHP_ME(TElASN1TagInfoFactory, GetTagInfo, arginfo_TElASN1TagInfoFactory_GetTagInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfoFactory, ReleaseTagInfo, arginfo_TElASN1TagInfoFactory_ReleaseTagInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfoFactory, Clear, arginfo_TElASN1TagInfoFactory_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagInfoFactory, __construct, arginfo_TElASN1TagInfoFactory___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElASN1TagInfoFactory(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElASN1TagInfoFactory_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElASN1TagInfoFactory", TElASN1TagInfoFactory_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElASN1TagInfoFactory_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElASN1TagPath_ce_ptr = NULL;

SB_PHP_METHOD(TElASN1TagPath, InitFromString)
{
	char *sS;
	sb_str_size sS_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		SBCheckError(TElASN1TagPath_InitFromString(SBGetObjectHandle(getThis() TSRMLS_CC), sS, (int32_t)sS_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPath, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElASN1TagPath_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPath, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElASN1TagPath_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElASN1TagPath_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1TagPath)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPath, AddElement)
{
	sb_zend_long l4MaxIndex;
	sb_zend_long l4MinIndex;
	sb_zend_long l4TagID;
	zend_bool bConstrained;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1TagPath_AddElement(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lbll", &l4TagID, &bConstrained, &l4MinIndex, &l4MaxIndex) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1TagPath_AddElement_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4TagID, (int8_t)bConstrained, (int32_t)l4MinIndex, (int32_t)l4MaxIndex, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (integer, bool, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPath, RemoveElement)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElASN1TagPath_RemoveElement(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPath, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElASN1TagPath_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPath, SaveToString)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElASN1TagPath_SaveToString(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1225319581, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPath, TagMatches)
{
	zval *oTag;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oTag, TElASN1TagInfo_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1TagPath_TagMatches(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTag TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1TagInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPath, get_Elements)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1TagPath_get_Elements(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElASN1TagPathElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPath, get_ElementCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1TagPath_get_ElementCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPath, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1TagPath_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPath_InitFromString, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPath_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPath_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElASN1TagPath, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPath_AddElement, 0, 0, 0)
	ZEND_ARG_INFO(0, TagID)
	ZEND_ARG_INFO(0, Constrained)
	ZEND_ARG_INFO(0, MinIndex)
	ZEND_ARG_INFO(0, MaxIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPath_RemoveElement, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPath_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPath_SaveToString, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPath_TagMatches, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1TagInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPath_get_Elements, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPath_get_ElementCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPath___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElASN1TagPath_methods[] = {
	PHP_ME(TElASN1TagPath, InitFromString, arginfo_TElASN1TagPath_InitFromString, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPath, Reset, arginfo_TElASN1TagPath_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPath, Assign, arginfo_TElASN1TagPath_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPath, AddElement, arginfo_TElASN1TagPath_AddElement, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPath, RemoveElement, arginfo_TElASN1TagPath_RemoveElement, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPath, Clear, arginfo_TElASN1TagPath_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPath, SaveToString, arginfo_TElASN1TagPath_SaveToString, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPath, TagMatches, arginfo_TElASN1TagPath_TagMatches, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPath, get_Elements, arginfo_TElASN1TagPath_get_Elements, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPath, get_ElementCount, arginfo_TElASN1TagPath_get_ElementCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPath, __construct, arginfo_TElASN1TagPath___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElASN1TagPath(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElASN1TagPath_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElASN1TagPath", TElASN1TagPath_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElASN1TagPath_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElASN1TagPathElement_ce_ptr = NULL;

SB_PHP_METHOD(TElASN1TagPathElement, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElASN1TagPathElement_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPathElement, InitFromString)
{
	char *sS;
	sb_str_size sS_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		SBCheckError(TElASN1TagPathElement_InitFromString(SBGetObjectHandle(getThis() TSRMLS_CC), sS, (int32_t)sS_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPathElement, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElASN1TagPathElement_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElASN1TagPathElement_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1TagPathElement)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPathElement, SaveToString)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElASN1TagPathElement_SaveToString(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1944188743, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPathElement, TagMatches)
{
	zval *oTag;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oTag, TElASN1TagInfo_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1TagPathElement_TagMatches(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTag TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1TagInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPathElement, Equals)
{
	sb_zend_long l4MaxIndex;
	sb_zend_long l4MinIndex;
	sb_zend_long l4TagID;
	zend_bool bConstrained;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lbll", &l4TagID, &bConstrained, &l4MinIndex, &l4MaxIndex) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1TagPathElement_Equals(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4TagID, (int8_t)bConstrained, (int32_t)l4MinIndex, (int32_t)l4MaxIndex, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPathElement, get_TagID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1TagPathElement_get_TagID(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPathElement, get_TagConstrained)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1TagPathElement_get_TagConstrained(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPathElement, get_MinIndex)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1TagPathElement_get_MinIndex(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPathElement, set_MinIndex)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElASN1TagPathElement_set_MinIndex(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPathElement, get_MaxIndex)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1TagPathElement_get_MaxIndex(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPathElement, set_MaxIndex)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElASN1TagPathElement_set_MaxIndex(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1TagPathElement, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1TagPathElement_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPathElement_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPathElement_InitFromString, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPathElement_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElASN1TagPathElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPathElement_SaveToString, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPathElement_TagMatches, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Tag, TElASN1TagInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPathElement_Equals, 0, 0, 4)
	ZEND_ARG_INFO(0, TagID)
	ZEND_ARG_INFO(0, Constrained)
	ZEND_ARG_INFO(0, MinIndex)
	ZEND_ARG_INFO(0, MaxIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPathElement_get_TagID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPathElement_get_TagConstrained, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPathElement_get_MinIndex, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPathElement_set_MinIndex, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPathElement_get_MaxIndex, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPathElement_set_MaxIndex, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1TagPathElement___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElASN1TagPathElement_methods[] = {
	PHP_ME(TElASN1TagPathElement, Reset, arginfo_TElASN1TagPathElement_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPathElement, InitFromString, arginfo_TElASN1TagPathElement_InitFromString, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPathElement, Assign, arginfo_TElASN1TagPathElement_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPathElement, SaveToString, arginfo_TElASN1TagPathElement_SaveToString, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPathElement, TagMatches, arginfo_TElASN1TagPathElement_TagMatches, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPathElement, Equals, arginfo_TElASN1TagPathElement_Equals, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPathElement, get_TagID, arginfo_TElASN1TagPathElement_get_TagID, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPathElement, get_TagConstrained, arginfo_TElASN1TagPathElement_get_TagConstrained, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPathElement, get_MinIndex, arginfo_TElASN1TagPathElement_get_MinIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPathElement, set_MinIndex, arginfo_TElASN1TagPathElement_set_MinIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPathElement, get_MaxIndex, arginfo_TElASN1TagPathElement_get_MaxIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPathElement, set_MaxIndex, arginfo_TElASN1TagPathElement_set_MaxIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1TagPathElement, __construct, arginfo_TElASN1TagPathElement___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElASN1TagPathElement(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElASN1TagPathElement_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElASN1TagPathElement", TElASN1TagPathElement_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElASN1TagPathElement_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElASN1SmartStreamProcessor_ce_ptr = NULL;

SB_PHP_METHOD(TElASN1SmartStreamProcessor, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElASN1SmartStreamProcessor_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, ProcessBuffer)
{
	sb_zend_long l4Count;
	sb_zend_long l4Size;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	SBArrayZValInfo piBuffer;
	zend_bool bSingleTag;
	zval *zaBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1SmartStreamProcessor_ProcessBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zllb", &zaBuffer, &l4StartIndex, &l4Count, &bSingleTag) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1SmartStreamProcessor_ProcessBuffer_1(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Count, (int8_t)bSingleTag, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlb", &zpBuffer, &l4Size, &bSingleTag) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElASN1SmartStreamProcessor_ProcessBuffer_2(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, (int8_t)bSingleTag, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, integer) or (array of byte|string|NULL, integer, integer, bool) or (\\TSBPointer|array of byte|string|NULL, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, ProcessStream)
{
	sb_zend_long l8Count;
	zend_bool bSingleTag;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStream, TStream_ce_ptr, &l8Count) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElASN1SmartStreamProcessor_ProcessStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int64_t)l8Count, &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lb", &oStream, TStream_ce_ptr, &l8Count, &bSingleTag) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElASN1SmartStreamProcessor_ProcessStream_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int64_t)l8Count, (int8_t)bSingleTag, &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, integer) or (\\TStream, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, AddKnownPath)
{
	char *sPath;
	sb_str_size sPath_len;
	void *pzHandler;
	zend_bool bCreateCopy;
	zend_bool bTransferOwnership;
	zval *oPath;
	zval *zHandler;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zbb", &oPath, TElASN1TagPath_ce_ptr, &zHandler, &bTransferOwnership, &bCreateCopy) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zHandler) || SB_IS_ARRAY_TYPE_RP(zHandler) || SB_IS_CALLABLE_TYPE_RP(zHandler) || SB_IS_NULL_TYPE_RP(zHandler)))
	{
		int32_t l4OutResultRaw = 0;
		pzHandler = SBSetEventData(zHandler TSRMLS_CC);
		SBCheckError(TElASN1SmartStreamProcessor_AddKnownPath(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPath TSRMLS_CC), pzHandler ? &TSBASN1TagPathHandlerRaw : NULL, pzHandler, (int8_t)bTransferOwnership, (int8_t)bCreateCopy, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sz", &sPath, &sPath_len, &zHandler) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zHandler) || SB_IS_ARRAY_TYPE_RP(zHandler) || SB_IS_CALLABLE_TYPE_RP(zHandler) || SB_IS_NULL_TYPE_RP(zHandler)))
	{
		int32_t l4OutResultRaw = 0;
		pzHandler = SBSetEventData(zHandler TSRMLS_CC);
		SBCheckError(TElASN1SmartStreamProcessor_AddKnownPath_1(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, pzHandler ? &TSBASN1TagPathHandlerRaw : NULL, pzHandler, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1SmartStreamProcessor_AddKnownPath_2(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1TagPath, \\TSBASN1TagPathHandler|callable|NULL, bool, bool) or (string, \\TSBASN1TagPathHandler|callable|NULL) or (string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, RemoveKnownPath)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElASN1SmartStreamProcessor_RemoveKnownPath(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, ClearKnownPaths)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElASN1SmartStreamProcessor_ClearKnownPaths(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, get_Paths)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1SmartStreamProcessor_get_Paths(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElASN1TagPath_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, get_PathCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElASN1SmartStreamProcessor_get_PathCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, get_TolerateUnknownPaths)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElASN1SmartStreamProcessor_get_TolerateUnknownPaths(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, set_TolerateUnknownPaths)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElASN1SmartStreamProcessor_set_TolerateUnknownPaths(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, get_UserData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1SmartStreamProcessor_get_UserData(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, set_UserData)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TObject_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElASN1SmartStreamProcessor_set_UserData(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, get_OnKnownPath)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1TagPathHandler pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1SmartStreamProcessor_get_OnKnownPath(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, set_OnKnownPath)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1SmartStreamProcessor_set_OnKnownPath(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBASN1TagPathHandlerRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBASN1TagPathHandler|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, get_OnUnknownPath)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBASN1TagPathHandler pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElASN1SmartStreamProcessor_get_OnUnknownPath(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, set_OnUnknownPath)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElASN1SmartStreamProcessor_set_OnUnknownPath(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBASN1TagPathHandlerRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBASN1TagPathHandler|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElASN1SmartStreamProcessor, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElASN1SmartStreamProcessor_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_ProcessBuffer, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex_or_Size)
	ZEND_ARG_INFO(0, Count_or_SingleTag)
	ZEND_ARG_INFO(0, SingleTag)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_ProcessStream, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, SingleTag)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_AddKnownPath, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Path, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Handler, 0, 1)
	ZEND_ARG_INFO(0, TransferOwnership)
	ZEND_ARG_INFO(0, CreateCopy)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_RemoveKnownPath, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_ClearKnownPaths, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_get_Paths, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_get_PathCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_get_TolerateUnknownPaths, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_set_TolerateUnknownPaths, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_get_UserData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_set_UserData, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TObject, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_get_OnKnownPath, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_set_OnKnownPath, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_get_OnUnknownPath, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor_set_OnUnknownPath, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElASN1SmartStreamProcessor___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElASN1SmartStreamProcessor_methods[] = {
	PHP_ME(TElASN1SmartStreamProcessor, Reset, arginfo_TElASN1SmartStreamProcessor_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, ProcessBuffer, arginfo_TElASN1SmartStreamProcessor_ProcessBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, ProcessStream, arginfo_TElASN1SmartStreamProcessor_ProcessStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, AddKnownPath, arginfo_TElASN1SmartStreamProcessor_AddKnownPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, RemoveKnownPath, arginfo_TElASN1SmartStreamProcessor_RemoveKnownPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, ClearKnownPaths, arginfo_TElASN1SmartStreamProcessor_ClearKnownPaths, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, get_Paths, arginfo_TElASN1SmartStreamProcessor_get_Paths, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, get_PathCount, arginfo_TElASN1SmartStreamProcessor_get_PathCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, get_TolerateUnknownPaths, arginfo_TElASN1SmartStreamProcessor_get_TolerateUnknownPaths, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, set_TolerateUnknownPaths, arginfo_TElASN1SmartStreamProcessor_set_TolerateUnknownPaths, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, get_UserData, arginfo_TElASN1SmartStreamProcessor_get_UserData, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, set_UserData, arginfo_TElASN1SmartStreamProcessor_set_UserData, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, get_OnKnownPath, arginfo_TElASN1SmartStreamProcessor_get_OnKnownPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, set_OnKnownPath, arginfo_TElASN1SmartStreamProcessor_set_OnKnownPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, get_OnUnknownPath, arginfo_TElASN1SmartStreamProcessor_get_OnUnknownPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, set_OnUnknownPath, arginfo_TElASN1SmartStreamProcessor_set_OnUnknownPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElASN1SmartStreamProcessor, __construct, arginfo_TElASN1SmartStreamProcessor___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElASN1SmartStreamProcessor(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElASN1SmartStreamProcessor_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElASN1SmartStreamProcessor", TElASN1SmartStreamProcessor_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElASN1SmartStreamProcessor_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

SB_PHP_FUNCTION(SBASN1Tree, asymWriteInteger)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *oTag;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zl", &oTag, TElASN1SimpleTag_ce_ptr, &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBASN1Tree_asymWriteInteger(SBGetObjectHandle(oTag TSRMLS_CC), piBuffer.data, (int32_t)l4Size) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1SimpleTag, \\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, ASN1ReadInteger)
{
	zval *oTag;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oTag, TElASN1SimpleTag_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBASN1Tree_ASN1ReadInteger(SBGetObjectHandle(oTag TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1SimpleTag)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, ASN1ReadInteger64)
{
	zval *oTag;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oTag, TElASN1SimpleTag_ce_ptr) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(SBASN1Tree_ASN1ReadInteger64(SBGetObjectHandle(oTag TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1SimpleTag)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, ASN1WriteInteger)
{
	sb_zend_long l4Value;
	zval *oTag;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oTag, TElASN1SimpleTag_ce_ptr, &l4Value) == SUCCESS)
	{
		SBCheckError(SBASN1Tree_ASN1WriteInteger(SBGetObjectHandle(oTag TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1SimpleTag, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, ASN1WriteInteger64)
{
	sb_zend_long l8Value;
	zval *oTag;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oTag, TElASN1SimpleTag_ce_ptr, &l8Value) == SUCCESS)
	{
		SBCheckError(SBASN1Tree_ASN1WriteInteger64(SBGetObjectHandle(oTag TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1SimpleTag, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, ASN1ReadSimpleValue)
{
	int32_t l4TagIDRaw;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	zval *zl4TagID;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaData, &zl4TagID) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)) && Z_ISREF_P(zl4TagID) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4TagID))))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		l4TagIDRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4TagID));
		_err = SBASN1Tree_ASN1ReadSimpleValue(aiData.data, aiData.len, &l4TagIDRaw, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-457708827, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		ZVAL_LONG(Z_REFVAL_P(zl4TagID), (sb_zend_long)l4TagIDRaw);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, ASN1WriteTagAndLength)
{
	sb_zend_long l4Tag;
	sb_zend_long l8Len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4Tag, &l8Len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBASN1Tree_ASN1WriteTagAndLength((int32_t)l4Tag, (int64_t)l8Len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1772507958, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, ASN1ReadBoolean)
{
	zval *oTag;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oTag, TElASN1SimpleTag_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBASN1Tree_ASN1ReadBoolean(SBGetObjectHandle(oTag TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1SimpleTag)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, ASN1WriteBoolean)
{
	zend_bool bValue;
	zval *oTag;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oTag, TElASN1SimpleTag_ce_ptr, &bValue) == SUCCESS)
	{
		SBCheckError(SBASN1Tree_ASN1WriteBoolean(SBGetObjectHandle(oTag TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1SimpleTag, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, ASN1ReadString)
{
	sb_zend_long l4TagId;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaData, &l4TagId) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = SBASN1Tree_ASN1ReadString(aiData.data, aiData.len, (int32_t)l4TagId, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1327107858, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, ASN1ReadStringAnsi)
{
	sb_zend_long l4TagId;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaData, &l4TagId) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = SBASN1Tree_ASN1ReadStringAnsi(aiData.data, aiData.len, (int32_t)l4TagId, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2139646446, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, FormatAttributeValue)
{
	sb_zend_long l4TagID;
	SBArrayZValInfo aiValue;
	uint32_t _err;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &l4TagID, &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		_err = SBASN1Tree_FormatAttributeValue((int32_t)l4TagID, aiValue.data, aiValue.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1563218394, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiValue);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, UnformatAttributeValue)
{
	int32_t l4TagIDRaw = 0;
	SBArrayZValInfo aiValue;
	uint32_t _err;
	zval *zaValue;
	zval *zl4TagID;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaValue, &zl4TagID) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)) && Z_ISREF_P(zl4TagID) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4TagID))))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		_err = SBASN1Tree_UnformatAttributeValue(aiValue.data, aiValue.len, &l4TagIDRaw, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-705886238, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiValue);
		ZVAL_LONG(Z_REFVAL_P(zl4TagID), (sb_zend_long)l4TagIDRaw);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, GetTagDisplayName)
{
	sb_zend_long l4TagID;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4TagID) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBASN1Tree_GetTagDisplayName((int32_t)l4TagID, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-901869378, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, GetTagByDisplayName)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBASN1Tree_GetTagByDisplayName(sName, (int32_t)sName_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, GetMaxASN1TreeDepth)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBASN1Tree_GetMaxASN1TreeDepth(&l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, SetMaxASN1TreeDepth)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(SBASN1Tree_SetMaxASN1TreeDepth((int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, GetMaxASN1BufferLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBASN1Tree_GetMaxASN1BufferLength(&l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, SetMaxASN1BufferLength)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(SBASN1Tree_SetMaxASN1BufferLength((int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, GetASN1CopyBuffers)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBASN1Tree_GetASN1CopyBuffers(&bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, SetASN1CopyBuffers)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(SBASN1Tree_SetASN1CopyBuffers((int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBASN1Tree, ASN1TagInfoFactory)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(SBASN1Tree_ASN1TagInfoFactory(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElASN1TagInfoFactory_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

void Register_SBASN1Tree_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_BOOLEAN, SB_ASN1_BOOLEAN, SB_ASN1_BOOLEAN);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_INTEGER, SB_ASN1_INTEGER, SB_ASN1_INTEGER);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_BITSTRING, SB_ASN1_BITSTRING, SB_ASN1_BITSTRING);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_OCTETSTRING, SB_ASN1_OCTETSTRING, SB_ASN1_OCTETSTRING);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_NULL, SB_ASN1_NULL, SB_ASN1_NULL);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_OBJECT, SB_ASN1_OBJECT, SB_ASN1_OBJECT);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_REAL, SB_ASN1_REAL, SB_ASN1_REAL);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_ENUMERATED, SB_ASN1_ENUMERATED, SB_ASN1_ENUMERATED);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_UTF8STRING, SB_ASN1_UTF8STRING, SB_ASN1_UTF8STRING);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_NUMERICSTR, SB_ASN1_NUMERICSTR, SB_ASN1_NUMERICSTR);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_PRINTABLESTRING, SB_ASN1_PRINTABLESTRING, SB_ASN1_PRINTABLESTRING);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_T61STRING, SB_ASN1_T61STRING, SB_ASN1_T61STRING);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_TELETEXSTRING, SB_ASN1_TELETEXSTRING, SB_ASN1_TELETEXSTRING);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_VIDEOTEXSTRING, SB_ASN1_VIDEOTEXSTRING, SB_ASN1_VIDEOTEXSTRING);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_IA5STRING, SB_ASN1_IA5STRING, SB_ASN1_IA5STRING);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_UTCTIME, SB_ASN1_UTCTIME, SB_ASN1_UTCTIME);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_GENERALIZEDTIME, SB_ASN1_GENERALIZEDTIME, SB_ASN1_GENERALIZEDTIME);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_GRAPHICSTRING, SB_ASN1_GRAPHICSTRING, SB_ASN1_GRAPHICSTRING);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_VISIBLESTRING, SB_ASN1_VISIBLESTRING, SB_ASN1_VISIBLESTRING);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_GENERALSTRING, SB_ASN1_GENERALSTRING, SB_ASN1_GENERALSTRING);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_UNIVERSALSTRING, SB_ASN1_UNIVERSALSTRING, SB_ASN1_UNIVERSALSTRING);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_BMPSTRING, SB_ASN1_BMPSTRING, SB_ASN1_BMPSTRING);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_SEQUENCE, SB_ASN1_SEQUENCE, SB_ASN1_SEQUENCE);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_SET, SB_ASN1_SET, SB_ASN1_SET);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A0_PRIMITIVE, SB_ASN1_A0_PRIMITIVE, SB_ASN1_A0_PRIMITIVE);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A0, SB_ASN1_A0, SB_ASN1_A0);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A1_PRIMITIVE, SB_ASN1_A1_PRIMITIVE, SB_ASN1_A1_PRIMITIVE);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A1, SB_ASN1_A1, SB_ASN1_A1);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A2_PRIMITIVE, SB_ASN1_A2_PRIMITIVE, SB_ASN1_A2_PRIMITIVE);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A2, SB_ASN1_A2, SB_ASN1_A2);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A3_PRIMITIVE, SB_ASN1_A3_PRIMITIVE, SB_ASN1_A3_PRIMITIVE);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A3, SB_ASN1_A3, SB_ASN1_A3);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A4_PRIMITIVE, SB_ASN1_A4_PRIMITIVE, SB_ASN1_A4_PRIMITIVE);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A4, SB_ASN1_A4, SB_ASN1_A4);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A5_PRIMITIVE, SB_ASN1_A5_PRIMITIVE, SB_ASN1_A5_PRIMITIVE);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A5, SB_ASN1_A5, SB_ASN1_A5);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A6_PRIMITIVE, SB_ASN1_A6_PRIMITIVE, SB_ASN1_A6_PRIMITIVE);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A6, SB_ASN1_A6, SB_ASN1_A6);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A7_PRIMITIVE, SB_ASN1_A7_PRIMITIVE, SB_ASN1_A7_PRIMITIVE);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A7, SB_ASN1_A7, SB_ASN1_A7);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A8_PRIMITIVE, SB_ASN1_A8_PRIMITIVE, SB_ASN1_A8_PRIMITIVE);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A8, SB_ASN1_A8, SB_ASN1_A8);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A9_PRIMITIVE, SB_ASN1_A9_PRIMITIVE, SB_ASN1_A9_PRIMITIVE);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_A9, SB_ASN1_A9, SB_ASN1_A9);
	SB_REGISTER_LONG_CONSTANT(SBASN1Tree, SB_ASN1_CONSTRAINED_FLAG, SB_ASN1_CONSTRAINED_FLAG, SB_ASN1_CONSTRAINED_FLAG);
}

void Register_SBASN1Tree_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBASN1DisplayFormat", NULL);
	TSBASN1DisplayFormat_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBASN1DisplayFormat_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBASN1DisplayFormat_ce_ptr, "adfDefault", 0)
	
	INIT_CLASS_ENTRY(ce, "TSBASN1DataSourceType", NULL);
	TSBASN1DataSourceType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBASN1DataSourceType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBASN1DataSourceType_ce_ptr, "dstBuffer", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBASN1DataSourceType_ce_ptr, "dstStream", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBASN1DataSourceType_ce_ptr, "dstVirtual", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBASN1DataSourceType_ce_ptr, "dstReference", 3)
	
	INIT_CLASS_ENTRY(ce, "TSBASN1StreamAccess", NULL);
	TSBASN1StreamAccess_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBASN1StreamAccess_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBASN1StreamAccess_ce_ptr, "saStoreStream", 0)
	
	INIT_CLASS_ENTRY(ce, "TSBASN1TagPathAction", NULL);
	TSBASN1TagPathAction_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBASN1TagPathAction_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBASN1TagPathAction_ce_ptr, "tpaContinue", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBASN1TagPathAction_ce_ptr, "tpaSkip", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBASN1TagPathAction_ce_ptr, "tpaTerminate", 2)
}

