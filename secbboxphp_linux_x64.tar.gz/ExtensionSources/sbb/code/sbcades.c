#include "sbcades.h"

zend_class_entry *TSBCAdESCompatibilityError_ce_ptr = NULL;

zend_class_entry *TSBCAdESCompatibilityErrors_ce_ptr = NULL;

void SB_CALLBACK TSBCAdESCertValidatorPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateValidatorHandle * CertValidator, TElX509CertificateHandle Cert)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zCertValidator;
	zval * zCert;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zCertValidator, 1);
	SBInitObject(zCertValidator, TElX509CertificateValidator_ce_ptr, *CertValidator TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCert, 2);
	SBInitObject(zCert, TElX509Certificate_ce_ptr, Cert TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	*CertValidator = SBGetObjectHandleCE(zCertValidator, TElX509CertificateValidator_ce_ptr TSRMLS_CC);
	SBDetachObjectHandleIfUniqueZVal(zCertValidator TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zCertValidator);
	SB_EVENT_CLEAR_ZVAL(zCert);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBCAdESCertValidatorFinishedEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateValidatorHandle CertValidator, TElX509CertificateHandle Cert, TSBCertificateValidityRaw Validity, TSBCertificateValidityReasonRaw Reason)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zCertValidator;
	zval * zCert;
	zval * zValidity;
	zval * zReason;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCertValidator, 1);
	SBInitObject(zCertValidator, TElX509CertificateValidator_ce_ptr, CertValidator TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCert, 2);
	SBInitObject(zCert, TElX509Certificate_ce_ptr, Cert TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zValidity, 3);
	ZVAL_LONG(zValidity, (sb_zend_long)Validity);
	SB_EVENT_INIT_ZVAL(zReason, 4);
	ZVAL_LONG(zReason, (sb_zend_long)Reason);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zCertValidator);
	SB_EVENT_CLEAR_ZVAL(zCert);
	SB_EVENT_CLEAR_ZVAL(zValidity);
	SB_EVENT_CLEAR_ZVAL(zReason);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBCAdESBeforeSignEventRaw(void * _ObjectData, TObjectHandle Sender, TElCMSSignatureHandle Signature, TElX509CertificateHandle Cert, TElCustomCertStorageHandle Chain)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zSignature;
	zval * zCert;
	zval * zChain;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSignature, 1);
	SBInitObject(zSignature, TElCMSSignature_ce_ptr, Signature TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCert, 2);
	SBInitObject(zCert, TElX509Certificate_ce_ptr, Cert TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zChain, 3);
	SBInitObject(zChain, TElCustomCertStorage_ce_ptr, Chain TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSignature);
	SB_EVENT_CLEAR_ZVAL(zCert);
	SB_EVENT_CLEAR_ZVAL(zChain);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBCAdESBeforeAddTimestampEventRaw(void * _ObjectData, TObjectHandle Sender, TElCMSSignatureHandle Signature, TElCustomTSPClientHandle TSPClient)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zSignature;
	zval * zTSPClient;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSignature, 1);
	SBInitObject(zSignature, TElCMSSignature_ce_ptr, Signature TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTSPClient, 2);
	SBInitObject(zTSPClient, TElCustomTSPClient_ce_ptr, TSPClient TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSignature);
	SB_EVENT_CLEAR_ZVAL(zTSPClient);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBCAdESBeforeAddValidationTimestampEventRaw(void * _ObjectData, TObjectHandle Sender, TElCMSSignatureHandle Signature, TSBCMSTimestampTypeRaw TimestampType, TElCustomTSPClientHandle TSPClient)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zSignature;
	zval * zTimestampType;
	zval * zTSPClient;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSignature, 1);
	SBInitObject(zSignature, TElCMSSignature_ce_ptr, Signature TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTimestampType, 2);
	ZVAL_LONG(zTimestampType, (sb_zend_long)TimestampType);
	SB_EVENT_INIT_ZVAL(zTSPClient, 3);
	SBInitObject(zTSPClient, TElCustomTSPClient_ce_ptr, TSPClient TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSignature);
	SB_EVENT_CLEAR_ZVAL(zTimestampType);
	SB_EVENT_CLEAR_ZVAL(zTSPClient);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBCAdESRemoteSignEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pHash[], int32_t szHash, uint8_t pSignedHash[], int32_t * szSignedHash)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zHash;
	zval * zSignedHash;
	SBArrayZValInfo aiSignedHash;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zHash, 1);
	SB_ZVAL_STRINGL_DUP(zHash, pHash, szHash);
	SB_EVENT_INIT_ZVAL_REF(zSignedHash, 2);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zSignedHash), pSignedHash, *szSignedHash);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zHash);
	if (SBGetByteArrayFromZVal(zSignedHash, &aiSignedHash TSRMLS_CC))
		SBCheckError(SBSetEventReturnBuffer(3, aiSignedHash.data, aiSignedHash.len) TSRMLS_CC);
	SBFreeArrayZValInfo(&aiSignedHash);
	SB_EVENT_CLEAR_ZVAL(zSignedHash);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSBCAdESSignatureValidity_ce_ptr = NULL;

zend_class_entry *TElCAdESRevocationInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElCAdESRevocationInfo, Assign)
{
	zend_bool bClear;
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oSource, TElCAdESRevocationInfo_ce_ptr, &bClear) == SUCCESS)
	{
		SBCheckError(TElCAdESRevocationInfo_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC), (int8_t)bClear) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCAdESRevocationInfo, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESRevocationInfo, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCAdESRevocationInfo_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESRevocationInfo, AddOCSPResponse)
{
	zval *oResp;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oResp, TElOCSPResponse_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCAdESRevocationInfo_AddOCSPResponse(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oResp TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOCSPResponse)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESRevocationInfo, RemoveOCSPResponse)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElCAdESRevocationInfo_RemoveOCSPResponse(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESRevocationInfo, get_Certificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCAdESRevocationInfo_get_Certificates(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElMemoryCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESRevocationInfo, get_CRLs)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCAdESRevocationInfo_get_CRLs(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElMemoryCRLStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESRevocationInfo, get_OCSPResponses)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCAdESRevocationInfo_get_OCSPResponses(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOCSPResponse_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESRevocationInfo, get_OCSPResponseCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCAdESRevocationInfo_get_OCSPResponseCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESRevocationInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCAdESRevocationInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESRevocationInfo_Assign, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Source, TElCAdESRevocationInfo, 1)
	ZEND_ARG_INFO(0, Clear)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESRevocationInfo_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESRevocationInfo_AddOCSPResponse, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Resp, TElOCSPResponse, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESRevocationInfo_RemoveOCSPResponse, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESRevocationInfo_get_Certificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESRevocationInfo_get_CRLs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESRevocationInfo_get_OCSPResponses, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESRevocationInfo_get_OCSPResponseCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESRevocationInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElCAdESRevocationInfo_methods[] = {
	PHP_ME(TElCAdESRevocationInfo, Assign, arginfo_TElCAdESRevocationInfo_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESRevocationInfo, Clear, arginfo_TElCAdESRevocationInfo_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESRevocationInfo, AddOCSPResponse, arginfo_TElCAdESRevocationInfo_AddOCSPResponse, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESRevocationInfo, RemoveOCSPResponse, arginfo_TElCAdESRevocationInfo_RemoveOCSPResponse, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESRevocationInfo, get_Certificates, arginfo_TElCAdESRevocationInfo_get_Certificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESRevocationInfo, get_CRLs, arginfo_TElCAdESRevocationInfo_get_CRLs, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESRevocationInfo, get_OCSPResponses, arginfo_TElCAdESRevocationInfo_get_OCSPResponses, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESRevocationInfo, get_OCSPResponseCount, arginfo_TElCAdESRevocationInfo_get_OCSPResponseCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESRevocationInfo, __construct, arginfo_TElCAdESRevocationInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCAdESRevocationInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCAdESRevocationInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCAdESRevocationInfo", TElCAdESRevocationInfo_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElCAdESRevocationInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElCAdESSignatureProcessor_ce_ptr = NULL;

SB_PHP_METHOD(TElCAdESSignatureProcessor, Validate)
{
	zval *oArchivalTimestamp;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCAdESSignatureValidityRaw fOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_Validate(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oArchivalTimestamp, TElCMSTimestamp_ce_ptr) == SUCCESS)
	{
		TSBCAdESSignatureValidityRaw fOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_Validate_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oArchivalTimestamp TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElCMSTimestamp)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, UpdateValidationInformation)
{
	zend_bool bBaselineProfileMode;
	zend_bool bUpdateRefs;
	zend_bool bUpdateValues;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "bb", &bUpdateRefs, &bUpdateValues) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpdateValidationInformation(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bUpdateRefs, (int8_t)bUpdateValues) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "bbb", &bUpdateRefs, &bUpdateValues, &bBaselineProfileMode) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpdateValidationInformation_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bUpdateRefs, (int8_t)bUpdateValues, (int8_t)bBaselineProfileMode) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool, bool) or (bool, bool, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateBES)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCert, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateBES(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateBES_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!z", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateBES_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate) or (\\TElX509Certificate, \\TElCustomCertStorage) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateEPES)
{
	char *sExplicitText;
	char *sUNOrganization;
	char *sURI;
	sb_str_size sExplicitText_len;
	sb_str_size sUNOrganization_len;
	sb_str_size sURI_len;
	sb_zend_long l4PolicyHashAlg;
	SBArrayZValInfo aiContentType;
	SBArrayZValInfo aiPolicyHash;
	SBArrayZValInfo aiPolicyID;
	SBArrayZValInfo aiUNNumbers;
	zval *oCert;
	zval *oChain;
	zval *zaContentType;
	zval *zaPolicyHash;
	zval *zaPolicyID;
	zval *zaUNNumbers;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zlz", &oCert, TElX509Certificate_ce_ptr, &zaPolicyID, &l4PolicyHashAlg, &zaPolicyHash) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaPolicyID) || SB_IS_ARRAY_TYPE_RP(zaPolicyID) || SB_IS_NULL_TYPE_RP(zaPolicyID)) && (SB_IS_STRING_TYPE_RP(zaPolicyHash) || SB_IS_ARRAY_TYPE_RP(zaPolicyHash) || SB_IS_NULL_TYPE_RP(zaPolicyHash)))
	{
		if (!SBGetByteArrayFromZVal(zaPolicyID, &aiPolicyID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaPolicyHash, &aiPolicyHash TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateEPES(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), aiPolicyID.data, aiPolicyID.len, (int32_t)l4PolicyHashAlg, aiPolicyHash.data, aiPolicyHash.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiPolicyID);
		SBFreeArrayZValInfo(&aiPolicyHash);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zzlz", &oCert, TElX509Certificate_ce_ptr, &zaContentType, &zaPolicyID, &l4PolicyHashAlg, &zaPolicyHash) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)) && (SB_IS_STRING_TYPE_RP(zaPolicyID) || SB_IS_ARRAY_TYPE_RP(zaPolicyID) || SB_IS_NULL_TYPE_RP(zaPolicyID)) && (SB_IS_STRING_TYPE_RP(zaPolicyHash) || SB_IS_ARRAY_TYPE_RP(zaPolicyHash) || SB_IS_NULL_TYPE_RP(zaPolicyHash)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaPolicyID, &aiPolicyID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaPolicyHash, &aiPolicyHash TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateEPES_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), aiContentType.data, aiContentType.len, aiPolicyID.data, aiPolicyID.len, (int32_t)l4PolicyHashAlg, aiPolicyHash.data, aiPolicyHash.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
		SBFreeArrayZValInfo(&aiPolicyID);
		SBFreeArrayZValInfo(&aiPolicyHash);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zzlzsszs", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &zaPolicyID, &l4PolicyHashAlg, &zaPolicyHash, &sURI, &sURI_len, &sUNOrganization, &sUNOrganization_len, &zaUNNumbers, &sExplicitText, &sExplicitText_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)) && (SB_IS_STRING_TYPE_RP(zaPolicyID) || SB_IS_ARRAY_TYPE_RP(zaPolicyID) || SB_IS_NULL_TYPE_RP(zaPolicyID)) && (SB_IS_STRING_TYPE_RP(zaPolicyHash) || SB_IS_ARRAY_TYPE_RP(zaPolicyHash) || SB_IS_NULL_TYPE_RP(zaPolicyHash)) && (SB_IS_ARRAY_TYPE_RP(zaUNNumbers) || SB_IS_NULL_TYPE_RP(zaUNNumbers)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaPolicyID, &aiPolicyID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaPolicyHash, &aiPolicyHash TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetInt32ArrayFromZVal(zaUNNumbers, &aiUNNumbers TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateEPES_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, aiPolicyID.data, aiPolicyID.len, (int32_t)l4PolicyHashAlg, aiPolicyHash.data, aiPolicyHash.len, sURI, (int32_t)sURI_len, sUNOrganization, (int32_t)sUNOrganization_len, aiUNNumbers.data, aiUNNumbers.len, sExplicitText, (int32_t)sExplicitText_len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
		SBFreeArrayZValInfo(&aiPolicyID);
		SBFreeArrayZValInfo(&aiPolicyHash);
		SBFreeArrayZValInfo(&aiUNNumbers);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, array of byte|string|NULL, integer, array of byte|string|NULL) or (\\TElX509Certificate, array of byte|string|NULL, array of byte|string|NULL, integer, array of byte|string|NULL) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, array of byte|string|NULL, integer, array of byte|string|NULL, string, string, array of int32|NULL, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateT)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateT(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateT_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateC)
{
	SBArrayZValInfo aiContentType;
	zend_bool bInsertCertAndRevValues;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateC(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!b", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr, &bInsertCertAndRevValues) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateC_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC), (int8_t)bInsertCertAndRevValues) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateXType1)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *oValidationTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateXType1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateXType1_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateXType2)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *oValidationTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateXType2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateXType2_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateX)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *oValidationTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateX(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateX_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateXLType1)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *oValidationTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateXLType1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateXLType1_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateXLType2)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *oValidationTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateXLType2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateXLType2_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateXL)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *oValidationTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateXL(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateXL_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateXLBase)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateXLBase(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateXLBase_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateBaselineB)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCert, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateBaselineB(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateBaselineB_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!z", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateBaselineB_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate) or (\\TElX509Certificate, \\TElCustomCertStorage) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateBaselineT)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateBaselineT(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateBaselineT_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateBaselineLT)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateBaselineLT(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateBaselineLT_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateBaselineLTA)
{
	zval *oArchivalTSPClient;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oArchivalTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateBaselineLTA(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oArchivalTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oArchivalTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateBaselineLTA_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oArchivalTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateExtendedBES)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCert, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedBES(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedBES_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!z", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedBES_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate) or (\\TElX509Certificate, \\TElCustomCertStorage) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateExtendedEPES)
{
	char *sExplicitText;
	char *sUNOrganization;
	char *sURI;
	sb_str_size sExplicitText_len;
	sb_str_size sUNOrganization_len;
	sb_str_size sURI_len;
	sb_zend_long l4PolicyHashAlg;
	SBArrayZValInfo aiContentType;
	SBArrayZValInfo aiPolicyHash;
	SBArrayZValInfo aiPolicyID;
	SBArrayZValInfo aiUNNumbers;
	zval *oCert;
	zval *oChain;
	zval *zaContentType;
	zval *zaPolicyHash;
	zval *zaPolicyID;
	zval *zaUNNumbers;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zlz", &oCert, TElX509Certificate_ce_ptr, &zaPolicyID, &l4PolicyHashAlg, &zaPolicyHash) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaPolicyID) || SB_IS_ARRAY_TYPE_RP(zaPolicyID) || SB_IS_NULL_TYPE_RP(zaPolicyID)) && (SB_IS_STRING_TYPE_RP(zaPolicyHash) || SB_IS_ARRAY_TYPE_RP(zaPolicyHash) || SB_IS_NULL_TYPE_RP(zaPolicyHash)))
	{
		if (!SBGetByteArrayFromZVal(zaPolicyID, &aiPolicyID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaPolicyHash, &aiPolicyHash TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedEPES(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), aiPolicyID.data, aiPolicyID.len, (int32_t)l4PolicyHashAlg, aiPolicyHash.data, aiPolicyHash.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiPolicyID);
		SBFreeArrayZValInfo(&aiPolicyHash);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zzlzsszs", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &zaPolicyID, &l4PolicyHashAlg, &zaPolicyHash, &sURI, &sURI_len, &sUNOrganization, &sUNOrganization_len, &zaUNNumbers, &sExplicitText, &sExplicitText_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)) && (SB_IS_STRING_TYPE_RP(zaPolicyID) || SB_IS_ARRAY_TYPE_RP(zaPolicyID) || SB_IS_NULL_TYPE_RP(zaPolicyID)) && (SB_IS_STRING_TYPE_RP(zaPolicyHash) || SB_IS_ARRAY_TYPE_RP(zaPolicyHash) || SB_IS_NULL_TYPE_RP(zaPolicyHash)) && (SB_IS_ARRAY_TYPE_RP(zaUNNumbers) || SB_IS_NULL_TYPE_RP(zaUNNumbers)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaPolicyID, &aiPolicyID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaPolicyHash, &aiPolicyHash TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetInt32ArrayFromZVal(zaUNNumbers, &aiUNNumbers TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedEPES_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, aiPolicyID.data, aiPolicyID.len, (int32_t)l4PolicyHashAlg, aiPolicyHash.data, aiPolicyHash.len, sURI, (int32_t)sURI_len, sUNOrganization, (int32_t)sUNOrganization_len, aiUNNumbers.data, aiUNNumbers.len, sExplicitText, (int32_t)sExplicitText_len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
		SBFreeArrayZValInfo(&aiPolicyID);
		SBFreeArrayZValInfo(&aiPolicyHash);
		SBFreeArrayZValInfo(&aiUNNumbers);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, array of byte|string|NULL, integer, array of byte|string|NULL) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, array of byte|string|NULL, integer, array of byte|string|NULL, string, string, array of int32|NULL, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateExtendedT)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedT(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedT_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateExtendedC)
{
	SBArrayZValInfo aiContentType;
	zend_bool bInsertCertAndRevValues;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedC(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!b", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr, &bInsertCertAndRevValues) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedC_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC), (int8_t)bInsertCertAndRevValues) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateExtendedXType1)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *oValidationTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedXType1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedXType1_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateExtendedXType2)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *oValidationTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedXType2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedXType2_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateExtendedX)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *oValidationTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedX(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedX_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateExtendedXLType1)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *oValidationTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedXLType1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedXLType1_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateExtendedXLType2)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *oValidationTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedXLType2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedXLType2_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateExtendedXL)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *oValidationTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedXL(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedXL_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateExtendedXLBase)
{
	SBArrayZValInfo aiContentType;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	zval *zaContentType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedXLBase(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &zaContentType, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContentType) || SB_IS_ARRAY_TYPE_RP(zaContentType) || SB_IS_NULL_TYPE_RP(zaContentType)))
	{
		if (!SBGetByteArrayFromZVal(zaContentType, &aiContentType TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedXLBase_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), aiContentType.data, aiContentType.len, SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContentType);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, array of byte|string|NULL, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CreateExtendedA)
{
	zval *oArchivalTSPClient;
	zval *oCert;
	zval *oChain;
	zval *oTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oArchivalTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedA(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oArchivalTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!O!", &oCert, TElX509Certificate_ce_ptr, &oChain, TElCustomCertStorage_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr, &oArchivalTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_CreateExtendedA_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oArchivalTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElX509Certificate, \\TElCustomCertStorage, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToT)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToT(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToC)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToC(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToX)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToX(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToXType1)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToXType1(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToXType2)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToXType2(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToXL)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToXL(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToXLType1)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToXLType1(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToXLType2)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToXLType2(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToA)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToA(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToBaselineLTA)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToBaselineLTA(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToExtendedT)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToExtendedT(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToExtendedC)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToExtendedC(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToExtendedX)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToExtendedX(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToExtendedXType1)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToExtendedXType1(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToExtendedXType2)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToExtendedXType2(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToExtendedXL)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToExtendedXL(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToExtendedXLType1)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToExtendedXLType1(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToExtendedXLType2)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToExtendedXLType2(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, CanUpgradeToExtendedA)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_CanUpgradeToExtendedA(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, UpgradeToT)
{
	zval *oTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToT(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, UpgradeToC)
{
	zend_bool bInsertCertAndRevValues;
	zval *oTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToC(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bInsertCertAndRevValues) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToC_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bInsertCertAndRevValues) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToC_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oTSPClient, TElCustomTSPClient_ce_ptr, &bInsertCertAndRevValues) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToC_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), (int8_t)bInsertCertAndRevValues) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool) or (\\TElCustomTSPClient) or (\\TElCustomTSPClient, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, UpgradeToX)
{
	zval *oTSPClient;
	zval *oValidationTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToX(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToX_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient) or (\\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, UpgradeToXType1)
{
	zval *oTSPClient;
	zval *oValidationTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToXType1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToXType1_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient) or (\\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, UpgradeToXType2)
{
	zval *oTSPClient;
	zval *oValidationTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToXType2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToXType2_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient) or (\\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, UpgradeToXL)
{
	zval *oTSPClient;
	zval *oValidationTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToXL(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToXL_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient) or (\\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, UpgradeToXLBase)
{
	zval *oTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToXLBase(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToXLBase_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, UpgradeToXLType1)
{
	zval *oTSPClient;
	zval *oValidationTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToXLType1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToXLType1_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient) or (\\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, UpgradeToXLType2)
{
	zval *oTSPClient;
	zval *oValidationTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToXLType2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToXLType2_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient) or (\\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, UpgradeToA)
{
	zval *oArchivalTSPClient;
	zval *oTSPClient;
	zval *oValidationTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oArchivalTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToA(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oArchivalTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oValidationTSPClient, TElCustomTSPClient_ce_ptr, &oArchivalTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToA_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC), SBGetObjectHandle(oArchivalTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oTSPClient, TElCustomTSPClient_ce_ptr, &oValidationTSPClient, TElCustomTSPClient_ce_ptr, &oArchivalTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToA_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oValidationTSPClient TSRMLS_CC), SBGetObjectHandle(oArchivalTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient) or (\\TElCustomTSPClient, \\TElCustomTSPClient) or (\\TElCustomTSPClient, \\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, UpgradeToBaselineLTA)
{
	zval *oArchivalTSPClient;
	zval *oTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oArchivalTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToBaselineLTA(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oArchivalTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oTSPClient, TElCustomTSPClient_ce_ptr, &oArchivalTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToBaselineLTA_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oArchivalTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient) or (\\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, UpgradeToExtendedA)
{
	zval *oArchivalTSPClient;
	zval *oTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oArchivalTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToExtendedA(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oArchivalTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oTSPClient, TElCustomTSPClient_ce_ptr, &oArchivalTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_UpgradeToExtendedA_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC), SBGetObjectHandle(oArchivalTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient) or (\\TElCustomTSPClient, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, Archive)
{
	zval *oArchivalTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oArchivalTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_Archive(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oArchivalTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, ArchiveBaseline)
{
	zval *oArchivalTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oArchivalTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_ArchiveBaseline(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oArchivalTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, ArchiveExtended)
{
	zval *oArchivalTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oArchivalTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_ArchiveExtended(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oArchivalTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsBES)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsBES(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsEPES)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsEPES(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsT)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsT(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsC)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsC(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsC_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsX)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsX(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsX_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsXType1)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsXType1(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsXType1_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsXType2)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsXType2(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsXType2_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsXL)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsXL(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsXL_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsXLType1)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsXLType1(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsXLType1_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsXLType2)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsXLType2(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsXLType2_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsTimestampedXL)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsTimestampedXL(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsTimestampedXL_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsA)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsA(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsA_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsBaselineB)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsBaselineB(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsBaselineT)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsBaselineT(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsBaselineLT)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsBaselineLT(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsBaselineLT_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsBaselineLTA)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsBaselineLTA(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsBaselineLTA_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsExtendedBES)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedBES(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsExtendedEPES)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedEPES(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsExtendedT)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedT(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsExtendedC)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedC(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedC_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsExtendedX)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedX(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedX_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsExtendedXType1)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedXType1(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedXType1_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsExtendedXType2)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedXType2(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedXType2_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsExtendedXL)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedXL(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedXL_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsExtendedXLType1)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedXLType1(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedXLType1_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsExtendedXLType2)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedXLType2(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedXLType2_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsTimestampedExtendedXL)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsTimestampedExtendedXL(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsTimestampedExtendedXL_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, IsExtendedA)
{
	zend_bool bDeepCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedA(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bDeepCheck) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_IsExtendedA_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bDeepCheck, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_Signature)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCAdESSignatureProcessor_get_Signature(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCMSSignature_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_Signature)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCMSSignature_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_Signature(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCMSSignature)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_CompatibilityErrors)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCAdESCompatibilityErrorsRaw fOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_CompatibilityErrors(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_ForceSigningCertificateV2)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_ForceSigningCertificateV2(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_ForceSigningCertificateV2)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_ForceSigningCertificateV2(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_ValidationMoment)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_ValidationMoment(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_ValidationMoment)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_ValidationMoment(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_ForceCompleteChainValidation)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_ForceCompleteChainValidation(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_ForceCompleteChainValidation)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_ForceCompleteChainValidation(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_IgnoreChainValidationErrors)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_IgnoreChainValidationErrors(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_IgnoreChainValidationErrors)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_IgnoreChainValidationErrors(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_PerformRevocationCheck)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_PerformRevocationCheck(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_PerformRevocationCheck)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_PerformRevocationCheck(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_OfflineMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_OfflineMode(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_OfflineMode)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_OfflineMode(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_ClaimedSigningTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_ClaimedSigningTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_CertifiedSigningTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_CertifiedSigningTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_LastArchivalTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_LastArchivalTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_CertifiedValidationTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_CertifiedValidationTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_DeepTimestampValidation)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_DeepTimestampValidation(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_DeepTimestampValidation)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_DeepTimestampValidation(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_DeepCountersignatureValidation)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_DeepCountersignatureValidation(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_DeepCountersignatureValidation)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_DeepCountersignatureValidation(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_CustomRevocationInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCAdESSignatureProcessor_get_CustomRevocationInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCAdESRevocationInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_TrustedCertificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCAdESSignatureProcessor_get_TrustedCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_TrustedCertificates)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_TrustedCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_AllowPartialValidationInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_AllowPartialValidationInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_AllowPartialValidationInfo)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_AllowPartialValidationInfo(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_SkipValidationTimestampedSignatures)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_SkipValidationTimestampedSignatures(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_SkipValidationTimestampedSignatures)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_SkipValidationTimestampedSignatures(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_GracePeriod)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_GracePeriod(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_GracePeriod)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_GracePeriod(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_ReportInvalidTimestamps)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_ReportInvalidTimestamps(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_ReportInvalidTimestamps)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_ReportInvalidTimestamps(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_AddReferenceToSigningCert)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_AddReferenceToSigningCert(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_AddReferenceToSigningCert)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_AddReferenceToSigningCert(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_AddReferencesToIrrevocableCerts)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_AddReferencesToIrrevocableCerts(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_AddReferencesToIrrevocableCerts)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_AddReferencesToIrrevocableCerts(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_AddReferencesToAllUsedCertsAndRevInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_AddReferencesToAllUsedCertsAndRevInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_AddReferencesToAllUsedCertsAndRevInfo)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_AddReferencesToAllUsedCertsAndRevInfo(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_LastValidationResult)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCMSAdvancedSignatureValidityRaw fOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_LastValidationResult(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_UseArchivalTimestampV3)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_UseArchivalTimestampV3(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_UseArchivalTimestampV3)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_UseArchivalTimestampV3(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_RemoteSigningMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCAdESSignatureProcessor_get_RemoteSigningMode(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_RemoteSigningMode)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCAdESSignatureProcessor_set_RemoteSigningMode(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_RemoteSigningParams)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCAdESSignatureProcessor_get_RemoteSigningParams(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElRemoteSigningParams_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_OnCertValidatorPrepared)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCAdESCertValidatorPreparedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCAdESSignatureProcessor_get_OnCertValidatorPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_OnCertValidatorPrepared)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCAdESSignatureProcessor_set_OnCertValidatorPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCAdESCertValidatorPreparedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCAdESCertValidatorPreparedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_OnCertValidatorFinished)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCAdESCertValidatorFinishedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCAdESSignatureProcessor_get_OnCertValidatorFinished(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_OnCertValidatorFinished)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCAdESSignatureProcessor_set_OnCertValidatorFinished(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCAdESCertValidatorFinishedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCAdESCertValidatorFinishedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_OnBeforeSign)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCAdESBeforeSignEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCAdESSignatureProcessor_get_OnBeforeSign(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_OnBeforeSign)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCAdESSignatureProcessor_set_OnBeforeSign(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCAdESBeforeSignEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCAdESBeforeSignEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_OnBeforeAddTimestamp)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCAdESBeforeAddTimestampEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCAdESSignatureProcessor_get_OnBeforeAddTimestamp(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_OnBeforeAddTimestamp)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCAdESSignatureProcessor_set_OnBeforeAddTimestamp(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCAdESBeforeAddTimestampEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCAdESBeforeAddTimestampEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_OnBeforeAddValidationTimestamp)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCAdESBeforeAddValidationTimestampEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCAdESSignatureProcessor_get_OnBeforeAddValidationTimestamp(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_OnBeforeAddValidationTimestamp)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCAdESSignatureProcessor_set_OnBeforeAddValidationTimestamp(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCAdESBeforeAddValidationTimestampEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCAdESBeforeAddValidationTimestampEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, get_OnRemoteSign)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCAdESRemoteSignEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCAdESSignatureProcessor_get_OnRemoteSign(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, set_OnRemoteSign)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCAdESSignatureProcessor_set_OnRemoteSign(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCAdESRemoteSignEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCAdESRemoteSignEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCAdESSignatureProcessor, __construct)
{
	zval *oSig;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSig, TElCMSSignature_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCAdESSignatureProcessor_Create(SBGetObjectHandle(oSig TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCAdESSignatureProcessor_Create_1(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCMSSignature) or ()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_Validate, 0, 0, 0)
	ZEND_ARG_OBJ_INFO(0, ArchivalTimestamp, TElCMSTimestamp, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_UpdateValidationInformation, 0, 0, 2)
	ZEND_ARG_INFO(0, UpdateRefs)
	ZEND_ARG_INFO(0, UpdateValues)
	ZEND_ARG_INFO(0, BaselineProfileMode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateBES, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_OBJ_INFO(0, Chain, TElCustomCertStorage, 1)
	ZEND_ARG_TYPE_INFO(0, ContentType, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateEPES, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, PolicyID_or_ContentType_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, PolicyHashAlg_or_PolicyID_or_ContentType, 0, 1)
	ZEND_ARG_TYPE_INFO(0, PolicyHash_or_PolicyHashAlg_or_PolicyID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, PolicyHash_or_PolicyHashAlg, 0, 1)
	ZEND_ARG_TYPE_INFO(0, PolicyHash, 0, 1)
	ZEND_ARG_INFO(0, URI)
	ZEND_ARG_INFO(0, UNOrganization)
	ZEND_ARG_ARRAY_INFO(0, UNNumbers, 1)
	ZEND_ARG_INFO(0, ExplicitText)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateT, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateC, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_INFO(0, InsertCertAndRevValues)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateXType1, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ValidationTSPClient_or_ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateXType2, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ValidationTSPClient_or_ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateX, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ValidationTSPClient_or_ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateXLType1, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ValidationTSPClient_or_ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateXLType2, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ValidationTSPClient_or_ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateXL, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ValidationTSPClient_or_ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateXLBase, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateBaselineB, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_OBJ_INFO(0, Chain, TElCustomCertStorage, 1)
	ZEND_ARG_TYPE_INFO(0, ContentType, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateBaselineT, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateBaselineLT, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateBaselineLTA, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ArchivalTSPClient_or_TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ArchivalTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateExtendedBES, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_OBJ_INFO(0, Chain, TElCustomCertStorage, 1)
	ZEND_ARG_TYPE_INFO(0, ContentType, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateExtendedEPES, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, PolicyID_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, PolicyHashAlg_or_ContentType, 0, 1)
	ZEND_ARG_TYPE_INFO(0, PolicyHash_or_PolicyID, 0, 1)
	ZEND_ARG_INFO(0, PolicyHashAlg)
	ZEND_ARG_TYPE_INFO(0, PolicyHash, 0, 1)
	ZEND_ARG_INFO(0, URI)
	ZEND_ARG_INFO(0, UNOrganization)
	ZEND_ARG_ARRAY_INFO(0, UNNumbers, 1)
	ZEND_ARG_INFO(0, ExplicitText)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateExtendedT, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateExtendedC, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_INFO(0, InsertCertAndRevValues)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateExtendedXType1, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ValidationTSPClient_or_ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateExtendedXType2, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ValidationTSPClient_or_ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateExtendedX, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ValidationTSPClient_or_ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateExtendedXLType1, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ValidationTSPClient_or_ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateExtendedXLType2, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ValidationTSPClient_or_ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateExtendedXL, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ValidationTSPClient_or_ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateExtendedXLBase, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ContentType, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CreateExtendedA, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_TYPE_INFO(0, TSPClient_or_Chain, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ArchivalTSPClient_or_TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ArchivalTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToT, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToC, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToX, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToXType1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToXType2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToXL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToXLType1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToXLType2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToA, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToBaselineLTA, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedT, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedC, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedX, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedXType1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedXType2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedXL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedXLType1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedXLType2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedA, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_UpgradeToT, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_UpgradeToC, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, InsertCertAndRevValues_or_TSPClient, 0, 1)
	ZEND_ARG_INFO(0, InsertCertAndRevValues)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_UpgradeToX, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient_or_TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_UpgradeToXType1, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient_or_TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_UpgradeToXType2, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient_or_TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_UpgradeToXL, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient_or_TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_UpgradeToXLBase, 0, 0, 0)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_UpgradeToXLType1, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient_or_TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_UpgradeToXLType2, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient_or_TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ValidationTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_UpgradeToA, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ArchivalTSPClient_or_ValidationTSPClient_or_TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ArchivalTSPClient_or_ValidationTSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ArchivalTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_UpgradeToBaselineLTA, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ArchivalTSPClient_or_TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ArchivalTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_UpgradeToExtendedA, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ArchivalTSPClient_or_TSPClient, TElCustomTSPClient, 1)
	ZEND_ARG_OBJ_INFO(0, ArchivalTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_Archive, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ArchivalTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_ArchiveBaseline, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ArchivalTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_ArchiveExtended, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ArchivalTSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsBES, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsEPES, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsT, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsC, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsX, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsXType1, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsXType2, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsXL, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsXLType1, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsXLType2, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsTimestampedXL, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsA, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsBaselineB, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsBaselineT, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsBaselineLT, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsBaselineLTA, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsExtendedBES, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsExtendedEPES, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsExtendedT, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsExtendedC, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsExtendedX, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsExtendedXType1, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsExtendedXType2, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsExtendedXL, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsExtendedXLType1, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsExtendedXLType2, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsTimestampedExtendedXL, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_IsExtendedA, 0, 0, 0)
	ZEND_ARG_INFO(0, DeepCheck)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_Signature, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_Signature, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCMSSignature, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_CompatibilityErrors, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_ForceSigningCertificateV2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_ForceSigningCertificateV2, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_ValidationMoment, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_ValidationMoment, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_ForceCompleteChainValidation, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_ForceCompleteChainValidation, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_IgnoreChainValidationErrors, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_IgnoreChainValidationErrors, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_PerformRevocationCheck, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_PerformRevocationCheck, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_OfflineMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_OfflineMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_ClaimedSigningTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_CertifiedSigningTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_LastArchivalTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_CertifiedValidationTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_DeepTimestampValidation, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_DeepTimestampValidation, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_DeepCountersignatureValidation, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_DeepCountersignatureValidation, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_CustomRevocationInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_TrustedCertificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_TrustedCertificates, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_AllowPartialValidationInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_AllowPartialValidationInfo, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_SkipValidationTimestampedSignatures, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_SkipValidationTimestampedSignatures, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_GracePeriod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_GracePeriod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_ReportInvalidTimestamps, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_ReportInvalidTimestamps, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_AddReferenceToSigningCert, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_AddReferenceToSigningCert, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_AddReferencesToIrrevocableCerts, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_AddReferencesToIrrevocableCerts, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_AddReferencesToAllUsedCertsAndRevInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_AddReferencesToAllUsedCertsAndRevInfo, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_LastValidationResult, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_UseArchivalTimestampV3, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_UseArchivalTimestampV3, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_RemoteSigningMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_RemoteSigningMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_RemoteSigningParams, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_OnCertValidatorPrepared, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_OnCertValidatorPrepared, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_OnCertValidatorFinished, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_OnCertValidatorFinished, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_OnBeforeSign, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_OnBeforeSign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_OnBeforeAddTimestamp, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_OnBeforeAddTimestamp, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_OnBeforeAddValidationTimestamp, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_OnBeforeAddValidationTimestamp, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_get_OnRemoteSign, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor_set_OnRemoteSign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCAdESSignatureProcessor___construct, 0, 0, 0)
	ZEND_ARG_OBJ_INFO(0, Sig, TElCMSSignature, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCAdESSignatureProcessor_methods[] = {
	PHP_ME(TElCAdESSignatureProcessor, Validate, arginfo_TElCAdESSignatureProcessor_Validate, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, UpdateValidationInformation, arginfo_TElCAdESSignatureProcessor_UpdateValidationInformation, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateBES, arginfo_TElCAdESSignatureProcessor_CreateBES, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateEPES, arginfo_TElCAdESSignatureProcessor_CreateEPES, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateT, arginfo_TElCAdESSignatureProcessor_CreateT, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateC, arginfo_TElCAdESSignatureProcessor_CreateC, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateXType1, arginfo_TElCAdESSignatureProcessor_CreateXType1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateXType2, arginfo_TElCAdESSignatureProcessor_CreateXType2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateX, arginfo_TElCAdESSignatureProcessor_CreateX, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateXLType1, arginfo_TElCAdESSignatureProcessor_CreateXLType1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateXLType2, arginfo_TElCAdESSignatureProcessor_CreateXLType2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateXL, arginfo_TElCAdESSignatureProcessor_CreateXL, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateXLBase, arginfo_TElCAdESSignatureProcessor_CreateXLBase, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateBaselineB, arginfo_TElCAdESSignatureProcessor_CreateBaselineB, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateBaselineT, arginfo_TElCAdESSignatureProcessor_CreateBaselineT, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateBaselineLT, arginfo_TElCAdESSignatureProcessor_CreateBaselineLT, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateBaselineLTA, arginfo_TElCAdESSignatureProcessor_CreateBaselineLTA, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateExtendedBES, arginfo_TElCAdESSignatureProcessor_CreateExtendedBES, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateExtendedEPES, arginfo_TElCAdESSignatureProcessor_CreateExtendedEPES, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateExtendedT, arginfo_TElCAdESSignatureProcessor_CreateExtendedT, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateExtendedC, arginfo_TElCAdESSignatureProcessor_CreateExtendedC, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateExtendedXType1, arginfo_TElCAdESSignatureProcessor_CreateExtendedXType1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateExtendedXType2, arginfo_TElCAdESSignatureProcessor_CreateExtendedXType2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateExtendedX, arginfo_TElCAdESSignatureProcessor_CreateExtendedX, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateExtendedXLType1, arginfo_TElCAdESSignatureProcessor_CreateExtendedXLType1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateExtendedXLType2, arginfo_TElCAdESSignatureProcessor_CreateExtendedXLType2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateExtendedXL, arginfo_TElCAdESSignatureProcessor_CreateExtendedXL, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateExtendedXLBase, arginfo_TElCAdESSignatureProcessor_CreateExtendedXLBase, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CreateExtendedA, arginfo_TElCAdESSignatureProcessor_CreateExtendedA, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToT, arginfo_TElCAdESSignatureProcessor_CanUpgradeToT, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToC, arginfo_TElCAdESSignatureProcessor_CanUpgradeToC, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToX, arginfo_TElCAdESSignatureProcessor_CanUpgradeToX, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToXType1, arginfo_TElCAdESSignatureProcessor_CanUpgradeToXType1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToXType2, arginfo_TElCAdESSignatureProcessor_CanUpgradeToXType2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToXL, arginfo_TElCAdESSignatureProcessor_CanUpgradeToXL, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToXLType1, arginfo_TElCAdESSignatureProcessor_CanUpgradeToXLType1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToXLType2, arginfo_TElCAdESSignatureProcessor_CanUpgradeToXLType2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToA, arginfo_TElCAdESSignatureProcessor_CanUpgradeToA, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToBaselineLTA, arginfo_TElCAdESSignatureProcessor_CanUpgradeToBaselineLTA, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToExtendedT, arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedT, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToExtendedC, arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedC, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToExtendedX, arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedX, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToExtendedXType1, arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedXType1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToExtendedXType2, arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedXType2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToExtendedXL, arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedXL, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToExtendedXLType1, arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedXLType1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToExtendedXLType2, arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedXLType2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, CanUpgradeToExtendedA, arginfo_TElCAdESSignatureProcessor_CanUpgradeToExtendedA, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, UpgradeToT, arginfo_TElCAdESSignatureProcessor_UpgradeToT, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, UpgradeToC, arginfo_TElCAdESSignatureProcessor_UpgradeToC, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, UpgradeToX, arginfo_TElCAdESSignatureProcessor_UpgradeToX, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, UpgradeToXType1, arginfo_TElCAdESSignatureProcessor_UpgradeToXType1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, UpgradeToXType2, arginfo_TElCAdESSignatureProcessor_UpgradeToXType2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, UpgradeToXL, arginfo_TElCAdESSignatureProcessor_UpgradeToXL, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, UpgradeToXLBase, arginfo_TElCAdESSignatureProcessor_UpgradeToXLBase, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, UpgradeToXLType1, arginfo_TElCAdESSignatureProcessor_UpgradeToXLType1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, UpgradeToXLType2, arginfo_TElCAdESSignatureProcessor_UpgradeToXLType2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, UpgradeToA, arginfo_TElCAdESSignatureProcessor_UpgradeToA, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, UpgradeToBaselineLTA, arginfo_TElCAdESSignatureProcessor_UpgradeToBaselineLTA, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, UpgradeToExtendedA, arginfo_TElCAdESSignatureProcessor_UpgradeToExtendedA, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, Archive, arginfo_TElCAdESSignatureProcessor_Archive, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, ArchiveBaseline, arginfo_TElCAdESSignatureProcessor_ArchiveBaseline, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, ArchiveExtended, arginfo_TElCAdESSignatureProcessor_ArchiveExtended, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsBES, arginfo_TElCAdESSignatureProcessor_IsBES, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsEPES, arginfo_TElCAdESSignatureProcessor_IsEPES, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsT, arginfo_TElCAdESSignatureProcessor_IsT, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsC, arginfo_TElCAdESSignatureProcessor_IsC, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsX, arginfo_TElCAdESSignatureProcessor_IsX, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsXType1, arginfo_TElCAdESSignatureProcessor_IsXType1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsXType2, arginfo_TElCAdESSignatureProcessor_IsXType2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsXL, arginfo_TElCAdESSignatureProcessor_IsXL, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsXLType1, arginfo_TElCAdESSignatureProcessor_IsXLType1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsXLType2, arginfo_TElCAdESSignatureProcessor_IsXLType2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsTimestampedXL, arginfo_TElCAdESSignatureProcessor_IsTimestampedXL, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsA, arginfo_TElCAdESSignatureProcessor_IsA, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsBaselineB, arginfo_TElCAdESSignatureProcessor_IsBaselineB, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsBaselineT, arginfo_TElCAdESSignatureProcessor_IsBaselineT, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsBaselineLT, arginfo_TElCAdESSignatureProcessor_IsBaselineLT, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsBaselineLTA, arginfo_TElCAdESSignatureProcessor_IsBaselineLTA, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsExtendedBES, arginfo_TElCAdESSignatureProcessor_IsExtendedBES, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsExtendedEPES, arginfo_TElCAdESSignatureProcessor_IsExtendedEPES, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsExtendedT, arginfo_TElCAdESSignatureProcessor_IsExtendedT, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsExtendedC, arginfo_TElCAdESSignatureProcessor_IsExtendedC, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsExtendedX, arginfo_TElCAdESSignatureProcessor_IsExtendedX, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsExtendedXType1, arginfo_TElCAdESSignatureProcessor_IsExtendedXType1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsExtendedXType2, arginfo_TElCAdESSignatureProcessor_IsExtendedXType2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsExtendedXL, arginfo_TElCAdESSignatureProcessor_IsExtendedXL, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsExtendedXLType1, arginfo_TElCAdESSignatureProcessor_IsExtendedXLType1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsExtendedXLType2, arginfo_TElCAdESSignatureProcessor_IsExtendedXLType2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsTimestampedExtendedXL, arginfo_TElCAdESSignatureProcessor_IsTimestampedExtendedXL, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, IsExtendedA, arginfo_TElCAdESSignatureProcessor_IsExtendedA, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_Signature, arginfo_TElCAdESSignatureProcessor_get_Signature, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_Signature, arginfo_TElCAdESSignatureProcessor_set_Signature, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_CompatibilityErrors, arginfo_TElCAdESSignatureProcessor_get_CompatibilityErrors, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_ForceSigningCertificateV2, arginfo_TElCAdESSignatureProcessor_get_ForceSigningCertificateV2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_ForceSigningCertificateV2, arginfo_TElCAdESSignatureProcessor_set_ForceSigningCertificateV2, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_ValidationMoment, arginfo_TElCAdESSignatureProcessor_get_ValidationMoment, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_ValidationMoment, arginfo_TElCAdESSignatureProcessor_set_ValidationMoment, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_ForceCompleteChainValidation, arginfo_TElCAdESSignatureProcessor_get_ForceCompleteChainValidation, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_ForceCompleteChainValidation, arginfo_TElCAdESSignatureProcessor_set_ForceCompleteChainValidation, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_IgnoreChainValidationErrors, arginfo_TElCAdESSignatureProcessor_get_IgnoreChainValidationErrors, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_IgnoreChainValidationErrors, arginfo_TElCAdESSignatureProcessor_set_IgnoreChainValidationErrors, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_PerformRevocationCheck, arginfo_TElCAdESSignatureProcessor_get_PerformRevocationCheck, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_PerformRevocationCheck, arginfo_TElCAdESSignatureProcessor_set_PerformRevocationCheck, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_OfflineMode, arginfo_TElCAdESSignatureProcessor_get_OfflineMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_OfflineMode, arginfo_TElCAdESSignatureProcessor_set_OfflineMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_ClaimedSigningTime, arginfo_TElCAdESSignatureProcessor_get_ClaimedSigningTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_CertifiedSigningTime, arginfo_TElCAdESSignatureProcessor_get_CertifiedSigningTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_LastArchivalTime, arginfo_TElCAdESSignatureProcessor_get_LastArchivalTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_CertifiedValidationTime, arginfo_TElCAdESSignatureProcessor_get_CertifiedValidationTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_DeepTimestampValidation, arginfo_TElCAdESSignatureProcessor_get_DeepTimestampValidation, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_DeepTimestampValidation, arginfo_TElCAdESSignatureProcessor_set_DeepTimestampValidation, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_DeepCountersignatureValidation, arginfo_TElCAdESSignatureProcessor_get_DeepCountersignatureValidation, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_DeepCountersignatureValidation, arginfo_TElCAdESSignatureProcessor_set_DeepCountersignatureValidation, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_CustomRevocationInfo, arginfo_TElCAdESSignatureProcessor_get_CustomRevocationInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_TrustedCertificates, arginfo_TElCAdESSignatureProcessor_get_TrustedCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_TrustedCertificates, arginfo_TElCAdESSignatureProcessor_set_TrustedCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_AllowPartialValidationInfo, arginfo_TElCAdESSignatureProcessor_get_AllowPartialValidationInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_AllowPartialValidationInfo, arginfo_TElCAdESSignatureProcessor_set_AllowPartialValidationInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_SkipValidationTimestampedSignatures, arginfo_TElCAdESSignatureProcessor_get_SkipValidationTimestampedSignatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_SkipValidationTimestampedSignatures, arginfo_TElCAdESSignatureProcessor_set_SkipValidationTimestampedSignatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_GracePeriod, arginfo_TElCAdESSignatureProcessor_get_GracePeriod, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_GracePeriod, arginfo_TElCAdESSignatureProcessor_set_GracePeriod, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_ReportInvalidTimestamps, arginfo_TElCAdESSignatureProcessor_get_ReportInvalidTimestamps, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_ReportInvalidTimestamps, arginfo_TElCAdESSignatureProcessor_set_ReportInvalidTimestamps, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_AddReferenceToSigningCert, arginfo_TElCAdESSignatureProcessor_get_AddReferenceToSigningCert, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_AddReferenceToSigningCert, arginfo_TElCAdESSignatureProcessor_set_AddReferenceToSigningCert, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_AddReferencesToIrrevocableCerts, arginfo_TElCAdESSignatureProcessor_get_AddReferencesToIrrevocableCerts, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_AddReferencesToIrrevocableCerts, arginfo_TElCAdESSignatureProcessor_set_AddReferencesToIrrevocableCerts, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_AddReferencesToAllUsedCertsAndRevInfo, arginfo_TElCAdESSignatureProcessor_get_AddReferencesToAllUsedCertsAndRevInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_AddReferencesToAllUsedCertsAndRevInfo, arginfo_TElCAdESSignatureProcessor_set_AddReferencesToAllUsedCertsAndRevInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_LastValidationResult, arginfo_TElCAdESSignatureProcessor_get_LastValidationResult, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_UseArchivalTimestampV3, arginfo_TElCAdESSignatureProcessor_get_UseArchivalTimestampV3, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_UseArchivalTimestampV3, arginfo_TElCAdESSignatureProcessor_set_UseArchivalTimestampV3, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_RemoteSigningMode, arginfo_TElCAdESSignatureProcessor_get_RemoteSigningMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_RemoteSigningMode, arginfo_TElCAdESSignatureProcessor_set_RemoteSigningMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_RemoteSigningParams, arginfo_TElCAdESSignatureProcessor_get_RemoteSigningParams, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_OnCertValidatorPrepared, arginfo_TElCAdESSignatureProcessor_get_OnCertValidatorPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_OnCertValidatorPrepared, arginfo_TElCAdESSignatureProcessor_set_OnCertValidatorPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_OnCertValidatorFinished, arginfo_TElCAdESSignatureProcessor_get_OnCertValidatorFinished, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_OnCertValidatorFinished, arginfo_TElCAdESSignatureProcessor_set_OnCertValidatorFinished, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_OnBeforeSign, arginfo_TElCAdESSignatureProcessor_get_OnBeforeSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_OnBeforeSign, arginfo_TElCAdESSignatureProcessor_set_OnBeforeSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_OnBeforeAddTimestamp, arginfo_TElCAdESSignatureProcessor_get_OnBeforeAddTimestamp, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_OnBeforeAddTimestamp, arginfo_TElCAdESSignatureProcessor_set_OnBeforeAddTimestamp, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_OnBeforeAddValidationTimestamp, arginfo_TElCAdESSignatureProcessor_get_OnBeforeAddValidationTimestamp, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_OnBeforeAddValidationTimestamp, arginfo_TElCAdESSignatureProcessor_set_OnBeforeAddValidationTimestamp, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, get_OnRemoteSign, arginfo_TElCAdESSignatureProcessor_get_OnRemoteSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, set_OnRemoteSign, arginfo_TElCAdESSignatureProcessor_set_OnRemoteSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElCAdESSignatureProcessor, __construct, arginfo_TElCAdESSignatureProcessor___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCAdESSignatureProcessor(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCAdESSignatureProcessor_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCAdESSignatureProcessor", TElCAdESSignatureProcessor_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElCAdESSignatureProcessor_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

void Register_SBCAdES_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBCAdES, ERROR_FACILITY_CADES, SB_ERROR_FACILITY_CADES, SB_ERROR_FACILITY_CADES);
	SB_REGISTER_LONG_CONSTANT(SBCAdES, SB_CADES_ERROR_NO_SIGNING_CERT, SB_CADES_ERROR_NO_SIGNING_CERT, SB_CADES_ERROR_NO_SIGNING_CERT);
	SB_REGISTER_LONG_CONSTANT(SBCAdES, SB_CADES_ERROR_NO_SIGNATURE, SB_CADES_ERROR_NO_SIGNATURE, SB_CADES_ERROR_NO_SIGNATURE);
	SB_REGISTER_LONG_CONSTANT(SBCAdES, SB_CADES_ERROR_CANT_MODIFIED_TIMESTAMPED_CONTENT, SB_CADES_ERROR_CANT_MODIFIED_TIMESTAMPED_CONTENT, SB_CADES_ERROR_CANT_MODIFIED_TIMESTAMPED_CONTENT);
	SB_REGISTER_LONG_CONSTANT(SBCAdES, SB_CADES_ERROR_TIMESTAMP_DOESNT_MATCH_SOURCE, SB_CADES_ERROR_TIMESTAMP_DOESNT_MATCH_SOURCE, SB_CADES_ERROR_TIMESTAMP_DOESNT_MATCH_SOURCE);
	SB_REGISTER_LONG_CONSTANT(SBCAdES, SB_CADES_ERROR_VALIDATION_INFO_INCOMPLETE, SB_CADES_ERROR_VALIDATION_INFO_INCOMPLETE, SB_CADES_ERROR_VALIDATION_INFO_INCOMPLETE);
	SB_REGISTER_LONG_CONSTANT(SBCAdES, SB_CADES_ERROR_C_MUST_CONTAIN_SIG_TIMESTAMP, SB_CADES_ERROR_C_MUST_CONTAIN_SIG_TIMESTAMP, SB_CADES_ERROR_C_MUST_CONTAIN_SIG_TIMESTAMP);
	SB_REGISTER_LONG_CONSTANT(SBCAdES, SB_CADES_ERROR_BAD_SIGNATURE_STATE, SB_CADES_ERROR_BAD_SIGNATURE_STATE, SB_CADES_ERROR_BAD_SIGNATURE_STATE);
	SB_REGISTER_LONG_CONSTANT(SBCAdES, SB_CADES_ERROR_CANT_UPGRADE_SIGNATURE_LEVEL, SB_CADES_ERROR_CANT_UPGRADE_SIGNATURE_LEVEL, SB_CADES_ERROR_CANT_UPGRADE_SIGNATURE_LEVEL);
	SB_REGISTER_LONG_CONSTANT(SBCAdES, SB_CADES_ERROR_CANT_UPGRADE_TO_SAME_LEVEL, SB_CADES_ERROR_CANT_UPGRADE_TO_SAME_LEVEL, SB_CADES_ERROR_CANT_UPGRADE_TO_SAME_LEVEL);
	SB_REGISTER_LONG_CONSTANT(SBCAdES, SB_CADES_ERROR_ONLY_ARCHIVAL_TIMESTAMP_ALLOWED, SB_CADES_ERROR_ONLY_ARCHIVAL_TIMESTAMP_ALLOWED, SB_CADES_ERROR_ONLY_ARCHIVAL_TIMESTAMP_ALLOWED);
}

void Register_SBCAdES_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBCAdESCompatibilityError", NULL);
	TSBCAdESCompatibilityError_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBCAdESCompatibilityError_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrUnknown", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrNoMessageDigest", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrNoContentType", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrNoSigningCertificate", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrNoSignaturePolicy", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrNoSignatureTimestamp", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrNoCertificateReferences", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrNoRevocationReferences", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrNoCertificateValues", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrNoRevocationValues", 9)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrNoTimestampedValidationData", 10)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrNoArchivalTimestamp", 11)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrUnexpectedValidationElements", 12)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrMissingValidationElements", 13)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrInvalidATSHashIndex", 14)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrNoSigningTime", 15)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityError_ce_ptr, "cerrMisplacedSigPolicyStore", 16)
	
	INIT_CLASS_ENTRY(ce, "TSBCAdESCompatibilityErrors", NULL);
	TSBCAdESCompatibilityErrors_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBCAdESCompatibilityErrors_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrUnknown", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrNoMessageDigest", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrNoContentType", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrNoSigningCertificate", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrNoSignaturePolicy", 16)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrNoSignatureTimestamp", 32)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrNoCertificateReferences", 64)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrNoRevocationReferences", 128)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrNoCertificateValues", 256)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrNoRevocationValues", 512)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrNoTimestampedValidationData", 1024)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrNoArchivalTimestamp", 2048)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrUnexpectedValidationElements", 4096)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrMissingValidationElements", 8192)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrInvalidATSHashIndex", 16384)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrNoSigningTime", 32768)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESCompatibilityErrors_ce_ptr, "cerrMisplacedSigPolicyStore", 65536)
	
	INIT_CLASS_ENTRY(ce, "TSBCAdESSignatureValidity", NULL);
	TSBCAdESSignatureValidity_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBCAdESSignatureValidity_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESSignatureValidity_ce_ptr, "asvValid", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESSignatureValidity_ce_ptr, "asvInvalid", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAdESSignatureValidity_ce_ptr, "asvIncomplete", 2)
}

