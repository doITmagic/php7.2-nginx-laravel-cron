#include "sbchscjk.h"

zend_class_entry *TPlCustomEUCCharset_ce_ptr = NULL;

SB_PHP_METHOD(TPlCustomEUCCharset, ConvertFromUCS)
{
	sb_zend_long u4Char;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Char) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TPlCustomEUCCharset_ConvertFromUCS(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Char, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCustomEUCCharset, ConvertToUCS)
{
	uint32_t u4CharRaw = 0;
	zval *oStream;
	zval *zu4Char;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oStream, TStream_ce_ptr, &zu4Char) == SUCCESS) && Z_ISREF_P(zu4Char) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4Char))))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TPlCustomEUCCharset_ConvertToUCS(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), &u4CharRaw, &l4OutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zu4Char), (sb_zend_long)u4CharRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCustomEUCCharset, ConvertBufferToUCS)
{
	sb_zend_long l4Count;
	SBPointerZValInfo piBuf;
	uint32_t u4CharRaw = 0;
	zend_bool bIsLastChunk;
	zval *zpBuf;
	zval *zu4Char;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlbz", &zpBuf, &l4Count, &bIsLastChunk, &zu4Char) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuf) || SB_IS_ARRAY_TYPE_RP(zpBuf) || SB_IS_NULL_TYPE_RP(zpBuf) || (SB_IS_OBJECT_TYPE_RP(zpBuf) && (Z_OBJCE_P(zpBuf) == TSBPointer_ce_ptr))) && Z_ISREF_P(zu4Char) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4Char))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuf, &piBuf TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TPlCustomEUCCharset_ConvertBufferToUCS(SBGetObjectHandle(getThis() TSRMLS_CC), piBuf.data, (int32_t)l4Count, (int8_t)bIsLastChunk, &u4CharRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuf);
		ZVAL_LONG(Z_REFVAL_P(zu4Char), (sb_zend_long)u4CharRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, bool, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCustomEUCCharset, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlCustomEUCCharset_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCustomEUCCharset, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlCustomEUCCharset_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCustomEUCCharset_ConvertFromUCS, 0, 0, 1)
	ZEND_ARG_INFO(0, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCustomEUCCharset_ConvertToUCS, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(1, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCustomEUCCharset_ConvertBufferToUCS, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, IsLastChunk)
	ZEND_ARG_INFO(1, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCustomEUCCharset_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCustomEUCCharset___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlCustomEUCCharset_methods[] = {
	PHP_ME(TPlCustomEUCCharset, ConvertFromUCS, arginfo_TPlCustomEUCCharset_ConvertFromUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlCustomEUCCharset, ConvertToUCS, arginfo_TPlCustomEUCCharset_ConvertToUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlCustomEUCCharset, ConvertBufferToUCS, arginfo_TPlCustomEUCCharset_ConvertBufferToUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlCustomEUCCharset, ClassType, arginfo_TPlCustomEUCCharset_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlCustomEUCCharset, __construct, arginfo_TPlCustomEUCCharset___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TPlCustomEUCCharset(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlCustomEUCCharset_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlCustomEUCCharset", TPlCustomEUCCharset_methods);
	if (NULL == TPlMixedCharset_ce_ptr)
		Register_TPlMixedCharset(TSRMLS_C);
	TPlCustomEUCCharset_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlMixedCharset_ce_ptr);
}

zend_class_entry *TPlCustomISO_2022Charset_ce_ptr = NULL;

SB_PHP_METHOD(TPlCustomISO_2022Charset, ConvertFromUCS)
{
	sb_zend_long u4Char;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Char) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TPlCustomISO_2022Charset_ConvertFromUCS(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Char, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCustomISO_2022Charset, ConvertToUCS)
{
	uint32_t u4CharRaw = 0;
	zval *oStream;
	zval *zu4Char;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oStream, TStream_ce_ptr, &zu4Char) == SUCCESS) && Z_ISREF_P(zu4Char) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4Char))))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TPlCustomISO_2022Charset_ConvertToUCS(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), &u4CharRaw, &l4OutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zu4Char), (sb_zend_long)u4CharRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCustomISO_2022Charset, ConvertBufferToUCS)
{
	sb_zend_long l4Count;
	SBPointerZValInfo piBuf;
	uint32_t u4CharRaw = 0;
	zend_bool bIsLastChunk;
	zval *zpBuf;
	zval *zu4Char;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlbz", &zpBuf, &l4Count, &bIsLastChunk, &zu4Char) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuf) || SB_IS_ARRAY_TYPE_RP(zpBuf) || SB_IS_NULL_TYPE_RP(zpBuf) || (SB_IS_OBJECT_TYPE_RP(zpBuf) && (Z_OBJCE_P(zpBuf) == TSBPointer_ce_ptr))) && Z_ISREF_P(zu4Char) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4Char))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuf, &piBuf TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TPlCustomISO_2022Charset_ConvertBufferToUCS(SBGetObjectHandle(getThis() TSRMLS_CC), piBuf.data, (int32_t)l4Count, (int8_t)bIsLastChunk, &u4CharRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuf);
		ZVAL_LONG(Z_REFVAL_P(zu4Char), (sb_zend_long)u4CharRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, bool, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCustomISO_2022Charset, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlCustomISO_2022Charset_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCustomISO_2022Charset, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlCustomISO_2022Charset_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCustomISO_2022Charset_ConvertFromUCS, 0, 0, 1)
	ZEND_ARG_INFO(0, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCustomISO_2022Charset_ConvertToUCS, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(1, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCustomISO_2022Charset_ConvertBufferToUCS, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, IsLastChunk)
	ZEND_ARG_INFO(1, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCustomISO_2022Charset_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCustomISO_2022Charset___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlCustomISO_2022Charset_methods[] = {
	PHP_ME(TPlCustomISO_2022Charset, ConvertFromUCS, arginfo_TPlCustomISO_2022Charset_ConvertFromUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlCustomISO_2022Charset, ConvertToUCS, arginfo_TPlCustomISO_2022Charset_ConvertToUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlCustomISO_2022Charset, ConvertBufferToUCS, arginfo_TPlCustomISO_2022Charset_ConvertBufferToUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlCustomISO_2022Charset, ClassType, arginfo_TPlCustomISO_2022Charset_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlCustomISO_2022Charset, __construct, arginfo_TPlCustomISO_2022Charset___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TPlCustomISO_2022Charset(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlCustomISO_2022Charset_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlCustomISO_2022Charset", TPlCustomISO_2022Charset_methods);
	if (NULL == TPlMixedCharset_ce_ptr)
		Register_TPlMixedCharset(TSRMLS_C);
	TPlCustomISO_2022Charset_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlMixedCharset_ce_ptr);
}

zend_class_entry *TPlShiftJISCode_ce_ptr = NULL;

SB_PHP_METHOD(TPlShiftJISCode, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlShiftJISCode_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlShiftJISCode, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlShiftJISCode_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlShiftJISCode_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlShiftJISCode___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlShiftJISCode_methods[] = {
	PHP_ME(TPlShiftJISCode, ClassType, arginfo_TPlShiftJISCode_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlShiftJISCode, __construct, arginfo_TPlShiftJISCode___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TPlShiftJISCode(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlShiftJISCode_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlShiftJISCode", TPlShiftJISCode_methods);
	if (NULL == TPlConvertingCharset_ce_ptr)
		Register_TPlConvertingCharset(TSRMLS_C);
	TPlShiftJISCode_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlConvertingCharset_ce_ptr);
}

zend_class_entry *TPlShiftJIS_ce_ptr = NULL;

SB_PHP_METHOD(TPlShiftJIS, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlShiftJIS_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2021332437, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlShiftJIS, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlShiftJIS_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1418163584, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlShiftJIS, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlShiftJIS_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlShiftJIS, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlShiftJIS_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlShiftJIS, CreateShift)
{
	sb_zend_long l4Shift;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Shift) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlShiftJIS_CreateShift((int32_t)l4Shift, &hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlMixedCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlShiftJIS_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlShiftJIS_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlShiftJIS_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlShiftJIS___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlShiftJIS_CreateShift, 0, 0, 1)
	ZEND_ARG_INFO(0, Shift)
ZEND_END_ARG_INFO()

static zend_function_entry TPlShiftJIS_methods[] = {
	PHP_ME(TPlShiftJIS, GetCategory, arginfo_TPlShiftJIS_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlShiftJIS, GetDescription, arginfo_TPlShiftJIS_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlShiftJIS, ClassType, arginfo_TPlShiftJIS_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlShiftJIS, __construct, arginfo_TPlShiftJIS___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TPlShiftJIS, CreateShift, arginfo_TPlShiftJIS_CreateShift, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TPlShiftJIS(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlShiftJIS_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlShiftJIS", TPlShiftJIS_methods);
	if (NULL == TPlMixedCharset_ce_ptr)
		Register_TPlMixedCharset(TSRMLS_C);
	TPlShiftJIS_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlMixedCharset_ce_ptr);
}

zend_class_entry *TPlEUC_JP_ce_ptr = NULL;

SB_PHP_METHOD(TPlEUC_JP, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlEUC_JP_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(145377387, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlEUC_JP, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlEUC_JP_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(845665674, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlEUC_JP, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlEUC_JP_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlEUC_JP, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlEUC_JP_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlEUC_JP_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlEUC_JP_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlEUC_JP_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlEUC_JP___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlEUC_JP_methods[] = {
	PHP_ME(TPlEUC_JP, GetCategory, arginfo_TPlEUC_JP_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlEUC_JP, GetDescription, arginfo_TPlEUC_JP_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlEUC_JP, ClassType, arginfo_TPlEUC_JP_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlEUC_JP, __construct, arginfo_TPlEUC_JP___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TPlEUC_JP(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlEUC_JP_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlEUC_JP", TPlEUC_JP_methods);
	if (NULL == TPlCustomEUCCharset_ce_ptr)
		Register_TPlCustomEUCCharset(TSRMLS_C);
	TPlEUC_JP_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlCustomEUCCharset_ce_ptr);
}

zend_class_entry *TPlISO_2022_JP_ce_ptr = NULL;

SB_PHP_METHOD(TPlISO_2022_JP, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlISO_2022_JP_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2114590763, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_JP, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlISO_2022_JP_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-557628445, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_JP, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_2022_JP_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_JP, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_2022_JP_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_JP_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_JP_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_JP_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_JP___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlISO_2022_JP_methods[] = {
	PHP_ME(TPlISO_2022_JP, GetCategory, arginfo_TPlISO_2022_JP_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_2022_JP, GetDescription, arginfo_TPlISO_2022_JP_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_2022_JP, ClassType, arginfo_TPlISO_2022_JP_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlISO_2022_JP, __construct, arginfo_TPlISO_2022_JP___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TPlISO_2022_JP(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlISO_2022_JP_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlISO_2022_JP", TPlISO_2022_JP_methods);
	if (NULL == TPlCustomISO_2022Charset_ce_ptr)
		Register_TPlCustomISO_2022Charset(TSRMLS_C);
	TPlISO_2022_JP_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlCustomISO_2022Charset_ce_ptr);
}

zend_class_entry *TPlISO_2022_JP_1_ce_ptr = NULL;

SB_PHP_METHOD(TPlISO_2022_JP_1, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlISO_2022_JP_1_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1032701087, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_JP_1, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlISO_2022_JP_1_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(498127468, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_JP_1, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_2022_JP_1_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_JP_1, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_2022_JP_1_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_JP_1_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_JP_1_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_JP_1_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_JP_1___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlISO_2022_JP_1_methods[] = {
	PHP_ME(TPlISO_2022_JP_1, GetCategory, arginfo_TPlISO_2022_JP_1_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_2022_JP_1, GetDescription, arginfo_TPlISO_2022_JP_1_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_2022_JP_1, ClassType, arginfo_TPlISO_2022_JP_1_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlISO_2022_JP_1, __construct, arginfo_TPlISO_2022_JP_1___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TPlISO_2022_JP_1(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlISO_2022_JP_1_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlISO_2022_JP_1", TPlISO_2022_JP_1_methods);
	if (NULL == TPlCustomISO_2022Charset_ce_ptr)
		Register_TPlCustomISO_2022Charset(TSRMLS_C);
	TPlISO_2022_JP_1_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlCustomISO_2022Charset_ce_ptr);
}

zend_class_entry *TPlISO_2022_JP_2_ce_ptr = NULL;

SB_PHP_METHOD(TPlISO_2022_JP_2, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlISO_2022_JP_2_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1453678131, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_JP_2, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlISO_2022_JP_2_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(341198906, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_JP_2, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_2022_JP_2_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_JP_2, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_2022_JP_2_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_JP_2_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_JP_2_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_JP_2_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_JP_2___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlISO_2022_JP_2_methods[] = {
	PHP_ME(TPlISO_2022_JP_2, GetCategory, arginfo_TPlISO_2022_JP_2_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_2022_JP_2, GetDescription, arginfo_TPlISO_2022_JP_2_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_2022_JP_2, ClassType, arginfo_TPlISO_2022_JP_2_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlISO_2022_JP_2, __construct, arginfo_TPlISO_2022_JP_2___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TPlISO_2022_JP_2(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlISO_2022_JP_2_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlISO_2022_JP_2", TPlISO_2022_JP_2_methods);
	if (NULL == TPlCustomISO_2022Charset_ce_ptr)
		Register_TPlCustomISO_2022Charset(TSRMLS_C);
	TPlISO_2022_JP_2_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlCustomISO_2022Charset_ce_ptr);
}

zend_class_entry *TPlGBK_ce_ptr = NULL;

SB_PHP_METHOD(TPlGBK, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlGBK_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1635215067, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGBK, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlGBK_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1518437264, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGBK, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlGBK_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGBK, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlGBK_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGBK, CreateShift)
{
	sb_zend_long l4Shift;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Shift) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlGBK_CreateShift((int32_t)l4Shift, &hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlMixedCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGBK_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGBK_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGBK_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGBK___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGBK_CreateShift, 0, 0, 1)
	ZEND_ARG_INFO(0, Shift)
ZEND_END_ARG_INFO()

static zend_function_entry TPlGBK_methods[] = {
	PHP_ME(TPlGBK, GetCategory, arginfo_TPlGBK_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlGBK, GetDescription, arginfo_TPlGBK_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlGBK, ClassType, arginfo_TPlGBK_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlGBK, __construct, arginfo_TPlGBK___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TPlGBK, CreateShift, arginfo_TPlGBK_CreateShift, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TPlGBK(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlGBK_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlGBK", TPlGBK_methods);
	if (NULL == TPlMixedCharset_ce_ptr)
		Register_TPlMixedCharset(TSRMLS_C);
	TPlGBK_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlMixedCharset_ce_ptr);
}

zend_class_entry *TPlHZ_GB_2312_ce_ptr = NULL;

SB_PHP_METHOD(TPlHZ_GB_2312, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlHZ_GB_2312_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1509144479, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlHZ_GB_2312, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlHZ_GB_2312_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1627282882, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlHZ_GB_2312, ConvertFromUCS)
{
	sb_zend_long u4Char;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Char) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TPlHZ_GB_2312_ConvertFromUCS(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Char, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlHZ_GB_2312, ConvertToUCS)
{
	uint32_t u4CharRaw = 0;
	zval *oStream;
	zval *zu4Char;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oStream, TStream_ce_ptr, &zu4Char) == SUCCESS) && Z_ISREF_P(zu4Char) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4Char))))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TPlHZ_GB_2312_ConvertToUCS(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), &u4CharRaw, &l4OutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zu4Char), (sb_zend_long)u4CharRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlHZ_GB_2312, ConvertBufferToUCS)
{
	sb_zend_long l4Count;
	SBPointerZValInfo piBuf;
	uint32_t u4CharRaw = 0;
	zend_bool bIsLastChunk;
	zval *zpBuf;
	zval *zu4Char;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlbz", &zpBuf, &l4Count, &bIsLastChunk, &zu4Char) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuf) || SB_IS_ARRAY_TYPE_RP(zpBuf) || SB_IS_NULL_TYPE_RP(zpBuf) || (SB_IS_OBJECT_TYPE_RP(zpBuf) && (Z_OBJCE_P(zpBuf) == TSBPointer_ce_ptr))) && Z_ISREF_P(zu4Char) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4Char))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuf, &piBuf TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TPlHZ_GB_2312_ConvertBufferToUCS(SBGetObjectHandle(getThis() TSRMLS_CC), piBuf.data, (int32_t)l4Count, (int8_t)bIsLastChunk, &u4CharRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuf);
		ZVAL_LONG(Z_REFVAL_P(zu4Char), (sb_zend_long)u4CharRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, bool, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlHZ_GB_2312, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlHZ_GB_2312_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlHZ_GB_2312, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlHZ_GB_2312_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlHZ_GB_2312_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlHZ_GB_2312_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlHZ_GB_2312_ConvertFromUCS, 0, 0, 1)
	ZEND_ARG_INFO(0, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlHZ_GB_2312_ConvertToUCS, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(1, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlHZ_GB_2312_ConvertBufferToUCS, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, IsLastChunk)
	ZEND_ARG_INFO(1, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlHZ_GB_2312_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlHZ_GB_2312___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlHZ_GB_2312_methods[] = {
	PHP_ME(TPlHZ_GB_2312, GetCategory, arginfo_TPlHZ_GB_2312_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlHZ_GB_2312, GetDescription, arginfo_TPlHZ_GB_2312_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlHZ_GB_2312, ConvertFromUCS, arginfo_TPlHZ_GB_2312_ConvertFromUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlHZ_GB_2312, ConvertToUCS, arginfo_TPlHZ_GB_2312_ConvertToUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlHZ_GB_2312, ConvertBufferToUCS, arginfo_TPlHZ_GB_2312_ConvertBufferToUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlHZ_GB_2312, ClassType, arginfo_TPlHZ_GB_2312_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlHZ_GB_2312, __construct, arginfo_TPlHZ_GB_2312___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TPlHZ_GB_2312(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlHZ_GB_2312_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlHZ_GB_2312", TPlHZ_GB_2312_methods);
	if (NULL == TPlMixedCharset_ce_ptr)
		Register_TPlMixedCharset(TSRMLS_C);
	TPlHZ_GB_2312_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlMixedCharset_ce_ptr);
}

zend_class_entry *TPlGB_18030Code_ce_ptr = NULL;

SB_PHP_METHOD(TPlGB_18030Code, CanConvert)
{
	sb_zend_long u4Char;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Char) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TPlGB_18030Code_CanConvert(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Char, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGB_18030Code, ConvertFromUCS)
{
	sb_zend_long u4Char;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Char) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TPlGB_18030Code_ConvertFromUCS(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Char, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGB_18030Code, ConvertToUCS)
{
	uint32_t u4CharRaw = 0;
	zval *oStream;
	zval *zu4Char;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oStream, TStream_ce_ptr, &zu4Char) == SUCCESS) && Z_ISREF_P(zu4Char) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4Char))))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TPlGB_18030Code_ConvertToUCS(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), &u4CharRaw, &l4OutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zu4Char), (sb_zend_long)u4CharRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGB_18030Code, ConvertBufferToUCS)
{
	sb_zend_long l4Count;
	SBPointerZValInfo piBuf;
	uint32_t u4CharRaw = 0;
	zend_bool bIsLastChunk;
	zval *zpBuf;
	zval *zu4Char;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlbz", &zpBuf, &l4Count, &bIsLastChunk, &zu4Char) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuf) || SB_IS_ARRAY_TYPE_RP(zpBuf) || SB_IS_NULL_TYPE_RP(zpBuf) || (SB_IS_OBJECT_TYPE_RP(zpBuf) && (Z_OBJCE_P(zpBuf) == TSBPointer_ce_ptr))) && Z_ISREF_P(zu4Char) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4Char))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuf, &piBuf TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TPlGB_18030Code_ConvertBufferToUCS(SBGetObjectHandle(getThis() TSRMLS_CC), piBuf.data, (int32_t)l4Count, (int8_t)bIsLastChunk, &u4CharRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuf);
		ZVAL_LONG(Z_REFVAL_P(zu4Char), (sb_zend_long)u4CharRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, bool, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGB_18030Code, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlGB_18030Code_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGB_18030Code, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlGB_18030Code_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGB_18030Code, CreateShift)
{
	sb_zend_long l4Shift;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Shift) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlGB_18030Code_CreateShift((int32_t)l4Shift, &hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGB_18030Code, CreateNoInit)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlGB_18030Code_CreateNoInit(&hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGB_18030Code, CreateForFinalize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlGB_18030Code_CreateForFinalize(&hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGB_18030Code_CanConvert, 0, 0, 1)
	ZEND_ARG_INFO(0, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGB_18030Code_ConvertFromUCS, 0, 0, 1)
	ZEND_ARG_INFO(0, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGB_18030Code_ConvertToUCS, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(1, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGB_18030Code_ConvertBufferToUCS, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, IsLastChunk)
	ZEND_ARG_INFO(1, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGB_18030Code_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGB_18030Code___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGB_18030Code_CreateShift, 0, 0, 1)
	ZEND_ARG_INFO(0, Shift)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGB_18030Code_CreateNoInit, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGB_18030Code_CreateForFinalize, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlGB_18030Code_methods[] = {
	PHP_ME(TPlGB_18030Code, CanConvert, arginfo_TPlGB_18030Code_CanConvert, ZEND_ACC_PUBLIC)
	PHP_ME(TPlGB_18030Code, ConvertFromUCS, arginfo_TPlGB_18030Code_ConvertFromUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlGB_18030Code, ConvertToUCS, arginfo_TPlGB_18030Code_ConvertToUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlGB_18030Code, ConvertBufferToUCS, arginfo_TPlGB_18030Code_ConvertBufferToUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlGB_18030Code, ClassType, arginfo_TPlGB_18030Code_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlGB_18030Code, __construct, arginfo_TPlGB_18030Code___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TPlGB_18030Code, CreateShift, arginfo_TPlGB_18030Code_CreateShift, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlGB_18030Code, CreateNoInit, arginfo_TPlGB_18030Code_CreateNoInit, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlGB_18030Code, CreateForFinalize, arginfo_TPlGB_18030Code_CreateForFinalize, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TPlGB_18030Code(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlGB_18030Code_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlGB_18030Code", TPlGB_18030Code_methods);
	if (NULL == TPlCharset_ce_ptr)
		Register_TPlCharset(TSRMLS_C);
	TPlGB_18030Code_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlCharset_ce_ptr);
}

zend_class_entry *TPlGB_18030_ce_ptr = NULL;

SB_PHP_METHOD(TPlGB_18030, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlGB_18030_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-250530226, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGB_18030, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlGB_18030_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2140005922, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGB_18030, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlGB_18030_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGB_18030, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlGB_18030_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlGB_18030, CreateShift)
{
	sb_zend_long l4Shift;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Shift) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlGB_18030_CreateShift((int32_t)l4Shift, &hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlMixedCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGB_18030_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGB_18030_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGB_18030_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGB_18030___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlGB_18030_CreateShift, 0, 0, 1)
	ZEND_ARG_INFO(0, Shift)
ZEND_END_ARG_INFO()

static zend_function_entry TPlGB_18030_methods[] = {
	PHP_ME(TPlGB_18030, GetCategory, arginfo_TPlGB_18030_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlGB_18030, GetDescription, arginfo_TPlGB_18030_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlGB_18030, ClassType, arginfo_TPlGB_18030_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlGB_18030, __construct, arginfo_TPlGB_18030___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TPlGB_18030, CreateShift, arginfo_TPlGB_18030_CreateShift, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TPlGB_18030(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlGB_18030_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlGB_18030", TPlGB_18030_methods);
	if (NULL == TPlMixedCharset_ce_ptr)
		Register_TPlMixedCharset(TSRMLS_C);
	TPlGB_18030_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlMixedCharset_ce_ptr);
}

zend_class_entry *TPlISO_2022_CN_ce_ptr = NULL;

SB_PHP_METHOD(TPlISO_2022_CN, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlISO_2022_CN_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1616119629, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_CN, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlISO_2022_CN_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-994412746, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_CN, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_2022_CN_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_CN, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_2022_CN_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_CN_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_CN_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_CN_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_CN___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlISO_2022_CN_methods[] = {
	PHP_ME(TPlISO_2022_CN, GetCategory, arginfo_TPlISO_2022_CN_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_2022_CN, GetDescription, arginfo_TPlISO_2022_CN_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_2022_CN, ClassType, arginfo_TPlISO_2022_CN_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlISO_2022_CN, __construct, arginfo_TPlISO_2022_CN___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TPlISO_2022_CN(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlISO_2022_CN_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlISO_2022_CN", TPlISO_2022_CN_methods);
	if (NULL == TPlCustomISO_2022Charset_ce_ptr)
		Register_TPlCustomISO_2022Charset(TSRMLS_C);
	TPlISO_2022_CN_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlCustomISO_2022Charset_ce_ptr);
}

zend_class_entry *TPlISO_2022_CN_EXT_ce_ptr = NULL;

SB_PHP_METHOD(TPlISO_2022_CN_EXT, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlISO_2022_CN_EXT_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-351609082, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_CN_EXT, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlISO_2022_CN_EXT_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1003365846, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_CN_EXT, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_2022_CN_EXT_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_CN_EXT, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_2022_CN_EXT_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_CN_EXT_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_CN_EXT_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_CN_EXT_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_CN_EXT___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlISO_2022_CN_EXT_methods[] = {
	PHP_ME(TPlISO_2022_CN_EXT, GetCategory, arginfo_TPlISO_2022_CN_EXT_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_2022_CN_EXT, GetDescription, arginfo_TPlISO_2022_CN_EXT_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_2022_CN_EXT, ClassType, arginfo_TPlISO_2022_CN_EXT_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlISO_2022_CN_EXT, __construct, arginfo_TPlISO_2022_CN_EXT___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TPlISO_2022_CN_EXT(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlISO_2022_CN_EXT_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlISO_2022_CN_EXT", TPlISO_2022_CN_EXT_methods);
	if (NULL == TPlCustomISO_2022Charset_ce_ptr)
		Register_TPlCustomISO_2022Charset(TSRMLS_C);
	TPlISO_2022_CN_EXT_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlCustomISO_2022Charset_ce_ptr);
}

zend_class_entry *TPlBigFiveHKSCS_ce_ptr = NULL;

SB_PHP_METHOD(TPlBigFiveHKSCS, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlBigFiveHKSCS_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(937782763, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlBigFiveHKSCS, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlBigFiveHKSCS_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(656494424, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlBigFiveHKSCS, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlBigFiveHKSCS_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlBigFiveHKSCS, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlBigFiveHKSCS_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlBigFiveHKSCS, CreateShift)
{
	sb_zend_long l4Shift;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Shift) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlBigFiveHKSCS_CreateShift((int32_t)l4Shift, &hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlMixedCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlBigFiveHKSCS_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlBigFiveHKSCS_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlBigFiveHKSCS_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlBigFiveHKSCS___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlBigFiveHKSCS_CreateShift, 0, 0, 1)
	ZEND_ARG_INFO(0, Shift)
ZEND_END_ARG_INFO()

static zend_function_entry TPlBigFiveHKSCS_methods[] = {
	PHP_ME(TPlBigFiveHKSCS, GetCategory, arginfo_TPlBigFiveHKSCS_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlBigFiveHKSCS, GetDescription, arginfo_TPlBigFiveHKSCS_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlBigFiveHKSCS, ClassType, arginfo_TPlBigFiveHKSCS_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlBigFiveHKSCS, __construct, arginfo_TPlBigFiveHKSCS___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TPlBigFiveHKSCS, CreateShift, arginfo_TPlBigFiveHKSCS_CreateShift, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TPlBigFiveHKSCS(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlBigFiveHKSCS_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlBigFiveHKSCS", TPlBigFiveHKSCS_methods);
	if (NULL == TPlMixedCharset_ce_ptr)
		Register_TPlMixedCharset(TSRMLS_C);
	TPlBigFiveHKSCS_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlMixedCharset_ce_ptr);
}

zend_class_entry *TPlCP950_ce_ptr = NULL;

SB_PHP_METHOD(TPlCP950, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlCP950_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1097557876, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCP950, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlCP950_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(639064894, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCP950, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlCP950_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCP950, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlCP950_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCP950, CreateShift)
{
	sb_zend_long l4Shift;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Shift) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlCP950_CreateShift((int32_t)l4Shift, &hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlMixedCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCP950_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCP950_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCP950_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCP950___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCP950_CreateShift, 0, 0, 1)
	ZEND_ARG_INFO(0, Shift)
ZEND_END_ARG_INFO()

static zend_function_entry TPlCP950_methods[] = {
	PHP_ME(TPlCP950, GetCategory, arginfo_TPlCP950_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlCP950, GetDescription, arginfo_TPlCP950_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlCP950, ClassType, arginfo_TPlCP950_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlCP950, __construct, arginfo_TPlCP950___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TPlCP950, CreateShift, arginfo_TPlCP950_CreateShift, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TPlCP950(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlCP950_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlCP950", TPlCP950_methods);
	if (NULL == TPlMixedCharset_ce_ptr)
		Register_TPlMixedCharset(TSRMLS_C);
	TPlCP950_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlMixedCharset_ce_ptr);
}

zend_class_entry *TPlCNS_11643_ce_ptr = NULL;

SB_PHP_METHOD(TPlCNS_11643, ConvertFromUCS)
{
	sb_zend_long u4Char;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Char) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TPlCNS_11643_ConvertFromUCS(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Char, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCNS_11643, ConvertToUCS)
{
	uint32_t u4CharRaw = 0;
	zval *oStream;
	zval *zu4Char;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oStream, TStream_ce_ptr, &zu4Char) == SUCCESS) && Z_ISREF_P(zu4Char) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4Char))))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TPlCNS_11643_ConvertToUCS(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), &u4CharRaw, &l4OutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zu4Char), (sb_zend_long)u4CharRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCNS_11643, ConvertBufferToUCS)
{
	sb_zend_long l4Count;
	SBPointerZValInfo piBuf;
	uint32_t u4CharRaw = 0;
	zend_bool bIsLastChunk;
	zval *zpBuf;
	zval *zu4Char;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlbz", &zpBuf, &l4Count, &bIsLastChunk, &zu4Char) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuf) || SB_IS_ARRAY_TYPE_RP(zpBuf) || SB_IS_NULL_TYPE_RP(zpBuf) || (SB_IS_OBJECT_TYPE_RP(zpBuf) && (Z_OBJCE_P(zpBuf) == TSBPointer_ce_ptr))) && Z_ISREF_P(zu4Char) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4Char))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuf, &piBuf TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TPlCNS_11643_ConvertBufferToUCS(SBGetObjectHandle(getThis() TSRMLS_CC), piBuf.data, (int32_t)l4Count, (int8_t)bIsLastChunk, &u4CharRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuf);
		ZVAL_LONG(Z_REFVAL_P(zu4Char), (sb_zend_long)u4CharRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, bool, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCNS_11643, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlCNS_11643_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCNS_11643, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlCNS_11643_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCNS_11643, CreateShift)
{
	sb_zend_long l4Shift;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Shift) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlCNS_11643_CreateShift((int32_t)l4Shift, &hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlMixedCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCNS_11643_ConvertFromUCS, 0, 0, 1)
	ZEND_ARG_INFO(0, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCNS_11643_ConvertToUCS, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(1, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCNS_11643_ConvertBufferToUCS, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, IsLastChunk)
	ZEND_ARG_INFO(1, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCNS_11643_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCNS_11643___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCNS_11643_CreateShift, 0, 0, 1)
	ZEND_ARG_INFO(0, Shift)
ZEND_END_ARG_INFO()

static zend_function_entry TPlCNS_11643_methods[] = {
	PHP_ME(TPlCNS_11643, ConvertFromUCS, arginfo_TPlCNS_11643_ConvertFromUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlCNS_11643, ConvertToUCS, arginfo_TPlCNS_11643_ConvertToUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlCNS_11643, ConvertBufferToUCS, arginfo_TPlCNS_11643_ConvertBufferToUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlCNS_11643, ClassType, arginfo_TPlCNS_11643_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlCNS_11643, __construct, arginfo_TPlCNS_11643___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TPlCNS_11643, CreateShift, arginfo_TPlCNS_11643_CreateShift, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TPlCNS_11643(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlCNS_11643_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlCNS_11643", TPlCNS_11643_methods);
	if (NULL == TPlMixedCharset_ce_ptr)
		Register_TPlMixedCharset(TSRMLS_C);
	TPlCNS_11643_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlMixedCharset_ce_ptr);
}

zend_class_entry *TPlEUC_TW_ce_ptr = NULL;

SB_PHP_METHOD(TPlEUC_TW, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlEUC_TW_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2076957903, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlEUC_TW, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlEUC_TW_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1523583355, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlEUC_TW, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlEUC_TW_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlEUC_TW, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlEUC_TW_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlEUC_TW_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlEUC_TW_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlEUC_TW_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlEUC_TW___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlEUC_TW_methods[] = {
	PHP_ME(TPlEUC_TW, GetCategory, arginfo_TPlEUC_TW_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlEUC_TW, GetDescription, arginfo_TPlEUC_TW_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlEUC_TW, ClassType, arginfo_TPlEUC_TW_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlEUC_TW, __construct, arginfo_TPlEUC_TW___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TPlEUC_TW(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlEUC_TW_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlEUC_TW", TPlEUC_TW_methods);
	if (NULL == TPlCustomEUCCharset_ce_ptr)
		Register_TPlCustomEUCCharset(TSRMLS_C);
	TPlEUC_TW_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlCustomEUCCharset_ce_ptr);
}

zend_class_entry *TPlCP949_ce_ptr = NULL;

SB_PHP_METHOD(TPlCP949, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlCP949_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2143405180, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCP949, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlCP949_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(50907790, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCP949, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlCP949_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCP949, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlCP949_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlCP949, CreateShift)
{
	sb_zend_long l4Shift;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Shift) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlCP949_CreateShift((int32_t)l4Shift, &hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlMixedCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCP949_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCP949_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCP949_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCP949___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlCP949_CreateShift, 0, 0, 1)
	ZEND_ARG_INFO(0, Shift)
ZEND_END_ARG_INFO()

static zend_function_entry TPlCP949_methods[] = {
	PHP_ME(TPlCP949, GetCategory, arginfo_TPlCP949_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlCP949, GetDescription, arginfo_TPlCP949_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlCP949, ClassType, arginfo_TPlCP949_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlCP949, __construct, arginfo_TPlCP949___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TPlCP949, CreateShift, arginfo_TPlCP949_CreateShift, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TPlCP949(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlCP949_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlCP949", TPlCP949_methods);
	if (NULL == TPlMixedCharset_ce_ptr)
		Register_TPlMixedCharset(TSRMLS_C);
	TPlCP949_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlMixedCharset_ce_ptr);
}

zend_class_entry *TPlJohabHangul_ce_ptr = NULL;

SB_PHP_METHOD(TPlJohabHangul, CanConvert)
{
	sb_zend_long u4Char;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Char) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TPlJohabHangul_CanConvert(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Char, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlJohabHangul, ConvertFromUCS)
{
	sb_zend_long u4Char;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Char) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TPlJohabHangul_ConvertFromUCS(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Char, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlJohabHangul, ConvertToUCS)
{
	uint32_t u4CharRaw = 0;
	zval *oStream;
	zval *zu4Char;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oStream, TStream_ce_ptr, &zu4Char) == SUCCESS) && Z_ISREF_P(zu4Char) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4Char))))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TPlJohabHangul_ConvertToUCS(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), &u4CharRaw, &l4OutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zu4Char), (sb_zend_long)u4CharRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlJohabHangul, ConvertBufferToUCS)
{
	sb_zend_long l4Count;
	SBPointerZValInfo piBuf;
	uint32_t u4CharRaw = 0;
	zend_bool bIsLastChunk;
	zval *zpBuf;
	zval *zu4Char;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlbz", &zpBuf, &l4Count, &bIsLastChunk, &zu4Char) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuf) || SB_IS_ARRAY_TYPE_RP(zpBuf) || SB_IS_NULL_TYPE_RP(zpBuf) || (SB_IS_OBJECT_TYPE_RP(zpBuf) && (Z_OBJCE_P(zpBuf) == TSBPointer_ce_ptr))) && Z_ISREF_P(zu4Char) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4Char))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuf, &piBuf TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TPlJohabHangul_ConvertBufferToUCS(SBGetObjectHandle(getThis() TSRMLS_CC), piBuf.data, (int32_t)l4Count, (int8_t)bIsLastChunk, &u4CharRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuf);
		ZVAL_LONG(Z_REFVAL_P(zu4Char), (sb_zend_long)u4CharRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, bool, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlJohabHangul, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlJohabHangul_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlJohabHangul, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlJohabHangul_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlJohabHangul, CreateShift)
{
	sb_zend_long l4Shift;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Shift) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlJohabHangul_CreateShift((int32_t)l4Shift, &hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlJohabHangul, CreateNoInit)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlJohabHangul_CreateNoInit(&hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlJohabHangul, CreateForFinalize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlJohabHangul_CreateForFinalize(&hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohabHangul_CanConvert, 0, 0, 1)
	ZEND_ARG_INFO(0, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohabHangul_ConvertFromUCS, 0, 0, 1)
	ZEND_ARG_INFO(0, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohabHangul_ConvertToUCS, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(1, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohabHangul_ConvertBufferToUCS, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Buf, 0, 1)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_INFO(0, IsLastChunk)
	ZEND_ARG_INFO(1, Char)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohabHangul_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohabHangul___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohabHangul_CreateShift, 0, 0, 1)
	ZEND_ARG_INFO(0, Shift)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohabHangul_CreateNoInit, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohabHangul_CreateForFinalize, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlJohabHangul_methods[] = {
	PHP_ME(TPlJohabHangul, CanConvert, arginfo_TPlJohabHangul_CanConvert, ZEND_ACC_PUBLIC)
	PHP_ME(TPlJohabHangul, ConvertFromUCS, arginfo_TPlJohabHangul_ConvertFromUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlJohabHangul, ConvertToUCS, arginfo_TPlJohabHangul_ConvertToUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlJohabHangul, ConvertBufferToUCS, arginfo_TPlJohabHangul_ConvertBufferToUCS, ZEND_ACC_PUBLIC)
	PHP_ME(TPlJohabHangul, ClassType, arginfo_TPlJohabHangul_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlJohabHangul, __construct, arginfo_TPlJohabHangul___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TPlJohabHangul, CreateShift, arginfo_TPlJohabHangul_CreateShift, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlJohabHangul, CreateNoInit, arginfo_TPlJohabHangul_CreateNoInit, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlJohabHangul, CreateForFinalize, arginfo_TPlJohabHangul_CreateForFinalize, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TPlJohabHangul(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlJohabHangul_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlJohabHangul", TPlJohabHangul_methods);
	if (NULL == TPlCharset_ce_ptr)
		Register_TPlCharset(TSRMLS_C);
	TPlJohabHangul_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlCharset_ce_ptr);
}

zend_class_entry *TPlJohabNonHangul_ce_ptr = NULL;

SB_PHP_METHOD(TPlJohabNonHangul, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlJohabNonHangul_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlJohabNonHangul, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlJohabNonHangul_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohabNonHangul_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohabNonHangul___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlJohabNonHangul_methods[] = {
	PHP_ME(TPlJohabNonHangul, ClassType, arginfo_TPlJohabNonHangul_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlJohabNonHangul, __construct, arginfo_TPlJohabNonHangul___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TPlJohabNonHangul(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlJohabNonHangul_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlJohabNonHangul", TPlJohabNonHangul_methods);
	if (NULL == TPlConvertingCharset_ce_ptr)
		Register_TPlConvertingCharset(TSRMLS_C);
	TPlJohabNonHangul_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlConvertingCharset_ce_ptr);
}

zend_class_entry *TPlJohab_ce_ptr = NULL;

SB_PHP_METHOD(TPlJohab, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlJohab_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(264728573, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlJohab, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlJohab_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1787364690, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlJohab, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlJohab_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlJohab, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlJohab_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlJohab, CreateShift)
{
	sb_zend_long l4Shift;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Shift) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlJohab_CreateShift((int32_t)l4Shift, &hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TPlMixedCharset_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohab_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohab_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohab_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohab___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlJohab_CreateShift, 0, 0, 1)
	ZEND_ARG_INFO(0, Shift)
ZEND_END_ARG_INFO()

static zend_function_entry TPlJohab_methods[] = {
	PHP_ME(TPlJohab, GetCategory, arginfo_TPlJohab_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlJohab, GetDescription, arginfo_TPlJohab_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlJohab, ClassType, arginfo_TPlJohab_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlJohab, __construct, arginfo_TPlJohab___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TPlJohab, CreateShift, arginfo_TPlJohab_CreateShift, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TPlJohab(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlJohab_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlJohab", TPlJohab_methods);
	if (NULL == TPlMixedCharset_ce_ptr)
		Register_TPlMixedCharset(TSRMLS_C);
	TPlJohab_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlMixedCharset_ce_ptr);
}

zend_class_entry *TPlEUC_KR_ce_ptr = NULL;

SB_PHP_METHOD(TPlEUC_KR, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlEUC_KR_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1080182059, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlEUC_KR, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlEUC_KR_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1423132429, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlEUC_KR, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlEUC_KR_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlEUC_KR, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlEUC_KR_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlEUC_KR_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlEUC_KR_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlEUC_KR_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlEUC_KR___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlEUC_KR_methods[] = {
	PHP_ME(TPlEUC_KR, GetCategory, arginfo_TPlEUC_KR_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlEUC_KR, GetDescription, arginfo_TPlEUC_KR_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlEUC_KR, ClassType, arginfo_TPlEUC_KR_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlEUC_KR, __construct, arginfo_TPlEUC_KR___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TPlEUC_KR(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlEUC_KR_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlEUC_KR", TPlEUC_KR_methods);
	if (NULL == TPlCustomEUCCharset_ce_ptr)
		Register_TPlCustomEUCCharset(TSRMLS_C);
	TPlEUC_KR_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlCustomEUCCharset_ce_ptr);
}

zend_class_entry *TPlISO_2022_KR_ce_ptr = NULL;

SB_PHP_METHOD(TPlISO_2022_KR, GetCategory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlISO_2022_KR_GetCategory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2113002022, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_KR, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TPlISO_2022_KR_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(830471583, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_KR, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_2022_KR_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TPlISO_2022_KR, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TPlISO_2022_KR_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_KR_GetCategory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_KR_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_KR_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TPlISO_2022_KR___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TPlISO_2022_KR_methods[] = {
	PHP_ME(TPlISO_2022_KR, GetCategory, arginfo_TPlISO_2022_KR_GetCategory, ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_2022_KR, GetDescription, arginfo_TPlISO_2022_KR_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TPlISO_2022_KR, ClassType, arginfo_TPlISO_2022_KR_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TPlISO_2022_KR, __construct, arginfo_TPlISO_2022_KR___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TPlISO_2022_KR(TSRMLS_D)
{
	zend_class_entry ce;
	if (TPlISO_2022_KR_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TPlISO_2022_KR", TPlISO_2022_KR_methods);
	if (NULL == TPlCustomISO_2022Charset_ce_ptr)
		Register_TPlCustomISO_2022Charset(TSRMLS_C);
	TPlISO_2022_KR_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPlCustomISO_2022Charset_ce_ptr);
}

void Register_SBChSCJK_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SShiftJIS, SB_SShiftJIS, SB_SShiftJIS);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SEUC_JP, SB_SEUC_JP, SB_SEUC_JP);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SISO_2022_JP, SB_SISO_2022_JP, SB_SISO_2022_JP);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SISO_2022_JP_1, SB_SISO_2022_JP_1, SB_SISO_2022_JP_1);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SISO_2022_JP_2, SB_SISO_2022_JP_2, SB_SISO_2022_JP_2);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SGBK, SB_SGBK, SB_SGBK);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SHZ_GB_2312, SB_SHZ_GB_2312, SB_SHZ_GB_2312);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SGB_18030, SB_SGB_18030, SB_SGB_18030);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SISO_2022_CN, SB_SISO_2022_CN, SB_SISO_2022_CN);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SISO_2022_CN_EXT, SB_SISO_2022_CN_EXT, SB_SISO_2022_CN_EXT);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SBigFiveHKSCS, SB_SBigFiveHKSCS, SB_SBigFiveHKSCS);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SCP950, SB_SCP950, SB_SCP950);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SEUC_TW, SB_SEUC_TW, SB_SEUC_TW);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SCP949, SB_SCP949, SB_SCP949);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SJohab, SB_SJohab, SB_SJohab);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SEUC_KR, SB_SEUC_KR, SB_SEUC_KR);
	SB_REGISTER_STRING_CONSTANT(SBChSCJK, SISO_2022_KR, SB_SISO_2022_KR, SB_SISO_2022_KR);
}

