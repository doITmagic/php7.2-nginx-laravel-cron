#include "sbcmdsslclient.h"

zend_class_entry *TElCommandSSLClient_ce_ptr = NULL;

SB_PHP_METHOD(TElCommandSSLClient, SendCmd)
{
	char *sCommand;
	sb_str_size sCommand_len;
	SBArrayZValInfo aiAcceptCodes;
	zval *zaAcceptCodes;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sz", &sCommand, &sCommand_len, &zaAcceptCodes) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaAcceptCodes) || SB_IS_NULL_TYPE_RP(zaAcceptCodes)))
	{
		int16_t l2OutResultRaw = 0;
		if (!SBGetInt16ArrayFromZVal(zaAcceptCodes, &aiAcceptCodes TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCommandSSLClient_SendCmd(SBGetObjectHandle(getThis() TSRMLS_CC), sCommand, (int32_t)sCommand_len, aiAcceptCodes.data, aiAcceptCodes.len, &l2OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAcceptCodes);
		RETURN_LONG((sb_zend_long)l2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, array of int16|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSLClient, get_LastReply)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElCommandSSLClient_get_LastReply(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-62805901, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSLClient, get_OnSent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBTextDataEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCommandSSLClient_get_OnSent(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSLClient, set_OnSent)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCommandSSLClient_set_OnSent(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBTextDataEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBTextDataEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSLClient, get_OnReceived)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBTextDataEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCommandSSLClient_get_OnReceived(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSLClient, set_OnReceived)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCommandSSLClient_set_OnReceived(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBTextDataEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBTextDataEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSLClient, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCommandSSLClient_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSLClient_SendCmd, 0, 0, 2)
	ZEND_ARG_INFO(0, Command)
	ZEND_ARG_ARRAY_INFO(0, AcceptCodes, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSLClient_get_LastReply, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSLClient_get_OnSent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSLClient_set_OnSent, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSLClient_get_OnReceived, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSLClient_set_OnReceived, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSLClient___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCommandSSLClient_methods[] = {
	PHP_ME(TElCommandSSLClient, SendCmd, arginfo_TElCommandSSLClient_SendCmd, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSLClient, get_LastReply, arginfo_TElCommandSSLClient_get_LastReply, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSLClient, get_OnSent, arginfo_TElCommandSSLClient_get_OnSent, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSLClient, set_OnSent, arginfo_TElCommandSSLClient_set_OnSent, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSLClient, get_OnReceived, arginfo_TElCommandSSLClient_get_OnReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSLClient, set_OnReceived, arginfo_TElCommandSSLClient_set_OnReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSLClient, __construct, arginfo_TElCommandSSLClient___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCommandSSLClient(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCommandSSLClient_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCommandSSLClient", TElCommandSSLClient_methods);
	if (NULL == TElSimpleSSLClient_ce_ptr)
		Register_TElSimpleSSLClient(TSRMLS_C);
	TElCommandSSLClient_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSimpleSSLClient_ce_ptr);
}

void Register_SBCmdSSLClient_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBCmdSSLClient, ERROR_FACILITY_CMDSSL, SB_ERROR_FACILITY_CMDSSL, SB_ERROR_FACILITY_CMDSSL);
	SB_REGISTER_LONG_CONSTANT(SBCmdSSLClient, ERROR_CMDSSL_ERROR_FLAG, SB_ERROR_CMDSSL_ERROR_FLAG, SB_ERROR_CMDSSL_ERROR_FLAG);
	SB_REGISTER_LONG_CONSTANT(SBCmdSSLClient, SB_CMDSSL_ERROR_INVALID_REPLY, SB_CMDSSL_ERROR_INVALID_REPLY, SB_CMDSSL_ERROR_INVALID_REPLY);
}

void Register_SBCmdSSLClient_Aliases(TSRMLS_D)
{
	if (NULL == TElCommandSSLClient_ce_ptr)
		Register_TElCommandSSLClient(TSRMLS_C);
	zend_register_class_alias("ElCommandSSLClient", TElCommandSSLClient_ce_ptr);
}

