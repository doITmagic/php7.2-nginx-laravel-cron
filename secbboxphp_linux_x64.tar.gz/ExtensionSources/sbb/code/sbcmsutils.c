#include "sbcmsutils.h"

void SB_CALLBACK TSBCMSCertificateNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElCertificateLookupHandle Lookup, TElX509CertificateHandle * Cert)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zLookup;
	zval * zCert;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zLookup, 1);
	SBInitObject(zLookup, TElCertificateLookup_ce_ptr, Lookup TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zCert, 2);
	SBInitObject(zCert, TElX509Certificate_ce_ptr, *Cert TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zLookup);
	*Cert = SBGetObjectHandleCE(zCert, TElX509Certificate_ce_ptr TSRMLS_CC);
	SBDetachObjectHandleIfUniqueZVal(zCert TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zCert);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

