#include "sbcompoundfile.h"

zend_class_entry *TElCompoundFileStorage_ce_ptr = NULL;

SB_PHP_METHOD(TElCompoundFileStorage, CreateNew)
{
	char *sFileName;
	sb_str_size sFileName_len;
	sb_zend_long l4Version;
	zend_bool bOwnStream;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &sFileName, &sFileName_len, &l4Version) == SUCCESS)
	{
		SBCheckError(TElCompoundFileStorage_CreateNew(SBGetObjectHandle(getThis() TSRMLS_CC), sFileName, (int32_t)sFileName_len, (int32_t)l4Version) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStream, TStream_ce_ptr, &l4Version) == SUCCESS)
	{
		SBCheckError(TElCompoundFileStorage_CreateNew_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int32_t)l4Version) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lb", &oStream, TStream_ce_ptr, &l4Version, &bOwnStream) == SUCCESS)
	{
		SBCheckError(TElCompoundFileStorage_CreateNew_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int32_t)l4Version, (int8_t)bOwnStream) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer) or (\\TStream, integer) or (\\TStream, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorage, Open)
{
	char *sFileName;
	sb_str_size sFileName_len;
	zend_bool bOwnStream;
	zend_bool bReadOnly;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sb", &sFileName, &sFileName_len, &bReadOnly) == SUCCESS)
	{
		SBCheckError(TElCompoundFileStorage_Open(SBGetObjectHandle(getThis() TSRMLS_CC), sFileName, (int32_t)sFileName_len, (int8_t)bReadOnly) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCompoundFileStorage_Open_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oStream, TStream_ce_ptr, &bOwnStream) == SUCCESS)
	{
		SBCheckError(TElCompoundFileStorage_Open_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int8_t)bOwnStream) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!bb", &oStream, TStream_ce_ptr, &bOwnStream, &bReadOnly) == SUCCESS)
	{
		SBCheckError(TElCompoundFileStorage_Open_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int8_t)bOwnStream, (int8_t)bReadOnly) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, bool) or (\\TStream) or (\\TStream, bool) or (\\TStream, bool, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorage, Close)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCompoundFileStorage_Close(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorage, Flush)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCompoundFileStorage_Flush(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorage, get_FileVersion)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCompoundFileStorage_get_FileVersion(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorage, get_IsReadOnly)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCompoundFileStorage_get_IsReadOnly(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorage, get_SectorSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCompoundFileStorage_get_SectorSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorage, get_MiniSectorSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCompoundFileStorage_get_MiniSectorSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorage, get_MiniSectorCutoffSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElCompoundFileStorage_get_MiniSectorCutoffSize(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorage, get_RootEntry)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileStorage_get_RootEntry(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCompoundFileStorageEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorage, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileStorage_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorage_CreateNew, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, FileName_or_Stream, 0, 1)
	ZEND_ARG_INFO(0, Version)
	ZEND_ARG_INFO(0, OwnStream)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorage_Open, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, FileName_or_Stream, 0, 1)
	ZEND_ARG_INFO(0, ReadOnly_or_OwnStream)
	ZEND_ARG_INFO(0, ReadOnly)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorage_Close, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorage_Flush, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorage_get_FileVersion, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorage_get_IsReadOnly, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorage_get_SectorSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorage_get_MiniSectorSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorage_get_MiniSectorCutoffSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorage_get_RootEntry, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorage___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElCompoundFileStorage_methods[] = {
	PHP_ME(TElCompoundFileStorage, CreateNew, arginfo_TElCompoundFileStorage_CreateNew, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorage, Open, arginfo_TElCompoundFileStorage_Open, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorage, Close, arginfo_TElCompoundFileStorage_Close, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorage, Flush, arginfo_TElCompoundFileStorage_Flush, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorage, get_FileVersion, arginfo_TElCompoundFileStorage_get_FileVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorage, get_IsReadOnly, arginfo_TElCompoundFileStorage_get_IsReadOnly, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorage, get_SectorSize, arginfo_TElCompoundFileStorage_get_SectorSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorage, get_MiniSectorSize, arginfo_TElCompoundFileStorage_get_MiniSectorSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorage, get_MiniSectorCutoffSize, arginfo_TElCompoundFileStorage_get_MiniSectorCutoffSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorage, get_RootEntry, arginfo_TElCompoundFileStorage_get_RootEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorage, __construct, arginfo_TElCompoundFileStorage___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCompoundFileStorage(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCompoundFileStorage_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCompoundFileStorage", TElCompoundFileStorage_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElCompoundFileStorage_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElCompoundFileCustomEntry_ce_ptr = NULL;

SB_PHP_METHOD(TElCompoundFileCustomEntry, get_Name)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElCompoundFileCustomEntry_get_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(398956327, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileCustomEntry, set_Name)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElCompoundFileCustomEntry_set_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileCustomEntry, get_Parent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileCustomEntry_get_Parent(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCompoundFileStorageEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileCustomEntry, get_Storage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileCustomEntry_get_Storage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCompoundFileStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileCustomEntry, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileCustomEntry_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileCustomEntry_get_Name, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileCustomEntry_set_Name, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileCustomEntry_get_Parent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileCustomEntry_get_Storage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileCustomEntry___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElCompoundFileCustomEntry_methods[] = {
	PHP_ME(TElCompoundFileCustomEntry, get_Name, arginfo_TElCompoundFileCustomEntry_get_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileCustomEntry, set_Name, arginfo_TElCompoundFileCustomEntry_set_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileCustomEntry, get_Parent, arginfo_TElCompoundFileCustomEntry_get_Parent, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileCustomEntry, get_Storage, arginfo_TElCompoundFileCustomEntry_get_Storage, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileCustomEntry, __construct, arginfo_TElCompoundFileCustomEntry___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCompoundFileCustomEntry(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCompoundFileCustomEntry_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCompoundFileCustomEntry", TElCompoundFileCustomEntry_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElCompoundFileCustomEntry_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElCompoundFileStorageEntry_ce_ptr = NULL;

SB_PHP_METHOD(TElCompoundFileStorageEntry, CreateStream)
{
	char *sStreamName;
	sb_str_size sStreamName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sStreamName, &sStreamName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileStorageEntry_CreateStream(SBGetObjectHandle(getThis() TSRMLS_CC), sStreamName, (int32_t)sStreamName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCompoundFileStreamEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, CreateSubStorage)
{
	char *sStorageName;
	sb_str_size sStorageName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sStorageName, &sStorageName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileStorageEntry_CreateSubStorage(SBGetObjectHandle(getThis() TSRMLS_CC), sStorageName, (int32_t)sStorageName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCompoundFileStorageEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, DeleteStream)
{
	char *sStreamName;
	sb_str_size sStreamName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sStreamName, &sStreamName_len) == SUCCESS)
	{
		SBCheckError(TElCompoundFileStorageEntry_DeleteStream(SBGetObjectHandle(getThis() TSRMLS_CC), sStreamName, (int32_t)sStreamName_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, DeleteSubStorage)
{
	char *sStorageName;
	sb_str_size sStorageName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sStorageName, &sStorageName_len) == SUCCESS)
	{
		SBCheckError(TElCompoundFileStorageEntry_DeleteSubStorage(SBGetObjectHandle(getThis() TSRMLS_CC), sStorageName, (int32_t)sStorageName_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, GetStream)
{
	char *sStreamName;
	sb_str_size sStreamName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sStreamName, &sStreamName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileStorageEntry_GetStream(SBGetObjectHandle(getThis() TSRMLS_CC), sStreamName, (int32_t)sStreamName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCompoundFileStreamEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, GetSubStorage)
{
	char *sStorageName;
	sb_str_size sStorageName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sStorageName, &sStorageName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileStorageEntry_GetSubStorage(SBGetObjectHandle(getThis() TSRMLS_CC), sStorageName, (int32_t)sStorageName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCompoundFileStorageEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, FindEntryByName)
{
	char *sEntryName;
	sb_str_size sEntryName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sEntryName, &sEntryName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileStorageEntry_FindEntryByName(SBGetObjectHandle(getThis() TSRMLS_CC), sEntryName, (int32_t)sEntryName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCompoundFileCustomEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, StreamExists)
{
	char *sStreamName;
	sb_str_size sStreamName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sStreamName, &sStreamName_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCompoundFileStorageEntry_StreamExists(SBGetObjectHandle(getThis() TSRMLS_CC), sStreamName, (int32_t)sStreamName_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, SubStorageExists)
{
	char *sStorageName;
	sb_str_size sStorageName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sStorageName, &sStorageName_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCompoundFileStorageEntry_SubStorageExists(SBGetObjectHandle(getThis() TSRMLS_CC), sStorageName, (int32_t)sStorageName_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, GetFirstChild)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileStorageEntry_GetFirstChild(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCompoundFileCustomEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, GetNextEntry)
{
	zval *oLast;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oLast, TElCompoundFileCustomEntry_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileStorageEntry_GetNextEntry(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oLast TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCompoundFileCustomEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCompoundFileCustomEntry)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, get_CLSID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TGuid roOutResult;
		SBCheckError(TElCompoundFileStorageEntry_get_CLSID(SBGetObjectHandle(getThis() TSRMLS_CC), &roOutResult) TSRMLS_CC);
		object_init_ex(return_value, TGuid_ce_ptr);
		SBSetStruct(return_value, &roOutResult, sizeof(TGuid) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, set_CLSID)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oValue, TGuid_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCompoundFileStorageEntry_set_CLSID(SBGetObjectHandle(getThis() TSRMLS_CC), (TGuid *)SBGetStructPointer(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TGuid)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, get_CreationTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElCompoundFileStorageEntry_get_CreationTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, set_CreationTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElCompoundFileStorageEntry_set_CreationTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, get_ModifiedTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElCompoundFileStorageEntry_get_ModifiedTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, set_ModifiedTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElCompoundFileStorageEntry_set_ModifiedTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStorageEntry, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileStorageEntry_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_CreateStream, 0, 0, 1)
	ZEND_ARG_INFO(0, StreamName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_CreateSubStorage, 0, 0, 1)
	ZEND_ARG_INFO(0, StorageName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_DeleteStream, 0, 0, 1)
	ZEND_ARG_INFO(0, StreamName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_DeleteSubStorage, 0, 0, 1)
	ZEND_ARG_INFO(0, StorageName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_GetStream, 0, 0, 1)
	ZEND_ARG_INFO(0, StreamName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_GetSubStorage, 0, 0, 1)
	ZEND_ARG_INFO(0, StorageName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_FindEntryByName, 0, 0, 1)
	ZEND_ARG_INFO(0, EntryName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_StreamExists, 0, 0, 1)
	ZEND_ARG_INFO(0, StreamName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_SubStorageExists, 0, 0, 1)
	ZEND_ARG_INFO(0, StorageName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_GetFirstChild, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_GetNextEntry, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Last, TElCompoundFileCustomEntry, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_get_CLSID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_set_CLSID, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TGuid, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_get_CreationTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_set_CreationTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_get_ModifiedTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry_set_ModifiedTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStorageEntry___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElCompoundFileStorageEntry_methods[] = {
	PHP_ME(TElCompoundFileStorageEntry, CreateStream, arginfo_TElCompoundFileStorageEntry_CreateStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, CreateSubStorage, arginfo_TElCompoundFileStorageEntry_CreateSubStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, DeleteStream, arginfo_TElCompoundFileStorageEntry_DeleteStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, DeleteSubStorage, arginfo_TElCompoundFileStorageEntry_DeleteSubStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, GetStream, arginfo_TElCompoundFileStorageEntry_GetStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, GetSubStorage, arginfo_TElCompoundFileStorageEntry_GetSubStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, FindEntryByName, arginfo_TElCompoundFileStorageEntry_FindEntryByName, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, StreamExists, arginfo_TElCompoundFileStorageEntry_StreamExists, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, SubStorageExists, arginfo_TElCompoundFileStorageEntry_SubStorageExists, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, GetFirstChild, arginfo_TElCompoundFileStorageEntry_GetFirstChild, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, GetNextEntry, arginfo_TElCompoundFileStorageEntry_GetNextEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, get_CLSID, arginfo_TElCompoundFileStorageEntry_get_CLSID, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, set_CLSID, arginfo_TElCompoundFileStorageEntry_set_CLSID, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, get_CreationTime, arginfo_TElCompoundFileStorageEntry_get_CreationTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, set_CreationTime, arginfo_TElCompoundFileStorageEntry_set_CreationTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, get_ModifiedTime, arginfo_TElCompoundFileStorageEntry_get_ModifiedTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, set_ModifiedTime, arginfo_TElCompoundFileStorageEntry_set_ModifiedTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStorageEntry, __construct, arginfo_TElCompoundFileStorageEntry___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCompoundFileStorageEntry(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCompoundFileStorageEntry_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCompoundFileStorageEntry", TElCompoundFileStorageEntry_methods);
	if (NULL == TElCompoundFileCustomEntry_ce_ptr)
		Register_TElCompoundFileCustomEntry(TSRMLS_C);
	TElCompoundFileStorageEntry_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCompoundFileCustomEntry_ce_ptr);
}

zend_class_entry *TElCompoundFileVirtualStream_ce_ptr = NULL;

SB_PHP_METHOD(TElCompoundFileVirtualStream, Flush)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCompoundFileVirtualStream_Flush(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileVirtualStream, Close)
{
	zend_bool bFlushData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCompoundFileVirtualStream_Close(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bFlushData) == SUCCESS)
	{
		SBCheckError(TElCompoundFileVirtualStream_Close_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bFlushData) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileVirtualStream, Read)
{
	sb_zend_long l4Count;
	SBPointerZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Count) == SUCCESS) && ((Z_ISREF_P(zpBuffer) && ((Z_TYPE_P(Z_REFVAL_P(zpBuffer)) == IS_STRING) || (Z_TYPE_P(Z_REFVAL_P(zpBuffer)) == IS_ARRAY) || ((Z_TYPE_P(Z_REFVAL_P(zpBuffer)) == IS_OBJECT) && (Z_OBJCE_P(Z_REFVAL_P(zpBuffer)) == TSBPointer_ce_ptr)))) || ((Z_TYPE_P(zpBuffer) == IS_OBJECT) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCompoundFileVirtualStream_Read(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBSetPointerToZVal(&piBuffer, zpBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileVirtualStream, Write)
{
	sb_zend_long l4Count;
	SBPointerZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCompoundFileVirtualStream_Write(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileVirtualStream, Seek)
{
	sb_zend_long fOrigin;
	sb_zend_long l4Offset;
	sb_zend_long l8Offset;
	sb_zend_long u2Origin;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4Offset, &u2Origin) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCompoundFileVirtualStream_Seek(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Offset, (uint16_t)u2Origin, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l8Offset, &fOrigin) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElCompoundFileVirtualStream_Seek_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Offset, (TSeekOriginRaw)fOrigin, &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer) or (integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileVirtualStream, get_IsMiniStream)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCompoundFileVirtualStream_get_IsMiniStream(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileVirtualStream, __construct)
{
	zval *oStorage;
	zval *oStreamEntry;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStorage, TElCompoundFileStorage_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileVirtualStream_Create(SBGetObjectHandle(oStorage TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oStorage, TElCompoundFileStorage_ce_ptr, &oStreamEntry, TElCompoundFileStreamEntry_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileVirtualStream_Create_1(SBGetObjectHandle(oStorage TSRMLS_CC), SBGetObjectHandle(oStreamEntry TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCompoundFileStorage) or (\\TElCompoundFileStorage, \\TElCompoundFileStreamEntry)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileVirtualStream_Flush, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileVirtualStream_Close, 0, 0, 0)
	ZEND_ARG_INFO(0, FlushData)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileVirtualStream_Read, 0, 0, 2)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileVirtualStream_Write, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileVirtualStream_Seek, 0, 0, 2)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(0, Origin)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileVirtualStream_get_IsMiniStream, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileVirtualStream___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Storage, TElCompoundFileStorage, 1)
	ZEND_ARG_OBJ_INFO(0, StreamEntry, TElCompoundFileStreamEntry, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCompoundFileVirtualStream_methods[] = {
	PHP_ME(TElCompoundFileVirtualStream, Flush, arginfo_TElCompoundFileVirtualStream_Flush, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileVirtualStream, Close, arginfo_TElCompoundFileVirtualStream_Close, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileVirtualStream, Read, arginfo_TElCompoundFileVirtualStream_Read, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileVirtualStream, Write, arginfo_TElCompoundFileVirtualStream_Write, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileVirtualStream, Seek, arginfo_TElCompoundFileVirtualStream_Seek, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileVirtualStream, get_IsMiniStream, arginfo_TElCompoundFileVirtualStream_get_IsMiniStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileVirtualStream, __construct, arginfo_TElCompoundFileVirtualStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCompoundFileVirtualStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCompoundFileVirtualStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCompoundFileVirtualStream", TElCompoundFileVirtualStream_methods);
	if (NULL == TStream_ce_ptr)
		Register_TStream(TSRMLS_C);
	TElCompoundFileVirtualStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TStream_ce_ptr);
}

zend_class_entry *TElCompoundFileTableStream_ce_ptr = NULL;

SB_PHP_METHOD(TElCompoundFileTableStream, Read)
{
	sb_zend_long l4Count;
	SBPointerZValInfo piBuffer;
	uint32_t u4ValueRaw;
	zval *zpBuffer;
	zval *zu4Value;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zu4Value) == SUCCESS) && Z_ISREF_P(zu4Value) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4Value))))
	{
		int32_t l4OutResultRaw = 0;
		u4ValueRaw = (uint32_t)Z_LVAL_P(Z_REFVAL_P(zu4Value));
		SBCheckError(TElCompoundFileTableStream_Read(SBGetObjectHandle(getThis() TSRMLS_CC), &u4ValueRaw, &l4OutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zu4Value), (sb_zend_long)u4ValueRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Count) == SUCCESS) && ((Z_ISREF_P(zpBuffer) && ((Z_TYPE_P(Z_REFVAL_P(zpBuffer)) == IS_STRING) || (Z_TYPE_P(Z_REFVAL_P(zpBuffer)) == IS_ARRAY) || ((Z_TYPE_P(Z_REFVAL_P(zpBuffer)) == IS_OBJECT) && (Z_OBJCE_P(Z_REFVAL_P(zpBuffer)) == TSBPointer_ce_ptr)))) || ((Z_TYPE_P(zpBuffer) == IS_OBJECT) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCompoundFileTableStream_Read_1(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBSetPointerToZVal(&piBuffer, zpBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(&integer) or (\\TSBPointer|array of byte|string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileTableStream, Write)
{
	sb_zend_long l4Count;
	sb_zend_long u4Value;
	SBPointerZValInfo piBuffer;
	zval *zpBuffer;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCompoundFileTableStream_Write(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCompoundFileTableStream_Write_1(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer) or (\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileTableStream, __construct)
{
	zval *oStorage;
	zval *oStreamEntry;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStorage, TElCompoundFileStorage_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileTableStream_Create(SBGetObjectHandle(oStorage TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oStorage, TElCompoundFileStorage_ce_ptr, &oStreamEntry, TElCompoundFileStreamEntry_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileTableStream_Create_1(SBGetObjectHandle(oStorage TSRMLS_CC), SBGetObjectHandle(oStreamEntry TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCompoundFileStorage) or (\\TElCompoundFileStorage, \\TElCompoundFileStreamEntry)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileTableStream_Read, 0, 0, 1)
	ZEND_ARG_INFO(1, Value_or_Buffer)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileTableStream_Write, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value_or_Buffer, 0, 1)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileTableStream___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Storage, TElCompoundFileStorage, 1)
	ZEND_ARG_OBJ_INFO(0, StreamEntry, TElCompoundFileStreamEntry, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCompoundFileTableStream_methods[] = {
	PHP_ME(TElCompoundFileTableStream, Read, arginfo_TElCompoundFileTableStream_Read, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileTableStream, Write, arginfo_TElCompoundFileTableStream_Write, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileTableStream, __construct, arginfo_TElCompoundFileTableStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCompoundFileTableStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCompoundFileTableStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCompoundFileTableStream", TElCompoundFileTableStream_methods);
	if (NULL == TElCompoundFileVirtualStream_ce_ptr)
		Register_TElCompoundFileVirtualStream(TSRMLS_C);
	TElCompoundFileTableStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCompoundFileVirtualStream_ce_ptr);
}

zend_class_entry *TElCompoundFileDirectoryStream_ce_ptr = NULL;

SB_PHP_METHOD(TElCompoundFileDirectoryStream, Read)
{
	sb_zend_long l4Count;
	SBPointerZValInfo piBuffer;
	zval *oValue;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oValue, TSBCompoundFileDirectoryEntry_ce_ptr) == SUCCESS) && SB_ISREF_STRUCT_P(oValue))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCompoundFileDirectoryStream_Read(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBCompoundFileDirectoryEntry *)SBGetStructPointer(oValue TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Count) == SUCCESS) && ((Z_ISREF_P(zpBuffer) && ((Z_TYPE_P(Z_REFVAL_P(zpBuffer)) == IS_STRING) || (Z_TYPE_P(Z_REFVAL_P(zpBuffer)) == IS_ARRAY) || ((Z_TYPE_P(Z_REFVAL_P(zpBuffer)) == IS_OBJECT) && (Z_OBJCE_P(Z_REFVAL_P(zpBuffer)) == TSBPointer_ce_ptr)))) || ((Z_TYPE_P(zpBuffer) == IS_OBJECT) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCompoundFileDirectoryStream_Read_1(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBSetPointerToZVal(&piBuffer, zpBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(&\\TSBCompoundFileDirectoryEntry) or (\\TSBPointer|array of byte|string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileDirectoryStream, Write)
{
	sb_zend_long l4Count;
	SBPointerZValInfo piBuffer;
	zval *oValue;
	zval *zpBuffer;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oValue, TSBCompoundFileDirectoryEntry_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCompoundFileDirectoryStream_Write(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBCompoundFileDirectoryEntry *)SBGetStructPointer(oValue TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCompoundFileDirectoryStream_Write_1(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCompoundFileDirectoryEntry) or (\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileDirectoryStream, __construct)
{
	zval *oStorage;
	zval *oStreamEntry;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStorage, TElCompoundFileStorage_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileDirectoryStream_Create(SBGetObjectHandle(oStorage TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oStorage, TElCompoundFileStorage_ce_ptr, &oStreamEntry, TElCompoundFileStreamEntry_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileDirectoryStream_Create_1(SBGetObjectHandle(oStorage TSRMLS_CC), SBGetObjectHandle(oStreamEntry TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCompoundFileStorage) or (\\TElCompoundFileStorage, \\TElCompoundFileStreamEntry)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileDirectoryStream_Read, 0, 0, 1)
	ZEND_ARG_INFO(1, Value_or_Buffer)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileDirectoryStream_Write, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value_or_Buffer, 0, 1)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileDirectoryStream___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Storage, TElCompoundFileStorage, 1)
	ZEND_ARG_OBJ_INFO(0, StreamEntry, TElCompoundFileStreamEntry, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCompoundFileDirectoryStream_methods[] = {
	PHP_ME(TElCompoundFileDirectoryStream, Read, arginfo_TElCompoundFileDirectoryStream_Read, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileDirectoryStream, Write, arginfo_TElCompoundFileDirectoryStream_Write, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileDirectoryStream, __construct, arginfo_TElCompoundFileDirectoryStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCompoundFileDirectoryStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCompoundFileDirectoryStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCompoundFileDirectoryStream", TElCompoundFileDirectoryStream_methods);
	if (NULL == TElCompoundFileVirtualStream_ce_ptr)
		Register_TElCompoundFileVirtualStream(TSRMLS_C);
	TElCompoundFileDirectoryStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCompoundFileVirtualStream_ce_ptr);
}

zend_class_entry *TElCompoundFileStreamEntry_ce_ptr = NULL;

SB_PHP_METHOD(TElCompoundFileStreamEntry, get_Stream)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileStreamEntry_get_Stream(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCompoundFileVirtualStream_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCompoundFileStreamEntry, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCompoundFileStreamEntry_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStreamEntry_get_Stream, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCompoundFileStreamEntry___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElCompoundFileStreamEntry_methods[] = {
	PHP_ME(TElCompoundFileStreamEntry, get_Stream, arginfo_TElCompoundFileStreamEntry_get_Stream, ZEND_ACC_PUBLIC)
	PHP_ME(TElCompoundFileStreamEntry, __construct, arginfo_TElCompoundFileStreamEntry___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCompoundFileStreamEntry(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCompoundFileStreamEntry_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCompoundFileStreamEntry", TElCompoundFileStreamEntry_methods);
	if (NULL == TElCompoundFileCustomEntry_ce_ptr)
		Register_TElCompoundFileCustomEntry(TSRMLS_C);
	TElCompoundFileStreamEntry_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCompoundFileCustomEntry_ce_ptr);
}

SB_PHP_FUNCTION(SBCompoundFile, IsValidDirectoryEntryName)
{
	char *sEntryName;
	sb_str_size sEntryName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sEntryName, &sEntryName_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBCompoundFile_IsValidDirectoryEntryName(sEntryName, (int32_t)sEntryName_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBCompoundFile, CompareDirectoryEntryNames)
{
	char *sX;
	char *sY;
	sb_str_size sX_len;
	sb_str_size sY_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sX, &sX_len, &sY, &sY_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBCompoundFile_CompareDirectoryEntryNames(sX, (int32_t)sX_len, sY, (int32_t)sY_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBCompoundFile, CopyStorage)
{
	zval *oDestStorage;
	zval *oSourceStorage;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oSourceStorage, TElCompoundFileStorageEntry_ce_ptr, &oDestStorage, TElCompoundFileStorageEntry_ce_ptr) == SUCCESS)
	{
		SBCheckError(SBCompoundFile_CopyStorage(SBGetObjectHandle(oSourceStorage TSRMLS_CC), SBGetObjectHandle(oDestStorage TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCompoundFileStorageEntry, \\TElCompoundFileStorageEntry)" TSRMLS_CC);
	}
}

