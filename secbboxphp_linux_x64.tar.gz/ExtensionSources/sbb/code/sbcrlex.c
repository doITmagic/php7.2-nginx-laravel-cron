#include "sbcrlex.h"

zend_class_entry *TElCertificateRevocationListEx_ce_ptr = NULL;

SB_PHP_METHOD(TElCertificateRevocationListEx, SaveToBuffer)
{
	int32_t l4SizeRaw;
	SBArrayZValInfo piBuffer;
	zval *oCertificate;
	zval *zl4Size;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzO!", &zpBuffer, &zl4Size, &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElCertificateRevocationListEx_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, SBGetObjectHandle(oCertificate TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zpBuffer, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElCertificateRevocationListEx_SaveToBuffer_1(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, &integer, \\TElX509Certificate) or (\\TSBPointer|array of byte|string|NULL, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateRevocationListEx, SaveToBufferPEM)
{
	char *sPassphrase;
	int32_t l4SizeRaw;
	sb_str_size sPassphrase_len;
	SBArrayZValInfo aiBuffer;
	SBArrayZValInfo piBuffer;
	uint32_t _err;
	zval *oCertificate;
	zval *zaBuffer;
	zval *zl4Size;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzO!s", &zpBuffer, &zl4Size, &oCertificate, TElX509Certificate_ce_ptr, &sPassphrase, &sPassphrase_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElCertificateRevocationListEx_SaveToBufferPEM(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, SBGetObjectHandle(oCertificate TSRMLS_CC), sPassphrase, (int32_t)sPassphrase_len, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!s", &zaBuffer, &oCertificate, TElX509Certificate_ce_ptr, &sPassphrase, &sPassphrase_len) == SUCCESS) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))))
	{
		int32_t l4OutResultRaw = 0;
		SBInitArrayZValInfo(&aiBuffer);
		_err = TElCertificateRevocationListEx_SaveToBufferPEM_1(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, &aiBuffer.len, SBGetObjectHandle(oCertificate TSRMLS_CC), sPassphrase, (int32_t)sPassphrase_len, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-597021365, 1, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzs", &zpBuffer, &zl4Size, &sPassphrase, &sPassphrase_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElCertificateRevocationListEx_SaveToBufferPEM_2(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, sPassphrase, (int32_t)sPassphrase_len, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, &integer, \\TElX509Certificate, string) or (&array of byte|string, \\TElX509Certificate, string) or (\\TSBPointer|array of byte|string|NULL, &integer, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateRevocationListEx, SaveToStream)
{
	zval *oCertificate;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oStream, TStream_ce_ptr, &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCertificateRevocationListEx_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, \\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateRevocationListEx, SaveToStreamPEM)
{
	char *sPassphrase;
	sb_str_size sPassphrase_len;
	zval *oCertificate;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!s", &oStream, TStream_ce_ptr, &oCertificate, TElX509Certificate_ce_ptr, &sPassphrase, &sPassphrase_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCertificateRevocationListEx_SaveToStreamPEM(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), sPassphrase, (int32_t)sPassphrase_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, \\TElX509Certificate, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateRevocationListEx, get_PreferredHashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCertificateRevocationListEx_get_PreferredHashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateRevocationListEx, set_PreferredHashAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElCertificateRevocationListEx_set_PreferredHashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateRevocationListEx, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCertificateRevocationListEx_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateRevocationListEx_SaveToBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
	ZEND_ARG_OBJ_INFO(0, Certificate, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateRevocationListEx_SaveToBufferPEM, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(1, Buffer, 0, 1)
	ZEND_ARG_TYPE_INFO(1, Size_or_Certificate, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Certificate_or_Passphrase, 0, 1)
	ZEND_ARG_INFO(0, Passphrase)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateRevocationListEx_SaveToStream, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_OBJ_INFO(0, Certificate, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateRevocationListEx_SaveToStreamPEM, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_OBJ_INFO(0, Certificate, TElX509Certificate, 1)
	ZEND_ARG_INFO(0, Passphrase)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateRevocationListEx_get_PreferredHashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateRevocationListEx_set_PreferredHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateRevocationListEx___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCertificateRevocationListEx_methods[] = {
	PHP_ME(TElCertificateRevocationListEx, SaveToBuffer, arginfo_TElCertificateRevocationListEx_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateRevocationListEx, SaveToBufferPEM, arginfo_TElCertificateRevocationListEx_SaveToBufferPEM, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateRevocationListEx, SaveToStream, arginfo_TElCertificateRevocationListEx_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateRevocationListEx, SaveToStreamPEM, arginfo_TElCertificateRevocationListEx_SaveToStreamPEM, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateRevocationListEx, get_PreferredHashAlgorithm, arginfo_TElCertificateRevocationListEx_get_PreferredHashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateRevocationListEx, set_PreferredHashAlgorithm, arginfo_TElCertificateRevocationListEx_set_PreferredHashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateRevocationListEx, __construct, arginfo_TElCertificateRevocationListEx___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCertificateRevocationListEx(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCertificateRevocationListEx_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCertificateRevocationListEx", TElCertificateRevocationListEx_methods);
	if (NULL == TElCertificateRevocationList_ce_ptr)
		Register_TElCertificateRevocationList(TSRMLS_C);
	TElCertificateRevocationListEx_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCertificateRevocationList_ce_ptr);
}

