#include "sbcryptoprovbuiltinex.h"

zend_class_entry *TElBuiltInExtendedCryptoProvider_ce_ptr = NULL;

SB_PHP_METHOD(TElBuiltInExtendedCryptoProvider, GetDefaultInstance)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElBuiltInExtendedCryptoProvider_GetDefaultInstance(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoProvider_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBuiltInExtendedCryptoProvider, SetAsDefault_Inst)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElBuiltInExtendedCryptoProvider_SetAsDefault_1(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBuiltInExtendedCryptoProvider, SetAsDefault)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElBuiltInExtendedCryptoProvider_SetAsDefault() TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBuiltInExtendedCryptoProvider, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElBuiltInExtendedCryptoProvider_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBuiltInExtendedCryptoProvider, __construct)
{
	zval *oAOwner;
	zval *oOptions;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElBuiltInExtendedCryptoProvider_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oOptions, TElCustomCryptoProviderOptions_ce_ptr, &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElBuiltInExtendedCryptoProvider_Create_1(SBGetObjectHandle(oOptions TSRMLS_CC), SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent) or (\\TElCustomCryptoProviderOptions, \\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBuiltInExtendedCryptoProvider_GetDefaultInstance, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBuiltInExtendedCryptoProvider_SetAsDefault_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBuiltInExtendedCryptoProvider_SetAsDefault, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBuiltInExtendedCryptoProvider_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBuiltInExtendedCryptoProvider___construct, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AOwner_or_Options, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElBuiltInExtendedCryptoProvider_methods[] = {
	PHP_ME(TElBuiltInExtendedCryptoProvider, GetDefaultInstance, arginfo_TElBuiltInExtendedCryptoProvider_GetDefaultInstance, ZEND_ACC_PUBLIC)
	PHP_ME(TElBuiltInExtendedCryptoProvider, SetAsDefault_Inst, arginfo_TElBuiltInExtendedCryptoProvider_SetAsDefault_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElBuiltInExtendedCryptoProvider, SetAsDefault, arginfo_TElBuiltInExtendedCryptoProvider_SetAsDefault, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElBuiltInExtendedCryptoProvider, ClassType, arginfo_TElBuiltInExtendedCryptoProvider_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElBuiltInExtendedCryptoProvider, __construct, arginfo_TElBuiltInExtendedCryptoProvider___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElBuiltInExtendedCryptoProvider(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElBuiltInExtendedCryptoProvider_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElBuiltInExtendedCryptoProvider", TElBuiltInExtendedCryptoProvider_methods);
	if (NULL == TElBuiltInCryptoProvider_ce_ptr)
		Register_TElBuiltInCryptoProvider(TSRMLS_C);
	TElBuiltInExtendedCryptoProvider_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElBuiltInCryptoProvider_ce_ptr);
}

zend_class_entry *TElBuiltInExtendedSymmetricCryptoFactory_ce_ptr = NULL;

SB_PHP_METHOD(TElBuiltInExtendedSymmetricCryptoFactory, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElBuiltInExtendedSymmetricCryptoFactory_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBuiltInExtendedSymmetricCryptoFactory___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElBuiltInExtendedSymmetricCryptoFactory_methods[] = {
	PHP_ME(TElBuiltInExtendedSymmetricCryptoFactory, __construct, arginfo_TElBuiltInExtendedSymmetricCryptoFactory___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElBuiltInExtendedSymmetricCryptoFactory(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElBuiltInExtendedSymmetricCryptoFactory_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElBuiltInExtendedSymmetricCryptoFactory", TElBuiltInExtendedSymmetricCryptoFactory_methods);
	if (NULL == TElBuiltInSymmetricCryptoFactory_ce_ptr)
		Register_TElBuiltInSymmetricCryptoFactory(TSRMLS_C);
	TElBuiltInExtendedSymmetricCryptoFactory_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElBuiltInSymmetricCryptoFactory_ce_ptr);
}

zend_class_entry *TElBuiltInIDEASymmetricCrypto_ce_ptr = NULL;

SB_PHP_METHOD(TElBuiltInIDEASymmetricCrypto, InitializeEncryption)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElBuiltInIDEASymmetricCrypto_InitializeEncryption(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBuiltInIDEASymmetricCrypto, InitializeDecryption)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElBuiltInIDEASymmetricCrypto_InitializeDecryption(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBuiltInIDEASymmetricCrypto, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElBuiltInIDEASymmetricCrypto_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBuiltInIDEASymmetricCrypto, __construct)
{
	sb_zend_long fMode;
	sb_zend_long l4AlgID;
	SBArrayZValInfo aiAlgOID;
	zval *zaAlgOID;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4AlgID, &fMode) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElBuiltInIDEASymmetricCrypto_Create((int32_t)l4AlgID, (TSBBuiltInSymmetricCryptoModeRaw)fMode, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaAlgOID, &fMode) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAlgOID) || SB_IS_ARRAY_TYPE_RP(zaAlgOID) || SB_IS_NULL_TYPE_RP(zaAlgOID)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAlgOID, &aiAlgOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElBuiltInIDEASymmetricCrypto_Create_1(aiAlgOID.data, aiAlgOID.len, (TSBBuiltInSymmetricCryptoModeRaw)fMode, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAlgOID);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fMode) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElBuiltInIDEASymmetricCrypto_Create_2((TSBBuiltInSymmetricCryptoModeRaw)fMode, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer) or (array of byte|string|NULL, integer) or (integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBuiltInIDEASymmetricCrypto_InitializeEncryption, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBuiltInIDEASymmetricCrypto_InitializeDecryption, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBuiltInIDEASymmetricCrypto_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBuiltInIDEASymmetricCrypto___construct, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AlgID_or_AlgOID_or_Mode, 0, 1)
	ZEND_ARG_INFO(0, Mode)
ZEND_END_ARG_INFO()

static zend_function_entry TElBuiltInIDEASymmetricCrypto_methods[] = {
	PHP_ME(TElBuiltInIDEASymmetricCrypto, InitializeEncryption, arginfo_TElBuiltInIDEASymmetricCrypto_InitializeEncryption, ZEND_ACC_PUBLIC)
	PHP_ME(TElBuiltInIDEASymmetricCrypto, InitializeDecryption, arginfo_TElBuiltInIDEASymmetricCrypto_InitializeDecryption, ZEND_ACC_PUBLIC)
	PHP_ME(TElBuiltInIDEASymmetricCrypto, ClassType, arginfo_TElBuiltInIDEASymmetricCrypto_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElBuiltInIDEASymmetricCrypto, __construct, arginfo_TElBuiltInIDEASymmetricCrypto___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElBuiltInIDEASymmetricCrypto(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElBuiltInIDEASymmetricCrypto_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElBuiltInIDEASymmetricCrypto", TElBuiltInIDEASymmetricCrypto_methods);
	if (NULL == TElBuiltInSymmetricCrypto_ce_ptr)
		Register_TElBuiltInSymmetricCrypto(TSRMLS_C);
	TElBuiltInIDEASymmetricCrypto_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElBuiltInSymmetricCrypto_ce_ptr);
}

SB_PHP_FUNCTION(SBCryptoProvBuiltInEx, BuiltInCryptoProviderEx)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(SBCryptoProvBuiltInEx_BuiltInCryptoProviderEx(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoProvider_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

