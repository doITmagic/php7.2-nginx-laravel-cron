#include "sbdefs.h"
#ifdef SB_WINDOWS
#include "sbcryptoprovcardpiv.h"

zend_class_entry *TElPIVCardCryptoProviderOptions_ce_ptr = NULL;

SB_PHP_METHOD(TElPIVCardCryptoProviderOptions, Assign)
{
	zval *oOptions;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOptions, TElCustomCryptoProviderOptions_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoProviderOptions_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oOptions TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoProviderOptions)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProviderOptions, get_UseForPublicKeyOperations)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoProviderOptions_get_UseForPublicKeyOperations(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProviderOptions, set_UseForPublicKeyOperations)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoProviderOptions_set_UseForPublicKeyOperations(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProviderOptions, get_UseForSymmetricKeyOperations)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoProviderOptions_get_UseForSymmetricKeyOperations(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProviderOptions, set_UseForSymmetricKeyOperations)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoProviderOptions_set_UseForSymmetricKeyOperations(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProviderOptions, get_UseForHashingOperations)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoProviderOptions_get_UseForHashingOperations(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProviderOptions, set_UseForHashingOperations)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoProviderOptions_set_UseForHashingOperations(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProviderOptions, get_UseForNonPrivateOperations)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoProviderOptions_get_UseForNonPrivateOperations(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProviderOptions, set_UseForNonPrivateOperations)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoProviderOptions_set_UseForNonPrivateOperations(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProviderOptions, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPIVCardCryptoProviderOptions_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProviderOptions_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Options, TElCustomCryptoProviderOptions, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProviderOptions_get_UseForPublicKeyOperations, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProviderOptions_set_UseForPublicKeyOperations, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProviderOptions_get_UseForSymmetricKeyOperations, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProviderOptions_set_UseForSymmetricKeyOperations, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProviderOptions_get_UseForHashingOperations, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProviderOptions_set_UseForHashingOperations, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProviderOptions_get_UseForNonPrivateOperations, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProviderOptions_set_UseForNonPrivateOperations, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProviderOptions___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPIVCardCryptoProviderOptions_methods[] = {
	PHP_ME(TElPIVCardCryptoProviderOptions, Assign, arginfo_TElPIVCardCryptoProviderOptions_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProviderOptions, get_UseForPublicKeyOperations, arginfo_TElPIVCardCryptoProviderOptions_get_UseForPublicKeyOperations, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProviderOptions, set_UseForPublicKeyOperations, arginfo_TElPIVCardCryptoProviderOptions_set_UseForPublicKeyOperations, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProviderOptions, get_UseForSymmetricKeyOperations, arginfo_TElPIVCardCryptoProviderOptions_get_UseForSymmetricKeyOperations, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProviderOptions, set_UseForSymmetricKeyOperations, arginfo_TElPIVCardCryptoProviderOptions_set_UseForSymmetricKeyOperations, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProviderOptions, get_UseForHashingOperations, arginfo_TElPIVCardCryptoProviderOptions_get_UseForHashingOperations, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProviderOptions, set_UseForHashingOperations, arginfo_TElPIVCardCryptoProviderOptions_set_UseForHashingOperations, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProviderOptions, get_UseForNonPrivateOperations, arginfo_TElPIVCardCryptoProviderOptions_get_UseForNonPrivateOperations, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProviderOptions, set_UseForNonPrivateOperations, arginfo_TElPIVCardCryptoProviderOptions_set_UseForNonPrivateOperations, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProviderOptions, __construct, arginfo_TElPIVCardCryptoProviderOptions___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPIVCardCryptoProviderOptions(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPIVCardCryptoProviderOptions_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPIVCardCryptoProviderOptions", TElPIVCardCryptoProviderOptions_methods);
	if (NULL == TElSmartCardCryptoProviderOptions_ce_ptr)
		Register_TElSmartCardCryptoProviderOptions(TSRMLS_C);
	TElPIVCardCryptoProviderOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSmartCardCryptoProviderOptions_ce_ptr);
}

zend_class_entry *TElPIVCardCryptoProvider_ce_ptr = NULL;

SB_PHP_METHOD(TElPIVCardCryptoProvider, SetAsDefault_Inst)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoProvider_SetAsDefault_1(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProvider, SetAsDefault)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoProvider_SetAsDefault() TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProvider, Clone)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPIVCardCryptoProvider_Clone(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoProvider_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProvider, IsAlgorithmSupported)
{
	sb_zend_long l4Algorithm;
	sb_zend_long l4Mode;
	SBArrayZValInfo aiAlgOID;
	SBArrayZValInfo aiAlgParams;
	zval *zaAlgOID;
	zval *zaAlgParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4Algorithm, &l4Mode) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoProvider_IsAlgorithmSupported(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Algorithm, (int32_t)l4Mode, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzl", &zaAlgOID, &zaAlgParams, &l4Mode) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAlgOID) || SB_IS_ARRAY_TYPE_RP(zaAlgOID) || SB_IS_NULL_TYPE_RP(zaAlgOID)) && (SB_IS_STRING_TYPE_RP(zaAlgParams) || SB_IS_ARRAY_TYPE_RP(zaAlgParams) || SB_IS_NULL_TYPE_RP(zaAlgParams)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaAlgOID, &aiAlgOID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaAlgParams, &aiAlgParams TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoProvider_IsAlgorithmSupported_1(SBGetObjectHandle(getThis() TSRMLS_CC), aiAlgOID.data, aiAlgOID.len, aiAlgParams.data, aiAlgParams.len, (int32_t)l4Mode, &bOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAlgOID);
		SBFreeArrayZValInfo(&aiAlgParams);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer) or (array of byte|string|NULL, array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProvider, IsOperationSupported)
{
	sb_zend_long l4Algorithm;
	sb_zend_long l4Mode;
	sb_zend_long l4Operation;
	SBArrayZValInfo aiAlgOID;
	SBArrayZValInfo aiAlgParams;
	zval *oKey;
	zval *oParams;
	zval *zaAlgOID;
	zval *zaAlgParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lllO!O!", &l4Operation, &l4Algorithm, &l4Mode, &oKey, TElCustomCryptoKey_ce_ptr, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoProvider_IsOperationSupported(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Operation, (int32_t)l4Algorithm, (int32_t)l4Mode, SBGetObjectHandle(oKey TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzzlO!O!", &l4Operation, &zaAlgOID, &zaAlgParams, &l4Mode, &oKey, TElCustomCryptoKey_ce_ptr, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAlgOID) || SB_IS_ARRAY_TYPE_RP(zaAlgOID) || SB_IS_NULL_TYPE_RP(zaAlgOID)) && (SB_IS_STRING_TYPE_RP(zaAlgParams) || SB_IS_ARRAY_TYPE_RP(zaAlgParams) || SB_IS_NULL_TYPE_RP(zaAlgParams)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaAlgOID, &aiAlgOID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaAlgParams, &aiAlgParams TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoProvider_IsOperationSupported_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Operation, aiAlgOID.data, aiAlgOID.len, aiAlgParams.data, aiAlgParams.len, (int32_t)l4Mode, SBGetObjectHandle(oKey TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAlgOID);
		SBFreeArrayZValInfo(&aiAlgParams);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, integer, \\TElCustomCryptoKey, \\TElRelativeDistinguishedName) or (integer, array of byte|string|NULL, array of byte|string|NULL, integer, \\TElCustomCryptoKey, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProvider, RandomInit)
{
	sb_zend_long l4BaseDataSize;
	SBArrayZValInfo piBaseData;
	zval *oParams;
	zval *zpBaseData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlO!", &zpBaseData, &l4BaseDataSize, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBaseData) || SB_IS_ARRAY_TYPE_RP(zpBaseData) || SB_IS_NULL_TYPE_RP(zpBaseData) || (SB_IS_OBJECT_TYPE_RP(zpBaseData) && (Z_OBJCE_P(zpBaseData) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpBaseData, &piBaseData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoProvider_RandomInit(SBGetObjectHandle(getThis() TSRMLS_CC), piBaseData.data, (int32_t)l4BaseDataSize, SBGetObjectHandle(oParams TSRMLS_CC)) TSRMLS_CC);
		SBFreePointerZValInfo(&piBaseData);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProvider, RandomSeed)
{
	sb_zend_long l4DataSize;
	SBArrayZValInfo piData;
	zval *zpData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpData, &l4DataSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpData) || SB_IS_ARRAY_TYPE_RP(zpData) || SB_IS_NULL_TYPE_RP(zpData) || (SB_IS_OBJECT_TYPE_RP(zpData) && (Z_OBJCE_P(zpData) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpData, &piData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoProvider_RandomSeed(SBGetObjectHandle(getThis() TSRMLS_CC), piData.data, (int32_t)l4DataSize) TSRMLS_CC);
		SBFreePointerZValInfo(&piData);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProvider, RandomGenerate)
{
	sb_zend_long l4MaxValue;
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoProvider_RandomGenerate(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4MaxValue) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoProvider_RandomGenerate_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4MaxValue, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer) or (integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProvider, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPIVCardCryptoProvider_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoProvider, __construct)
{
	zval *oAOwner;
	zval *oOptions;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPIVCardCryptoProvider_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oOptions, TElCustomCryptoProviderOptions_ce_ptr, &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPIVCardCryptoProvider_Create_1(SBGetObjectHandle(oOptions TSRMLS_CC), SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent) or (\\TElCustomCryptoProviderOptions, \\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProvider_SetAsDefault_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProvider_SetAsDefault, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProvider_Clone, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProvider_IsAlgorithmSupported, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Algorithm_or_AlgOID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Mode_or_AlgParams, 0, 1)
	ZEND_ARG_INFO(0, Mode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProvider_IsOperationSupported, 0, 0, 5)
	ZEND_ARG_INFO(0, Operation)
	ZEND_ARG_TYPE_INFO(0, Algorithm_or_AlgOID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Mode_or_AlgParams, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Key_or_Mode, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Params_or_Key, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProvider_RandomInit, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, BaseData, 0, 1)
	ZEND_ARG_INFO(0, BaseDataSize)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProvider_RandomSeed, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, DataSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProvider_RandomGenerate, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer_or_MaxValue, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProvider_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoProvider___construct, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AOwner_or_Options, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElPIVCardCryptoProvider_methods[] = {
	PHP_ME(TElPIVCardCryptoProvider, SetAsDefault_Inst, arginfo_TElPIVCardCryptoProvider_SetAsDefault_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProvider, SetAsDefault, arginfo_TElPIVCardCryptoProvider_SetAsDefault, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPIVCardCryptoProvider, Clone, arginfo_TElPIVCardCryptoProvider_Clone, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProvider, IsAlgorithmSupported, arginfo_TElPIVCardCryptoProvider_IsAlgorithmSupported, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProvider, IsOperationSupported, arginfo_TElPIVCardCryptoProvider_IsOperationSupported, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProvider, RandomInit, arginfo_TElPIVCardCryptoProvider_RandomInit, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProvider, RandomSeed, arginfo_TElPIVCardCryptoProvider_RandomSeed, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProvider, RandomGenerate, arginfo_TElPIVCardCryptoProvider_RandomGenerate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoProvider, ClassType, arginfo_TElPIVCardCryptoProvider_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPIVCardCryptoProvider, __construct, arginfo_TElPIVCardCryptoProvider___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPIVCardCryptoProvider(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPIVCardCryptoProvider_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPIVCardCryptoProvider", TElPIVCardCryptoProvider_methods);
	if (NULL == TElSmartCardCryptoProvider_ce_ptr)
		Register_TElSmartCardCryptoProvider(TSRMLS_C);
	TElPIVCardCryptoProvider_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSmartCardCryptoProvider_ce_ptr);
}

zend_class_entry *TElPIVCardCryptoKeyContainer_ce_ptr = NULL;

SB_PHP_METHOD(TElPIVCardCryptoKeyContainer, AcquireKey)
{
	char *sHandle;
	sb_str_size sHandle_len;
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sHandle, &sHandle_len, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPIVCardCryptoKeyContainer_AcquireKey(SBGetObjectHandle(getThis() TSRMLS_CC), sHandle, (int32_t)sHandle_len, SBGetObjectHandle(oParams TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoKey_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKeyContainer, AcquireObject)
{
	char *sHandle;
	sb_str_size sHandle_len;
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sHandle, &sHandle_len, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPIVCardCryptoKeyContainer_AcquireObject(SBGetObjectHandle(getThis() TSRMLS_CC), sHandle, (int32_t)sHandle_len, SBGetObjectHandle(oParams TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKeyContainer, ReleaseObject)
{
	TElClassHandle hoKey;
	zval *oKey;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oKey, TElCustomCryptoObject_ce_ptr) == SUCCESS) && SB_ISREF_OBJECT_P(oKey))
	{
		hoKey = SBGetObjectHandle(oKey TSRMLS_CC);
		SBCheckError(TElPIVCardCryptoKeyContainer_ReleaseObject(SBGetObjectHandle(getThis() TSRMLS_CC), &hoKey) TSRMLS_CC);
		SBUpdateObjectHandle(oKey, hoKey TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(&\\TElCustomCryptoObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKeyContainer, ReleaseKey)
{
	TElClassHandle hoKey;
	zval *oKey;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oKey, TElCustomCryptoKey_ce_ptr) == SUCCESS) && SB_ISREF_OBJECT_P(oKey))
	{
		hoKey = SBGetObjectHandle(oKey TSRMLS_CC);
		SBCheckError(TElPIVCardCryptoKeyContainer_ReleaseKey(SBGetObjectHandle(getThis() TSRMLS_CC), &hoKey) TSRMLS_CC);
		SBUpdateObjectHandle(oKey, hoKey TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(&\\TElCustomCryptoKey)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKeyContainer, AddSymmetricKey)
{
	uint32_t _err;
	zval *oKey;
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oKey, TElCustomCryptoKey_ce_ptr, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPIVCardCryptoKeyContainer_AddSymmetricKey(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKey TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(371021293, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoKey, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKeyContainer, AddPublicKeyPair)
{
	char *sPrivKeyHandle;
	char *sPubKeyHandle;
	int32_t sPrivKeyHandle_len;
	int32_t sPubKeyHandle_len;
	uint32_t _err;
	zval *oParams;
	zval *oPrivKey;
	zval *oPubKey;
	zval *zsPrivKeyHandle;
	zval *zsPubKeyHandle;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zzO!", &oPubKey, TElCustomCryptoKey_ce_ptr, &oPrivKey, TElCustomCryptoKey_ce_ptr, &zsPubKeyHandle, &zsPrivKeyHandle, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS) && Z_ISREF_P(zsPubKeyHandle) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsPubKeyHandle))) && Z_ISREF_P(zsPrivKeyHandle) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsPrivKeyHandle))))
	{
		sPubKeyHandle = Z_STRVAL_P(Z_REFVAL_P(zsPubKeyHandle));
		sPubKeyHandle_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsPubKeyHandle));
		sPrivKeyHandle = Z_STRVAL_P(Z_REFVAL_P(zsPrivKeyHandle));
		sPrivKeyHandle_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsPrivKeyHandle));
		_err = TElPIVCardCryptoKeyContainer_AddPublicKeyPair(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPubKey TSRMLS_CC), SBGetObjectHandle(oPrivKey TSRMLS_CC), sPubKeyHandle, &sPubKeyHandle_len, sPrivKeyHandle, &sPrivKeyHandle_len, SBGetObjectHandle(oParams TSRMLS_CC));
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sPubKeyHandle = emalloc(sPubKeyHandle_len + 1);
			SBCheckError(SBGetLastReturnStringA(1242703088, 3, sPubKeyHandle, &sPubKeyHandle_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsPubKeyHandle));
			sPrivKeyHandle = emalloc(sPrivKeyHandle_len + 1);
			SBCheckError(SBGetLastReturnStringA(1242703088, 4, sPrivKeyHandle, &sPrivKeyHandle_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsPrivKeyHandle));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sPubKeyHandle[sPubKeyHandle_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsPubKeyHandle), sPubKeyHandle, sPubKeyHandle_len);
		sPrivKeyHandle[sPrivKeyHandle_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsPrivKeyHandle), sPrivKeyHandle, sPrivKeyHandle_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoKey, \\TElCustomCryptoKey, &string, &string, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKeyContainer, AddPublicKey)
{
	uint32_t _err;
	zval *oKey;
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oKey, TElCustomCryptoKey_ce_ptr, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPIVCardCryptoKeyContainer_AddPublicKey(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKey TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1709981857, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoKey, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKeyContainer, GenerateSymmetricKey)
{
	sb_zend_long l4Algorithm;
	sb_zend_long l4Bits;
	uint32_t _err;
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llO!", &l4Algorithm, &l4Bits, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPIVCardCryptoKeyContainer_GenerateSymmetricKey(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Algorithm, (int32_t)l4Bits, SBGetObjectHandle(oParams TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(894102955, 4, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKeyContainer, GeneratePublicKeyPair)
{
	char *sPrivKeyHandle;
	char *sPubKeyHandle;
	int32_t sPrivKeyHandle_len;
	int32_t sPubKeyHandle_len;
	sb_zend_long l4Algorithm;
	sb_zend_long l4Bits;
	uint32_t _err;
	zval *oParams;
	zval *zsPrivKeyHandle;
	zval *zsPubKeyHandle;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llzzO!", &l4Algorithm, &l4Bits, &zsPubKeyHandle, &zsPrivKeyHandle, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS) && Z_ISREF_P(zsPubKeyHandle) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsPubKeyHandle))) && Z_ISREF_P(zsPrivKeyHandle) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsPrivKeyHandle))))
	{
		sPubKeyHandle = Z_STRVAL_P(Z_REFVAL_P(zsPubKeyHandle));
		sPubKeyHandle_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsPubKeyHandle));
		sPrivKeyHandle = Z_STRVAL_P(Z_REFVAL_P(zsPrivKeyHandle));
		sPrivKeyHandle_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsPrivKeyHandle));
		_err = TElPIVCardCryptoKeyContainer_GeneratePublicKeyPair(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Algorithm, (int32_t)l4Bits, sPubKeyHandle, &sPubKeyHandle_len, sPrivKeyHandle, &sPrivKeyHandle_len, SBGetObjectHandle(oParams TSRMLS_CC));
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sPubKeyHandle = emalloc(sPubKeyHandle_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2116608634, 3, sPubKeyHandle, &sPubKeyHandle_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsPubKeyHandle));
			sPrivKeyHandle = emalloc(sPrivKeyHandle_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2116608634, 4, sPrivKeyHandle, &sPrivKeyHandle_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsPrivKeyHandle));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sPubKeyHandle[sPubKeyHandle_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsPubKeyHandle), sPubKeyHandle, sPubKeyHandle_len);
		sPrivKeyHandle[sPrivKeyHandle_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsPrivKeyHandle), sPrivKeyHandle, sPrivKeyHandle_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, &string, &string, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKeyContainer, CreateCertificateObject)
{
	sb_zend_long l4Size;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *oParams;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zllO!", &zaData, &l4StartIndex, &l4Size, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = TElPIVCardCryptoKeyContainer_CreateCertificateObject(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, (int32_t)l4StartIndex, (int32_t)l4Size, SBGetObjectHandle(oParams TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(451551069, 5, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, integer, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKeyContainer, CreateDataObject)
{
	sb_zend_long l4Size;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *oParams;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zllO!", &zaData, &l4StartIndex, &l4Size, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = TElPIVCardCryptoKeyContainer_CreateDataObject(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, (int32_t)l4StartIndex, (int32_t)l4Size, SBGetObjectHandle(oParams TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2126190173, 5, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, integer, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKeyContainer, __construct)
{
	zval *oCryptoProvider;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPIVCardCryptoKeyContainer_Create(SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoProvider)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKeyContainer_AcquireKey, 0, 0, 2)
	ZEND_ARG_INFO(0, Handle)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKeyContainer_AcquireObject, 0, 0, 2)
	ZEND_ARG_INFO(0, Handle)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKeyContainer_ReleaseObject, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(1, Key, TElCustomCryptoObject, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKeyContainer_ReleaseKey, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(1, Key, TElCustomCryptoKey, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKeyContainer_AddSymmetricKey, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Key, TElCustomCryptoKey, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKeyContainer_AddPublicKeyPair, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(0, PubKey, TElCustomCryptoKey, 1)
	ZEND_ARG_OBJ_INFO(0, PrivKey, TElCustomCryptoKey, 1)
	ZEND_ARG_INFO(1, PubKeyHandle)
	ZEND_ARG_INFO(1, PrivKeyHandle)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKeyContainer_AddPublicKey, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Key, TElCustomCryptoKey, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKeyContainer_GenerateSymmetricKey, 0, 0, 3)
	ZEND_ARG_INFO(0, Algorithm)
	ZEND_ARG_INFO(0, Bits)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKeyContainer_GeneratePublicKeyPair, 0, 0, 5)
	ZEND_ARG_INFO(0, Algorithm)
	ZEND_ARG_INFO(0, Bits)
	ZEND_ARG_INFO(1, PubKeyHandle)
	ZEND_ARG_INFO(1, PrivKeyHandle)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKeyContainer_CreateCertificateObject, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKeyContainer_CreateDataObject, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKeyContainer___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, CryptoProvider, TElCustomCryptoProvider, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElPIVCardCryptoKeyContainer_methods[] = {
	PHP_ME(TElPIVCardCryptoKeyContainer, AcquireKey, arginfo_TElPIVCardCryptoKeyContainer_AcquireKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKeyContainer, AcquireObject, arginfo_TElPIVCardCryptoKeyContainer_AcquireObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKeyContainer, ReleaseObject, arginfo_TElPIVCardCryptoKeyContainer_ReleaseObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKeyContainer, ReleaseKey, arginfo_TElPIVCardCryptoKeyContainer_ReleaseKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKeyContainer, AddSymmetricKey, arginfo_TElPIVCardCryptoKeyContainer_AddSymmetricKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKeyContainer, AddPublicKeyPair, arginfo_TElPIVCardCryptoKeyContainer_AddPublicKeyPair, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKeyContainer, AddPublicKey, arginfo_TElPIVCardCryptoKeyContainer_AddPublicKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKeyContainer, GenerateSymmetricKey, arginfo_TElPIVCardCryptoKeyContainer_GenerateSymmetricKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKeyContainer, GeneratePublicKeyPair, arginfo_TElPIVCardCryptoKeyContainer_GeneratePublicKeyPair, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKeyContainer, CreateCertificateObject, arginfo_TElPIVCardCryptoKeyContainer_CreateCertificateObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKeyContainer, CreateDataObject, arginfo_TElPIVCardCryptoKeyContainer_CreateDataObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKeyContainer, __construct, arginfo_TElPIVCardCryptoKeyContainer___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPIVCardCryptoKeyContainer(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPIVCardCryptoKeyContainer_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPIVCardCryptoKeyContainer", TElPIVCardCryptoKeyContainer_methods);
	if (NULL == TElSmartCardCryptoKeyContainer_ce_ptr)
		Register_TElSmartCardCryptoKeyContainer(TSRMLS_C);
	TElPIVCardCryptoKeyContainer_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSmartCardCryptoKeyContainer_ce_ptr);
}

zend_class_entry *TElPIVCardCryptoContext_ce_ptr = NULL;

SB_PHP_METHOD(TElPIVCardCryptoContext, EstimateOutputSize)
{
	sb_zend_long l8InSize;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8InSize) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoContext_EstimateOutputSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8InSize, &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoContext, GetContextProp)
{
	SBArrayZValInfo aiDefault;
	SBArrayZValInfo aiPropID;
	uint32_t _err;
	zval *zaDefault;
	zval *zaPropID;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaPropID, &zaDefault) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaPropID) || SB_IS_ARRAY_TYPE_RP(zaPropID) || SB_IS_NULL_TYPE_RP(zaPropID)) && (SB_IS_STRING_TYPE_RP(zaDefault) || SB_IS_ARRAY_TYPE_RP(zaDefault) || SB_IS_NULL_TYPE_RP(zaDefault)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaPropID, &aiPropID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaDefault, &aiDefault TSRMLS_CC)) RETURN_FALSE;
		_err = TElPIVCardCryptoContext_GetContextProp(SBGetObjectHandle(getThis() TSRMLS_CC), aiPropID.data, aiPropID.len, aiDefault.data, aiDefault.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1878453188, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiPropID);
		SBFreeArrayZValInfo(&aiDefault);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoContext, SetContextProp)
{
	SBArrayZValInfo aiPropID;
	SBArrayZValInfo aiValue;
	zval *zaPropID;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaPropID, &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaPropID) || SB_IS_ARRAY_TYPE_RP(zaPropID) || SB_IS_NULL_TYPE_RP(zaPropID)) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaPropID, &aiPropID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoContext_SetContextProp(SBGetObjectHandle(getThis() TSRMLS_CC), aiPropID.data, aiPropID.len, aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiPropID);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoContext, __construct)
{
	sb_zend_long fOperation;
	sb_zend_long l4Algorithm;
	sb_zend_long l4Mode;
	SBArrayZValInfo aiAlgOID;
	SBArrayZValInfo aiAlgParams;
	zval *oKey;
	zval *oParams;
	zval *oProv;
	zval *zaAlgOID;
	zval *zaAlgParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llO!lO!O!", &l4Algorithm, &l4Mode, &oKey, TElCustomCryptoKey_ce_ptr, &fOperation, &oProv, TElCustomCryptoProvider_ce_ptr, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPIVCardCryptoContext_Create((int32_t)l4Algorithm, (int32_t)l4Mode, SBGetObjectHandle(oKey TSRMLS_CC), (TSBSmartCardCryptoContextOperationRaw)fOperation, SBGetObjectHandle(oProv TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzlO!lO!O!", &zaAlgOID, &zaAlgParams, &l4Mode, &oKey, TElCustomCryptoKey_ce_ptr, &fOperation, &oProv, TElCustomCryptoProvider_ce_ptr, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAlgOID) || SB_IS_ARRAY_TYPE_RP(zaAlgOID) || SB_IS_NULL_TYPE_RP(zaAlgOID)) && (SB_IS_STRING_TYPE_RP(zaAlgParams) || SB_IS_ARRAY_TYPE_RP(zaAlgParams) || SB_IS_NULL_TYPE_RP(zaAlgParams)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAlgOID, &aiAlgOID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaAlgParams, &aiAlgParams TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoContext_Create_1(aiAlgOID.data, aiAlgOID.len, aiAlgParams.data, aiAlgParams.len, (int32_t)l4Mode, SBGetObjectHandle(oKey TSRMLS_CC), (TSBSmartCardCryptoContextOperationRaw)fOperation, SBGetObjectHandle(oProv TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAlgOID);
		SBFreeArrayZValInfo(&aiAlgParams);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, \\TElCustomCryptoKey, integer, \\TElCustomCryptoProvider, \\TElRelativeDistinguishedName) or (array of byte|string|NULL, array of byte|string|NULL, integer, \\TElCustomCryptoKey, integer, \\TElCustomCryptoProvider, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoContext_EstimateOutputSize, 0, 0, 1)
	ZEND_ARG_INFO(0, InSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoContext_GetContextProp, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, PropID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Default, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoContext_SetContextProp, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, PropID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoContext___construct, 0, 0, 6)
	ZEND_ARG_TYPE_INFO(0, Algorithm_or_AlgOID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Mode_or_AlgParams, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Key_or_Mode, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Operation_or_Key, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Prov_or_Operation, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Params_or_Prov, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElPIVCardCryptoContext_methods[] = {
	PHP_ME(TElPIVCardCryptoContext, EstimateOutputSize, arginfo_TElPIVCardCryptoContext_EstimateOutputSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoContext, GetContextProp, arginfo_TElPIVCardCryptoContext_GetContextProp, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoContext, SetContextProp, arginfo_TElPIVCardCryptoContext_SetContextProp, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoContext, __construct, arginfo_TElPIVCardCryptoContext___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPIVCardCryptoContext(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPIVCardCryptoContext_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPIVCardCryptoContext", TElPIVCardCryptoContext_methods);
	if (NULL == TElSmartCardCryptoContext_ce_ptr)
		Register_TElSmartCardCryptoContext(TSRMLS_C);
	TElPIVCardCryptoContext_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSmartCardCryptoContext_ce_ptr);
}

zend_class_entry *TElPIVCardCryptoKey_ce_ptr = NULL;

SB_PHP_METHOD(TElPIVCardCryptoKey, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoKey_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, Generate)
{
	sb_zend_long l4Bits;
	SBArrayZValInfo piProgressData;
	void *pzProgressFunc;
	zval *oParams;
	zval *zpProgressData;
	zval *zProgressFunc;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!zz", &l4Bits, &oParams, TElRelativeDistinguishedName_ce_ptr, &zProgressFunc, &zpProgressData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zProgressFunc) || SB_IS_ARRAY_TYPE_RP(zProgressFunc) || SB_IS_CALLABLE_TYPE_RP(zProgressFunc) || SB_IS_NULL_TYPE_RP(zProgressFunc)) && (SB_IS_STRING_TYPE_RP(zpProgressData) || SB_IS_ARRAY_TYPE_RP(zpProgressData) || SB_IS_NULL_TYPE_RP(zpProgressData) || (SB_IS_OBJECT_TYPE_RP(zpProgressData) && (Z_OBJCE_P(zpProgressData) == TSBPointer_ce_ptr))))
	{
		pzProgressFunc = SBSetEventData(zProgressFunc TSRMLS_CC);
		if (!SBGetPointerFromZVal(zpProgressData, &piProgressData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoKey_Generate(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Bits, SBGetObjectHandle(oParams TSRMLS_CC), pzProgressFunc ? &TSBProgressFuncRaw : NULL, pzProgressFunc, piProgressData.data) TSRMLS_CC);
		SBFreePointerZValInfo(&piProgressData);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElRelativeDistinguishedName, \\TSBProgressFunc|callable|NULL, \\TSBPointer|array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, ChangeAlgorithm)
{
	sb_zend_long l4Algorithm;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Algorithm) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoKey_ChangeAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Algorithm) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, ImportPublic)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *oParams;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlO!", &zpBuffer, &l4Size, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoKey_ImportPublic(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, SBGetObjectHandle(oParams TSRMLS_CC)) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, ImportSecret)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *oParams;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlO!", &zpBuffer, &l4Size, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoKey_ImportSecret(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, SBGetObjectHandle(oParams TSRMLS_CC)) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, ExportPublic)
{
	int32_t l4SizeRaw;
	SBArrayZValInfo piBuffer;
	zval *oParams;
	zval *zl4Size;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzO!", &zpBuffer, &zl4Size, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElPIVCardCryptoKey_ExportPublic(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, SBGetObjectHandle(oParams TSRMLS_CC)) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, &integer, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, ExportSecret)
{
	int32_t l4SizeRaw;
	SBArrayZValInfo piBuffer;
	zval *oParams;
	zval *zl4Size;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzO!", &zpBuffer, &zl4Size, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElPIVCardCryptoKey_ExportSecret(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, SBGetObjectHandle(oParams TSRMLS_CC)) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, &integer, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, Clone)
{
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPIVCardCryptoKey_Clone(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoKey_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, ClonePublic)
{
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPIVCardCryptoKey_ClonePublic(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoKey_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, ClearPublic)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoKey_ClearPublic(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, ClearSecret)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoKey_ClearSecret(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, GetKeyProp)
{
	SBArrayZValInfo aiDefault;
	SBArrayZValInfo aiPropID;
	uint32_t _err;
	zval *zaDefault;
	zval *zaPropID;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaPropID, &zaDefault) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaPropID) || SB_IS_ARRAY_TYPE_RP(zaPropID) || SB_IS_NULL_TYPE_RP(zaPropID)) && (SB_IS_STRING_TYPE_RP(zaDefault) || SB_IS_ARRAY_TYPE_RP(zaDefault) || SB_IS_NULL_TYPE_RP(zaDefault)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaPropID, &aiPropID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaDefault, &aiDefault TSRMLS_CC)) RETURN_FALSE;
		_err = TElPIVCardCryptoKey_GetKeyProp(SBGetObjectHandle(getThis() TSRMLS_CC), aiPropID.data, aiPropID.len, aiDefault.data, aiDefault.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-697360156, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiPropID);
		SBFreeArrayZValInfo(&aiDefault);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, SetKeyProp)
{
	SBArrayZValInfo aiPropID;
	SBArrayZValInfo aiValue;
	zval *zaPropID;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaPropID, &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaPropID) || SB_IS_ARRAY_TYPE_RP(zaPropID) || SB_IS_NULL_TYPE_RP(zaPropID)) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaPropID, &aiPropID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoKey_SetKeyProp(SBGetObjectHandle(getThis() TSRMLS_CC), aiPropID.data, aiPropID.len, aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiPropID);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, GetKeyAttribute)
{
	int8_t bProtectedRaw;
	SBArrayZValInfo aiAttrID;
	SBArrayZValInfo aiDefault;
	uint32_t _err;
	zval *zaAttrID;
	zval *zaDefault;
	zval *zbProtected;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzz", &zaAttrID, &zbProtected, &zaDefault) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAttrID) || SB_IS_ARRAY_TYPE_RP(zaAttrID) || SB_IS_NULL_TYPE_RP(zaAttrID)) && Z_ISREF_P(zbProtected) && SB_IS_BOOL_TYPE_P(Z_REFVAL_P(zbProtected)) && (SB_IS_STRING_TYPE_RP(zaDefault) || SB_IS_ARRAY_TYPE_RP(zaDefault) || SB_IS_NULL_TYPE_RP(zaDefault)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaAttrID, &aiAttrID TSRMLS_CC)) RETURN_FALSE;
		bProtectedRaw = (int8_t)SB_BVAL_P(Z_REFVAL_P(zbProtected));
		if (!SBGetByteArrayFromZVal(zaDefault, &aiDefault TSRMLS_CC)) RETURN_FALSE;
		_err = TElPIVCardCryptoKey_GetKeyAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), aiAttrID.data, aiAttrID.len, &bProtectedRaw, aiDefault.data, aiDefault.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-2045411734, 4, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiAttrID);
		ZVAL_BOOL(Z_REFVAL_P(zbProtected), (zend_bool)bProtectedRaw);
		SBFreeArrayZValInfo(&aiDefault);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &bool, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, SetKeyAttribute)
{
	SBArrayZValInfo aiAttrID;
	SBArrayZValInfo aiAttrValue;
	zend_bool bProtected;
	zval *zaAttrID;
	zval *zaAttrValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzb", &zaAttrID, &zaAttrValue, &bProtected) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAttrID) || SB_IS_ARRAY_TYPE_RP(zaAttrID) || SB_IS_NULL_TYPE_RP(zaAttrID)) && (SB_IS_STRING_TYPE_RP(zaAttrValue) || SB_IS_ARRAY_TYPE_RP(zaAttrValue) || SB_IS_NULL_TYPE_RP(zaAttrValue)))
	{
		if (!SBGetByteArrayFromZVal(zaAttrID, &aiAttrID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaAttrValue, &aiAttrValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoKey_SetKeyAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), aiAttrID.data, aiAttrID.len, aiAttrValue.data, aiAttrValue.len, (int8_t)bProtected) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAttrID);
		SBFreeArrayZValInfo(&aiAttrValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, array of byte|string|NULL, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, PrepareForEncryption)
{
	zend_bool bMultiUse;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bMultiUse) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoKey_PrepareForEncryption(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bMultiUse) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, PrepareForSigning)
{
	zend_bool bMultiUse;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bMultiUse) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoKey_PrepareForSigning(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bMultiUse) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, CancelPreparation)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoKey_CancelPreparation(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, AsyncOperationFinished)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoKey_AsyncOperationFinished(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, Equals)
{
	zend_bool bPublicOnly;
	zval *oParams;
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!bO!", &oSource, TElCustomCryptoKey_ce_ptr, &bPublicOnly, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoKey_Equals(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC), (int8_t)bPublicOnly, SBGetObjectHandle(oParams TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoKey, bool, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, Matches)
{
	zval *oParams;
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oSource, TElCustomCryptoKey_ce_ptr, &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoKey_Matches(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoKey, \\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, Persistentiate)
{
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoKey_Persistentiate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, Update)
{
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoKey_Update(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, Commit)
{
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoKey_Commit(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, get_KeyID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPIVCardCryptoKey_get_KeyID(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1685011300, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, get_Handle)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
#ifndef CPU64
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoKey_get_Handle(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
#else
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoKey_get_Handle(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
#endif
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoKey, __construct)
{
	zval *oCryptoProvider;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPIVCardCryptoKey_Create(SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoProvider)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_Generate, 0, 0, 4)
	ZEND_ARG_INFO(0, Bits)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
	ZEND_ARG_TYPE_INFO(0, ProgressFunc, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ProgressData, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_ChangeAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_ImportPublic, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_ImportSecret, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_ExportPublic, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_ExportSecret, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_Clone, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_ClonePublic, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_ClearPublic, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_ClearSecret, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_GetKeyProp, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, PropID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Default, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_SetKeyProp, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, PropID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_GetKeyAttribute, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, AttrID, 0, 1)
	ZEND_ARG_INFO(1, Protected)
	ZEND_ARG_TYPE_INFO(0, Default, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_SetKeyAttribute, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, AttrID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AttrValue, 0, 1)
	ZEND_ARG_INFO(0, Protected)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_PrepareForEncryption, 0, 0, 1)
	ZEND_ARG_INFO(0, MultiUse)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_PrepareForSigning, 0, 0, 1)
	ZEND_ARG_INFO(0, MultiUse)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_CancelPreparation, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_AsyncOperationFinished, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_Equals, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomCryptoKey, 1)
	ZEND_ARG_INFO(0, PublicOnly)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_Matches, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomCryptoKey, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_Persistentiate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_Update, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_Commit, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_get_KeyID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey_get_Handle, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoKey___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, CryptoProvider, TElCustomCryptoProvider, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElPIVCardCryptoKey_methods[] = {
	PHP_ME(TElPIVCardCryptoKey, Reset, arginfo_TElPIVCardCryptoKey_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, Generate, arginfo_TElPIVCardCryptoKey_Generate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, ChangeAlgorithm, arginfo_TElPIVCardCryptoKey_ChangeAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, ImportPublic, arginfo_TElPIVCardCryptoKey_ImportPublic, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, ImportSecret, arginfo_TElPIVCardCryptoKey_ImportSecret, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, ExportPublic, arginfo_TElPIVCardCryptoKey_ExportPublic, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, ExportSecret, arginfo_TElPIVCardCryptoKey_ExportSecret, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, Clone, arginfo_TElPIVCardCryptoKey_Clone, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, ClonePublic, arginfo_TElPIVCardCryptoKey_ClonePublic, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, ClearPublic, arginfo_TElPIVCardCryptoKey_ClearPublic, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, ClearSecret, arginfo_TElPIVCardCryptoKey_ClearSecret, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, GetKeyProp, arginfo_TElPIVCardCryptoKey_GetKeyProp, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, SetKeyProp, arginfo_TElPIVCardCryptoKey_SetKeyProp, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, GetKeyAttribute, arginfo_TElPIVCardCryptoKey_GetKeyAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, SetKeyAttribute, arginfo_TElPIVCardCryptoKey_SetKeyAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, PrepareForEncryption, arginfo_TElPIVCardCryptoKey_PrepareForEncryption, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, PrepareForSigning, arginfo_TElPIVCardCryptoKey_PrepareForSigning, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, CancelPreparation, arginfo_TElPIVCardCryptoKey_CancelPreparation, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, AsyncOperationFinished, arginfo_TElPIVCardCryptoKey_AsyncOperationFinished, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, Equals, arginfo_TElPIVCardCryptoKey_Equals, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, Matches, arginfo_TElPIVCardCryptoKey_Matches, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, Persistentiate, arginfo_TElPIVCardCryptoKey_Persistentiate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, Update, arginfo_TElPIVCardCryptoKey_Update, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, Commit, arginfo_TElPIVCardCryptoKey_Commit, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, get_KeyID, arginfo_TElPIVCardCryptoKey_get_KeyID, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, get_Handle, arginfo_TElPIVCardCryptoKey_get_Handle, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoKey, __construct, arginfo_TElPIVCardCryptoKey___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPIVCardCryptoKey(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPIVCardCryptoKey_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPIVCardCryptoKey", TElPIVCardCryptoKey_methods);
	if (NULL == TElSmartCardCryptoKey_ce_ptr)
		Register_TElSmartCardCryptoKey(TSRMLS_C);
	TElPIVCardCryptoKey_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSmartCardCryptoKey_ce_ptr);
}

zend_class_entry *TElPIVCardCryptoObject_ce_ptr = NULL;

SB_PHP_METHOD(TElPIVCardCryptoObject, Clone)
{
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPIVCardCryptoObject_Clone(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoObject_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, Persistentiate)
{
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoObject_Persistentiate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, Update)
{
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoObject_Update(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, Commit)
{
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oParams, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoObject_Commit(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, GetObjectProp)
{
	SBArrayZValInfo aiDefault;
	SBArrayZValInfo aiPropID;
	uint32_t _err;
	zval *zaDefault;
	zval *zaPropID;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaPropID, &zaDefault) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaPropID) || SB_IS_ARRAY_TYPE_RP(zaPropID) || SB_IS_NULL_TYPE_RP(zaPropID)) && (SB_IS_STRING_TYPE_RP(zaDefault) || SB_IS_ARRAY_TYPE_RP(zaDefault) || SB_IS_NULL_TYPE_RP(zaDefault)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaPropID, &aiPropID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaDefault, &aiDefault TSRMLS_CC)) RETURN_FALSE;
		_err = TElPIVCardCryptoObject_GetObjectProp(SBGetObjectHandle(getThis() TSRMLS_CC), aiPropID.data, aiPropID.len, aiDefault.data, aiDefault.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-850274288, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiPropID);
		SBFreeArrayZValInfo(&aiDefault);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, SetObjectProp)
{
	SBArrayZValInfo aiPropID;
	SBArrayZValInfo aiValue;
	zval *zaPropID;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaPropID, &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaPropID) || SB_IS_ARRAY_TYPE_RP(zaPropID) || SB_IS_NULL_TYPE_RP(zaPropID)) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaPropID, &aiPropID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoObject_SetObjectProp(SBGetObjectHandle(getThis() TSRMLS_CC), aiPropID.data, aiPropID.len, aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiPropID);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, GetObjectAttribute)
{
	int8_t bProtectedRaw;
	SBArrayZValInfo aiAttrID;
	SBArrayZValInfo aiDefault;
	uint32_t _err;
	zval *zaAttrID;
	zval *zaDefault;
	zval *zbProtected;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzz", &zaAttrID, &zbProtected, &zaDefault) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAttrID) || SB_IS_ARRAY_TYPE_RP(zaAttrID) || SB_IS_NULL_TYPE_RP(zaAttrID)) && Z_ISREF_P(zbProtected) && SB_IS_BOOL_TYPE_P(Z_REFVAL_P(zbProtected)) && (SB_IS_STRING_TYPE_RP(zaDefault) || SB_IS_ARRAY_TYPE_RP(zaDefault) || SB_IS_NULL_TYPE_RP(zaDefault)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaAttrID, &aiAttrID TSRMLS_CC)) RETURN_FALSE;
		bProtectedRaw = (int8_t)SB_BVAL_P(Z_REFVAL_P(zbProtected));
		if (!SBGetByteArrayFromZVal(zaDefault, &aiDefault TSRMLS_CC)) RETURN_FALSE;
		_err = TElPIVCardCryptoObject_GetObjectAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), aiAttrID.data, aiAttrID.len, &bProtectedRaw, aiDefault.data, aiDefault.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1278119137, 4, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiAttrID);
		ZVAL_BOOL(Z_REFVAL_P(zbProtected), (zend_bool)bProtectedRaw);
		SBFreeArrayZValInfo(&aiDefault);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &bool, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, SetObjectAttribute)
{
	SBArrayZValInfo aiAttrID;
	SBArrayZValInfo aiAttrValue;
	zend_bool bProtected;
	zval *zaAttrID;
	zval *zaAttrValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzb", &zaAttrID, &zaAttrValue, &bProtected) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAttrID) || SB_IS_ARRAY_TYPE_RP(zaAttrID) || SB_IS_NULL_TYPE_RP(zaAttrID)) && (SB_IS_STRING_TYPE_RP(zaAttrValue) || SB_IS_ARRAY_TYPE_RP(zaAttrValue) || SB_IS_NULL_TYPE_RP(zaAttrValue)))
	{
		if (!SBGetByteArrayFromZVal(zaAttrID, &aiAttrID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaAttrValue, &aiAttrValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoObject_SetObjectAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), aiAttrID.data, aiAttrID.len, aiAttrValue.data, aiAttrValue.len, (int8_t)bProtected) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAttrID);
		SBFreeArrayZValInfo(&aiAttrValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, array of byte|string|NULL, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, GetData)
{
	uint32_t _err;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPIVCardCryptoObject_GetData(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(970764473, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoObject_GetData_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, PutData)
{
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiData;
	zval *oData;
	zval *zaData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oData, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPIVCardCryptoObject_PutData(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oData TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaData, &l4StartIndex, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPIVCardCryptoObject_PutData_1(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, (int32_t)l4StartIndex, (int32_t)l4Count) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream) or (array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, get_Handle)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
#ifndef CPU64
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoObject_get_Handle(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
#else
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElPIVCardCryptoObject_get_Handle(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
#endif
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, get_Subject)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPIVCardCryptoObject_get_Subject(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-185387383, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, get_KeyID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPIVCardCryptoObject_get_KeyID(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1671653472, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, get_Issuer)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPIVCardCryptoObject_get_Issuer(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1612580742, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPIVCardCryptoObject, __construct)
{
	zval *oCryptoProvider;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPIVCardCryptoObject_Create(SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoProvider)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_Clone, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_Persistentiate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_Update, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_Commit, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_GetObjectProp, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, PropID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Default, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_SetObjectProp, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, PropID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_GetObjectAttribute, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, AttrID, 0, 1)
	ZEND_ARG_INFO(1, Protected)
	ZEND_ARG_TYPE_INFO(0, Default, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_SetObjectAttribute, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, AttrID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AttrValue, 0, 1)
	ZEND_ARG_INFO(0, Protected)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_GetData, 0, 0, 0)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_PutData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_get_Handle, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_get_Subject, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_get_KeyID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject_get_Issuer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPIVCardCryptoObject___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, CryptoProvider, TElCustomCryptoProvider, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElPIVCardCryptoObject_methods[] = {
	PHP_ME(TElPIVCardCryptoObject, Clone, arginfo_TElPIVCardCryptoObject_Clone, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, Reset, arginfo_TElPIVCardCryptoObject_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, Persistentiate, arginfo_TElPIVCardCryptoObject_Persistentiate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, Update, arginfo_TElPIVCardCryptoObject_Update, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, Commit, arginfo_TElPIVCardCryptoObject_Commit, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, GetObjectProp, arginfo_TElPIVCardCryptoObject_GetObjectProp, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, SetObjectProp, arginfo_TElPIVCardCryptoObject_SetObjectProp, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, GetObjectAttribute, arginfo_TElPIVCardCryptoObject_GetObjectAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, SetObjectAttribute, arginfo_TElPIVCardCryptoObject_SetObjectAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, GetData, arginfo_TElPIVCardCryptoObject_GetData, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, PutData, arginfo_TElPIVCardCryptoObject_PutData, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, get_Handle, arginfo_TElPIVCardCryptoObject_get_Handle, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, get_Subject, arginfo_TElPIVCardCryptoObject_get_Subject, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, get_KeyID, arginfo_TElPIVCardCryptoObject_get_KeyID, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, get_Issuer, arginfo_TElPIVCardCryptoObject_get_Issuer, ZEND_ACC_PUBLIC)
	PHP_ME(TElPIVCardCryptoObject, __construct, arginfo_TElPIVCardCryptoObject___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPIVCardCryptoObject(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPIVCardCryptoObject_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPIVCardCryptoObject", TElPIVCardCryptoObject_methods);
	if (NULL == TElSmartCardCryptoObject_ce_ptr)
		Register_TElSmartCardCryptoObject(TSRMLS_C);
	TElPIVCardCryptoObject_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSmartCardCryptoObject_ce_ptr);
}

SB_PHP_FUNCTION(SBCryptoProvCardPIV, PIVCardCryptoProvider)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(SBCryptoProvCardPIV_PIVCardCryptoProvider(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoProvider_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}
#endif
