#include "sbcustomcertstorage.h"

zend_class_entry *TSBLookupCriterion_ce_ptr = NULL;

zend_class_entry *TSBLookupCriteria_ce_ptr = NULL;

zend_class_entry *TSBLookupOption_ce_ptr = NULL;

zend_class_entry *TSBLookupOptions_ce_ptr = NULL;

zend_class_entry *TSBDateLookupOption_ce_ptr = NULL;

zend_class_entry *TSBDateLookupOptions_ce_ptr = NULL;

zend_class_entry *TSBKeySizeLookupOption_ce_ptr = NULL;

zend_class_entry *TSBKeyUsageLookupOption_ce_ptr = NULL;

zend_class_entry *TSBKeyUsageLookupOptions_ce_ptr = NULL;

zend_class_entry *TSBCertStorageOption_ce_ptr = NULL;

zend_class_entry *TSBCertStorageOptions_ce_ptr = NULL;

void SB_CALLBACK TSBCertificateValidationEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle Certificate, TElCustomCertStorageHandle AdditionalCertificates, TSBCertificateValidityRaw * Validity, TSBCertificateValidityReasonRaw * Reason, int8_t * DoContinue)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(6);
	zval * zSender;
	zval * zCertificate;
	zval * zAdditionalCertificates;
	zval * zValidity;
	zval * zReason;
	zval * zDoContinue;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCertificate, 1);
	SBInitObject(zCertificate, TElX509Certificate_ce_ptr, Certificate TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zAdditionalCertificates, 2);
	SBInitObject(zAdditionalCertificates, TElCustomCertStorage_ce_ptr, AdditionalCertificates TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zValidity, 3);
	ZVAL_LONG(Z_REFVAL_P(zValidity), (sb_zend_long)*Validity);
	SB_EVENT_INIT_ZVAL_REF(zReason, 4);
	ZVAL_LONG(Z_REFVAL_P(zReason), (sb_zend_long)*Reason);
	SB_EVENT_INIT_ZVAL_REF(zDoContinue, 5);
	ZVAL_BOOL(Z_REFVAL_P(zDoContinue), (zend_bool)*DoContinue);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 6, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zCertificate);
	SB_EVENT_CLEAR_ZVAL(zAdditionalCertificates);
	convert_to_long(Z_REFVAL_P(zValidity));
	*Validity = (TSBCertificateValidityRaw)Z_LVAL_P(Z_REFVAL_P(zValidity));
	SB_EVENT_CLEAR_ZVAL(zValidity);
	convert_to_long(Z_REFVAL_P(zReason));
	*Reason = (TSBCertificateValidityReasonRaw)Z_LVAL_P(Z_REFVAL_P(zReason));
	SB_EVENT_CLEAR_ZVAL(zReason);
	convert_to_boolean(Z_REFVAL_P(zDoContinue));
	*DoContinue = (int8_t)SB_BVAL_P(Z_REFVAL_P(zDoContinue));
	SB_EVENT_CLEAR_ZVAL(zDoContinue);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSBFileCertStorageAccessType_ce_ptr = NULL;

zend_class_entry *TSBFileCertStorageSaveOption_ce_ptr = NULL;

zend_class_entry *TSBFileCertStorageSaveOptions_ce_ptr = NULL;

zend_class_entry *TElCustomCertStorage_ce_ptr = NULL;

SB_PHP_METHOD(TElCustomCertStorage, Validate)
{
	TSBCertificateValidityReasonRaw fReasonRaw;
	zend_bool bCheckCACertDates;
	zval *dtValidityMoment;
	zval *oCertificate;
	zval *zfReason;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zO", &oCertificate, TElX509Certificate_ce_ptr, &zfReason, &dtValidityMoment, php_date_get_date_ce()) == SUCCESS) && Z_ISREF_P(zfReason) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zfReason))))
	{
		TSBCertificateValidityRaw fOutResultRaw = 0;
		fReasonRaw = (TSBCertificateValidityReasonRaw)Z_LVAL_P(Z_REFVAL_P(zfReason));
		SBCheckError(TElCustomCertStorage_Validate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &fReasonRaw, SBGetDateTime(dtValidityMoment TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zfReason), (sb_zend_long)fReasonRaw);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zbO", &oCertificate, TElX509Certificate_ce_ptr, &zfReason, &bCheckCACertDates, &dtValidityMoment, php_date_get_date_ce()) == SUCCESS) && Z_ISREF_P(zfReason) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zfReason))))
	{
		TSBCertificateValidityRaw fOutResultRaw = 0;
		fReasonRaw = (TSBCertificateValidityReasonRaw)Z_LVAL_P(Z_REFVAL_P(zfReason));
		SBCheckError(TElCustomCertStorage_Validate_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &fReasonRaw, (int8_t)bCheckCACertDates, SBGetDateTime(dtValidityMoment TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zfReason), (sb_zend_long)fReasonRaw);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, &integer, \\DateTime) or (\\TElX509Certificate, &integer, bool, \\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, Add)
{
	zend_bool bCopyPrivateKey;
	zval *oCertificate;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oCertificate, TElX509Certificate_ce_ptr, &bCopyPrivateKey) == SUCCESS)
	{
		SBCheckError(TElCustomCertStorage_Add(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (int8_t)bCopyPrivateKey) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, Remove)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElCustomCertStorage_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, ExportTo)
{
	zval *oStorage;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStorage, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomCertStorage_ExportTo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStorage TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, LoadFromBufferPKCS7)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCustomCertStorage_LoadFromBufferPKCS7(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, SaveToBufferPKCS7)
{
	int32_t l4SizeRaw;
	SBArrayZValInfo piBuffer;
	zval *zl4Size;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zpBuffer, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElCustomCertStorage_SaveToBufferPKCS7(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, LoadFromStreamPKCS7)
{
	sb_zend_long l4Count;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStream, TStream_ce_ptr, &l4Count) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_LoadFromStreamPKCS7(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, SaveToStreamPKCS7)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_SaveToStreamPKCS7(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, LoadFromBufferPEM)
{
	char *sPassword;
	sb_str_size sPassword_len;
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zls", &zpBuffer, &l4Size, &sPassword, &sPassword_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCustomCertStorage_LoadFromBufferPEM(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, sPassword, (int32_t)sPassword_len, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, SaveToBufferPEM)
{
	char *sPassword;
	int32_t l4SizeRaw;
	sb_str_size sPassword_len;
	sb_zend_long fEncryptionMode;
	sb_zend_long l4EncryptionAlgorithm;
	SBArrayZValInfo piBuffer;
	zval *zl4Size;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzs", &zpBuffer, &zl4Size, &sPassword, &sPassword_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElCustomCertStorage_SaveToBufferPEM(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, sPassword, (int32_t)sPassword_len, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzsll", &zpBuffer, &zl4Size, &sPassword, &sPassword_len, &l4EncryptionAlgorithm, &fEncryptionMode) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElCustomCertStorage_SaveToBufferPEM_1(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, sPassword, (int32_t)sPassword_len, (int32_t)l4EncryptionAlgorithm, (TSBSymmetricCryptoModeRaw)fEncryptionMode, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, &integer, string) or (\\TSBPointer|array of byte|string|NULL, &integer, string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, LoadFromStreamPEM)
{
	char *sPassword;
	sb_str_size sPassword_len;
	sb_zend_long l4Count;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!sl", &oStream, TStream_ce_ptr, &sPassword, &sPassword_len, &l4Count) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_LoadFromStreamPEM(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), sPassword, (int32_t)sPassword_len, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, SaveToStreamPEM)
{
	char *sPassword;
	sb_str_size sPassword_len;
	sb_zend_long fEncryptionMode;
	sb_zend_long l4EncryptionAlgorithm;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!s", &oStream, TStream_ce_ptr, &sPassword, &sPassword_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_SaveToStreamPEM(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), sPassword, (int32_t)sPassword_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!sll", &oStream, TStream_ce_ptr, &sPassword, &sPassword_len, &l4EncryptionAlgorithm, &fEncryptionMode) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_SaveToStreamPEM_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), sPassword, (int32_t)sPassword_len, (int32_t)l4EncryptionAlgorithm, (TSBSymmetricCryptoModeRaw)fEncryptionMode, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, string) or (\\TStream, string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, LoadFromBufferJKS)
{
	char *sPass;
	sb_str_size sPass_len;
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	void *pzOnPasswordNeeded;
	zval *zOnPasswordNeeded;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zslz", &zpBuffer, &sPass, &sPass_len, &l4Size, &zOnPasswordNeeded) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zOnPasswordNeeded) || SB_IS_ARRAY_TYPE_RP(zOnPasswordNeeded) || SB_IS_CALLABLE_TYPE_RP(zOnPasswordNeeded) || SB_IS_NULL_TYPE_RP(zOnPasswordNeeded)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		pzOnPasswordNeeded = SBSetEventData(zOnPasswordNeeded TSRMLS_CC);
		SBCheckError(TElCustomCertStorage_LoadFromBufferJKS(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, sPass, (int32_t)sPass_len, (int32_t)l4Size, pzOnPasswordNeeded ? &TElJKSPasswordEventRaw : NULL, pzOnPasswordNeeded, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, string, integer, \\TElJKSPasswordEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, SaveToBufferJKS)
{
	char *sPass;
	int32_t l4SizeRaw;
	sb_str_size sPass_len;
	SBArrayZValInfo piBuffer;
	zval *zl4Size;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zsz", &zpBuffer, &sPass, &sPass_len, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElCustomCertStorage_SaveToBufferJKS(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, sPass, (int32_t)sPass_len, &l4SizeRaw, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, string, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, SaveToBufferJKSEx)
{
	char *sPass;
	int32_t l4SizeRaw;
	sb_str_size sPass_len;
	SBArrayZValInfo piBuffer;
	void *pzOnAliasNeeded;
	zval *zl4Size;
	zval *zOnAliasNeeded;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zszz", &zpBuffer, &sPass, &sPass_len, &zl4Size, &zOnAliasNeeded) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))) && (SB_IS_STRING_TYPE_RP(zOnAliasNeeded) || SB_IS_ARRAY_TYPE_RP(zOnAliasNeeded) || SB_IS_CALLABLE_TYPE_RP(zOnAliasNeeded) || SB_IS_NULL_TYPE_RP(zOnAliasNeeded)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		pzOnAliasNeeded = SBSetEventData(zOnAliasNeeded TSRMLS_CC);
		SBCheckError(TElCustomCertStorage_SaveToBufferJKSEx(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, sPass, (int32_t)sPass_len, &l4SizeRaw, pzOnAliasNeeded ? &TElJKSAliasNeededEventRaw : NULL, pzOnAliasNeeded, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, string, &integer, \\TElJKSAliasNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, LoadFromStreamJKS)
{
	char *sPass;
	sb_str_size sPass_len;
	sb_zend_long l4Count;
	void *pzOnPasswordNeeded;
	zval *oStream;
	zval *zOnPasswordNeeded;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!slz", &oStream, TStream_ce_ptr, &sPass, &sPass_len, &l4Count, &zOnPasswordNeeded) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zOnPasswordNeeded) || SB_IS_ARRAY_TYPE_RP(zOnPasswordNeeded) || SB_IS_CALLABLE_TYPE_RP(zOnPasswordNeeded) || SB_IS_NULL_TYPE_RP(zOnPasswordNeeded)))
	{
		int8_t bOutResultRaw = 0;
		pzOnPasswordNeeded = SBSetEventData(zOnPasswordNeeded TSRMLS_CC);
		SBCheckError(TElCustomCertStorage_LoadFromStreamJKS(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), sPass, (int32_t)sPass_len, (int32_t)l4Count, pzOnPasswordNeeded ? &TElJKSPasswordEventRaw : NULL, pzOnPasswordNeeded, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, string, integer, \\TElJKSPasswordEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, SaveToStreamJKS)
{
	char *sPass;
	sb_str_size sPass_len;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!s", &oStream, TStream_ce_ptr, &sPass, &sPass_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_SaveToStreamJKS(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), sPass, (int32_t)sPass_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, SaveToStreamJKSEx)
{
	char *sPass;
	sb_str_size sPass_len;
	void *pzOnAliasNeeded;
	zval *oStream;
	zval *zOnAliasNeeded;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!sz", &oStream, TStream_ce_ptr, &sPass, &sPass_len, &zOnAliasNeeded) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zOnAliasNeeded) || SB_IS_ARRAY_TYPE_RP(zOnAliasNeeded) || SB_IS_CALLABLE_TYPE_RP(zOnAliasNeeded) || SB_IS_NULL_TYPE_RP(zOnAliasNeeded)))
	{
		int8_t bOutResultRaw = 0;
		pzOnAliasNeeded = SBSetEventData(zOnAliasNeeded TSRMLS_CC);
		SBCheckError(TElCustomCertStorage_SaveToStreamJKSEx(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), sPass, (int32_t)sPass_len, pzOnAliasNeeded ? &TElJKSAliasNeededEventRaw : NULL, pzOnAliasNeeded, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, string, \\TElJKSAliasNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, LoadFromBufferPFX)
{
	char *sPassword;
	sb_str_size sPassword_len;
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zls", &zpBuffer, &l4Size, &sPassword, &sPassword_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCustomCertStorage_LoadFromBufferPFX(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, sPassword, (int32_t)sPassword_len, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, SaveToBufferPFX)
{
	char *sPassword;
	int32_t l4SizeRaw;
	sb_str_size sPassword_len;
	sb_zend_long l4CertEncryptionAlgorithm;
	sb_zend_long l4KeyEncryptionAlgorithm;
	SBArrayZValInfo piBuffer;
	zval *zl4Size;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzsll", &zpBuffer, &zl4Size, &sPassword, &sPassword_len, &l4KeyEncryptionAlgorithm, &l4CertEncryptionAlgorithm) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElCustomCertStorage_SaveToBufferPFX(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, sPassword, (int32_t)sPassword_len, (int32_t)l4KeyEncryptionAlgorithm, (int32_t)l4CertEncryptionAlgorithm, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzs", &zpBuffer, &zl4Size, &sPassword, &sPassword_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElCustomCertStorage_SaveToBufferPFX_1(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, sPassword, (int32_t)sPassword_len, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, &integer, string, integer, integer) or (\\TSBPointer|array of byte|string|NULL, &integer, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, LoadFromStreamPFX)
{
	char *sPassword;
	sb_str_size sPassword_len;
	sb_zend_long l4Count;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!sl", &oStream, TStream_ce_ptr, &sPassword, &sPassword_len, &l4Count) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_LoadFromStreamPFX(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), sPassword, (int32_t)sPassword_len, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, SaveToStreamPFX)
{
	char *sPassword;
	sb_str_size sPassword_len;
	sb_zend_long l4CertEncryptionAlgorithm;
	sb_zend_long l4KeyEncryptionAlgorithm;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!sll", &oStream, TStream_ce_ptr, &sPassword, &sPassword_len, &l4KeyEncryptionAlgorithm, &l4CertEncryptionAlgorithm) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_SaveToStreamPFX(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), sPassword, (int32_t)sPassword_len, (int32_t)l4KeyEncryptionAlgorithm, (int32_t)l4CertEncryptionAlgorithm, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!s", &oStream, TStream_ce_ptr, &sPassword, &sPassword_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_SaveToStreamPFX_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), sPassword, (int32_t)sPassword_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, string, integer, integer) or (\\TStream, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, LoadFromBufferPkiPath)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCustomCertStorage_LoadFromBufferPkiPath(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, SaveToBufferPkiPath)
{
	int32_t l4SizeRaw;
	SBArrayZValInfo piBuffer;
	zval *zl4Size;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zpBuffer, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElCustomCertStorage_SaveToBufferPkiPath(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, LoadFromStreamPkiPath)
{
	sb_zend_long l4Count;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStream, TStream_ce_ptr, &l4Count) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_LoadFromStreamPkiPath(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int32_t)l4Count, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, SaveToStreamPkiPath)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_SaveToStreamPkiPath(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, BuildChain)
{
	sb_zend_long l4ChainIndex;
	zval *oCertificate;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomCertStorage_BuildChain(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509CertificateChain_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4ChainIndex) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomCertStorage_BuildChain_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4ChainIndex, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509CertificateChain_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate) or (integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, IndexOf)
{
	zval *oCertificate;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_IndexOf(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, IsPresent)
{
	zval *oCertificate;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_IsPresent(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCustomCertStorage_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, FindByHash)
{
	zval *oDigest;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oDigest, TMessageDigest160_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_FindByHash(SBGetObjectHandle(getThis() TSRMLS_CC), (TMessageDigest160 *)SBGetStructPointer(oDigest TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oDigest, TMessageDigest128_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_FindByHash_1(SBGetObjectHandle(getThis() TSRMLS_CC), (TMessageDigest128 *)SBGetStructPointer(oDigest TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TMessageDigest160) or (\\TMessageDigest128)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, GetIssuerCertificate)
{
	zval *oCertificate;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_GetIssuerCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, GetIssuerCertificates)
{
	zend_bool bExcludeDuplicates;
	zval *oCertificate;
	zval *oList;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!b", &oCertificate, TElX509Certificate_ce_ptr, &oList, TList_ce_ptr, &bExcludeDuplicates) == SUCCESS)
	{
		SBCheckError(TElCustomCertStorage_GetIssuerCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), SBGetObjectHandle(oList TSRMLS_CC), (int8_t)bExcludeDuplicates) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TList, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, IsReadOnly_Inst)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_IsReadOnly_1(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, IsReadOnly)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_IsReadOnly(&bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, FindFirst)
{
	zval *oLookup;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oLookup, TElCertificateLookup_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_FindFirst(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oLookup TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCertificateLookup)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, FindNext)
{
	zval *oLookup;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oLookup, TElCertificateLookup_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_FindNext(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oLookup TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCertificateLookup)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, ImportFrom)
{
	zend_bool bImportEndEntity;
	zval *oChain;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oChain, TElX509CertificateChain_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomCertStorage_ImportFrom(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oChain, TElX509CertificateChain_ce_ptr, &bImportEndEntity) == SUCCESS)
	{
		SBCheckError(TElCustomCertStorage_ImportFrom_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oChain TSRMLS_CC), (int8_t)bImportEndEntity) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509CertificateChain) or (\\TElX509CertificateChain, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, BeginRead)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCustomCertStorage_BeginRead(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, Contains)
{
	zval *oCertificate;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_Contains(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, EndRead)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCustomCertStorage_EndRead(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, get_ChainCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_get_ChainCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, get_Certificates)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomCertStorage_get_Certificates(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, get_Chains)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_get_Chains(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, get_CRL)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomCertStorage_get_CRL(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElAbstractCRL_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, set_CRL)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElAbstractCRL_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomCertStorage_set_CRL(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElAbstractCRL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, get_CryptoProviderManager)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomCertStorage_get_CryptoProviderManager(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoProviderManager_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, set_CryptoProviderManager)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCryptoProviderManager_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomCertStorage_set_CryptoProviderManager(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoProviderManager)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, get_Options)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCertStorageOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElCustomCertStorage_get_Options(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, set_Options)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElCustomCertStorage_set_Options(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBCertStorageOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomCertStorage, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomCertStorage_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_Validate, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Certificate, TElX509Certificate, 1)
	ZEND_ARG_INFO(1, Reason)
	ZEND_ARG_INFO(0, ValidityMoment_or_CheckCACertDates)
	ZEND_ARG_OBJ_INFO(0, ValidityMoment, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_Add, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Certificate, 0, 1)
	ZEND_ARG_INFO(0, CopyPrivateKey)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_ExportTo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Storage, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_LoadFromBufferPKCS7, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_SaveToBufferPKCS7, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_LoadFromStreamPKCS7, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_SaveToStreamPKCS7, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_LoadFromBufferPEM, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, Password)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_SaveToBufferPEM, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_INFO(0, EncryptionAlgorithm)
	ZEND_ARG_INFO(0, EncryptionMode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_LoadFromStreamPEM, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_SaveToStreamPEM, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_INFO(0, EncryptionAlgorithm)
	ZEND_ARG_INFO(0, EncryptionMode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_LoadFromBufferJKS, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Pass)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, OnPasswordNeeded, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_SaveToBufferJKS, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Pass)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_SaveToBufferJKSEx, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Pass)
	ZEND_ARG_INFO(1, Size)
	ZEND_ARG_TYPE_INFO(0, OnAliasNeeded, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_LoadFromStreamJKS, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Pass)
	ZEND_ARG_INFO(0, Count)
	ZEND_ARG_TYPE_INFO(0, OnPasswordNeeded, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_SaveToStreamJKS, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Pass)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_SaveToStreamJKSEx, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Pass)
	ZEND_ARG_TYPE_INFO(0, OnAliasNeeded, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_LoadFromBufferPFX, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, Password)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_SaveToBufferPFX, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_INFO(0, KeyEncryptionAlgorithm)
	ZEND_ARG_INFO(0, CertEncryptionAlgorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_LoadFromStreamPFX, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_SaveToStreamPFX, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_INFO(0, KeyEncryptionAlgorithm)
	ZEND_ARG_INFO(0, CertEncryptionAlgorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_LoadFromBufferPkiPath, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_SaveToBufferPkiPath, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_LoadFromStreamPkiPath, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_SaveToStreamPkiPath, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_BuildChain, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Certificate_or_ChainIndex, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_IndexOf, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Certificate, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_IsPresent, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Certificate, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_FindByHash, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Digest, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_GetIssuerCertificate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Certificate, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_GetIssuerCertificates, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Certificate, TElX509Certificate, 1)
	ZEND_ARG_OBJ_INFO(0, List, TList, 1)
	ZEND_ARG_INFO(0, ExcludeDuplicates)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_IsReadOnly_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_IsReadOnly, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_FindFirst, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Lookup, TElCertificateLookup, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_FindNext, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Lookup, TElCertificateLookup, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_ImportFrom, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Chain, TElX509CertificateChain, 1)
	ZEND_ARG_INFO(0, ImportEndEntity)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_BeginRead, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_Contains, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Certificate, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_EndRead, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_get_ChainCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_get_Certificates, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_get_Chains, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_get_CRL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_set_CRL, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElAbstractCRL, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_get_CryptoProviderManager, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_set_CryptoProviderManager, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCryptoProviderManager, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_get_Options, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage_set_Options, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomCertStorage___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCustomCertStorage_methods[] = {
	PHP_ME(TElCustomCertStorage, Validate, arginfo_TElCustomCertStorage_Validate, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, Add, arginfo_TElCustomCertStorage_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, Remove, arginfo_TElCustomCertStorage_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, ExportTo, arginfo_TElCustomCertStorage_ExportTo, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, LoadFromBufferPKCS7, arginfo_TElCustomCertStorage_LoadFromBufferPKCS7, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, SaveToBufferPKCS7, arginfo_TElCustomCertStorage_SaveToBufferPKCS7, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, LoadFromStreamPKCS7, arginfo_TElCustomCertStorage_LoadFromStreamPKCS7, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, SaveToStreamPKCS7, arginfo_TElCustomCertStorage_SaveToStreamPKCS7, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, LoadFromBufferPEM, arginfo_TElCustomCertStorage_LoadFromBufferPEM, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, SaveToBufferPEM, arginfo_TElCustomCertStorage_SaveToBufferPEM, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, LoadFromStreamPEM, arginfo_TElCustomCertStorage_LoadFromStreamPEM, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, SaveToStreamPEM, arginfo_TElCustomCertStorage_SaveToStreamPEM, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, LoadFromBufferJKS, arginfo_TElCustomCertStorage_LoadFromBufferJKS, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, SaveToBufferJKS, arginfo_TElCustomCertStorage_SaveToBufferJKS, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, SaveToBufferJKSEx, arginfo_TElCustomCertStorage_SaveToBufferJKSEx, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, LoadFromStreamJKS, arginfo_TElCustomCertStorage_LoadFromStreamJKS, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, SaveToStreamJKS, arginfo_TElCustomCertStorage_SaveToStreamJKS, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, SaveToStreamJKSEx, arginfo_TElCustomCertStorage_SaveToStreamJKSEx, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, LoadFromBufferPFX, arginfo_TElCustomCertStorage_LoadFromBufferPFX, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, SaveToBufferPFX, arginfo_TElCustomCertStorage_SaveToBufferPFX, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, LoadFromStreamPFX, arginfo_TElCustomCertStorage_LoadFromStreamPFX, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, SaveToStreamPFX, arginfo_TElCustomCertStorage_SaveToStreamPFX, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, LoadFromBufferPkiPath, arginfo_TElCustomCertStorage_LoadFromBufferPkiPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, SaveToBufferPkiPath, arginfo_TElCustomCertStorage_SaveToBufferPkiPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, LoadFromStreamPkiPath, arginfo_TElCustomCertStorage_LoadFromStreamPkiPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, SaveToStreamPkiPath, arginfo_TElCustomCertStorage_SaveToStreamPkiPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, BuildChain, arginfo_TElCustomCertStorage_BuildChain, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, IndexOf, arginfo_TElCustomCertStorage_IndexOf, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, IsPresent, arginfo_TElCustomCertStorage_IsPresent, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, Clear, arginfo_TElCustomCertStorage_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, FindByHash, arginfo_TElCustomCertStorage_FindByHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, GetIssuerCertificate, arginfo_TElCustomCertStorage_GetIssuerCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, GetIssuerCertificates, arginfo_TElCustomCertStorage_GetIssuerCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, IsReadOnly_Inst, arginfo_TElCustomCertStorage_IsReadOnly_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, IsReadOnly, arginfo_TElCustomCertStorage_IsReadOnly, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElCustomCertStorage, FindFirst, arginfo_TElCustomCertStorage_FindFirst, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, FindNext, arginfo_TElCustomCertStorage_FindNext, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, ImportFrom, arginfo_TElCustomCertStorage_ImportFrom, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, BeginRead, arginfo_TElCustomCertStorage_BeginRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, Contains, arginfo_TElCustomCertStorage_Contains, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, EndRead, arginfo_TElCustomCertStorage_EndRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, get_Count, arginfo_TElCustomCertStorage_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, get_ChainCount, arginfo_TElCustomCertStorage_get_ChainCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, get_Certificates, arginfo_TElCustomCertStorage_get_Certificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, get_Chains, arginfo_TElCustomCertStorage_get_Chains, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, get_CRL, arginfo_TElCustomCertStorage_get_CRL, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, set_CRL, arginfo_TElCustomCertStorage_set_CRL, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, get_CryptoProviderManager, arginfo_TElCustomCertStorage_get_CryptoProviderManager, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, set_CryptoProviderManager, arginfo_TElCustomCertStorage_set_CryptoProviderManager, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, get_Options, arginfo_TElCustomCertStorage_get_Options, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, set_Options, arginfo_TElCustomCertStorage_set_Options, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomCertStorage, __construct, arginfo_TElCustomCertStorage___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCustomCertStorage(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCustomCertStorage_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCustomCertStorage", TElCustomCertStorage_methods);
	if (NULL == TElBaseCertStorage_ce_ptr)
		Register_TElBaseCertStorage(TSRMLS_C);
	TElCustomCertStorage_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElBaseCertStorage_ce_ptr);
}

zend_class_entry *TElCertificateLookup_ce_ptr = NULL;

SB_PHP_METHOD(TElCertificateLookup, get_AuthorityKeyIdentifier)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElCertificateLookup_get_AuthorityKeyIdentifier(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1186836801, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_AuthorityKeyIdentifier)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCertificateLookup_set_AuthorityKeyIdentifier(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_SubjectKeyIdentifier)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElCertificateLookup_get_SubjectKeyIdentifier(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1379184985, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_SubjectKeyIdentifier)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCertificateLookup_set_SubjectKeyIdentifier(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_SerialNumber)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElCertificateLookup_get_SerialNumber(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1250502559, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_SerialNumber)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCertificateLookup_set_SerialNumber(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_PublicKeyHash)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElCertificateLookup_get_PublicKeyHash(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-141608244, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_PublicKeyHash)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCertificateLookup_set_PublicKeyHash(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_CertificateHash)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElCertificateLookup_get_CertificateHash(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(490020564, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_CertificateHash)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCertificateLookup_set_CertificateHash(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_Criteria)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBLookupCriteriaRaw fOutResultRaw = 0;
		SBCheckError(TElCertificateLookup_get_Criteria(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_Criteria)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElCertificateLookup_set_Criteria(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBLookupCriteriaRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_Options)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBLookupOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElCertificateLookup_get_Options(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_Options)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElCertificateLookup_set_Options(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBLookupOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_IssuerRDN)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCertificateLookup_get_IssuerRDN(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElRelativeDistinguishedName_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_SubjectRDN)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCertificateLookup_get_SubjectRDN(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElRelativeDistinguishedName_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_ValidFrom)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElCertificateLookup_get_ValidFrom(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_ValidFrom)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElCertificateLookup_set_ValidFrom(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_ValidTo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElCertificateLookup_get_ValidTo(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_ValidTo)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElCertificateLookup_set_ValidTo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_PublicKeyAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCertificateLookup_get_PublicKeyAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_PublicKeyAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElCertificateLookup_set_PublicKeyAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_SignatureAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCertificateLookup_get_SignatureAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_SignatureAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElCertificateLookup_set_SignatureAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_PublicKeySizeMin)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCertificateLookup_get_PublicKeySizeMin(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_PublicKeySizeMin)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElCertificateLookup_set_PublicKeySizeMin(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_PublicKeySizeMax)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCertificateLookup_get_PublicKeySizeMax(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_PublicKeySizeMax)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElCertificateLookup_set_PublicKeySizeMax(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_KeyUsage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBKeyUsageRaw fOutResultRaw = 0;
		SBCheckError(TElCertificateLookup_get_KeyUsage(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_KeyUsage)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElCertificateLookup_set_KeyUsage(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBKeyUsageRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_EmailAddresses)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCertificateLookup_get_EmailAddresses(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_PublicKeyHashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCertificateLookup_get_PublicKeyHashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_PublicKeyHashAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElCertificateLookup_set_PublicKeyHashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_CertificateHashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCertificateLookup_get_CertificateHashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_CertificateHashAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElCertificateLookup_set_CertificateHashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_DateLookupOptions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDateLookupOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElCertificateLookup_get_DateLookupOptions(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_DateLookupOptions)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElCertificateLookup_set_DateLookupOptions(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBDateLookupOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_KeySizeLookupOption)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBKeySizeLookupOptionRaw fOutResultRaw = 0;
		SBCheckError(TElCertificateLookup_get_KeySizeLookupOption(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_KeySizeLookupOption)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElCertificateLookup_set_KeySizeLookupOption(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBKeySizeLookupOptionRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, get_KeyUsageLookupOptions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBKeyUsageLookupOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElCertificateLookup_get_KeyUsageLookupOptions(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, set_KeyUsageLookupOptions)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElCertificateLookup_set_KeyUsageLookupOptions(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBKeyUsageLookupOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateLookup, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCertificateLookup_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_AuthorityKeyIdentifier, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_AuthorityKeyIdentifier, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_SubjectKeyIdentifier, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_SubjectKeyIdentifier, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_SerialNumber, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_SerialNumber, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_PublicKeyHash, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_PublicKeyHash, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_CertificateHash, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_CertificateHash, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_Criteria, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_Criteria, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_Options, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_Options, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_IssuerRDN, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_SubjectRDN, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_ValidFrom, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_ValidFrom, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_ValidTo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_ValidTo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_PublicKeyAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_PublicKeyAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_SignatureAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_SignatureAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_PublicKeySizeMin, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_PublicKeySizeMin, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_PublicKeySizeMax, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_PublicKeySizeMax, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_KeyUsage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_KeyUsage, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_EmailAddresses, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_PublicKeyHashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_PublicKeyHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_CertificateHashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_CertificateHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_DateLookupOptions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_DateLookupOptions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_KeySizeLookupOption, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_KeySizeLookupOption, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_get_KeyUsageLookupOptions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup_set_KeyUsageLookupOptions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateLookup___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCertificateLookup_methods[] = {
	PHP_ME(TElCertificateLookup, get_AuthorityKeyIdentifier, arginfo_TElCertificateLookup_get_AuthorityKeyIdentifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_AuthorityKeyIdentifier, arginfo_TElCertificateLookup_set_AuthorityKeyIdentifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_SubjectKeyIdentifier, arginfo_TElCertificateLookup_get_SubjectKeyIdentifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_SubjectKeyIdentifier, arginfo_TElCertificateLookup_set_SubjectKeyIdentifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_SerialNumber, arginfo_TElCertificateLookup_get_SerialNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_SerialNumber, arginfo_TElCertificateLookup_set_SerialNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_PublicKeyHash, arginfo_TElCertificateLookup_get_PublicKeyHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_PublicKeyHash, arginfo_TElCertificateLookup_set_PublicKeyHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_CertificateHash, arginfo_TElCertificateLookup_get_CertificateHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_CertificateHash, arginfo_TElCertificateLookup_set_CertificateHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_Criteria, arginfo_TElCertificateLookup_get_Criteria, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_Criteria, arginfo_TElCertificateLookup_set_Criteria, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_Options, arginfo_TElCertificateLookup_get_Options, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_Options, arginfo_TElCertificateLookup_set_Options, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_IssuerRDN, arginfo_TElCertificateLookup_get_IssuerRDN, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_SubjectRDN, arginfo_TElCertificateLookup_get_SubjectRDN, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_ValidFrom, arginfo_TElCertificateLookup_get_ValidFrom, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_ValidFrom, arginfo_TElCertificateLookup_set_ValidFrom, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_ValidTo, arginfo_TElCertificateLookup_get_ValidTo, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_ValidTo, arginfo_TElCertificateLookup_set_ValidTo, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_PublicKeyAlgorithm, arginfo_TElCertificateLookup_get_PublicKeyAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_PublicKeyAlgorithm, arginfo_TElCertificateLookup_set_PublicKeyAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_SignatureAlgorithm, arginfo_TElCertificateLookup_get_SignatureAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_SignatureAlgorithm, arginfo_TElCertificateLookup_set_SignatureAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_PublicKeySizeMin, arginfo_TElCertificateLookup_get_PublicKeySizeMin, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_PublicKeySizeMin, arginfo_TElCertificateLookup_set_PublicKeySizeMin, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_PublicKeySizeMax, arginfo_TElCertificateLookup_get_PublicKeySizeMax, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_PublicKeySizeMax, arginfo_TElCertificateLookup_set_PublicKeySizeMax, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_KeyUsage, arginfo_TElCertificateLookup_get_KeyUsage, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_KeyUsage, arginfo_TElCertificateLookup_set_KeyUsage, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_EmailAddresses, arginfo_TElCertificateLookup_get_EmailAddresses, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_PublicKeyHashAlgorithm, arginfo_TElCertificateLookup_get_PublicKeyHashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_PublicKeyHashAlgorithm, arginfo_TElCertificateLookup_set_PublicKeyHashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_CertificateHashAlgorithm, arginfo_TElCertificateLookup_get_CertificateHashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_CertificateHashAlgorithm, arginfo_TElCertificateLookup_set_CertificateHashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_DateLookupOptions, arginfo_TElCertificateLookup_get_DateLookupOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_DateLookupOptions, arginfo_TElCertificateLookup_set_DateLookupOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_KeySizeLookupOption, arginfo_TElCertificateLookup_get_KeySizeLookupOption, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_KeySizeLookupOption, arginfo_TElCertificateLookup_set_KeySizeLookupOption, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, get_KeyUsageLookupOptions, arginfo_TElCertificateLookup_get_KeyUsageLookupOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, set_KeyUsageLookupOptions, arginfo_TElCertificateLookup_set_KeyUsageLookupOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateLookup, __construct, arginfo_TElCertificateLookup___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCertificateLookup(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCertificateLookup_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCertificateLookup", TElCertificateLookup_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElCertificateLookup_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElMemoryCertStorage_ce_ptr = NULL;

SB_PHP_METHOD(TElMemoryCertStorage, Add)
{
	zend_bool bCopyPrivateKey;
	zval *oX509Certificate;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oX509Certificate, TElX509Certificate_ce_ptr, &bCopyPrivateKey) == SUCCESS)
	{
		SBCheckError(TElMemoryCertStorage_Add(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oX509Certificate TSRMLS_CC), (int8_t)bCopyPrivateKey) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMemoryCertStorage, Remove)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElMemoryCertStorage_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMemoryCertStorage, get_CertificateList)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMemoryCertStorage_get_CertificateList(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TSBObjectList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMemoryCertStorage, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMemoryCertStorage_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMemoryCertStorage_Add, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, X509Certificate, 0, 1)
	ZEND_ARG_INFO(0, CopyPrivateKey)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMemoryCertStorage_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMemoryCertStorage_get_CertificateList, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMemoryCertStorage___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElMemoryCertStorage_methods[] = {
	PHP_ME(TElMemoryCertStorage, Add, arginfo_TElMemoryCertStorage_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElMemoryCertStorage, Remove, arginfo_TElMemoryCertStorage_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElMemoryCertStorage, get_CertificateList, arginfo_TElMemoryCertStorage_get_CertificateList, ZEND_ACC_PUBLIC)
	PHP_ME(TElMemoryCertStorage, __construct, arginfo_TElMemoryCertStorage___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMemoryCertStorage(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMemoryCertStorage_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMemoryCertStorage", TElMemoryCertStorage_methods);
	if (NULL == TElCustomCertStorage_ce_ptr)
		Register_TElCustomCertStorage(TSRMLS_C);
	TElMemoryCertStorage_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomCertStorage_ce_ptr);
}

zend_class_entry *TElFileCertStorage_ce_ptr = NULL;

SB_PHP_METHOD(TElFileCertStorage, Validate)
{
	TSBCertificateValidityReasonRaw fReasonRaw;
	zend_bool bCheckCACertDates;
	zval *dtValidityMoment;
	zval *oCertificate;
	zval *zfReason;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zbO", &oCertificate, TElX509Certificate_ce_ptr, &zfReason, &bCheckCACertDates, &dtValidityMoment, php_date_get_date_ce()) == SUCCESS) && Z_ISREF_P(zfReason) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zfReason))))
	{
		TSBCertificateValidityRaw fOutResultRaw = 0;
		fReasonRaw = (TSBCertificateValidityReasonRaw)Z_LVAL_P(Z_REFVAL_P(zfReason));
		SBCheckError(TElFileCertStorage_Validate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &fReasonRaw, (int8_t)bCheckCACertDates, SBGetDateTime(dtValidityMoment TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zfReason), (sb_zend_long)fReasonRaw);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zO", &oCertificate, TElX509Certificate_ce_ptr, &zfReason, &dtValidityMoment, php_date_get_date_ce()) == SUCCESS) && Z_ISREF_P(zfReason) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zfReason))))
	{
		TSBCertificateValidityRaw fOutResultRaw = 0;
		fReasonRaw = (TSBCertificateValidityReasonRaw)Z_LVAL_P(Z_REFVAL_P(zfReason));
		SBCheckError(TElFileCertStorage_Validate_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &fReasonRaw, SBGetDateTime(dtValidityMoment TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zfReason), (sb_zend_long)fReasonRaw);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, &integer, bool, \\DateTime) or (\\TElX509Certificate, &integer, \\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileCertStorage, Add)
{
	zend_bool bCopyPrivateKey;
	zval *oX509Certificate;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oX509Certificate, TElX509Certificate_ce_ptr, &bCopyPrivateKey) == SUCCESS)
	{
		SBCheckError(TElFileCertStorage_Add(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oX509Certificate TSRMLS_CC), (int8_t)bCopyPrivateKey) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileCertStorage, Remove)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElFileCertStorage_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileCertStorage, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElFileCertStorage_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileCertStorage, SaveToFile)
{
	char *sFileName;
	sb_str_size sFileName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sFileName, &sFileName_len) == SUCCESS)
	{
		SBCheckError(TElFileCertStorage_SaveToFile(SBGetObjectHandle(getThis() TSRMLS_CC), sFileName, (int32_t)sFileName_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileCertStorage, Reload)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElFileCertStorage_Reload(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileCertStorage, Save)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElFileCertStorage_Save(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileCertStorage, get_FileName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElFileCertStorage_get_FileName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(479027560, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileCertStorage, set_FileName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElFileCertStorage_set_FileName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileCertStorage, get_AccessType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFileCertStorageAccessTypeRaw fOutResultRaw = 0;
		SBCheckError(TElFileCertStorage_get_AccessType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileCertStorage, set_AccessType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElFileCertStorage_set_AccessType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBFileCertStorageAccessTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileCertStorage, get_SaveOptions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFileCertStorageSaveOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElFileCertStorage_get_SaveOptions(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileCertStorage, set_SaveOptions)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElFileCertStorage_set_SaveOptions(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBFileCertStorageSaveOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileCertStorage, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElFileCertStorage_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileCertStorage_Validate, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Certificate, TElX509Certificate, 1)
	ZEND_ARG_INFO(1, Reason)
	ZEND_ARG_INFO(0, CheckCACertDates_or_ValidityMoment)
	ZEND_ARG_OBJ_INFO(0, ValidityMoment, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileCertStorage_Add, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, X509Certificate, 0, 1)
	ZEND_ARG_INFO(0, CopyPrivateKey)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileCertStorage_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileCertStorage_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileCertStorage_SaveToFile, 0, 0, 1)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileCertStorage_Reload, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileCertStorage_Save, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileCertStorage_get_FileName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileCertStorage_set_FileName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileCertStorage_get_AccessType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileCertStorage_set_AccessType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileCertStorage_get_SaveOptions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileCertStorage_set_SaveOptions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileCertStorage___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElFileCertStorage_methods[] = {
	PHP_ME(TElFileCertStorage, Validate, arginfo_TElFileCertStorage_Validate, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileCertStorage, Add, arginfo_TElFileCertStorage_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileCertStorage, Remove, arginfo_TElFileCertStorage_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileCertStorage, Clear, arginfo_TElFileCertStorage_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileCertStorage, SaveToFile, arginfo_TElFileCertStorage_SaveToFile, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileCertStorage, Reload, arginfo_TElFileCertStorage_Reload, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileCertStorage, Save, arginfo_TElFileCertStorage_Save, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileCertStorage, get_FileName, arginfo_TElFileCertStorage_get_FileName, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileCertStorage, set_FileName, arginfo_TElFileCertStorage_set_FileName, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileCertStorage, get_AccessType, arginfo_TElFileCertStorage_get_AccessType, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileCertStorage, set_AccessType, arginfo_TElFileCertStorage_set_AccessType, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileCertStorage, get_SaveOptions, arginfo_TElFileCertStorage_get_SaveOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileCertStorage, set_SaveOptions, arginfo_TElFileCertStorage_set_SaveOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileCertStorage, __construct, arginfo_TElFileCertStorage___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElFileCertStorage(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElFileCertStorage_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElFileCertStorage", TElFileCertStorage_methods);
	if (NULL == TElCustomCertStorage_ce_ptr)
		Register_TElCustomCertStorage(TSRMLS_C);
	TElFileCertStorage_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomCertStorage_ce_ptr);
}

SB_PHP_FUNCTION(SBCustomCertStorage, IsIssuerCertificate)
{
	zend_bool bStrictChainBuilding;
	zval *oIssuer;
	zval *oSubject;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!b", &oSubject, TElX509Certificate_ce_ptr, &oIssuer, TElX509Certificate_ce_ptr, &bStrictChainBuilding) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBCustomCertStorage_IsIssuerCertificate(SBGetObjectHandle(oSubject TSRMLS_CC), SBGetObjectHandle(oIssuer TSRMLS_CC), (int8_t)bStrictChainBuilding, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, \\TElX509Certificate, bool)" TSRMLS_CC);
	}
}

void Register_SBCustomCertStorage_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBLookupCriterion", NULL);
	TSBLookupCriterion_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBLookupCriterion_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriterion_ce_ptr, "lcIssuer", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriterion_ce_ptr, "lcSubject", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriterion_ce_ptr, "lcValidity", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriterion_ce_ptr, "lcPublicKeyAlgorithm", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriterion_ce_ptr, "lcSignatureAlgorithm", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriterion_ce_ptr, "lcPublicKeySize", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriterion_ce_ptr, "lcAuthorityKeyIdentifier", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriterion_ce_ptr, "lcSubjectKeyIdentifier", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriterion_ce_ptr, "lcKeyUsage", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriterion_ce_ptr, "lcEmail", 9)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriterion_ce_ptr, "lcSerialNumber", 10)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriterion_ce_ptr, "lcPublicKeyHash", 11)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriterion_ce_ptr, "lcCertificateHash", 12)
	
	INIT_CLASS_ENTRY(ce, "TSBLookupCriteria", NULL);
	TSBLookupCriteria_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBLookupCriteria_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriteria_ce_ptr, "lcIssuer", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriteria_ce_ptr, "lcSubject", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriteria_ce_ptr, "lcValidity", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriteria_ce_ptr, "lcPublicKeyAlgorithm", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriteria_ce_ptr, "lcSignatureAlgorithm", 16)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriteria_ce_ptr, "lcPublicKeySize", 32)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriteria_ce_ptr, "lcAuthorityKeyIdentifier", 64)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriteria_ce_ptr, "lcSubjectKeyIdentifier", 128)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriteria_ce_ptr, "lcKeyUsage", 256)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriteria_ce_ptr, "lcEmail", 512)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriteria_ce_ptr, "lcSerialNumber", 1024)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriteria_ce_ptr, "lcPublicKeyHash", 2048)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupCriteria_ce_ptr, "lcCertificateHash", 4096)
	
	INIT_CLASS_ENTRY(ce, "TSBLookupOption", NULL);
	TSBLookupOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBLookupOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupOption_ce_ptr, "loExactMatch", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupOption_ce_ptr, "loMatchAll", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupOption_ce_ptr, "loCompareRDNAsStrings", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBLookupOptions", NULL);
	TSBLookupOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBLookupOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupOptions_ce_ptr, "loExactMatch", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupOptions_ce_ptr, "loMatchAll", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBLookupOptions_ce_ptr, "loCompareRDNAsStrings", 4)
	
	INIT_CLASS_ENTRY(ce, "TSBDateLookupOption", NULL);
	TSBDateLookupOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBDateLookupOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBDateLookupOption_ce_ptr, "dloBefore", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBDateLookupOption_ce_ptr, "dloAfter", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBDateLookupOption_ce_ptr, "dloBetween", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBDateLookupOptions", NULL);
	TSBDateLookupOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBDateLookupOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBDateLookupOptions_ce_ptr, "dloBefore", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBDateLookupOptions_ce_ptr, "dloAfter", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBDateLookupOptions_ce_ptr, "dloBetween", 4)
	
	INIT_CLASS_ENTRY(ce, "TSBKeySizeLookupOption", NULL);
	TSBKeySizeLookupOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBKeySizeLookupOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBKeySizeLookupOption_ce_ptr, "ksloSmaller", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeySizeLookupOption_ce_ptr, "ksloGreater", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeySizeLookupOption_ce_ptr, "ksloBetween", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBKeyUsageLookupOption", NULL);
	TSBKeyUsageLookupOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBKeyUsageLookupOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyUsageLookupOption_ce_ptr, "kuloMatchAll", 0)
	
	INIT_CLASS_ENTRY(ce, "TSBKeyUsageLookupOptions", NULL);
	TSBKeyUsageLookupOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBKeyUsageLookupOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyUsageLookupOptions_ce_ptr, "kuloMatchAll", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBCertStorageOption", NULL);
	TSBCertStorageOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBCertStorageOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBCertStorageOption_ce_ptr, "csoStrictChainBuilding", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBCertStorageOption_ce_ptr, "csoIgnoreInvalidCertificates", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBCertStorageOptions", NULL);
	TSBCertStorageOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBCertStorageOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBCertStorageOptions_ce_ptr, "csoStrictChainBuilding", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBCertStorageOptions_ce_ptr, "csoIgnoreInvalidCertificates", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBFileCertStorageAccessType", NULL);
	TSBFileCertStorageAccessType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBFileCertStorageAccessType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFileCertStorageAccessType_ce_ptr, "csatImmediate", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileCertStorageAccessType_ce_ptr, "csatOnDemand", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBFileCertStorageSaveOption", NULL);
	TSBFileCertStorageSaveOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBFileCertStorageSaveOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFileCertStorageSaveOption_ce_ptr, "fcsoSaveOnDestroy", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileCertStorageSaveOption_ce_ptr, "fcsoSaveOnFilenameChange", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileCertStorageSaveOption_ce_ptr, "fcsoSaveOnChange", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBFileCertStorageSaveOptions", NULL);
	TSBFileCertStorageSaveOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBFileCertStorageSaveOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFileCertStorageSaveOptions_ce_ptr, "fcsoSaveOnDestroy", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileCertStorageSaveOptions_ce_ptr, "fcsoSaveOnFilenameChange", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileCertStorageSaveOptions_ce_ptr, "fcsoSaveOnChange", 4)
}

void Register_SBCustomCertStorage_Aliases(TSRMLS_D)
{
	if (NULL == TElCustomCertStorage_ce_ptr)
		Register_TElCustomCertStorage(TSRMLS_C);
	zend_register_class_alias("ElCustomCertStorage", TElCustomCertStorage_ce_ptr);
	if (NULL == TElCertificateLookup_ce_ptr)
		Register_TElCertificateLookup(TSRMLS_C);
	zend_register_class_alias("ElCertificateLookup", TElCertificateLookup_ce_ptr);
	if (NULL == TElMemoryCertStorage_ce_ptr)
		Register_TElMemoryCertStorage(TSRMLS_C);
	zend_register_class_alias("ElMemoryCertStorage", TElMemoryCertStorage_ce_ptr);
	if (NULL == TElFileCertStorage_ce_ptr)
		Register_TElFileCertStorage(TSRMLS_C);
	zend_register_class_alias("ElFileCertStorage", TElFileCertStorage_ce_ptr);
}

