#include "sbdatastorage.h"

zend_class_entry *TSBDSDataAuthInfoType_ce_ptr = NULL;

zend_class_entry *TSBDSDigestLocation_ce_ptr = NULL;

zend_class_entry *TSBDataStorageOperation_ce_ptr = NULL;

void SB_CALLBACK TSBDataStorageOperationFinishEventRaw(void * _ObjectData, TObjectHandle Sender, TSBDataStorageOperationRaw Operation)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zOperation;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOperation, 1);
	ZVAL_LONG(zOperation, (sb_zend_long)Operation);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zOperation);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBDataStorageOperationStartEventRaw(void * _ObjectData, TObjectHandle Sender, TSBDataStorageOperationRaw Operation, int8_t * Cancel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zOperation;
	zval * zCancel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOperation, 1);
	ZVAL_LONG(zOperation, (sb_zend_long)Operation);
	SB_EVENT_INIT_ZVAL_REF(zCancel, 2);
	ZVAL_BOOL(Z_REFVAL_P(zCancel), (zend_bool)*Cancel);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zOperation);
	convert_to_boolean(Z_REFVAL_P(zCancel));
	*Cancel = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCancel));
	SB_EVENT_CLEAR_ZVAL(zCancel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBDataStorageProgressEventRaw(void * _ObjectData, TObjectHandle Sender, TSBDataStorageOperationRaw Operation, int64_t Total, int64_t Current, int8_t * Cancel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zOperation;
	zval * zTotal;
	zval * zCurrent;
	zval * zCancel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOperation, 1);
	ZVAL_LONG(zOperation, (sb_zend_long)Operation);
	SB_EVENT_INIT_ZVAL(zTotal, 2);
	ZVAL_LONG(zTotal, (sb_zend_long)Total);
	SB_EVENT_INIT_ZVAL(zCurrent, 3);
	ZVAL_LONG(zCurrent, (sb_zend_long)Current);
	SB_EVENT_INIT_ZVAL_REF(zCancel, 4);
	ZVAL_BOOL(Z_REFVAL_P(zCancel), (zend_bool)*Cancel);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zOperation);
	SB_EVENT_CLEAR_ZVAL(zTotal);
	SB_EVENT_CLEAR_ZVAL(zCurrent);
	convert_to_boolean(Z_REFVAL_P(zCancel));
	*Cancel = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCancel));
	SB_EVENT_CLEAR_ZVAL(zCancel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBDataStorageProgressFuncRaw(void * _ObjectData, TSBDataStorageOperationRaw Operation, int64_t Total, int64_t Current, void * Data, int8_t * Cancel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zOperation;
	zval * zTotal;
	zval * zCurrent;
	zval * zData;
	zval * zCancel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zOperation, 0);
	ZVAL_LONG(zOperation, (sb_zend_long)Operation);
	SB_EVENT_INIT_ZVAL(zTotal, 1);
	ZVAL_LONG(zTotal, (sb_zend_long)Total);
	SB_EVENT_INIT_ZVAL(zCurrent, 2);
	ZVAL_LONG(zCurrent, (sb_zend_long)Current);
	SB_EVENT_INIT_ZVAL(zData, 3);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zCancel, 4);
	ZVAL_BOOL(Z_REFVAL_P(zCancel), (zend_bool)*Cancel);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zOperation);
	SB_EVENT_CLEAR_ZVAL(zTotal);
	SB_EVENT_CLEAR_ZVAL(zCurrent);
	SB_EVENT_CLEAR_ZVAL(zData);
	convert_to_boolean(Z_REFVAL_P(zCancel));
	*Cancel = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCancel));
	SB_EVENT_CLEAR_ZVAL(zCancel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElDSKeyProtectionHandlerClass_ce_ptr = NULL;

void SB_CALLBACK TSBFDSSecurityHandlerCreatedEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomDataStorageObjectHandle Obj, void * Data, TElCustomDataStorageSecurityHandlerHandle Handler)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zObj;
	zval * zData;
	zval * zHandler;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zObj, 1);
	SBInitObject(zObj, TElCustomDataStorageObject_ce_ptr, Obj TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 2);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zHandler, 3);
	SBInitObject(zHandler, TElCustomDataStorageSecurityHandler_ce_ptr, Handler TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zObj);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zHandler);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBFDSSecurityHandlerNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomDataStorageObjectHandle Obj, void * Data, TElCustomDataStorageSecurityHandlerHandle * Handler)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zObj;
	zval * zData;
	zval * zHandler;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zObj, 1);
	SBInitObject(zObj, TElCustomDataStorageObject_ce_ptr, Obj TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 2);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zHandler, 3);
	SBInitObject(zHandler, TElCustomDataStorageSecurityHandler_ce_ptr, *Handler TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zObj);
	SB_EVENT_CLEAR_ZVAL(zData);
	*Handler = SBGetObjectHandleCE(zHandler, TElCustomDataStorageSecurityHandler_ce_ptr TSRMLS_CC);
	SBDetachObjectHandleIfUniqueZVal(zHandler TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zHandler);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBDataStorageSecHandlerSignatureFoundEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t Success, int32_t ErrorCode, TElMessageVerifierHandle Verifier, int8_t * TryAgain)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zSuccess;
	zval * zErrorCode;
	zval * zVerifier;
	zval * zTryAgain;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSuccess, 1);
	ZVAL_BOOL(zSuccess, (zend_bool)Success);
	SB_EVENT_INIT_ZVAL(zErrorCode, 2);
	ZVAL_LONG(zErrorCode, (sb_zend_long)ErrorCode);
	SB_EVENT_INIT_ZVAL(zVerifier, 3);
	SBInitObject(zVerifier, TElMessageVerifier_ce_ptr, Verifier TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zTryAgain, 4);
	ZVAL_BOOL(Z_REFVAL_P(zTryAgain), (zend_bool)*TryAgain);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSuccess);
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	SB_EVENT_CLEAR_ZVAL(zVerifier);
	convert_to_boolean(Z_REFVAL_P(zTryAgain));
	*TryAgain = (int8_t)SB_BVAL_P(Z_REFVAL_P(zTryAgain));
	SB_EVENT_CLEAR_ZVAL(zTryAgain);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBDataStorageSecHandlerSigningPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElMessageSignerHandle Signer)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zSigner;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSigner, 1);
	SBInitObject(zSigner, TElMessageSigner_ce_ptr, Signer TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSigner);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBDataStorageCreateTemporaryStreamEventRaw(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream, int8_t * ReleaseStreamAfterUse)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zStream;
	zval * zReleaseStreamAfterUse;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zStream, 1);
	SBInitObject(zStream, TStream_ce_ptr, *Stream TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zReleaseStreamAfterUse, 2);
	ZVAL_BOOL(Z_REFVAL_P(zReleaseStreamAfterUse), (zend_bool)*ReleaseStreamAfterUse);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	*Stream = SBGetObjectHandleCE(zStream, TStream_ce_ptr TSRMLS_CC);
	SBDetachObjectHandleIfUniqueZVal(zStream TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zStream);
	convert_to_boolean(Z_REFVAL_P(zReleaseStreamAfterUse));
	*ReleaseStreamAfterUse = (int8_t)SB_BVAL_P(Z_REFVAL_P(zReleaseStreamAfterUse));
	SB_EVENT_CLEAR_ZVAL(zReleaseStreamAfterUse);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSBDSDataStorageFeature_ce_ptr = NULL;

zend_class_entry *TElDataStorageSecurityHandlerClass_ce_ptr = NULL;

zend_class_entry *TSBEncodingHandlerFeature_ce_ptr = NULL;

zend_class_entry *TElDataStorageEncodingHandlerClass_ce_ptr = NULL;

zend_class_entry *TElDSCustomKeyProtectionHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElDSCustomKeyProtectionHandler, GetOID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDSCustomKeyProtectionHandler_GetOID(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1227672378, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSCustomKeyProtectionHandler, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElDSCustomKeyProtectionHandler_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1046809960, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSCustomKeyProtectionHandler, Load)
{
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDSCustomKeyProtectionHandler_Load(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSCustomKeyProtectionHandler, Save)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDSCustomKeyProtectionHandler_Save(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1241977083, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSCustomKeyProtectionHandler, CreateInstance)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSCustomKeyProtectionHandler_CreateInstance(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDSCustomKeyProtectionHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSCustomKeyProtectionHandler, GetKey)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDSCustomKeyProtectionHandler_GetKey(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1029457345, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSCustomKeyProtectionHandler, SetKey)
{
	SBArrayZValInfo aiKey;
	zval *zaKey;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaKey) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaKey) || SB_IS_ARRAY_TYPE_RP(zaKey) || SB_IS_NULL_TYPE_RP(zaKey)))
	{
		if (!SBGetByteArrayFromZVal(zaKey, &aiKey TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDSCustomKeyProtectionHandler_SetKey(SBGetObjectHandle(getThis() TSRMLS_CC), aiKey.data, aiKey.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiKey);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSCustomKeyProtectionHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDSCustomKeyProtectionHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSCustomKeyProtectionHandler, KeyAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDSCustomKeyProtectionHandler_KeyAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSCustomKeyProtectionHandler, ClearCache)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDSCustomKeyProtectionHandler_ClearCache(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSCustomKeyProtectionHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSCustomKeyProtectionHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSCustomKeyProtectionHandler, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSCustomKeyProtectionHandler_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSCustomKeyProtectionHandler_GetOID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSCustomKeyProtectionHandler_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSCustomKeyProtectionHandler_Load, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSCustomKeyProtectionHandler_Save, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSCustomKeyProtectionHandler_CreateInstance, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSCustomKeyProtectionHandler_GetKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSCustomKeyProtectionHandler_SetKey, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Key, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSCustomKeyProtectionHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSCustomKeyProtectionHandler_KeyAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSCustomKeyProtectionHandler_ClearCache, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSCustomKeyProtectionHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSCustomKeyProtectionHandler___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDSCustomKeyProtectionHandler_methods[] = {
	PHP_ME(TElDSCustomKeyProtectionHandler, GetOID, arginfo_TElDSCustomKeyProtectionHandler_GetOID, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSCustomKeyProtectionHandler, GetDescription, arginfo_TElDSCustomKeyProtectionHandler_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSCustomKeyProtectionHandler, Load, arginfo_TElDSCustomKeyProtectionHandler_Load, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSCustomKeyProtectionHandler, Save, arginfo_TElDSCustomKeyProtectionHandler_Save, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSCustomKeyProtectionHandler, CreateInstance, arginfo_TElDSCustomKeyProtectionHandler_CreateInstance, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSCustomKeyProtectionHandler, GetKey, arginfo_TElDSCustomKeyProtectionHandler_GetKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSCustomKeyProtectionHandler, SetKey, arginfo_TElDSCustomKeyProtectionHandler_SetKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSCustomKeyProtectionHandler, Reset, arginfo_TElDSCustomKeyProtectionHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSCustomKeyProtectionHandler, KeyAvailable, arginfo_TElDSCustomKeyProtectionHandler_KeyAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSCustomKeyProtectionHandler, ClearCache, arginfo_TElDSCustomKeyProtectionHandler_ClearCache, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSCustomKeyProtectionHandler, ClassType, arginfo_TElDSCustomKeyProtectionHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElDSCustomKeyProtectionHandler, __construct, arginfo_TElDSCustomKeyProtectionHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDSCustomKeyProtectionHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDSCustomKeyProtectionHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDSCustomKeyProtectionHandler", TElDSCustomKeyProtectionHandler_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElDSCustomKeyProtectionHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElCustomDataStorageEncodingHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElCustomDataStorageEncodingHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCustomDataStorageEncodingHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageEncodingHandler, GetOID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElCustomDataStorageEncodingHandler_GetOID(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1769623172, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageEncodingHandler, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElCustomDataStorageEncodingHandler_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1076407532, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageEncodingHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomDataStorageEncodingHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageEncodingHandler, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomDataStorageEncodingHandler_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageEncodingHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageEncodingHandler_GetOID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageEncodingHandler_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageEncodingHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageEncodingHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCustomDataStorageEncodingHandler_methods[] = {
	PHP_ME(TElCustomDataStorageEncodingHandler, Reset, arginfo_TElCustomDataStorageEncodingHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageEncodingHandler, GetOID, arginfo_TElCustomDataStorageEncodingHandler_GetOID, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageEncodingHandler, GetDescription, arginfo_TElCustomDataStorageEncodingHandler_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageEncodingHandler, ClassType, arginfo_TElCustomDataStorageEncodingHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElCustomDataStorageEncodingHandler, __construct, arginfo_TElCustomDataStorageEncodingHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCustomDataStorageEncodingHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCustomDataStorageEncodingHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCustomDataStorageEncodingHandler", TElCustomDataStorageEncodingHandler_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElCustomDataStorageEncodingHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElDSEnvelopedDataKeyProtectionHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, GetOID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDSEnvelopedDataKeyProtectionHandler_GetOID(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1416456398, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElDSEnvelopedDataKeyProtectionHandler_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(93320110, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, CreateInstance)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_CreateInstance(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDSCustomKeyProtectionHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, Load)
{
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_Load(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, Save)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDSEnvelopedDataKeyProtectionHandler_Save(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-238052159, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, GetKey)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDSEnvelopedDataKeyProtectionHandler_GetKey(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(186754113, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, SetKey)
{
	SBArrayZValInfo aiKey;
	zval *zaKey;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaKey) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaKey) || SB_IS_ARRAY_TYPE_RP(zaKey) || SB_IS_NULL_TYPE_RP(zaKey)))
	{
		if (!SBGetByteArrayFromZVal(zaKey, &aiKey TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_SetKey(SBGetObjectHandle(getThis() TSRMLS_CC), aiKey.data, aiKey.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiKey);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, KeyAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_KeyAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, ClearCache)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_ClearCache(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, get_CertIDs)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_get_CertIDs(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Issuer_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, get_CertIDCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_get_CertIDCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, get_CertStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_get_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, set_CertStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_set_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, get_Algorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_get_Algorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, set_Algorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_set_Algorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, get_BitsInKey)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_get_BitsInKey(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, set_BitsInKey)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_set_BitsInKey(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, get_UseOAEP)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_get_UseOAEP(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, set_UseOAEP)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_set_UseOAEP(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEnvelopedDataKeyProtectionHandler, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSEnvelopedDataKeyProtectionHandler_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_GetOID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_CreateInstance, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_Load, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_Save, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_GetKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_SetKey, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Key, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_KeyAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_ClearCache, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_get_CertIDs, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_get_CertIDCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_get_CertStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_set_CertStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_get_Algorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_set_Algorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_get_BitsInKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_set_BitsInKey, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_get_UseOAEP, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler_set_UseOAEP, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEnvelopedDataKeyProtectionHandler___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDSEnvelopedDataKeyProtectionHandler_methods[] = {
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, GetOID, arginfo_TElDSEnvelopedDataKeyProtectionHandler_GetOID, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, GetDescription, arginfo_TElDSEnvelopedDataKeyProtectionHandler_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, CreateInstance, arginfo_TElDSEnvelopedDataKeyProtectionHandler_CreateInstance, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, Load, arginfo_TElDSEnvelopedDataKeyProtectionHandler_Load, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, Save, arginfo_TElDSEnvelopedDataKeyProtectionHandler_Save, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, GetKey, arginfo_TElDSEnvelopedDataKeyProtectionHandler_GetKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, SetKey, arginfo_TElDSEnvelopedDataKeyProtectionHandler_SetKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, Reset, arginfo_TElDSEnvelopedDataKeyProtectionHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, KeyAvailable, arginfo_TElDSEnvelopedDataKeyProtectionHandler_KeyAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, ClearCache, arginfo_TElDSEnvelopedDataKeyProtectionHandler_ClearCache, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, ClassType, arginfo_TElDSEnvelopedDataKeyProtectionHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, get_CertIDs, arginfo_TElDSEnvelopedDataKeyProtectionHandler_get_CertIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, get_CertIDCount, arginfo_TElDSEnvelopedDataKeyProtectionHandler_get_CertIDCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, get_CertStorage, arginfo_TElDSEnvelopedDataKeyProtectionHandler_get_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, set_CertStorage, arginfo_TElDSEnvelopedDataKeyProtectionHandler_set_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, get_Algorithm, arginfo_TElDSEnvelopedDataKeyProtectionHandler_get_Algorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, set_Algorithm, arginfo_TElDSEnvelopedDataKeyProtectionHandler_set_Algorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, get_BitsInKey, arginfo_TElDSEnvelopedDataKeyProtectionHandler_get_BitsInKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, set_BitsInKey, arginfo_TElDSEnvelopedDataKeyProtectionHandler_set_BitsInKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, get_UseOAEP, arginfo_TElDSEnvelopedDataKeyProtectionHandler_get_UseOAEP, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, set_UseOAEP, arginfo_TElDSEnvelopedDataKeyProtectionHandler_set_UseOAEP, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEnvelopedDataKeyProtectionHandler, __construct, arginfo_TElDSEnvelopedDataKeyProtectionHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDSEnvelopedDataKeyProtectionHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDSEnvelopedDataKeyProtectionHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDSEnvelopedDataKeyProtectionHandler", TElDSEnvelopedDataKeyProtectionHandler_methods);
	if (NULL == TElDSCustomKeyProtectionHandler_ce_ptr)
		Register_TElDSCustomKeyProtectionHandler(TSRMLS_C);
	TElDSEnvelopedDataKeyProtectionHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElDSCustomKeyProtectionHandler_ce_ptr);
}

zend_class_entry *TElDSEncryptedDataKeyProtectionHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, GetOID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDSEncryptedDataKeyProtectionHandler_GetOID(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(447065014, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElDSEncryptedDataKeyProtectionHandler_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2107548763, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, CreateInstance)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSEncryptedDataKeyProtectionHandler_CreateInstance(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDSCustomKeyProtectionHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, Load)
{
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDSEncryptedDataKeyProtectionHandler_Load(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, Save)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDSEncryptedDataKeyProtectionHandler_Save(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(124973038, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, GetKey)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDSEncryptedDataKeyProtectionHandler_GetKey(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1172924217, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, SetKey)
{
	SBArrayZValInfo aiKey;
	zval *zaKey;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaKey) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaKey) || SB_IS_ARRAY_TYPE_RP(zaKey) || SB_IS_NULL_TYPE_RP(zaKey)))
	{
		if (!SBGetByteArrayFromZVal(zaKey, &aiKey TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDSEncryptedDataKeyProtectionHandler_SetKey(SBGetObjectHandle(getThis() TSRMLS_CC), aiKey.data, aiKey.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiKey);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDSEncryptedDataKeyProtectionHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, KeyAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDSEncryptedDataKeyProtectionHandler_KeyAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, ClearCache)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDSEncryptedDataKeyProtectionHandler_ClearCache(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSEncryptedDataKeyProtectionHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, get_Algorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDSEncryptedDataKeyProtectionHandler_get_Algorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, set_Algorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElDSEncryptedDataKeyProtectionHandler_set_Algorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, get_BitsInKey)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDSEncryptedDataKeyProtectionHandler_get_BitsInKey(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, set_BitsInKey)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElDSEncryptedDataKeyProtectionHandler_set_BitsInKey(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, get_EncryptionKey)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDSEncryptedDataKeyProtectionHandler_get_EncryptionKey(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-368228187, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, set_EncryptionKey)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDSEncryptedDataKeyProtectionHandler_set_EncryptionKey(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, get_GenericKeys)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSEncryptedDataKeyProtectionHandler_get_GenericKeys(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElByteArrayList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSEncryptedDataKeyProtectionHandler, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSEncryptedDataKeyProtectionHandler_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_GetOID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_CreateInstance, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_Load, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_Save, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_GetKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_SetKey, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Key, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_KeyAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_ClearCache, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_get_Algorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_set_Algorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_get_BitsInKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_set_BitsInKey, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_get_EncryptionKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_set_EncryptionKey, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler_get_GenericKeys, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSEncryptedDataKeyProtectionHandler___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDSEncryptedDataKeyProtectionHandler_methods[] = {
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, GetOID, arginfo_TElDSEncryptedDataKeyProtectionHandler_GetOID, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, GetDescription, arginfo_TElDSEncryptedDataKeyProtectionHandler_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, CreateInstance, arginfo_TElDSEncryptedDataKeyProtectionHandler_CreateInstance, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, Load, arginfo_TElDSEncryptedDataKeyProtectionHandler_Load, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, Save, arginfo_TElDSEncryptedDataKeyProtectionHandler_Save, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, GetKey, arginfo_TElDSEncryptedDataKeyProtectionHandler_GetKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, SetKey, arginfo_TElDSEncryptedDataKeyProtectionHandler_SetKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, Reset, arginfo_TElDSEncryptedDataKeyProtectionHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, KeyAvailable, arginfo_TElDSEncryptedDataKeyProtectionHandler_KeyAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, ClearCache, arginfo_TElDSEncryptedDataKeyProtectionHandler_ClearCache, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, ClassType, arginfo_TElDSEncryptedDataKeyProtectionHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, get_Algorithm, arginfo_TElDSEncryptedDataKeyProtectionHandler_get_Algorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, set_Algorithm, arginfo_TElDSEncryptedDataKeyProtectionHandler_set_Algorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, get_BitsInKey, arginfo_TElDSEncryptedDataKeyProtectionHandler_get_BitsInKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, set_BitsInKey, arginfo_TElDSEncryptedDataKeyProtectionHandler_set_BitsInKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, get_EncryptionKey, arginfo_TElDSEncryptedDataKeyProtectionHandler_get_EncryptionKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, set_EncryptionKey, arginfo_TElDSEncryptedDataKeyProtectionHandler_set_EncryptionKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, get_GenericKeys, arginfo_TElDSEncryptedDataKeyProtectionHandler_get_GenericKeys, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSEncryptedDataKeyProtectionHandler, __construct, arginfo_TElDSEncryptedDataKeyProtectionHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDSEncryptedDataKeyProtectionHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDSEncryptedDataKeyProtectionHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDSEncryptedDataKeyProtectionHandler", TElDSEncryptedDataKeyProtectionHandler_methods);
	if (NULL == TElDSCustomKeyProtectionHandler_ce_ptr)
		Register_TElDSCustomKeyProtectionHandler(TSRMLS_C);
	TElDSEncryptedDataKeyProtectionHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElDSCustomKeyProtectionHandler_ce_ptr);
}

zend_class_entry *TElDSPlainKeyProtectionHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElDSPlainKeyProtectionHandler, GetOID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDSPlainKeyProtectionHandler_GetOID(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-901855, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSPlainKeyProtectionHandler, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElDSPlainKeyProtectionHandler_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1823701371, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSPlainKeyProtectionHandler, CreateInstance)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSPlainKeyProtectionHandler_CreateInstance(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDSCustomKeyProtectionHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSPlainKeyProtectionHandler, Load)
{
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDSPlainKeyProtectionHandler_Load(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSPlainKeyProtectionHandler, Save)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDSPlainKeyProtectionHandler_Save(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-408649744, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSPlainKeyProtectionHandler, GetKey)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDSPlainKeyProtectionHandler_GetKey(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1051614370, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSPlainKeyProtectionHandler, SetKey)
{
	SBArrayZValInfo aiKey;
	zval *zaKey;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaKey) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaKey) || SB_IS_ARRAY_TYPE_RP(zaKey) || SB_IS_NULL_TYPE_RP(zaKey)))
	{
		if (!SBGetByteArrayFromZVal(zaKey, &aiKey TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDSPlainKeyProtectionHandler_SetKey(SBGetObjectHandle(getThis() TSRMLS_CC), aiKey.data, aiKey.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiKey);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSPlainKeyProtectionHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDSPlainKeyProtectionHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSPlainKeyProtectionHandler, KeyAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDSPlainKeyProtectionHandler_KeyAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSPlainKeyProtectionHandler, ClearCache)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDSPlainKeyProtectionHandler_ClearCache(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSPlainKeyProtectionHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSPlainKeyProtectionHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSPlainKeyProtectionHandler, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSPlainKeyProtectionHandler_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSPlainKeyProtectionHandler_GetOID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSPlainKeyProtectionHandler_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSPlainKeyProtectionHandler_CreateInstance, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSPlainKeyProtectionHandler_Load, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSPlainKeyProtectionHandler_Save, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSPlainKeyProtectionHandler_GetKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSPlainKeyProtectionHandler_SetKey, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Key, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSPlainKeyProtectionHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSPlainKeyProtectionHandler_KeyAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSPlainKeyProtectionHandler_ClearCache, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSPlainKeyProtectionHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSPlainKeyProtectionHandler___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDSPlainKeyProtectionHandler_methods[] = {
	PHP_ME(TElDSPlainKeyProtectionHandler, GetOID, arginfo_TElDSPlainKeyProtectionHandler_GetOID, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSPlainKeyProtectionHandler, GetDescription, arginfo_TElDSPlainKeyProtectionHandler_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSPlainKeyProtectionHandler, CreateInstance, arginfo_TElDSPlainKeyProtectionHandler_CreateInstance, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSPlainKeyProtectionHandler, Load, arginfo_TElDSPlainKeyProtectionHandler_Load, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSPlainKeyProtectionHandler, Save, arginfo_TElDSPlainKeyProtectionHandler_Save, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSPlainKeyProtectionHandler, GetKey, arginfo_TElDSPlainKeyProtectionHandler_GetKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSPlainKeyProtectionHandler, SetKey, arginfo_TElDSPlainKeyProtectionHandler_SetKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSPlainKeyProtectionHandler, Reset, arginfo_TElDSPlainKeyProtectionHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSPlainKeyProtectionHandler, KeyAvailable, arginfo_TElDSPlainKeyProtectionHandler_KeyAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSPlainKeyProtectionHandler, ClearCache, arginfo_TElDSPlainKeyProtectionHandler_ClearCache, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSPlainKeyProtectionHandler, ClassType, arginfo_TElDSPlainKeyProtectionHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElDSPlainKeyProtectionHandler, __construct, arginfo_TElDSPlainKeyProtectionHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDSPlainKeyProtectionHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDSPlainKeyProtectionHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDSPlainKeyProtectionHandler", TElDSPlainKeyProtectionHandler_methods);
	if (NULL == TElDSCustomKeyProtectionHandler_ce_ptr)
		Register_TElDSCustomKeyProtectionHandler(TSRMLS_C);
	TElDSPlainKeyProtectionHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElDSCustomKeyProtectionHandler_ce_ptr);
}

zend_class_entry *TElDSKeyProtectionHandlersFactory_ce_ptr = NULL;

SB_PHP_METHOD(TElDSKeyProtectionHandlersFactory, RegisterHandler)
{
	zval *oCls;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCls, TElDSKeyProtectionHandlerClass_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDSKeyProtectionHandlersFactory_RegisterHandler(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCls TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDSKeyProtectionHandlerClass)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSKeyProtectionHandlersFactory, UnregisterHandler)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElDSKeyProtectionHandlersFactory_UnregisterHandler(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSKeyProtectionHandlersFactory, CreateInstance)
{
	SBArrayZValInfo aiOID;
	zval *zaOID;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaOID) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDSKeyProtectionHandlersFactory_CreateInstance(SBGetObjectHandle(getThis() TSRMLS_CC), aiOID.data, aiOID.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		SBInitObject(return_value, TElDSCustomKeyProtectionHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSKeyProtectionHandlersFactory, get_RegisteredHandlers)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSKeyProtectionHandlersFactory_get_RegisteredHandlers(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDSCustomKeyProtectionHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSKeyProtectionHandlersFactory, get_RegisteredHandlerCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDSKeyProtectionHandlersFactory_get_RegisteredHandlerCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDSKeyProtectionHandlersFactory, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDSKeyProtectionHandlersFactory_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSKeyProtectionHandlersFactory_RegisterHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Cls, TElDSKeyProtectionHandlerClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSKeyProtectionHandlersFactory_UnregisterHandler, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSKeyProtectionHandlersFactory_CreateInstance, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSKeyProtectionHandlersFactory_get_RegisteredHandlers, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSKeyProtectionHandlersFactory_get_RegisteredHandlerCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDSKeyProtectionHandlersFactory___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDSKeyProtectionHandlersFactory_methods[] = {
	PHP_ME(TElDSKeyProtectionHandlersFactory, RegisterHandler, arginfo_TElDSKeyProtectionHandlersFactory_RegisterHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSKeyProtectionHandlersFactory, UnregisterHandler, arginfo_TElDSKeyProtectionHandlersFactory_UnregisterHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSKeyProtectionHandlersFactory, CreateInstance, arginfo_TElDSKeyProtectionHandlersFactory_CreateInstance, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSKeyProtectionHandlersFactory, get_RegisteredHandlers, arginfo_TElDSKeyProtectionHandlersFactory_get_RegisteredHandlers, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSKeyProtectionHandlersFactory, get_RegisteredHandlerCount, arginfo_TElDSKeyProtectionHandlersFactory_get_RegisteredHandlerCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElDSKeyProtectionHandlersFactory, __construct, arginfo_TElDSKeyProtectionHandlersFactory___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDSKeyProtectionHandlersFactory(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDSKeyProtectionHandlersFactory_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDSKeyProtectionHandlersFactory", TElDSKeyProtectionHandlersFactory_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElDSKeyProtectionHandlersFactory_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElCustomDataStorageSecurityHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElCustomDataStorageSecurityHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCustomDataStorageSecurityHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageSecurityHandler, GetOID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElCustomDataStorageSecurityHandler_GetOID(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(2077776458, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageSecurityHandler, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElCustomDataStorageSecurityHandler_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1551296791, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageSecurityHandler, CanEncrypt)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomDataStorageSecurityHandler_CanEncrypt(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageSecurityHandler, CanDecrypt)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomDataStorageSecurityHandler_CanDecrypt(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageSecurityHandler, ClearCache)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCustomDataStorageSecurityHandler_ClearCache(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageSecurityHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomDataStorageSecurityHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageSecurityHandler, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomDataStorageSecurityHandler_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageSecurityHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageSecurityHandler_GetOID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageSecurityHandler_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageSecurityHandler_CanEncrypt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageSecurityHandler_CanDecrypt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageSecurityHandler_ClearCache, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageSecurityHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageSecurityHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCustomDataStorageSecurityHandler_methods[] = {
	PHP_ME(TElCustomDataStorageSecurityHandler, Reset, arginfo_TElCustomDataStorageSecurityHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageSecurityHandler, GetOID, arginfo_TElCustomDataStorageSecurityHandler_GetOID, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageSecurityHandler, GetDescription, arginfo_TElCustomDataStorageSecurityHandler_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageSecurityHandler, CanEncrypt, arginfo_TElCustomDataStorageSecurityHandler_CanEncrypt, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageSecurityHandler, CanDecrypt, arginfo_TElCustomDataStorageSecurityHandler_CanDecrypt, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageSecurityHandler, ClearCache, arginfo_TElCustomDataStorageSecurityHandler_ClearCache, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageSecurityHandler, ClassType, arginfo_TElCustomDataStorageSecurityHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElCustomDataStorageSecurityHandler, __construct, arginfo_TElCustomDataStorageSecurityHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCustomDataStorageSecurityHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCustomDataStorageSecurityHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCustomDataStorageSecurityHandler", TElCustomDataStorageSecurityHandler_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElCustomDataStorageSecurityHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElDataStorageObjectList_ce_ptr = NULL;

SB_PHP_METHOD(TElDataStorageObjectList, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDataStorageObjectList_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDataStorageObjectList, get_Objects)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDataStorageObjectList_get_Objects(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDataStorageObjectList, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDataStorageObjectList_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDataStorageObjectList, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDataStorageObjectList_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageObjectList_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageObjectList_get_Objects, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageObjectList_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageObjectList___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDataStorageObjectList_methods[] = {
	PHP_ME(TElDataStorageObjectList, Clear, arginfo_TElDataStorageObjectList_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElDataStorageObjectList, get_Objects, arginfo_TElDataStorageObjectList_get_Objects, ZEND_ACC_PUBLIC)
	PHP_ME(TElDataStorageObjectList, get_Count, arginfo_TElDataStorageObjectList_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElDataStorageObjectList, __construct, arginfo_TElDataStorageObjectList___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDataStorageObjectList(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDataStorageObjectList_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDataStorageObjectList", TElDataStorageObjectList_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElDataStorageObjectList_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElCustomDataStorageObject_ce_ptr = NULL;

SB_PHP_METHOD(TElCustomDataStorageObject, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomDataStorageObject_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomDataStorageObject_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomDataStorageObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageObject, Clone)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomDataStorageObject_Clone(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageObject, get_Handler)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomDataStorageObject_get_Handler(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageSecurityHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageObject, get_Name)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElCustomDataStorageObject_get_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1280591424, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageObject, get_Secured)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomDataStorageObject_get_Secured(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageObject, get_RawSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElCustomDataStorageObject_get_RawSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageObject, get_Tag)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomDataStorageObject_get_Tag(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageObject, set_Tag)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TObject_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomDataStorageObject_set_Tag(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorageObject, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomDataStorageObject_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageObject_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomDataStorageObject, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageObject_Clone, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageObject_get_Handler, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageObject_get_Name, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageObject_get_Secured, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageObject_get_RawSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageObject_get_Tag, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageObject_set_Tag, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TObject, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorageObject___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElCustomDataStorageObject_methods[] = {
	PHP_ME(TElCustomDataStorageObject, Assign, arginfo_TElCustomDataStorageObject_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageObject, Clone, arginfo_TElCustomDataStorageObject_Clone, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageObject, get_Handler, arginfo_TElCustomDataStorageObject_get_Handler, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageObject, get_Name, arginfo_TElCustomDataStorageObject_get_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageObject, get_Secured, arginfo_TElCustomDataStorageObject_get_Secured, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageObject, get_RawSize, arginfo_TElCustomDataStorageObject_get_RawSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageObject, get_Tag, arginfo_TElCustomDataStorageObject_get_Tag, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageObject, set_Tag, arginfo_TElCustomDataStorageObject_set_Tag, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorageObject, __construct, arginfo_TElCustomDataStorageObject___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCustomDataStorageObject(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCustomDataStorageObject_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCustomDataStorageObject", TElCustomDataStorageObject_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElCustomDataStorageObject_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElCustomDataStorage_ce_ptr = NULL;

SB_PHP_METHOD(TElCustomDataStorage, AcquireObject)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomDataStorage_AcquireObject(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, ReleaseObject)
{
	TElClassHandle hoObj;
	zval *oObj;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oObj, TElCustomDataStorageObject_ce_ptr) == SUCCESS) && SB_ISREF_OBJECT_P(oObj))
	{
		hoObj = SBGetObjectHandle(oObj TSRMLS_CC);
		SBCheckError(TElCustomDataStorage_ReleaseObject(SBGetObjectHandle(getThis() TSRMLS_CC), &hoObj) TSRMLS_CC);
		SBUpdateObjectHandle(oObj, hoObj TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(&\\TElCustomDataStorageObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, ReadObject)
{
	zval *oObj;
	zval *oStrm;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oObj, TElCustomDataStorageObject_ce_ptr, &oStrm, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomDataStorage_ReadObject(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), SBGetObjectHandle(oStrm TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomDataStorageObject, \\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, WriteObject)
{
	zval *oHandler;
	zval *oObj;
	zval *oStrm;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oObj, TElCustomDataStorageObject_ce_ptr, &oStrm, TStream_ce_ptr, &oHandler, TElCustomDataStorageSecurityHandler_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomDataStorage_WriteObject(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), SBGetObjectHandle(oStrm TSRMLS_CC), SBGetObjectHandle(oHandler TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomDataStorageObject, \\TStream, \\TElCustomDataStorageSecurityHandler)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, ReadBlock)
{
	int64_t l8ReadRaw;
	sb_zend_long l8Offset;
	sb_zend_long l8Size;
	zval *oObj;
	zval *oStrm;
	zval *zl8Read;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!llz", &oObj, TElCustomDataStorageObject_ce_ptr, &oStrm, TStream_ce_ptr, &l8Offset, &l8Size, &zl8Read) == SUCCESS) && Z_ISREF_P(zl8Read) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl8Read))))
	{
		l8ReadRaw = (int64_t)Z_LVAL_P(Z_REFVAL_P(zl8Read));
		SBCheckError(TElCustomDataStorage_ReadBlock(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), SBGetObjectHandle(oStrm TSRMLS_CC), (int64_t)l8Offset, (int64_t)l8Size, &l8ReadRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zl8Read), (sb_zend_long)l8ReadRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomDataStorageObject, \\TStream, integer, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, WriteBlock)
{
	int64_t l8WrittenRaw;
	sb_zend_long l8Offset;
	zval *oHandler;
	zval *oObj;
	zval *oStrm;
	zval *zl8Written;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!lz", &oObj, TElCustomDataStorageObject_ce_ptr, &oStrm, TStream_ce_ptr, &oHandler, TElCustomDataStorageSecurityHandler_ce_ptr, &l8Offset, &zl8Written) == SUCCESS) && Z_ISREF_P(zl8Written) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl8Written))))
	{
		l8WrittenRaw = (int64_t)Z_LVAL_P(Z_REFVAL_P(zl8Written));
		SBCheckError(TElCustomDataStorage_WriteBlock(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), SBGetObjectHandle(oStrm TSRMLS_CC), SBGetObjectHandle(oHandler TSRMLS_CC), (int64_t)l8Offset, &l8WrittenRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zl8Written), (sb_zend_long)l8WrittenRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomDataStorageObject, \\TStream, \\TElCustomDataStorageSecurityHandler, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, DeleteObject)
{
	TElClassHandle hoObj;
	zval *oObj;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oObj, TElCustomDataStorageObject_ce_ptr) == SUCCESS) && SB_ISREF_OBJECT_P(oObj))
	{
		hoObj = SBGetObjectHandle(oObj TSRMLS_CC);
		SBCheckError(TElCustomDataStorage_DeleteObject(SBGetObjectHandle(getThis() TSRMLS_CC), &hoObj) TSRMLS_CC);
		SBUpdateObjectHandle(oObj, hoObj TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(&\\TElCustomDataStorageObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, GetProtectionInfo)
{
	zval *oObj;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oObj, TElCustomDataStorageObject_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomDataStorage_GetProtectionInfo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageSecurityHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomDataStorageObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, List)
{
	zval *oObjs;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oObjs, TElDataStorageObjectList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomDataStorage_List(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObjs TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDataStorageObjectList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, CopyObject)
{
	zval *oNewHandler;
	zval *oObj;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oObj, TElCustomDataStorageObject_ce_ptr, &oNewHandler, TElCustomDataStorageSecurityHandler_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomDataStorage_CopyObject(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), SBGetObjectHandle(oNewHandler TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomDataStorageObject, \\TElCustomDataStorageSecurityHandler)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, get_PassthroughMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomDataStorage_get_PassthroughMode(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, set_PassthroughMode)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCustomDataStorage_set_PassthroughMode(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, get_Overwrite)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomDataStorage_get_Overwrite(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, set_Overwrite)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCustomDataStorage_set_Overwrite(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, get_SecurityHandler)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomDataStorage_get_SecurityHandler(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageSecurityHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, set_SecurityHandler)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomDataStorageSecurityHandler_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomDataStorage_set_SecurityHandler(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomDataStorageSecurityHandler)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, get_ObjectInfoReadStrategy)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBProtectedObjectReadStrategyRaw fOutResultRaw = 0;
		SBCheckError(TElCustomDataStorage_get_ObjectInfoReadStrategy(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, set_ObjectInfoReadStrategy)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElCustomDataStorage_set_ObjectInfoReadStrategy(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBProtectedObjectReadStrategyRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, get_OnProgress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDataStorageProgressEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCustomDataStorage_get_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, set_OnProgress)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCustomDataStorage_set_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDataStorageProgressEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDataStorageProgressEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, get_OnOperationStart)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDataStorageOperationStartEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCustomDataStorage_get_OnOperationStart(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, set_OnOperationStart)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCustomDataStorage_set_OnOperationStart(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDataStorageOperationStartEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDataStorageOperationStartEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, get_OnOperationFinish)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDataStorageOperationFinishEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCustomDataStorage_get_OnOperationFinish(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, set_OnOperationFinish)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCustomDataStorage_set_OnOperationFinish(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDataStorageOperationFinishEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDataStorageOperationFinishEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, get_OnSecurityHandlerNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFDSSecurityHandlerNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCustomDataStorage_get_OnSecurityHandlerNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, set_OnSecurityHandlerNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCustomDataStorage_set_OnSecurityHandlerNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBFDSSecurityHandlerNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBFDSSecurityHandlerNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, get_OnSecurityHandlerCreated)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFDSSecurityHandlerCreatedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCustomDataStorage_get_OnSecurityHandlerCreated(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, set_OnSecurityHandlerCreated)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCustomDataStorage_set_OnSecurityHandlerCreated(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBFDSSecurityHandlerCreatedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBFDSSecurityHandlerCreatedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomDataStorage, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomDataStorage_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_AcquireObject, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_ReleaseObject, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(1, Obj, TElCustomDataStorageObject, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_ReadObject, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Obj, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Strm, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_WriteObject, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Obj, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Strm, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Handler, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_ReadBlock, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Obj, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Strm, 0, 1)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(1, Read)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_WriteBlock, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Obj, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Strm, TStream, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElCustomDataStorageSecurityHandler, 1)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(1, Written)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_DeleteObject, 0, 0, 1)
	ZEND_ARG_INFO(1, Obj)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_GetProtectionInfo, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Obj, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_List, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Objs, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_CopyObject, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Obj, 0, 1)
	ZEND_ARG_TYPE_INFO(0, NewHandler, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_get_PassthroughMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_set_PassthroughMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_get_Overwrite, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_set_Overwrite, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_get_SecurityHandler, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_set_SecurityHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomDataStorageSecurityHandler, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_get_ObjectInfoReadStrategy, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_set_ObjectInfoReadStrategy, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_get_OnProgress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_set_OnProgress, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_get_OnOperationStart, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_set_OnOperationStart, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_get_OnOperationFinish, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_set_OnOperationFinish, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_get_OnSecurityHandlerNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_set_OnSecurityHandlerNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_get_OnSecurityHandlerCreated, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage_set_OnSecurityHandlerCreated, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomDataStorage___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCustomDataStorage_methods[] = {
	PHP_ME(TElCustomDataStorage, AcquireObject, arginfo_TElCustomDataStorage_AcquireObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, ReleaseObject, arginfo_TElCustomDataStorage_ReleaseObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, ReadObject, arginfo_TElCustomDataStorage_ReadObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, WriteObject, arginfo_TElCustomDataStorage_WriteObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, ReadBlock, arginfo_TElCustomDataStorage_ReadBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, WriteBlock, arginfo_TElCustomDataStorage_WriteBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, DeleteObject, arginfo_TElCustomDataStorage_DeleteObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, GetProtectionInfo, arginfo_TElCustomDataStorage_GetProtectionInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, List, arginfo_TElCustomDataStorage_List, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, CopyObject, arginfo_TElCustomDataStorage_CopyObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, get_PassthroughMode, arginfo_TElCustomDataStorage_get_PassthroughMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, set_PassthroughMode, arginfo_TElCustomDataStorage_set_PassthroughMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, get_Overwrite, arginfo_TElCustomDataStorage_get_Overwrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, set_Overwrite, arginfo_TElCustomDataStorage_set_Overwrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, get_SecurityHandler, arginfo_TElCustomDataStorage_get_SecurityHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, set_SecurityHandler, arginfo_TElCustomDataStorage_set_SecurityHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, get_ObjectInfoReadStrategy, arginfo_TElCustomDataStorage_get_ObjectInfoReadStrategy, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, set_ObjectInfoReadStrategy, arginfo_TElCustomDataStorage_set_ObjectInfoReadStrategy, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, get_OnProgress, arginfo_TElCustomDataStorage_get_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, set_OnProgress, arginfo_TElCustomDataStorage_set_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, get_OnOperationStart, arginfo_TElCustomDataStorage_get_OnOperationStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, set_OnOperationStart, arginfo_TElCustomDataStorage_set_OnOperationStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, get_OnOperationFinish, arginfo_TElCustomDataStorage_get_OnOperationFinish, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, set_OnOperationFinish, arginfo_TElCustomDataStorage_set_OnOperationFinish, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, get_OnSecurityHandlerNeeded, arginfo_TElCustomDataStorage_get_OnSecurityHandlerNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, set_OnSecurityHandlerNeeded, arginfo_TElCustomDataStorage_set_OnSecurityHandlerNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, get_OnSecurityHandlerCreated, arginfo_TElCustomDataStorage_get_OnSecurityHandlerCreated, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, set_OnSecurityHandlerCreated, arginfo_TElCustomDataStorage_set_OnSecurityHandlerCreated, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomDataStorage, __construct, arginfo_TElCustomDataStorage___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCustomDataStorage(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCustomDataStorage_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCustomDataStorage", TElCustomDataStorage_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElCustomDataStorage_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElDefaultDataStorageSecurityHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, CanEncrypt)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_CanEncrypt(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, CanDecrypt)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_CanDecrypt(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, ClearCache)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_ClearCache(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElDefaultDataStorageSecurityHandler_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-420404516, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, GetOID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDefaultDataStorageSecurityHandler_GetOID(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1362081200, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDefaultDataStorageSecurityHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_CertIDs)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_CertIDs(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Issuer_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_CertIDCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_CertIDCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_DataSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_DataSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_GenericEncryptionKey)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDefaultDataStorageSecurityHandler_get_GenericEncryptionKey(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(908931814, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_GenericEncryptionKey)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_GenericEncryptionKey(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_GenericEncryptionKeys)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_GenericEncryptionKeys(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElByteArrayList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_GenericEncryptionKeyUsed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_GenericEncryptionKeyUsed(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_ProtectedUserData)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDefaultDataStorageSecurityHandler_get_ProtectedUserData(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(758319081, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_ProtectedUserData)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_ProtectedUserData(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_UnprotectedUserData)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDefaultDataStorageSecurityHandler_get_UnprotectedUserData(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(989181194, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_UnprotectedUserData)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_UnprotectedUserData(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_SignatureFound)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_SignatureFound(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_SignatureVerifier)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_SignatureVerifier(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElMessageVerifier_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_SignatureVerificationResult)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_SignatureVerificationResult(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_ObjectIntegrityRecordAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_ObjectIntegrityRecordAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_MetadataIntegrityRecordAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_MetadataIntegrityRecordAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_AuthBlockSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_AuthBlockSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_AuthBlockSize)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_AuthBlockSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_AuthDigestAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_AuthDigestAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_AuthDigestAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_AuthDigestAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_AuthDigestLocation)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDSDigestLocationRaw fOutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_AuthDigestLocation(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_AuthDigestLocation)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_AuthDigestLocation(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBDSDigestLocationRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_AuthHashSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_AuthHashSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_AuthHashSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_AuthHashSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_AuthInfoType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDSDataAuthInfoTypeRaw fOutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_AuthInfoType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_AuthInfoType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_AuthInfoType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBDSDataAuthInfoTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_AuthKeyLen)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_AuthKeyLen(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_AuthKeyLen)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_AuthKeyLen(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_CacheEncryptionKey)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_CacheEncryptionKey(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_CacheEncryptionKey)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_CacheEncryptionKey(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_DataEncryptionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_DataEncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_DataEncryptionAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_DataEncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_EncodingHandler)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_EncodingHandler(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageEncodingHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_EncodingHandler)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomDataStorageEncodingHandler_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_EncodingHandler(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomDataStorageEncodingHandler)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_EncryptionCertificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_EncryptionCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_EncryptionCertificates)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_EncryptionCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_KeyEncryptionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_KeyEncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_KeyEncryptionAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_KeyEncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_SigningCertificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_SigningCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_SigningCertificates)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_SigningCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_SignatureHashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_SignatureHashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_SignatureHashAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_SignatureHashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_ExtraTrailerSpace)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_ExtraTrailerSpace(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_ExtraTrailerSpace)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_ExtraTrailerSpace(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_OnSigningPrepared)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDataStorageSecHandlerSigningPreparedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_OnSigningPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_OnSigningPrepared)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_OnSigningPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDataStorageSecHandlerSigningPreparedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDataStorageSecHandlerSigningPreparedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, get_OnSignatureFound)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDataStorageSecHandlerSignatureFoundEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDefaultDataStorageSecurityHandler_get_OnSignatureFound(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, set_OnSignatureFound)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDefaultDataStorageSecurityHandler_set_OnSignatureFound(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDataStorageSecHandlerSignatureFoundEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDataStorageSecHandlerSignatureFoundEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDefaultDataStorageSecurityHandler, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDefaultDataStorageSecurityHandler_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_CanEncrypt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_CanDecrypt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_ClearCache, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_GetOID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_CertIDs, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_CertIDCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_DataSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_GenericEncryptionKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_GenericEncryptionKey, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_GenericEncryptionKeys, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_GenericEncryptionKeyUsed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_ProtectedUserData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_ProtectedUserData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_UnprotectedUserData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_UnprotectedUserData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_SignatureFound, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_SignatureVerifier, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_SignatureVerificationResult, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_ObjectIntegrityRecordAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_MetadataIntegrityRecordAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_AuthBlockSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_AuthBlockSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_AuthDigestAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_AuthDigestAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_AuthDigestLocation, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_AuthDigestLocation, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_AuthHashSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_AuthHashSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_AuthInfoType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_AuthInfoType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_AuthKeyLen, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_AuthKeyLen, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_CacheEncryptionKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_CacheEncryptionKey, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_DataEncryptionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_DataEncryptionAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_EncodingHandler, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_EncodingHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomDataStorageEncodingHandler, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_EncryptionCertificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_EncryptionCertificates, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_KeyEncryptionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_KeyEncryptionAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_SigningCertificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_SigningCertificates, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_SignatureHashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_SignatureHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_ExtraTrailerSpace, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_ExtraTrailerSpace, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_OnSigningPrepared, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_OnSigningPrepared, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_get_OnSignatureFound, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler_set_OnSignatureFound, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDefaultDataStorageSecurityHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElDefaultDataStorageSecurityHandler_methods[] = {
	PHP_ME(TElDefaultDataStorageSecurityHandler, CanEncrypt, arginfo_TElDefaultDataStorageSecurityHandler_CanEncrypt, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, CanDecrypt, arginfo_TElDefaultDataStorageSecurityHandler_CanDecrypt, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, ClearCache, arginfo_TElDefaultDataStorageSecurityHandler_ClearCache, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, GetDescription, arginfo_TElDefaultDataStorageSecurityHandler_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, GetOID, arginfo_TElDefaultDataStorageSecurityHandler_GetOID, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, Reset, arginfo_TElDefaultDataStorageSecurityHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, ClassType, arginfo_TElDefaultDataStorageSecurityHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_CertIDs, arginfo_TElDefaultDataStorageSecurityHandler_get_CertIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_CertIDCount, arginfo_TElDefaultDataStorageSecurityHandler_get_CertIDCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_DataSize, arginfo_TElDefaultDataStorageSecurityHandler_get_DataSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_GenericEncryptionKey, arginfo_TElDefaultDataStorageSecurityHandler_get_GenericEncryptionKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_GenericEncryptionKey, arginfo_TElDefaultDataStorageSecurityHandler_set_GenericEncryptionKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_GenericEncryptionKeys, arginfo_TElDefaultDataStorageSecurityHandler_get_GenericEncryptionKeys, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_GenericEncryptionKeyUsed, arginfo_TElDefaultDataStorageSecurityHandler_get_GenericEncryptionKeyUsed, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_ProtectedUserData, arginfo_TElDefaultDataStorageSecurityHandler_get_ProtectedUserData, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_ProtectedUserData, arginfo_TElDefaultDataStorageSecurityHandler_set_ProtectedUserData, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_UnprotectedUserData, arginfo_TElDefaultDataStorageSecurityHandler_get_UnprotectedUserData, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_UnprotectedUserData, arginfo_TElDefaultDataStorageSecurityHandler_set_UnprotectedUserData, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_SignatureFound, arginfo_TElDefaultDataStorageSecurityHandler_get_SignatureFound, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_SignatureVerifier, arginfo_TElDefaultDataStorageSecurityHandler_get_SignatureVerifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_SignatureVerificationResult, arginfo_TElDefaultDataStorageSecurityHandler_get_SignatureVerificationResult, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_ObjectIntegrityRecordAvailable, arginfo_TElDefaultDataStorageSecurityHandler_get_ObjectIntegrityRecordAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_MetadataIntegrityRecordAvailable, arginfo_TElDefaultDataStorageSecurityHandler_get_MetadataIntegrityRecordAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_AuthBlockSize, arginfo_TElDefaultDataStorageSecurityHandler_get_AuthBlockSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_AuthBlockSize, arginfo_TElDefaultDataStorageSecurityHandler_set_AuthBlockSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_AuthDigestAlgorithm, arginfo_TElDefaultDataStorageSecurityHandler_get_AuthDigestAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_AuthDigestAlgorithm, arginfo_TElDefaultDataStorageSecurityHandler_set_AuthDigestAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_AuthDigestLocation, arginfo_TElDefaultDataStorageSecurityHandler_get_AuthDigestLocation, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_AuthDigestLocation, arginfo_TElDefaultDataStorageSecurityHandler_set_AuthDigestLocation, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_AuthHashSize, arginfo_TElDefaultDataStorageSecurityHandler_get_AuthHashSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_AuthHashSize, arginfo_TElDefaultDataStorageSecurityHandler_set_AuthHashSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_AuthInfoType, arginfo_TElDefaultDataStorageSecurityHandler_get_AuthInfoType, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_AuthInfoType, arginfo_TElDefaultDataStorageSecurityHandler_set_AuthInfoType, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_AuthKeyLen, arginfo_TElDefaultDataStorageSecurityHandler_get_AuthKeyLen, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_AuthKeyLen, arginfo_TElDefaultDataStorageSecurityHandler_set_AuthKeyLen, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_CacheEncryptionKey, arginfo_TElDefaultDataStorageSecurityHandler_get_CacheEncryptionKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_CacheEncryptionKey, arginfo_TElDefaultDataStorageSecurityHandler_set_CacheEncryptionKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_DataEncryptionAlgorithm, arginfo_TElDefaultDataStorageSecurityHandler_get_DataEncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_DataEncryptionAlgorithm, arginfo_TElDefaultDataStorageSecurityHandler_set_DataEncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_EncodingHandler, arginfo_TElDefaultDataStorageSecurityHandler_get_EncodingHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_EncodingHandler, arginfo_TElDefaultDataStorageSecurityHandler_set_EncodingHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_EncryptionCertificates, arginfo_TElDefaultDataStorageSecurityHandler_get_EncryptionCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_EncryptionCertificates, arginfo_TElDefaultDataStorageSecurityHandler_set_EncryptionCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_KeyEncryptionAlgorithm, arginfo_TElDefaultDataStorageSecurityHandler_get_KeyEncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_KeyEncryptionAlgorithm, arginfo_TElDefaultDataStorageSecurityHandler_set_KeyEncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_SigningCertificates, arginfo_TElDefaultDataStorageSecurityHandler_get_SigningCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_SigningCertificates, arginfo_TElDefaultDataStorageSecurityHandler_set_SigningCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_SignatureHashAlgorithm, arginfo_TElDefaultDataStorageSecurityHandler_get_SignatureHashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_SignatureHashAlgorithm, arginfo_TElDefaultDataStorageSecurityHandler_set_SignatureHashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_ExtraTrailerSpace, arginfo_TElDefaultDataStorageSecurityHandler_get_ExtraTrailerSpace, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_ExtraTrailerSpace, arginfo_TElDefaultDataStorageSecurityHandler_set_ExtraTrailerSpace, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_OnSigningPrepared, arginfo_TElDefaultDataStorageSecurityHandler_get_OnSigningPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_OnSigningPrepared, arginfo_TElDefaultDataStorageSecurityHandler_set_OnSigningPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, get_OnSignatureFound, arginfo_TElDefaultDataStorageSecurityHandler_get_OnSignatureFound, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, set_OnSignatureFound, arginfo_TElDefaultDataStorageSecurityHandler_set_OnSignatureFound, ZEND_ACC_PUBLIC)
	PHP_ME(TElDefaultDataStorageSecurityHandler, __construct, arginfo_TElDefaultDataStorageSecurityHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDefaultDataStorageSecurityHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDefaultDataStorageSecurityHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDefaultDataStorageSecurityHandler", TElDefaultDataStorageSecurityHandler_methods);
	if (NULL == TElCustomDataStorageSecurityHandler_ce_ptr)
		Register_TElCustomDataStorageSecurityHandler(TSRMLS_C);
	TElDefaultDataStorageSecurityHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomDataStorageSecurityHandler_ce_ptr);
}

zend_class_entry *TElDataStorageSecurityHandlersFactory_ce_ptr = NULL;

SB_PHP_METHOD(TElDataStorageSecurityHandlersFactory, RegisterHandler)
{
	zval *oCls;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCls, TElDataStorageSecurityHandlerClass_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDataStorageSecurityHandlersFactory_RegisterHandler(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCls TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDataStorageSecurityHandlerClass)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDataStorageSecurityHandlersFactory, UnregisterHandler)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElDataStorageSecurityHandlersFactory_UnregisterHandler(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDataStorageSecurityHandlersFactory, CreateInstance)
{
	SBArrayZValInfo aiOID;
	zval *zaOID;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaOID) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDataStorageSecurityHandlersFactory_CreateInstance(SBGetObjectHandle(getThis() TSRMLS_CC), aiOID.data, aiOID.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		SBInitObject(return_value, TElCustomDataStorageSecurityHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDataStorageSecurityHandlersFactory, CreateInstanceFromMetadata)
{
	SBArrayZValInfo aiSecMetadata;
	zval *zaSecMetadata;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaSecMetadata) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSecMetadata) || SB_IS_ARRAY_TYPE_RP(zaSecMetadata) || SB_IS_NULL_TYPE_RP(zaSecMetadata)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaSecMetadata, &aiSecMetadata TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDataStorageSecurityHandlersFactory_CreateInstanceFromMetadata(SBGetObjectHandle(getThis() TSRMLS_CC), aiSecMetadata.data, aiSecMetadata.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiSecMetadata);
		SBInitObject(return_value, TElCustomDataStorageSecurityHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDataStorageSecurityHandlersFactory, get_RegisteredHandlers)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDataStorageSecurityHandlersFactory_get_RegisteredHandlers(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageSecurityHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDataStorageSecurityHandlersFactory, get_RegisteredHandlerCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDataStorageSecurityHandlersFactory_get_RegisteredHandlerCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDataStorageSecurityHandlersFactory, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDataStorageSecurityHandlersFactory_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageSecurityHandlersFactory_RegisterHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Cls, TElDataStorageSecurityHandlerClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageSecurityHandlersFactory_UnregisterHandler, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageSecurityHandlersFactory_CreateInstance, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageSecurityHandlersFactory_CreateInstanceFromMetadata, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, SecMetadata, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageSecurityHandlersFactory_get_RegisteredHandlers, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageSecurityHandlersFactory_get_RegisteredHandlerCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageSecurityHandlersFactory___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDataStorageSecurityHandlersFactory_methods[] = {
	PHP_ME(TElDataStorageSecurityHandlersFactory, RegisterHandler, arginfo_TElDataStorageSecurityHandlersFactory_RegisterHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElDataStorageSecurityHandlersFactory, UnregisterHandler, arginfo_TElDataStorageSecurityHandlersFactory_UnregisterHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElDataStorageSecurityHandlersFactory, CreateInstance, arginfo_TElDataStorageSecurityHandlersFactory_CreateInstance, ZEND_ACC_PUBLIC)
	PHP_ME(TElDataStorageSecurityHandlersFactory, CreateInstanceFromMetadata, arginfo_TElDataStorageSecurityHandlersFactory_CreateInstanceFromMetadata, ZEND_ACC_PUBLIC)
	PHP_ME(TElDataStorageSecurityHandlersFactory, get_RegisteredHandlers, arginfo_TElDataStorageSecurityHandlersFactory_get_RegisteredHandlers, ZEND_ACC_PUBLIC)
	PHP_ME(TElDataStorageSecurityHandlersFactory, get_RegisteredHandlerCount, arginfo_TElDataStorageSecurityHandlersFactory_get_RegisteredHandlerCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElDataStorageSecurityHandlersFactory, __construct, arginfo_TElDataStorageSecurityHandlersFactory___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDataStorageSecurityHandlersFactory(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDataStorageSecurityHandlersFactory_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDataStorageSecurityHandlersFactory", TElDataStorageSecurityHandlersFactory_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElDataStorageSecurityHandlersFactory_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElDataStorageEncodingHandlersFactory_ce_ptr = NULL;

SB_PHP_METHOD(TElDataStorageEncodingHandlersFactory, RegisterHandler)
{
	zval *oCls;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCls, TElDataStorageEncodingHandlerClass_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDataStorageEncodingHandlersFactory_RegisterHandler(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCls TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDataStorageEncodingHandlerClass)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDataStorageEncodingHandlersFactory, UnregisterHandler)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElDataStorageEncodingHandlersFactory_UnregisterHandler(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDataStorageEncodingHandlersFactory, CreateInstance)
{
	SBArrayZValInfo aiOID;
	SBArrayZValInfo aiParams;
	zval *zaOID;
	zval *zaParams;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaOID) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDataStorageEncodingHandlersFactory_CreateInstance(SBGetObjectHandle(getThis() TSRMLS_CC), aiOID.data, aiOID.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		SBInitObject(return_value, TElCustomDataStorageEncodingHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaOID, &zaParams) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)) && (SB_IS_STRING_TYPE_RP(zaParams) || SB_IS_ARRAY_TYPE_RP(zaParams) || SB_IS_NULL_TYPE_RP(zaParams)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaParams, &aiParams TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDataStorageEncodingHandlersFactory_CreateInstance_1(SBGetObjectHandle(getThis() TSRMLS_CC), aiOID.data, aiOID.len, aiParams.data, aiParams.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		SBFreeArrayZValInfo(&aiParams);
		SBInitObject(return_value, TElCustomDataStorageEncodingHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL) or (array of byte|string|NULL, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDataStorageEncodingHandlersFactory, get_RegisteredHandlers)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDataStorageEncodingHandlersFactory_get_RegisteredHandlers(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageEncodingHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDataStorageEncodingHandlersFactory, get_RegisteredHandlerCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDataStorageEncodingHandlersFactory_get_RegisteredHandlerCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDataStorageEncodingHandlersFactory, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDataStorageEncodingHandlersFactory_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageEncodingHandlersFactory_RegisterHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Cls, TElDataStorageEncodingHandlerClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageEncodingHandlersFactory_UnregisterHandler, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageEncodingHandlersFactory_CreateInstance, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Params, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageEncodingHandlersFactory_get_RegisteredHandlers, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageEncodingHandlersFactory_get_RegisteredHandlerCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDataStorageEncodingHandlersFactory___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDataStorageEncodingHandlersFactory_methods[] = {
	PHP_ME(TElDataStorageEncodingHandlersFactory, RegisterHandler, arginfo_TElDataStorageEncodingHandlersFactory_RegisterHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElDataStorageEncodingHandlersFactory, UnregisterHandler, arginfo_TElDataStorageEncodingHandlersFactory_UnregisterHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElDataStorageEncodingHandlersFactory, CreateInstance, arginfo_TElDataStorageEncodingHandlersFactory_CreateInstance, ZEND_ACC_PUBLIC)
	PHP_ME(TElDataStorageEncodingHandlersFactory, get_RegisteredHandlers, arginfo_TElDataStorageEncodingHandlersFactory_get_RegisteredHandlers, ZEND_ACC_PUBLIC)
	PHP_ME(TElDataStorageEncodingHandlersFactory, get_RegisteredHandlerCount, arginfo_TElDataStorageEncodingHandlersFactory_get_RegisteredHandlerCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElDataStorageEncodingHandlersFactory, __construct, arginfo_TElDataStorageEncodingHandlersFactory___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDataStorageEncodingHandlersFactory(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDataStorageEncodingHandlersFactory_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDataStorageEncodingHandlersFactory", TElDataStorageEncodingHandlersFactory_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElDataStorageEncodingHandlersFactory_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

SB_PHP_FUNCTION(SBDataStorage, DataStorageSecurityHandlersFactory)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(SBDataStorage_DataStorageSecurityHandlersFactory(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDataStorageSecurityHandlersFactory_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDataStorage, DataStorageEncodingHandlersFactory)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(SBDataStorage_DataStorageEncodingHandlersFactory(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDataStorageEncodingHandlersFactory_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

void Register_SBDataStorage_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SB_DEFSECHANDLER_MD_NAME, SB_DEFSECHANDLER_MD_NAME, SB_DEFSECHANDLER_MD_NAME);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SB_CONTENTLENGTH_MD_NAME, SB_CONTENTLENGTH_MD_NAME, SB_CONTENTLENGTH_MD_NAME);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, ERROR_FACILITY_CLOUD, SB_ERROR_FACILITY_CLOUD, SB_ERROR_FACILITY_CLOUD);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, ERROR_CLOUD_ERROR_FLAG, SB_ERROR_CLOUD_ERROR_FLAG, SB_ERROR_CLOUD_ERROR_FLAG);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_BASE, SB_CLOUD_ERROR_BASE, SB_CLOUD_ERROR_BASE);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_INTERNAL_ERROR, SB_CLOUD_ERROR_INTERNAL_ERROR, SB_CLOUD_ERROR_INTERNAL_ERROR);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_UNSUPPORTED_OPERATION, SB_CLOUD_ERROR_UNSUPPORTED_OPERATION, SB_CLOUD_ERROR_UNSUPPORTED_OPERATION);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_UNSUPPORTED_MD_LOCATION, SB_CLOUD_ERROR_UNSUPPORTED_MD_LOCATION, SB_CLOUD_ERROR_UNSUPPORTED_MD_LOCATION);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_WRONG_METADATA_MODE, SB_CLOUD_ERROR_WRONG_METADATA_MODE, SB_CLOUD_ERROR_WRONG_METADATA_MODE);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_CRC_CHECK_IN_PT_ONLY, SB_CLOUD_ERROR_CRC_CHECK_IN_PT_ONLY, SB_CLOUD_ERROR_CRC_CHECK_IN_PT_ONLY);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_HTTP_REQUEST_FAILED, SB_CLOUD_ERROR_HTTP_REQUEST_FAILED, SB_CLOUD_ERROR_HTTP_REQUEST_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_BAD_PARAMETERS, SB_CLOUD_ERROR_BAD_PARAMETERS, SB_CLOUD_ERROR_BAD_PARAMETERS);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_LISTING_COMPLETED, SB_CLOUD_ERROR_LISTING_COMPLETED, SB_CLOUD_ERROR_LISTING_COMPLETED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_OBJECT_EXISTS, SB_CLOUD_ERROR_OBJECT_EXISTS, SB_CLOUD_ERROR_OBJECT_EXISTS);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_NOT_IMPLEMENTED, SB_CLOUD_ERROR_NOT_IMPLEMENTED, SB_CLOUD_ERROR_NOT_IMPLEMENTED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_NO_BUCKET, SB_CLOUD_ERROR_NO_BUCKET, SB_CLOUD_ERROR_NO_BUCKET);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_UNEXPECTED_MESSAGE, SB_CLOUD_ERROR_UNEXPECTED_MESSAGE, SB_CLOUD_ERROR_UNEXPECTED_MESSAGE);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_VERSIONING_DISABLED, SB_CLOUD_ERROR_VERSIONING_DISABLED, SB_CLOUD_ERROR_VERSIONING_DISABLED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_BAD_NOTIFY_CONFIG, SB_CLOUD_ERROR_BAD_NOTIFY_CONFIG, SB_CLOUD_ERROR_BAD_NOTIFY_CONFIG);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_OPERATION_FAILED, SB_CLOUD_ERROR_OPERATION_FAILED, SB_CLOUD_ERROR_OPERATION_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_NO_HTTP_CLIENT, SB_CLOUD_ERROR_NO_HTTP_CLIENT, SB_CLOUD_ERROR_NO_HTTP_CLIENT);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_INVALID_OBJECT_NAME, SB_CLOUD_ERROR_INVALID_OBJECT_NAME, SB_CLOUD_ERROR_INVALID_OBJECT_NAME);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_INVALID_JSON_RESPONSE, SB_CLOUD_ERROR_INVALID_JSON_RESPONSE, SB_CLOUD_ERROR_INVALID_JSON_RESPONSE);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_INVALID_ACCOUNT_INFO, SB_CLOUD_ERROR_INVALID_ACCOUNT_INFO, SB_CLOUD_ERROR_INVALID_ACCOUNT_INFO);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_INVALID_OBJECT_KIND, SB_CLOUD_ERROR_INVALID_OBJECT_KIND, SB_CLOUD_ERROR_INVALID_OBJECT_KIND);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_INVALID_OPERATION, SB_CLOUD_ERROR_INVALID_OPERATION, SB_CLOUD_ERROR_INVALID_OPERATION);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_INVALID_RESPONSE, SB_CLOUD_ERROR_INVALID_RESPONSE, SB_CLOUD_ERROR_INVALID_RESPONSE);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_INVALID_OBJECT_ID, SB_CLOUD_ERROR_INVALID_OBJECT_ID, SB_CLOUD_ERROR_INVALID_OBJECT_ID);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_INVALID_AUTH_CODE, SB_CLOUD_ERROR_INVALID_AUTH_CODE, SB_CLOUD_ERROR_INVALID_AUTH_CODE);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_INTERRUPTED_BY_USER, SB_CLOUD_ERROR_INTERRUPTED_BY_USER, SB_CLOUD_ERROR_INTERRUPTED_BY_USER);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_STORAGE_NOT_FOUND, SB_CLOUD_ERROR_STORAGE_NOT_FOUND, SB_CLOUD_ERROR_STORAGE_NOT_FOUND);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_STREAM_NOT_READABLE, SB_CLOUD_ERROR_STREAM_NOT_READABLE, SB_CLOUD_ERROR_STREAM_NOT_READABLE);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_STREAM_NOT_WRITEABLE, SB_CLOUD_ERROR_STREAM_NOT_WRITEABLE, SB_CLOUD_ERROR_STREAM_NOT_WRITEABLE);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_EDIT_MEDIA_URL_NOT_FOUND, SB_CLOUD_ERROR_EDIT_MEDIA_URL_NOT_FOUND, SB_CLOUD_ERROR_EDIT_MEDIA_URL_NOT_FOUND);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_UNSUPPORTED_FEATURE, SB_CLOUD_ERROR_UNSUPPORTED_FEATURE, SB_CLOUD_ERROR_UNSUPPORTED_FEATURE);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_CANT_MODIFY_METADATA, SB_CLOUD_ERROR_CANT_MODIFY_METADATA, SB_CLOUD_ERROR_CANT_MODIFY_METADATA);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_CANT_COPY_FOLDERS, SB_CLOUD_ERROR_CANT_COPY_FOLDERS, SB_CLOUD_ERROR_CANT_COPY_FOLDERS);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_EDIT_URL_NOT_FOUND, SB_CLOUD_ERROR_EDIT_URL_NOT_FOUND, SB_CLOUD_ERROR_EDIT_URL_NOT_FOUND);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_OBJECT_NOT_FOUND, SB_CLOUD_ERROR_OBJECT_NOT_FOUND, SB_CLOUD_ERROR_OBJECT_NOT_FOUND);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_AUTH_FAILED, SB_CLOUD_ERROR_AUTH_FAILED, SB_CLOUD_ERROR_AUTH_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_OBJECT_NOT_FOLDER, SB_CLOUD_ERROR_OBJECT_NOT_FOLDER, SB_CLOUD_ERROR_OBJECT_NOT_FOLDER);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_OBJECT_URL_NOT_AVAIL, SB_CLOUD_ERROR_OBJECT_URL_NOT_AVAIL, SB_CLOUD_ERROR_OBJECT_URL_NOT_AVAIL);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_FILE_INACCESSIBLE, SB_CLOUD_ERROR_FILE_INACCESSIBLE, SB_CLOUD_ERROR_FILE_INACCESSIBLE);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_AUTH_NOT_STARTED, SB_CLOUD_ERROR_AUTH_NOT_STARTED, SB_CLOUD_ERROR_AUTH_NOT_STARTED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_UPLOAD_NOT_STARTED, SB_CLOUD_ERROR_UPLOAD_NOT_STARTED, SB_CLOUD_ERROR_UPLOAD_NOT_STARTED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_UPLOAD_NOT_COMPLETED, SB_CLOUD_ERROR_UPLOAD_NOT_COMPLETED, SB_CLOUD_ERROR_UPLOAD_NOT_COMPLETED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_CANT_PRESERVE_METADATA, SB_CLOUD_ERROR_CANT_PRESERVE_METADATA, SB_CLOUD_ERROR_CANT_PRESERVE_METADATA);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_FAILED_GET_COPY_REF, SB_CLOUD_ERROR_FAILED_GET_COPY_REF, SB_CLOUD_ERROR_FAILED_GET_COPY_REF);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_CANT_CONSTRUCT_MDPATH, SB_CLOUD_ERROR_CANT_CONSTRUCT_MDPATH, SB_CLOUD_ERROR_CANT_CONSTRUCT_MDPATH);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_BAD_JSON_OBJ, SB_CLOUD_ERROR_BAD_JSON_OBJ, SB_CLOUD_ERROR_BAD_JSON_OBJ);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_PROPERTY_NOT_FOUND, SB_CLOUD_ERROR_PROPERTY_NOT_FOUND, SB_CLOUD_ERROR_PROPERTY_NOT_FOUND);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_RESUME_UPLOAD_FAILED, SB_CLOUD_ERROR_RESUME_UPLOAD_FAILED, SB_CLOUD_ERROR_RESUME_UPLOAD_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_RESUME_INVALID_RANGE, SB_CLOUD_ERROR_RESUME_INVALID_RANGE, SB_CLOUD_ERROR_RESUME_INVALID_RANGE);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_SERVER_REPORTED_ERROR, SB_CLOUD_ERROR_SERVER_REPORTED_ERROR, SB_CLOUD_ERROR_SERVER_REPORTED_ERROR);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_NO_RESUME_ID, SB_CLOUD_ERROR_NO_RESUME_ID, SB_CLOUD_ERROR_NO_RESUME_ID);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_WRONG_OBJECT_TYPE, SB_CLOUD_ERROR_WRONG_OBJECT_TYPE, SB_CLOUD_ERROR_WRONG_OBJECT_TYPE);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_COMMENTS_NOT_ENABLED, SB_CLOUD_ERROR_COMMENTS_NOT_ENABLED, SB_CLOUD_ERROR_COMMENTS_NOT_ENABLED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_TAGS_NOT_ENABLED, SB_CLOUD_ERROR_TAGS_NOT_ENABLED, SB_CLOUD_ERROR_TAGS_NOT_ENABLED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_NO_AUTH_EVENT_HANDLER, SB_CLOUD_ERROR_NO_AUTH_EVENT_HANDLER, SB_CLOUD_ERROR_NO_AUTH_EVENT_HANDLER);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_COPY_FAILED, SB_CLOUD_ERROR_COPY_FAILED, SB_CLOUD_ERROR_COPY_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_COPY_TIMEOUT, SB_CLOUD_ERROR_COPY_TIMEOUT, SB_CLOUD_ERROR_COPY_TIMEOUT);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_ACCESS_DENIED, SB_CLOUD_ERROR_ACCESS_DENIED, SB_CLOUD_ERROR_ACCESS_DENIED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_CONTENT_NOT_READY, SB_CLOUD_ERROR_CONTENT_NOT_READY, SB_CLOUD_ERROR_CONTENT_NOT_READY);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_FAILED_BITS_SESSION, SB_CLOUD_ERROR_FAILED_BITS_SESSION, SB_CLOUD_ERROR_FAILED_BITS_SESSION);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_ACCESS_TOKEN_EXPIRED, SB_CLOUD_ERROR_ACCESS_TOKEN_EXPIRED, SB_CLOUD_ERROR_ACCESS_TOKEN_EXPIRED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_BAD_STREAM, SB_CLOUD_ERROR_BAD_STREAM, SB_CLOUD_ERROR_BAD_STREAM);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_OPERATION_TIMEOUT, SB_CLOUD_ERROR_OPERATION_TIMEOUT, SB_CLOUD_ERROR_OPERATION_TIMEOUT);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_FOLDER_NOT_SHARED, SB_CLOUD_ERROR_FOLDER_NOT_SHARED, SB_CLOUD_ERROR_FOLDER_NOT_SHARED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_FILE_NOT_SHARED, SB_CLOUD_ERROR_FILE_NOT_SHARED, SB_CLOUD_ERROR_FILE_NOT_SHARED);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_CANT_DELETE_DELETED_OBJECT, SB_CLOUD_ERROR_CANT_DELETE_DELETED_OBJECT, SB_CLOUD_ERROR_CANT_DELETE_DELETED_OBJECT);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_CANT_COPY_DELETED_OBJECT, SB_CLOUD_ERROR_CANT_COPY_DELETED_OBJECT, SB_CLOUD_ERROR_CANT_COPY_DELETED_OBJECT);
	SB_REGISTER_LONG_CONSTANT(SBDataStorage, SB_CLOUD_ERROR_UNSUPPORTED_OBJECT_TYPE, SB_CLOUD_ERROR_UNSUPPORTED_OBJECT_TYPE, SB_CLOUD_ERROR_UNSUPPORTED_OBJECT_TYPE);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SBadSecurityInfo, SB_SBadSecurityInfo, SB_SBadSecurityInfo);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SBadContentType, SB_SBadContentType, SB_SBadContentType);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SBadKeyInfo, SB_SBadKeyInfo, SB_SBadKeyInfo);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SBadEnvelopedData, SB_SBadEnvelopedData, SB_SBadEnvelopedData);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SBadAuthInfo, SB_SBadAuthInfo, SB_SBadAuthInfo);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SUnsupportedOperation, SB_SUnsupportedOperation, SB_SUnsupportedOperation);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SNoEncryptionCertificatesFound, SB_SNoEncryptionCertificatesFound, SB_SNoEncryptionCertificatesFound);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SNoEncryptionKeyMaterialFound, SB_SNoEncryptionKeyMaterialFound, SB_SNoEncryptionKeyMaterialFound);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SBadKeyMaterial, SB_SBadKeyMaterial, SB_SBadKeyMaterial);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SFailedToCreateSecurityHandler, SB_SFailedToCreateSecurityHandler, SB_SFailedToCreateSecurityHandler);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SFailedToExtractKeyMaterial, SB_SFailedToExtractKeyMaterial, SB_SFailedToExtractKeyMaterial);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SObjectIsStoredInUnencryptedForm, SB_SObjectIsStoredInUnencryptedForm, SB_SObjectIsStoredInUnencryptedForm);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SEncryptionKeyNotAvailable, SB_SEncryptionKeyNotAvailable, SB_SEncryptionKeyNotAvailable);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SObjectDoesNotExist, SB_SObjectDoesNotExist, SB_SObjectDoesNotExist);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SBadBlockSize, SB_SBadBlockSize, SB_SBadBlockSize);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SOffsetShouldBeAMultipleOfBlockSize, SB_SOffsetShouldBeAMultipleOfBlockSize, SB_SOffsetShouldBeAMultipleOfBlockSize);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SSizeShouldBeAMultipleOfBlockSize, SB_SSizeShouldBeAMultipleOfBlockSize, SB_SSizeShouldBeAMultipleOfBlockSize);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SDataAuthenticationFailed, SB_SDataAuthenticationFailed, SB_SDataAuthenticationFailed);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SCannotCopyUnprotectedObjectToProtected, SB_SCannotCopyUnprotectedObjectToProtected, SB_SCannotCopyUnprotectedObjectToProtected);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SCannotCopyProtectedObjectToUnprotected, SB_SCannotCopyProtectedObjectToUnprotected, SB_SCannotCopyProtectedObjectToUnprotected);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SUnsupportedSecurityHandlerType, SB_SUnsupportedSecurityHandlerType, SB_SUnsupportedSecurityHandlerType);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SRandomAccessNotSupported, SB_SRandomAccessNotSupported, SB_SRandomAccessNotSupported);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SExtAuthNotSupportedByHandler, SB_SExtAuthNotSupportedByHandler, SB_SExtAuthNotSupportedByHandler);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SKeyEncryptionAlgorithmNotSet, SB_SKeyEncryptionAlgorithmNotSet, SB_SKeyEncryptionAlgorithmNotSet);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SUnsupportedHMACAlgorithm, SB_SUnsupportedHMACAlgorithm, SB_SUnsupportedHMACAlgorithm);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SBadUserDataChecksum, SB_SBadUserDataChecksum, SB_SBadUserDataChecksum);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SUnsupportedDataEncryptionAlgorithm, SB_SUnsupportedDataEncryptionAlgorithm, SB_SUnsupportedDataEncryptionAlgorithm);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SUnsupportedKeyEncryptionAlgorithm, SB_SUnsupportedKeyEncryptionAlgorithm, SB_SUnsupportedKeyEncryptionAlgorithm);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SUnsupportedAuthInfoType, SB_SUnsupportedAuthInfoType, SB_SUnsupportedAuthInfoType);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SPerBlockAccessUnsupported, SB_SPerBlockAccessUnsupported, SB_SPerBlockAccessUnsupported);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SOperationUnsupportedInExtMDMode, SB_SOperationUnsupportedInExtMDMode, SB_SOperationUnsupportedInExtMDMode);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SMetadataDigestMismatch, SB_SMetadataDigestMismatch, SB_SMetadataDigestMismatch);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SIncompatibleDestinationSecurityHandler, SB_SIncompatibleDestinationSecurityHandler, SB_SIncompatibleDestinationSecurityHandler);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SStreamObjectIsBad, SB_SStreamObjectIsBad, SB_SStreamObjectIsBad);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SInvalidAccountInfo, SB_SInvalidAccountInfo, SB_SInvalidAccountInfo);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SInvalidJsonResponse, SB_SInvalidJsonResponse, SB_SInvalidJsonResponse);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SInvalidObjectKind, SB_SInvalidObjectKind, SB_SInvalidObjectKind);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SInvalidObjectID, SB_SInvalidObjectID, SB_SInvalidObjectID);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SWrongObjectType, SB_SWrongObjectType, SB_SWrongObjectType);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SAttemptToAccessMetadataFilesInEmbMDMode, SB_SAttemptToAccessMetadataFilesInEmbMDMode, SB_SAttemptToAccessMetadataFilesInEmbMDMode);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SOperationTimeout, SB_SOperationTimeout, SB_SOperationTimeout);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SFolderNotShared, SB_SFolderNotShared, SB_SFolderNotShared);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SFileNotShared, SB_SFileNotShared, SB_SFileNotShared);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SCantDeleteDeletedObject, SB_SCantDeleteDeletedObject, SB_SCantDeleteDeletedObject);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SCantCopyDeletedObject, SB_SCantCopyDeletedObject, SB_SCantCopyDeletedObject);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SUnsupportedObjectType, SB_SUnsupportedObjectType, SB_SUnsupportedObjectType);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SHandlerAlreadyRegisteredStr, SB_SHandlerAlreadyRegisteredStr, SB_SHandlerAlreadyRegisteredStr);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SHandlerNotFoundStr, SB_SHandlerNotFoundStr, SB_SHandlerNotFoundStr);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SEncodingHandlerAlreadyRegisteredStr, SB_SEncodingHandlerAlreadyRegisteredStr, SB_SEncodingHandlerAlreadyRegisteredStr);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SEncodingHandlerNotFoundStr, SB_SEncodingHandlerNotFoundStr, SB_SEncodingHandlerNotFoundStr);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SBadSecurityInfoInt, SB_SBadSecurityInfoInt, SB_SBadSecurityInfoInt);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SDecryptionErrorInt, SB_SDecryptionErrorInt, SB_SDecryptionErrorInt);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SEncryptionErrorInt, SB_SEncryptionErrorInt, SB_SEncryptionErrorInt);
	SB_REGISTER_STRING_CONSTANT(SBDataStorage, SSignatureValidationFailed, SB_SSignatureValidationFailed, SB_SSignatureValidationFailed);
}

void Register_SBDataStorage_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBDSDataAuthInfoType", NULL);
	TSBDSDataAuthInfoType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBDSDataAuthInfoType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBDSDataAuthInfoType_ce_ptr, "aitNone", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBDSDataAuthInfoType_ce_ptr, "aitBasic", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBDSDataAuthInfoType_ce_ptr, "aitExtended", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBDSDigestLocation", NULL);
	TSBDSDigestLocation_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBDSDigestLocation_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBDSDigestLocation_ce_ptr, "dlLocal", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBDSDigestLocation_ce_ptr, "dlAppended", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBDSDigestLocation_ce_ptr, "dlEmbedded", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBDataStorageOperation", NULL);
	TSBDataStorageOperation_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBDataStorageOperation_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBDataStorageOperation_ce_ptr, "dsoNone", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBDataStorageOperation_ce_ptr, "dsoRead", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBDataStorageOperation_ce_ptr, "dsoWrite", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBDataStorageOperation_ce_ptr, "dsoList", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBDataStorageOperation_ce_ptr, "dsoDelete", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBDataStorageOperation_ce_ptr, "dsoCopy", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBDataStorageOperation_ce_ptr, "dsoRename", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBDataStorageOperation_ce_ptr, "dsoReadInfo", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBDataStorageOperation_ce_ptr, "dsoWriteInfo", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBDataStorageOperation_ce_ptr, "dsoOther", 9)
	SB_DECLARE_CLASS_LONG_CONST(TSBDataStorageOperation_ce_ptr, "dsoLock", 10)
	SB_DECLARE_CLASS_LONG_CONST(TSBDataStorageOperation_ce_ptr, "dsoUnlock", 11)
	
	INIT_CLASS_ENTRY(ce, "TSBDSDataStorageFeature", NULL);
	TSBDSDataStorageFeature_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBDSDataStorageFeature_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBDSDataStorageFeature_ce_ptr, "dsfObjectRead", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBDSDataStorageFeature_ce_ptr, "dsfObjectWrite", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBDSDataStorageFeature_ce_ptr, "dsfBlockRead", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBDSDataStorageFeature_ce_ptr, "dsfBlockWrite", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBDSDataStorageFeature_ce_ptr, "dsfMetadataGet", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBDSDataStorageFeature_ce_ptr, "dsfMetadataSet", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBDSDataStorageFeature_ce_ptr, "dsfCopy", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBDSDataStorageFeature_ce_ptr, "dsfDelete", 7)
	
	INIT_CLASS_ENTRY(ce, "TSBEncodingHandlerFeature", NULL);
	TSBEncodingHandlerFeature_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBEncodingHandlerFeature_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBEncodingHandlerFeature_ce_ptr, "ehfObjectEncoding", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncodingHandlerFeature_ce_ptr, "ehfObjectDecoding", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncodingHandlerFeature_ce_ptr, "ehfRandomAccessEncoding", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncodingHandlerFeature_ce_ptr, "ehfRandomAccessDecoding", 3)
}

void Register_SBDataStorage_Aliases(TSRMLS_D)
{
	TElDSKeyProtectionHandlerClass_ce_ptr = TObject_ce_ptr;
	zend_register_class_alias("TElDSKeyProtectionHandlerClass", TElDSKeyProtectionHandlerClass_ce_ptr);
	TElDataStorageSecurityHandlerClass_ce_ptr = TObject_ce_ptr;
	zend_register_class_alias("TElDataStorageSecurityHandlerClass", TElDataStorageSecurityHandlerClass_ce_ptr);
	TElDataStorageEncodingHandlerClass_ce_ptr = TObject_ce_ptr;
	zend_register_class_alias("TElDataStorageEncodingHandlerClass", TElDataStorageEncodingHandlerClass_ce_ptr);
}

