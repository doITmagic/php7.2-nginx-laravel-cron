#include "sbdatastorageencodings.h"

zend_class_entry *TElZlibDataStorageEncodingHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElZlibDataStorageEncodingHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElZlibDataStorageEncodingHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZlibDataStorageEncodingHandler, GetOID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElZlibDataStorageEncodingHandler_GetOID(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1343821601, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZlibDataStorageEncodingHandler, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZlibDataStorageEncodingHandler_GetDescription(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1839675731, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZlibDataStorageEncodingHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZlibDataStorageEncodingHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZlibDataStorageEncodingHandler, get_CompressionLevel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElZlibDataStorageEncodingHandler_get_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZlibDataStorageEncodingHandler, set_CompressionLevel)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElZlibDataStorageEncodingHandler_set_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZlibDataStorageEncodingHandler, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZlibDataStorageEncodingHandler_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZlibDataStorageEncodingHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZlibDataStorageEncodingHandler_GetOID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZlibDataStorageEncodingHandler_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZlibDataStorageEncodingHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZlibDataStorageEncodingHandler_get_CompressionLevel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZlibDataStorageEncodingHandler_set_CompressionLevel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZlibDataStorageEncodingHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElZlibDataStorageEncodingHandler_methods[] = {
	PHP_ME(TElZlibDataStorageEncodingHandler, Reset, arginfo_TElZlibDataStorageEncodingHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElZlibDataStorageEncodingHandler, GetOID, arginfo_TElZlibDataStorageEncodingHandler_GetOID, ZEND_ACC_PUBLIC)
	PHP_ME(TElZlibDataStorageEncodingHandler, GetDescription, arginfo_TElZlibDataStorageEncodingHandler_GetDescription, ZEND_ACC_PUBLIC)
	PHP_ME(TElZlibDataStorageEncodingHandler, ClassType, arginfo_TElZlibDataStorageEncodingHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElZlibDataStorageEncodingHandler, get_CompressionLevel, arginfo_TElZlibDataStorageEncodingHandler_get_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElZlibDataStorageEncodingHandler, set_CompressionLevel, arginfo_TElZlibDataStorageEncodingHandler_set_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElZlibDataStorageEncodingHandler, __construct, arginfo_TElZlibDataStorageEncodingHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZlibDataStorageEncodingHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZlibDataStorageEncodingHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZlibDataStorageEncodingHandler", TElZlibDataStorageEncodingHandler_methods);
	if (NULL == TElCustomDataStorageEncodingHandler_ce_ptr)
		Register_TElCustomDataStorageEncodingHandler(TSRMLS_C);
	TElZlibDataStorageEncodingHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomDataStorageEncodingHandler_ce_ptr);
}

