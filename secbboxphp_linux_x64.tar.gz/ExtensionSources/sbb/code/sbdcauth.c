#include "sbdcauth.h"

zend_class_entry *TSBAuthResult_ce_ptr = NULL;

void SB_CALLBACK TSBDCAuthStartEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pData[], int32_t szData, int64_t StartTime, int8_t * DoContinue)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zData;
	zval * zStartTime;
	zval * zDoContinue;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SB_ZVAL_STRINGL_DUP(zData, pData, szData);
	SB_EVENT_INIT_ZVAL(zStartTime, 2);
	object_init_ex(zStartTime, php_date_get_date_ce());
	SBSetDateTime(zStartTime, StartTime TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zDoContinue, 3);
	ZVAL_BOOL(Z_REFVAL_P(zDoContinue), (zend_bool)*DoContinue);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zStartTime);
	convert_to_boolean(Z_REFVAL_P(zDoContinue));
	*DoContinue = (int8_t)SB_BVAL_P(Z_REFVAL_P(zDoContinue));
	SB_EVENT_CLEAR_ZVAL(zDoContinue);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBDCAuthSigningCertNeededEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pData[], int32_t szData, int64_t StartTime, TElX509CertificateHandle * Cert)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zData;
	zval * zStartTime;
	zval * zCert;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SB_ZVAL_STRINGL_DUP(zData, pData, szData);
	SB_EVENT_INIT_ZVAL(zStartTime, 2);
	object_init_ex(zStartTime, php_date_get_date_ce());
	SBSetDateTime(zStartTime, StartTime TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zCert, 3);
	SBInitObject(zCert, TElX509Certificate_ce_ptr, *Cert TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zStartTime);
	*Cert = SBGetObjectHandleCE(zCert, TElX509Certificate_ce_ptr TSRMLS_CC);
	SBDetachObjectHandleIfUniqueZVal(zCert TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zCert);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElDCAuthToken_ce_ptr = NULL;

SB_PHP_METHOD(TElDCAuthToken, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDCAuthToken_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCAuthToken, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDCAuthToken_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCAuthToken, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDCAuthToken_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCAuthToken, Validate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBAuthResultRaw fOutResultRaw = 0;
		SBCheckError(TElDCAuthToken_Validate(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCAuthToken, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCAuthToken_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCAuthToken_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCAuthToken_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCAuthToken_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCAuthToken_Validate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCAuthToken___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDCAuthToken_methods[] = {
	PHP_ME(TElDCAuthToken, LoadFromStream, arginfo_TElDCAuthToken_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCAuthToken, SaveToStream, arginfo_TElDCAuthToken_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCAuthToken, Clear, arginfo_TElDCAuthToken_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCAuthToken, Validate, arginfo_TElDCAuthToken_Validate, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCAuthToken, __construct, arginfo_TElDCAuthToken___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDCAuthToken(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDCAuthToken_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDCAuthToken", TElDCAuthToken_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElDCAuthToken_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElCustomAuthenticator_ce_ptr = NULL;

SB_PHP_METHOD(TElCustomAuthenticator, StartAuthentication)
{
	SBArrayZValInfo aiData;
	zval *zaData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomAuthenticator_StartAuthentication(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCustomAuthenticator_StartAuthentication_1(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomAuthenticator, ContinueAuthentication)
{
	TElClassHandle hoAuthToken;
	TElClassHandle hoNextState;
	zval *oAuthToken;
	zval *oNextState;
	zval *oState;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!OO", &oState, TElDCAsyncState_ce_ptr, &oNextState, TElDCAsyncState_ce_ptr, &oAuthToken, TElDCAuthToken_ce_ptr) == SUCCESS) && SB_ISREF_OBJECT_P(oNextState) && SB_ISREF_OBJECT_P(oAuthToken))
	{
		TSBAuthResultRaw fOutResultRaw = 0;
		hoNextState = SBGetObjectHandle(oNextState TSRMLS_CC);
		hoAuthToken = SBGetObjectHandle(oAuthToken TSRMLS_CC);
		SBCheckError(TElCustomAuthenticator_ContinueAuthentication(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oState TSRMLS_CC), &hoNextState, &hoAuthToken, &fOutResultRaw) TSRMLS_CC);
		SBUpdateObjectHandle(oNextState, hoNextState TSRMLS_CC);
		SBUpdateObjectHandle(oAuthToken, hoAuthToken TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDCAsyncState, &\\TElDCAsyncState, &\\TElDCAuthToken)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomAuthenticator, get_LastAuthResult)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBAuthResultRaw fOutResultRaw = 0;
		SBCheckError(TElCustomAuthenticator_get_LastAuthResult(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomAuthenticator, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomAuthenticator_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomAuthenticator_StartAuthentication, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomAuthenticator_ContinueAuthentication, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, State, TElDCAsyncState, 1)
	ZEND_ARG_OBJ_INFO(1, NextState, TElDCAsyncState, 0)
	ZEND_ARG_OBJ_INFO(1, AuthToken, TElDCAuthToken, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomAuthenticator_get_LastAuthResult, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomAuthenticator___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCustomAuthenticator_methods[] = {
	PHP_ME(TElCustomAuthenticator, StartAuthentication, arginfo_TElCustomAuthenticator_StartAuthentication, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomAuthenticator, ContinueAuthentication, arginfo_TElCustomAuthenticator_ContinueAuthentication, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomAuthenticator, get_LastAuthResult, arginfo_TElCustomAuthenticator_get_LastAuthResult, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomAuthenticator, __construct, arginfo_TElCustomAuthenticator___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCustomAuthenticator(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCustomAuthenticator_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCustomAuthenticator", TElCustomAuthenticator_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElCustomAuthenticator_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElBasicDCAuthToken_ce_ptr = NULL;

SB_PHP_METHOD(TElBasicDCAuthToken, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElBasicDCAuthToken_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBasicDCAuthToken, Validate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBAuthResultRaw fOutResultRaw = 0;
		SBCheckError(TElBasicDCAuthToken_Validate(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBasicDCAuthToken, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElBasicDCAuthToken_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBasicDCAuthToken_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBasicDCAuthToken_Validate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBasicDCAuthToken___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElBasicDCAuthToken_methods[] = {
	PHP_ME(TElBasicDCAuthToken, Clear, arginfo_TElBasicDCAuthToken_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElBasicDCAuthToken, Validate, arginfo_TElBasicDCAuthToken_Validate, ZEND_ACC_PUBLIC)
	PHP_ME(TElBasicDCAuthToken, __construct, arginfo_TElBasicDCAuthToken___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElBasicDCAuthToken(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElBasicDCAuthToken_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElBasicDCAuthToken", TElBasicDCAuthToken_methods);
	if (NULL == TElDCAuthToken_ce_ptr)
		Register_TElDCAuthToken(TSRMLS_C);
	TElBasicDCAuthToken_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElDCAuthToken_ce_ptr);
}

zend_class_entry *TElBasicDCAuthenticator_ce_ptr = NULL;

SB_PHP_METHOD(TElBasicDCAuthenticator, get_HashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElBasicDCAuthenticator_get_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBasicDCAuthenticator, set_HashAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElBasicDCAuthenticator_set_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBasicDCAuthenticator, get_CertStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElBasicDCAuthenticator_get_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBasicDCAuthenticator, set_CertStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElBasicDCAuthenticator_set_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBasicDCAuthenticator, get_SigningCertIndex)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElBasicDCAuthenticator_get_SigningCertIndex(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBasicDCAuthenticator, set_SigningCertIndex)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElBasicDCAuthenticator_set_SigningCertIndex(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBasicDCAuthenticator, get_OnAuthStart)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDCAuthStartEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElBasicDCAuthenticator_get_OnAuthStart(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBasicDCAuthenticator, set_OnAuthStart)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElBasicDCAuthenticator_set_OnAuthStart(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDCAuthStartEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDCAuthStartEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBasicDCAuthenticator, get_OnSigningCertNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDCAuthSigningCertNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElBasicDCAuthenticator_get_OnSigningCertNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBasicDCAuthenticator, set_OnSigningCertNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElBasicDCAuthenticator_set_OnSigningCertNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDCAuthSigningCertNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDCAuthSigningCertNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElBasicDCAuthenticator, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElBasicDCAuthenticator_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBasicDCAuthenticator_get_HashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBasicDCAuthenticator_set_HashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBasicDCAuthenticator_get_CertStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBasicDCAuthenticator_set_CertStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBasicDCAuthenticator_get_SigningCertIndex, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBasicDCAuthenticator_set_SigningCertIndex, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBasicDCAuthenticator_get_OnAuthStart, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBasicDCAuthenticator_set_OnAuthStart, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBasicDCAuthenticator_get_OnSigningCertNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBasicDCAuthenticator_set_OnSigningCertNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElBasicDCAuthenticator___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElBasicDCAuthenticator_methods[] = {
	PHP_ME(TElBasicDCAuthenticator, get_HashAlgorithm, arginfo_TElBasicDCAuthenticator_get_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElBasicDCAuthenticator, set_HashAlgorithm, arginfo_TElBasicDCAuthenticator_set_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElBasicDCAuthenticator, get_CertStorage, arginfo_TElBasicDCAuthenticator_get_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElBasicDCAuthenticator, set_CertStorage, arginfo_TElBasicDCAuthenticator_set_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElBasicDCAuthenticator, get_SigningCertIndex, arginfo_TElBasicDCAuthenticator_get_SigningCertIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElBasicDCAuthenticator, set_SigningCertIndex, arginfo_TElBasicDCAuthenticator_set_SigningCertIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElBasicDCAuthenticator, get_OnAuthStart, arginfo_TElBasicDCAuthenticator_get_OnAuthStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElBasicDCAuthenticator, set_OnAuthStart, arginfo_TElBasicDCAuthenticator_set_OnAuthStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElBasicDCAuthenticator, get_OnSigningCertNeeded, arginfo_TElBasicDCAuthenticator_get_OnSigningCertNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElBasicDCAuthenticator, set_OnSigningCertNeeded, arginfo_TElBasicDCAuthenticator_set_OnSigningCertNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElBasicDCAuthenticator, __construct, arginfo_TElBasicDCAuthenticator___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElBasicDCAuthenticator(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElBasicDCAuthenticator_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElBasicDCAuthenticator", TElBasicDCAuthenticator_methods);
	if (NULL == TElCustomAuthenticator_ce_ptr)
		Register_TElCustomAuthenticator(TSRMLS_C);
	TElBasicDCAuthenticator_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomAuthenticator_ce_ptr);
}

void Register_SBDCAuth_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBDCAuth, SB_AUTH_ERROR, SB_AUTH_ERROR, SB_AUTH_ERROR);
	SB_REGISTER_LONG_CONSTANT(SBDCAuth, SB_AUTH_ERROR_UNSUPPORTED_OPERATION, SB_AUTH_ERROR_UNSUPPORTED_OPERATION, SB_AUTH_ERROR_UNSUPPORTED_OPERATION);
	SB_REGISTER_LONG_CONSTANT(SBDCAuth, SB_AUTH_ERROR_TOKEN_READONLY, SB_AUTH_ERROR_TOKEN_READONLY, SB_AUTH_ERROR_TOKEN_READONLY);
	SB_REGISTER_LONG_CONSTANT(SBDCAuth, SB_AUTH_ERROR_OBJECT_NOT_INITIALIZED, SB_AUTH_ERROR_OBJECT_NOT_INITIALIZED, SB_AUTH_ERROR_OBJECT_NOT_INITIALIZED);
	SB_REGISTER_LONG_CONSTANT(SBDCAuth, SB_AUTH_ERROR_BAD_ASYNC_STATE, SB_AUTH_ERROR_BAD_ASYNC_STATE, SB_AUTH_ERROR_BAD_ASYNC_STATE);
	SB_REGISTER_LONG_CONSTANT(SBDCAuth, SB_AUTH_ERROR_CANCELLED_BY_USER, SB_AUTH_ERROR_CANCELLED_BY_USER, SB_AUTH_ERROR_CANCELLED_BY_USER);
	SB_REGISTER_LONG_CONSTANT(SBDCAuth, SB_AUTH_ERROR_INVALID_AUTH_TOKEN, SB_AUTH_ERROR_INVALID_AUTH_TOKEN, SB_AUTH_ERROR_INVALID_AUTH_TOKEN);
	SB_REGISTER_LONG_CONSTANT(SBDCAuth, SB_DC_AUTH_NONCE_LENGTH, SB_DC_AUTH_NONCE_LENGTH, SB_DC_AUTH_NONCE_LENGTH);
}

void Register_SBDCAuth_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBAuthResult", NULL);
	TSBAuthResult_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBAuthResult_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBAuthResult_ce_ptr, "arSuccess", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBAuthResult_ce_ptr, "arFailure", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBAuthResult_ce_ptr, "arFurtherAuthNeeded", 2)
}

