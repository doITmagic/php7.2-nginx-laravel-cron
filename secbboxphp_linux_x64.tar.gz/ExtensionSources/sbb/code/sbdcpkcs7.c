#include "sbdcpkcs7.h"

void SB_CALLBACK TSBDCPKCS7SignerPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElMessageSignerHandle Signer)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zSigner;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSigner, 1);
	SBInitObject(zSigner, TElMessageSigner_ce_ptr, Signer TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSigner);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBDCPKCS7TSPClientNeededEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pTSPServiceID[], int32_t szTSPServiceID, TElCustomTSPClientHandle * TSPClient, int8_t * Success)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zTSPServiceID;
	zval * zTSPClient;
	zval * zSuccess;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTSPServiceID, 1);
	SB_ZVAL_STRINGL_DUP(zTSPServiceID, pTSPServiceID, szTSPServiceID);
	SB_EVENT_INIT_ZVAL_REF(zTSPClient, 2);
	SBInitObject(zTSPClient, TElCustomTSPClient_ce_ptr, *TSPClient TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zSuccess, 3);
	ZVAL_BOOL(Z_REFVAL_P(zSuccess), (zend_bool)*Success);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zTSPServiceID);
	*TSPClient = SBGetObjectHandleCE(zTSPClient, TElCustomTSPClient_ce_ptr TSRMLS_CC);
	SBDetachObjectHandleIfUniqueZVal(zTSPClient TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zTSPClient);
	convert_to_boolean(Z_REFVAL_P(zSuccess));
	*Success = (int8_t)SB_BVAL_P(Z_REFVAL_P(zSuccess));
	SB_EVENT_CLEAR_ZVAL(zSuccess);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElDCPKCS7SignOperationHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElDCPKCS7SignOperationHandler, get_CertStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCPKCS7SignOperationHandler_get_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCPKCS7SignOperationHandler, set_CertStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDCPKCS7SignOperationHandler_set_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCPKCS7SignOperationHandler, get_OnTSPClientNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDCPKCS7TSPClientNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDCPKCS7SignOperationHandler_get_OnTSPClientNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCPKCS7SignOperationHandler, set_OnTSPClientNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDCPKCS7SignOperationHandler_set_OnTSPClientNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDCPKCS7TSPClientNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDCPKCS7TSPClientNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCPKCS7SignOperationHandler, get_OnSignerPrepared)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDCPKCS7SignerPreparedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDCPKCS7SignOperationHandler_get_OnSignerPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCPKCS7SignOperationHandler, set_OnSignerPrepared)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDCPKCS7SignOperationHandler_set_OnSignerPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDCPKCS7SignerPreparedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDCPKCS7SignerPreparedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCPKCS7SignOperationHandler, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCPKCS7SignOperationHandler_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCPKCS7SignOperationHandler_get_CertStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCPKCS7SignOperationHandler_set_CertStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCPKCS7SignOperationHandler_get_OnTSPClientNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCPKCS7SignOperationHandler_set_OnTSPClientNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCPKCS7SignOperationHandler_get_OnSignerPrepared, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCPKCS7SignOperationHandler_set_OnSignerPrepared, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCPKCS7SignOperationHandler___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDCPKCS7SignOperationHandler_methods[] = {
	PHP_ME(TElDCPKCS7SignOperationHandler, get_CertStorage, arginfo_TElDCPKCS7SignOperationHandler_get_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCPKCS7SignOperationHandler, set_CertStorage, arginfo_TElDCPKCS7SignOperationHandler_set_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCPKCS7SignOperationHandler, get_OnTSPClientNeeded, arginfo_TElDCPKCS7SignOperationHandler_get_OnTSPClientNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCPKCS7SignOperationHandler, set_OnTSPClientNeeded, arginfo_TElDCPKCS7SignOperationHandler_set_OnTSPClientNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCPKCS7SignOperationHandler, get_OnSignerPrepared, arginfo_TElDCPKCS7SignOperationHandler_get_OnSignerPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCPKCS7SignOperationHandler, set_OnSignerPrepared, arginfo_TElDCPKCS7SignOperationHandler_set_OnSignerPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCPKCS7SignOperationHandler, __construct, arginfo_TElDCPKCS7SignOperationHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDCPKCS7SignOperationHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDCPKCS7SignOperationHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDCPKCS7SignOperationHandler", TElDCPKCS7SignOperationHandler_methods);
	if (NULL == TElDCSignOperationHandler_ce_ptr)
		Register_TElDCSignOperationHandler(TSRMLS_C);
	TElDCPKCS7SignOperationHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElDCSignOperationHandler_ce_ptr);
}

