#include "sbdcpki.h"

zend_class_entry *TElDCX509SignOperationHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElDCX509SignOperationHandler, get_CertStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCX509SignOperationHandler_get_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCX509SignOperationHandler, set_CertStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDCX509SignOperationHandler_set_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCX509SignOperationHandler, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCX509SignOperationHandler_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCX509SignOperationHandler_get_CertStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCX509SignOperationHandler_set_CertStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCX509SignOperationHandler___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDCX509SignOperationHandler_methods[] = {
	PHP_ME(TElDCX509SignOperationHandler, get_CertStorage, arginfo_TElDCX509SignOperationHandler_get_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCX509SignOperationHandler, set_CertStorage, arginfo_TElDCX509SignOperationHandler_set_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCX509SignOperationHandler, __construct, arginfo_TElDCX509SignOperationHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDCX509SignOperationHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDCX509SignOperationHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDCX509SignOperationHandler", TElDCX509SignOperationHandler_methods);
	if (NULL == TElDCSignOperationHandler_ce_ptr)
		Register_TElDCSignOperationHandler(TSRMLS_C);
	TElDCX509SignOperationHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElDCSignOperationHandler_ce_ptr);
}

