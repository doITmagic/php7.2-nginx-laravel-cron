#include "sbdcserver.h"

void SB_CALLBACK TSBDCSignRequestEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pData[], int32_t szData, const uint8_t pHashAlg[], int32_t szHashAlg, TSBDCRequestedCertificatesOptionRaw RequestedCertificates, TElRelativeDistinguishedNameHandle SigningCertInfo, TElRelativeDistinguishedNameHandle InputPars, TElRelativeDistinguishedNameHandle Keys, TElRelativeDistinguishedNameHandle OutputPars, uint8_t pSignResult[], int32_t * szSignResult)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(9);
	zval * zSender;
	zval * zData;
	zval * zHashAlg;
	zval * zRequestedCertificates;
	zval * zSigningCertInfo;
	zval * zInputPars;
	zval * zKeys;
	zval * zOutputPars;
	zval * zSignResult;
	SBArrayZValInfo aiSignResult;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SB_ZVAL_STRINGL_DUP(zData, pData, szData);
	SB_EVENT_INIT_ZVAL(zHashAlg, 2);
	SB_ZVAL_STRINGL_DUP(zHashAlg, pHashAlg, szHashAlg);
	SB_EVENT_INIT_ZVAL(zRequestedCertificates, 3);
	ZVAL_LONG(zRequestedCertificates, (sb_zend_long)RequestedCertificates);
	SB_EVENT_INIT_ZVAL(zSigningCertInfo, 4);
	SBInitObject(zSigningCertInfo, TElRelativeDistinguishedName_ce_ptr, SigningCertInfo TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zInputPars, 5);
	SBInitObject(zInputPars, TElRelativeDistinguishedName_ce_ptr, InputPars TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zKeys, 6);
	SBInitObject(zKeys, TElRelativeDistinguishedName_ce_ptr, Keys TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOutputPars, 7);
	SBInitObject(zOutputPars, TElRelativeDistinguishedName_ce_ptr, OutputPars TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zSignResult, 8);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zSignResult), pSignResult, *szSignResult);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 9, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zHashAlg);
	SB_EVENT_CLEAR_ZVAL(zRequestedCertificates);
	SB_EVENT_CLEAR_ZVAL(zSigningCertInfo);
	SB_EVENT_CLEAR_ZVAL(zInputPars);
	SB_EVENT_CLEAR_ZVAL(zKeys);
	SB_EVENT_CLEAR_ZVAL(zOutputPars);
	if (SBGetByteArrayFromZVal(zSignResult, &aiSignResult TSRMLS_CC))
		SBCheckError(SBSetEventReturnBuffer(9, aiSignResult.data, aiSignResult.len) TSRMLS_CC);
	SBFreeArrayZValInfo(&aiSignResult);
	SB_EVENT_CLEAR_ZVAL(zSignResult);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBDCServerCertificateNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TObjectHandle CertID, TElX509CertificateHandle * Certificate, int8_t * FreeOnFinish)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zCertID;
	zval * zCertificate;
	zval * zFreeOnFinish;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCertID, 1);
	SBInitObject(zCertID, TObject_ce_ptr, CertID TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zCertificate, 2);
	SBInitObject(zCertificate, TElX509Certificate_ce_ptr, *Certificate TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zFreeOnFinish, 3);
	ZVAL_BOOL(Z_REFVAL_P(zFreeOnFinish), (zend_bool)*FreeOnFinish);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zCertID);
	*Certificate = SBGetObjectHandleCE(zCertificate, TElX509Certificate_ce_ptr TSRMLS_CC);
	SBDetachObjectHandleIfUniqueZVal(zCertificate TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zCertificate);
	convert_to_boolean(Z_REFVAL_P(zFreeOnFinish));
	*FreeOnFinish = (int8_t)SB_BVAL_P(Z_REFVAL_P(zFreeOnFinish));
	SB_EVENT_CLEAR_ZVAL(zFreeOnFinish);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBDCServerCertificateValidateEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle Certificate, TElMemoryCertStorageHandle OtherCertificates, int8_t * Valid)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zCertificate;
	zval * zOtherCertificates;
	zval * zValid;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCertificate, 1);
	SBInitObject(zCertificate, TElX509Certificate_ce_ptr, Certificate TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOtherCertificates, 2);
	SBInitObject(zOtherCertificates, TElMemoryCertStorage_ce_ptr, OtherCertificates TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zValid, 3);
	ZVAL_BOOL(Z_REFVAL_P(zValid), (zend_bool)*Valid);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zCertificate);
	SB_EVENT_CLEAR_ZVAL(zOtherCertificates);
	convert_to_boolean(Z_REFVAL_P(zValid));
	*Valid = (int8_t)SB_BVAL_P(Z_REFVAL_P(zValid));
	SB_EVENT_CLEAR_ZVAL(zValid);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBDCServerSignatureFoundEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcSigType, int32_t szSigType, TElStringListHandle Params, int8_t * Accept)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zSigType;
	zval * zParams;
	zval * zAccept;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSigType, 1);
	SB_ZVAL_STRINGL_DUP(zSigType, pcSigType, szSigType);
	SB_EVENT_INIT_ZVAL(zParams, 2);
	SBInitObject(zParams, TElStringList_ce_ptr, Params TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 3);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSigType);
	SB_EVENT_CLEAR_ZVAL(zParams);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBDCServerSignatureHandlerNeededEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcSigType, int32_t szSigType, TElStringListHandle Params, TElDCServerRequestSignatureHandlerHandle * Handler)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zSigType;
	zval * zParams;
	zval * zHandler;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSigType, 1);
	SB_ZVAL_STRINGL_DUP(zSigType, pcSigType, szSigType);
	SB_EVENT_INIT_ZVAL(zParams, 2);
	SBInitObject(zParams, TElStringList_ce_ptr, Params TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zHandler, 3);
	SBInitObject(zHandler, TElDCServerRequestSignatureHandler_ce_ptr, *Handler TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSigType);
	SB_EVENT_CLEAR_ZVAL(zParams);
	*Handler = SBGetObjectHandleCE(zHandler, TElDCServerRequestSignatureHandler_ce_ptr TSRMLS_CC);
	SBDetachObjectHandleIfUniqueZVal(zHandler TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zHandler);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBDCServerParametersReceivedEventRaw(void * _ObjectData, TObjectHandle Sender, TElRelativeDistinguishedNameHandle Params)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zParams;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zParams, 1);
	SBInitObject(zParams, TElRelativeDistinguishedName_ce_ptr, Params TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zParams);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElDCStandardServer_ce_ptr = NULL;

SB_PHP_METHOD(TElDCStandardServer, Process)
{
	zval *oInEncoding;
	zval *oInStream;
	zval *oOutEncoding;
	zval *oOutStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!O!", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &oInEncoding, TElDCEncoding_ce_ptr, &oOutEncoding, TElDCEncoding_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDCStandardServer_Process(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), SBGetObjectHandle(oInEncoding TSRMLS_CC), SBGetObjectHandle(oOutEncoding TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDCStandardServer_Process_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, \\TStream, \\TElDCEncoding, \\TElDCEncoding) or (\\TStream, \\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, BeginProcess)
{
	zval *oInEncoding;
	zval *oInStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oInStream, TStream_ce_ptr, &oInEncoding, TElDCEncoding_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCStandardServer_BeginProcess(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oInEncoding TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCServerRequest_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oInStream, TStream_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCStandardServer_BeginProcess_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCServerRequest_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, \\TElDCEncoding) or (\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, EndProcess)
{
	zval *oOutEncoding;
	zval *oOutStream;
	zval *oRequest;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oRequest, TElDCServerRequest_ce_ptr, &oOutStream, TStream_ce_ptr, &oOutEncoding, TElDCEncoding_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDCStandardServer_EndProcess(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oRequest TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), SBGetObjectHandle(oOutEncoding TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oRequest, TElDCServerRequest_ce_ptr, &oOutStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElDCStandardServer_EndProcess_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oRequest TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDCServerRequest, \\TStream, \\TElDCEncoding) or (\\TElDCServerRequest, \\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, AddOperationHandler)
{
	zval *oHandler;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oHandler, TElDCOperationHandler_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDCStandardServer_AddOperationHandler(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oHandler TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDCOperationHandler)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, RemoveOperationHandler)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElDCStandardServer_RemoveOperationHandler(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, ClearOperationHandlers)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDCStandardServer_ClearOperationHandlers(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, AddRequestSignatureHandler)
{
	zval *oHandler;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oHandler, TElDCServerRequestSignatureHandler_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDCStandardServer_AddRequestSignatureHandler(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oHandler TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDCServerRequestSignatureHandler)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, RemoveRequestSignatureHandler)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElDCStandardServer_RemoveRequestSignatureHandler(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, ClearRequestSignatureHandlers)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDCStandardServer_ClearRequestSignatureHandlers(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, get_OperationHandlers)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCStandardServer_get_OperationHandlers(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCOperationHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, get_OperationHandlerCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDCStandardServer_get_OperationHandlerCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, get_RequestSignatureHandlers)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCStandardServer_get_RequestSignatureHandlers(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCServerRequestSignatureHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, get_RequestSignatureHandlerCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDCStandardServer_get_RequestSignatureHandlerCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, get_SecurityParameters)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCStandardServer_get_SecurityParameters(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCServerSecurityParameters_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, get_OnSignatureFound)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDCServerSignatureFoundEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDCStandardServer_get_OnSignatureFound(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, set_OnSignatureFound)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDCStandardServer_set_OnSignatureFound(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDCServerSignatureFoundEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDCServerSignatureFoundEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, get_OnSignatureHandlerNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDCServerSignatureHandlerNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDCStandardServer_get_OnSignatureHandlerNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, set_OnSignatureHandlerNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDCStandardServer_set_OnSignatureHandlerNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDCServerSignatureHandlerNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDCServerSignatureHandlerNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, get_OnParametersReceived)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDCServerParametersReceivedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDCStandardServer_get_OnParametersReceived(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, set_OnParametersReceived)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDCStandardServer_set_OnParametersReceived(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDCServerParametersReceivedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDCServerParametersReceivedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCStandardServer, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCStandardServer_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_Process, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, InStream, TStream, 1)
	ZEND_ARG_OBJ_INFO(0, OutStream, TStream, 1)
	ZEND_ARG_OBJ_INFO(0, InEncoding, TElDCEncoding, 1)
	ZEND_ARG_OBJ_INFO(0, OutEncoding, TElDCEncoding, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_BeginProcess, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, InStream, TStream, 1)
	ZEND_ARG_OBJ_INFO(0, InEncoding, TElDCEncoding, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_EndProcess, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Request, TElDCServerRequest, 1)
	ZEND_ARG_OBJ_INFO(0, OutStream, TStream, 1)
	ZEND_ARG_OBJ_INFO(0, OutEncoding, TElDCEncoding, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_AddOperationHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElDCOperationHandler, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_RemoveOperationHandler, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_ClearOperationHandlers, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_AddRequestSignatureHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElDCServerRequestSignatureHandler, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_RemoveRequestSignatureHandler, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_ClearRequestSignatureHandlers, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_get_OperationHandlers, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_get_OperationHandlerCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_get_RequestSignatureHandlers, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_get_RequestSignatureHandlerCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_get_SecurityParameters, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_get_OnSignatureFound, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_set_OnSignatureFound, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_get_OnSignatureHandlerNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_set_OnSignatureHandlerNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_get_OnParametersReceived, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer_set_OnParametersReceived, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCStandardServer___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDCStandardServer_methods[] = {
	PHP_ME(TElDCStandardServer, Process, arginfo_TElDCStandardServer_Process, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, BeginProcess, arginfo_TElDCStandardServer_BeginProcess, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, EndProcess, arginfo_TElDCStandardServer_EndProcess, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, AddOperationHandler, arginfo_TElDCStandardServer_AddOperationHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, RemoveOperationHandler, arginfo_TElDCStandardServer_RemoveOperationHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, ClearOperationHandlers, arginfo_TElDCStandardServer_ClearOperationHandlers, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, AddRequestSignatureHandler, arginfo_TElDCStandardServer_AddRequestSignatureHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, RemoveRequestSignatureHandler, arginfo_TElDCStandardServer_RemoveRequestSignatureHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, ClearRequestSignatureHandlers, arginfo_TElDCStandardServer_ClearRequestSignatureHandlers, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, get_OperationHandlers, arginfo_TElDCStandardServer_get_OperationHandlers, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, get_OperationHandlerCount, arginfo_TElDCStandardServer_get_OperationHandlerCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, get_RequestSignatureHandlers, arginfo_TElDCStandardServer_get_RequestSignatureHandlers, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, get_RequestSignatureHandlerCount, arginfo_TElDCStandardServer_get_RequestSignatureHandlerCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, get_SecurityParameters, arginfo_TElDCStandardServer_get_SecurityParameters, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, get_OnSignatureFound, arginfo_TElDCStandardServer_get_OnSignatureFound, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, set_OnSignatureFound, arginfo_TElDCStandardServer_set_OnSignatureFound, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, get_OnSignatureHandlerNeeded, arginfo_TElDCStandardServer_get_OnSignatureHandlerNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, set_OnSignatureHandlerNeeded, arginfo_TElDCStandardServer_set_OnSignatureHandlerNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, get_OnParametersReceived, arginfo_TElDCStandardServer_get_OnParametersReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, set_OnParametersReceived, arginfo_TElDCStandardServer_set_OnParametersReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCStandardServer, __construct, arginfo_TElDCStandardServer___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDCStandardServer(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDCStandardServer_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDCStandardServer", TElDCStandardServer_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElDCStandardServer_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElDCOperationHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElDCOperationHandler, get_AcceptedOperationIDs)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCOperationHandler_get_AcceptedOperationIDs(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCOperationHandler, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCOperationHandler_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCOperationHandler_get_AcceptedOperationIDs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCOperationHandler___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDCOperationHandler_methods[] = {
	PHP_ME(TElDCOperationHandler, get_AcceptedOperationIDs, arginfo_TElDCOperationHandler_get_AcceptedOperationIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCOperationHandler, __construct, arginfo_TElDCOperationHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDCOperationHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDCOperationHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDCOperationHandler", TElDCOperationHandler_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElDCOperationHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElDCSignOperationHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElDCSignOperationHandler, get_OnSignRequest)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDCSignRequestEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDCSignOperationHandler_get_OnSignRequest(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCSignOperationHandler, set_OnSignRequest)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDCSignOperationHandler_set_OnSignRequest(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDCSignRequestEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDCSignRequestEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCSignOperationHandler, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCSignOperationHandler_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCSignOperationHandler_get_OnSignRequest, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCSignOperationHandler_set_OnSignRequest, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCSignOperationHandler___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDCSignOperationHandler_methods[] = {
	PHP_ME(TElDCSignOperationHandler, get_OnSignRequest, arginfo_TElDCSignOperationHandler_get_OnSignRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCSignOperationHandler, set_OnSignRequest, arginfo_TElDCSignOperationHandler_set_OnSignRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCSignOperationHandler, __construct, arginfo_TElDCSignOperationHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDCSignOperationHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDCSignOperationHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDCSignOperationHandler", TElDCSignOperationHandler_methods);
	if (NULL == TElDCOperationHandler_ce_ptr)
		Register_TElDCOperationHandler(TSRMLS_C);
	TElDCSignOperationHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElDCOperationHandler_ce_ptr);
}

zend_class_entry *TElDCSingleServerRequest_ce_ptr = NULL;

SB_PHP_METHOD(TElDCSingleServerRequest, get_Parameters)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCSingleServerRequest_get_Parameters(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElRelativeDistinguishedName_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCSingleServerRequest, get_RequestedCertificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDCRequestedCertificatesOptionRaw fOutResultRaw = 0;
		SBCheckError(TElDCSingleServerRequest_get_RequestedCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCSingleServerRequest, get_SigningCertInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCSingleServerRequest_get_SigningCertInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElRelativeDistinguishedName_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCSingleServerRequest, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TElDCStandardServer_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCSingleServerRequest_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDCStandardServer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCSingleServerRequest_get_Parameters, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCSingleServerRequest_get_RequestedCertificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCSingleServerRequest_get_SigningCertInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCSingleServerRequest___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TElDCStandardServer, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElDCSingleServerRequest_methods[] = {
	PHP_ME(TElDCSingleServerRequest, get_Parameters, arginfo_TElDCSingleServerRequest_get_Parameters, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCSingleServerRequest, get_RequestedCertificates, arginfo_TElDCSingleServerRequest_get_RequestedCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCSingleServerRequest, get_SigningCertInfo, arginfo_TElDCSingleServerRequest_get_SigningCertInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCSingleServerRequest, __construct, arginfo_TElDCSingleServerRequest___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDCSingleServerRequest(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDCSingleServerRequest_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDCSingleServerRequest", TElDCSingleServerRequest_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElDCSingleServerRequest_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElDCServerRequest_ce_ptr = NULL;

SB_PHP_METHOD(TElDCServerRequest, BeginProcess)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDCServerRequest_BeginProcess(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerRequest, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElDCServerRequest_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerRequest, get_Requests)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCServerRequest_get_Requests(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCSingleServerRequest_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerRequest, get_RequestCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDCServerRequest_get_RequestCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerRequest, get_Parameters)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCServerRequest_get_Parameters(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElRelativeDistinguishedName_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerRequest, get_SigningCertInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCServerRequest_get_SigningCertInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElRelativeDistinguishedName_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerRequest, get_RequestedCertificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDCRequestedCertificatesOptionRaw fOutResultRaw = 0;
		SBCheckError(TElDCServerRequest_get_RequestedCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerRequest, __construct)
{
	zval *oOwner;
	zval *oReqRoot;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oOwner, TElDCStandardServer_ce_ptr, &oReqRoot, TElDCNode_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCServerRequest_Create(SBGetObjectHandle(oOwner TSRMLS_CC), SBGetObjectHandle(oReqRoot TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDCStandardServer, \\TElDCNode)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerRequest_BeginProcess, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerRequest_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerRequest_get_Requests, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerRequest_get_RequestCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerRequest_get_Parameters, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerRequest_get_SigningCertInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerRequest_get_RequestedCertificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerRequest___construct, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Owner, TElDCStandardServer, 1)
	ZEND_ARG_OBJ_INFO(0, ReqRoot, TElDCNode, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElDCServerRequest_methods[] = {
	PHP_ME(TElDCServerRequest, BeginProcess, arginfo_TElDCServerRequest_BeginProcess, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerRequest, Clear, arginfo_TElDCServerRequest_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerRequest, get_Requests, arginfo_TElDCServerRequest_get_Requests, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerRequest, get_RequestCount, arginfo_TElDCServerRequest_get_RequestCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerRequest, get_Parameters, arginfo_TElDCServerRequest_get_Parameters, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerRequest, get_SigningCertInfo, arginfo_TElDCServerRequest_get_SigningCertInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerRequest, get_RequestedCertificates, arginfo_TElDCServerRequest_get_RequestedCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerRequest, __construct, arginfo_TElDCServerRequest___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDCServerRequest(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDCServerRequest_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDCServerRequest", TElDCServerRequest_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElDCServerRequest_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElDCServerSecurityParameters_ce_ptr = NULL;

SB_PHP_METHOD(TElDCServerSecurityParameters, get_RequireSignature)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDCServerSecurityParameters_get_RequireSignature(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerSecurityParameters, set_RequireSignature)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElDCServerSecurityParameters_set_RequireSignature(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerSecurityParameters, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCServerSecurityParameters_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerSecurityParameters_get_RequireSignature, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerSecurityParameters_set_RequireSignature, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerSecurityParameters___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDCServerSecurityParameters_methods[] = {
	PHP_ME(TElDCServerSecurityParameters, get_RequireSignature, arginfo_TElDCServerSecurityParameters_get_RequireSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerSecurityParameters, set_RequireSignature, arginfo_TElDCServerSecurityParameters_set_RequireSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerSecurityParameters, __construct, arginfo_TElDCServerSecurityParameters___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDCServerSecurityParameters(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDCServerSecurityParameters_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDCServerSecurityParameters", TElDCServerSecurityParameters_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElDCServerSecurityParameters_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElDCServerRequestSignatureHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElDCServerRequestSignatureHandler, ValidateSignature)
{
	sb_zend_long l4HashAlgorithm;
	SBArrayZValInfo aiHash;
	SBArrayZValInfo aiSignature;
	zval *oSigParams;
	zval *zaHash;
	zval *zaSignature;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzlO!", &zaSignature, &zaHash, &l4HashAlgorithm, &oSigParams, TElStringList_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSignature) || SB_IS_ARRAY_TYPE_RP(zaSignature) || SB_IS_NULL_TYPE_RP(zaSignature)) && (SB_IS_STRING_TYPE_RP(zaHash) || SB_IS_ARRAY_TYPE_RP(zaHash) || SB_IS_NULL_TYPE_RP(zaHash)))
	{
		if (!SBGetByteArrayFromZVal(zaSignature, &aiSignature TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaHash, &aiHash TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDCServerRequestSignatureHandler_ValidateSignature(SBGetObjectHandle(getThis() TSRMLS_CC), aiSignature.data, aiSignature.len, aiHash.data, aiHash.len, (int32_t)l4HashAlgorithm, SBGetObjectHandle(oSigParams TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiSignature);
		SBFreeArrayZValInfo(&aiHash);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, array of byte|string|NULL, integer, \\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerRequestSignatureHandler, GetName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElDCServerRequestSignatureHandler_GetName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1636614602, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerRequestSignatureHandler, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCServerRequestSignatureHandler_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerRequestSignatureHandler_ValidateSignature, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Signature, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Hash, 0, 1)
	ZEND_ARG_INFO(0, HashAlgorithm)
	ZEND_ARG_OBJ_INFO(0, SigParams, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerRequestSignatureHandler_GetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerRequestSignatureHandler___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDCServerRequestSignatureHandler_methods[] = {
	PHP_ME(TElDCServerRequestSignatureHandler, ValidateSignature, arginfo_TElDCServerRequestSignatureHandler_ValidateSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerRequestSignatureHandler, GetName, arginfo_TElDCServerRequestSignatureHandler_GetName, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerRequestSignatureHandler, __construct, arginfo_TElDCServerRequestSignatureHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDCServerRequestSignatureHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDCServerRequestSignatureHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDCServerRequestSignatureHandler", TElDCServerRequestSignatureHandler_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElDCServerRequestSignatureHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElDCServerPKCS1RequestSignatureHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElDCServerPKCS1RequestSignatureHandler, ValidateSignature)
{
	sb_zend_long l4HashAlgorithm;
	SBArrayZValInfo aiHash;
	SBArrayZValInfo aiSignature;
	zval *oSigParams;
	zval *zaHash;
	zval *zaSignature;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzlO!", &zaSignature, &zaHash, &l4HashAlgorithm, &oSigParams, TElStringList_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSignature) || SB_IS_ARRAY_TYPE_RP(zaSignature) || SB_IS_NULL_TYPE_RP(zaSignature)) && (SB_IS_STRING_TYPE_RP(zaHash) || SB_IS_ARRAY_TYPE_RP(zaHash) || SB_IS_NULL_TYPE_RP(zaHash)))
	{
		if (!SBGetByteArrayFromZVal(zaSignature, &aiSignature TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaHash, &aiHash TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDCServerPKCS1RequestSignatureHandler_ValidateSignature(SBGetObjectHandle(getThis() TSRMLS_CC), aiSignature.data, aiSignature.len, aiHash.data, aiHash.len, (int32_t)l4HashAlgorithm, SBGetObjectHandle(oSigParams TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiSignature);
		SBFreeArrayZValInfo(&aiHash);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, array of byte|string|NULL, integer, \\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerPKCS1RequestSignatureHandler, GetName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElDCServerPKCS1RequestSignatureHandler_GetName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1189976601, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerPKCS1RequestSignatureHandler, get_OnCertificateValidate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDCServerCertificateValidateEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDCServerPKCS1RequestSignatureHandler_get_OnCertificateValidate(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerPKCS1RequestSignatureHandler, set_OnCertificateValidate)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDCServerPKCS1RequestSignatureHandler_set_OnCertificateValidate(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDCServerCertificateValidateEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDCServerCertificateValidateEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerPKCS1RequestSignatureHandler, get_OnCertificateNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDCServerCertificateNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDCServerPKCS1RequestSignatureHandler_get_OnCertificateNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerPKCS1RequestSignatureHandler, set_OnCertificateNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDCServerPKCS1RequestSignatureHandler_set_OnCertificateNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDCServerCertificateNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDCServerCertificateNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDCServerPKCS1RequestSignatureHandler, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDCServerPKCS1RequestSignatureHandler_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerPKCS1RequestSignatureHandler_ValidateSignature, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Signature, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Hash, 0, 1)
	ZEND_ARG_INFO(0, HashAlgorithm)
	ZEND_ARG_OBJ_INFO(0, SigParams, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerPKCS1RequestSignatureHandler_GetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerPKCS1RequestSignatureHandler_get_OnCertificateValidate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerPKCS1RequestSignatureHandler_set_OnCertificateValidate, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerPKCS1RequestSignatureHandler_get_OnCertificateNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerPKCS1RequestSignatureHandler_set_OnCertificateNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDCServerPKCS1RequestSignatureHandler___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDCServerPKCS1RequestSignatureHandler_methods[] = {
	PHP_ME(TElDCServerPKCS1RequestSignatureHandler, ValidateSignature, arginfo_TElDCServerPKCS1RequestSignatureHandler_ValidateSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerPKCS1RequestSignatureHandler, GetName, arginfo_TElDCServerPKCS1RequestSignatureHandler_GetName, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerPKCS1RequestSignatureHandler, get_OnCertificateValidate, arginfo_TElDCServerPKCS1RequestSignatureHandler_get_OnCertificateValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerPKCS1RequestSignatureHandler, set_OnCertificateValidate, arginfo_TElDCServerPKCS1RequestSignatureHandler_set_OnCertificateValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerPKCS1RequestSignatureHandler, get_OnCertificateNeeded, arginfo_TElDCServerPKCS1RequestSignatureHandler_get_OnCertificateNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerPKCS1RequestSignatureHandler, set_OnCertificateNeeded, arginfo_TElDCServerPKCS1RequestSignatureHandler_set_OnCertificateNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElDCServerPKCS1RequestSignatureHandler, __construct, arginfo_TElDCServerPKCS1RequestSignatureHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDCServerPKCS1RequestSignatureHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDCServerPKCS1RequestSignatureHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDCServerPKCS1RequestSignatureHandler", TElDCServerPKCS1RequestSignatureHandler_methods);
	if (NULL == TElDCServerRequestSignatureHandler_ce_ptr)
		Register_TElDCServerRequestSignatureHandler(TSRMLS_C);
	TElDCServerPKCS1RequestSignatureHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElDCServerRequestSignatureHandler_ce_ptr);
}

