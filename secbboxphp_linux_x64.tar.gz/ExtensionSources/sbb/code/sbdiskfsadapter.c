#include "sbdiskfsadapter.h"

void SB_CALLBACK TElVFSWriteFileTagEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, const char * pcTagValue, int32_t szTagValue, int32_t * ResultCode)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zPath;
	zval * zTagName;
	zval * zTagValue;
	zval * zResultCode;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SB_ZVAL_STRINGL_DUP(zPath, pcPath, szPath);
	SB_EVENT_INIT_ZVAL(zTagName, 2);
	SB_ZVAL_STRINGL_DUP(zTagName, pcTagName, szTagName);
	SB_EVENT_INIT_ZVAL(zTagValue, 3);
	SB_ZVAL_STRINGL_DUP(zTagValue, pcTagValue, szTagValue);
	SB_EVENT_INIT_ZVAL_REF(zResultCode, 4);
	ZVAL_LONG(Z_REFVAL_P(zResultCode), (sb_zend_long)*ResultCode);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	SB_EVENT_CLEAR_ZVAL(zTagName);
	SB_EVENT_CLEAR_ZVAL(zTagValue);
	convert_to_long(Z_REFVAL_P(zResultCode));
	*ResultCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zResultCode));
	SB_EVENT_CLEAR_ZVAL(zResultCode);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElVFSReadFileTagEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, char * pcTagValue, int32_t * szTagValue, int32_t * ResultCode)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zPath;
	zval * zTagName;
	zval * zTagValue;
	zval * zResultCode;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SB_ZVAL_STRINGL_DUP(zPath, pcPath, szPath);
	SB_EVENT_INIT_ZVAL(zTagName, 2);
	SB_ZVAL_STRINGL_DUP(zTagName, pcTagName, szTagName);
	SB_EVENT_INIT_ZVAL_REF(zTagValue, 3);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zTagValue), pcTagValue, *szTagValue);
	SB_EVENT_INIT_ZVAL_REF(zResultCode, 4);
	ZVAL_LONG(Z_REFVAL_P(zResultCode), (sb_zend_long)*ResultCode);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	SB_EVENT_CLEAR_ZVAL(zTagName);
	convert_to_string(Z_REFVAL_P(zTagValue));
	SBCheckError(SBSetEventReturnStringA(4, Z_STRVAL_P(Z_REFVAL_P(zTagValue)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zTagValue))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zTagValue);
	convert_to_long(Z_REFVAL_P(zResultCode));
	*ResultCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zResultCode));
	SB_EVENT_CLEAR_ZVAL(zResultCode);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElVFSDeleteFileTagEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, int32_t * ResultCode)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zPath;
	zval * zTagName;
	zval * zResultCode;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SB_ZVAL_STRINGL_DUP(zPath, pcPath, szPath);
	SB_EVENT_INIT_ZVAL(zTagName, 2);
	SB_ZVAL_STRINGL_DUP(zTagName, pcTagName, szTagName);
	SB_EVENT_INIT_ZVAL_REF(zResultCode, 3);
	ZVAL_LONG(Z_REFVAL_P(zResultCode), (sb_zend_long)*ResultCode);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	SB_EVENT_CLEAR_ZVAL(zTagName);
	convert_to_long(Z_REFVAL_P(zResultCode));
	*ResultCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zResultCode));
	SB_EVENT_CLEAR_ZVAL(zResultCode);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElDiskFileSystemAdapter_ce_ptr = NULL;

SB_PHP_METHOD(TElDiskFileSystemAdapter, AdjustPath)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElDiskFileSystemAdapter_AdjustPath(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(484334838, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, Clone)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDiskFileSystemAdapter_Clone(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomFileSystemAdapter_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, GetFileStream)
{
	char *sPath;
	sb_str_size sPath_len;
	sb_zend_long fShareMode;
	sb_zend_long u4OpenMode;
	TElClassHandle hoFileStream;
	zval *oFileStream;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sllO", &sPath, &sPath_len, &u4OpenMode, &fShareMode, &oFileStream, TStream_ce_ptr) == SUCCESS) && SB_ISREF_OBJECT_P(oFileStream))
	{
		int32_t l4OutResultRaw = 0;
		hoFileStream = SBGetObjectHandle(oFileStream TSRMLS_CC);
		SBCheckError(TElDiskFileSystemAdapter_GetFileStream(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, (uint32_t)u4OpenMode, (TSBFileShareModeRaw)fShareMode, &hoFileStream, &l4OutResultRaw) TSRMLS_CC);
		SBUpdateObjectHandle(oFileStream, hoFileStream TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer, integer, &\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, FileExists)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDiskFileSystemAdapter_FileExists(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, DirectoryExists)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDiskFileSystemAdapter_DirectoryExists(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, FileDelete)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDiskFileSystemAdapter_FileDelete(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, FileMove)
{
	char *sFromName;
	char *sToName;
	sb_str_size sFromName_len;
	sb_str_size sToName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sFromName, &sFromName_len, &sToName, &sToName_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDiskFileSystemAdapter_FileMove(SBGetObjectHandle(getThis() TSRMLS_CC), sFromName, (int32_t)sFromName_len, sToName, (int32_t)sToName_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, DirectoryRemove)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDiskFileSystemAdapter_DirectoryRemove(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, DirectoryMake)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDiskFileSystemAdapter_DirectoryMake(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, FileRead)
{
	int32_t l4ErrorCodeRaw;
	sb_zend_long l4Index;
	sb_zend_long l4Size;
	SBArrayZValInfo aiBuffer;
	zval *oFileHandle;
	zval *zaBuffer;
	zval *zl4ErrorCode;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zllz", &oFileHandle, TObject_ce_ptr, &zaBuffer, &l4Index, &l4Size, &zl4ErrorCode) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4ErrorCode) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4ErrorCode))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4ErrorCodeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4ErrorCode));
		SBCheckError(TElDiskFileSystemAdapter_FileRead(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oFileHandle TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, (int32_t)l4Size, &l4ErrorCodeRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4ErrorCode), (sb_zend_long)l4ErrorCodeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject, array of byte|string|NULL, integer, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, FileWrite)
{
	int32_t l4ErrorCodeRaw;
	sb_zend_long l4Index;
	sb_zend_long l4Size;
	SBArrayZValInfo aiBuffer;
	zval *oFileHandle;
	zval *zaBuffer;
	zval *zl4ErrorCode;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zllz", &oFileHandle, TObject_ce_ptr, &zaBuffer, &l4Index, &l4Size, &zl4ErrorCode) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zl4ErrorCode) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4ErrorCode))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4ErrorCodeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4ErrorCode));
		SBCheckError(TElDiskFileSystemAdapter_FileWrite(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oFileHandle TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4Index, (int32_t)l4Size, &l4ErrorCodeRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4ErrorCode), (sb_zend_long)l4ErrorCodeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject, array of byte|string|NULL, integer, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, FileSeek)
{
	sb_zend_long fOrigin;
	sb_zend_long l8Position;
	zval *oFileHandle;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!ll", &oFileHandle, TObject_ce_ptr, &l8Position, &fOrigin) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElDiskFileSystemAdapter_FileSeek(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oFileHandle TSRMLS_CC), (int64_t)l8Position, (TSBFileSeekOriginRaw)fOrigin, &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, FileSetSize)
{
	sb_zend_long l8NewSize;
	zval *oFileHandle;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oFileHandle, TObject_ce_ptr, &l8NewSize) == SUCCESS)
	{
		SBCheckError(TElDiskFileSystemAdapter_FileSetSize(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oFileHandle TSRMLS_CC), (int64_t)l8NewSize) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, FileGetSize)
{
	zval *oFileHandle;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oFileHandle, TObject_ce_ptr) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElDiskFileSystemAdapter_FileGetSize(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oFileHandle TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, FileGetPosition)
{
	zval *oFileHandle;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oFileHandle, TObject_ce_ptr) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElDiskFileSystemAdapter_FileGetPosition(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oFileHandle TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, WriteFileTag)
{
	char *sPath;
	char *sTagName;
	char *sTagValue;
	sb_str_size sPath_len;
	sb_str_size sTagName_len;
	sb_str_size sTagValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sss", &sPath, &sPath_len, &sTagName, &sTagName_len, &sTagValue, &sTagValue_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDiskFileSystemAdapter_WriteFileTag(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, sTagName, (int32_t)sTagName_len, sTagValue, (int32_t)sTagValue_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, ReadFileTag)
{
	char *sPath;
	char *sTagName;
	char *sTagValue;
	int32_t sTagValue_len;
	sb_str_size sPath_len;
	sb_str_size sTagName_len;
	uint32_t _err;
	zval *zsTagValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssz", &sPath, &sPath_len, &sTagName, &sTagName_len, &zsTagValue) == SUCCESS) && Z_ISREF_P(zsTagValue) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsTagValue))))
	{
		int32_t l4OutResultRaw = 0;
		sTagValue = Z_STRVAL_P(Z_REFVAL_P(zsTagValue));
		sTagValue_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsTagValue));
		_err = TElDiskFileSystemAdapter_ReadFileTag(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, sTagName, (int32_t)sTagName_len, sTagValue, &sTagValue_len, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sTagValue = emalloc(sTagValue_len + 1);
			SBCheckError(SBGetLastReturnStringA(1165768749, 3, sTagValue, &sTagValue_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsTagValue));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sTagValue[sTagValue_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsTagValue), sTagValue, sTagValue_len);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, &string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, DeleteFileTag)
{
	char *sPath;
	char *sTagName;
	sb_str_size sPath_len;
	sb_str_size sTagName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sPath, &sPath_len, &sTagName, &sTagName_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDiskFileSystemAdapter_DeleteFileTag(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, sTagName, (int32_t)sTagName_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, FileGetTimes)
{
	char *sPath;
	int64_t dtCreationTimeRaw;
	int64_t dtLastAccessTimeRaw;
	int64_t dtModificationTimeRaw;
	sb_str_size sPath_len;
	zval *dtCreationTime;
	zval *dtLastAccessTime;
	zval *dtModificationTime;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sOOO", &sPath, &sPath_len, &dtCreationTime, php_date_get_date_ce(), &dtModificationTime, php_date_get_date_ce(), &dtLastAccessTime, php_date_get_date_ce()) == SUCCESS) && SB_ISREF_DATETIME_P(dtCreationTime) && SB_ISREF_DATETIME_P(dtModificationTime) && SB_ISREF_DATETIME_P(dtLastAccessTime))
	{
		int32_t l4OutResultRaw = 0;
		dtCreationTimeRaw = SBGetDateTime(dtCreationTime TSRMLS_CC);
		dtModificationTimeRaw = SBGetDateTime(dtModificationTime TSRMLS_CC);
		dtLastAccessTimeRaw = SBGetDateTime(dtLastAccessTime TSRMLS_CC);
		SBCheckError(TElDiskFileSystemAdapter_FileGetTimes(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, &dtCreationTimeRaw, &dtModificationTimeRaw, &dtLastAccessTimeRaw, &l4OutResultRaw) TSRMLS_CC);
		SBSetDateTime(dtCreationTime, dtCreationTimeRaw TSRMLS_CC);
		SBSetDateTime(dtModificationTime, dtModificationTimeRaw TSRMLS_CC);
		SBSetDateTime(dtLastAccessTime, dtLastAccessTimeRaw TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, &\\DateTime, &\\DateTime, &\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, GetEntryInformation)
{
	char *sPath;
	sb_str_size sPath_len;
	zval *oEntryInfo;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sPath, &sPath_len, &oEntryInfo, TElVFSEntryInformation_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDiskFileSystemAdapter_GetEntryInformation(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, SBGetObjectHandle(oEntryInfo TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElVFSEntryInformation)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, SetEntryInformation)
{
	char *sPath;
	sb_str_size sPath_len;
	sb_zend_long l4InfoFlags;
	zval *oEntryInfo;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!l", &sPath, &sPath_len, &oEntryInfo, TElVFSEntryInformation_ce_ptr, &l4InfoFlags) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDiskFileSystemAdapter_SetEntryInformation(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, SBGetObjectHandle(oEntryInfo TSRMLS_CC), (int32_t)l4InfoFlags, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElVFSEntryInformation, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, GetFullPath)
{
	char *sFileName;
	sb_str_size sFileName_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sFileName, &sFileName_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElDiskFileSystemAdapter_GetFullPath(SBGetObjectHandle(getThis() TSRMLS_CC), sFileName, (int32_t)sFileName_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1203931947, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, get_OnWriteFileTag)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElVFSWriteFileTagEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDiskFileSystemAdapter_get_OnWriteFileTag(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, set_OnWriteFileTag)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDiskFileSystemAdapter_set_OnWriteFileTag(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TElVFSWriteFileTagEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElVFSWriteFileTagEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, get_OnReadFileTag)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElVFSReadFileTagEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDiskFileSystemAdapter_get_OnReadFileTag(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, set_OnReadFileTag)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDiskFileSystemAdapter_set_OnReadFileTag(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TElVFSReadFileTagEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElVFSReadFileTagEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, get_OnDeleteFileTag)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElVFSDeleteFileTagEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDiskFileSystemAdapter_get_OnDeleteFileTag(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, set_OnDeleteFileTag)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDiskFileSystemAdapter_set_OnDeleteFileTag(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TElVFSDeleteFileTagEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElVFSDeleteFileTagEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDiskFileSystemAdapter, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDiskFileSystemAdapter_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_AdjustPath, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_Clone, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_GetFileStream, 0, 0, 4)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_INFO(0, OpenMode)
	ZEND_ARG_INFO(0, ShareMode)
	ZEND_ARG_OBJ_INFO(1, FileStream, TStream, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_FileExists, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_DirectoryExists, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_FileDelete, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_FileMove, 0, 0, 2)
	ZEND_ARG_INFO(0, FromName)
	ZEND_ARG_INFO(0, ToName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_DirectoryRemove, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_DirectoryMake, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_FileRead, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(0, FileHandle, TObject, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(1, ErrorCode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_FileWrite, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(0, FileHandle, TObject, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(1, ErrorCode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_FileSeek, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, FileHandle, TObject, 1)
	ZEND_ARG_INFO(0, Position)
	ZEND_ARG_INFO(0, Origin)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_FileSetSize, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, FileHandle, TObject, 1)
	ZEND_ARG_INFO(0, NewSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_FileGetSize, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, FileHandle, TObject, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_FileGetPosition, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, FileHandle, TObject, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_WriteFileTag, 0, 0, 3)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_INFO(0, TagName)
	ZEND_ARG_INFO(0, TagValue)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_ReadFileTag, 0, 0, 3)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_INFO(0, TagName)
	ZEND_ARG_INFO(1, TagValue)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_DeleteFileTag, 0, 0, 2)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_INFO(0, TagName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_FileGetTimes, 0, 0, 4)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_OBJ_INFO(1, CreationTime, DateTime, 0)
	ZEND_ARG_OBJ_INFO(1, ModificationTime, DateTime, 0)
	ZEND_ARG_OBJ_INFO(1, LastAccessTime, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_GetEntryInformation, 0, 0, 2)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_OBJ_INFO(0, EntryInfo, TElVFSEntryInformation, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_SetEntryInformation, 0, 0, 3)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_OBJ_INFO(0, EntryInfo, TElVFSEntryInformation, 1)
	ZEND_ARG_INFO(0, InfoFlags)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_GetFullPath, 0, 0, 1)
	ZEND_ARG_INFO(0, FileName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_get_OnWriteFileTag, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_set_OnWriteFileTag, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_get_OnReadFileTag, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_set_OnReadFileTag, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_get_OnDeleteFileTag, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter_set_OnDeleteFileTag, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDiskFileSystemAdapter___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElDiskFileSystemAdapter_methods[] = {
	PHP_ME(TElDiskFileSystemAdapter, AdjustPath, arginfo_TElDiskFileSystemAdapter_AdjustPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, Clone, arginfo_TElDiskFileSystemAdapter_Clone, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, GetFileStream, arginfo_TElDiskFileSystemAdapter_GetFileStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, FileExists, arginfo_TElDiskFileSystemAdapter_FileExists, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, DirectoryExists, arginfo_TElDiskFileSystemAdapter_DirectoryExists, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, FileDelete, arginfo_TElDiskFileSystemAdapter_FileDelete, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, FileMove, arginfo_TElDiskFileSystemAdapter_FileMove, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, DirectoryRemove, arginfo_TElDiskFileSystemAdapter_DirectoryRemove, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, DirectoryMake, arginfo_TElDiskFileSystemAdapter_DirectoryMake, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, FileRead, arginfo_TElDiskFileSystemAdapter_FileRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, FileWrite, arginfo_TElDiskFileSystemAdapter_FileWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, FileSeek, arginfo_TElDiskFileSystemAdapter_FileSeek, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, FileSetSize, arginfo_TElDiskFileSystemAdapter_FileSetSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, FileGetSize, arginfo_TElDiskFileSystemAdapter_FileGetSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, FileGetPosition, arginfo_TElDiskFileSystemAdapter_FileGetPosition, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, WriteFileTag, arginfo_TElDiskFileSystemAdapter_WriteFileTag, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, ReadFileTag, arginfo_TElDiskFileSystemAdapter_ReadFileTag, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, DeleteFileTag, arginfo_TElDiskFileSystemAdapter_DeleteFileTag, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, FileGetTimes, arginfo_TElDiskFileSystemAdapter_FileGetTimes, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, GetEntryInformation, arginfo_TElDiskFileSystemAdapter_GetEntryInformation, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, SetEntryInformation, arginfo_TElDiskFileSystemAdapter_SetEntryInformation, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, GetFullPath, arginfo_TElDiskFileSystemAdapter_GetFullPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, get_OnWriteFileTag, arginfo_TElDiskFileSystemAdapter_get_OnWriteFileTag, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, set_OnWriteFileTag, arginfo_TElDiskFileSystemAdapter_set_OnWriteFileTag, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, get_OnReadFileTag, arginfo_TElDiskFileSystemAdapter_get_OnReadFileTag, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, set_OnReadFileTag, arginfo_TElDiskFileSystemAdapter_set_OnReadFileTag, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, get_OnDeleteFileTag, arginfo_TElDiskFileSystemAdapter_get_OnDeleteFileTag, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, set_OnDeleteFileTag, arginfo_TElDiskFileSystemAdapter_set_OnDeleteFileTag, ZEND_ACC_PUBLIC)
	PHP_ME(TElDiskFileSystemAdapter, __construct, arginfo_TElDiskFileSystemAdapter___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDiskFileSystemAdapter(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDiskFileSystemAdapter_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDiskFileSystemAdapter", TElDiskFileSystemAdapter_methods);
	if (NULL == TElCustomFileSystemAdapter_ce_ptr)
		Register_TElCustomFileSystemAdapter(TSRMLS_C);
	TElDiskFileSystemAdapter_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomFileSystemAdapter_ce_ptr);
}

