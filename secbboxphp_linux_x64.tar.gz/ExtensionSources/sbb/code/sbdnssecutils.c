#include "sbdnssecutils.h"

SB_PHP_FUNCTION(SBDNSSECUtils, ResourceTypeToCode)
{
	sb_zend_long fAType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fAType) == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(SBDNSSECUtils_ResourceTypeToCode((TSBDNSResourceTypeRaw)fAType, &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, ResourceCodeToType)
{
	sb_zend_long u2ACode;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2ACode) == SUCCESS)
	{
		TSBDNSResourceTypeRaw fOutResultRaw = 0;
		SBCheckError(SBDNSSECUtils_ResourceCodeToType((uint16_t)u2ACode, &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, IPv6ToString)
{
	SBArrayZValInfo aiBuffer;
	uint32_t _err;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = SBDNSSECUtils_IPv6ToString(aiBuffer.data, aiBuffer.len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1185144435, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiBuffer);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, ReadDomainName)
{
	SBArrayZValInfo aiBuffer;
	uint16_t u2OffsetRaw;
	uint32_t _err;
	zval *zaBuffer;
	zval *zu2Offset;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaBuffer, &zu2Offset) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)) && Z_ISREF_P(zu2Offset) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2Offset))))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		u2OffsetRaw = (uint16_t)Z_LVAL_P(Z_REFVAL_P(zu2Offset));
		_err = SBDNSSECUtils_ReadDomainName(aiBuffer.data, aiBuffer.len, &u2OffsetRaw, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1152854976, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiBuffer);
		ZVAL_LONG(Z_REFVAL_P(zu2Offset), (sb_zend_long)u2OffsetRaw);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, WriteDomainName)
{
	char *sName;
	int32_t l4IndexRaw;
	sb_str_size sName_len;
	SBArrayZValInfo aiBuffer;
	uint32_t _err;
	zval *oStream;
	zval *zaBuffer;
	zval *zl4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sName, &sName_len, &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(SBDNSSECUtils_WriteDomainName(sName, (int32_t)sName_len, SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szz", &sName, &sName_len, &zaBuffer, &zl4Index) == SUCCESS) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))) && Z_ISREF_P(zl4Index) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Index))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4IndexRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Index));
		_err = SBDNSSECUtils_WriteDomainName_1(sName, (int32_t)sName_len, aiBuffer.data, &aiBuffer.len, &l4IndexRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-356186367, 1, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Index), (sb_zend_long)l4IndexRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TStream) or (string, &array of byte|string, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, WriteIPv4Address)
{
	char *sAddress;
	int32_t l4IndexRaw;
	sb_str_size sAddress_len;
	SBArrayZValInfo aiBuffer;
	uint32_t _err;
	zval *zaBuffer;
	zval *zl4Index;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szz", &sAddress, &sAddress_len, &zaBuffer, &zl4Index) == SUCCESS) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))) && Z_ISREF_P(zl4Index) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Index))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4IndexRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Index));
		_err = SBDNSSECUtils_WriteIPv4Address(sAddress, (int32_t)sAddress_len, aiBuffer.data, &aiBuffer.len, &l4IndexRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-1490868494, 1, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Index), (sb_zend_long)l4IndexRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, &array of byte|string, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, WriteIPv6Address)
{
	char *sAddress;
	int32_t l4IndexRaw;
	sb_str_size sAddress_len;
	SBArrayZValInfo aiBuffer;
	uint32_t _err;
	zval *zaBuffer;
	zval *zl4Index;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szz", &sAddress, &sAddress_len, &zaBuffer, &zl4Index) == SUCCESS) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))) && Z_ISREF_P(zl4Index) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Index))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4IndexRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Index));
		_err = SBDNSSECUtils_WriteIPv6Address(sAddress, (int32_t)sAddress_len, aiBuffer.data, &aiBuffer.len, &l4IndexRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(2108821133, 1, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Index), (sb_zend_long)l4IndexRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, &array of byte|string, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, WriteString)
{
	char *sStr;
	int32_t l4IndexRaw;
	sb_str_size sStr_len;
	SBArrayZValInfo aiBuffer;
	uint32_t _err;
	zval *zaBuffer;
	zval *zl4Index;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szz", &sStr, &sStr_len, &zaBuffer, &zl4Index) == SUCCESS) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))) && Z_ISREF_P(zl4Index) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Index))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4IndexRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Index));
		_err = SBDNSSECUtils_WriteString(sStr, (int32_t)sStr_len, aiBuffer.data, &aiBuffer.len, &l4IndexRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-1433360000, 1, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Index), (sb_zend_long)l4IndexRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, &array of byte|string, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, ResponseCodeToRCode)
{
	sb_zend_long fACode;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fACode) == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(SBDNSSECUtils_ResponseCodeToRCode((TSBDNSResponseCodeRaw)fACode, &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, RCodeToResponseCode)
{
	sb_zend_long u2ACode;
	zend_bool bUsedInExtensions;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &u2ACode, &bUsedInExtensions) == SUCCESS)
	{
		TSBDNSResponseCodeRaw fOutResultRaw = 0;
		SBCheckError(SBDNSSECUtils_RCodeToResponseCode((uint16_t)u2ACode, (int8_t)bUsedInExtensions, &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, OperationCodeToOpCode)
{
	sb_zend_long fACode;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fACode) == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(SBDNSSECUtils_OperationCodeToOpCode((TSBDNSOperationCodeRaw)fACode, &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, OpCodeToOperationCode)
{
	sb_zend_long u1ACode;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1ACode) == SUCCESS)
	{
		TSBDNSOperationCodeRaw fOutResultRaw = 0;
		SBCheckError(SBDNSSECUtils_OpCodeToOperationCode((uint8_t)u1ACode, &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, CheckBufferBounds)
{
	sb_zend_long u2Offset;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaBuffer, &u2Offset) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBDNSSECUtils_CheckBufferBounds(aiBuffer.data, aiBuffer.len, (uint16_t)u2Offset) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, IsSubdomain)
{
	char *sDomain;
	char *sSubdomain;
	sb_str_size sDomain_len;
	sb_str_size sSubdomain_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sSubdomain, &sSubdomain_len, &sDomain, &sDomain_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBDNSSECUtils_IsSubdomain(sSubdomain, (int32_t)sSubdomain_len, sDomain, (int32_t)sDomain_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, LabelCount)
{
	char *sDomain;
	sb_str_size sDomain_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sDomain, &sDomain_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBDNSSECUtils_LabelCount(sDomain, (int32_t)sDomain_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, ExtractLabels)
{
	char *sDomain;
	sb_str_size sDomain_len;
	sb_zend_long l4Count;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &sDomain, &sDomain_len, &l4Count) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBDNSSECUtils_ExtractLabels(sDomain, (int32_t)sDomain_len, (int32_t)l4Count, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1161428816, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBDNSSECUtils, CompareDomainNames)
{
	char *sName1;
	char *sName2;
	sb_str_size sName1_len;
	sb_str_size sName2_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sName1, &sName1_len, &sName2, &sName2_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBDNSSECUtils_CompareDomainNames(sName1, (int32_t)sName1_len, sName2, (int32_t)sName2_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

