#include "sbdtlsserver.h"

void SB_CALLBACK TSBDTLSServerCreatedEventRaw(void * _ObjectData, TObjectHandle Sender, TElDTLSServerHandle Server, const uint8_t pClientID[], int32_t szClientID)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zServer;
	zval * zClientID;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zServer, 1);
	SBInitObject(zServer, TElDTLSServer_ce_ptr, Server TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zClientID, 2);
	SB_ZVAL_STRINGL_DUP(zClientID, pClientID, szClientID);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zServer);
	SB_EVENT_CLEAR_ZVAL(zClientID);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBDTLSSendEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size, const uint8_t pClientID[], int32_t szClientID)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zBuffer;
	zval * zSize;
	zval * zClientID;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 1);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSize, 2);
	ZVAL_LONG(zSize, (sb_zend_long)Size);
	SB_EVENT_INIT_ZVAL(zClientID, 3);
	SB_ZVAL_STRINGL_DUP(zClientID, pClientID, szClientID);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zSize);
	SB_EVENT_CLEAR_ZVAL(zClientID);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElDTLSServer_ce_ptr = NULL;

SB_PHP_METHOD(TElDTLSServer, get_UseClientVerification)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDTLSServer_get_UseClientVerification(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServer, set_UseClientVerification)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElDTLSServer_set_UseClientVerification(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServer, get_DatagramSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDTLSServer_get_DatagramSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServer, set_DatagramSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElDTLSServer_set_DatagramSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServer, get_MaxDataSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDTLSServer_get_MaxDataSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServer, get_SplitLongData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDTLSServer_get_SplitLongData(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServer, set_SplitLongData)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElDTLSServer_set_SplitLongData(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServer, get_UseRetransmissionTimer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDTLSServer_get_UseRetransmissionTimer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServer, set_UseRetransmissionTimer)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElDTLSServer_set_UseRetransmissionTimer(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServer, get_TimerValue)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDTLSServer_get_TimerValue(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServer, set_TimerValue)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElDTLSServer_set_TimerValue(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServer, get_AutoAdjustTimerValue)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElDTLSServer_get_AutoAdjustTimerValue(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServer, set_AutoAdjustTimerValue)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElDTLSServer_set_AutoAdjustTimerValue(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServer, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDTLSServer_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServer_get_UseClientVerification, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServer_set_UseClientVerification, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServer_get_DatagramSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServer_set_DatagramSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServer_get_MaxDataSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServer_get_SplitLongData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServer_set_SplitLongData, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServer_get_UseRetransmissionTimer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServer_set_UseRetransmissionTimer, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServer_get_TimerValue, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServer_set_TimerValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServer_get_AutoAdjustTimerValue, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServer_set_AutoAdjustTimerValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServer___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElDTLSServer_methods[] = {
	PHP_ME(TElDTLSServer, get_UseClientVerification, arginfo_TElDTLSServer_get_UseClientVerification, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServer, set_UseClientVerification, arginfo_TElDTLSServer_set_UseClientVerification, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServer, get_DatagramSize, arginfo_TElDTLSServer_get_DatagramSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServer, set_DatagramSize, arginfo_TElDTLSServer_set_DatagramSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServer, get_MaxDataSize, arginfo_TElDTLSServer_get_MaxDataSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServer, get_SplitLongData, arginfo_TElDTLSServer_get_SplitLongData, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServer, set_SplitLongData, arginfo_TElDTLSServer_set_SplitLongData, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServer, get_UseRetransmissionTimer, arginfo_TElDTLSServer_get_UseRetransmissionTimer, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServer, set_UseRetransmissionTimer, arginfo_TElDTLSServer_set_UseRetransmissionTimer, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServer, get_TimerValue, arginfo_TElDTLSServer_get_TimerValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServer, set_TimerValue, arginfo_TElDTLSServer_set_TimerValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServer, get_AutoAdjustTimerValue, arginfo_TElDTLSServer_get_AutoAdjustTimerValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServer, set_AutoAdjustTimerValue, arginfo_TElDTLSServer_set_AutoAdjustTimerValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServer, __construct, arginfo_TElDTLSServer___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDTLSServer(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDTLSServer_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDTLSServer", TElDTLSServer_methods);
	if (NULL == TElSSLServer_ce_ptr)
		Register_TElSSLServer(TSRMLS_C);
	TElDTLSServer_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSSLServer_ce_ptr);
}

zend_class_entry *TElDTLSServerFactory_ce_ptr = NULL;

SB_PHP_METHOD(TElDTLSServerFactory, ProcessRequest)
{
	sb_zend_long l4Size;
	SBArrayZValInfo aiClientID;
	SBArrayZValInfo piBuffer;
	zval *zaClientID;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zpBuffer, &l4Size, &zaClientID) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zaClientID) || SB_IS_ARRAY_TYPE_RP(zaClientID) || SB_IS_NULL_TYPE_RP(zaClientID)))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaClientID, &aiClientID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDTLSServerFactory_ProcessRequest(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, aiClientID.data, aiClientID.len) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		SBFreeArrayZValInfo(&aiClientID);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServerFactory, get_OnSend)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDTLSSendEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDTLSServerFactory_get_OnSend(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServerFactory, set_OnSend)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDTLSServerFactory_set_OnSend(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDTLSSendEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDTLSSendEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServerFactory, get_OnServerCreated)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDTLSServerCreatedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElDTLSServerFactory_get_OnServerCreated(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServerFactory, set_OnServerCreated)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElDTLSServerFactory_set_OnServerCreated(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDTLSServerCreatedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDTLSServerCreatedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSServerFactory, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDTLSServerFactory_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServerFactory_ProcessRequest, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_TYPE_INFO(0, ClientID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServerFactory_get_OnSend, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServerFactory_set_OnSend, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServerFactory_get_OnServerCreated, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServerFactory_set_OnServerCreated, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSServerFactory___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElDTLSServerFactory_methods[] = {
	PHP_ME(TElDTLSServerFactory, ProcessRequest, arginfo_TElDTLSServerFactory_ProcessRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServerFactory, get_OnSend, arginfo_TElDTLSServerFactory_get_OnSend, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServerFactory, set_OnSend, arginfo_TElDTLSServerFactory_set_OnSend, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServerFactory, get_OnServerCreated, arginfo_TElDTLSServerFactory_get_OnServerCreated, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServerFactory, set_OnServerCreated, arginfo_TElDTLSServerFactory_set_OnServerCreated, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSServerFactory, __construct, arginfo_TElDTLSServerFactory___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElDTLSServerFactory(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDTLSServerFactory_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDTLSServerFactory", TElDTLSServerFactory_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElDTLSServerFactory_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

void Register_SBDTLSServer_Aliases(TSRMLS_D)
{
	if (NULL == TElDTLSServer_ce_ptr)
		Register_TElDTLSServer(TSRMLS_C);
	zend_register_class_alias("ElDTLSServer", TElDTLSServer_ce_ptr);
	if (NULL == TElDTLSServerFactory_ce_ptr)
		Register_TElDTLSServerFactory(TSRMLS_C);
	zend_register_class_alias("ElDTLSServerFactory", TElDTLSServerFactory_ce_ptr);
}

