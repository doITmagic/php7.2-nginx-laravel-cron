#include "sbeccommon.h"

zend_class_entry *TElECDomainParameters_ce_ptr = NULL;

SB_PHP_METHOD(TElECDomainParameters, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElECDomainParameters_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElECDomainParameters_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElECDomainParameters_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElECDomainParameters)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, Check)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElECDomainParameters_Check(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_Curve)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElECDomainParameters_get_Curve(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_Curve)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElECDomainParameters_set_Curve(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_CurveOID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElECDomainParameters_get_CurveOID(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1799319650, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_CurveOID)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElECDomainParameters_set_CurveOID(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_P)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElECDomainParameters_get_P(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-620394513, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_P)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElECDomainParameters_set_P(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_A)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElECDomainParameters_get_A(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1313495267, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_A)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElECDomainParameters_set_A(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_B)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElECDomainParameters_get_B(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(683472551, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_B)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElECDomainParameters_set_B(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_N)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElECDomainParameters_get_N(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(554351244, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_N)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElECDomainParameters_set_N(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_H)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElECDomainParameters_get_H(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_H)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElECDomainParameters_set_H(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_X)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElECDomainParameters_get_X(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-706867235, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_X)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElECDomainParameters_set_X(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_Y)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElECDomainParameters_get_Y(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1562820789, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_Y)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElECDomainParameters_set_Y(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_Seed)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElECDomainParameters_get_Seed(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1460997693, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_Seed)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElECDomainParameters_set_Seed(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_FieldType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElECDomainParameters_get_FieldType(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_FieldType)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElECDomainParameters_set_FieldType(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_Field)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElECDomainParameters_get_Field(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_Field)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElECDomainParameters_set_Field(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_FieldBits)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElECDomainParameters_get_FieldBits(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_SubgroupBits)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElECDomainParameters_get_SubgroupBits(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_M)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElECDomainParameters_get_M(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_M)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElECDomainParameters_set_M(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_K1)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElECDomainParameters_get_K1(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_K1)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElECDomainParameters_set_K1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_K2)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElECDomainParameters_get_K2(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_K2)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElECDomainParameters_set_K2(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_K3)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElECDomainParameters_get_K3(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_K3)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElECDomainParameters_set_K3(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, get_K4)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElECDomainParameters_get_K4(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, set_K4)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElECDomainParameters_set_K4(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECDomainParameters, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElECDomainParameters_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElECDomainParameters, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_Check, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_Curve, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_Curve, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_CurveOID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_CurveOID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_P, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_P, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_A, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_A, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_B, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_B, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_N, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_N, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_H, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_H, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_X, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_X, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_Y, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_Y, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_Seed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_Seed, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_FieldType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_FieldType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_Field, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_Field, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_FieldBits, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_SubgroupBits, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_M, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_M, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_K1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_K1, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_K2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_K2, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_K3, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_K3, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_get_K4, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters_set_K4, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECDomainParameters___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElECDomainParameters_methods[] = {
	PHP_ME(TElECDomainParameters, Reset, arginfo_TElECDomainParameters_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, Assign, arginfo_TElECDomainParameters_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, Check, arginfo_TElECDomainParameters_Check, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_Curve, arginfo_TElECDomainParameters_get_Curve, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_Curve, arginfo_TElECDomainParameters_set_Curve, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_CurveOID, arginfo_TElECDomainParameters_get_CurveOID, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_CurveOID, arginfo_TElECDomainParameters_set_CurveOID, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_P, arginfo_TElECDomainParameters_get_P, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_P, arginfo_TElECDomainParameters_set_P, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_A, arginfo_TElECDomainParameters_get_A, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_A, arginfo_TElECDomainParameters_set_A, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_B, arginfo_TElECDomainParameters_get_B, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_B, arginfo_TElECDomainParameters_set_B, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_N, arginfo_TElECDomainParameters_get_N, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_N, arginfo_TElECDomainParameters_set_N, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_H, arginfo_TElECDomainParameters_get_H, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_H, arginfo_TElECDomainParameters_set_H, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_X, arginfo_TElECDomainParameters_get_X, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_X, arginfo_TElECDomainParameters_set_X, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_Y, arginfo_TElECDomainParameters_get_Y, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_Y, arginfo_TElECDomainParameters_set_Y, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_Seed, arginfo_TElECDomainParameters_get_Seed, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_Seed, arginfo_TElECDomainParameters_set_Seed, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_FieldType, arginfo_TElECDomainParameters_get_FieldType, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_FieldType, arginfo_TElECDomainParameters_set_FieldType, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_Field, arginfo_TElECDomainParameters_get_Field, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_Field, arginfo_TElECDomainParameters_set_Field, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_FieldBits, arginfo_TElECDomainParameters_get_FieldBits, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_SubgroupBits, arginfo_TElECDomainParameters_get_SubgroupBits, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_M, arginfo_TElECDomainParameters_get_M, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_M, arginfo_TElECDomainParameters_set_M, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_K1, arginfo_TElECDomainParameters_get_K1, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_K1, arginfo_TElECDomainParameters_set_K1, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_K2, arginfo_TElECDomainParameters_get_K2, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_K2, arginfo_TElECDomainParameters_set_K2, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_K3, arginfo_TElECDomainParameters_get_K3, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_K3, arginfo_TElECDomainParameters_set_K3, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, get_K4, arginfo_TElECDomainParameters_get_K4, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, set_K4, arginfo_TElECDomainParameters_set_K4, ZEND_ACC_PUBLIC)
	PHP_ME(TElECDomainParameters, __construct, arginfo_TElECDomainParameters___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElECDomainParameters(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElECDomainParameters_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElECDomainParameters", TElECDomainParameters_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElECDomainParameters_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

SB_PHP_FUNCTION(SBECCommon, GetCurveByOID)
{
	SBArrayZValInfo aiOID;
	zval *zaOID;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaOID) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBECCommon_GetCurveByOID(aiOID.data, aiOID.len, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBECCommon, GetOIDByCurve)
{
	sb_zend_long l4Curve;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Curve) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBECCommon_GetOIDByCurve((int32_t)l4Curve, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1430321745, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBECCommon, IsPointCompressed)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBECCommon_IsPointCompressed(piBuffer.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBECCommon, BufferToPoint)
{
	int32_t l4XSizeRaw;
	int32_t l4YSizeRaw;
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	SBArrayZValInfo piX;
	SBArrayZValInfo piY;
	zval *oDomainParams;
	zval *zl4XSize;
	zval *zl4YSize;
	zval *zpBuffer;
	zval *zpX;
	zval *zpY;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlO!zzzz", &zpBuffer, &l4Size, &oDomainParams, TElECDomainParameters_ce_ptr, &zpX, &zl4XSize, &zpY, &zl4YSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpX) || SB_IS_ARRAY_TYPE_RP(zpX) || SB_IS_NULL_TYPE_RP(zpX) || (SB_IS_OBJECT_TYPE_RP(zpX) && (Z_OBJCE_P(zpX) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4XSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4XSize))) && (SB_IS_STRING_TYPE_RP(zpY) || SB_IS_ARRAY_TYPE_RP(zpY) || SB_IS_NULL_TYPE_RP(zpY) || (SB_IS_OBJECT_TYPE_RP(zpY) && (Z_OBJCE_P(zpY) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4YSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4YSize))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpX, &piX TSRMLS_CC)) RETURN_FALSE;
		l4XSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4XSize));
		if (!SBGetPointerFromZVal(zpY, &piY TSRMLS_CC)) RETURN_FALSE;
		l4YSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4YSize));
		SBCheckError(SBECCommon_BufferToPoint(piBuffer.data, (int32_t)l4Size, SBGetObjectHandle(oDomainParams TSRMLS_CC), piX.data, &l4XSizeRaw, piY.data, &l4YSizeRaw, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		SBFreePointerZValInfo(&piX);
		ZVAL_LONG(Z_REFVAL_P(zl4XSize), (sb_zend_long)l4XSizeRaw);
		SBFreePointerZValInfo(&piY);
		ZVAL_LONG(Z_REFVAL_P(zl4YSize), (sb_zend_long)l4YSizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TElECDomainParameters, \\TSBPointer|array of byte|string|NULL, &integer, \\TSBPointer|array of byte|string|NULL, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBECCommon, PointToBuffer)
{
	int32_t l4SizeRaw;
	sb_zend_long l4XSize;
	sb_zend_long l4YSize;
	SBArrayZValInfo piBuffer;
	SBArrayZValInfo piX;
	SBArrayZValInfo piY;
	zend_bool bCompress;
	zend_bool bHybrid;
	zval *oDomainParams;
	zval *zl4Size;
	zval *zpBuffer;
	zval *zpX;
	zval *zpY;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzlO!zzbb", &zpX, &l4XSize, &zpY, &l4YSize, &oDomainParams, TElECDomainParameters_ce_ptr, &zpBuffer, &zl4Size, &bCompress, &bHybrid) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpX) || SB_IS_ARRAY_TYPE_RP(zpX) || SB_IS_NULL_TYPE_RP(zpX) || (SB_IS_OBJECT_TYPE_RP(zpX) && (Z_OBJCE_P(zpX) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpY) || SB_IS_ARRAY_TYPE_RP(zpY) || SB_IS_NULL_TYPE_RP(zpY) || (SB_IS_OBJECT_TYPE_RP(zpY) && (Z_OBJCE_P(zpY) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpX, &piX TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpY, &piY TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(SBECCommon_PointToBuffer(piX.data, (int32_t)l4XSize, piY.data, (int32_t)l4YSize, SBGetObjectHandle(oDomainParams TSRMLS_CC), piBuffer.data, &l4SizeRaw, (int8_t)bCompress, (int8_t)bHybrid, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piX);
		SBFreePointerZValInfo(&piY);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, integer, \\TElECDomainParameters, \\TSBPointer|array of byte|string|NULL, &integer, bool, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBECCommon, ValidateKey)
{
	sb_zend_long l4DSize;
	sb_zend_long l4QxSize;
	sb_zend_long l4QySize;
	SBArrayZValInfo piD;
	SBArrayZValInfo piQx;
	SBArrayZValInfo piQy;
	zval *oDomainParams;
	zval *zpD;
	zval *zpQx;
	zval *zpQy;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zlzlzl", &oDomainParams, TElECDomainParameters_ce_ptr, &zpD, &l4DSize, &zpQx, &l4QxSize, &zpQy, &l4QySize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpD) || SB_IS_ARRAY_TYPE_RP(zpD) || SB_IS_NULL_TYPE_RP(zpD) || (SB_IS_OBJECT_TYPE_RP(zpD) && (Z_OBJCE_P(zpD) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpQx) || SB_IS_ARRAY_TYPE_RP(zpQx) || SB_IS_NULL_TYPE_RP(zpQx) || (SB_IS_OBJECT_TYPE_RP(zpQx) && (Z_OBJCE_P(zpQx) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpQy) || SB_IS_ARRAY_TYPE_RP(zpQy) || SB_IS_NULL_TYPE_RP(zpQy) || (SB_IS_OBJECT_TYPE_RP(zpQy) && (Z_OBJCE_P(zpQy) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpD, &piD TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpQx, &piQx TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpQy, &piQy TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBECCommon_ValidateKey(SBGetObjectHandle(oDomainParams TSRMLS_CC), piD.data, (int32_t)l4DSize, piQx.data, (int32_t)l4QxSize, piQy.data, (int32_t)l4QySize, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piD);
		SBFreePointerZValInfo(&piQx);
		SBFreePointerZValInfo(&piQy);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElECDomainParameters, \\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBECCommon, HexStrToFieldElement)
{
	char *sSrc;
	sb_str_size sSrc_len;
	sb_zend_long l4PSize;
	uint32_t _err;
	zend_bool bLittleEndian;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sbl", &sSrc, &sSrc_len, &bLittleEndian, &l4PSize) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBECCommon_HexStrToFieldElement(sSrc, (int32_t)sSrc_len, (int8_t)bLittleEndian, (int32_t)l4PSize, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1674007267, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, bool, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBECCommon, BufferToFieldElement)
{
	sb_zend_long l4Size;
	SBArrayZValInfo aiBuf;
	SBArrayZValInfo piBuf;
	TLInt * proA;
	zval *oA;
	zval *oP;
	zval *zaBuf;
	zval *zpBuf;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zOO!", &zaBuf, &oA, TLInt_ce_ptr, &oP, TLInt_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuf) || SB_IS_ARRAY_TYPE_RP(zaBuf) || SB_IS_NULL_TYPE_RP(zaBuf)) && Z_ISREF_P(oA))
	{
		if (!SBGetByteArrayFromZVal(zaBuf, &aiBuf TSRMLS_CC)) RETURN_FALSE;
		proA = (TLInt *)SBGetStructPointer(oA TSRMLS_CC);
		SBCheckError(SBECCommon_BufferToFieldElement(aiBuf.data, aiBuf.len, &proA, (TLInt *)SBGetStructPointer(oP TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuf);
		SBSetStructPointer(oA, proA, sizeof(TLInt) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlOO!", &zpBuf, &l4Size, &oA, TLInt_ce_ptr, &oP, TLInt_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuf) || SB_IS_ARRAY_TYPE_RP(zpBuf) || SB_IS_NULL_TYPE_RP(zpBuf) || (SB_IS_OBJECT_TYPE_RP(zpBuf) && (Z_OBJCE_P(zpBuf) == TSBPointer_ce_ptr))) && Z_ISREF_P(oA))
	{
		if (!SBGetPointerFromZVal(zpBuf, &piBuf TSRMLS_CC)) RETURN_FALSE;
		proA = (TLInt *)SBGetStructPointer(oA TSRMLS_CC);
		SBCheckError(SBECCommon_BufferToFieldElement_1(piBuf.data, (int32_t)l4Size, &proA, (TLInt *)SBGetStructPointer(oP TSRMLS_CC)) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuf);
		SBSetStructPointer(oA, proA, sizeof(TLInt) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &TLInt, TLInt) or (\\TSBPointer|array of byte|string|NULL, integer, &TLInt, TLInt)" TSRMLS_CC);
	}
}

