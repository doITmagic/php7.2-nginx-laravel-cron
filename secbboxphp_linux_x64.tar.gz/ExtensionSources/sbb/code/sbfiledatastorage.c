#include "sbfiledatastorage.h"

zend_class_entry *TSBFileDataStorageCondition_ce_ptr = NULL;

zend_class_entry *TSBFileDataStorageConditions_ce_ptr = NULL;

zend_class_entry *TElFileDataStorageObject_ce_ptr = NULL;

SB_PHP_METHOD(TElFileDataStorageObject, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomDataStorageObject_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElFileDataStorageObject_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomDataStorageObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorageObject, Clone)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElFileDataStorageObject_Clone(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorageObject, get_Size)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElFileDataStorageObject_get_Size(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorageObject, get_ModificationTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElFileDataStorageObject_get_ModificationTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorageObject, get_ETag)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElFileDataStorageObject_get_ETag(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1554210822, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorageObject, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElFileDataStorageObject_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorageObject_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomDataStorageObject, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorageObject_Clone, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorageObject_get_Size, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorageObject_get_ModificationTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorageObject_get_ETag, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorageObject___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElFileDataStorageObject_methods[] = {
	PHP_ME(TElFileDataStorageObject, Assign, arginfo_TElFileDataStorageObject_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorageObject, Clone, arginfo_TElFileDataStorageObject_Clone, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorageObject, get_Size, arginfo_TElFileDataStorageObject_get_Size, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorageObject, get_ModificationTime, arginfo_TElFileDataStorageObject_get_ModificationTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorageObject, get_ETag, arginfo_TElFileDataStorageObject_get_ETag, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorageObject, __construct, arginfo_TElFileDataStorageObject___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElFileDataStorageObject(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElFileDataStorageObject_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElFileDataStorageObject", TElFileDataStorageObject_methods);
	if (NULL == TElCustomDataStorageObject_ce_ptr)
		Register_TElCustomDataStorageObject(TSRMLS_C);
	TElFileDataStorageObject_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomDataStorageObject_ce_ptr);
}

zend_class_entry *TElFileDataStorage_ce_ptr = NULL;

SB_PHP_METHOD(TElFileDataStorage, AcquireObject)
{
	char *sObjName;
	sb_str_size sObjName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sObjName, &sObjName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElFileDataStorage_AcquireObject(SBGetObjectHandle(getThis() TSRMLS_CC), sObjName, (int32_t)sObjName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElFileDataStorageObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElFileDataStorage_AcquireObject_1(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or ()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, WriteObject)
{
	char *sData;
	char *sObjName;
	sb_str_size sData_len;
	sb_str_size sObjName_len;
	SBArrayZValInfo aiETag;
	SBArrayZValInfo aiNewETag;
	uint32_t _err;
	zval *oHandler;
	zval *oObj;
	zval *oStrm;
	zval *zaETag;
	zval *zaNewETag;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssO!", &sObjName, &sObjName_len, &sData, &sData_len, &oHandler, TElCustomDataStorageSecurityHandler_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_WriteObject(SBGetObjectHandle(getThis() TSRMLS_CC), sObjName, (int32_t)sObjName_len, sData, (int32_t)sData_len, SBGetObjectHandle(oHandler TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!O!", &sObjName, &sObjName_len, &oStrm, TStream_ce_ptr, &oHandler, TElCustomDataStorageSecurityHandler_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_WriteObject_1(SBGetObjectHandle(getThis() TSRMLS_CC), sObjName, (int32_t)sObjName_len, SBGetObjectHandle(oStrm TSRMLS_CC), SBGetObjectHandle(oHandler TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!zO!", &sObjName, &sObjName_len, &oStrm, TStream_ce_ptr, &zaETag, &oHandler, TElCustomDataStorageSecurityHandler_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaETag) || SB_IS_ARRAY_TYPE_RP(zaETag) || SB_IS_NULL_TYPE_RP(zaETag)))
	{
		if (!SBGetByteArrayFromZVal(zaETag, &aiETag TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElFileDataStorage_WriteObject_2(SBGetObjectHandle(getThis() TSRMLS_CC), sObjName, (int32_t)sObjName_len, SBGetObjectHandle(oStrm TSRMLS_CC), aiETag.data, aiETag.len, SBGetObjectHandle(oHandler TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiETag);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!zO!z", &sObjName, &sObjName_len, &oStrm, TStream_ce_ptr, &zaETag, &oHandler, TElCustomDataStorageSecurityHandler_ce_ptr, &zaNewETag) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaETag) || SB_IS_ARRAY_TYPE_RP(zaETag) || SB_IS_NULL_TYPE_RP(zaETag)) && Z_ISREF_P(zaNewETag) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaNewETag))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaNewETag)))))
	{
		if (!SBGetByteArrayFromZVal(zaETag, &aiETag TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaNewETag, &aiNewETag TSRMLS_CC)) RETURN_FALSE;
		_err = TElFileDataStorage_WriteObject_3(SBGetObjectHandle(getThis() TSRMLS_CC), sObjName, (int32_t)sObjName_len, SBGetObjectHandle(oStrm TSRMLS_CC), aiETag.data, aiETag.len, SBGetObjectHandle(oHandler TSRMLS_CC), aiNewETag.data, &aiNewETag.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaNewETag, &aiNewETag TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-1125844992, 5, aiNewETag.data, &aiNewETag.len) TSRMLS_CC);
			((char *)aiNewETag.data)[aiNewETag.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiNewETag);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiETag);
		SBSetByteArrayToZVal(&aiNewETag, zaNewETag);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oObj, TElFileDataStorageObject_ce_ptr, &oStrm, TStream_ce_ptr, &oHandler, TElCustomDataStorageSecurityHandler_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_WriteObject_4(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), SBGetObjectHandle(oStrm TSRMLS_CC), SBGetObjectHandle(oHandler TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zO!", &oObj, TElFileDataStorageObject_ce_ptr, &oStrm, TStream_ce_ptr, &zaETag, &oHandler, TElCustomDataStorageSecurityHandler_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaETag) || SB_IS_ARRAY_TYPE_RP(zaETag) || SB_IS_NULL_TYPE_RP(zaETag)))
	{
		if (!SBGetByteArrayFromZVal(zaETag, &aiETag TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElFileDataStorage_WriteObject_5(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), SBGetObjectHandle(oStrm TSRMLS_CC), aiETag.data, aiETag.len, SBGetObjectHandle(oHandler TSRMLS_CC)) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiETag);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oObj, TElCustomDataStorageObject_ce_ptr, &oStrm, TStream_ce_ptr, &oHandler, TElCustomDataStorageSecurityHandler_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_WriteObject_6(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), SBGetObjectHandle(oStrm TSRMLS_CC), SBGetObjectHandle(oHandler TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, \\TElCustomDataStorageSecurityHandler) or (string, \\TStream, \\TElCustomDataStorageSecurityHandler) or (string, \\TStream, array of byte|string|NULL, \\TElCustomDataStorageSecurityHandler) or (string, \\TStream, array of byte|string|NULL, \\TElCustomDataStorageSecurityHandler, &array of byte|string) or (\\TElFileDataStorageObject, \\TStream, \\TElCustomDataStorageSecurityHandler) or (\\TElFileDataStorageObject, \\TStream, array of byte|string|NULL, \\TElCustomDataStorageSecurityHandler) or (\\TElCustomDataStorageObject, \\TStream, \\TElCustomDataStorageSecurityHandler)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, WriteBlock)
{
	char *sObjName;
	int64_t l8WrittenRaw;
	sb_str_size sObjName_len;
	sb_zend_long l8Offset;
	zval *oHandler;
	zval *oObj;
	zval *oStrm;
	zval *zl8Written;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!O!lz", &sObjName, &sObjName_len, &oStrm, TStream_ce_ptr, &oHandler, TElCustomDataStorageSecurityHandler_ce_ptr, &l8Offset, &zl8Written) == SUCCESS) && Z_ISREF_P(zl8Written) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl8Written))))
	{
		l8WrittenRaw = (int64_t)Z_LVAL_P(Z_REFVAL_P(zl8Written));
		SBCheckError(TElFileDataStorage_WriteBlock(SBGetObjectHandle(getThis() TSRMLS_CC), sObjName, (int32_t)sObjName_len, SBGetObjectHandle(oStrm TSRMLS_CC), SBGetObjectHandle(oHandler TSRMLS_CC), (int64_t)l8Offset, &l8WrittenRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zl8Written), (sb_zend_long)l8WrittenRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!lz", &oObj, TElCustomDataStorageObject_ce_ptr, &oStrm, TStream_ce_ptr, &oHandler, TElCustomDataStorageSecurityHandler_ce_ptr, &l8Offset, &zl8Written) == SUCCESS) && Z_ISREF_P(zl8Written) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl8Written))))
	{
		l8WrittenRaw = (int64_t)Z_LVAL_P(Z_REFVAL_P(zl8Written));
		SBCheckError(TElFileDataStorage_WriteBlock_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), SBGetObjectHandle(oStrm TSRMLS_CC), SBGetObjectHandle(oHandler TSRMLS_CC), (int64_t)l8Offset, &l8WrittenRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zl8Written), (sb_zend_long)l8WrittenRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TStream, \\TElCustomDataStorageSecurityHandler, integer, &integer) or (\\TElCustomDataStorageObject, \\TStream, \\TElCustomDataStorageSecurityHandler, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, ReadObject)
{
	char *sObjName;
	sb_str_size sObjName_len;
	SBArrayZValInfo aiETag;
	zval *oObj;
	zval *oStrm;
	zval *zaETag;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sObjName, &sObjName_len, &oStrm, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_ReadObject(SBGetObjectHandle(getThis() TSRMLS_CC), sObjName, (int32_t)sObjName_len, SBGetObjectHandle(oStrm TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!z", &sObjName, &sObjName_len, &oStrm, TStream_ce_ptr, &zaETag) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaETag) || SB_IS_ARRAY_TYPE_RP(zaETag) || SB_IS_NULL_TYPE_RP(zaETag)))
	{
		if (!SBGetByteArrayFromZVal(zaETag, &aiETag TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElFileDataStorage_ReadObject_1(SBGetObjectHandle(getThis() TSRMLS_CC), sObjName, (int32_t)sObjName_len, SBGetObjectHandle(oStrm TSRMLS_CC), aiETag.data, aiETag.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiETag);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oObj, TElFileDataStorageObject_ce_ptr, &oStrm, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_ReadObject_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), SBGetObjectHandle(oStrm TSRMLS_CC)) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!z", &oObj, TElFileDataStorageObject_ce_ptr, &oStrm, TStream_ce_ptr, &zaETag) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaETag) || SB_IS_ARRAY_TYPE_RP(zaETag) || SB_IS_NULL_TYPE_RP(zaETag)))
	{
		if (!SBGetByteArrayFromZVal(zaETag, &aiETag TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElFileDataStorage_ReadObject_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), SBGetObjectHandle(oStrm TSRMLS_CC), aiETag.data, aiETag.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiETag);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oObj, TElCustomDataStorageObject_ce_ptr, &oStrm, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_ReadObject_4(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), SBGetObjectHandle(oStrm TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TStream) or (string, \\TStream, array of byte|string|NULL) or (\\TElFileDataStorageObject, \\TStream) or (\\TElFileDataStorageObject, \\TStream, array of byte|string|NULL) or (\\TElCustomDataStorageObject, \\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, CopyObject)
{
	char *sDestObjName;
	char *sSrcObjName;
	sb_str_size sDestObjName_len;
	sb_str_size sSrcObjName_len;
	zval *oHandler;
	zval *oNewHandler;
	zval *oObj;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssO!", &sSrcObjName, &sSrcObjName_len, &sDestObjName, &sDestObjName_len, &oHandler, TElCustomDataStorageSecurityHandler_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_CopyObject(SBGetObjectHandle(getThis() TSRMLS_CC), sSrcObjName, (int32_t)sSrcObjName_len, sDestObjName, (int32_t)sDestObjName_len, SBGetObjectHandle(oHandler TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oObj, TElCustomDataStorageObject_ce_ptr, &oNewHandler, TElCustomDataStorageSecurityHandler_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElFileDataStorage_CopyObject_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), SBGetObjectHandle(oNewHandler TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, \\TElCustomDataStorageSecurityHandler) or (\\TElCustomDataStorageObject, \\TElCustomDataStorageSecurityHandler)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, DeleteObject)
{
	char *sObjName;
	sb_str_size sObjName_len;
	SBArrayZValInfo aiETag;
	TElClassHandle hoObj;
	zval *oObj;
	zval *zaETag;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sObjName, &sObjName_len) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_DeleteObject(SBGetObjectHandle(getThis() TSRMLS_CC), sObjName, (int32_t)sObjName_len) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sz", &sObjName, &sObjName_len, &zaETag) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaETag) || SB_IS_ARRAY_TYPE_RP(zaETag) || SB_IS_NULL_TYPE_RP(zaETag)))
	{
		if (!SBGetByteArrayFromZVal(zaETag, &aiETag TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElFileDataStorage_DeleteObject_1(SBGetObjectHandle(getThis() TSRMLS_CC), sObjName, (int32_t)sObjName_len, aiETag.data, aiETag.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiETag);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oObj, TElCustomDataStorageObject_ce_ptr) == SUCCESS) && SB_ISREF_OBJECT_P(oObj))
	{
		hoObj = SBGetObjectHandle(oObj TSRMLS_CC);
		SBCheckError(TElFileDataStorage_DeleteObject_2(SBGetObjectHandle(getThis() TSRMLS_CC), &hoObj) TSRMLS_CC);
		SBUpdateObjectHandle(oObj, hoObj TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string, array of byte|string|NULL) or (&\\TElCustomDataStorageObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, ObjectExists)
{
	char *sObjName;
	sb_str_size sObjName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sObjName, &sObjName_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElFileDataStorage_ObjectExists(SBGetObjectHandle(getThis() TSRMLS_CC), sObjName, (int32_t)sObjName_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, GetProtectionInfo)
{
	char *sObjName;
	sb_str_size sObjName_len;
	zval *oObj;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sObjName, &sObjName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElFileDataStorage_GetProtectionInfo(SBGetObjectHandle(getThis() TSRMLS_CC), sObjName, (int32_t)sObjName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageSecurityHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oObj, TElCustomDataStorageObject_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElFileDataStorage_GetProtectionInfo_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oObj TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomDataStorageSecurityHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (\\TElCustomDataStorageObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, get_DataFileExtension)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElFileDataStorage_get_DataFileExtension(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1946407155, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, set_DataFileExtension)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_set_DataFileExtension(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, get_Directory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElFileDataStorage_get_Directory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(197147386, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, set_Directory)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_set_Directory(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, get_EmbeddedMetadataMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElFileDataStorage_get_EmbeddedMetadataMode(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, set_EmbeddedMetadataMode)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_set_EmbeddedMetadataMode(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, get_FileSystemAdapter)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElFileDataStorage_get_FileSystemAdapter(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomFileSystemAdapter_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, set_FileSystemAdapter)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomFileSystemAdapter_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_set_FileSystemAdapter(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomFileSystemAdapter)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, get_MedataFileExtension)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElFileDataStorage_get_MedataFileExtension(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(84739464, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, set_MedataFileExtension)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_set_MedataFileExtension(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, get_Overwrite)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElFileDataStorage_get_Overwrite(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, set_Overwrite)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_set_Overwrite(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, get_PassthroughMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElFileDataStorage_get_PassthroughMode(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, set_PassthroughMode)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElFileDataStorage_set_PassthroughMode(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFileDataStorage, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElFileDataStorage_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_AcquireObject, 0, 0, 0)
	ZEND_ARG_INFO(0, ObjName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_WriteObject, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, ObjName_or_Obj, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data_or_Strm, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Handler_or_ETag, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElCustomDataStorageSecurityHandler, 1)
	ZEND_ARG_INFO(1, NewETag)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_WriteBlock, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, ObjName_or_Obj, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Strm, TStream, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElCustomDataStorageSecurityHandler, 1)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(1, Written)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_ReadObject, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, ObjName_or_Obj, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Strm, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ETag, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_CopyObject, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, SrcObjName_or_Obj, 0, 1)
	ZEND_ARG_TYPE_INFO(0, DestObjName_or_NewHandler, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElCustomDataStorageSecurityHandler, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_DeleteObject, 0, 0, 1)
	ZEND_ARG_INFO(1, ObjName_or_Obj)
	ZEND_ARG_TYPE_INFO(0, ETag, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_ObjectExists, 0, 0, 1)
	ZEND_ARG_INFO(0, ObjName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_GetProtectionInfo, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ObjName_or_Obj, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_get_DataFileExtension, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_set_DataFileExtension, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_get_Directory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_set_Directory, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_get_EmbeddedMetadataMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_set_EmbeddedMetadataMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_get_FileSystemAdapter, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_set_FileSystemAdapter, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomFileSystemAdapter, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_get_MedataFileExtension, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_set_MedataFileExtension, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_get_Overwrite, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_set_Overwrite, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_get_PassthroughMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage_set_PassthroughMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFileDataStorage___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElFileDataStorage_methods[] = {
	PHP_ME(TElFileDataStorage, AcquireObject, arginfo_TElFileDataStorage_AcquireObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, WriteObject, arginfo_TElFileDataStorage_WriteObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, WriteBlock, arginfo_TElFileDataStorage_WriteBlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, ReadObject, arginfo_TElFileDataStorage_ReadObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, CopyObject, arginfo_TElFileDataStorage_CopyObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, DeleteObject, arginfo_TElFileDataStorage_DeleteObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, ObjectExists, arginfo_TElFileDataStorage_ObjectExists, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, GetProtectionInfo, arginfo_TElFileDataStorage_GetProtectionInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, get_DataFileExtension, arginfo_TElFileDataStorage_get_DataFileExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, set_DataFileExtension, arginfo_TElFileDataStorage_set_DataFileExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, get_Directory, arginfo_TElFileDataStorage_get_Directory, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, set_Directory, arginfo_TElFileDataStorage_set_Directory, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, get_EmbeddedMetadataMode, arginfo_TElFileDataStorage_get_EmbeddedMetadataMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, set_EmbeddedMetadataMode, arginfo_TElFileDataStorage_set_EmbeddedMetadataMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, get_FileSystemAdapter, arginfo_TElFileDataStorage_get_FileSystemAdapter, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, set_FileSystemAdapter, arginfo_TElFileDataStorage_set_FileSystemAdapter, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, get_MedataFileExtension, arginfo_TElFileDataStorage_get_MedataFileExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, set_MedataFileExtension, arginfo_TElFileDataStorage_set_MedataFileExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, get_Overwrite, arginfo_TElFileDataStorage_get_Overwrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, set_Overwrite, arginfo_TElFileDataStorage_set_Overwrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, get_PassthroughMode, arginfo_TElFileDataStorage_get_PassthroughMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, set_PassthroughMode, arginfo_TElFileDataStorage_set_PassthroughMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElFileDataStorage, __construct, arginfo_TElFileDataStorage___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElFileDataStorage(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElFileDataStorage_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElFileDataStorage", TElFileDataStorage_methods);
	if (NULL == TElCustomDataStorage_ce_ptr)
		Register_TElCustomDataStorage(TSRMLS_C);
	TElFileDataStorage_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomDataStorage_ce_ptr);
}

SB_PHP_FUNCTION(SBFileDataStorage, ComposeETag)
{
	sb_zend_long l8Size;
	uint32_t _err;
	zval *dtModTime;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "Ol", &dtModTime, php_date_get_date_ce(), &l8Size) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBFileDataStorage_ComposeETag(SBGetDateTime(dtModTime TSRMLS_CC), (int64_t)l8Size, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1441170903, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime, integer)" TSRMLS_CC);
	}
}

void Register_SBFileDataStorage_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBFileDataStorageCondition", NULL);
	TSBFileDataStorageCondition_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBFileDataStorageCondition_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFileDataStorageCondition_ce_ptr, "fdscETag", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileDataStorageCondition_ce_ptr, "fdscModTime", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBFileDataStorageConditions", NULL);
	TSBFileDataStorageConditions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBFileDataStorageConditions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFileDataStorageConditions_ce_ptr, "fdscETag", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileDataStorageConditions_ce_ptr, "fdscModTime", 2)
}

