#include "sbhashfunction.h"

zend_class_entry *TElHMACKeyMaterial_ce_ptr = NULL;

SB_PHP_METHOD(TElHMACKeyMaterial, get_Key)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElHMACKeyMaterial_get_Key(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(529900884, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHMACKeyMaterial, set_Key)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHMACKeyMaterial_set_Key(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHMACKeyMaterial, get_Nonce)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElHMACKeyMaterial_get_Nonce(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1252546576, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHMACKeyMaterial, set_Nonce)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHMACKeyMaterial_set_Nonce(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHMACKeyMaterial, get_CryptoProvider)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHMACKeyMaterial_get_CryptoProvider(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoProvider_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHMACKeyMaterial, __construct)
{
	zval *oKey;
	zval *oManager;
	zval *oProv;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oProv, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHMACKeyMaterial_Create(SBGetObjectHandle(oProv TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oKey, TElCustomCryptoKey_ce_ptr, &oProv, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHMACKeyMaterial_Create_1(SBGetObjectHandle(oKey TSRMLS_CC), SBGetObjectHandle(oProv TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oManager, TElCustomCryptoProviderManager_ce_ptr, &oProv, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHMACKeyMaterial_Create_2(SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oProv TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oKey, TElCustomCryptoKey_ce_ptr, &oManager, TElCustomCryptoProviderManager_ce_ptr, &oProv, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHMACKeyMaterial_Create_3(SBGetObjectHandle(oKey TSRMLS_CC), SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oProv TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoProvider) or (\\TElCustomCryptoKey, \\TElCustomCryptoProvider) or (\\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider) or (\\TElCustomCryptoKey, \\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHMACKeyMaterial_get_Key, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHMACKeyMaterial_set_Key, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHMACKeyMaterial_get_Nonce, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHMACKeyMaterial_set_Nonce, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHMACKeyMaterial_get_CryptoProvider, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHMACKeyMaterial___construct, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Prov_or_Key_or_Manager, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Prov_or_Manager, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Prov, TElCustomCryptoProvider, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElHMACKeyMaterial_methods[] = {
	PHP_ME(TElHMACKeyMaterial, get_Key, arginfo_TElHMACKeyMaterial_get_Key, ZEND_ACC_PUBLIC)
	PHP_ME(TElHMACKeyMaterial, set_Key, arginfo_TElHMACKeyMaterial_set_Key, ZEND_ACC_PUBLIC)
	PHP_ME(TElHMACKeyMaterial, get_Nonce, arginfo_TElHMACKeyMaterial_get_Nonce, ZEND_ACC_PUBLIC)
	PHP_ME(TElHMACKeyMaterial, set_Nonce, arginfo_TElHMACKeyMaterial_set_Nonce, ZEND_ACC_PUBLIC)
	PHP_ME(TElHMACKeyMaterial, get_CryptoProvider, arginfo_TElHMACKeyMaterial_get_CryptoProvider, ZEND_ACC_PUBLIC)
	PHP_ME(TElHMACKeyMaterial, __construct, arginfo_TElHMACKeyMaterial___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElHMACKeyMaterial(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElHMACKeyMaterial_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElHMACKeyMaterial", TElHMACKeyMaterial_methods);
	if (NULL == TElKeyMaterial_ce_ptr)
		Register_TElKeyMaterial(TSRMLS_C);
	TElHMACKeyMaterial_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElKeyMaterial_ce_ptr);
}

zend_class_entry *TElHashFunction_ce_ptr = NULL;

SB_PHP_METHOD(TElHashFunction, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElHashFunction_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, Update)
{
	sb_zend_long l4Count;
	sb_zend_long l4Size;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	SBArrayZValInfo piBuffer;
	zval *zaBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_Update(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_Update_1(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Count) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_Update_2(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer) or (array of byte|string|NULL, integer, integer) or (array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, UpdateStream)
{
	sb_zend_long l8Count;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStream, TStream_ce_ptr, &l8Count) == SUCCESS)
	{
		SBCheckError(TElHashFunction_UpdateStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int64_t)l8Count) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, Finish)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElHashFunction_Finish(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-100778215, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, Clone)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHashFunction_Clone(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElHashFunction_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, IsAlgorithmSupported_Inst)
{
	sb_zend_long l4Algorithm;
	SBArrayZValInfo aiOID;
	zval *oCryptoProvider;
	zval *oManager;
	zval *zaOID;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Algorithm, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElHashFunction_IsAlgorithmSupported_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Algorithm, SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!", &zaOID, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_IsAlgorithmSupported_3(SBGetObjectHandle(getThis() TSRMLS_CC), aiOID.data, aiOID.len, SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!O!", &l4Algorithm, &oManager, TElCustomCryptoProviderManager_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElHashFunction_IsAlgorithmSupported_5(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Algorithm, SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!O!", &zaOID, &oManager, TElCustomCryptoProviderManager_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_IsAlgorithmSupported_7(SBGetObjectHandle(getThis() TSRMLS_CC), aiOID.data, aiOID.len, SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElCustomCryptoProvider) or (array of byte|string|NULL, \\TElCustomCryptoProvider) or (integer, \\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider) or (array of byte|string|NULL, \\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, IsAlgorithmSupported)
{
	sb_zend_long l4Algorithm;
	SBArrayZValInfo aiOID;
	zval *oCryptoProvider;
	zval *oManager;
	zval *zaOID;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Algorithm, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElHashFunction_IsAlgorithmSupported((int32_t)l4Algorithm, SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!", &zaOID, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_IsAlgorithmSupported_2(aiOID.data, aiOID.len, SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!O!", &l4Algorithm, &oManager, TElCustomCryptoProviderManager_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElHashFunction_IsAlgorithmSupported_4((int32_t)l4Algorithm, SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!O!", &zaOID, &oManager, TElCustomCryptoProviderManager_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_IsAlgorithmSupported_6(aiOID.data, aiOID.len, SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElCustomCryptoProvider) or (array of byte|string|NULL, \\TElCustomCryptoProvider) or (integer, \\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider) or (array of byte|string|NULL, \\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, GetDigestSizeBits_Inst)
{
	sb_zend_long l4Algorithm;
	SBArrayZValInfo aiOID;
	zval *oCryptoProvider;
	zval *oManager;
	zval *zaOID;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Algorithm, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHashFunction_GetDigestSizeBits_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Algorithm, SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!", &zaOID, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_GetDigestSizeBits_3(SBGetObjectHandle(getThis() TSRMLS_CC), aiOID.data, aiOID.len, SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!O!", &l4Algorithm, &oManager, TElCustomCryptoProviderManager_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHashFunction_GetDigestSizeBits_5(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Algorithm, SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!O!", &zaOID, &oManager, TElCustomCryptoProviderManager_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_GetDigestSizeBits_7(SBGetObjectHandle(getThis() TSRMLS_CC), aiOID.data, aiOID.len, SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElCustomCryptoProvider) or (array of byte|string|NULL, \\TElCustomCryptoProvider) or (integer, \\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider) or (array of byte|string|NULL, \\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, GetDigestSizeBits)
{
	sb_zend_long l4Algorithm;
	SBArrayZValInfo aiOID;
	zval *oCryptoProvider;
	zval *oManager;
	zval *zaOID;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Algorithm, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHashFunction_GetDigestSizeBits((int32_t)l4Algorithm, SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!", &zaOID, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_GetDigestSizeBits_2(aiOID.data, aiOID.len, SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!O!", &l4Algorithm, &oManager, TElCustomCryptoProviderManager_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHashFunction_GetDigestSizeBits_4((int32_t)l4Algorithm, SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!O!", &zaOID, &oManager, TElCustomCryptoProviderManager_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_GetDigestSizeBits_6(aiOID.data, aiOID.len, SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElCustomCryptoProvider) or (array of byte|string|NULL, \\TElCustomCryptoProvider) or (integer, \\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider) or (array of byte|string|NULL, \\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, Hash_Inst)
{
	sb_zend_long l4Algorithm;
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	uint32_t _err;
	zval *oKey;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &l4Algorithm, &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = TElHashFunction_Hash_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Algorithm, piBuffer.data, (int32_t)l4Size, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-571314624, 4, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piBuffer);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!zl", &l4Algorithm, &oKey, TElHMACKeyMaterial_ce_ptr, &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = TElHashFunction_Hash_3(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Algorithm, SBGetObjectHandle(oKey TSRMLS_CC), piBuffer.data, (int32_t)l4Size, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1076733756, 5, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piBuffer);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TSBPointer|array of byte|string|NULL, integer) or (integer, \\TElHMACKeyMaterial, \\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, Hash)
{
	sb_zend_long l4Algorithm;
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	uint32_t _err;
	zval *oKey;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &l4Algorithm, &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = TElHashFunction_Hash((int32_t)l4Algorithm, piBuffer.data, (int32_t)l4Size, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-571314624, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piBuffer);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!zl", &l4Algorithm, &oKey, TElHMACKeyMaterial_ce_ptr, &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = TElHashFunction_Hash_2((int32_t)l4Algorithm, SBGetObjectHandle(oKey TSRMLS_CC), piBuffer.data, (int32_t)l4Size, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1076733756, 4, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piBuffer);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TSBPointer|array of byte|string|NULL, integer) or (integer, \\TElHMACKeyMaterial, \\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, get_Algorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHashFunction_get_Algorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, get_CryptoProvider)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHashFunction_get_CryptoProvider(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoProvider_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, set_CryptoProvider)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElHashFunction_set_CryptoProvider(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoProvider)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, get_Key)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHashFunction_get_Key(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElHMACKeyMaterial_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, set_Key)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElHMACKeyMaterial_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElHashFunction_set_Key(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElHMACKeyMaterial)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, get_ShakeOutputLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHashFunction_get_ShakeOutputLength(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, set_ShakeOutputLength)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElHashFunction_set_ShakeOutputLength(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHashFunction, __construct)
{
	sb_zend_long l4Algorithm;
	SBArrayZValInfo aiOID;
	zval *oCryptoProvider;
	zval *oKey;
	zval *oManager;
	zval *oParameters;
	zval *zaOID;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Algorithm, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHashFunction_Create((int32_t)l4Algorithm, SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!", &zaOID, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_Create_1(aiOID.data, aiOID.len, SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!O!", &l4Algorithm, &oParameters, TElRelativeDistinguishedName_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHashFunction_Create_2((int32_t)l4Algorithm, SBGetObjectHandle(oParameters TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!O!", &zaOID, &oParameters, TElRelativeDistinguishedName_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_Create_3(aiOID.data, aiOID.len, SBGetObjectHandle(oParameters TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHashFunction_Create_4(SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Algorithm, &oKey, TElHMACKeyMaterial_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHashFunction_Create_5((int32_t)l4Algorithm, SBGetObjectHandle(oKey TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!", &zaOID, &oKey, TElHMACKeyMaterial_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_Create_6(aiOID.data, aiOID.len, SBGetObjectHandle(oKey TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!O!", &l4Algorithm, &oKey, TElHMACKeyMaterial_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHashFunction_Create_7((int32_t)l4Algorithm, SBGetObjectHandle(oKey TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!O!", &zaOID, &oKey, TElHMACKeyMaterial_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_Create_8(aiOID.data, aiOID.len, SBGetObjectHandle(oKey TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oManager, TElCustomCryptoProviderManager_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHashFunction_Create_9(SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!O!O!", &l4Algorithm, &oParameters, TElRelativeDistinguishedName_ce_ptr, &oManager, TElCustomCryptoProviderManager_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHashFunction_Create_10((int32_t)l4Algorithm, SBGetObjectHandle(oParameters TSRMLS_CC), SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!O!O!", &zaOID, &oParameters, TElRelativeDistinguishedName_ce_ptr, &oManager, TElCustomCryptoProviderManager_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_Create_11(aiOID.data, aiOID.len, SBGetObjectHandle(oParameters TSRMLS_CC), SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!O!O!", &l4Algorithm, &oKey, TElHMACKeyMaterial_ce_ptr, &oManager, TElCustomCryptoProviderManager_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHashFunction_Create_12((int32_t)l4Algorithm, SBGetObjectHandle(oKey TSRMLS_CC), SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zO!O!O!", &zaOID, &oKey, TElHMACKeyMaterial_ce_ptr, &oManager, TElCustomCryptoProviderManager_ce_ptr, &oCryptoProvider, TElCustomCryptoProvider_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHashFunction_Create_13(aiOID.data, aiOID.len, SBGetObjectHandle(oKey TSRMLS_CC), SBGetObjectHandle(oManager TSRMLS_CC), SBGetObjectHandle(oCryptoProvider TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOID);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElCustomCryptoProvider) or (array of byte|string|NULL, \\TElCustomCryptoProvider) or (integer, \\TElRelativeDistinguishedName, \\TElCustomCryptoProvider) or (array of byte|string|NULL, \\TElRelativeDistinguishedName, \\TElCustomCryptoProvider) or (\\TElCustomCryptoProvider) or (integer, \\TElHMACKeyMaterial) or (array of byte|string|NULL, \\TElHMACKeyMaterial) or (integer, \\TElHMACKeyMaterial, \\TElCustomCryptoProvider) or (array of byte|string|NULL, \\TElHMACKeyMaterial, \\TElCustomCryptoProvider) or (\\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider) or (integer, \\TElRelativeDistinguishedName, \\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider) or (array of byte|string|NULL, \\TElRelativeDistinguishedName, \\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider) or (integer, \\TElHMACKeyMaterial, \\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider) or (array of byte|string|NULL, \\TElHMACKeyMaterial, \\TElCustomCryptoProviderManager, \\TElCustomCryptoProvider)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_Update, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size_or_StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_UpdateStream, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_Finish, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_Clone, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_IsAlgorithmSupported_Inst, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Algorithm_or_OID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, CryptoProvider_or_Manager, 0, 1)
	ZEND_ARG_OBJ_INFO(0, CryptoProvider, TElCustomCryptoProvider, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_IsAlgorithmSupported, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Algorithm_or_OID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, CryptoProvider_or_Manager, 0, 1)
	ZEND_ARG_OBJ_INFO(0, CryptoProvider, TElCustomCryptoProvider, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_GetDigestSizeBits_Inst, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Algorithm_or_OID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, CryptoProvider_or_Manager, 0, 1)
	ZEND_ARG_OBJ_INFO(0, CryptoProvider, TElCustomCryptoProvider, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_GetDigestSizeBits, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Algorithm_or_OID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, CryptoProvider_or_Manager, 0, 1)
	ZEND_ARG_OBJ_INFO(0, CryptoProvider, TElCustomCryptoProvider, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_Hash_Inst, 0, 0, 3)
	ZEND_ARG_INFO(0, Algorithm)
	ZEND_ARG_TYPE_INFO(0, Buffer_or_Key, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Size_or_Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_Hash, 0, 0, 3)
	ZEND_ARG_INFO(0, Algorithm)
	ZEND_ARG_TYPE_INFO(0, Buffer_or_Key, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Size_or_Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_get_Algorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_get_CryptoProvider, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_set_CryptoProvider, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCryptoProvider, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_get_Key, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_set_Key, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElHMACKeyMaterial, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_get_ShakeOutputLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction_set_ShakeOutputLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHashFunction___construct, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Algorithm_or_OID_or_CryptoProvider_or_Manager, 0, 1)
	ZEND_ARG_TYPE_INFO(0, CryptoProvider_or_Parameters_or_Key, 0, 1)
	ZEND_ARG_TYPE_INFO(0, CryptoProvider_or_Manager, 0, 1)
	ZEND_ARG_OBJ_INFO(0, CryptoProvider, TElCustomCryptoProvider, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElHashFunction_methods[] = {
	PHP_ME(TElHashFunction, Reset, arginfo_TElHashFunction_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, Update, arginfo_TElHashFunction_Update, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, UpdateStream, arginfo_TElHashFunction_UpdateStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, Finish, arginfo_TElHashFunction_Finish, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, Clone, arginfo_TElHashFunction_Clone, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, IsAlgorithmSupported_Inst, arginfo_TElHashFunction_IsAlgorithmSupported_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, IsAlgorithmSupported, arginfo_TElHashFunction_IsAlgorithmSupported, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElHashFunction, GetDigestSizeBits_Inst, arginfo_TElHashFunction_GetDigestSizeBits_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, GetDigestSizeBits, arginfo_TElHashFunction_GetDigestSizeBits, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElHashFunction, Hash_Inst, arginfo_TElHashFunction_Hash_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, Hash, arginfo_TElHashFunction_Hash, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElHashFunction, get_Algorithm, arginfo_TElHashFunction_get_Algorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, get_CryptoProvider, arginfo_TElHashFunction_get_CryptoProvider, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, set_CryptoProvider, arginfo_TElHashFunction_set_CryptoProvider, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, get_Key, arginfo_TElHashFunction_get_Key, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, set_Key, arginfo_TElHashFunction_set_Key, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, get_ShakeOutputLength, arginfo_TElHashFunction_get_ShakeOutputLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, set_ShakeOutputLength, arginfo_TElHashFunction_set_ShakeOutputLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElHashFunction, __construct, arginfo_TElHashFunction___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElHashFunction(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElHashFunction_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElHashFunction", TElHashFunction_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElHashFunction_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

void Register_SBHashFunction_Aliases(TSRMLS_D)
{
	if (NULL == TElHMACKeyMaterial_ce_ptr)
		Register_TElHMACKeyMaterial(TSRMLS_C);
	zend_register_class_alias("ElHMACKeyMaterial", TElHMACKeyMaterial_ce_ptr);
	if (NULL == TElHashFunction_ce_ptr)
		Register_TElHashFunction(TSRMLS_C);
	zend_register_class_alias("ElHashFunction", TElHashFunction_ce_ptr);
}

