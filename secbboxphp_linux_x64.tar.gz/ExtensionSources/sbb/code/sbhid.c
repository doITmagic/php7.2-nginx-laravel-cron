#include "sbhid.h"

void SB_CALLBACK TSBHIDEnumerateDevicesProcRaw(void * _ObjectData, TElHIDDeviceInfoHandle DeviceInfo, int8_t * FreeDeviceInfoObject, int8_t * OutResult)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_INIT_PARAMS(2);
	zval * zDeviceInfo;
	zval * zFreeDeviceInfoObject;
	SB_EVENT_DECL_RETVAL_PTR(pzOutResult);
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zDeviceInfo, 0);
	SBInitObject(zDeviceInfo, TElHIDDeviceInfo_ce_ptr, DeviceInfo TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zFreeDeviceInfoObject, 1);
	ZVAL_BOOL(Z_REFVAL_P(zFreeDeviceInfoObject), (zend_bool)*FreeDeviceInfoObject);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(pzOutResult), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zDeviceInfo);
	convert_to_boolean(Z_REFVAL_P(zFreeDeviceInfoObject));
	*FreeDeviceInfoObject = (int8_t)SB_BVAL_P(Z_REFVAL_P(zFreeDeviceInfoObject));
	SB_EVENT_CLEAR_ZVAL(zFreeDeviceInfoObject);
	if (pzOutResult)
	{
		convert_to_boolean(pzOutResult);
		*OutResult = (int8_t)SB_BVAL_P(pzOutResult);
		SB_EVENT_CLEAR_ZVAL(pzOutResult);
	}
}

zend_class_entry *TElHIDDeviceInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElHIDDeviceInfo, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElHIDDeviceInfo_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, Clone)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHIDDeviceInfo_Clone(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElHIDDeviceInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, Init)
{
	char *sADevicePath;
	sb_str_size sADevicePath_len;
	zval *oDevice;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sADevicePath, &sADevicePath_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElHIDDeviceInfo_Init(SBGetObjectHandle(getThis() TSRMLS_CC), sADevicePath, (int32_t)sADevicePath_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sADevicePath, &sADevicePath_len, &oDevice, TObject_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElHIDDeviceInfo_Init_1(SBGetObjectHandle(getThis() TSRMLS_CC), sADevicePath, (int32_t)sADevicePath_len, SBGetObjectHandle(oDevice TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string, \\TObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, get_DevicePath)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElHIDDeviceInfo_get_DevicePath(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(268868636, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, get_Manufacturer)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElHIDDeviceInfo_get_Manufacturer(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-704765207, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, get_Product)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElHIDDeviceInfo_get_Product(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1628927797, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, get_SerialNumber)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElHIDDeviceInfo_get_SerialNumber(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1818020853, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, get_VendorID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElHIDDeviceInfo_get_VendorID(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, get_ProductID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElHIDDeviceInfo_get_ProductID(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, get_RevisionNumber)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElHIDDeviceInfo_get_RevisionNumber(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, get_Usage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElHIDDeviceInfo_get_Usage(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, get_UsagePage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElHIDDeviceInfo_get_UsagePage(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, get_InputReportByteLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElHIDDeviceInfo_get_InputReportByteLength(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, get_OutputReportByteLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElHIDDeviceInfo_get_OutputReportByteLength(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, get_FeatureReportByteLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElHIDDeviceInfo_get_FeatureReportByteLength(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHIDDeviceInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_Clone, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_Init, 0, 0, 1)
	ZEND_ARG_INFO(0, ADevicePath)
	ZEND_ARG_OBJ_INFO(0, Device, TObject, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_get_DevicePath, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_get_Manufacturer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_get_Product, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_get_SerialNumber, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_get_VendorID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_get_ProductID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_get_RevisionNumber, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_get_Usage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_get_UsagePage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_get_InputReportByteLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_get_OutputReportByteLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo_get_FeatureReportByteLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElHIDDeviceInfo_methods[] = {
	PHP_ME(TElHIDDeviceInfo, Clear, arginfo_TElHIDDeviceInfo_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, Clone, arginfo_TElHIDDeviceInfo_Clone, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, Init, arginfo_TElHIDDeviceInfo_Init, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, get_DevicePath, arginfo_TElHIDDeviceInfo_get_DevicePath, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, get_Manufacturer, arginfo_TElHIDDeviceInfo_get_Manufacturer, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, get_Product, arginfo_TElHIDDeviceInfo_get_Product, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, get_SerialNumber, arginfo_TElHIDDeviceInfo_get_SerialNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, get_VendorID, arginfo_TElHIDDeviceInfo_get_VendorID, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, get_ProductID, arginfo_TElHIDDeviceInfo_get_ProductID, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, get_RevisionNumber, arginfo_TElHIDDeviceInfo_get_RevisionNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, get_Usage, arginfo_TElHIDDeviceInfo_get_Usage, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, get_UsagePage, arginfo_TElHIDDeviceInfo_get_UsagePage, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, get_InputReportByteLength, arginfo_TElHIDDeviceInfo_get_InputReportByteLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, get_OutputReportByteLength, arginfo_TElHIDDeviceInfo_get_OutputReportByteLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, get_FeatureReportByteLength, arginfo_TElHIDDeviceInfo_get_FeatureReportByteLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfo, __construct, arginfo_TElHIDDeviceInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElHIDDeviceInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElHIDDeviceInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElHIDDeviceInfo", TElHIDDeviceInfo_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElHIDDeviceInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElHIDDeviceInfoList_ce_ptr = NULL;

SB_PHP_METHOD(TElHIDDeviceInfoList, Add)
{
	zval *oAInfo;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAInfo, TElHIDDeviceInfo_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHIDDeviceInfoList_Add(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oAInfo TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElHIDDeviceInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfoList, Insert)
{
	sb_zend_long l4Index;
	zval *oAInfo;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Index, &oAInfo, TElHIDDeviceInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElHIDDeviceInfoList_Insert(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, SBGetObjectHandle(oAInfo TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElHIDDeviceInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfoList, Delete)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElHIDDeviceInfoList_Delete(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfoList, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElHIDDeviceInfoList_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfoList, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHIDDeviceInfoList_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfoList, get_DeviceInfos)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHIDDeviceInfoList_get_DeviceInfos(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElHIDDeviceInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDeviceInfoList, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHIDDeviceInfoList_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfoList_Add, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AInfo, TElHIDDeviceInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfoList_Insert, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_OBJ_INFO(0, AInfo, TElHIDDeviceInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfoList_Delete, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfoList_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfoList_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfoList_get_DeviceInfos, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDeviceInfoList___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElHIDDeviceInfoList_methods[] = {
	PHP_ME(TElHIDDeviceInfoList, Add, arginfo_TElHIDDeviceInfoList_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfoList, Insert, arginfo_TElHIDDeviceInfoList_Insert, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfoList, Delete, arginfo_TElHIDDeviceInfoList_Delete, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfoList, Clear, arginfo_TElHIDDeviceInfoList_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfoList, get_Count, arginfo_TElHIDDeviceInfoList_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfoList, get_DeviceInfos, arginfo_TElHIDDeviceInfoList_get_DeviceInfos, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDeviceInfoList, __construct, arginfo_TElHIDDeviceInfoList___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElHIDDeviceInfoList(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElHIDDeviceInfoList_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElHIDDeviceInfoList", TElHIDDeviceInfoList_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElHIDDeviceInfoList_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElHIDDevice_ce_ptr = NULL;

SB_PHP_METHOD(TElHIDDevice, Open)
{
	char *sADevicePath;
	sb_str_size sADevicePath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sADevicePath, &sADevicePath_len) == SUCCESS)
	{
		SBCheckError(TElHIDDevice_Open(SBGetObjectHandle(getThis() TSRMLS_CC), sADevicePath, (int32_t)sADevicePath_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDevice, Close)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElHIDDevice_Close(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDevice, Read)
{
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHIDDevice_Read(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDevice, Write)
{
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHIDDevice_Write(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDevice, GetFeature)
{
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHIDDevice_GetFeature(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDevice, SetFeature)
{
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHIDDevice_SetFeature(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDevice, get_Info)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHIDDevice_get_Info(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElHIDDeviceInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDevice, get_Timeout)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHIDDevice_get_Timeout(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDevice, set_Timeout)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElHIDDevice_set_Timeout(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHIDDevice, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHIDDevice_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDevice_Open, 0, 0, 1)
	ZEND_ARG_INFO(0, ADevicePath)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDevice_Close, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDevice_Read, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDevice_Write, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDevice_GetFeature, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDevice_SetFeature, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDevice_get_Info, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDevice_get_Timeout, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDevice_set_Timeout, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHIDDevice___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElHIDDevice_methods[] = {
	PHP_ME(TElHIDDevice, Open, arginfo_TElHIDDevice_Open, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDevice, Close, arginfo_TElHIDDevice_Close, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDevice, Read, arginfo_TElHIDDevice_Read, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDevice, Write, arginfo_TElHIDDevice_Write, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDevice, GetFeature, arginfo_TElHIDDevice_GetFeature, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDevice, SetFeature, arginfo_TElHIDDevice_SetFeature, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDevice, get_Info, arginfo_TElHIDDevice_get_Info, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDevice, get_Timeout, arginfo_TElHIDDevice_get_Timeout, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDevice, set_Timeout, arginfo_TElHIDDevice_set_Timeout, ZEND_ACC_PUBLIC)
	PHP_ME(TElHIDDevice, __construct, arginfo_TElHIDDevice___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElHIDDevice(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElHIDDevice_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElHIDDevice", TElHIDDevice_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElHIDDevice_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

SB_PHP_FUNCTION(SBHID, HIDEnumerateDevices)
{
	void *pzEnumProc;
	zval *zEnumProc;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(SBHID_HIDEnumerateDevices(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElHIDDeviceInfoList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zEnumProc) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zEnumProc) || SB_IS_ARRAY_TYPE_RP(zEnumProc) || SB_IS_CALLABLE_TYPE_RP(zEnumProc) || SB_IS_NULL_TYPE_RP(zEnumProc)))
	{
		pzEnumProc = SBSetEventData(zEnumProc TSRMLS_CC);
		SBCheckError(SBHID_HIDEnumerateDevices_1(pzEnumProc ? &TSBHIDEnumerateDevicesProcRaw : NULL, pzEnumProc) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TSBHIDEnumerateDevicesProc|callable|NULL)" TSRMLS_CC);
	}
}

void Register_SBHID_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBHID, ERROR_FACILITY_HID, SB_ERROR_FACILITY_HID, SB_ERROR_FACILITY_HID);
	SB_REGISTER_LONG_CONSTANT(SBHID, ERROR_HID_ERROR_FLAG, SB_ERROR_HID_ERROR_FLAG, SB_ERROR_HID_ERROR_FLAG);
	SB_REGISTER_LONG_CONSTANT(SBHID, ERROR_HID_CORE_ERROR_FLAG, SB_ERROR_HID_CORE_ERROR_FLAG, SB_ERROR_HID_CORE_ERROR_FLAG);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_DEVICE_NOT_OPEN, SB_HID_ERROR_DEVICE_NOT_OPEN, SB_HID_ERROR_DEVICE_NOT_OPEN);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_DEVICE_WRITE_ONLY, SB_HID_ERROR_DEVICE_WRITE_ONLY, SB_HID_ERROR_DEVICE_WRITE_ONLY);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_DEVICE_READ_ONLY, SB_HID_ERROR_DEVICE_READ_ONLY, SB_HID_ERROR_DEVICE_READ_ONLY);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_FAILED_SET_INPUT_BUFNUM, SB_HID_ERROR_FAILED_SET_INPUT_BUFNUM, SB_HID_ERROR_FAILED_SET_INPUT_BUFNUM);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_INDEX_OUT_OF_BOUNDS, SB_HID_ERROR_INDEX_OUT_OF_BOUNDS, SB_HID_ERROR_INDEX_OUT_OF_BOUNDS);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_DEVICE_NO_FEATURE_REPORTS, SB_HID_ERROR_DEVICE_NO_FEATURE_REPORTS, SB_HID_ERROR_DEVICE_NO_FEATURE_REPORTS);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_INVALID_DEVICE_HANDLE, SB_HID_ERROR_INVALID_DEVICE_HANDLE, SB_HID_ERROR_INVALID_DEVICE_HANDLE);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_INVALID_DEVICE_OBJECT_CLASS, SB_HID_ERROR_INVALID_DEVICE_OBJECT_CLASS, SB_HID_ERROR_INVALID_DEVICE_OBJECT_CLASS);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_HID_LIBRARY_LOAD_FAILED, SB_HID_ERROR_HID_LIBRARY_LOAD_FAILED, SB_HID_ERROR_HID_LIBRARY_LOAD_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_SETUP_API_LIBRARY_LOAD_FAILED, SB_HID_ERROR_SETUP_API_LIBRARY_LOAD_FAILED, SB_HID_ERROR_SETUP_API_LIBRARY_LOAD_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_DEVICE_INTFS_ENUM_FAILED, SB_HID_ERROR_DEVICE_INTFS_ENUM_FAILED, SB_HID_ERROR_DEVICE_INTFS_ENUM_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_DEVICE_INTF_DETAIL_GET_FAILED, SB_HID_ERROR_DEVICE_INTF_DETAIL_GET_FAILED, SB_HID_ERROR_DEVICE_INTF_DETAIL_GET_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_UDEV_LIBRARY_LOAD_FAILED, SB_HID_ERROR_UDEV_LIBRARY_LOAD_FAILED, SB_HID_ERROR_UDEV_LIBRARY_LOAD_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_UDEV_INIT_FAILED, SB_HID_ERROR_UDEV_INIT_FAILED, SB_HID_ERROR_UDEV_INIT_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_UDEV_INIT_ENUM_FAILED, SB_HID_ERROR_UDEV_INIT_ENUM_FAILED, SB_HID_ERROR_UDEV_INIT_ENUM_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_UDEV_ADD_MATCH_SUBSYSTEM_FAILED, SB_HID_ERROR_UDEV_ADD_MATCH_SUBSYSTEM_FAILED, SB_HID_ERROR_UDEV_ADD_MATCH_SUBSYSTEM_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_UDEV_DEVICES_ENUM_FAILED, SB_HID_ERROR_UDEV_DEVICES_ENUM_FAILED, SB_HID_ERROR_UDEV_DEVICES_ENUM_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_IOKIT_LIBRARY_LOAD_FAILED, SB_HID_ERROR_IOKIT_LIBRARY_LOAD_FAILED, SB_HID_ERROR_IOKIT_LIBRARY_LOAD_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBHID, SB_HID_ERROR_IOKIT_INIT_FAILED, SB_HID_ERROR_IOKIT_INIT_FAILED, SB_HID_ERROR_IOKIT_INIT_FAILED);
	SB_REGISTER_STRING_CONSTANT(SBHID, SHIDInvalidDeviceObjectClass, SB_SHIDInvalidDeviceObjectClass, SB_SHIDInvalidDeviceObjectClass);
	SB_REGISTER_STRING_CONSTANT(SBHID, SHIDInvalidDeviceHandle, SB_SHIDInvalidDeviceHandle, SB_SHIDInvalidDeviceHandle);
}

void Register_SBHID_Aliases(TSRMLS_D)
{
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	zend_register_class_alias("TSBHIDDeviceObject", TObject_ce_ptr);
}

