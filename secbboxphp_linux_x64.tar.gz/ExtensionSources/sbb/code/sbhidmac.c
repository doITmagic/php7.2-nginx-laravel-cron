#include "sbdefs.h"

#ifdef MACOS
#include "sbhidmac.h"

SB_PHP_FUNCTION(SBHIDMac, HIDEnumerateDevices)
{
	void *pzEnumProc;
	zval *oList;
	zval *zEnumProc;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oList, TElHIDDeviceInfoList_ce_ptr, &zEnumProc) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zEnumProc) || SB_IS_ARRAY_TYPE_RP(zEnumProc) || SB_IS_CALLABLE_TYPE_RP(zEnumProc) || SB_IS_NULL_TYPE_RP(zEnumProc)))
	{
		pzEnumProc = SBSetEventData(zEnumProc TSRMLS_CC);
		SBCheckError(SBHIDMac_HIDEnumerateDevices(SBGetObjectHandle(oList TSRMLS_CC), pzEnumProc ? &TSBHIDEnumerateDevicesProcRaw : NULL, pzEnumProc) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElHIDDeviceInfoList, \\TSBHIDEnumerateDevicesProc|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, LoadIOHIDModule)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(SBHIDMac_LoadIOHIDModule() TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, UnloadIOHIDModule)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(SBHIDMac_UnloadIOHIDModule() TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, HIDOpenDevice)
{
	char *sPath;
	sb_str_size sPath_len;
	zend_bool bReadWriteAccess;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sb", &sPath, &sPath_len, &bReadWriteAccess) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(SBHIDMac_HIDOpenDevice(sPath, (int32_t)sPath_len, (int8_t)bReadWriteAccess, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, HIDCloseDevice)
{
	zval *oDevice;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDevice, TObject_ce_ptr) == SUCCESS)
	{
		SBCheckError(SBHIDMac_HIDCloseDevice(SBGetObjectHandle(oDevice TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, HIDReadTimeout)
{
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	sb_zend_long l4Timeout;
	SBArrayZValInfo aiBuffer;
	zval *oDevice;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zlll", &oDevice, TObject_ce_ptr, &zaBuffer, &l4StartIndex, &l4Count, &l4Timeout) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBHIDMac_HIDReadTimeout(SBGetObjectHandle(oDevice TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Count, (int32_t)l4Timeout, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject, array of byte|string|NULL, integer, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, HIDWriteTimeout)
{
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	sb_zend_long l4Timeout;
	SBArrayZValInfo aiBuffer;
	zval *oDevice;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zlll", &oDevice, TObject_ce_ptr, &zaBuffer, &l4StartIndex, &l4Count, &l4Timeout) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBHIDMac_HIDWriteTimeout(SBGetObjectHandle(oDevice TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Count, (int32_t)l4Timeout, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject, array of byte|string|NULL, integer, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, HIDIsInvalidDevice)
{
	zval *oDevice;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDevice, TObject_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBHIDMac_HIDIsInvalidDevice(SBGetObjectHandle(oDevice TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, HIDGetDeviceAttributes)
{
	uint16_t u2ProductIDRaw;
	uint16_t u2VendorIDRaw;
	uint16_t u2VersionNumberRaw;
	zval *oDevice;
	zval *zu2ProductID;
	zval *zu2VendorID;
	zval *zu2VersionNumber;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zzz", &oDevice, TObject_ce_ptr, &zu2VendorID, &zu2ProductID, &zu2VersionNumber) == SUCCESS) && Z_ISREF_P(zu2VendorID) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2VendorID))) && Z_ISREF_P(zu2ProductID) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2ProductID))) && Z_ISREF_P(zu2VersionNumber) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2VersionNumber))))
	{
		u2VendorIDRaw = (uint16_t)Z_LVAL_P(Z_REFVAL_P(zu2VendorID));
		u2ProductIDRaw = (uint16_t)Z_LVAL_P(Z_REFVAL_P(zu2ProductID));
		u2VersionNumberRaw = (uint16_t)Z_LVAL_P(Z_REFVAL_P(zu2VersionNumber));
		SBCheckError(SBHIDMac_HIDGetDeviceAttributes(SBGetObjectHandle(oDevice TSRMLS_CC), &u2VendorIDRaw, &u2ProductIDRaw, &u2VersionNumberRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zu2VendorID), (sb_zend_long)u2VendorIDRaw);
		ZVAL_LONG(Z_REFVAL_P(zu2ProductID), (sb_zend_long)u2ProductIDRaw);
		ZVAL_LONG(Z_REFVAL_P(zu2VersionNumber), (sb_zend_long)u2VersionNumberRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject, &integer, &integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, HIDGetDeviceSerialNumber)
{
	uint32_t _err;
	zval *oDevice;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDevice, TObject_ce_ptr) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBHIDMac_HIDGetDeviceSerialNumber(SBGetObjectHandle(oDevice TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1154692820, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, HIDGetDeviceManufacturer)
{
	uint32_t _err;
	zval *oDevice;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDevice, TObject_ce_ptr) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBHIDMac_HIDGetDeviceManufacturer(SBGetObjectHandle(oDevice TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1000123817, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, HIDGetDeviceProduct)
{
	uint32_t _err;
	zval *oDevice;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDevice, TObject_ce_ptr) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBHIDMac_HIDGetDeviceProduct(SBGetObjectHandle(oDevice TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1868686963, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, HIDGetDeviceIndexedString)
{
	sb_zend_long l4Index;
	uint32_t _err;
	zval *oDevice;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oDevice, TObject_ce_ptr, &l4Index) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBHIDMac_HIDGetDeviceIndexedString(SBGetObjectHandle(oDevice TSRMLS_CC), (int32_t)l4Index, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(877250908, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, HIDGetDeviceCapabilities)
{
	uint16_t u2FeatureReportByteLengthRaw;
	uint16_t u2InputReportByteLengthRaw;
	uint16_t u2OutputReportByteLengthRaw;
	uint16_t u2UsagePageRaw;
	uint16_t u2UsageRaw;
	zval *oDevice;
	zval *zu2FeatureReportByteLength;
	zval *zu2InputReportByteLength;
	zval *zu2OutputReportByteLength;
	zval *zu2Usage;
	zval *zu2UsagePage;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zzzzz", &oDevice, TObject_ce_ptr, &zu2Usage, &zu2UsagePage, &zu2InputReportByteLength, &zu2OutputReportByteLength, &zu2FeatureReportByteLength) == SUCCESS) && Z_ISREF_P(zu2Usage) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2Usage))) && Z_ISREF_P(zu2UsagePage) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2UsagePage))) && Z_ISREF_P(zu2InputReportByteLength) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2InputReportByteLength))) && Z_ISREF_P(zu2OutputReportByteLength) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2OutputReportByteLength))) && Z_ISREF_P(zu2FeatureReportByteLength) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2FeatureReportByteLength))))
	{
		u2UsageRaw = (uint16_t)Z_LVAL_P(Z_REFVAL_P(zu2Usage));
		u2UsagePageRaw = (uint16_t)Z_LVAL_P(Z_REFVAL_P(zu2UsagePage));
		u2InputReportByteLengthRaw = (uint16_t)Z_LVAL_P(Z_REFVAL_P(zu2InputReportByteLength));
		u2OutputReportByteLengthRaw = (uint16_t)Z_LVAL_P(Z_REFVAL_P(zu2OutputReportByteLength));
		u2FeatureReportByteLengthRaw = (uint16_t)Z_LVAL_P(Z_REFVAL_P(zu2FeatureReportByteLength));
		SBCheckError(SBHIDMac_HIDGetDeviceCapabilities(SBGetObjectHandle(oDevice TSRMLS_CC), &u2UsageRaw, &u2UsagePageRaw, &u2InputReportByteLengthRaw, &u2OutputReportByteLengthRaw, &u2FeatureReportByteLengthRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zu2Usage), (sb_zend_long)u2UsageRaw);
		ZVAL_LONG(Z_REFVAL_P(zu2UsagePage), (sb_zend_long)u2UsagePageRaw);
		ZVAL_LONG(Z_REFVAL_P(zu2InputReportByteLength), (sb_zend_long)u2InputReportByteLengthRaw);
		ZVAL_LONG(Z_REFVAL_P(zu2OutputReportByteLength), (sb_zend_long)u2OutputReportByteLengthRaw);
		ZVAL_LONG(Z_REFVAL_P(zu2FeatureReportByteLength), (sb_zend_long)u2FeatureReportByteLengthRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject, &integer, &integer, &integer, &integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, HIDGetDeviceFeature)
{
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	zval *oDevice;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zll", &oDevice, TObject_ce_ptr, &zaBuffer, &l4StartIndex, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBHIDMac_HIDGetDeviceFeature(SBGetObjectHandle(oDevice TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject, array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBHIDMac, HIDSetDeviceFeature)
{
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	zval *oDevice;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zll", &oDevice, TObject_ce_ptr, &zaBuffer, &l4StartIndex, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBHIDMac_HIDSetDeviceFeature(SBGetObjectHandle(oDevice TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject, array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}
#endif
