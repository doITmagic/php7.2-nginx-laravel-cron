#include "sbhttpswebdavclient.h"

zend_class_entry *TElHTTPSWebDAVClient_ce_ptr = NULL;

SB_PHP_METHOD(TElHTTPSWebDAVClient, PropFind)
{
	char *sURL;
	sb_str_size sURL_len;
	sb_zend_long fDepth;
	zend_bool bAll;
	zval *oProperties;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &sURL, &sURL_len, &fDepth) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_PropFind(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, (TSBWebDAVDepthRaw)fDepth, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!bl", &sURL, &sURL_len, &oProperties, TElWebDAVPropertyInfoList_ce_ptr, &bAll, &fDepth) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_PropFind_1(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, SBGetObjectHandle(oProperties TSRMLS_CC), (int8_t)bAll, (TSBWebDAVDepthRaw)fDepth, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer) or (string, \\TElWebDAVPropertyInfoList, bool, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, AddressBookReport)
{
	char *sURL;
	sb_str_size sURL_len;
	sb_zend_long fDepth;
	sb_zend_long l4Limit;
	zend_bool bAll;
	zval *oAddressDataProps;
	zval *oFilter;
	zval *oHrefs;
	zval *oProperties;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!O!O!lO!bl", &sURL, &sURL_len, &oProperties, TElWebDAVPropertyInfoList_ce_ptr, &oAddressDataProps, TElStringList_ce_ptr, &oFilter, TElCardDavFilter_ce_ptr, &l4Limit, &oHrefs, TElStringList_ce_ptr, &bAll, &fDepth) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_AddressBookReport(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, SBGetObjectHandle(oProperties TSRMLS_CC), SBGetObjectHandle(oAddressDataProps TSRMLS_CC), SBGetObjectHandle(oFilter TSRMLS_CC), (int32_t)l4Limit, SBGetObjectHandle(oHrefs TSRMLS_CC), (int8_t)bAll, (TSBWebDAVDepthRaw)fDepth, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElWebDAVPropertyInfoList, \\TElStringList, \\TElCardDavFilter, integer, \\TElStringList, bool, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, AclPrincipalPropSetReport)
{
	char *sURL;
	sb_str_size sURL_len;
	zval *oProperties;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sURL, &sURL_len, &oProperties, TElWebDAVPropertyInfoList_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_AclPrincipalPropSetReport(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, SBGetObjectHandle(oProperties TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElWebDAVPropertyInfoList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, AclPrincipalMatchReport)
{
	char *sURL;
	sb_str_size sURL_len;
	zval *oPrincipalProperty;
	zval *oProperties;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!O!", &sURL, &sURL_len, &oPrincipalProperty, TElWebDAVPropertyInfo_ce_ptr, &oProperties, TElWebDAVPropertyInfoList_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_AclPrincipalMatchReport(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, SBGetObjectHandle(oPrincipalProperty TSRMLS_CC), SBGetObjectHandle(oProperties TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElWebDAVPropertyInfo, \\TElWebDAVPropertyInfoList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, PrincipalSearchPropertySetReport)
{
	char *sURL;
	sb_str_size sURL_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sURL, &sURL_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_PrincipalSearchPropertySetReport(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, PrincipalPropertySearchReport)
{
	char *sURL;
	sb_str_size sURL_len;
	zend_bool bApplyToPrincipalCollectionSet;
	zval *oMatches;
	zval *oMatchProperties;
	zval *oProperties;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!O!O!b", &sURL, &sURL_len, &oMatchProperties, TElWebDAVPropertyInfoList_ce_ptr, &oMatches, TElStringList_ce_ptr, &oProperties, TElWebDAVPropertyInfoList_ce_ptr, &bApplyToPrincipalCollectionSet) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_PrincipalPropertySearchReport(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, SBGetObjectHandle(oMatchProperties TSRMLS_CC), SBGetObjectHandle(oMatches TSRMLS_CC), SBGetObjectHandle(oProperties TSRMLS_CC), (int8_t)bApplyToPrincipalCollectionSet, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElWebDAVPropertyInfoList, \\TElStringList, \\TElWebDAVPropertyInfoList, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, Acl)
{
	char *sURL;
	sb_str_size sURL_len;
	zval *oNewAcl;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sURL, &sURL_len, &oNewAcl, TElWebDAVACL_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_Acl(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, SBGetObjectHandle(oNewAcl TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElWebDAVACL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, PropPatch)
{
	char *sIfHeader;
	char *sURL;
	sb_str_size sIfHeader_len;
	sb_str_size sURL_len;
	zval *oRemoveProperties;
	zval *oSetProperties;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!O!s", &sURL, &sURL_len, &oSetProperties, TElWebDAVPropertyInfoList_ce_ptr, &oRemoveProperties, TElWebDAVPropertyInfoList_ce_ptr, &sIfHeader, &sIfHeader_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_PropPatch(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, SBGetObjectHandle(oSetProperties TSRMLS_CC), SBGetObjectHandle(oRemoveProperties TSRMLS_CC), sIfHeader, (int32_t)sIfHeader_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElWebDAVPropertyInfoList, \\TElWebDAVPropertyInfoList, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, MkCol)
{
	char *sIfHeader;
	char *sURL;
	sb_str_size sIfHeader_len;
	sb_str_size sURL_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sURL, &sURL_len, &sIfHeader, &sIfHeader_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_MkCol(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, sIfHeader, (int32_t)sIfHeader_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, MkColEx)
{
	char *sDescription;
	char *sDisplayName;
	char *sIfHeader;
	char *sLang;
	char *sURL;
	sb_str_size sDescription_len;
	sb_str_size sDisplayName_len;
	sb_str_size sIfHeader_len;
	sb_str_size sLang_len;
	sb_str_size sURL_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sssss", &sURL, &sURL_len, &sDisplayName, &sDisplayName_len, &sDescription, &sDescription_len, &sLang, &sLang_len, &sIfHeader, &sIfHeader_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_MkColEx(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, sDisplayName, (int32_t)sDisplayName_len, sDescription, (int32_t)sDescription_len, sLang, (int32_t)sLang_len, sIfHeader, (int32_t)sIfHeader_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, string, string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, Copy)
{
	char *sDestURL;
	char *sIfHeader;
	char *sSrcURL;
	sb_str_size sDestURL_len;
	sb_str_size sIfHeader_len;
	sb_str_size sSrcURL_len;
	sb_zend_long fDepth;
	zend_bool bIncludeDepth;
	zend_bool bOverwrite;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sslbbs", &sSrcURL, &sSrcURL_len, &sDestURL, &sDestURL_len, &fDepth, &bOverwrite, &bIncludeDepth, &sIfHeader, &sIfHeader_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_Copy(SBGetObjectHandle(getThis() TSRMLS_CC), sSrcURL, (int32_t)sSrcURL_len, sDestURL, (int32_t)sDestURL_len, (TSBWebDAVDepthRaw)fDepth, (int8_t)bOverwrite, (int8_t)bIncludeDepth, sIfHeader, (int32_t)sIfHeader_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, integer, bool, bool, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, Move)
{
	char *sDestURL;
	char *sIfHeader;
	char *sSrcURL;
	sb_str_size sDestURL_len;
	sb_str_size sIfHeader_len;
	sb_str_size sSrcURL_len;
	sb_zend_long fDepth;
	zend_bool bOverwrite;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sslbs", &sSrcURL, &sSrcURL_len, &sDestURL, &sDestURL_len, &fDepth, &bOverwrite, &sIfHeader, &sIfHeader_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_Move(SBGetObjectHandle(getThis() TSRMLS_CC), sSrcURL, (int32_t)sSrcURL_len, sDestURL, (int32_t)sDestURL_len, (TSBWebDAVDepthRaw)fDepth, (int8_t)bOverwrite, sIfHeader, (int32_t)sIfHeader_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, integer, bool, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, Lock)
{
	char *sIfHeader;
	char *sOwner;
	char *sURL;
	sb_str_size sIfHeader_len;
	sb_str_size sOwner_len;
	sb_str_size sURL_len;
	sb_zend_long fDepth;
	sb_zend_long fScope;
	sb_zend_long l4Timeout;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssslll", &sURL, &sURL_len, &sIfHeader, &sIfHeader_len, &sOwner, &sOwner_len, &fScope, &fDepth, &l4Timeout) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_Lock(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, sIfHeader, (int32_t)sIfHeader_len, sOwner, (int32_t)sOwner_len, (TSBWebDAVLockScopeRaw)fScope, (TSBWebDAVDepthRaw)fDepth, (int32_t)l4Timeout, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, string, integer, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, Unlock)
{
	char *sToken;
	char *sURL;
	sb_str_size sToken_len;
	sb_str_size sURL_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sURL, &sURL_len, &sToken, &sToken_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_Unlock(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, sToken, (int32_t)sToken_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, Delete)
{
	char *sIfHeader;
	char *sURL;
	sb_str_size sIfHeader_len;
	sb_str_size sURL_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sURL, &sURL_len, &sIfHeader, &sIfHeader_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_Delete(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, sIfHeader, (int32_t)sIfHeader_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sURL, &sURL_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_Delete_1(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string) or (string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, Put)
{
	char *sContent;
	char *sIfHeader;
	char *sURL;
	sb_str_size sContent_len;
	sb_str_size sIfHeader_len;
	sb_str_size sURL_len;
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	sb_zend_long l8ContentLength;
	SBArrayZValInfo aiContent;
	zend_bool bCloseStream;
	zval *oContent;
	zval *zaContent;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sss", &sURL, &sURL_len, &sContent, &sContent_len, &sIfHeader, &sIfHeader_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_Put(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, sContent, (int32_t)sContent_len, sIfHeader, (int32_t)sIfHeader_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szs", &sURL, &sURL_len, &zaContent, &sIfHeader, &sIfHeader_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContent) || SB_IS_ARRAY_TYPE_RP(zaContent) || SB_IS_NULL_TYPE_RP(zaContent)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaContent, &aiContent TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHTTPSWebDAVClient_Put_1(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, aiContent.data, aiContent.len, sIfHeader, (int32_t)sIfHeader_len, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContent);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szlls", &sURL, &sURL_len, &zaContent, &l4StartIndex, &l4Count, &sIfHeader, &sIfHeader_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContent) || SB_IS_ARRAY_TYPE_RP(zaContent) || SB_IS_NULL_TYPE_RP(zaContent)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaContent, &aiContent TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHTTPSWebDAVClient_Put_2(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, aiContent.data, aiContent.len, (int32_t)l4StartIndex, (int32_t)l4Count, sIfHeader, (int32_t)sIfHeader_len, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContent);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!bs", &sURL, &sURL_len, &oContent, TStream_ce_ptr, &bCloseStream, &sIfHeader, &sIfHeader_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_Put_3(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, SBGetObjectHandle(oContent TSRMLS_CC), (int8_t)bCloseStream, sIfHeader, (int32_t)sIfHeader_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sURL, &sURL_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_Put_4(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &sURL, &sURL_len, &l8ContentLength) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_Put_5(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, (int64_t)l8ContentLength, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sURL, &sURL_len, &sContent, &sContent_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_Put_6(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, sContent, (int32_t)sContent_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sz", &sURL, &sURL_len, &zaContent) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContent) || SB_IS_ARRAY_TYPE_RP(zaContent) || SB_IS_NULL_TYPE_RP(zaContent)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaContent, &aiContent TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHTTPSWebDAVClient_Put_7(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, aiContent.data, aiContent.len, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContent);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szll", &sURL, &sURL_len, &zaContent, &l4StartIndex, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaContent) || SB_IS_ARRAY_TYPE_RP(zaContent) || SB_IS_NULL_TYPE_RP(zaContent)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaContent, &aiContent TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElHTTPSWebDAVClient_Put_8(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, aiContent.data, aiContent.len, (int32_t)l4StartIndex, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiContent);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!b", &sURL, &sURL_len, &oContent, TStream_ce_ptr, &bCloseStream) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElHTTPSWebDAVClient_Put_9(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len, SBGetObjectHandle(oContent TSRMLS_CC), (int8_t)bCloseStream, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, string) or (string, array of byte|string|NULL, string) or (string, array of byte|string|NULL, integer, integer, string) or (string, \\TStream, bool, string) or (string) or (string, integer) or (string, string) or (string, array of byte|string|NULL) or (string, array of byte|string|NULL, integer, integer) or (string, \\TStream, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHTTPSWebDAVClient, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHTTPSWebDAVClient_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_PropFind, 0, 0, 2)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_TYPE_INFO(0, Depth_or_Properties, 0, 1)
	ZEND_ARG_INFO(0, All)
	ZEND_ARG_INFO(0, Depth)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_AddressBookReport, 0, 0, 8)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_OBJ_INFO(0, Properties, TElWebDAVPropertyInfoList, 1)
	ZEND_ARG_OBJ_INFO(0, AddressDataProps, TElStringList, 1)
	ZEND_ARG_OBJ_INFO(0, Filter, TElCardDavFilter, 1)
	ZEND_ARG_INFO(0, Limit)
	ZEND_ARG_OBJ_INFO(0, Hrefs, TElStringList, 1)
	ZEND_ARG_INFO(0, All)
	ZEND_ARG_INFO(0, Depth)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_AclPrincipalPropSetReport, 0, 0, 2)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_OBJ_INFO(0, Properties, TElWebDAVPropertyInfoList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_AclPrincipalMatchReport, 0, 0, 3)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_OBJ_INFO(0, PrincipalProperty, TElWebDAVPropertyInfo, 1)
	ZEND_ARG_OBJ_INFO(0, Properties, TElWebDAVPropertyInfoList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_PrincipalSearchPropertySetReport, 0, 0, 1)
	ZEND_ARG_INFO(0, URL)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_PrincipalPropertySearchReport, 0, 0, 5)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_OBJ_INFO(0, MatchProperties, TElWebDAVPropertyInfoList, 1)
	ZEND_ARG_OBJ_INFO(0, Matches, TElStringList, 1)
	ZEND_ARG_OBJ_INFO(0, Properties, TElWebDAVPropertyInfoList, 1)
	ZEND_ARG_INFO(0, ApplyToPrincipalCollectionSet)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_Acl, 0, 0, 2)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_OBJ_INFO(0, NewAcl, TElWebDAVACL, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_PropPatch, 0, 0, 4)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_OBJ_INFO(0, SetProperties, TElWebDAVPropertyInfoList, 1)
	ZEND_ARG_OBJ_INFO(0, RemoveProperties, TElWebDAVPropertyInfoList, 1)
	ZEND_ARG_INFO(0, IfHeader)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_MkCol, 0, 0, 2)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_INFO(0, IfHeader)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_MkColEx, 0, 0, 5)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_INFO(0, DisplayName)
	ZEND_ARG_INFO(0, Description)
	ZEND_ARG_INFO(0, Lang)
	ZEND_ARG_INFO(0, IfHeader)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_Copy, 0, 0, 6)
	ZEND_ARG_INFO(0, SrcURL)
	ZEND_ARG_INFO(0, DestURL)
	ZEND_ARG_INFO(0, Depth)
	ZEND_ARG_INFO(0, Overwrite)
	ZEND_ARG_INFO(0, IncludeDepth)
	ZEND_ARG_INFO(0, IfHeader)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_Move, 0, 0, 5)
	ZEND_ARG_INFO(0, SrcURL)
	ZEND_ARG_INFO(0, DestURL)
	ZEND_ARG_INFO(0, Depth)
	ZEND_ARG_INFO(0, Overwrite)
	ZEND_ARG_INFO(0, IfHeader)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_Lock, 0, 0, 6)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_INFO(0, IfHeader)
	ZEND_ARG_INFO(0, Owner)
	ZEND_ARG_INFO(0, Scope)
	ZEND_ARG_INFO(0, Depth)
	ZEND_ARG_INFO(0, Timeout)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_Unlock, 0, 0, 2)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_INFO(0, Token)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_Delete, 0, 0, 1)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_INFO(0, IfHeader)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient_Put, 0, 0, 1)
	ZEND_ARG_INFO(0, URL)
	ZEND_ARG_TYPE_INFO(0, Content_or_ContentLength, 0, 1)
	ZEND_ARG_INFO(0, IfHeader_or_StartIndex_or_CloseStream)
	ZEND_ARG_INFO(0, Count_or_IfHeader)
	ZEND_ARG_INFO(0, IfHeader)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHTTPSWebDAVClient___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElHTTPSWebDAVClient_methods[] = {
	PHP_ME(TElHTTPSWebDAVClient, PropFind, arginfo_TElHTTPSWebDAVClient_PropFind, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, AddressBookReport, arginfo_TElHTTPSWebDAVClient_AddressBookReport, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, AclPrincipalPropSetReport, arginfo_TElHTTPSWebDAVClient_AclPrincipalPropSetReport, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, AclPrincipalMatchReport, arginfo_TElHTTPSWebDAVClient_AclPrincipalMatchReport, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, PrincipalSearchPropertySetReport, arginfo_TElHTTPSWebDAVClient_PrincipalSearchPropertySetReport, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, PrincipalPropertySearchReport, arginfo_TElHTTPSWebDAVClient_PrincipalPropertySearchReport, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, Acl, arginfo_TElHTTPSWebDAVClient_Acl, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, PropPatch, arginfo_TElHTTPSWebDAVClient_PropPatch, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, MkCol, arginfo_TElHTTPSWebDAVClient_MkCol, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, MkColEx, arginfo_TElHTTPSWebDAVClient_MkColEx, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, Copy, arginfo_TElHTTPSWebDAVClient_Copy, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, Move, arginfo_TElHTTPSWebDAVClient_Move, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, Lock, arginfo_TElHTTPSWebDAVClient_Lock, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, Unlock, arginfo_TElHTTPSWebDAVClient_Unlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, Delete, arginfo_TElHTTPSWebDAVClient_Delete, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, Put, arginfo_TElHTTPSWebDAVClient_Put, ZEND_ACC_PUBLIC)
	PHP_ME(TElHTTPSWebDAVClient, __construct, arginfo_TElHTTPSWebDAVClient___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElHTTPSWebDAVClient(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElHTTPSWebDAVClient_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElHTTPSWebDAVClient", TElHTTPSWebDAVClient_methods);
	if (NULL == TElHTTPSClient_ce_ptr)
		Register_TElHTTPSClient(TSRMLS_C);
	TElHTTPSWebDAVClient_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElHTTPSClient_ce_ptr);
}

void Register_SBHTTPSWebDAVClient_Aliases(TSRMLS_D)
{
	if (NULL == TElHTTPSWebDAVClient_ce_ptr)
		Register_TElHTTPSWebDAVClient(TSRMLS_C);
	zend_register_class_alias("ElHTTPSWebDAVClient", TElHTTPSWebDAVClient_ce_ptr);
}

