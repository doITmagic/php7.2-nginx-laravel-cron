#include "sbjson.h"

zend_class_entry *TSBJsonType_ce_ptr = NULL;

zend_class_entry *TElJsonEntity_ce_ptr = NULL;

SB_PHP_METHOD(TElJsonEntity, Read_Inst)
{
	char *sText;
	sb_str_size sText_len;
	sb_zend_long l4Length;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sText, &sText_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonEntity_Read_1(SBGetObjectHandle(getThis() TSRMLS_CC), sText, (int32_t)sText_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonEntity_Read_3(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Length) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonEntity_Read_5(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Length, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (array of byte|string|NULL) or (array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonEntity, Read)
{
	char *sText;
	sb_str_size sText_len;
	sb_zend_long l4Length;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sText, &sText_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonEntity_Read(sText, (int32_t)sText_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonEntity_Read_2(aiBuffer.data, aiBuffer.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Length) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonEntity_Read_4(aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Length, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (array of byte|string|NULL) or (array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonEntity, Write)
{
	char *cIndentChar;
	sb_str_size cIndentChar_len;
	sb_zend_long l4CharsPerIndentLevel;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	uint32_t _err;
	zval *oStream;
	zval *zaBuffer;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonEntity_Write(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(755906151, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &cIndentChar, &cIndentChar_len, &l4CharsPerIndentLevel) == SUCCESS) && (1 == cIndentChar_len))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonEntity_Write_1(SBGetObjectHandle(getThis() TSRMLS_CC), cIndentChar[0], (int32_t)l4CharsPerIndentLevel, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-622701096, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaBuffer, &l4StartIndex) == SUCCESS) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = TElJsonEntity_Write_2(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, &aiBuffer.len, (int32_t)l4StartIndex, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-275891617, 1, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "slzl", &cIndentChar, &cIndentChar_len, &l4CharsPerIndentLevel, &zaBuffer, &l4StartIndex) == SUCCESS) && (1 == cIndentChar_len) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = TElJsonEntity_Write_3(SBGetObjectHandle(getThis() TSRMLS_CC), cIndentChar[0], (int32_t)l4CharsPerIndentLevel, aiBuffer.data, &aiBuffer.len, (int32_t)l4StartIndex, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-844348557, 3, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonEntity_Write_4(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "slO!", &cIndentChar, &cIndentChar_len, &l4CharsPerIndentLevel, &oStream, TStream_ce_ptr) == SUCCESS) && (1 == cIndentChar_len))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonEntity_Write_5(SBGetObjectHandle(getThis() TSRMLS_CC), cIndentChar[0], (int32_t)l4CharsPerIndentLevel, SBGetObjectHandle(oStream TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (char, integer) or (&array of byte|string, integer) or (char, integer, &array of byte|string, integer) or (\\TStream) or (char, integer, \\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonEntity, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElJsonEntity_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonEntity, Clone)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonEntity_Clone(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonEntity, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonEntity_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonEntity_Read_Inst, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Text_or_Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Length)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonEntity_Read, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Text_or_Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Length)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonEntity_Write, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(1, IndentChar_or_Buffer_or_Stream, 0, 1)
	ZEND_ARG_INFO(0, CharsPerIndentLevel_or_StartIndex)
	ZEND_ARG_TYPE_INFO(1, Buffer_or_Stream, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonEntity_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonEntity_Clone, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonEntity___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElJsonEntity_methods[] = {
	PHP_ME(TElJsonEntity, Read_Inst, arginfo_TElJsonEntity_Read_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonEntity, Read, arginfo_TElJsonEntity_Read, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElJsonEntity, Write, arginfo_TElJsonEntity_Write, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonEntity, Assign, arginfo_TElJsonEntity_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonEntity, Clone, arginfo_TElJsonEntity_Clone, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonEntity, __construct, arginfo_TElJsonEntity___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElJsonEntity(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElJsonEntity_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElJsonEntity", TElJsonEntity_methods);
	if (NULL == TPersistent_ce_ptr)
		Register_TPersistent(TSRMLS_C);
	TElJsonEntity_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPersistent_ce_ptr);
}

zend_class_entry *TElJsonArray_ce_ptr = NULL;

SB_PHP_METHOD(TElJsonArray, Read_Inst)
{
	char *sText;
	sb_str_size sText_len;
	sb_zend_long l4Length;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sText, &sText_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonArray_Read_1(SBGetObjectHandle(getThis() TSRMLS_CC), sText, (int32_t)sText_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonArray_Read_3(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Length) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonArray_Read_5(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Length, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (array of byte|string|NULL) or (array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, Read)
{
	char *sText;
	sb_str_size sText_len;
	sb_zend_long l4Length;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sText, &sText_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonArray_Read(sText, (int32_t)sText_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonArray_Read_2(aiBuffer.data, aiBuffer.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Length) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonArray_Read_4(aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Length, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (array of byte|string|NULL) or (array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, Write)
{
	char *cIndentChar;
	sb_str_size cIndentChar_len;
	sb_zend_long l4CharsPerIndentLevel;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	uint32_t _err;
	zval *oStream;
	zval *zaBuffer;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonArray_Write(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(755906151, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &cIndentChar, &cIndentChar_len, &l4CharsPerIndentLevel) == SUCCESS) && (1 == cIndentChar_len))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonArray_Write_1(SBGetObjectHandle(getThis() TSRMLS_CC), cIndentChar[0], (int32_t)l4CharsPerIndentLevel, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-622701096, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaBuffer, &l4StartIndex) == SUCCESS) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = TElJsonArray_Write_2(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, &aiBuffer.len, (int32_t)l4StartIndex, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-275891617, 1, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "slzl", &cIndentChar, &cIndentChar_len, &l4CharsPerIndentLevel, &zaBuffer, &l4StartIndex) == SUCCESS) && (1 == cIndentChar_len) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = TElJsonArray_Write_3(SBGetObjectHandle(getThis() TSRMLS_CC), cIndentChar[0], (int32_t)l4CharsPerIndentLevel, aiBuffer.data, &aiBuffer.len, (int32_t)l4StartIndex, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-844348557, 3, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonArray_Write_4(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "slO!", &cIndentChar, &cIndentChar_len, &l4CharsPerIndentLevel, &oStream, TStream_ce_ptr) == SUCCESS) && (1 == cIndentChar_len))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonArray_Write_5(SBGetObjectHandle(getThis() TSRMLS_CC), cIndentChar[0], (int32_t)l4CharsPerIndentLevel, SBGetObjectHandle(oStream TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (char, integer) or (&array of byte|string, integer) or (char, integer, &array of byte|string, integer) or (\\TStream) or (char, integer, \\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElJsonArray_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, Clone)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonArray_Clone(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, AssignStringList)
{
	zval *oValues;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValues, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElJsonArray_AssignStringList(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValues TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, Append)
{
	char *sValue;
	double dValue;
	sb_str_size sValue_len;
	sb_zend_long l4Value;
	zend_bool bValue;
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElJsonEntity_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonArray_Append(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonArray_Append_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "d", &dValue) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonArray_Append_2(SBGetObjectHandle(getThis() TSRMLS_CC), (double)dValue, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonArray_Append_3(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonArray_Append_4(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonArray_Append_5(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElJsonEntity) or (integer) or (double) or (bool) or (string) or ()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElJsonArray_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, Delete)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElJsonArray_Delete(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, GetArray)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonArray_GetArray(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonArray_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, GetArrayIfExists)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonArray_GetArrayIfExists(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonArray_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, GetBooleanValue)
{
	sb_zend_long l4Index;
	zend_bool bDefault;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonArray_GetBooleanValue(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &l4Index, &bDefault) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonArray_GetBooleanValue_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (int8_t)bDefault, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer) or (integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, GetDoubleValue)
{
	double dDefault;
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElJsonArray_GetDoubleValue(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ld", &l4Index, &dDefault) == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElJsonArray_GetDoubleValue_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (double)dDefault, &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("(integer) or (integer, double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, GetIntegerValue)
{
	sb_zend_long l4Index;
	sb_zend_long l8Default;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElJsonArray_GetIntegerValue(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4Index, &l8Default) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElJsonArray_GetIntegerValue_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (int64_t)l8Default, &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer) or (integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, GetObject)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonArray_GetObject(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, GetObjectIfExists)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonArray_GetObjectIfExists(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, GetStringValue)
{
	char *sDefault;
	sb_str_size sDefault_len;
	sb_zend_long l4Index;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonArray_GetStringValue(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1166726195, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ls", &l4Index, &sDefault, &sDefault_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonArray_GetStringValue_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, sDefault, (int32_t)sDefault_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1190904774, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer) or (integer, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, Insert)
{
	char *sValue;
	double dValue;
	sb_str_size sValue_len;
	sb_zend_long l4Index;
	sb_zend_long l4Value;
	zend_bool bValue;
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Index, &oValue, TElJsonEntity_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElJsonArray_Insert(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4Index, &l4Value) == SUCCESS)
	{
		SBCheckError(TElJsonArray_Insert_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (int32_t)l4Value) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ld", &l4Index, &dValue) == SUCCESS)
	{
		SBCheckError(TElJsonArray_Insert_2(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (double)dValue) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &l4Index, &bValue) == SUCCESS)
	{
		SBCheckError(TElJsonArray_Insert_3(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (int8_t)bValue) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ls", &l4Index, &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElJsonArray_Insert_4(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElJsonArray_Insert_5(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElJsonEntity) or (integer, integer) or (integer, double) or (integer, bool) or (integer, string) or (integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, IsNullValue)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonArray_IsNullValue(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, SetBooleanValue)
{
	sb_zend_long l4Index;
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &l4Index, &bValue) == SUCCESS)
	{
		SBCheckError(TElJsonArray_SetBooleanValue(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, SetDoubleValue)
{
	double dValue;
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ld", &l4Index, &dValue) == SUCCESS)
	{
		SBCheckError(TElJsonArray_SetDoubleValue(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (double)dValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, SetIntegerValue)
{
	sb_zend_long l4Index;
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4Index, &l8Value) == SUCCESS)
	{
		SBCheckError(TElJsonArray_SetIntegerValue(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, SetNullValue)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElJsonArray_SetNullValue(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, SetStringValue)
{
	char *sValue;
	sb_str_size sValue_len;
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ls", &l4Index, &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElJsonArray_SetStringValue(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, get_Item)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonArray_get_Item(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, set_Item)
{
	sb_zend_long l4Index;
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Index, &oValue, TElJsonEntity_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElJsonArray_set_Item(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElJsonEntity)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, get_Length)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonArray_get_Length(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, set_Length)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElJsonArray_set_Length(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, get_OwnsItems)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonArray_get_OwnsItems(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonArray, __construct)
{
	zend_bool bOwnsItems;
	zval *oOriginal;
	zval *oValues;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bOwnsItems) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonArray_Create((int8_t)bOwnsItems, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOriginal, TElJsonArray_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonArray_Create_1(SBGetObjectHandle(oOriginal TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValues, TElStringList_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonArray_Create_2(SBGetObjectHandle(oValues TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool) or (\\TElJsonArray) or (\\TElStringList)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_Read_Inst, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Text_or_Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Length)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_Read, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Text_or_Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Length)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_Write, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(1, IndentChar_or_Buffer_or_Stream, 0, 1)
	ZEND_ARG_INFO(0, CharsPerIndentLevel_or_StartIndex)
	ZEND_ARG_TYPE_INFO(1, Buffer_or_Stream, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_Clone, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_AssignStringList, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Values, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_Append, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_Delete, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_GetArray, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_GetArrayIfExists, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_GetBooleanValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_GetDoubleValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_GetIntegerValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_GetObject, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_GetObjectIfExists, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_GetStringValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_Insert, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_IsNullValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_SetBooleanValue, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_SetDoubleValue, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_SetIntegerValue, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_SetNullValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_SetStringValue, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_get_Item, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_set_Item, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_OBJ_INFO(0, Value, TElJsonEntity, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_get_Length, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_set_Length, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray_get_OwnsItems, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonArray___construct, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OwnsItems_or_Original_or_Values, 0, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElJsonArray_methods[] = {
	PHP_ME(TElJsonArray, Read_Inst, arginfo_TElJsonArray_Read_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, Read, arginfo_TElJsonArray_Read, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElJsonArray, Write, arginfo_TElJsonArray_Write, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, Assign, arginfo_TElJsonArray_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, Clone, arginfo_TElJsonArray_Clone, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, AssignStringList, arginfo_TElJsonArray_AssignStringList, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, Append, arginfo_TElJsonArray_Append, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, Clear, arginfo_TElJsonArray_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, Delete, arginfo_TElJsonArray_Delete, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, GetArray, arginfo_TElJsonArray_GetArray, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, GetArrayIfExists, arginfo_TElJsonArray_GetArrayIfExists, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, GetBooleanValue, arginfo_TElJsonArray_GetBooleanValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, GetDoubleValue, arginfo_TElJsonArray_GetDoubleValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, GetIntegerValue, arginfo_TElJsonArray_GetIntegerValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, GetObject, arginfo_TElJsonArray_GetObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, GetObjectIfExists, arginfo_TElJsonArray_GetObjectIfExists, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, GetStringValue, arginfo_TElJsonArray_GetStringValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, Insert, arginfo_TElJsonArray_Insert, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, IsNullValue, arginfo_TElJsonArray_IsNullValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, SetBooleanValue, arginfo_TElJsonArray_SetBooleanValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, SetDoubleValue, arginfo_TElJsonArray_SetDoubleValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, SetIntegerValue, arginfo_TElJsonArray_SetIntegerValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, SetNullValue, arginfo_TElJsonArray_SetNullValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, SetStringValue, arginfo_TElJsonArray_SetStringValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, get_Item, arginfo_TElJsonArray_get_Item, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, set_Item, arginfo_TElJsonArray_set_Item, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, get_Length, arginfo_TElJsonArray_get_Length, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, set_Length, arginfo_TElJsonArray_set_Length, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, get_OwnsItems, arginfo_TElJsonArray_get_OwnsItems, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonArray, __construct, arginfo_TElJsonArray___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElJsonArray(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElJsonArray_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElJsonArray", TElJsonArray_methods);
	if (NULL == TElJsonEntity_ce_ptr)
		Register_TElJsonEntity(TSRMLS_C);
	TElJsonArray_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElJsonEntity_ce_ptr);
}

zend_class_entry *TElJsonObject_ce_ptr = NULL;

SB_PHP_METHOD(TElJsonObject, Read_Inst)
{
	char *sText;
	sb_str_size sText_len;
	sb_zend_long l4Length;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sText, &sText_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonObject_Read_1(SBGetObjectHandle(getThis() TSRMLS_CC), sText, (int32_t)sText_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonObject_Read_3(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Length) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonObject_Read_5(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Length, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (array of byte|string|NULL) or (array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, Read)
{
	char *sText;
	sb_str_size sText_len;
	sb_zend_long l4Length;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sText, &sText_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonObject_Read(sText, (int32_t)sText_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonObject_Read_2(aiBuffer.data, aiBuffer.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Length) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonObject_Read_4(aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Length, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (array of byte|string|NULL) or (array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, Write)
{
	char *cIndentChar;
	sb_str_size cIndentChar_len;
	sb_zend_long l4CharsPerIndentLevel;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	uint32_t _err;
	zval *oStream;
	zval *zaBuffer;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonObject_Write(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(755906151, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &cIndentChar, &cIndentChar_len, &l4CharsPerIndentLevel) == SUCCESS) && (1 == cIndentChar_len))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonObject_Write_1(SBGetObjectHandle(getThis() TSRMLS_CC), cIndentChar[0], (int32_t)l4CharsPerIndentLevel, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-622701096, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaBuffer, &l4StartIndex) == SUCCESS) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = TElJsonObject_Write_2(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, &aiBuffer.len, (int32_t)l4StartIndex, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-275891617, 1, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "slzl", &cIndentChar, &cIndentChar_len, &l4CharsPerIndentLevel, &zaBuffer, &l4StartIndex) == SUCCESS) && (1 == cIndentChar_len) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = TElJsonObject_Write_3(SBGetObjectHandle(getThis() TSRMLS_CC), cIndentChar[0], (int32_t)l4CharsPerIndentLevel, aiBuffer.data, &aiBuffer.len, (int32_t)l4StartIndex, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-844348557, 3, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonObject_Write_4(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "slO!", &cIndentChar, &cIndentChar_len, &l4CharsPerIndentLevel, &oStream, TStream_ce_ptr) == SUCCESS) && (1 == cIndentChar_len))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonObject_Write_5(SBGetObjectHandle(getThis() TSRMLS_CC), cIndentChar[0], (int32_t)l4CharsPerIndentLevel, SBGetObjectHandle(oStream TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (char, integer) or (&array of byte|string, integer) or (char, integer, &array of byte|string, integer) or (\\TStream) or (char, integer, \\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElJsonObject_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, Clone)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonObject_Clone(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, Append)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElJsonObject_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElJsonObject_Append(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElJsonObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, AppendWithFilter)
{
	zval *oFilter;
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oSource, TElJsonObject_ce_ptr, &oFilter, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElJsonObject_AppendWithFilter(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC), SBGetObjectHandle(oFilter TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElJsonObject, \\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElJsonObject_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, Delete)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElJsonObject_Delete(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, DeleteValue)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		SBCheckError(TElJsonObject_DeleteValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, GetArray)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonObject_GetArray(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonArray_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, GetArrayIfExists)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonObject_GetArrayIfExists(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonArray_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, GetBooleanValue)
{
	char *sName;
	sb_str_size sName_len;
	zend_bool bDefault;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonObject_GetBooleanValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sb", &sName, &sName_len, &bDefault) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonObject_GetBooleanValue_1(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, (int8_t)bDefault, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, GetDoubleValue)
{
	char *sName;
	double dDefault;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElJsonObject_GetDoubleValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sd", &sName, &sName_len, &dDefault) == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElJsonObject_GetDoubleValue_1(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, (double)dDefault, &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string, double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, GetIntegerValue)
{
	char *sName;
	sb_str_size sName_len;
	sb_zend_long l8Default;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElJsonObject_GetIntegerValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &sName, &sName_len, &l8Default) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElJsonObject_GetIntegerValue_1(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, (int64_t)l8Default, &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, GetObject)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonObject_GetObject(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, GetObjectIfExists)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonObject_GetObjectIfExists(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, GetNumericDateValue)
{
	char *sName;
	sb_str_size sName_len;
	zval *dtDefault;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElJsonObject_GetNumericDateValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO", &sName, &sName_len, &dtDefault, php_date_get_date_ce()) == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElJsonObject_GetNumericDateValue_1(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, SBGetDateTime(dtDefault TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string, \\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, GetStringValue)
{
	char *sDefault;
	char *sName;
	sb_str_size sDefault_len;
	sb_str_size sName_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonObject_GetStringValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1670015003, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sName, &sName_len, &sDefault, &sDefault_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonObject_GetStringValue_1(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, sDefault, (int32_t)sDefault_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-780686030, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, GetValueIfExists)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonObject_GetValueIfExists(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, IndexOf)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonObject_IndexOf(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, IsNullValue)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonObject_IsNullValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, Remove)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonObject_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, NameAtIndex)
{
	sb_zend_long l4Index;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonObject_NameAtIndex(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-929865159, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, ValueAtIndex)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonObject_ValueAtIndex(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, ValueExists)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonObject_ValueExists(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, SetArray)
{
	char *sName;
	sb_str_size sName_len;
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sName, &sName_len, &oValue, TElJsonArray_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElJsonObject_SetArray(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sName, &sName_len, &oValue, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElJsonObject_SetArray_1(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElJsonArray) or (string, \\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, SetBooleanValue)
{
	char *sName;
	sb_str_size sName_len;
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sb", &sName, &sName_len, &bValue) == SUCCESS)
	{
		SBCheckError(TElJsonObject_SetBooleanValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, SetDoubleValue)
{
	char *sName;
	double dValue;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sd", &sName, &sName_len, &dValue) == SUCCESS)
	{
		SBCheckError(TElJsonObject_SetDoubleValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, (double)dValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, SetNullValue)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		SBCheckError(TElJsonObject_SetNullValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, SetIntegerValue)
{
	char *sName;
	sb_str_size sName_len;
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &sName, &sName_len, &l8Value) == SUCCESS)
	{
		SBCheckError(TElJsonObject_SetIntegerValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, SetNumericDateValue)
{
	char *sName;
	sb_str_size sName_len;
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO", &sName, &sName_len, &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElJsonObject_SetNumericDateValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, SetObject)
{
	char *sName;
	sb_str_size sName_len;
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sName, &sName_len, &oValue, TElJsonObject_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElJsonObject_SetObject(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElJsonObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, SetStringValue)
{
	char *sName;
	char *sValue;
	sb_str_size sName_len;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sName, &sName_len, &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElJsonObject_SetStringValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, GetValue)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonObject_GetValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, SetValue)
{
	char *sName;
	sb_str_size sName_len;
	zval *oAValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sName, &sName_len, &oAValue, TElJsonEntity_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElJsonObject_SetValue(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, SBGetObjectHandle(oAValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElJsonEntity)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, GetText)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonObject_GetText(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-888488973, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, SetText)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElJsonObject_SetText(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonObject_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, get_SortValues)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonObject_get_SortValues(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, set_SortValues)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElJsonObject_set_SortValues(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, get_OwnsValues)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonObject_get_OwnsValues(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, get_Text)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonObject_get_Text(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1973890048, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, set_Text)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElJsonObject_set_Text(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, get_Value)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonObject_get_Value(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, set_Value)
{
	char *sName;
	sb_str_size sName_len;
	zval *oAValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sName, &sName_len, &oAValue, TElJsonEntity_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElJsonObject_set_Value(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, SBGetObjectHandle(oAValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElJsonEntity)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonObject, __construct)
{
	zend_bool bOwnsValues;
	zval *oOriginal;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bOwnsValues) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonObject_Create((int8_t)bOwnsValues, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOriginal, TElJsonObject_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonObject_Create_1(SBGetObjectHandle(oOriginal TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool) or (\\TElJsonObject)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_Read_Inst, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Text_or_Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Length)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_Read, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Text_or_Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Length)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_Write, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(1, IndentChar_or_Buffer_or_Stream, 0, 1)
	ZEND_ARG_INFO(0, CharsPerIndentLevel_or_StartIndex)
	ZEND_ARG_TYPE_INFO(1, Buffer_or_Stream, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_Clone, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_Append, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElJsonObject, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_AppendWithFilter, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Source, TElJsonObject, 1)
	ZEND_ARG_OBJ_INFO(0, Filter, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_Delete, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_DeleteValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_GetArray, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_GetArrayIfExists, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_GetBooleanValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_GetDoubleValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_GetIntegerValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_GetObject, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_GetObjectIfExists, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_GetNumericDateValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_OBJ_INFO(0, Default, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_GetStringValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Default)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_GetValueIfExists, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_IndexOf, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_IsNullValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_NameAtIndex, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_ValueAtIndex, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_ValueExists, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_SetArray, 0, 0, 2)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_SetBooleanValue, 0, 0, 2)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_SetDoubleValue, 0, 0, 2)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_SetNullValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_SetIntegerValue, 0, 0, 2)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_SetNumericDateValue, 0, 0, 2)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_SetObject, 0, 0, 2)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_OBJ_INFO(0, Value, TElJsonObject, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_SetStringValue, 0, 0, 2)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_GetValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_SetValue, 0, 0, 2)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_OBJ_INFO(0, AValue, TElJsonEntity, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_GetText, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_SetText, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_get_SortValues, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_set_SortValues, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_get_OwnsValues, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_get_Text, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_set_Text, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_get_Value, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject_set_Value, 0, 0, 2)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_OBJ_INFO(0, AValue, TElJsonEntity, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonObject___construct, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OwnsValues_or_Original, 0, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElJsonObject_methods[] = {
	PHP_ME(TElJsonObject, Read_Inst, arginfo_TElJsonObject_Read_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, Read, arginfo_TElJsonObject_Read, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElJsonObject, Write, arginfo_TElJsonObject_Write, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, Assign, arginfo_TElJsonObject_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, Clone, arginfo_TElJsonObject_Clone, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, Append, arginfo_TElJsonObject_Append, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, AppendWithFilter, arginfo_TElJsonObject_AppendWithFilter, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, Clear, arginfo_TElJsonObject_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, Delete, arginfo_TElJsonObject_Delete, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, DeleteValue, arginfo_TElJsonObject_DeleteValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, GetArray, arginfo_TElJsonObject_GetArray, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, GetArrayIfExists, arginfo_TElJsonObject_GetArrayIfExists, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, GetBooleanValue, arginfo_TElJsonObject_GetBooleanValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, GetDoubleValue, arginfo_TElJsonObject_GetDoubleValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, GetIntegerValue, arginfo_TElJsonObject_GetIntegerValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, GetObject, arginfo_TElJsonObject_GetObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, GetObjectIfExists, arginfo_TElJsonObject_GetObjectIfExists, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, GetNumericDateValue, arginfo_TElJsonObject_GetNumericDateValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, GetStringValue, arginfo_TElJsonObject_GetStringValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, GetValueIfExists, arginfo_TElJsonObject_GetValueIfExists, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, IndexOf, arginfo_TElJsonObject_IndexOf, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, IsNullValue, arginfo_TElJsonObject_IsNullValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, Remove, arginfo_TElJsonObject_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, NameAtIndex, arginfo_TElJsonObject_NameAtIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, ValueAtIndex, arginfo_TElJsonObject_ValueAtIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, ValueExists, arginfo_TElJsonObject_ValueExists, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, SetArray, arginfo_TElJsonObject_SetArray, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, SetBooleanValue, arginfo_TElJsonObject_SetBooleanValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, SetDoubleValue, arginfo_TElJsonObject_SetDoubleValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, SetNullValue, arginfo_TElJsonObject_SetNullValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, SetIntegerValue, arginfo_TElJsonObject_SetIntegerValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, SetNumericDateValue, arginfo_TElJsonObject_SetNumericDateValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, SetObject, arginfo_TElJsonObject_SetObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, SetStringValue, arginfo_TElJsonObject_SetStringValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, GetValue, arginfo_TElJsonObject_GetValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, SetValue, arginfo_TElJsonObject_SetValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, GetText, arginfo_TElJsonObject_GetText, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, SetText, arginfo_TElJsonObject_SetText, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, get_Count, arginfo_TElJsonObject_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, get_SortValues, arginfo_TElJsonObject_get_SortValues, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, set_SortValues, arginfo_TElJsonObject_set_SortValues, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, get_OwnsValues, arginfo_TElJsonObject_get_OwnsValues, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, get_Text, arginfo_TElJsonObject_get_Text, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, set_Text, arginfo_TElJsonObject_set_Text, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, get_Value, arginfo_TElJsonObject_get_Value, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, set_Value, arginfo_TElJsonObject_set_Value, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonObject, __construct, arginfo_TElJsonObject___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElJsonObject(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElJsonObject_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElJsonObject", TElJsonObject_methods);
	if (NULL == TElJsonEntity_ce_ptr)
		Register_TElJsonEntity(TSRMLS_C);
	TElJsonObject_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElJsonEntity_ce_ptr);
}

zend_class_entry *TElJsonValue_ce_ptr = NULL;

SB_PHP_METHOD(TElJsonValue, Read_Inst)
{
	char *sText;
	sb_str_size sText_len;
	sb_zend_long l4Length;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sText, &sText_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonValue_Read_1(SBGetObjectHandle(getThis() TSRMLS_CC), sText, (int32_t)sText_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonValue_Read_3(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Length) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonValue_Read_5(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Length, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (array of byte|string|NULL) or (array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, Read)
{
	char *sText;
	sb_str_size sText_len;
	sb_zend_long l4Length;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sText, &sText_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonValue_Read(sText, (int32_t)sText_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonValue_Read_2(aiBuffer.data, aiBuffer.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4StartIndex, &l4Length) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElJsonValue_Read_4(aiBuffer.data, aiBuffer.len, (int32_t)l4StartIndex, (int32_t)l4Length, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (array of byte|string|NULL) or (array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, Write)
{
	char *cIndentChar;
	sb_str_size cIndentChar_len;
	sb_zend_long l4CharsPerIndentLevel;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiBuffer;
	uint32_t _err;
	zval *oStream;
	zval *zaBuffer;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonValue_Write(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(755906151, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &cIndentChar, &cIndentChar_len, &l4CharsPerIndentLevel) == SUCCESS) && (1 == cIndentChar_len))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonValue_Write_1(SBGetObjectHandle(getThis() TSRMLS_CC), cIndentChar[0], (int32_t)l4CharsPerIndentLevel, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-622701096, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaBuffer, &l4StartIndex) == SUCCESS) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = TElJsonValue_Write_2(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, &aiBuffer.len, (int32_t)l4StartIndex, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-275891617, 1, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "slzl", &cIndentChar, &cIndentChar_len, &l4CharsPerIndentLevel, &zaBuffer, &l4StartIndex) == SUCCESS) && (1 == cIndentChar_len) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = TElJsonValue_Write_3(SBGetObjectHandle(getThis() TSRMLS_CC), cIndentChar[0], (int32_t)l4CharsPerIndentLevel, aiBuffer.data, &aiBuffer.len, (int32_t)l4StartIndex, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-844348557, 3, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonValue_Write_4(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "slO!", &cIndentChar, &cIndentChar_len, &l4CharsPerIndentLevel, &oStream, TStream_ce_ptr) == SUCCESS) && (1 == cIndentChar_len))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElJsonValue_Write_5(SBGetObjectHandle(getThis() TSRMLS_CC), cIndentChar[0], (int32_t)l4CharsPerIndentLevel, SBGetObjectHandle(oStream TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (char, integer) or (&array of byte|string, integer) or (char, integer, &array of byte|string, integer) or (\\TStream) or (char, integer, \\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElJsonValue_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, Clone)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonValue_Clone(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElJsonEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, get_AsBoolean)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonValue_get_AsBoolean(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, set_AsBoolean)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElJsonValue_set_AsBoolean(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, get_AsInteger)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElJsonValue_get_AsInteger(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, set_AsInteger)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElJsonValue_set_AsInteger(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, get_AsNumber)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElJsonValue_get_AsNumber(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, set_AsNumber)
{
	double dValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "d", &dValue) == SUCCESS)
	{
		SBCheckError(TElJsonValue_set_AsNumber(SBGetObjectHandle(getThis() TSRMLS_CC), (double)dValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, get_AsString)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonValue_get_AsString(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(722361528, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, set_AsString)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElJsonValue_set_AsString(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, get_AsNumericDate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElJsonValue_get_AsNumericDate(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, set_AsNumericDate)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElJsonValue_set_AsNumericDate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, get_IsBoolean)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonValue_get_IsBoolean(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, get_IsNull)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonValue_get_IsNull(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, set_IsNull)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElJsonValue_set_IsNull(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, get_IsNumber)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonValue_get_IsNumber(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, get_IsString)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElJsonValue_get_IsString(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, get_Value)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElJsonValue_get_Value(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1465167972, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, get_ValueType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBJsonTypeRaw fOutResultRaw = 0;
		SBCheckError(TElJsonValue_get_ValueType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElJsonValue, __construct)
{
	char *sValue;
	double dValue;
	sb_str_size sValue_len;
	sb_zend_long l8Value;
	zend_bool bValue;
	zval *oOriginal;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonValue_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOriginal, TElJsonValue_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonValue_Create_1(SBGetObjectHandle(oOriginal TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonValue_Create_2((int8_t)bValue, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "d", &dValue) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonValue_Create_3((double)dValue, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonValue_Create_4((int64_t)l8Value, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElJsonValue_Create_5(sValue, (int32_t)sValue_len, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElJsonValue) or (bool) or (double) or (integer) or (string)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_Read_Inst, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Text_or_Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Length)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_Read, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Text_or_Buffer, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Length)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_Write, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(1, IndentChar_or_Buffer_or_Stream, 0, 1)
	ZEND_ARG_INFO(0, CharsPerIndentLevel_or_StartIndex)
	ZEND_ARG_TYPE_INFO(1, Buffer_or_Stream, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_Clone, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_get_AsBoolean, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_set_AsBoolean, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_get_AsInteger, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_set_AsInteger, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_get_AsNumber, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_set_AsNumber, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_get_AsString, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_set_AsString, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_get_AsNumericDate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_set_AsNumericDate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_get_IsBoolean, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_get_IsNull, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_set_IsNull, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_get_IsNumber, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_get_IsString, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_get_Value, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue_get_ValueType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElJsonValue___construct, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, Original_or_Value, 0, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElJsonValue_methods[] = {
	PHP_ME(TElJsonValue, Read_Inst, arginfo_TElJsonValue_Read_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, Read, arginfo_TElJsonValue_Read, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElJsonValue, Write, arginfo_TElJsonValue_Write, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, Assign, arginfo_TElJsonValue_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, Clone, arginfo_TElJsonValue_Clone, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, get_AsBoolean, arginfo_TElJsonValue_get_AsBoolean, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, set_AsBoolean, arginfo_TElJsonValue_set_AsBoolean, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, get_AsInteger, arginfo_TElJsonValue_get_AsInteger, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, set_AsInteger, arginfo_TElJsonValue_set_AsInteger, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, get_AsNumber, arginfo_TElJsonValue_get_AsNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, set_AsNumber, arginfo_TElJsonValue_set_AsNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, get_AsString, arginfo_TElJsonValue_get_AsString, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, set_AsString, arginfo_TElJsonValue_set_AsString, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, get_AsNumericDate, arginfo_TElJsonValue_get_AsNumericDate, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, set_AsNumericDate, arginfo_TElJsonValue_set_AsNumericDate, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, get_IsBoolean, arginfo_TElJsonValue_get_IsBoolean, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, get_IsNull, arginfo_TElJsonValue_get_IsNull, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, set_IsNull, arginfo_TElJsonValue_set_IsNull, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, get_IsNumber, arginfo_TElJsonValue_get_IsNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, get_IsString, arginfo_TElJsonValue_get_IsString, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, get_Value, arginfo_TElJsonValue_get_Value, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, get_ValueType, arginfo_TElJsonValue_get_ValueType, ZEND_ACC_PUBLIC)
	PHP_ME(TElJsonValue, __construct, arginfo_TElJsonValue___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElJsonValue(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElJsonValue_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElJsonValue", TElJsonValue_methods);
	if (NULL == TElJsonEntity_ce_ptr)
		Register_TElJsonEntity(TSRMLS_C);
	TElJsonValue_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElJsonEntity_ce_ptr);
}

void Register_SBJSON_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBJsonType", NULL);
	TSBJsonType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBJsonType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBJsonType_ce_ptr, "jsonNull", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBJsonType_ce_ptr, "jsonBoolean", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBJsonType_ce_ptr, "jsonString", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBJsonType_ce_ptr, "jsonNumber", 3)
}

