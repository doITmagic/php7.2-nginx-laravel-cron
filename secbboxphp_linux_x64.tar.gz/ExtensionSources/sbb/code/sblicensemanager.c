#include "sblicensemanager.h"

zend_class_entry *TSBLicenseKeyRegKey_ce_ptr = NULL;

zend_class_entry *TElSBLicenseManager_ce_ptr = NULL;

#ifdef SB_WINDOWS
SB_PHP_METHOD(TElSBLicenseManager, get_RegistryKey)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSBLicenseManager_get_RegistryKey(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSBLicenseManager, set_RegistryKey)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSBLicenseManager_set_RegistryKey(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}
#endif

SB_PHP_METHOD(TElSBLicenseManager, get_LicenseKey)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSBLicenseManager_get_LicenseKey(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1768800821, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSBLicenseManager, set_LicenseKey)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSBLicenseManager_set_LicenseKey(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSBLicenseManager, get_LicenseKeyFile)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSBLicenseManager_get_LicenseKeyFile(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-636647649, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSBLicenseManager, set_LicenseKeyFile)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSBLicenseManager_set_LicenseKeyFile(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSBLicenseManager, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSBLicenseManager_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

#ifdef SB_WINDOWS
ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSBLicenseManager_get_RegistryKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSBLicenseManager_set_RegistryKey, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()
#endif

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSBLicenseManager_get_LicenseKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSBLicenseManager_set_LicenseKey, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSBLicenseManager_get_LicenseKeyFile, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSBLicenseManager_set_LicenseKeyFile, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSBLicenseManager___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSBLicenseManager_methods[] = {
#ifdef SB_WINDOWS
	PHP_ME(TElSBLicenseManager, get_RegistryKey, arginfo_TElSBLicenseManager_get_RegistryKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElSBLicenseManager, set_RegistryKey, arginfo_TElSBLicenseManager_set_RegistryKey, ZEND_ACC_PUBLIC)
#endif
	PHP_ME(TElSBLicenseManager, get_LicenseKey, arginfo_TElSBLicenseManager_get_LicenseKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElSBLicenseManager, set_LicenseKey, arginfo_TElSBLicenseManager_set_LicenseKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElSBLicenseManager, get_LicenseKeyFile, arginfo_TElSBLicenseManager_get_LicenseKeyFile, ZEND_ACC_PUBLIC)
	PHP_ME(TElSBLicenseManager, set_LicenseKeyFile, arginfo_TElSBLicenseManager_set_LicenseKeyFile, ZEND_ACC_PUBLIC)
	PHP_ME(TElSBLicenseManager, __construct, arginfo_TElSBLicenseManager___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSBLicenseManager(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSBLicenseManager_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSBLicenseManager", TElSBLicenseManager_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElSBLicenseManager_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

void Register_SBLicenseManager_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBLicenseKeyRegKey", NULL);
	TSBLicenseKeyRegKey_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBLicenseKeyRegKey_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBLicenseKeyRegKey_ce_ptr, "rkHK", 0)
}

void Register_SBLicenseManager_Aliases(TSRMLS_D)
{
	if (NULL == TElSBLicenseManager_ce_ptr)
		Register_TElSBLicenseManager(TSRMLS_C);
	zend_register_class_alias("ElSBLicenseManager", TElSBLicenseManager_ce_ptr);
}
