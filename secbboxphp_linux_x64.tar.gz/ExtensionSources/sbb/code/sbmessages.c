#include "sbmessages.h"

zend_class_entry *TSBEncryptionOption_ce_ptr = NULL;

zend_class_entry *TSBEncryptionOptions_ce_ptr = NULL;

void SB_CALLBACK TSBCertIDsEventRaw(void * _ObjectData, TObjectHandle Sender, TListHandle CertIDs)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zCertIDs;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCertIDs, 1);
	SBInitObject(zCertIDs, TList_ce_ptr, CertIDs TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zCertIDs);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSBDecryptionOption_ce_ptr = NULL;

zend_class_entry *TSBDecryptionOptions_ce_ptr = NULL;

zend_class_entry *TSBMessageSignatureType_ce_ptr = NULL;

zend_class_entry *TSBVerificationOption_ce_ptr = NULL;

zend_class_entry *TSBVerificationOptions_ce_ptr = NULL;

zend_class_entry *TSBSigningOption_ce_ptr = NULL;

zend_class_entry *TSBSigningOptions_ce_ptr = NULL;

zend_class_entry *TSBSignOperationType_ce_ptr = NULL;

zend_class_entry *TElMessageProcessor_ce_ptr = NULL;

SB_PHP_METHOD(TElMessageProcessor, get_ErrorInfo)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElMessageProcessor_get_ErrorInfo(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(66943194, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageProcessor, get_CryptoProviderManager)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageProcessor_get_CryptoProviderManager(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoProviderManager_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageProcessor, set_CryptoProviderManager)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCryptoProviderManager_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessageProcessor_set_CryptoProviderManager(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoProviderManager)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageProcessor, get_AlignEncryptedKey)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageProcessor_get_AlignEncryptedKey(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageProcessor, set_AlignEncryptedKey)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageProcessor_set_AlignEncryptedKey(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageProcessor, get_OAEPHashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageProcessor_get_OAEPHashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageProcessor, set_OAEPHashAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElMessageProcessor_set_OAEPHashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageProcessor, get_OnProgress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBProgressEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElMessageProcessor_get_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageProcessor, set_OnProgress)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElMessageProcessor_set_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBProgressEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBProgressEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageProcessor, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageProcessor_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageProcessor_get_ErrorInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageProcessor_get_CryptoProviderManager, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageProcessor_set_CryptoProviderManager, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCryptoProviderManager, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageProcessor_get_AlignEncryptedKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageProcessor_set_AlignEncryptedKey, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageProcessor_get_OAEPHashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageProcessor_set_OAEPHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageProcessor_get_OnProgress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageProcessor_set_OnProgress, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageProcessor___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElMessageProcessor_methods[] = {
	PHP_ME(TElMessageProcessor, get_ErrorInfo, arginfo_TElMessageProcessor_get_ErrorInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageProcessor, get_CryptoProviderManager, arginfo_TElMessageProcessor_get_CryptoProviderManager, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageProcessor, set_CryptoProviderManager, arginfo_TElMessageProcessor_set_CryptoProviderManager, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageProcessor, get_AlignEncryptedKey, arginfo_TElMessageProcessor_get_AlignEncryptedKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageProcessor, set_AlignEncryptedKey, arginfo_TElMessageProcessor_set_AlignEncryptedKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageProcessor, get_OAEPHashAlgorithm, arginfo_TElMessageProcessor_get_OAEPHashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageProcessor, set_OAEPHashAlgorithm, arginfo_TElMessageProcessor_set_OAEPHashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageProcessor, get_OnProgress, arginfo_TElMessageProcessor_get_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageProcessor, set_OnProgress, arginfo_TElMessageProcessor_set_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageProcessor, __construct, arginfo_TElMessageProcessor___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMessageProcessor(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMessageProcessor_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMessageProcessor", TElMessageProcessor_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElMessageProcessor_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElMessageEncryptor_ce_ptr = NULL;

SB_PHP_METHOD(TElMessageEncryptor, Encrypt)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	sb_zend_long l4KeySize;
	sb_zend_long l8InCount;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piKey;
	SBArrayZValInfo piOutBuffer;
	zval *oInStream;
	zval *oOutStream;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpKey;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzz", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElMessageEncryptor_Encrypt(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzzl", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize, &zpKey, &l4KeySize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))) && (SB_IS_STRING_TYPE_RP(zpKey) || SB_IS_ARRAY_TYPE_RP(zpKey) || SB_IS_NULL_TYPE_RP(zpKey) || (SB_IS_OBJECT_TYPE_RP(zpKey) && (Z_OBJCE_P(zpKey) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		if (!SBGetPointerFromZVal(zpKey, &piKey TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMessageEncryptor_Encrypt_1(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, piKey.data, (int32_t)l4KeySize, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		SBFreePointerZValInfo(&piKey);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &l8InCount) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageEncryptor_Encrypt_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zll", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &zpKey, &l4KeySize, &l8InCount) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpKey) || SB_IS_ARRAY_TYPE_RP(zpKey) || SB_IS_NULL_TYPE_RP(zpKey) || (SB_IS_OBJECT_TYPE_RP(zpKey) && (Z_OBJCE_P(zpKey) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpKey, &piKey TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMessageEncryptor_Encrypt_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), piKey.data, (int32_t)l4KeySize, (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piKey);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer) or (\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer, \\TSBPointer|array of byte|string|NULL, integer) or (\\TStream, \\TStream, integer) or (\\TStream, \\TStream, \\TSBPointer|array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, get_GOSTParamSet)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElMessageEncryptor_get_GOSTParamSet(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1294885631, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, set_GOSTParamSet)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMessageEncryptor_set_GOSTParamSet(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, get_CertStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageEncryptor_get_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, set_CertStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessageEncryptor_set_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, get_Algorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageEncryptor_get_Algorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, set_Algorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElMessageEncryptor_set_Algorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, get_BitsInKey)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageEncryptor_get_BitsInKey(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, set_BitsInKey)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElMessageEncryptor_set_BitsInKey(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, get_UseUndefSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageEncryptor_get_UseUndefSize(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, set_UseUndefSize)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageEncryptor_set_UseUndefSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, get_UseOAEP)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageEncryptor_get_UseOAEP(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, set_UseOAEP)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageEncryptor_set_UseOAEP(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, get_EncryptionOptions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBEncryptionOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElMessageEncryptor_get_EncryptionOptions(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, set_EncryptionOptions)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElMessageEncryptor_set_EncryptionOptions(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBEncryptionOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, get_UseImplicitContentEncoding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageEncryptor_get_UseImplicitContentEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, set_UseImplicitContentEncoding)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageEncryptor_set_UseImplicitContentEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, get_OriginatorCertificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageEncryptor_get_OriginatorCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, set_OriginatorCertificates)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessageEncryptor_set_OriginatorCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, get_OriginatorCRLs)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageEncryptor_get_OriginatorCRLs(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCRLStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, set_OriginatorCRLs)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCRLStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessageEncryptor_set_OriginatorCRLs(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCRLStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, get_UnprotectedAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageEncryptor_get_UnprotectedAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Attributes_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, get_AuthenticatedAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageEncryptor_get_AuthenticatedAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Attributes_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, get_UnauthenticatedAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageEncryptor_get_UnauthenticatedAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Attributes_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageEncryptor, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageEncryptor_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_Encrypt, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, InBuffer_or_InStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InSize_or_OutStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_InCount_or_Key, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_KeySize)
	ZEND_ARG_TYPE_INFO(0, Key_or_InCount, 0, 1)
	ZEND_ARG_INFO(0, KeySize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_get_GOSTParamSet, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_set_GOSTParamSet, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_get_CertStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_set_CertStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_get_Algorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_set_Algorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_get_BitsInKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_set_BitsInKey, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_get_UseUndefSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_set_UseUndefSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_get_UseOAEP, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_set_UseOAEP, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_get_EncryptionOptions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_set_EncryptionOptions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_get_UseImplicitContentEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_set_UseImplicitContentEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_get_OriginatorCertificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_set_OriginatorCertificates, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_get_OriginatorCRLs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_set_OriginatorCRLs, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCRLStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_get_UnprotectedAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_get_AuthenticatedAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor_get_UnauthenticatedAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageEncryptor___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElMessageEncryptor_methods[] = {
	PHP_ME(TElMessageEncryptor, Encrypt, arginfo_TElMessageEncryptor_Encrypt, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, get_GOSTParamSet, arginfo_TElMessageEncryptor_get_GOSTParamSet, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, set_GOSTParamSet, arginfo_TElMessageEncryptor_set_GOSTParamSet, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, get_CertStorage, arginfo_TElMessageEncryptor_get_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, set_CertStorage, arginfo_TElMessageEncryptor_set_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, get_Algorithm, arginfo_TElMessageEncryptor_get_Algorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, set_Algorithm, arginfo_TElMessageEncryptor_set_Algorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, get_BitsInKey, arginfo_TElMessageEncryptor_get_BitsInKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, set_BitsInKey, arginfo_TElMessageEncryptor_set_BitsInKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, get_UseUndefSize, arginfo_TElMessageEncryptor_get_UseUndefSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, set_UseUndefSize, arginfo_TElMessageEncryptor_set_UseUndefSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, get_UseOAEP, arginfo_TElMessageEncryptor_get_UseOAEP, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, set_UseOAEP, arginfo_TElMessageEncryptor_set_UseOAEP, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, get_EncryptionOptions, arginfo_TElMessageEncryptor_get_EncryptionOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, set_EncryptionOptions, arginfo_TElMessageEncryptor_set_EncryptionOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, get_UseImplicitContentEncoding, arginfo_TElMessageEncryptor_get_UseImplicitContentEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, set_UseImplicitContentEncoding, arginfo_TElMessageEncryptor_set_UseImplicitContentEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, get_OriginatorCertificates, arginfo_TElMessageEncryptor_get_OriginatorCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, set_OriginatorCertificates, arginfo_TElMessageEncryptor_set_OriginatorCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, get_OriginatorCRLs, arginfo_TElMessageEncryptor_get_OriginatorCRLs, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, set_OriginatorCRLs, arginfo_TElMessageEncryptor_set_OriginatorCRLs, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, get_UnprotectedAttributes, arginfo_TElMessageEncryptor_get_UnprotectedAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, get_AuthenticatedAttributes, arginfo_TElMessageEncryptor_get_AuthenticatedAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, get_UnauthenticatedAttributes, arginfo_TElMessageEncryptor_get_UnauthenticatedAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageEncryptor, __construct, arginfo_TElMessageEncryptor___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMessageEncryptor(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMessageEncryptor_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMessageEncryptor", TElMessageEncryptor_methods);
	if (NULL == TElMessageProcessor_ce_ptr)
		Register_TElMessageProcessor(TSRMLS_C);
	TElMessageEncryptor_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElMessageProcessor_ce_ptr);
}

zend_class_entry *TElMessageDecryptor_ce_ptr = NULL;

SB_PHP_METHOD(TElMessageDecryptor, Decrypt)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	sb_zend_long l4KeySize;
	sb_zend_long l8InCount;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piKey;
	SBArrayZValInfo piOutBuffer;
	zval *oInStream;
	zval *oOutStream;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpKey;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzz", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElMessageDecryptor_Decrypt(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzzl", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize, &zpKey, &l4KeySize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))) && (SB_IS_STRING_TYPE_RP(zpKey) || SB_IS_ARRAY_TYPE_RP(zpKey) || SB_IS_NULL_TYPE_RP(zpKey) || (SB_IS_OBJECT_TYPE_RP(zpKey) && (Z_OBJCE_P(zpKey) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		if (!SBGetPointerFromZVal(zpKey, &piKey TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMessageDecryptor_Decrypt_1(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, piKey.data, (int32_t)l4KeySize, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		SBFreePointerZValInfo(&piKey);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &l8InCount) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageDecryptor_Decrypt_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!zll", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &zpKey, &l4KeySize, &l8InCount) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpKey) || SB_IS_ARRAY_TYPE_RP(zpKey) || SB_IS_NULL_TYPE_RP(zpKey) || (SB_IS_OBJECT_TYPE_RP(zpKey) && (Z_OBJCE_P(zpKey) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpKey, &piKey TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMessageDecryptor_Decrypt_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), piKey.data, (int32_t)l4KeySize, (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piKey);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer) or (\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer, \\TSBPointer|array of byte|string|NULL, integer) or (\\TStream, \\TStream, integer) or (\\TStream, \\TStream, \\TSBPointer|array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, IsConventionallyEncrypted_Inst)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMessageDecryptor_IsConventionallyEncrypted_1(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, IsConventionallyEncrypted)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMessageDecryptor_IsConventionallyEncrypted(piBuffer.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, get_Algorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageDecryptor_get_Algorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, get_BitsInKey)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageDecryptor_get_BitsInKey(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, get_CertIDs)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageDecryptor_get_CertIDs(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Issuer_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, get_CertIDCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageDecryptor_get_CertIDCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, get_UsedCertificate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageDecryptor_get_UsedCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, get_UseOAEP)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageDecryptor_get_UseOAEP(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, get_OriginatorCertificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageDecryptor_get_OriginatorCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElMemoryCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, get_OriginatorCRLs)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageDecryptor_get_OriginatorCRLs(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElMemoryCRLStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, get_UnprotectedAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageDecryptor_get_UnprotectedAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Attributes_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, get_AuthenticatedAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageDecryptor_get_AuthenticatedAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Attributes_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, get_UnauthenticatedAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageDecryptor_get_UnauthenticatedAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Attributes_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, get_CertStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageDecryptor_get_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, set_CertStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessageDecryptor_set_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, get_DecryptionOptions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDecryptionOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElMessageDecryptor_get_DecryptionOptions(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, set_DecryptionOptions)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElMessageDecryptor_set_DecryptionOptions(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBDecryptionOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, get_OnCertIDs)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCertIDsEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElMessageDecryptor_get_OnCertIDs(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, set_OnCertIDs)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElMessageDecryptor_set_OnCertIDs(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCertIDsEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCertIDsEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecryptor, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageDecryptor_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_Decrypt, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, InBuffer_or_InStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InSize_or_OutStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_InCount_or_Key, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_KeySize)
	ZEND_ARG_TYPE_INFO(0, Key_or_InCount, 0, 1)
	ZEND_ARG_INFO(0, KeySize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_IsConventionallyEncrypted_Inst, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_IsConventionallyEncrypted, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_get_Algorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_get_BitsInKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_get_CertIDs, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_get_CertIDCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_get_UsedCertificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_get_UseOAEP, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_get_OriginatorCertificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_get_OriginatorCRLs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_get_UnprotectedAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_get_AuthenticatedAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_get_UnauthenticatedAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_get_CertStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_set_CertStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_get_DecryptionOptions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_set_DecryptionOptions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_get_OnCertIDs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor_set_OnCertIDs, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecryptor___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElMessageDecryptor_methods[] = {
	PHP_ME(TElMessageDecryptor, Decrypt, arginfo_TElMessageDecryptor_Decrypt, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, IsConventionallyEncrypted_Inst, arginfo_TElMessageDecryptor_IsConventionallyEncrypted_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, IsConventionallyEncrypted, arginfo_TElMessageDecryptor_IsConventionallyEncrypted, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElMessageDecryptor, get_Algorithm, arginfo_TElMessageDecryptor_get_Algorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, get_BitsInKey, arginfo_TElMessageDecryptor_get_BitsInKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, get_CertIDs, arginfo_TElMessageDecryptor_get_CertIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, get_CertIDCount, arginfo_TElMessageDecryptor_get_CertIDCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, get_UsedCertificate, arginfo_TElMessageDecryptor_get_UsedCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, get_UseOAEP, arginfo_TElMessageDecryptor_get_UseOAEP, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, get_OriginatorCertificates, arginfo_TElMessageDecryptor_get_OriginatorCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, get_OriginatorCRLs, arginfo_TElMessageDecryptor_get_OriginatorCRLs, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, get_UnprotectedAttributes, arginfo_TElMessageDecryptor_get_UnprotectedAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, get_AuthenticatedAttributes, arginfo_TElMessageDecryptor_get_AuthenticatedAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, get_UnauthenticatedAttributes, arginfo_TElMessageDecryptor_get_UnauthenticatedAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, get_CertStorage, arginfo_TElMessageDecryptor_get_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, set_CertStorage, arginfo_TElMessageDecryptor_set_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, get_DecryptionOptions, arginfo_TElMessageDecryptor_get_DecryptionOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, set_DecryptionOptions, arginfo_TElMessageDecryptor_set_DecryptionOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, get_OnCertIDs, arginfo_TElMessageDecryptor_get_OnCertIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, set_OnCertIDs, arginfo_TElMessageDecryptor_set_OnCertIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecryptor, __construct, arginfo_TElMessageDecryptor___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMessageDecryptor(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMessageDecryptor_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMessageDecryptor", TElMessageDecryptor_methods);
	if (NULL == TElMessageProcessor_ce_ptr)
		Register_TElMessageProcessor(TSRMLS_C);
	TElMessageDecryptor_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElMessageProcessor_ce_ptr);
}

zend_class_entry *TElMessageVerifier_ce_ptr = NULL;

SB_PHP_METHOD(TElMessageVerifier, Verify)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	sb_zend_long l8InCount;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	zval *oInStream;
	zval *oOutStream;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzz", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElMessageVerifier_Verify(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &l8InCount) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageVerifier_Verify_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer) or (\\TStream, \\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, VerifyDetached)
{
	sb_zend_long l4SignatureSize;
	sb_zend_long l4Size;
	sb_zend_long l8InCount;
	sb_zend_long l8SigCount;
	SBArrayZValInfo piBuffer;
	SBArrayZValInfo piSignature;
	zval *oInStream;
	zval *oSigStream;
	zval *zpBuffer;
	zval *zpSignature;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzl", &zpBuffer, &l4Size, &zpSignature, &l4SignatureSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpSignature) || SB_IS_ARRAY_TYPE_RP(zpSignature) || SB_IS_NULL_TYPE_RP(zpSignature) || (SB_IS_OBJECT_TYPE_RP(zpSignature) && (Z_OBJCE_P(zpSignature) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpSignature, &piSignature TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMessageVerifier_VerifyDetached(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, piSignature.data, (int32_t)l4SignatureSize, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		SBFreePointerZValInfo(&piSignature);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!ll", &oInStream, TStream_ce_ptr, &oSigStream, TStream_ce_ptr, &l8InCount, &l8SigCount) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageVerifier_VerifyDetached_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oSigStream TSRMLS_CC), (int64_t)l8InCount, (int64_t)l8SigCount, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, integer) or (\\TStream, \\TStream, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, IsSignatureDetached_Inst)
{
	sb_zend_long l4Size;
	sb_zend_long l8Count;
	SBArrayZValInfo piSignature;
	zval *oSignature;
	zval *zpSignature;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpSignature, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpSignature) || SB_IS_ARRAY_TYPE_RP(zpSignature) || SB_IS_NULL_TYPE_RP(zpSignature) || (SB_IS_OBJECT_TYPE_RP(zpSignature) && (Z_OBJCE_P(zpSignature) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpSignature, &piSignature TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMessageVerifier_IsSignatureDetached_1(SBGetObjectHandle(getThis() TSRMLS_CC), piSignature.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piSignature);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oSignature, TStream_ce_ptr, &l8Count) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageVerifier_IsSignatureDetached_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSignature TSRMLS_CC), (int64_t)l8Count, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer) or (\\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, IsSignatureDetached)
{
	sb_zend_long l4Size;
	sb_zend_long l8Count;
	SBArrayZValInfo piSignature;
	zval *oSignature;
	zval *zpSignature;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpSignature, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpSignature) || SB_IS_ARRAY_TYPE_RP(zpSignature) || SB_IS_NULL_TYPE_RP(zpSignature) || (SB_IS_OBJECT_TYPE_RP(zpSignature) && (Z_OBJCE_P(zpSignature) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpSignature, &piSignature TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMessageVerifier_IsSignatureDetached(piSignature.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piSignature);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oSignature, TStream_ce_ptr, &l8Count) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageVerifier_IsSignatureDetached_2(SBGetObjectHandle(oSignature TSRMLS_CC), (int64_t)l8Count, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer) or (\\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_Certificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageVerifier_get_Certificates(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElMemoryCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_Attributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageVerifier_get_Attributes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Attributes_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_HashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageVerifier_get_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_MacAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageVerifier_get_MacAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_CertIDs)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageVerifier_get_CertIDs(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Issuer_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_CountersignatureCertIDs)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageVerifier_get_CountersignatureCertIDs(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Issuer_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_CountersignatureVerificationResults)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageVerifier_get_CountersignatureVerificationResults(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_CountersignatureAttributes)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageVerifier_get_CountersignatureAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Attributes_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_CertIDCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageVerifier_get_CertIDCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_CountersignatureCertIDCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageVerifier_get_CountersignatureCertIDCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_SignatureType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBMessageSignatureTypeRaw fOutResultRaw = 0;
		SBCheckError(TElMessageVerifier_get_SignatureType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_UsePSS)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageVerifier_get_UsePSS(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_InputIsDigest)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageVerifier_get_InputIsDigest(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, set_InputIsDigest)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageVerifier_set_InputIsDigest(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_Timestamps)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageVerifier_get_Timestamps(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElClientTSPInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_TimestampCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageVerifier_get_TimestampCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_SigningTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElMessageVerifier_get_SigningTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_CertStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageVerifier_get_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, set_CertStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessageVerifier_set_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_VerifyCountersignatures)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageVerifier_get_VerifyCountersignatures(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, set_VerifyCountersignatures)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageVerifier_set_VerifyCountersignatures(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_VerificationOptions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBVerificationOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElMessageVerifier_get_VerificationOptions(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, set_VerificationOptions)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElMessageVerifier_set_VerificationOptions(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBVerificationOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, get_OnCertIDs)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCertIDsEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElMessageVerifier_get_OnCertIDs(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, set_OnCertIDs)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElMessageVerifier_set_OnCertIDs(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCertIDsEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCertIDsEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageVerifier, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageVerifier_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_Verify, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, InBuffer_or_InStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InSize_or_OutStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_InCount, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_VerifyDetached, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Buffer_or_InStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Size_or_SigStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Signature_or_InCount, 0, 1)
	ZEND_ARG_INFO(0, SignatureSize_or_SigCount)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_IsSignatureDetached_Inst, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Signature, 0, 1)
	ZEND_ARG_INFO(0, Size_or_Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_IsSignatureDetached, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Signature, 0, 1)
	ZEND_ARG_INFO(0, Size_or_Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_Certificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_Attributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_HashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_MacAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_CertIDs, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_CountersignatureCertIDs, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_CountersignatureVerificationResults, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_CountersignatureAttributes, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_CertIDCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_CountersignatureCertIDCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_SignatureType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_UsePSS, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_InputIsDigest, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_set_InputIsDigest, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_Timestamps, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_TimestampCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_SigningTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_CertStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_set_CertStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_VerifyCountersignatures, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_set_VerifyCountersignatures, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_VerificationOptions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_set_VerificationOptions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_get_OnCertIDs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier_set_OnCertIDs, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageVerifier___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElMessageVerifier_methods[] = {
	PHP_ME(TElMessageVerifier, Verify, arginfo_TElMessageVerifier_Verify, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, VerifyDetached, arginfo_TElMessageVerifier_VerifyDetached, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, IsSignatureDetached_Inst, arginfo_TElMessageVerifier_IsSignatureDetached_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, IsSignatureDetached, arginfo_TElMessageVerifier_IsSignatureDetached, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElMessageVerifier, get_Certificates, arginfo_TElMessageVerifier_get_Certificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_Attributes, arginfo_TElMessageVerifier_get_Attributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_HashAlgorithm, arginfo_TElMessageVerifier_get_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_MacAlgorithm, arginfo_TElMessageVerifier_get_MacAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_CertIDs, arginfo_TElMessageVerifier_get_CertIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_CountersignatureCertIDs, arginfo_TElMessageVerifier_get_CountersignatureCertIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_CountersignatureVerificationResults, arginfo_TElMessageVerifier_get_CountersignatureVerificationResults, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_CountersignatureAttributes, arginfo_TElMessageVerifier_get_CountersignatureAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_CertIDCount, arginfo_TElMessageVerifier_get_CertIDCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_CountersignatureCertIDCount, arginfo_TElMessageVerifier_get_CountersignatureCertIDCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_SignatureType, arginfo_TElMessageVerifier_get_SignatureType, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_UsePSS, arginfo_TElMessageVerifier_get_UsePSS, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_InputIsDigest, arginfo_TElMessageVerifier_get_InputIsDigest, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, set_InputIsDigest, arginfo_TElMessageVerifier_set_InputIsDigest, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_Timestamps, arginfo_TElMessageVerifier_get_Timestamps, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_TimestampCount, arginfo_TElMessageVerifier_get_TimestampCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_SigningTime, arginfo_TElMessageVerifier_get_SigningTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_CertStorage, arginfo_TElMessageVerifier_get_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, set_CertStorage, arginfo_TElMessageVerifier_set_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_VerifyCountersignatures, arginfo_TElMessageVerifier_get_VerifyCountersignatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, set_VerifyCountersignatures, arginfo_TElMessageVerifier_set_VerifyCountersignatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_VerificationOptions, arginfo_TElMessageVerifier_get_VerificationOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, set_VerificationOptions, arginfo_TElMessageVerifier_set_VerificationOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, get_OnCertIDs, arginfo_TElMessageVerifier_get_OnCertIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, set_OnCertIDs, arginfo_TElMessageVerifier_set_OnCertIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageVerifier, __construct, arginfo_TElMessageVerifier___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMessageVerifier(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMessageVerifier_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMessageVerifier", TElMessageVerifier_methods);
	if (NULL == TElMessageProcessor_ce_ptr)
		Register_TElMessageProcessor(TSRMLS_C);
	TElMessageVerifier_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElMessageProcessor_ce_ptr);
}

zend_class_entry *TElMessageSigner_ce_ptr = NULL;

SB_PHP_METHOD(TElMessageSigner, Sign)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	sb_zend_long l8InCount;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	zend_bool bDetached;
	zval *oInStream;
	zval *oOutStream;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzb", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize, &bDetached) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElMessageSigner_Sign(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, (int8_t)bDetached, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!bl", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &bDetached, &l8InCount) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageSigner_Sign_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int8_t)bDetached, (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer, bool) or (\\TStream, \\TStream, bool, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, InitiateAsyncSign)
{
	int32_t l4OutSizeRaw;
	sb_zend_long fAsyncSignMethod;
	sb_zend_long l4InSize;
	sb_zend_long l8InCount;
	SBArrayZValInfo aiAdditionalData;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	TElClassHandle hoState;
	zend_bool bDetached;
	zval *oInStream;
	zval *oOutStream;
	zval *oPars;
	zval *oState;
	zval *zaAdditionalData;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzbO", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize, &bDetached, &oState, TElDCAsyncState_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, (int8_t)bDetached, &hoState, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzblO", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize, &bDetached, &fAsyncSignMethod, &oState, TElDCAsyncState_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_1(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, (int8_t)bDetached, (TSBDCAsyncSignMethodRaw)fAsyncSignMethod, &hoState, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzbO!zO", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize, &bDetached, &oPars, TElDCParameters_ce_ptr, &zaAdditionalData, &oState, TElDCAsyncState_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_2(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, (int8_t)bDetached, SBGetObjectHandle(oPars TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoState, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzbO!lzO", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize, &bDetached, &oPars, TElDCParameters_ce_ptr, &fAsyncSignMethod, &zaAdditionalData, &oState, TElDCAsyncState_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_3(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, (int8_t)bDetached, SBGetObjectHandle(oPars TSRMLS_CC), (TSBDCAsyncSignMethodRaw)fAsyncSignMethod, aiAdditionalData.data, aiAdditionalData.len, &hoState, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlbO", &zpInBuffer, &l4InSize, &bDetached, &oState, TElDCAsyncState_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_4(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, (int8_t)bDetached, &hoState, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlblO", &zpInBuffer, &l4InSize, &bDetached, &fAsyncSignMethod, &oState, TElDCAsyncState_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_5(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, (int8_t)bDetached, (TSBDCAsyncSignMethodRaw)fAsyncSignMethod, &hoState, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlbO!zO", &zpInBuffer, &l4InSize, &bDetached, &oPars, TElDCParameters_ce_ptr, &zaAdditionalData, &oState, TElDCAsyncState_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_6(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, (int8_t)bDetached, SBGetObjectHandle(oPars TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoState, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlbO!lzO", &zpInBuffer, &l4InSize, &bDetached, &oPars, TElDCParameters_ce_ptr, &fAsyncSignMethod, &zaAdditionalData, &oState, TElDCAsyncState_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_7(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, (int8_t)bDetached, SBGetObjectHandle(oPars TSRMLS_CC), (TSBDCAsyncSignMethodRaw)fAsyncSignMethod, aiAdditionalData.data, aiAdditionalData.len, &hoState, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!bOl", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &bDetached, &oState, TElDCAsyncState_ce_ptr, &l8InCount) == SUCCESS) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_8(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int8_t)bDetached, &hoState, (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!blOl", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &bDetached, &fAsyncSignMethod, &oState, TElDCAsyncState_ce_ptr, &l8InCount) == SUCCESS) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_9(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int8_t)bDetached, (TSBDCAsyncSignMethodRaw)fAsyncSignMethod, &hoState, (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!bO!zOl", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &bDetached, &oPars, TElDCParameters_ce_ptr, &zaAdditionalData, &oState, TElDCAsyncState_ce_ptr, &l8InCount) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_10(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int8_t)bDetached, SBGetObjectHandle(oPars TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoState, (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!bO!lzOl", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &bDetached, &oPars, TElDCParameters_ce_ptr, &fAsyncSignMethod, &zaAdditionalData, &oState, TElDCAsyncState_ce_ptr, &l8InCount) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_11(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int8_t)bDetached, SBGetObjectHandle(oPars TSRMLS_CC), (TSBDCAsyncSignMethodRaw)fAsyncSignMethod, aiAdditionalData.data, aiAdditionalData.len, &hoState, (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!bOl", &oInStream, TStream_ce_ptr, &bDetached, &oState, TElDCAsyncState_ce_ptr, &l8InCount) == SUCCESS) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_12(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), (int8_t)bDetached, &hoState, (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!blOl", &oInStream, TStream_ce_ptr, &bDetached, &fAsyncSignMethod, &oState, TElDCAsyncState_ce_ptr, &l8InCount) == SUCCESS) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_13(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), (int8_t)bDetached, (TSBDCAsyncSignMethodRaw)fAsyncSignMethod, &hoState, (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!bO!zOl", &oInStream, TStream_ce_ptr, &bDetached, &oPars, TElDCParameters_ce_ptr, &zaAdditionalData, &oState, TElDCAsyncState_ce_ptr, &l8InCount) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_14(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), (int8_t)bDetached, SBGetObjectHandle(oPars TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoState, (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!bO!lzOl", &oInStream, TStream_ce_ptr, &bDetached, &oPars, TElDCParameters_ce_ptr, &fAsyncSignMethod, &zaAdditionalData, &oState, TElDCAsyncState_ce_ptr, &l8InCount) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)) && SB_ISREF_OBJECT_P(oState))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		hoState = SBGetObjectHandle(oState TSRMLS_CC);
		SBCheckError(TElMessageSigner_InitiateAsyncSign_15(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), (int8_t)bDetached, SBGetObjectHandle(oPars TSRMLS_CC), (TSBDCAsyncSignMethodRaw)fAsyncSignMethod, aiAdditionalData.data, aiAdditionalData.len, &hoState, (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBUpdateObjectHandle(oState, hoState TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer, bool, &\\TElDCAsyncState) or (\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer, bool, integer, &\\TElDCAsyncState) or (\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer, bool, \\TElDCParameters, array of byte|string|NULL, &\\TElDCAsyncState) or (\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer, bool, \\TElDCParameters, integer, array of byte|string|NULL, &\\TElDCAsyncState) or (\\TSBPointer|array of byte|string|NULL, integer, bool, &\\TElDCAsyncState) or (\\TSBPointer|array of byte|string|NULL, integer, bool, integer, &\\TElDCAsyncState) or (\\TSBPointer|array of byte|string|NULL, integer, bool, \\TElDCParameters, array of byte|string|NULL, &\\TElDCAsyncState) or (\\TSBPointer|array of byte|string|NULL, integer, bool, \\TElDCParameters, integer, array of byte|string|NULL, &\\TElDCAsyncState) or (\\TStream, \\TStream, bool, &\\TElDCAsyncState, integer) or (\\TStream, \\TStream, bool, integer, &\\TElDCAsyncState, integer) or (\\TStream, \\TStream, bool, \\TElDCParameters, array of byte|string|NULL, &\\TElDCAsyncState, integer) or (\\TStream, \\TStream, bool, \\TElDCParameters, integer, array of byte|string|NULL, &\\TElDCAsyncState, integer) or (\\TStream, bool, &\\TElDCAsyncState, integer) or (\\TStream, bool, integer, &\\TElDCAsyncState, integer) or (\\TStream, bool, \\TElDCParameters, array of byte|string|NULL, &\\TElDCAsyncState, integer) or (\\TStream, bool, \\TElDCParameters, integer, array of byte|string|NULL, &\\TElDCAsyncState, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, CompleteAsyncSign)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	sb_zend_long l8InCount;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	zval *oAsyncState;
	zval *oInStream;
	zval *oOutStream;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzO!", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize, &oAsyncState, TElDCAsyncState_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElMessageSigner_CompleteAsyncSign(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, SBGetObjectHandle(oAsyncState TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzO!", &zpOutBuffer, &zl4OutSize, &oAsyncState, TElDCAsyncState_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElMessageSigner_CompleteAsyncSign_1(SBGetObjectHandle(getThis() TSRMLS_CC), piOutBuffer.data, &l4OutSizeRaw, SBGetObjectHandle(oAsyncState TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!l", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &oAsyncState, TElDCAsyncState_ce_ptr, &l8InCount) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageSigner_CompleteAsyncSign_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), SBGetObjectHandle(oAsyncState TSRMLS_CC), (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oOutStream, TStream_ce_ptr, &oAsyncState, TElDCAsyncState_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageSigner_CompleteAsyncSign_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), SBGetObjectHandle(oAsyncState TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer, \\TElDCAsyncState) or (\\TSBPointer|array of byte|string|NULL, &integer, \\TElDCAsyncState) or (\\TStream, \\TStream, \\TElDCAsyncState, integer) or (\\TStream, \\TElDCAsyncState)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, ExtractAdditionalDataFromAsyncState_Inst)
{
	uint32_t _err;
	zval *oState;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oState, TElDCAsyncState_ce_ptr) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElMessageSigner_ExtractAdditionalDataFromAsyncState_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oState TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1493819957, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDCAsyncState)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, ExtractAdditionalDataFromAsyncState)
{
	uint32_t _err;
	zval *oState;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oState, TElDCAsyncState_ce_ptr) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElMessageSigner_ExtractAdditionalDataFromAsyncState(SBGetObjectHandle(oState TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1493819957, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDCAsyncState)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, Countersign)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	sb_zend_long l8InCount;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	zval *oInStream;
	zval *oOutStream;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzz", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElMessageSigner_Countersign(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &l8InCount) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageSigner_Countersign_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer) or (\\TStream, \\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, Timestamp)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	sb_zend_long l8InCount;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	zval *oInStream;
	zval *oOutStream;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzz", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElMessageSigner_Timestamp(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &l8InCount) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageSigner_Timestamp_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer) or (\\TStream, \\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, TimestampCountersignature)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	sb_zend_long l4SigIndex;
	sb_zend_long l8InCount;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	zval *oInStream;
	zval *oOutStream;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzl", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize, &l4SigIndex) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElMessageSigner_TimestampCountersignature(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, (int32_t)l4SigIndex, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!ll", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &l4SigIndex, &l8InCount) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageSigner_TimestampCountersignature_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int32_t)l4SigIndex, (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer, integer) or (\\TStream, \\TStream, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_AuthenticatedAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageSigner_get_AuthenticatedAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Attributes_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_UnauthenticatedAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageSigner_get_UnauthenticatedAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPKCS7Attributes_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_HashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageSigner_get_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_HashAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElMessageSigner_set_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_MacAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageSigner_get_MacAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_MacAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElMessageSigner_set_MacAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_ContentType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElMessageSigner_get_ContentType(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1966822532, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_ContentType)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMessageSigner_set_ContentType(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_DataHash)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElMessageSigner_get_DataHash(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(216493652, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_DigestEncryptionAlgorithm)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElMessageSigner_get_DigestEncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1542524589, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_DigestEncryptionAlgorithm)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMessageSigner_set_DigestEncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_SigningTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElMessageSigner_get_SigningTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_SigningTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElMessageSigner_set_SigningTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_SignatureType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBMessageSignatureTypeRaw fOutResultRaw = 0;
		SBCheckError(TElMessageSigner_get_SignatureType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_SignatureType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElMessageSigner_set_SignatureType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBMessageSignatureTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_CertStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageSigner_get_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_CertStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessageSigner_set_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_IncludeCertificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageSigner_get_IncludeCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_IncludeCertificates)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageSigner_set_IncludeCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_IncludeChain)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageSigner_get_IncludeChain(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_IncludeChain)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageSigner_set_IncludeChain(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_RecipientCerts)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageSigner_get_RecipientCerts(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_RecipientCerts)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessageSigner_set_RecipientCerts(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_UseUndefSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageSigner_get_UseUndefSize(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_UseUndefSize)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageSigner_set_UseUndefSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_UsePSS)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageSigner_get_UsePSS(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_UsePSS)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageSigner_set_UsePSS(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_SigningOptions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSigningOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElMessageSigner_get_SigningOptions(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_SigningOptions)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElMessageSigner_set_SigningOptions(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSigningOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_ExtraSpace)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageSigner_get_ExtraSpace(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_ExtraSpace)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElMessageSigner_set_ExtraSpace(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_InputIsHash)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageSigner_get_InputIsHash(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_InputIsHash)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageSigner_set_InputIsHash(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, get_TSPClient)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageSigner_get_TSPClient(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomTSPClient_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, set_TSPClient)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessageSigner_set_TSPClient(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageSigner, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageSigner_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_Sign, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, InBuffer_or_InStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InSize_or_OutStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_Detached, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_InCount)
	ZEND_ARG_INFO(0, Detached)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_InitiateAsyncSign, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, InBuffer_or_InStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InSize_or_OutStream_or_Detached, 0, 1)
	ZEND_ARG_TYPE_INFO(1, OutBuffer_or_Detached_or_State_or_AsyncSignMethod_or_Pars, 0, 1)
	ZEND_ARG_TYPE_INFO(1, OutSize_or_State_or_AsyncSignMethod_or_Pars_or_InCount_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(1, Detached_or_State_or_AdditionalData_or_AsyncSignMethod_or_InCount, 0, 1)
	ZEND_ARG_TYPE_INFO(1, State_or_AsyncSignMethod_or_Pars_or_AdditionalData_or_InCount, 0, 1)
	ZEND_ARG_TYPE_INFO(1, State_or_AdditionalData_or_AsyncSignMethod_or_InCount, 0, 1)
	ZEND_ARG_TYPE_INFO(1, State_or_AdditionalData_or_InCount, 0, 1)
	ZEND_ARG_OBJ_INFO(1, State, TElDCAsyncState, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_CompleteAsyncSign, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, InBuffer_or_OutBuffer_or_InStream_or_OutStream, 0, 1)
	ZEND_ARG_TYPE_INFO(1, InSize_or_OutSize_or_OutStream_or_AsyncState, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_AsyncState, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_InCount)
	ZEND_ARG_OBJ_INFO(0, AsyncState, TElDCAsyncState, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_ExtractAdditionalDataFromAsyncState_Inst, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, State, TElDCAsyncState, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_ExtractAdditionalDataFromAsyncState, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, State, TElDCAsyncState, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_Countersign, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, InBuffer_or_InStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InSize_or_OutStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_InCount, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_Timestamp, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, InBuffer_or_InStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InSize_or_OutStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_InCount, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_TimestampCountersignature, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, InBuffer_or_InStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InSize_or_OutStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_SigIndex, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_InCount)
	ZEND_ARG_INFO(0, SigIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_AuthenticatedAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_UnauthenticatedAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_HashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_HashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_MacAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_MacAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_ContentType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_ContentType, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_DataHash, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_DigestEncryptionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_DigestEncryptionAlgorithm, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_SigningTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_SigningTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_SignatureType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_SignatureType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_CertStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_CertStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_IncludeCertificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_IncludeCertificates, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_IncludeChain, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_IncludeChain, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_RecipientCerts, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_RecipientCerts, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_UseUndefSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_UseUndefSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_UsePSS, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_UsePSS, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_SigningOptions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_SigningOptions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_ExtraSpace, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_ExtraSpace, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_InputIsHash, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_InputIsHash, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_get_TSPClient, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner_set_TSPClient, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageSigner___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElMessageSigner_methods[] = {
	PHP_ME(TElMessageSigner, Sign, arginfo_TElMessageSigner_Sign, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, InitiateAsyncSign, arginfo_TElMessageSigner_InitiateAsyncSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, CompleteAsyncSign, arginfo_TElMessageSigner_CompleteAsyncSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, ExtractAdditionalDataFromAsyncState_Inst, arginfo_TElMessageSigner_ExtractAdditionalDataFromAsyncState_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, ExtractAdditionalDataFromAsyncState, arginfo_TElMessageSigner_ExtractAdditionalDataFromAsyncState, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElMessageSigner, Countersign, arginfo_TElMessageSigner_Countersign, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, Timestamp, arginfo_TElMessageSigner_Timestamp, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, TimestampCountersignature, arginfo_TElMessageSigner_TimestampCountersignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_AuthenticatedAttributes, arginfo_TElMessageSigner_get_AuthenticatedAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_UnauthenticatedAttributes, arginfo_TElMessageSigner_get_UnauthenticatedAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_HashAlgorithm, arginfo_TElMessageSigner_get_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_HashAlgorithm, arginfo_TElMessageSigner_set_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_MacAlgorithm, arginfo_TElMessageSigner_get_MacAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_MacAlgorithm, arginfo_TElMessageSigner_set_MacAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_ContentType, arginfo_TElMessageSigner_get_ContentType, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_ContentType, arginfo_TElMessageSigner_set_ContentType, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_DataHash, arginfo_TElMessageSigner_get_DataHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_DigestEncryptionAlgorithm, arginfo_TElMessageSigner_get_DigestEncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_DigestEncryptionAlgorithm, arginfo_TElMessageSigner_set_DigestEncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_SigningTime, arginfo_TElMessageSigner_get_SigningTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_SigningTime, arginfo_TElMessageSigner_set_SigningTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_SignatureType, arginfo_TElMessageSigner_get_SignatureType, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_SignatureType, arginfo_TElMessageSigner_set_SignatureType, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_CertStorage, arginfo_TElMessageSigner_get_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_CertStorage, arginfo_TElMessageSigner_set_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_IncludeCertificates, arginfo_TElMessageSigner_get_IncludeCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_IncludeCertificates, arginfo_TElMessageSigner_set_IncludeCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_IncludeChain, arginfo_TElMessageSigner_get_IncludeChain, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_IncludeChain, arginfo_TElMessageSigner_set_IncludeChain, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_RecipientCerts, arginfo_TElMessageSigner_get_RecipientCerts, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_RecipientCerts, arginfo_TElMessageSigner_set_RecipientCerts, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_UseUndefSize, arginfo_TElMessageSigner_get_UseUndefSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_UseUndefSize, arginfo_TElMessageSigner_set_UseUndefSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_UsePSS, arginfo_TElMessageSigner_get_UsePSS, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_UsePSS, arginfo_TElMessageSigner_set_UsePSS, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_SigningOptions, arginfo_TElMessageSigner_get_SigningOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_SigningOptions, arginfo_TElMessageSigner_set_SigningOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_ExtraSpace, arginfo_TElMessageSigner_get_ExtraSpace, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_ExtraSpace, arginfo_TElMessageSigner_set_ExtraSpace, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_InputIsHash, arginfo_TElMessageSigner_get_InputIsHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_InputIsHash, arginfo_TElMessageSigner_set_InputIsHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, get_TSPClient, arginfo_TElMessageSigner_get_TSPClient, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, set_TSPClient, arginfo_TElMessageSigner_set_TSPClient, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageSigner, __construct, arginfo_TElMessageSigner___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMessageSigner(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMessageSigner_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMessageSigner", TElMessageSigner_methods);
	if (NULL == TElMessageProcessor_ce_ptr)
		Register_TElMessageProcessor(TSRMLS_C);
	TElMessageSigner_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElMessageProcessor_ce_ptr);
}

zend_class_entry *TElMessageDecompressor_ce_ptr = NULL;

SB_PHP_METHOD(TElMessageDecompressor, Decompress)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	sb_zend_long l8InCount;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	zval *oInStream;
	zval *oOutStream;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzz", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElMessageDecompressor_Decompress(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &l8InCount) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageDecompressor_Decompress_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer) or (\\TStream, \\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecompressor, get_ContentType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElMessageDecompressor_get_ContentType(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-434653365, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageDecompressor, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageDecompressor_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecompressor_Decompress, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, InBuffer_or_InStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InSize_or_OutStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_InCount, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecompressor_get_ContentType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageDecompressor___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElMessageDecompressor_methods[] = {
	PHP_ME(TElMessageDecompressor, Decompress, arginfo_TElMessageDecompressor_Decompress, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecompressor, get_ContentType, arginfo_TElMessageDecompressor_get_ContentType, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageDecompressor, __construct, arginfo_TElMessageDecompressor___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMessageDecompressor(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMessageDecompressor_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMessageDecompressor", TElMessageDecompressor_methods);
	if (NULL == TElMessageProcessor_ce_ptr)
		Register_TElMessageProcessor(TSRMLS_C);
	TElMessageDecompressor_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElMessageProcessor_ce_ptr);
}

zend_class_entry *TElMessageCompressor_ce_ptr = NULL;

SB_PHP_METHOD(TElMessageCompressor, Compress)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	sb_zend_long l8InCount;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	zval *oInStream;
	zval *oOutStream;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzz", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElMessageCompressor_Compress(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &l8InCount) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageCompressor_Compress_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer) or (\\TStream, \\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageCompressor, get_ContentType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElMessageCompressor_get_ContentType(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(2094700661, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageCompressor, set_ContentType)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMessageCompressor_set_ContentType(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageCompressor, get_CompressionLevel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageCompressor_get_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageCompressor, set_CompressionLevel)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElMessageCompressor_set_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageCompressor, get_FragmentSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageCompressor_get_FragmentSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageCompressor, set_FragmentSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElMessageCompressor_set_FragmentSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageCompressor, get_UseUndefSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageCompressor_get_UseUndefSize(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageCompressor, set_UseUndefSize)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageCompressor_set_UseUndefSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageCompressor, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageCompressor_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageCompressor_Compress, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, InBuffer_or_InStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InSize_or_OutStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_InCount, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageCompressor_get_ContentType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageCompressor_set_ContentType, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageCompressor_get_CompressionLevel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageCompressor_set_CompressionLevel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageCompressor_get_FragmentSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageCompressor_set_FragmentSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageCompressor_get_UseUndefSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageCompressor_set_UseUndefSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageCompressor___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElMessageCompressor_methods[] = {
	PHP_ME(TElMessageCompressor, Compress, arginfo_TElMessageCompressor_Compress, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageCompressor, get_ContentType, arginfo_TElMessageCompressor_get_ContentType, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageCompressor, set_ContentType, arginfo_TElMessageCompressor_set_ContentType, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageCompressor, get_CompressionLevel, arginfo_TElMessageCompressor_get_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageCompressor, set_CompressionLevel, arginfo_TElMessageCompressor_set_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageCompressor, get_FragmentSize, arginfo_TElMessageCompressor_get_FragmentSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageCompressor, set_FragmentSize, arginfo_TElMessageCompressor_set_FragmentSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageCompressor, get_UseUndefSize, arginfo_TElMessageCompressor_get_UseUndefSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageCompressor, set_UseUndefSize, arginfo_TElMessageCompressor_set_UseUndefSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageCompressor, __construct, arginfo_TElMessageCompressor___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMessageCompressor(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMessageCompressor_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMessageCompressor", TElMessageCompressor_methods);
	if (NULL == TElMessageProcessor_ce_ptr)
		Register_TElMessageProcessor(TSRMLS_C);
	TElMessageCompressor_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElMessageProcessor_ce_ptr);
}

zend_class_entry *TElMessageTimestamper_ce_ptr = NULL;

SB_PHP_METHOD(TElMessageTimestamper, Timestamp)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	sb_zend_long l8InCount;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	zval *oInStream;
	zval *oOutStream;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzz", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElMessageTimestamper_Timestamp(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &l8InCount) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageTimestamper_Timestamp_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer) or (\\TStream, \\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, AddTSPClient)
{
	zval *oClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageTimestamper_AddTSPClient(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oClient TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, RemoveTSPClient)
{
	sb_zend_long l4Index;
	zval *oClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElMessageTimestamper_RemoveTSPClient(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessageTimestamper_RemoveTSPClient_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer) or (\\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, get_TSPClients)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageTimestamper_get_TSPClients(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomTSPClient_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, get_TSPClientsCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageTimestamper_get_TSPClientsCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, get_TSPClient)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageTimestamper_get_TSPClient(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomTSPClient_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, set_TSPClient)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessageTimestamper_set_TSPClient(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, get_IncludeContent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageTimestamper_get_IncludeContent(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, set_IncludeContent)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageTimestamper_set_IncludeContent(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, get_ProtectMetadata)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageTimestamper_get_ProtectMetadata(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, set_ProtectMetadata)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageTimestamper_set_ProtectMetadata(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, get_DataURI)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElMessageTimestamper_get_DataURI(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1723008449, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, set_DataURI)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElMessageTimestamper_set_DataURI(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, get_FileName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElMessageTimestamper_get_FileName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-355479255, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, set_FileName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElMessageTimestamper_set_FileName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, get_MediaType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElMessageTimestamper_get_MediaType(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1185520154, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, set_MediaType)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElMessageTimestamper_set_MediaType(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, get_UseUndefSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessageTimestamper_get_UseUndefSize(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, set_UseUndefSize)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessageTimestamper_set_UseUndefSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestamper, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageTimestamper_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_Timestamp, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, InBuffer_or_InStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InSize_or_OutStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_InCount, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_AddTSPClient, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Client, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_RemoveTSPClient, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Index_or_Client, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_get_TSPClients, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_get_TSPClientsCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_get_TSPClient, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_set_TSPClient, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_get_IncludeContent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_set_IncludeContent, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_get_ProtectMetadata, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_set_ProtectMetadata, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_get_DataURI, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_set_DataURI, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_get_FileName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_set_FileName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_get_MediaType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_set_MediaType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_get_UseUndefSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper_set_UseUndefSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestamper___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElMessageTimestamper_methods[] = {
	PHP_ME(TElMessageTimestamper, Timestamp, arginfo_TElMessageTimestamper_Timestamp, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, AddTSPClient, arginfo_TElMessageTimestamper_AddTSPClient, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, RemoveTSPClient, arginfo_TElMessageTimestamper_RemoveTSPClient, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, get_TSPClients, arginfo_TElMessageTimestamper_get_TSPClients, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, get_TSPClientsCount, arginfo_TElMessageTimestamper_get_TSPClientsCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, get_TSPClient, arginfo_TElMessageTimestamper_get_TSPClient, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, set_TSPClient, arginfo_TElMessageTimestamper_set_TSPClient, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, get_IncludeContent, arginfo_TElMessageTimestamper_get_IncludeContent, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, set_IncludeContent, arginfo_TElMessageTimestamper_set_IncludeContent, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, get_ProtectMetadata, arginfo_TElMessageTimestamper_get_ProtectMetadata, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, set_ProtectMetadata, arginfo_TElMessageTimestamper_set_ProtectMetadata, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, get_DataURI, arginfo_TElMessageTimestamper_get_DataURI, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, set_DataURI, arginfo_TElMessageTimestamper_set_DataURI, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, get_FileName, arginfo_TElMessageTimestamper_get_FileName, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, set_FileName, arginfo_TElMessageTimestamper_set_FileName, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, get_MediaType, arginfo_TElMessageTimestamper_get_MediaType, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, set_MediaType, arginfo_TElMessageTimestamper_set_MediaType, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, get_UseUndefSize, arginfo_TElMessageTimestamper_get_UseUndefSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, set_UseUndefSize, arginfo_TElMessageTimestamper_set_UseUndefSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestamper, __construct, arginfo_TElMessageTimestamper___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMessageTimestamper(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMessageTimestamper_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMessageTimestamper", TElMessageTimestamper_methods);
	if (NULL == TElMessageProcessor_ce_ptr)
		Register_TElMessageProcessor(TSRMLS_C);
	TElMessageTimestamper_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElMessageProcessor_ce_ptr);
}

zend_class_entry *TElMessageTimestampVerifier_ce_ptr = NULL;

SB_PHP_METHOD(TElMessageTimestampVerifier, Verify)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	sb_zend_long l8InCount;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	zval *oInStream;
	zval *oOutStream;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzz", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElMessageTimestampVerifier_Verify(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oInStream, TStream_ce_ptr, &oOutStream, TStream_ce_ptr, &l8InCount) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageTimestampVerifier_Verify_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oOutStream TSRMLS_CC), (int64_t)l8InCount, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer) or (\\TStream, \\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestampVerifier, VerifyDetached)
{
	sb_zend_long l4DataSize;
	sb_zend_long l4Size;
	sb_zend_long l8DataCount;
	sb_zend_long l8InCount;
	SBArrayZValInfo piBuffer;
	SBArrayZValInfo piData;
	zval *oDataStream;
	zval *oInStream;
	zval *zpBuffer;
	zval *zpData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzl", &zpBuffer, &l4Size, &zpData, &l4DataSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpData) || SB_IS_ARRAY_TYPE_RP(zpData) || SB_IS_NULL_TYPE_RP(zpData) || (SB_IS_OBJECT_TYPE_RP(zpData) && (Z_OBJCE_P(zpData) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpData, &piData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMessageTimestampVerifier_VerifyDetached(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, piData.data, (int32_t)l4DataSize, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		SBFreePointerZValInfo(&piData);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!ll", &oInStream, TStream_ce_ptr, &oDataStream, TStream_ce_ptr, &l8InCount, &l8DataCount) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageTimestampVerifier_VerifyDetached_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oInStream TSRMLS_CC), SBGetObjectHandle(oDataStream TSRMLS_CC), (int64_t)l8InCount, (int64_t)l8DataCount, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, integer) or (\\TStream, \\TStream, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestampVerifier, IsTimestampDetached_Inst)
{
	char *sDataURI;
	char *sFileName;
	int32_t sDataURI_len;
	int32_t sFileName_len;
	sb_zend_long l4Size;
	sb_zend_long l8Count;
	SBArrayZValInfo piTimestamp;
	uint32_t _err;
	zval *oTimestamp;
	zval *zpTimestamp;
	zval *zsDataURI;
	zval *zsFileName;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzz", &zpTimestamp, &l4Size, &zsDataURI, &zsFileName) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpTimestamp) || SB_IS_ARRAY_TYPE_RP(zpTimestamp) || SB_IS_NULL_TYPE_RP(zpTimestamp) || (SB_IS_OBJECT_TYPE_RP(zpTimestamp) && (Z_OBJCE_P(zpTimestamp) == TSBPointer_ce_ptr))) && Z_ISREF_P(zsDataURI) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsDataURI))) && Z_ISREF_P(zsFileName) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsFileName))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpTimestamp, &piTimestamp TSRMLS_CC)) RETURN_FALSE;
		sDataURI = Z_STRVAL_P(Z_REFVAL_P(zsDataURI));
		sDataURI_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsDataURI));
		sFileName = Z_STRVAL_P(Z_REFVAL_P(zsFileName));
		sFileName_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsFileName));
		_err = TElMessageTimestampVerifier_IsTimestampDetached_1(SBGetObjectHandle(getThis() TSRMLS_CC), piTimestamp.data, (int32_t)l4Size, sDataURI, &sDataURI_len, sFileName, &sFileName_len, &bOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sDataURI = emalloc(sDataURI_len + 1);
			SBCheckError(SBGetLastReturnStringA(901351290, 3, sDataURI, &sDataURI_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsDataURI));
			sFileName = emalloc(sFileName_len + 1);
			SBCheckError(SBGetLastReturnStringA(901351290, 4, sFileName, &sFileName_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsFileName));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piTimestamp);
		sDataURI[sDataURI_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsDataURI), sDataURI, sDataURI_len);
		sFileName[sFileName_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsFileName), sFileName, sFileName_len);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zzl", &oTimestamp, TStream_ce_ptr, &zsDataURI, &zsFileName, &l8Count) == SUCCESS) && Z_ISREF_P(zsDataURI) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsDataURI))) && Z_ISREF_P(zsFileName) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsFileName))))
	{
		int8_t bOutResultRaw = 0;
		sDataURI = Z_STRVAL_P(Z_REFVAL_P(zsDataURI));
		sDataURI_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsDataURI));
		sFileName = Z_STRVAL_P(Z_REFVAL_P(zsFileName));
		sFileName_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsFileName));
		_err = TElMessageTimestampVerifier_IsTimestampDetached_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTimestamp TSRMLS_CC), sDataURI, &sDataURI_len, sFileName, &sFileName_len, (int64_t)l8Count, &bOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sDataURI = emalloc(sDataURI_len + 1);
			SBCheckError(SBGetLastReturnStringA(248864784, 2, sDataURI, &sDataURI_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsDataURI));
			sFileName = emalloc(sFileName_len + 1);
			SBCheckError(SBGetLastReturnStringA(248864784, 3, sFileName, &sFileName_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsFileName));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sDataURI[sDataURI_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsDataURI), sDataURI, sDataURI_len);
		sFileName[sFileName_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsFileName), sFileName, sFileName_len);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, &string, &string) or (\\TStream, &string, &string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestampVerifier, IsTimestampDetached)
{
	char *sDataURI;
	char *sFileName;
	int32_t sDataURI_len;
	int32_t sFileName_len;
	sb_zend_long l4Size;
	sb_zend_long l8Count;
	SBArrayZValInfo piTimestamp;
	uint32_t _err;
	zval *oTimestamp;
	zval *zpTimestamp;
	zval *zsDataURI;
	zval *zsFileName;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzz", &zpTimestamp, &l4Size, &zsDataURI, &zsFileName) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpTimestamp) || SB_IS_ARRAY_TYPE_RP(zpTimestamp) || SB_IS_NULL_TYPE_RP(zpTimestamp) || (SB_IS_OBJECT_TYPE_RP(zpTimestamp) && (Z_OBJCE_P(zpTimestamp) == TSBPointer_ce_ptr))) && Z_ISREF_P(zsDataURI) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsDataURI))) && Z_ISREF_P(zsFileName) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsFileName))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpTimestamp, &piTimestamp TSRMLS_CC)) RETURN_FALSE;
		sDataURI = Z_STRVAL_P(Z_REFVAL_P(zsDataURI));
		sDataURI_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsDataURI));
		sFileName = Z_STRVAL_P(Z_REFVAL_P(zsFileName));
		sFileName_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsFileName));
		_err = TElMessageTimestampVerifier_IsTimestampDetached(piTimestamp.data, (int32_t)l4Size, sDataURI, &sDataURI_len, sFileName, &sFileName_len, &bOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sDataURI = emalloc(sDataURI_len + 1);
			SBCheckError(SBGetLastReturnStringA(901351290, 2, sDataURI, &sDataURI_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsDataURI));
			sFileName = emalloc(sFileName_len + 1);
			SBCheckError(SBGetLastReturnStringA(901351290, 3, sFileName, &sFileName_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsFileName));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piTimestamp);
		sDataURI[sDataURI_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsDataURI), sDataURI, sDataURI_len);
		sFileName[sFileName_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsFileName), sFileName, sFileName_len);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zzl", &oTimestamp, TStream_ce_ptr, &zsDataURI, &zsFileName, &l8Count) == SUCCESS) && Z_ISREF_P(zsDataURI) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsDataURI))) && Z_ISREF_P(zsFileName) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsFileName))))
	{
		int8_t bOutResultRaw = 0;
		sDataURI = Z_STRVAL_P(Z_REFVAL_P(zsDataURI));
		sDataURI_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsDataURI));
		sFileName = Z_STRVAL_P(Z_REFVAL_P(zsFileName));
		sFileName_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsFileName));
		_err = TElMessageTimestampVerifier_IsTimestampDetached_2(SBGetObjectHandle(oTimestamp TSRMLS_CC), sDataURI, &sDataURI_len, sFileName, &sFileName_len, (int64_t)l8Count, &bOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sDataURI = emalloc(sDataURI_len + 1);
			SBCheckError(SBGetLastReturnStringA(248864784, 1, sDataURI, &sDataURI_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsDataURI));
			sFileName = emalloc(sFileName_len + 1);
			SBCheckError(SBGetLastReturnStringA(248864784, 2, sFileName, &sFileName_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsFileName));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sDataURI[sDataURI_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsDataURI), sDataURI, sDataURI_len);
		sFileName[sFileName_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsFileName), sFileName, sFileName_len);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, &string, &string) or (\\TStream, &string, &string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestampVerifier, get_Timestamps)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageTimestampVerifier_get_Timestamps(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElClientTSPInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestampVerifier, get_TimestampCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessageTimestampVerifier_get_TimestampCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestampVerifier, get_DataURI)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElMessageTimestampVerifier_get_DataURI(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1774625349, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestampVerifier, get_FileName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElMessageTimestampVerifier_get_FileName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1434551, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestampVerifier, get_MediaType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElMessageTimestampVerifier_get_MediaType(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1375010411, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessageTimestampVerifier, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessageTimestampVerifier_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestampVerifier_Verify, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, InBuffer_or_InStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, InSize_or_OutStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, OutBuffer_or_InCount, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestampVerifier_VerifyDetached, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Buffer_or_InStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Size_or_DataStream, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data_or_InCount, 0, 1)
	ZEND_ARG_INFO(0, DataSize_or_DataCount)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestampVerifier_IsTimestampDetached_Inst, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Timestamp, 0, 1)
	ZEND_ARG_INFO(1, Size_or_DataURI)
	ZEND_ARG_INFO(1, DataURI_or_FileName)
	ZEND_ARG_INFO(1, FileName_or_Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestampVerifier_IsTimestampDetached, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, Timestamp, 0, 1)
	ZEND_ARG_INFO(1, Size_or_DataURI)
	ZEND_ARG_INFO(1, DataURI_or_FileName)
	ZEND_ARG_INFO(1, FileName_or_Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestampVerifier_get_Timestamps, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestampVerifier_get_TimestampCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestampVerifier_get_DataURI, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestampVerifier_get_FileName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestampVerifier_get_MediaType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessageTimestampVerifier___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElMessageTimestampVerifier_methods[] = {
	PHP_ME(TElMessageTimestampVerifier, Verify, arginfo_TElMessageTimestampVerifier_Verify, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestampVerifier, VerifyDetached, arginfo_TElMessageTimestampVerifier_VerifyDetached, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestampVerifier, IsTimestampDetached_Inst, arginfo_TElMessageTimestampVerifier_IsTimestampDetached_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestampVerifier, IsTimestampDetached, arginfo_TElMessageTimestampVerifier_IsTimestampDetached, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElMessageTimestampVerifier, get_Timestamps, arginfo_TElMessageTimestampVerifier_get_Timestamps, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestampVerifier, get_TimestampCount, arginfo_TElMessageTimestampVerifier_get_TimestampCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestampVerifier, get_DataURI, arginfo_TElMessageTimestampVerifier_get_DataURI, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestampVerifier, get_FileName, arginfo_TElMessageTimestampVerifier_get_FileName, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestampVerifier, get_MediaType, arginfo_TElMessageTimestampVerifier_get_MediaType, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessageTimestampVerifier, __construct, arginfo_TElMessageTimestampVerifier___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMessageTimestampVerifier(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMessageTimestampVerifier_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMessageTimestampVerifier", TElMessageTimestampVerifier_methods);
	if (NULL == TElMessageProcessor_ce_ptr)
		Register_TElMessageProcessor(TSRMLS_C);
	TElMessageTimestampVerifier_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElMessageProcessor_ce_ptr);
}

void Register_SBMessages_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBMessages, ERROR_FACILITY_CMSBASE, SB_ERROR_FACILITY_CMSBASE, SB_ERROR_FACILITY_CMSBASE);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_NO_ENCRYPTED_DATA, SB_MESSAGE_ERROR_NO_ENCRYPTED_DATA, SB_MESSAGE_ERROR_NO_ENCRYPTED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_NO_CERTIFICATE, SB_MESSAGE_ERROR_NO_CERTIFICATE, SB_MESSAGE_ERROR_NO_CERTIFICATE);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_KEY_DECRYPTION_FAILED, SB_MESSAGE_ERROR_KEY_DECRYPTION_FAILED, SB_MESSAGE_ERROR_KEY_DECRYPTION_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_BUFFER_TOO_SMALL, SB_MESSAGE_ERROR_BUFFER_TOO_SMALL, SB_MESSAGE_ERROR_BUFFER_TOO_SMALL);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_CONTENT_DECRYPTION_FAILED, SB_MESSAGE_ERROR_CONTENT_DECRYPTION_FAILED, SB_MESSAGE_ERROR_CONTENT_DECRYPTION_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_INVALID_FORMAT, SB_MESSAGE_ERROR_INVALID_FORMAT, SB_MESSAGE_ERROR_INVALID_FORMAT);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_NO_RECIPIENTS, SB_MESSAGE_ERROR_NO_RECIPIENTS, SB_MESSAGE_ERROR_NO_RECIPIENTS);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_UNSUPPORTED_ALGORITHM, SB_MESSAGE_ERROR_UNSUPPORTED_ALGORITHM, SB_MESSAGE_ERROR_UNSUPPORTED_ALGORITHM);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_ENCRYPTION_FAILED, SB_MESSAGE_ERROR_ENCRYPTION_FAILED, SB_MESSAGE_ERROR_ENCRYPTION_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_INVALID_KEY_LENGTH, SB_MESSAGE_ERROR_INVALID_KEY_LENGTH, SB_MESSAGE_ERROR_INVALID_KEY_LENGTH);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_NO_SIGNED_DATA, SB_MESSAGE_ERROR_NO_SIGNED_DATA, SB_MESSAGE_ERROR_NO_SIGNED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_INVALID_SIGNATURE, SB_MESSAGE_ERROR_INVALID_SIGNATURE, SB_MESSAGE_ERROR_INVALID_SIGNATURE);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_INVALID_DIGEST, SB_MESSAGE_ERROR_INVALID_DIGEST, SB_MESSAGE_ERROR_INVALID_DIGEST);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_SIGNING_FAILED, SB_MESSAGE_ERROR_SIGNING_FAILED, SB_MESSAGE_ERROR_SIGNING_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_INTERNAL_ERROR, SB_MESSAGE_ERROR_INTERNAL_ERROR, SB_MESSAGE_ERROR_INTERNAL_ERROR);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_INVALID_MAC, SB_MESSAGE_ERROR_INVALID_MAC, SB_MESSAGE_ERROR_INVALID_MAC);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_UNSUPPORTED_SIGNATURE_TYPE, SB_MESSAGE_ERROR_UNSUPPORTED_SIGNATURE_TYPE, SB_MESSAGE_ERROR_UNSUPPORTED_SIGNATURE_TYPE);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_INVALID_COUNTERSIGNATURE, SB_MESSAGE_ERROR_INVALID_COUNTERSIGNATURE, SB_MESSAGE_ERROR_INVALID_COUNTERSIGNATURE);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_DIGEST_NOT_FOUND, SB_MESSAGE_ERROR_DIGEST_NOT_FOUND, SB_MESSAGE_ERROR_DIGEST_NOT_FOUND);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_UNSUPPORTED_DIGEST_ALGORITHM, SB_MESSAGE_ERROR_UNSUPPORTED_DIGEST_ALGORITHM, SB_MESSAGE_ERROR_UNSUPPORTED_DIGEST_ALGORITHM);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_CANCELLED_BY_USER, SB_MESSAGE_ERROR_CANCELLED_BY_USER, SB_MESSAGE_ERROR_CANCELLED_BY_USER);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_VERIFICATION_FAILED, SB_MESSAGE_ERROR_VERIFICATION_FAILED, SB_MESSAGE_ERROR_VERIFICATION_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_DIGEST_CALCULATION_FAILED, SB_MESSAGE_ERROR_DIGEST_CALCULATION_FAILED, SB_MESSAGE_ERROR_DIGEST_CALCULATION_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_MAC_CALCULATION_FAILED, SB_MESSAGE_ERROR_MAC_CALCULATION_FAILED, SB_MESSAGE_ERROR_MAC_CALCULATION_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_TSPCLIENT_NOT_FOUND, SB_MESSAGE_ERROR_TSPCLIENT_NOT_FOUND, SB_MESSAGE_ERROR_TSPCLIENT_NOT_FOUND);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_BAD_TIMESTAMP, SB_MESSAGE_ERROR_BAD_TIMESTAMP, SB_MESSAGE_ERROR_BAD_TIMESTAMP);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_KEYOP_FAILED_RSA, SB_MESSAGE_ERROR_KEYOP_FAILED_RSA, SB_MESSAGE_ERROR_KEYOP_FAILED_RSA);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_KEYOP_FAILED_DSA, SB_MESSAGE_ERROR_KEYOP_FAILED_DSA, SB_MESSAGE_ERROR_KEYOP_FAILED_DSA);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_KEYOP_FAILED_RSA_PSS, SB_MESSAGE_ERROR_KEYOP_FAILED_RSA_PSS, SB_MESSAGE_ERROR_KEYOP_FAILED_RSA_PSS);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_NO_COMPRESSED_DATA, SB_MESSAGE_ERROR_NO_COMPRESSED_DATA, SB_MESSAGE_ERROR_NO_COMPRESSED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_KEYOP_FAILED_EC, SB_MESSAGE_ERROR_KEYOP_FAILED_EC, SB_MESSAGE_ERROR_KEYOP_FAILED_EC);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_DC_BAD_ASYNC_STATE, SB_MESSAGE_ERROR_DC_BAD_ASYNC_STATE, SB_MESSAGE_ERROR_DC_BAD_ASYNC_STATE);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_DC_SERVER_ERROR, SB_MESSAGE_ERROR_DC_SERVER_ERROR, SB_MESSAGE_ERROR_DC_SERVER_ERROR);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_DC_MODULE_UNAVAILABLE, SB_MESSAGE_ERROR_DC_MODULE_UNAVAILABLE, SB_MESSAGE_ERROR_DC_MODULE_UNAVAILABLE);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_KEYOP_FAILED_GOST, SB_MESSAGE_ERROR_KEYOP_FAILED_GOST, SB_MESSAGE_ERROR_KEYOP_FAILED_GOST);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_NO_CONTENT_OR_DATA_URI, SB_MESSAGE_ERROR_NO_CONTENT_OR_DATA_URI, SB_MESSAGE_ERROR_NO_CONTENT_OR_DATA_URI);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_TIMESTAMPING_FAILED, SB_MESSAGE_ERROR_TIMESTAMPING_FAILED, SB_MESSAGE_ERROR_TIMESTAMPING_FAILED);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_NO_TIMESTAMPED_DATA, SB_MESSAGE_ERROR_NO_TIMESTAMPED_DATA, SB_MESSAGE_ERROR_NO_TIMESTAMPED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_ASN_LIMIT_EXCEEDED, SB_MESSAGE_ERROR_ASN_LIMIT_EXCEEDED, SB_MESSAGE_ERROR_ASN_LIMIT_EXCEEDED);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_DATA_NOT_AVAILABLE, SB_MESSAGE_ERROR_DATA_NOT_AVAILABLE, SB_MESSAGE_ERROR_DATA_NOT_AVAILABLE);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_DC_ASYNC_STATE_UNVERIFIED, SB_MESSAGE_ERROR_DC_ASYNC_STATE_UNVERIFIED, SB_MESSAGE_ERROR_DC_ASYNC_STATE_UNVERIFIED);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_DC_NO_STATE_STORAGE, SB_MESSAGE_ERROR_DC_NO_STATE_STORAGE, SB_MESSAGE_ERROR_DC_NO_STATE_STORAGE);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_DC_FAILED_TO_CREATE_STREAM, SB_MESSAGE_ERROR_DC_FAILED_TO_CREATE_STREAM, SB_MESSAGE_ERROR_DC_FAILED_TO_CREATE_STREAM);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_DC_NO_PRESIGNED_DATA, SB_MESSAGE_ERROR_DC_NO_PRESIGNED_DATA, SB_MESSAGE_ERROR_DC_NO_PRESIGNED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBMessages, SB_MESSAGE_ERROR_INVALID_ENCRYPTION_CIPHER_MODE, SB_MESSAGE_ERROR_INVALID_ENCRYPTION_CIPHER_MODE, SB_MESSAGE_ERROR_INVALID_ENCRYPTION_CIPHER_MODE);
}

void Register_SBMessages_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBEncryptionOption", NULL);
	TSBEncryptionOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBEncryptionOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptionOption_ce_ptr, "eoIgnoreSupportedWin32Algorithms", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptionOption_ce_ptr, "eoNoOuterContentInfo", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBEncryptionOptions", NULL);
	TSBEncryptionOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBEncryptionOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptionOptions_ce_ptr, "eoIgnoreSupportedWin32Algorithms", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptionOptions_ce_ptr, "eoNoOuterContentInfo", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBDecryptionOption", NULL);
	TSBDecryptionOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBDecryptionOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBDecryptionOption_ce_ptr, "doNoOuterContentInfo", 0)
	
	INIT_CLASS_ENTRY(ce, "TSBDecryptionOptions", NULL);
	TSBDecryptionOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBDecryptionOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBDecryptionOptions_ce_ptr, "doNoOuterContentInfo", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBMessageSignatureType", NULL);
	TSBMessageSignatureType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBMessageSignatureType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBMessageSignatureType_ce_ptr, "mstPublicKey", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBMessageSignatureType_ce_ptr, "mstMAC", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBVerificationOption", NULL);
	TSBVerificationOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBVerificationOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBVerificationOption_ce_ptr, "voUseEmbeddedCerts", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBVerificationOption_ce_ptr, "voUseLocalCerts", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBVerificationOption_ce_ptr, "voVerifyMessageDigests", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBVerificationOption_ce_ptr, "voVerifyTimestamps", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBVerificationOption_ce_ptr, "voNoOuterContentInfo", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBVerificationOption_ce_ptr, "voLiberalMode", 5)
	
	INIT_CLASS_ENTRY(ce, "TSBVerificationOptions", NULL);
	TSBVerificationOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBVerificationOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBVerificationOptions_ce_ptr, "voUseEmbeddedCerts", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBVerificationOptions_ce_ptr, "voUseLocalCerts", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBVerificationOptions_ce_ptr, "voVerifyMessageDigests", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBVerificationOptions_ce_ptr, "voVerifyTimestamps", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBVerificationOptions_ce_ptr, "voNoOuterContentInfo", 16)
	SB_DECLARE_CLASS_LONG_CONST(TSBVerificationOptions_ce_ptr, "voLiberalMode", 32)
	
	INIT_CLASS_ENTRY(ce, "TSBSigningOption", NULL);
	TSBSigningOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSigningOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOption_ce_ptr, "soInsertMessageDigests", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOption_ce_ptr, "soIgnoreTimestampFailure", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOption_ce_ptr, "soNoOuterContentInfo", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOption_ce_ptr, "soRawCountersign", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOption_ce_ptr, "soInsertSigningTime", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOption_ce_ptr, "soUseGeneralizedTimeFormat", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOption_ce_ptr, "soIgnoreBadCountersignatures", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOption_ce_ptr, "soUseImplicitContent", 7)
	
	INIT_CLASS_ENTRY(ce, "TSBSigningOptions", NULL);
	TSBSigningOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBSigningOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOptions_ce_ptr, "soInsertMessageDigests", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOptions_ce_ptr, "soIgnoreTimestampFailure", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOptions_ce_ptr, "soNoOuterContentInfo", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOptions_ce_ptr, "soRawCountersign", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOptions_ce_ptr, "soInsertSigningTime", 16)
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOptions_ce_ptr, "soUseGeneralizedTimeFormat", 32)
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOptions_ce_ptr, "soIgnoreBadCountersignatures", 64)
	SB_DECLARE_CLASS_LONG_CONST(TSBSigningOptions_ce_ptr, "soUseImplicitContent", 128)
	
	INIT_CLASS_ENTRY(ce, "TSBSignOperationType", NULL);
	TSBSignOperationType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSignOperationType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSignOperationType_ce_ptr, "sotGeneric", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSignOperationType_ce_ptr, "sotAsyncPrepare", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSignOperationType_ce_ptr, "sotAsyncComplete", 2)
}

void Register_SBMessages_Aliases(TSRMLS_D)
{
	if (NULL == TElMessageProcessor_ce_ptr)
		Register_TElMessageProcessor(TSRMLS_C);
	zend_register_class_alias("ElMessageProcessor", TElMessageProcessor_ce_ptr);
	if (NULL == TElMessageEncryptor_ce_ptr)
		Register_TElMessageEncryptor(TSRMLS_C);
	zend_register_class_alias("ElMessageEncryptor", TElMessageEncryptor_ce_ptr);
	if (NULL == TElMessageDecryptor_ce_ptr)
		Register_TElMessageDecryptor(TSRMLS_C);
	zend_register_class_alias("ElMessageDecryptor", TElMessageDecryptor_ce_ptr);
	if (NULL == TElMessageVerifier_ce_ptr)
		Register_TElMessageVerifier(TSRMLS_C);
	zend_register_class_alias("ElMessageVerifier", TElMessageVerifier_ce_ptr);
	if (NULL == TElMessageSigner_ce_ptr)
		Register_TElMessageSigner(TSRMLS_C);
	zend_register_class_alias("ElMessageSigner", TElMessageSigner_ce_ptr);
}

