#include "sboauth2.h"

zend_class_entry *TSBOAuth2GrantType_ce_ptr = NULL;

zend_class_entry *TElOAuth2Request_ce_ptr = NULL;

SB_PHP_METHOD(TElOAuth2Request, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOAuth2Request_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Request, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOAuth2Request_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Request, get_Body)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOAuth2Request_get_Body(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-809270083, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Request, get_Header)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOAuth2Request_get_Header(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Request, get_Method)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOAuth2Request_get_Method(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Request, get_URL)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2Request_get_URL(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1059418622, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Request, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOAuth2Request_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Request_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Request_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Request_get_Body, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Request_get_Header, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Request_get_Method, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Request_get_URL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Request___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOAuth2Request_methods[] = {
	PHP_ME(TElOAuth2Request, Assign, arginfo_TElOAuth2Request_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Request, Clear, arginfo_TElOAuth2Request_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Request, get_Body, arginfo_TElOAuth2Request_get_Body, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Request, get_Header, arginfo_TElOAuth2Request_get_Header, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Request, get_Method, arginfo_TElOAuth2Request_get_Method, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Request, get_URL, arginfo_TElOAuth2Request_get_URL, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Request, __construct, arginfo_TElOAuth2Request___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOAuth2Request(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOAuth2Request_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOAuth2Request", TElOAuth2Request_methods);
	if (NULL == TPersistent_ce_ptr)
		Register_TPersistent(TSRMLS_C);
	TElOAuth2Request_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPersistent_ce_ptr);
}

zend_class_entry *TElOAuth2Client_ce_ptr = NULL;

SB_PHP_METHOD(TElOAuth2Client, Process)
{
	char *sURL = NULL;
	int32_t l4MethodRaw = 0;
	int32_t sURL_len = 0;
	SBArrayZValInfo aiRequestBody;
	SBArrayZValInfo aiResponseBody;
	uint32_t _err;
	zval *oNewRequest;
	zval *oRequestHeader;
	zval *oResponseHeader;
	zval *zaRequestBody;
	zval *zaResponseBody;
	zval *zl4Method;
	zval *zsURL;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zzzO!z", &oResponseHeader, TElStringList_ce_ptr, &zaResponseBody, &zl4Method, &zsURL, &oRequestHeader, TElStringList_ce_ptr, &zaRequestBody) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaResponseBody) || SB_IS_ARRAY_TYPE_RP(zaResponseBody) || SB_IS_NULL_TYPE_RP(zaResponseBody)) && Z_ISREF_P(zl4Method) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Method))) && Z_ISREF_P(zsURL) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsURL))) && Z_ISREF_P(zaRequestBody) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaRequestBody))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaRequestBody)))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaResponseBody, &aiResponseBody TSRMLS_CC)) RETURN_FALSE;
		SBInitArrayZValInfo(&aiRequestBody);
		_err = TElOAuth2Client_Process(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oResponseHeader TSRMLS_CC), aiResponseBody.data, aiResponseBody.len, &l4MethodRaw, sURL, &sURL_len, SBGetObjectHandle(oRequestHeader TSRMLS_CC), aiRequestBody.data, &aiRequestBody.len, &bOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sURL = emalloc(sURL_len + 1);
			SBCheckError(SBGetLastReturnStringA(2123190349, 4, sURL, &sURL_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsURL));
			SBDetachDataFromZValAndResize(zaRequestBody, &aiRequestBody TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(2123190349, 6, aiRequestBody.data, &aiRequestBody.len) TSRMLS_CC);
			((char *)aiRequestBody.data)[aiRequestBody.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiRequestBody);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiResponseBody);
		ZVAL_LONG(Z_REFVAL_P(zl4Method), (sb_zend_long)l4MethodRaw);
		sURL[sURL_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsURL), sURL, sURL_len);
		SBSetByteArrayToZVal(&aiRequestBody, zaRequestBody);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zO!", &oResponseHeader, TElStringList_ce_ptr, &zaResponseBody, &oNewRequest, TElOAuth2Request_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaResponseBody) || SB_IS_ARRAY_TYPE_RP(zaResponseBody) || SB_IS_NULL_TYPE_RP(zaResponseBody)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaResponseBody, &aiResponseBody TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOAuth2Client_Process_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oResponseHeader TSRMLS_CC), aiResponseBody.data, aiResponseBody.len, SBGetObjectHandle(oNewRequest TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiResponseBody);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList, array of byte|string|NULL, &integer, &string, \\TElStringList, &array of byte|string) or (\\TElStringList, array of byte|string|NULL, \\TElOAuth2Request)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, Refresh)
{
	char *sURL = NULL;
	int32_t l4MethodRaw = 0;
	int32_t sURL_len = 0;
	SBArrayZValInfo aiRequestBody;
	uint32_t _err;
	zval *oRequest;
	zval *oRequestHeader;
	zval *zaRequestBody;
	zval *zl4Method;
	zval *zsURL;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzO!z", &zl4Method, &zsURL, &oRequestHeader, TElStringList_ce_ptr, &zaRequestBody) == SUCCESS) && Z_ISREF_P(zl4Method) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Method))) && Z_ISREF_P(zsURL) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsURL))) && Z_ISREF_P(zaRequestBody) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaRequestBody))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaRequestBody)))))
	{
		SBInitArrayZValInfo(&aiRequestBody);
		_err = TElOAuth2Client_Refresh(SBGetObjectHandle(getThis() TSRMLS_CC), &l4MethodRaw, sURL, &sURL_len, SBGetObjectHandle(oRequestHeader TSRMLS_CC), aiRequestBody.data, &aiRequestBody.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sURL = emalloc(sURL_len + 1);
			SBCheckError(SBGetLastReturnStringA(1704849633, 2, sURL, &sURL_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsURL));
			SBDetachDataFromZValAndResize(zaRequestBody, &aiRequestBody TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(1704849633, 4, aiRequestBody.data, &aiRequestBody.len) TSRMLS_CC);
			((char *)aiRequestBody.data)[aiRequestBody.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiRequestBody);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		ZVAL_LONG(Z_REFVAL_P(zl4Method), (sb_zend_long)l4MethodRaw);
		sURL[sURL_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsURL), sURL, sURL_len);
		SBSetByteArrayToZVal(&aiRequestBody, zaRequestBody);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oRequest, TElOAuth2Request_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_Refresh_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oRequest TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(&integer, &string, \\TElStringList, &array of byte|string) or (\\TElOAuth2Request)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, Start)
{
	char *sURL = NULL;
	int32_t l4MethodRaw = 0;
	int32_t sURL_len = 0;
	SBArrayZValInfo aiRequestBody;
	uint32_t _err;
	zval *oRequest;
	zval *oRequestHeader;
	zval *zaRequestBody;
	zval *zl4Method;
	zval *zsURL;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzO!z", &zl4Method, &zsURL, &oRequestHeader, TElStringList_ce_ptr, &zaRequestBody) == SUCCESS) && Z_ISREF_P(zl4Method) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Method))) && Z_ISREF_P(zsURL) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsURL))) && Z_ISREF_P(zaRequestBody) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaRequestBody))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaRequestBody)))))
	{
		SBInitArrayZValInfo(&aiRequestBody);
		_err = TElOAuth2Client_Start(SBGetObjectHandle(getThis() TSRMLS_CC), &l4MethodRaw, sURL, &sURL_len, SBGetObjectHandle(oRequestHeader TSRMLS_CC), aiRequestBody.data, &aiRequestBody.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sURL = emalloc(sURL_len + 1);
			SBCheckError(SBGetLastReturnStringA(-506836368, 2, sURL, &sURL_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsURL));
			SBDetachDataFromZValAndResize(zaRequestBody, &aiRequestBody TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-506836368, 4, aiRequestBody.data, &aiRequestBody.len) TSRMLS_CC);
			((char *)aiRequestBody.data)[aiRequestBody.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiRequestBody);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		ZVAL_LONG(Z_REFVAL_P(zl4Method), (sb_zend_long)l4MethodRaw);
		sURL[sURL_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsURL), sURL, sURL_len);
		SBSetByteArrayToZVal(&aiRequestBody, zaRequestBody);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oRequest, TElOAuth2Request_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_Start_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oRequest TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(&integer, &string, \\TElStringList, &array of byte|string) or (\\TElOAuth2Request)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, ApplyCustomParams)
{
	zval *oParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oParams, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_ApplyCustomParams(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oParams TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, ClearCustomParams)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_ClearCustomParams(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_AccessToken)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2Client_get_AccessToken(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-847733687, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_AuthURL)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2Client_get_AuthURL(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(758586444, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, set_AuthURL)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_set_AuthURL(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_ClientID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2Client_get_ClientID(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1613757171, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, set_ClientID)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_set_ClientID(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_ClientSecret)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2Client_get_ClientSecret(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2059516065, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, set_ClientSecret)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_set_ClientSecret(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_Complete)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOAuth2Client_get_Complete(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_CustomParam)
{
	char *sName;
	sb_str_size sName_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2Client_get_CustomParam(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(124182039, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, set_CustomParam)
{
	char *sName;
	char *sValue;
	sb_str_size sName_len;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sName, &sName_len, &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_set_CustomParam(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_ExpiresAt)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElOAuth2Client_get_ExpiresAt(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_ExpiresIn)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOAuth2Client_get_ExpiresIn(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_GrantType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOAuth2GrantTypeRaw fOutResultRaw = 0;
		SBCheckError(TElOAuth2Client_get_GrantType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, set_GrantType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_set_GrantType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBOAuth2GrantTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2Client_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2069924526, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_RedirectURL)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2Client_get_RedirectURL(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1221542194, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, set_RedirectURL)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_set_RedirectURL(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_RefreshToken)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2Client_get_RefreshToken(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1642711359, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, set_RefreshToken)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_set_RefreshToken(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_Scope)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2Client_get_Scope(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1651875393, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, set_Scope)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_set_Scope(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_State)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2Client_get_State(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1052173975, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, set_State)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_set_State(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_TokenType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2Client_get_TokenType(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1389053628, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_TokenURL)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2Client_get_TokenURL(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(200075734, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, set_TokenURL)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_set_TokenURL(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_UseURLParams)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOAuth2Client_get_UseURLParams(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, set_UseURLParams)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_set_UseURLParams(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, get_UserName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2Client_get_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(382625074, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, set_UserName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOAuth2Client_set_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2Client, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOAuth2Client_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_Process, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, ResponseHeader, TElStringList, 1)
	ZEND_ARG_TYPE_INFO(0, ResponseBody, 0, 1)
	ZEND_ARG_TYPE_INFO(1, Method_or_NewRequest, 0, 1)
	ZEND_ARG_INFO(1, URL)
	ZEND_ARG_OBJ_INFO(0, RequestHeader, TElStringList, 1)
	ZEND_ARG_INFO(1, RequestBody)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_Refresh, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(1, Method_or_Request, 0, 1)
	ZEND_ARG_INFO(1, URL)
	ZEND_ARG_OBJ_INFO(0, RequestHeader, TElStringList, 1)
	ZEND_ARG_INFO(1, RequestBody)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_Start, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(1, Method_or_Request, 0, 1)
	ZEND_ARG_INFO(1, URL)
	ZEND_ARG_OBJ_INFO(0, RequestHeader, TElStringList, 1)
	ZEND_ARG_INFO(1, RequestBody)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_ApplyCustomParams, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Params, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_ClearCustomParams, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_AccessToken, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_AuthURL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_set_AuthURL, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_ClientID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_set_ClientID, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_ClientSecret, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_set_ClientSecret, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_Complete, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_CustomParam, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_set_CustomParam, 0, 0, 2)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_ExpiresAt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_ExpiresIn, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_GrantType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_set_GrantType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_RedirectURL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_set_RedirectURL, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_RefreshToken, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_set_RefreshToken, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_Scope, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_set_Scope, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_State, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_set_State, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_TokenType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_TokenURL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_set_TokenURL, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_UseURLParams, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_set_UseURLParams, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_get_UserName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client_set_UserName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2Client___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOAuth2Client_methods[] = {
	PHP_ME(TElOAuth2Client, Process, arginfo_TElOAuth2Client_Process, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, Refresh, arginfo_TElOAuth2Client_Refresh, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, Start, arginfo_TElOAuth2Client_Start, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, ApplyCustomParams, arginfo_TElOAuth2Client_ApplyCustomParams, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, ClearCustomParams, arginfo_TElOAuth2Client_ClearCustomParams, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_AccessToken, arginfo_TElOAuth2Client_get_AccessToken, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_AuthURL, arginfo_TElOAuth2Client_get_AuthURL, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, set_AuthURL, arginfo_TElOAuth2Client_set_AuthURL, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_ClientID, arginfo_TElOAuth2Client_get_ClientID, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, set_ClientID, arginfo_TElOAuth2Client_set_ClientID, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_ClientSecret, arginfo_TElOAuth2Client_get_ClientSecret, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, set_ClientSecret, arginfo_TElOAuth2Client_set_ClientSecret, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_Complete, arginfo_TElOAuth2Client_get_Complete, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_CustomParam, arginfo_TElOAuth2Client_get_CustomParam, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, set_CustomParam, arginfo_TElOAuth2Client_set_CustomParam, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_ExpiresAt, arginfo_TElOAuth2Client_get_ExpiresAt, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_ExpiresIn, arginfo_TElOAuth2Client_get_ExpiresIn, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_GrantType, arginfo_TElOAuth2Client_get_GrantType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, set_GrantType, arginfo_TElOAuth2Client_set_GrantType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_Password, arginfo_TElOAuth2Client_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, set_Password, arginfo_TElOAuth2Client_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_RedirectURL, arginfo_TElOAuth2Client_get_RedirectURL, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, set_RedirectURL, arginfo_TElOAuth2Client_set_RedirectURL, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_RefreshToken, arginfo_TElOAuth2Client_get_RefreshToken, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, set_RefreshToken, arginfo_TElOAuth2Client_set_RefreshToken, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_Scope, arginfo_TElOAuth2Client_get_Scope, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, set_Scope, arginfo_TElOAuth2Client_set_Scope, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_State, arginfo_TElOAuth2Client_get_State, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, set_State, arginfo_TElOAuth2Client_set_State, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_TokenType, arginfo_TElOAuth2Client_get_TokenType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_TokenURL, arginfo_TElOAuth2Client_get_TokenURL, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, set_TokenURL, arginfo_TElOAuth2Client_set_TokenURL, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_UseURLParams, arginfo_TElOAuth2Client_get_UseURLParams, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, set_UseURLParams, arginfo_TElOAuth2Client_set_UseURLParams, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, get_UserName, arginfo_TElOAuth2Client_get_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, set_UserName, arginfo_TElOAuth2Client_set_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2Client, __construct, arginfo_TElOAuth2Client___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOAuth2Client(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOAuth2Client_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOAuth2Client", TElOAuth2Client_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElOAuth2Client_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElOAuth2RedirectReceiver_ce_ptr = NULL;

SB_PHP_METHOD(TElOAuth2RedirectReceiver, Activate)
{
	char *sLocalAddress;
	char *sURL;
	sb_str_size sLocalAddress_len;
	sb_str_size sURL_len;
	sb_zend_long u2LocalPort;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sURL, &sURL_len) == SUCCESS)
	{
		SBCheckError(TElOAuth2RedirectReceiver_Activate(SBGetObjectHandle(getThis() TSRMLS_CC), sURL, (int32_t)sURL_len) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &sLocalAddress, &sLocalAddress_len, &u2LocalPort) == SUCCESS)
	{
		SBCheckError(TElOAuth2RedirectReceiver_Activate_1(SBGetObjectHandle(getThis() TSRMLS_CC), sLocalAddress, (int32_t)sLocalAddress_len, (uint16_t)u2LocalPort) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, Deactivate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOAuth2RedirectReceiver_Deactivate(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, Receive)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOAuth2RedirectReceiver_Receive(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOAuth2RedirectReceiver_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, get_Active)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOAuth2RedirectReceiver_get_Active(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, get_AuthorizationCode)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOAuth2RedirectReceiver_get_AuthorizationCode(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1043151050, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, get_Done)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOAuth2RedirectReceiver_get_Done(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, get_ReceivedHeaders)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOAuth2RedirectReceiver_get_ReceivedHeaders(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, get_BufferSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOAuth2RedirectReceiver_get_BufferSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, set_BufferSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOAuth2RedirectReceiver_set_BufferSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, get_ResponsePage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOAuth2RedirectReceiver_get_ResponsePage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, set_ResponsePage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOAuth2RedirectReceiver_set_ResponsePage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, get_UseIPv6)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOAuth2RedirectReceiver_get_UseIPv6(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, set_UseIPv6)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElOAuth2RedirectReceiver_set_UseIPv6(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, get_SocketTimeout)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOAuth2RedirectReceiver_get_SocketTimeout(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, set_SocketTimeout)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOAuth2RedirectReceiver_set_SocketTimeout(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, get_OnComplete)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElOAuth2RedirectReceiver_get_OnComplete(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, set_OnComplete)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElOAuth2RedirectReceiver_set_OnComplete(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOAuth2RedirectReceiver, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOAuth2RedirectReceiver_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_Activate, 0, 0, 1)
	ZEND_ARG_INFO(0, URL_or_LocalAddress)
	ZEND_ARG_INFO(0, LocalPort)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_Deactivate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_Receive, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_get_Active, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_get_AuthorizationCode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_get_Done, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_get_ReceivedHeaders, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_get_BufferSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_set_BufferSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_get_ResponsePage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_set_ResponsePage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_get_UseIPv6, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_set_UseIPv6, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_get_SocketTimeout, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_set_SocketTimeout, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_get_OnComplete, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver_set_OnComplete, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOAuth2RedirectReceiver___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOAuth2RedirectReceiver_methods[] = {
	PHP_ME(TElOAuth2RedirectReceiver, Activate, arginfo_TElOAuth2RedirectReceiver_Activate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, Deactivate, arginfo_TElOAuth2RedirectReceiver_Deactivate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, Receive, arginfo_TElOAuth2RedirectReceiver_Receive, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, Reset, arginfo_TElOAuth2RedirectReceiver_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, get_Active, arginfo_TElOAuth2RedirectReceiver_get_Active, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, get_AuthorizationCode, arginfo_TElOAuth2RedirectReceiver_get_AuthorizationCode, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, get_Done, arginfo_TElOAuth2RedirectReceiver_get_Done, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, get_ReceivedHeaders, arginfo_TElOAuth2RedirectReceiver_get_ReceivedHeaders, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, get_BufferSize, arginfo_TElOAuth2RedirectReceiver_get_BufferSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, set_BufferSize, arginfo_TElOAuth2RedirectReceiver_set_BufferSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, get_ResponsePage, arginfo_TElOAuth2RedirectReceiver_get_ResponsePage, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, set_ResponsePage, arginfo_TElOAuth2RedirectReceiver_set_ResponsePage, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, get_UseIPv6, arginfo_TElOAuth2RedirectReceiver_get_UseIPv6, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, set_UseIPv6, arginfo_TElOAuth2RedirectReceiver_set_UseIPv6, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, get_SocketTimeout, arginfo_TElOAuth2RedirectReceiver_get_SocketTimeout, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, set_SocketTimeout, arginfo_TElOAuth2RedirectReceiver_set_SocketTimeout, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, get_OnComplete, arginfo_TElOAuth2RedirectReceiver_get_OnComplete, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, set_OnComplete, arginfo_TElOAuth2RedirectReceiver_set_OnComplete, ZEND_ACC_PUBLIC)
	PHP_ME(TElOAuth2RedirectReceiver, __construct, arginfo_TElOAuth2RedirectReceiver___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOAuth2RedirectReceiver(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOAuth2RedirectReceiver_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOAuth2RedirectReceiver", TElOAuth2RedirectReceiver_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElOAuth2RedirectReceiver_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

void Register_SBOAuth2_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, ERROR_FACILITY_OAUTH2, SB_ERROR_FACILITY_OAUTH2, SB_ERROR_FACILITY_OAUTH2);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, ERROR_OAUTH2_ERROR_FLAG, SB_ERROR_OAUTH2_ERROR_FLAG, SB_ERROR_OAUTH2_ERROR_FLAG);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_ERROR_INVALID_HTTP_CODE, SB_OAUTH2_ERROR_INVALID_HTTP_CODE, SB_OAUTH2_ERROR_INVALID_HTTP_CODE);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_ERROR_INVALID_RESPONSE_FORMAT, SB_OAUTH2_ERROR_INVALID_RESPONSE_FORMAT, SB_OAUTH2_ERROR_INVALID_RESPONSE_FORMAT);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_ERROR_INVALID_STATE_PARAMETER, SB_OAUTH2_ERROR_INVALID_STATE_PARAMETER, SB_OAUTH2_ERROR_INVALID_STATE_PARAMETER);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_ERROR_NO_CODE_RECEIVED, SB_OAUTH2_ERROR_NO_CODE_RECEIVED, SB_OAUTH2_ERROR_NO_CODE_RECEIVED);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_ERROR_NO_REFRESH_TOKEN, SB_OAUTH2_ERROR_NO_REFRESH_TOKEN, SB_OAUTH2_ERROR_NO_REFRESH_TOKEN);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_ERROR_INVALID_PARAMETER, SB_OAUTH2_ERROR_INVALID_PARAMETER, SB_OAUTH2_ERROR_INVALID_PARAMETER);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_ERROR_INVALID_HTTP_HEADER, SB_OAUTH2_ERROR_INVALID_HTTP_HEADER, SB_OAUTH2_ERROR_INVALID_HTTP_HEADER);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_ERROR_SOCKET_ERROR, SB_OAUTH2_ERROR_SOCKET_ERROR, SB_OAUTH2_ERROR_SOCKET_ERROR);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, ERROR_OAUTH2_SERVER_ERROR_FLAG, SB_ERROR_OAUTH2_SERVER_ERROR_FLAG, SB_ERROR_OAUTH2_SERVER_ERROR_FLAG);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_SERVER_ERROR_UNKNOWN, SB_OAUTH2_SERVER_ERROR_UNKNOWN, SB_OAUTH2_SERVER_ERROR_UNKNOWN);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_SERVER_ERROR_ACCESS_DENIED, SB_OAUTH2_SERVER_ERROR_ACCESS_DENIED, SB_OAUTH2_SERVER_ERROR_ACCESS_DENIED);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_SERVER_ERROR_INVALID_CLIENT, SB_OAUTH2_SERVER_ERROR_INVALID_CLIENT, SB_OAUTH2_SERVER_ERROR_INVALID_CLIENT);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_SERVER_ERROR_INVALID_GRANT, SB_OAUTH2_SERVER_ERROR_INVALID_GRANT, SB_OAUTH2_SERVER_ERROR_INVALID_GRANT);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_SERVER_ERROR_INVALID_REQUEST, SB_OAUTH2_SERVER_ERROR_INVALID_REQUEST, SB_OAUTH2_SERVER_ERROR_INVALID_REQUEST);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_SERVER_ERROR_INVALID_SCOPE, SB_OAUTH2_SERVER_ERROR_INVALID_SCOPE, SB_OAUTH2_SERVER_ERROR_INVALID_SCOPE);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_SERVER_ERROR_SERVER_FAILURE, SB_OAUTH2_SERVER_ERROR_SERVER_FAILURE, SB_OAUTH2_SERVER_ERROR_SERVER_FAILURE);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_SERVER_ERROR_TEMPORARILY, SB_OAUTH2_SERVER_ERROR_TEMPORARILY, SB_OAUTH2_SERVER_ERROR_TEMPORARILY);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_SERVER_ERROR_UNAUTH_CLIENT, SB_OAUTH2_SERVER_ERROR_UNAUTH_CLIENT, SB_OAUTH2_SERVER_ERROR_UNAUTH_CLIENT);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_SERVER_ERROR_UNSUPPORTED_GRANT, SB_OAUTH2_SERVER_ERROR_UNSUPPORTED_GRANT, SB_OAUTH2_SERVER_ERROR_UNSUPPORTED_GRANT);
	SB_REGISTER_LONG_CONSTANT(SBOAuth2, SB_OAUTH2_SERVER_ERROR_UNSUPPORTED_RESPONSE, SB_OAUTH2_SERVER_ERROR_UNSUPPORTED_RESPONSE, SB_OAUTH2_SERVER_ERROR_UNSUPPORTED_RESPONSE);
}

void Register_SBOAuth2_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBOAuth2GrantType", NULL);
	TSBOAuth2GrantType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBOAuth2GrantType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBOAuth2GrantType_ce_ptr, "oauthAuthorizationCode", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBOAuth2GrantType_ce_ptr, "oauthImplicit", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBOAuth2GrantType_ce_ptr, "oauthResourceOwnerPassword", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBOAuth2GrantType_ce_ptr, "oauthClientCredentials", 3)
}

