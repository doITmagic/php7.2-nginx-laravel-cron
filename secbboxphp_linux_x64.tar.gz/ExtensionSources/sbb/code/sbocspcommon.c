#include "sbocspcommon.h"

zend_class_entry *TElOCSPServerError_ce_ptr = NULL;

zend_class_entry *TElOCSPCertificateStatus_ce_ptr = NULL;

zend_class_entry *TElResponderIDType_ce_ptr = NULL;

void SB_CALLBACK TSBCertificateOCSPCheckEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pHashAlgOID[], int32_t szHashAlgOID, const uint8_t pIssuerNameHash[], int32_t szIssuerNameHash, const uint8_t pIssuerKeyHash[], int32_t szIssuerKeyHash, const uint8_t pCertificateSerial[], int32_t szCertificateSerial, TElOCSPCertificateStatusRaw * CertStatus, TSBCRLReasonFlagRaw * Reason, int64_t * RevocationTime, int64_t * ThisUpdate, int64_t * NextUpdate)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(10);
	zval * zSender;
	zval * zHashAlgOID;
	zval * zIssuerNameHash;
	zval * zIssuerKeyHash;
	zval * zCertificateSerial;
	zval * zCertStatus;
	zval * zReason;
	zval * zRevocationTime;
	zval * zThisUpdate;
	zval * zNextUpdate;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zHashAlgOID, 1);
	SB_ZVAL_STRINGL_DUP(zHashAlgOID, pHashAlgOID, szHashAlgOID);
	SB_EVENT_INIT_ZVAL(zIssuerNameHash, 2);
	SB_ZVAL_STRINGL_DUP(zIssuerNameHash, pIssuerNameHash, szIssuerNameHash);
	SB_EVENT_INIT_ZVAL(zIssuerKeyHash, 3);
	SB_ZVAL_STRINGL_DUP(zIssuerKeyHash, pIssuerKeyHash, szIssuerKeyHash);
	SB_EVENT_INIT_ZVAL(zCertificateSerial, 4);
	SB_ZVAL_STRINGL_DUP(zCertificateSerial, pCertificateSerial, szCertificateSerial);
	SB_EVENT_INIT_ZVAL_REF(zCertStatus, 5);
	ZVAL_LONG(Z_REFVAL_P(zCertStatus), (sb_zend_long)*CertStatus);
	SB_EVENT_INIT_ZVAL_REF(zReason, 6);
	ZVAL_LONG(Z_REFVAL_P(zReason), (sb_zend_long)*Reason);
	SB_EVENT_INIT_ZVAL_REF(zRevocationTime, 7);
	object_init_ex(Z_REFVAL_P(zRevocationTime), php_date_get_date_ce());
	SBSetDateTime(zRevocationTime, *RevocationTime TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zThisUpdate, 8);
	object_init_ex(Z_REFVAL_P(zThisUpdate), php_date_get_date_ce());
	SBSetDateTime(zThisUpdate, *ThisUpdate TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zNextUpdate, 9);
	object_init_ex(Z_REFVAL_P(zNextUpdate), php_date_get_date_ce());
	SBSetDateTime(zNextUpdate, *NextUpdate TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 10, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zHashAlgOID);
	SB_EVENT_CLEAR_ZVAL(zIssuerNameHash);
	SB_EVENT_CLEAR_ZVAL(zIssuerKeyHash);
	SB_EVENT_CLEAR_ZVAL(zCertificateSerial);
	convert_to_long(Z_REFVAL_P(zCertStatus));
	*CertStatus = (TElOCSPCertificateStatusRaw)Z_LVAL_P(Z_REFVAL_P(zCertStatus));
	SB_EVENT_CLEAR_ZVAL(zCertStatus);
	convert_to_long(Z_REFVAL_P(zReason));
	*Reason = (TSBCRLReasonFlagRaw)Z_LVAL_P(Z_REFVAL_P(zReason));
	SB_EVENT_CLEAR_ZVAL(zReason);
	*RevocationTime = SBGetDateTime(zRevocationTime TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zRevocationTime);
	*ThisUpdate = SBGetDateTime(zThisUpdate TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zThisUpdate);
	*NextUpdate = SBGetDateTime(zNextUpdate TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zNextUpdate);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBOCSPSignatureValidateEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t * Valid)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zValid;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zValid, 1);
	ZVAL_BOOL(Z_REFVAL_P(zValid), (zend_bool)*Valid);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	convert_to_boolean(Z_REFVAL_P(zValid));
	*Valid = (int8_t)SB_BVAL_P(Z_REFVAL_P(zValid));
	SB_EVENT_CLEAR_ZVAL(zValid);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBOCSPCertificateNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle * Certificate)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zCertificate;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zCertificate, 1);
	SBInitObject(zCertificate, TElX509Certificate_ce_ptr, *Certificate TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	*Certificate = SBGetObjectHandleCE(zCertificate, TElX509Certificate_ce_ptr TSRMLS_CC);
	SBDetachObjectHandleIfUniqueZVal(zCertificate TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zCertificate);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElOCSPClass_ce_ptr = NULL;

SB_PHP_METHOD(TElOCSPClass, get_RequestorName)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOCSPClass_get_RequestorName(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElGeneralName_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPClass, get_IncludeCertificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOCSPClass_get_IncludeCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPClass, set_IncludeCertificates)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElOCSPClass_set_IncludeCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPClass, get_SigningCertStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOCSPClass_get_SigningCertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPClass, set_SigningCertStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOCSPClass_set_SigningCertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPClass, get_OnCertificateNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOCSPCertificateNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElOCSPClass_get_OnCertificateNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPClass, set_OnCertificateNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElOCSPClass_set_OnCertificateNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBOCSPCertificateNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOCSPCertificateNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPClass, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOCSPClass_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPClass_get_RequestorName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPClass_get_IncludeCertificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPClass_set_IncludeCertificates, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPClass_get_SigningCertStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPClass_set_SigningCertStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPClass_get_OnCertificateNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPClass_set_OnCertificateNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPClass___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOCSPClass_methods[] = {
	PHP_ME(TElOCSPClass, get_RequestorName, arginfo_TElOCSPClass_get_RequestorName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPClass, get_IncludeCertificates, arginfo_TElOCSPClass_get_IncludeCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPClass, set_IncludeCertificates, arginfo_TElOCSPClass_set_IncludeCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPClass, get_SigningCertStorage, arginfo_TElOCSPClass_get_SigningCertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPClass, set_SigningCertStorage, arginfo_TElOCSPClass_set_SigningCertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPClass, get_OnCertificateNeeded, arginfo_TElOCSPClass_get_OnCertificateNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPClass, set_OnCertificateNeeded, arginfo_TElOCSPClass_set_OnCertificateNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPClass, __construct, arginfo_TElOCSPClass___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOCSPClass(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOCSPClass_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOCSPClass", TElOCSPClass_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElOCSPClass_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

SB_PHP_FUNCTION(SBOCSPCommon, ReasonFlagToEnum)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBOCSPCommon_ReasonFlagToEnum((TSBCRLReasonFlagRaw)fValue, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBOCSPCommon, EnumToReasonFlag)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		TSBCRLReasonFlagRaw fOutResultRaw = 0;
		SBCheckError(SBOCSPCommon_EnumToReasonFlag((int32_t)l4Value, &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBOCSPCommon, ReadAsnInteger)
{
	SBArrayZValInfo aiIntBuf;
	uint32_t _err;
	zval *zaIntBuf;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaIntBuf) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaIntBuf) || SB_IS_ARRAY_TYPE_RP(zaIntBuf) || SB_IS_NULL_TYPE_RP(zaIntBuf)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaIntBuf, &aiIntBuf TSRMLS_CC)) RETURN_FALSE;
		_err = SBOCSPCommon_ReadAsnInteger(aiIntBuf.data, aiIntBuf.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(773542451, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiIntBuf);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

void Register_SBOCSPCommon_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBOCSPCommon, ERROR_FACILITY_OCSP, SB_ERROR_FACILITY_OCSP, SB_ERROR_FACILITY_OCSP);
	SB_REGISTER_LONG_CONSTANT(SBOCSPCommon, ERROR_OCSP_PROTOCOL_ERROR_FLAG, SB_ERROR_OCSP_PROTOCOL_ERROR_FLAG, SB_ERROR_OCSP_PROTOCOL_ERROR_FLAG);
	SB_REGISTER_LONG_CONSTANT(SBOCSPCommon, SB_OCSP_ERROR_NO_CERTIFICATES, SB_OCSP_ERROR_NO_CERTIFICATES, SB_OCSP_ERROR_NO_CERTIFICATES);
	SB_REGISTER_LONG_CONSTANT(SBOCSPCommon, SB_OCSP_ERROR_NO_ISSUER_CERTIFICATES, SB_OCSP_ERROR_NO_ISSUER_CERTIFICATES, SB_OCSP_ERROR_NO_ISSUER_CERTIFICATES);
	SB_REGISTER_LONG_CONSTANT(SBOCSPCommon, SB_OCSP_ERROR_WRONG_DATA, SB_OCSP_ERROR_WRONG_DATA, SB_OCSP_ERROR_WRONG_DATA);
	SB_REGISTER_LONG_CONSTANT(SBOCSPCommon, SB_OCSP_ERROR_NO_EVENT_HANDLER, SB_OCSP_ERROR_NO_EVENT_HANDLER, SB_OCSP_ERROR_NO_EVENT_HANDLER);
	SB_REGISTER_LONG_CONSTANT(SBOCSPCommon, SB_OCSP_ERROR_NO_PARAMETERS, SB_OCSP_ERROR_NO_PARAMETERS, SB_OCSP_ERROR_NO_PARAMETERS);
	SB_REGISTER_LONG_CONSTANT(SBOCSPCommon, SB_OCSP_ERROR_NO_REPLY, SB_OCSP_ERROR_NO_REPLY, SB_OCSP_ERROR_NO_REPLY);
	SB_REGISTER_LONG_CONSTANT(SBOCSPCommon, SB_OCSP_ERROR_WRONG_SIGNATURE, SB_OCSP_ERROR_WRONG_SIGNATURE, SB_OCSP_ERROR_WRONG_SIGNATURE);
	SB_REGISTER_LONG_CONSTANT(SBOCSPCommon, SB_OCSP_ERROR_UNSUPPORTED_ALGORITHM, SB_OCSP_ERROR_UNSUPPORTED_ALGORITHM, SB_OCSP_ERROR_UNSUPPORTED_ALGORITHM);
	SB_REGISTER_LONG_CONSTANT(SBOCSPCommon, SB_OCSP_ERROR_INVALID_RESPONSE, SB_OCSP_ERROR_INVALID_RESPONSE, SB_OCSP_ERROR_INVALID_RESPONSE);
	SB_REGISTER_LONG_CONSTANT(SBOCSPCommon, SB_OCSP_ERROR_WRONG_HTTP_REPLY, SB_OCSP_ERROR_WRONG_HTTP_REPLY, SB_OCSP_ERROR_WRONG_HTTP_REPLY);
	SB_REGISTER_STRING_CONSTANT(SBOCSPCommon, SB_OCSP_OID_BASIC_RESPONSE, SB_OCSP_OID_BASIC_RESPONSE, SB_OCSP_OID_BASIC_RESPONSE);
	SB_REGISTER_STRING_CONSTANT(SBOCSPCommon, SB_OCSP_OID_NONCE, SB_OCSP_OID_NONCE, SB_OCSP_OID_NONCE);
	SB_REGISTER_STRING_CONSTANT(SBOCSPCommon, SB_OCSP_OID_OCSP_RESPONSE, SB_OCSP_OID_OCSP_RESPONSE, SB_OCSP_OID_OCSP_RESPONSE);
	SB_REGISTER_STRING_CONSTANT(SBOCSPCommon, SB_OID_OCSP_RESPONSE, SB_OID_OCSP_RESPONSE, SB_OID_OCSP_RESPONSE);
}

void Register_SBOCSPCommon_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TElOCSPServerError", NULL);
	TElOCSPServerError_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TElOCSPServerError_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TElOCSPServerError_ce_ptr, "oseSuccessful", 0)
	SB_DECLARE_CLASS_LONG_CONST(TElOCSPServerError_ce_ptr, "oseMalformedRequest", 1)
	SB_DECLARE_CLASS_LONG_CONST(TElOCSPServerError_ce_ptr, "oseInternalError", 2)
	SB_DECLARE_CLASS_LONG_CONST(TElOCSPServerError_ce_ptr, "oseTryLater", 3)
	SB_DECLARE_CLASS_LONG_CONST(TElOCSPServerError_ce_ptr, "oseUnused1", 4)
	SB_DECLARE_CLASS_LONG_CONST(TElOCSPServerError_ce_ptr, "oseSigRequired", 5)
	SB_DECLARE_CLASS_LONG_CONST(TElOCSPServerError_ce_ptr, "oseUnauthorized", 6)
	
	INIT_CLASS_ENTRY(ce, "TElOCSPCertificateStatus", NULL);
	TElOCSPCertificateStatus_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TElOCSPCertificateStatus_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TElOCSPCertificateStatus_ce_ptr, "csGood", 0)
	SB_DECLARE_CLASS_LONG_CONST(TElOCSPCertificateStatus_ce_ptr, "csRevoked", 1)
	SB_DECLARE_CLASS_LONG_CONST(TElOCSPCertificateStatus_ce_ptr, "csUnknown", 2)
	
	INIT_CLASS_ENTRY(ce, "TElResponderIDType", NULL);
	TElResponderIDType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TElResponderIDType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TElResponderIDType_ce_ptr, "ritName", 0)
	SB_DECLARE_CLASS_LONG_CONST(TElResponderIDType_ce_ptr, "ritKeyHash", 1)
}

void Register_SBOCSPCommon_Aliases(TSRMLS_D)
{
	if (NULL == TElOCSPClass_ce_ptr)
		Register_TElOCSPClass(TSRMLS_C);
	zend_register_class_alias("ElOCSPClass", TElOCSPClass_ce_ptr);
}

