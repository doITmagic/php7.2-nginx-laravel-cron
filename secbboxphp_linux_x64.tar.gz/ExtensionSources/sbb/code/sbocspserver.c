#include "sbocspserver.h"

zend_class_entry *TSBOCSPServerOption_ce_ptr = NULL;

zend_class_entry *TSBOCSPServerOptions_ce_ptr = NULL;

void SB_CALLBACK TSBOCSPSigningCertificatesNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomCertStorageHandle * Certificates)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zCertificates;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zCertificates, 1);
	SBInitObject(zCertificates, TElCustomCertStorage_ce_ptr, *Certificates TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	*Certificates = SBGetObjectHandleCE(zCertificates, TElCustomCertStorage_ce_ptr TSRMLS_CC);
	SBDetachObjectHandleIfUniqueZVal(zCertificates TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zCertificates);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElOCSPServer_ce_ptr = NULL;

SB_PHP_METHOD(TElOCSPServer, ProcessRequest)
{
	SBArrayZValInfo aiReply;
	SBArrayZValInfo aiRequest;
	uint32_t _err;
	zval *zaReply;
	zval *zaRequest;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaRequest, &zaReply) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaRequest) || SB_IS_ARRAY_TYPE_RP(zaRequest) || SB_IS_NULL_TYPE_RP(zaRequest)) && Z_ISREF_P(zaReply) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaReply))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaReply)))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaRequest, &aiRequest TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaReply, &aiReply TSRMLS_CC)) RETURN_FALSE;
		_err = TElOCSPServer_ProcessRequest(SBGetObjectHandle(getThis() TSRMLS_CC), aiRequest.data, aiRequest.len, aiReply.data, &aiReply.len, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaReply, &aiReply TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-1727265080, 2, aiReply.data, &aiReply.len) TSRMLS_CC);
			((char *)aiReply.data)[aiReply.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiReply);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiRequest);
		SBSetByteArrayToZVal(&aiReply, zaReply);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, get_ResponderIdType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElResponderIDTypeRaw fOutResultRaw = 0;
		SBCheckError(TElOCSPServer_get_ResponderIdType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, set_ResponderIdType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElOCSPServer_set_ResponderIdType(SBGetObjectHandle(getThis() TSRMLS_CC), (TElResponderIDTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, get_RequestCertificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOCSPServer_get_RequestCertificates(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElMemoryCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, get_SignatureAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOCSPServer_get_SignatureAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, set_SignatureAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOCSPServer_set_SignatureAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, get_ProducedAt)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElOCSPServer_get_ProducedAt(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, set_ProducedAt)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElOCSPServer_set_ProducedAt(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, get_SignatureRequired)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOCSPServer_get_SignatureRequired(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, set_SignatureRequired)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElOCSPServer_set_SignatureRequired(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, get_Options)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOCSPServerOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElOCSPServer_get_Options(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, set_Options)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElOCSPServer_set_Options(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBOCSPServerOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, get_IssuerHashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOCSPServer_get_IssuerHashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, set_IssuerHashAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOCSPServer_set_IssuerHashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, get_OnCertificateCheck)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCertificateOCSPCheckEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElOCSPServer_get_OnCertificateCheck(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, set_OnCertificateCheck)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElOCSPServer_set_OnCertificateCheck(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCertificateOCSPCheckEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCertificateOCSPCheckEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, get_OnSignatureValidate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOCSPSignatureValidateEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElOCSPServer_get_OnSignatureValidate(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, set_OnSignatureValidate)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElOCSPServer_set_OnSignatureValidate(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBOCSPSignatureValidateEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOCSPSignatureValidateEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, get_OnSigningCertificatesNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOCSPSigningCertificatesNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElOCSPServer_get_OnSigningCertificatesNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, set_OnSigningCertificatesNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElOCSPServer_set_OnSigningCertificatesNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBOCSPSigningCertificatesNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOCSPSigningCertificatesNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPServer, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOCSPServer_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_ProcessRequest, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Request, 0, 1)
	ZEND_ARG_INFO(1, Reply)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_get_ResponderIdType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_set_ResponderIdType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_get_RequestCertificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_get_SignatureAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_set_SignatureAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_get_ProducedAt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_set_ProducedAt, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_get_SignatureRequired, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_set_SignatureRequired, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_get_Options, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_set_Options, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_get_IssuerHashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_set_IssuerHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_get_OnCertificateCheck, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_set_OnCertificateCheck, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_get_OnSignatureValidate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_set_OnSignatureValidate, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_get_OnSigningCertificatesNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer_set_OnSigningCertificatesNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPServer___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOCSPServer_methods[] = {
	PHP_ME(TElOCSPServer, ProcessRequest, arginfo_TElOCSPServer_ProcessRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, get_ResponderIdType, arginfo_TElOCSPServer_get_ResponderIdType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, set_ResponderIdType, arginfo_TElOCSPServer_set_ResponderIdType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, get_RequestCertificates, arginfo_TElOCSPServer_get_RequestCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, get_SignatureAlgorithm, arginfo_TElOCSPServer_get_SignatureAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, set_SignatureAlgorithm, arginfo_TElOCSPServer_set_SignatureAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, get_ProducedAt, arginfo_TElOCSPServer_get_ProducedAt, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, set_ProducedAt, arginfo_TElOCSPServer_set_ProducedAt, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, get_SignatureRequired, arginfo_TElOCSPServer_get_SignatureRequired, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, set_SignatureRequired, arginfo_TElOCSPServer_set_SignatureRequired, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, get_Options, arginfo_TElOCSPServer_get_Options, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, set_Options, arginfo_TElOCSPServer_set_Options, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, get_IssuerHashAlgorithm, arginfo_TElOCSPServer_get_IssuerHashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, set_IssuerHashAlgorithm, arginfo_TElOCSPServer_set_IssuerHashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, get_OnCertificateCheck, arginfo_TElOCSPServer_get_OnCertificateCheck, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, set_OnCertificateCheck, arginfo_TElOCSPServer_set_OnCertificateCheck, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, get_OnSignatureValidate, arginfo_TElOCSPServer_get_OnSignatureValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, set_OnSignatureValidate, arginfo_TElOCSPServer_set_OnSignatureValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, get_OnSigningCertificatesNeeded, arginfo_TElOCSPServer_get_OnSigningCertificatesNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, set_OnSigningCertificatesNeeded, arginfo_TElOCSPServer_set_OnSigningCertificatesNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPServer, __construct, arginfo_TElOCSPServer___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOCSPServer(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOCSPServer_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOCSPServer", TElOCSPServer_methods);
	if (NULL == TElOCSPClass_ce_ptr)
		Register_TElOCSPClass(TSRMLS_C);
	TElOCSPServer_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOCSPClass_ce_ptr);
}

void Register_SBOCSPServer_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBOCSPServerOption", NULL);
	TSBOCSPServerOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBOCSPServerOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBOCSPServerOption_ce_ptr, "osoIncludeVersion", 0)
	
	INIT_CLASS_ENTRY(ce, "TSBOCSPServerOptions", NULL);
	TSBOCSPServerOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBOCSPServerOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBOCSPServerOptions_ce_ptr, "osoIncludeVersion", 1)
}

void Register_SBOCSPServer_Aliases(TSRMLS_D)
{
	if (NULL == TElOCSPServer_ce_ptr)
		Register_TElOCSPServer(TSRMLS_C);
	zend_register_class_alias("ElOCSPServer", TElOCSPServer_ce_ptr);
}

