#include "sbocspstorage.h"

zend_class_entry *TElOCSPResponseStorage_ce_ptr = NULL;

SB_PHP_METHOD(TElOCSPResponseStorage, Add)
{
	zval *oResp;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oResp, TElOCSPResponse_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOCSPResponseStorage_Add(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oResp TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOCSPResponseStorage_Add_1(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOCSPResponse) or ()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPResponseStorage, Remove)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElOCSPResponseStorage_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPResponseStorage, IndexOf)
{
	zval *oResp;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oResp, TElOCSPResponse_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOCSPResponseStorage_IndexOf(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oResp TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOCSPResponse)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPResponseStorage, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOCSPResponseStorage_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPResponseStorage, ExportTo)
{
	zval *oStorage;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStorage, TElOCSPResponseStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOCSPResponseStorage_ExportTo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStorage TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOCSPResponseStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPResponseStorage, get_Responses)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOCSPResponseStorage_get_Responses(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOCSPResponse_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPResponseStorage, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOCSPResponseStorage_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOCSPResponseStorage, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOCSPResponseStorage_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPResponseStorage_Add, 0, 0, 0)
	ZEND_ARG_OBJ_INFO(0, Resp, TElOCSPResponse, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPResponseStorage_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPResponseStorage_IndexOf, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Resp, TElOCSPResponse, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPResponseStorage_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPResponseStorage_ExportTo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Storage, TElOCSPResponseStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPResponseStorage_get_Responses, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPResponseStorage_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOCSPResponseStorage___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOCSPResponseStorage_methods[] = {
	PHP_ME(TElOCSPResponseStorage, Add, arginfo_TElOCSPResponseStorage_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPResponseStorage, Remove, arginfo_TElOCSPResponseStorage_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPResponseStorage, IndexOf, arginfo_TElOCSPResponseStorage_IndexOf, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPResponseStorage, Clear, arginfo_TElOCSPResponseStorage_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPResponseStorage, ExportTo, arginfo_TElOCSPResponseStorage_ExportTo, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPResponseStorage, get_Responses, arginfo_TElOCSPResponseStorage_get_Responses, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPResponseStorage, get_Count, arginfo_TElOCSPResponseStorage_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElOCSPResponseStorage, __construct, arginfo_TElOCSPResponseStorage___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOCSPResponseStorage(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOCSPResponseStorage_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOCSPResponseStorage", TElOCSPResponseStorage_methods);
	if (NULL == TPersistent_ce_ptr)
		Register_TPersistent(TSRMLS_C);
	TElOCSPResponseStorage_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPersistent_ce_ptr);
}

