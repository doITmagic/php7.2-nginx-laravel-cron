#include "sbofficebinarycore.h"

zend_class_entry *TElOfficeBinaryObject_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeBinaryObject, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryObject_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryObject, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryObject_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryObject, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryObject_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryObject_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryObject_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryObject___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeBinaryObject_methods[] = {
	PHP_ME(TElOfficeBinaryObject, LoadFromStream, arginfo_TElOfficeBinaryObject_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryObject, SaveToStream, arginfo_TElOfficeBinaryObject_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryObject, __construct, arginfo_TElOfficeBinaryObject___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeBinaryObject(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeBinaryObject_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeBinaryObject", TElOfficeBinaryObject_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElOfficeBinaryObject_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElOfficeDataSpaceVersionInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeDataSpaceVersionInfo, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceVersionInfo_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceVersionInfo, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceVersionInfo_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceVersionInfo, get_FeatureIdentifier)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeDataSpaceVersionInfo_get_FeatureIdentifier(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1724887295, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceVersionInfo, set_FeatureIdentifier)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceVersionInfo_set_FeatureIdentifier(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceVersionInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeDataSpaceVersionInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceVersionInfo_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceVersionInfo_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceVersionInfo_get_FeatureIdentifier, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceVersionInfo_set_FeatureIdentifier, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceVersionInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeDataSpaceVersionInfo_methods[] = {
	PHP_ME(TElOfficeDataSpaceVersionInfo, LoadFromStream, arginfo_TElOfficeDataSpaceVersionInfo_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceVersionInfo, SaveToStream, arginfo_TElOfficeDataSpaceVersionInfo_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceVersionInfo, get_FeatureIdentifier, arginfo_TElOfficeDataSpaceVersionInfo_get_FeatureIdentifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceVersionInfo, set_FeatureIdentifier, arginfo_TElOfficeDataSpaceVersionInfo_set_FeatureIdentifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceVersionInfo, __construct, arginfo_TElOfficeDataSpaceVersionInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeDataSpaceVersionInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeDataSpaceVersionInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeDataSpaceVersionInfo", TElOfficeDataSpaceVersionInfo_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeDataSpaceVersionInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeDataSpaceReferenceComponent_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeDataSpaceReferenceComponent, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceReferenceComponent_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceReferenceComponent, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceReferenceComponent_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceReferenceComponent, get_ReferenceComponentType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeDataSpaceReferenceComponent_get_ReferenceComponentType(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceReferenceComponent, set_ReferenceComponentType)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceReferenceComponent_set_ReferenceComponentType(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceReferenceComponent, get_ReferenceComponent)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeDataSpaceReferenceComponent_get_ReferenceComponent(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1959522345, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceReferenceComponent, set_ReferenceComponent)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceReferenceComponent_set_ReferenceComponent(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceReferenceComponent, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeDataSpaceReferenceComponent_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceReferenceComponent_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceReferenceComponent_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceReferenceComponent_get_ReferenceComponentType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceReferenceComponent_set_ReferenceComponentType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceReferenceComponent_get_ReferenceComponent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceReferenceComponent_set_ReferenceComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceReferenceComponent___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeDataSpaceReferenceComponent_methods[] = {
	PHP_ME(TElOfficeDataSpaceReferenceComponent, LoadFromStream, arginfo_TElOfficeDataSpaceReferenceComponent_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceReferenceComponent, SaveToStream, arginfo_TElOfficeDataSpaceReferenceComponent_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceReferenceComponent, get_ReferenceComponentType, arginfo_TElOfficeDataSpaceReferenceComponent_get_ReferenceComponentType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceReferenceComponent, set_ReferenceComponentType, arginfo_TElOfficeDataSpaceReferenceComponent_set_ReferenceComponentType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceReferenceComponent, get_ReferenceComponent, arginfo_TElOfficeDataSpaceReferenceComponent_get_ReferenceComponent, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceReferenceComponent, set_ReferenceComponent, arginfo_TElOfficeDataSpaceReferenceComponent_set_ReferenceComponent, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceReferenceComponent, __construct, arginfo_TElOfficeDataSpaceReferenceComponent___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeDataSpaceReferenceComponent(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeDataSpaceReferenceComponent_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeDataSpaceReferenceComponent", TElOfficeDataSpaceReferenceComponent_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeDataSpaceReferenceComponent_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeDataSpaceMapEntry_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeDataSpaceMapEntry, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceMapEntry_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMapEntry, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceMapEntry_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMapEntry, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceMapEntry_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMapEntry, Add)
{
	zval *oARef;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oARef, TElOfficeDataSpaceReferenceComponent_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeDataSpaceMapEntry_Add(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oARef TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficeDataSpaceReferenceComponent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMapEntry, Insert)
{
	sb_zend_long l4Index;
	zval *oARef;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Index, &oARef, TElOfficeDataSpaceReferenceComponent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceMapEntry_Insert(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, SBGetObjectHandle(oARef TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElOfficeDataSpaceReferenceComponent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMapEntry, Delete)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceMapEntry_Delete(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMapEntry, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeDataSpaceMapEntry_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMapEntry, get_ReferenceComponents)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeDataSpaceMapEntry_get_ReferenceComponents(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeDataSpaceReferenceComponent_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMapEntry, get_DataSpaceName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeDataSpaceMapEntry_get_DataSpaceName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(818654366, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMapEntry, set_DataSpaceName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceMapEntry_set_DataSpaceName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMapEntry, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeDataSpaceMapEntry_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMapEntry_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMapEntry_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMapEntry_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMapEntry_Add, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ARef, TElOfficeDataSpaceReferenceComponent, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMapEntry_Insert, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_OBJ_INFO(0, ARef, TElOfficeDataSpaceReferenceComponent, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMapEntry_Delete, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMapEntry_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMapEntry_get_ReferenceComponents, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMapEntry_get_DataSpaceName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMapEntry_set_DataSpaceName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMapEntry___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeDataSpaceMapEntry_methods[] = {
	PHP_ME(TElOfficeDataSpaceMapEntry, LoadFromStream, arginfo_TElOfficeDataSpaceMapEntry_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMapEntry, SaveToStream, arginfo_TElOfficeDataSpaceMapEntry_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMapEntry, Clear, arginfo_TElOfficeDataSpaceMapEntry_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMapEntry, Add, arginfo_TElOfficeDataSpaceMapEntry_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMapEntry, Insert, arginfo_TElOfficeDataSpaceMapEntry_Insert, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMapEntry, Delete, arginfo_TElOfficeDataSpaceMapEntry_Delete, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMapEntry, get_Count, arginfo_TElOfficeDataSpaceMapEntry_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMapEntry, get_ReferenceComponents, arginfo_TElOfficeDataSpaceMapEntry_get_ReferenceComponents, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMapEntry, get_DataSpaceName, arginfo_TElOfficeDataSpaceMapEntry_get_DataSpaceName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMapEntry, set_DataSpaceName, arginfo_TElOfficeDataSpaceMapEntry_set_DataSpaceName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMapEntry, __construct, arginfo_TElOfficeDataSpaceMapEntry___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeDataSpaceMapEntry(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeDataSpaceMapEntry_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeDataSpaceMapEntry", TElOfficeDataSpaceMapEntry_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeDataSpaceMapEntry_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeDataSpaceMap_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeDataSpaceMap, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceMap_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMap, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceMap_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMap, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceMap_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMap, Add)
{
	zval *oAEntry;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAEntry, TElOfficeDataSpaceMapEntry_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeDataSpaceMap_Add(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oAEntry TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficeDataSpaceMapEntry)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMap, Insert)
{
	sb_zend_long l4Index;
	zval *oAEntry;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Index, &oAEntry, TElOfficeDataSpaceMapEntry_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceMap_Insert(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, SBGetObjectHandle(oAEntry TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElOfficeDataSpaceMapEntry)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMap, Delete)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceMap_Delete(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMap, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeDataSpaceMap_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMap, get_MapEntries)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeDataSpaceMap_get_MapEntries(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeDataSpaceMapEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceMap, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeDataSpaceMap_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMap_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMap_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMap_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMap_Add, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AEntry, TElOfficeDataSpaceMapEntry, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMap_Insert, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_OBJ_INFO(0, AEntry, TElOfficeDataSpaceMapEntry, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMap_Delete, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMap_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMap_get_MapEntries, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceMap___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeDataSpaceMap_methods[] = {
	PHP_ME(TElOfficeDataSpaceMap, LoadFromStream, arginfo_TElOfficeDataSpaceMap_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMap, SaveToStream, arginfo_TElOfficeDataSpaceMap_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMap, Clear, arginfo_TElOfficeDataSpaceMap_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMap, Add, arginfo_TElOfficeDataSpaceMap_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMap, Insert, arginfo_TElOfficeDataSpaceMap_Insert, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMap, Delete, arginfo_TElOfficeDataSpaceMap_Delete, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMap, get_Count, arginfo_TElOfficeDataSpaceMap_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMap, get_MapEntries, arginfo_TElOfficeDataSpaceMap_get_MapEntries, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceMap, __construct, arginfo_TElOfficeDataSpaceMap___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeDataSpaceMap(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeDataSpaceMap_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeDataSpaceMap", TElOfficeDataSpaceMap_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeDataSpaceMap_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeDataSpaceDefinition_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeDataSpaceDefinition, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceDefinition_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceDefinition, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceDefinition_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceDefinition, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceDefinition_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceDefinition, Add)
{
	char *sARef;
	sb_str_size sARef_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sARef, &sARef_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeDataSpaceDefinition_Add(SBGetObjectHandle(getThis() TSRMLS_CC), sARef, (int32_t)sARef_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceDefinition, Insert)
{
	char *sARef;
	sb_str_size sARef_len;
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ls", &l4Index, &sARef, &sARef_len) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceDefinition_Insert(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, sARef, (int32_t)sARef_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceDefinition, Delete)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElOfficeDataSpaceDefinition_Delete(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceDefinition, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeDataSpaceDefinition_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceDefinition, get_TransformReferences)
{
	sb_zend_long l4Index;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeDataSpaceDefinition_get_TransformReferences(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1625892206, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDataSpaceDefinition, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeDataSpaceDefinition_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceDefinition_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceDefinition_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceDefinition_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceDefinition_Add, 0, 0, 1)
	ZEND_ARG_INFO(0, ARef)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceDefinition_Insert, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, ARef)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceDefinition_Delete, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceDefinition_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceDefinition_get_TransformReferences, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDataSpaceDefinition___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeDataSpaceDefinition_methods[] = {
	PHP_ME(TElOfficeDataSpaceDefinition, LoadFromStream, arginfo_TElOfficeDataSpaceDefinition_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceDefinition, SaveToStream, arginfo_TElOfficeDataSpaceDefinition_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceDefinition, Clear, arginfo_TElOfficeDataSpaceDefinition_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceDefinition, Add, arginfo_TElOfficeDataSpaceDefinition_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceDefinition, Insert, arginfo_TElOfficeDataSpaceDefinition_Insert, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceDefinition, Delete, arginfo_TElOfficeDataSpaceDefinition_Delete, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceDefinition, get_Count, arginfo_TElOfficeDataSpaceDefinition_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceDefinition, get_TransformReferences, arginfo_TElOfficeDataSpaceDefinition_get_TransformReferences, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDataSpaceDefinition, __construct, arginfo_TElOfficeDataSpaceDefinition___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeDataSpaceDefinition(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeDataSpaceDefinition_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeDataSpaceDefinition", TElOfficeDataSpaceDefinition_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeDataSpaceDefinition_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeTransformInfoHeader_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeTransformInfoHeader, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeTransformInfoHeader_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeTransformInfoHeader, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeTransformInfoHeader_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeTransformInfoHeader, get_TransformID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeTransformInfoHeader_get_TransformID(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(767021258, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeTransformInfoHeader, set_TransformID)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeTransformInfoHeader_set_TransformID(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeTransformInfoHeader, get_TransformName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeTransformInfoHeader_get_TransformName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-115540952, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeTransformInfoHeader, set_TransformName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeTransformInfoHeader_set_TransformName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeTransformInfoHeader, get_TransformType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeTransformInfoHeader_get_TransformType(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeTransformInfoHeader, set_TransformType)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeTransformInfoHeader_set_TransformType(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeTransformInfoHeader, get_ReaderVersion)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeVersion roOutResult;
		SBCheckError(TElOfficeTransformInfoHeader_get_ReaderVersion(SBGetObjectHandle(getThis() TSRMLS_CC), &roOutResult) TSRMLS_CC);
		object_init_ex(return_value, TSBOfficeVersion_ce_ptr);
		SBSetStruct(return_value, &roOutResult, sizeof(TSBOfficeVersion) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeTransformInfoHeader, set_ReaderVersion)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oValue, TSBOfficeVersion_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeTransformInfoHeader_set_ReaderVersion(SBGetObjectHandle(getThis() TSRMLS_CC), *(TSBOfficeVersion *)SBGetStructPointer(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOfficeVersion)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeTransformInfoHeader, get_UpdaterVersion)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeVersion roOutResult;
		SBCheckError(TElOfficeTransformInfoHeader_get_UpdaterVersion(SBGetObjectHandle(getThis() TSRMLS_CC), &roOutResult) TSRMLS_CC);
		object_init_ex(return_value, TSBOfficeVersion_ce_ptr);
		SBSetStruct(return_value, &roOutResult, sizeof(TSBOfficeVersion) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeTransformInfoHeader, set_UpdaterVersion)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oValue, TSBOfficeVersion_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeTransformInfoHeader_set_UpdaterVersion(SBGetObjectHandle(getThis() TSRMLS_CC), *(TSBOfficeVersion *)SBGetStructPointer(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOfficeVersion)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeTransformInfoHeader, get_WriterVersion)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeVersion roOutResult;
		SBCheckError(TElOfficeTransformInfoHeader_get_WriterVersion(SBGetObjectHandle(getThis() TSRMLS_CC), &roOutResult) TSRMLS_CC);
		object_init_ex(return_value, TSBOfficeVersion_ce_ptr);
		SBSetStruct(return_value, &roOutResult, sizeof(TSBOfficeVersion) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeTransformInfoHeader, set_WriterVersion)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oValue, TSBOfficeVersion_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeTransformInfoHeader_set_WriterVersion(SBGetObjectHandle(getThis() TSRMLS_CC), *(TSBOfficeVersion *)SBGetStructPointer(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOfficeVersion)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeTransformInfoHeader, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeTransformInfoHeader_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader_get_TransformID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader_set_TransformID, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader_get_TransformName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader_set_TransformName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader_get_TransformType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader_set_TransformType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader_get_ReaderVersion, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader_set_ReaderVersion, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TSBOfficeVersion, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader_get_UpdaterVersion, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader_set_UpdaterVersion, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TSBOfficeVersion, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader_get_WriterVersion, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader_set_WriterVersion, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TSBOfficeVersion, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeTransformInfoHeader___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeTransformInfoHeader_methods[] = {
	PHP_ME(TElOfficeTransformInfoHeader, LoadFromStream, arginfo_TElOfficeTransformInfoHeader_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeTransformInfoHeader, SaveToStream, arginfo_TElOfficeTransformInfoHeader_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeTransformInfoHeader, get_TransformID, arginfo_TElOfficeTransformInfoHeader_get_TransformID, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeTransformInfoHeader, set_TransformID, arginfo_TElOfficeTransformInfoHeader_set_TransformID, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeTransformInfoHeader, get_TransformName, arginfo_TElOfficeTransformInfoHeader_get_TransformName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeTransformInfoHeader, set_TransformName, arginfo_TElOfficeTransformInfoHeader_set_TransformName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeTransformInfoHeader, get_TransformType, arginfo_TElOfficeTransformInfoHeader_get_TransformType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeTransformInfoHeader, set_TransformType, arginfo_TElOfficeTransformInfoHeader_set_TransformType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeTransformInfoHeader, get_ReaderVersion, arginfo_TElOfficeTransformInfoHeader_get_ReaderVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeTransformInfoHeader, set_ReaderVersion, arginfo_TElOfficeTransformInfoHeader_set_ReaderVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeTransformInfoHeader, get_UpdaterVersion, arginfo_TElOfficeTransformInfoHeader_get_UpdaterVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeTransformInfoHeader, set_UpdaterVersion, arginfo_TElOfficeTransformInfoHeader_set_UpdaterVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeTransformInfoHeader, get_WriterVersion, arginfo_TElOfficeTransformInfoHeader_get_WriterVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeTransformInfoHeader, set_WriterVersion, arginfo_TElOfficeTransformInfoHeader_set_WriterVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeTransformInfoHeader, __construct, arginfo_TElOfficeTransformInfoHeader___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeTransformInfoHeader(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeTransformInfoHeader_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeTransformInfoHeader", TElOfficeTransformInfoHeader_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeTransformInfoHeader_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeEncryptionTransformInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeEncryptionTransformInfo, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionTransformInfo_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionTransformInfo, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionTransformInfo_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionTransformInfo, get_EncryptionName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeEncryptionTransformInfo_get_EncryptionName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-142559156, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionTransformInfo, set_EncryptionName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionTransformInfo_set_EncryptionName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionTransformInfo, get_EncryptionBlockSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptionTransformInfo_get_EncryptionBlockSize(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionTransformInfo, set_EncryptionBlockSize)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionTransformInfo_set_EncryptionBlockSize(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionTransformInfo, get_CipherMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptionTransformInfo_get_CipherMode(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionTransformInfo, set_CipherMode)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionTransformInfo_set_CipherMode(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionTransformInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeEncryptionTransformInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionTransformInfo_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionTransformInfo_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionTransformInfo_get_EncryptionName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionTransformInfo_set_EncryptionName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionTransformInfo_get_EncryptionBlockSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionTransformInfo_set_EncryptionBlockSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionTransformInfo_get_CipherMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionTransformInfo_set_CipherMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionTransformInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeEncryptionTransformInfo_methods[] = {
	PHP_ME(TElOfficeEncryptionTransformInfo, LoadFromStream, arginfo_TElOfficeEncryptionTransformInfo_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionTransformInfo, SaveToStream, arginfo_TElOfficeEncryptionTransformInfo_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionTransformInfo, get_EncryptionName, arginfo_TElOfficeEncryptionTransformInfo_get_EncryptionName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionTransformInfo, set_EncryptionName, arginfo_TElOfficeEncryptionTransformInfo_set_EncryptionName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionTransformInfo, get_EncryptionBlockSize, arginfo_TElOfficeEncryptionTransformInfo_get_EncryptionBlockSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionTransformInfo, set_EncryptionBlockSize, arginfo_TElOfficeEncryptionTransformInfo_set_EncryptionBlockSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionTransformInfo, get_CipherMode, arginfo_TElOfficeEncryptionTransformInfo_get_CipherMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionTransformInfo, set_CipherMode, arginfo_TElOfficeEncryptionTransformInfo_set_CipherMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionTransformInfo, __construct, arginfo_TElOfficeEncryptionTransformInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeEncryptionTransformInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeEncryptionTransformInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeEncryptionTransformInfo", TElOfficeEncryptionTransformInfo_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeEncryptionTransformInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeExtensibilityHeader_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeExtensibilityHeader, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeExtensibilityHeader_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeExtensibilityHeader, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeExtensibilityHeader_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeExtensibilityHeader, get_Length)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeExtensibilityHeader_get_Length(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeExtensibilityHeader, set_Length)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeExtensibilityHeader_set_Length(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeExtensibilityHeader, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeExtensibilityHeader_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeExtensibilityHeader_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeExtensibilityHeader_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeExtensibilityHeader_get_Length, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeExtensibilityHeader_set_Length, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeExtensibilityHeader___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeExtensibilityHeader_methods[] = {
	PHP_ME(TElOfficeExtensibilityHeader, LoadFromStream, arginfo_TElOfficeExtensibilityHeader_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeExtensibilityHeader, SaveToStream, arginfo_TElOfficeExtensibilityHeader_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeExtensibilityHeader, get_Length, arginfo_TElOfficeExtensibilityHeader_get_Length, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeExtensibilityHeader, set_Length, arginfo_TElOfficeExtensibilityHeader_set_Length, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeExtensibilityHeader, __construct, arginfo_TElOfficeExtensibilityHeader___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeExtensibilityHeader(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeExtensibilityHeader_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeExtensibilityHeader", TElOfficeExtensibilityHeader_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeExtensibilityHeader_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeIRMDSTransformInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeIRMDSTransformInfo, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeIRMDSTransformInfo_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeIRMDSTransformInfo, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeIRMDSTransformInfo_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeIRMDSTransformInfo, get_TransformInfoHeader)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeIRMDSTransformInfo_get_TransformInfoHeader(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeTransformInfoHeader_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeIRMDSTransformInfo, get_ExtensibilityHeader)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeIRMDSTransformInfo_get_ExtensibilityHeader(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeExtensibilityHeader_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeIRMDSTransformInfo, get_XrMLLicense)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeIRMDSTransformInfo_get_XrMLLicense(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2007089094, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeIRMDSTransformInfo, set_XrMLLicense)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeIRMDSTransformInfo_set_XrMLLicense(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeIRMDSTransformInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeIRMDSTransformInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeIRMDSTransformInfo_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeIRMDSTransformInfo_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeIRMDSTransformInfo_get_TransformInfoHeader, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeIRMDSTransformInfo_get_ExtensibilityHeader, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeIRMDSTransformInfo_get_XrMLLicense, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeIRMDSTransformInfo_set_XrMLLicense, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeIRMDSTransformInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeIRMDSTransformInfo_methods[] = {
	PHP_ME(TElOfficeIRMDSTransformInfo, LoadFromStream, arginfo_TElOfficeIRMDSTransformInfo_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeIRMDSTransformInfo, SaveToStream, arginfo_TElOfficeIRMDSTransformInfo_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeIRMDSTransformInfo, get_TransformInfoHeader, arginfo_TElOfficeIRMDSTransformInfo_get_TransformInfoHeader, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeIRMDSTransformInfo, get_ExtensibilityHeader, arginfo_TElOfficeIRMDSTransformInfo_get_ExtensibilityHeader, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeIRMDSTransformInfo, get_XrMLLicense, arginfo_TElOfficeIRMDSTransformInfo_get_XrMLLicense, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeIRMDSTransformInfo, set_XrMLLicense, arginfo_TElOfficeIRMDSTransformInfo_set_XrMLLicense, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeIRMDSTransformInfo, __construct, arginfo_TElOfficeIRMDSTransformInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeIRMDSTransformInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeIRMDSTransformInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeIRMDSTransformInfo", TElOfficeIRMDSTransformInfo_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeIRMDSTransformInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeEndUserLicenseHeader_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeEndUserLicenseHeader, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEndUserLicenseHeader_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEndUserLicenseHeader, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEndUserLicenseHeader_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEndUserLicenseHeader, get_ID_String)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeEndUserLicenseHeader_get_ID_String(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-669079394, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEndUserLicenseHeader, set_ID_String)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeEndUserLicenseHeader_set_ID_String(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEndUserLicenseHeader, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeEndUserLicenseHeader_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEndUserLicenseHeader_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEndUserLicenseHeader_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEndUserLicenseHeader_get_ID_String, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEndUserLicenseHeader_set_ID_String, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEndUserLicenseHeader___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeEndUserLicenseHeader_methods[] = {
	PHP_ME(TElOfficeEndUserLicenseHeader, LoadFromStream, arginfo_TElOfficeEndUserLicenseHeader_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEndUserLicenseHeader, SaveToStream, arginfo_TElOfficeEndUserLicenseHeader_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEndUserLicenseHeader, get_ID_String, arginfo_TElOfficeEndUserLicenseHeader_get_ID_String, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEndUserLicenseHeader, set_ID_String, arginfo_TElOfficeEndUserLicenseHeader_set_ID_String, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEndUserLicenseHeader, __construct, arginfo_TElOfficeEndUserLicenseHeader___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeEndUserLicenseHeader(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeEndUserLicenseHeader_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeEndUserLicenseHeader", TElOfficeEndUserLicenseHeader_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeEndUserLicenseHeader_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeEncryptionHeader_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeEncryptionHeader, LoadFromStream)
{
	sb_zend_long u4Length;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionHeader_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStream, TStream_ce_ptr, &u4Length) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionHeader_LoadFromStream_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (uint32_t)u4Length) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream) or (\\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionHeader, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionHeader_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionHeader, get_Flags)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptionHeader_get_Flags(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionHeader, set_Flags)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionHeader_set_Flags(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionHeader, get_AlgID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptionHeader_get_AlgID(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionHeader, set_AlgID)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionHeader_set_AlgID(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionHeader, get_AlgIDHash)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptionHeader_get_AlgIDHash(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionHeader, set_AlgIDHash)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionHeader_set_AlgIDHash(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionHeader, get_KeySize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptionHeader_get_KeySize(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionHeader, set_KeySize)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionHeader_set_KeySize(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionHeader, get_ProviderType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptionHeader_get_ProviderType(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionHeader, set_ProviderType)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionHeader_set_ProviderType(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionHeader, get_CSPName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeEncryptionHeader_get_CSPName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-654900006, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionHeader, set_CSPName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionHeader_set_CSPName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionHeader, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeEncryptionHeader_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Length)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader_get_Flags, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader_set_Flags, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader_get_AlgID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader_set_AlgID, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader_get_AlgIDHash, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader_set_AlgIDHash, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader_get_KeySize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader_set_KeySize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader_get_ProviderType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader_set_ProviderType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader_get_CSPName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader_set_CSPName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionHeader___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeEncryptionHeader_methods[] = {
	PHP_ME(TElOfficeEncryptionHeader, LoadFromStream, arginfo_TElOfficeEncryptionHeader_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionHeader, SaveToStream, arginfo_TElOfficeEncryptionHeader_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionHeader, get_Flags, arginfo_TElOfficeEncryptionHeader_get_Flags, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionHeader, set_Flags, arginfo_TElOfficeEncryptionHeader_set_Flags, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionHeader, get_AlgID, arginfo_TElOfficeEncryptionHeader_get_AlgID, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionHeader, set_AlgID, arginfo_TElOfficeEncryptionHeader_set_AlgID, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionHeader, get_AlgIDHash, arginfo_TElOfficeEncryptionHeader_get_AlgIDHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionHeader, set_AlgIDHash, arginfo_TElOfficeEncryptionHeader_set_AlgIDHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionHeader, get_KeySize, arginfo_TElOfficeEncryptionHeader_get_KeySize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionHeader, set_KeySize, arginfo_TElOfficeEncryptionHeader_set_KeySize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionHeader, get_ProviderType, arginfo_TElOfficeEncryptionHeader_get_ProviderType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionHeader, set_ProviderType, arginfo_TElOfficeEncryptionHeader_set_ProviderType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionHeader, get_CSPName, arginfo_TElOfficeEncryptionHeader_get_CSPName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionHeader, set_CSPName, arginfo_TElOfficeEncryptionHeader_set_CSPName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionHeader, __construct, arginfo_TElOfficeEncryptionHeader___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeEncryptionHeader(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeEncryptionHeader_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeEncryptionHeader", TElOfficeEncryptionHeader_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeEncryptionHeader_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeEncryptionVerifier_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeEncryptionVerifier, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionVerifier_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionVerifier, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionVerifier_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionVerifier, get_Salt)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeEncryptionVerifier_get_Salt(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(874505940, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionVerifier, set_Salt)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeEncryptionVerifier_set_Salt(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionVerifier, get_EncryptedVerifier)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeEncryptionVerifier_get_EncryptedVerifier(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(108409809, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionVerifier, set_EncryptedVerifier)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeEncryptionVerifier_set_EncryptedVerifier(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionVerifier, get_VerifierHashSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptionVerifier_get_VerifierHashSize(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionVerifier, set_VerifierHashSize)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionVerifier_set_VerifierHashSize(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionVerifier, get_EncryptedVerifierHash)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeEncryptionVerifier_get_EncryptedVerifierHash(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(2014178538, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionVerifier, set_EncryptedVerifierHash)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeEncryptionVerifier_set_EncryptedVerifierHash(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionVerifier, get_ExpectedEncryptedVerifierHashSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptionVerifier_get_ExpectedEncryptedVerifierHashSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionVerifier, set_ExpectedEncryptedVerifierHashSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionVerifier_set_ExpectedEncryptedVerifierHashSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionVerifier, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeEncryptionVerifier_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionVerifier_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionVerifier_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionVerifier_get_Salt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionVerifier_set_Salt, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionVerifier_get_EncryptedVerifier, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionVerifier_set_EncryptedVerifier, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionVerifier_get_VerifierHashSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionVerifier_set_VerifierHashSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionVerifier_get_EncryptedVerifierHash, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionVerifier_set_EncryptedVerifierHash, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionVerifier_get_ExpectedEncryptedVerifierHashSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionVerifier_set_ExpectedEncryptedVerifierHashSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionVerifier___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeEncryptionVerifier_methods[] = {
	PHP_ME(TElOfficeEncryptionVerifier, LoadFromStream, arginfo_TElOfficeEncryptionVerifier_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionVerifier, SaveToStream, arginfo_TElOfficeEncryptionVerifier_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionVerifier, get_Salt, arginfo_TElOfficeEncryptionVerifier_get_Salt, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionVerifier, set_Salt, arginfo_TElOfficeEncryptionVerifier_set_Salt, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionVerifier, get_EncryptedVerifier, arginfo_TElOfficeEncryptionVerifier_get_EncryptedVerifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionVerifier, set_EncryptedVerifier, arginfo_TElOfficeEncryptionVerifier_set_EncryptedVerifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionVerifier, get_VerifierHashSize, arginfo_TElOfficeEncryptionVerifier_get_VerifierHashSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionVerifier, set_VerifierHashSize, arginfo_TElOfficeEncryptionVerifier_set_VerifierHashSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionVerifier, get_EncryptedVerifierHash, arginfo_TElOfficeEncryptionVerifier_get_EncryptedVerifierHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionVerifier, set_EncryptedVerifierHash, arginfo_TElOfficeEncryptionVerifier_set_EncryptedVerifierHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionVerifier, get_ExpectedEncryptedVerifierHashSize, arginfo_TElOfficeEncryptionVerifier_get_ExpectedEncryptedVerifierHashSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionVerifier, set_ExpectedEncryptedVerifierHashSize, arginfo_TElOfficeEncryptionVerifier_set_ExpectedEncryptedVerifierHashSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionVerifier, __construct, arginfo_TElOfficeEncryptionVerifier___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeEncryptionVerifier(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeEncryptionVerifier_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeEncryptionVerifier", TElOfficeEncryptionVerifier_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeEncryptionVerifier_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeEncryptionInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeEncryptionInfo, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfo_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfo, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfo_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfo, get_EncryptionVersionInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeVersion roOutResult;
		SBCheckError(TElOfficeEncryptionInfo_get_EncryptionVersionInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &roOutResult) TSRMLS_CC);
		object_init_ex(return_value, TSBOfficeVersion_ce_ptr);
		SBSetStruct(return_value, &roOutResult, sizeof(TSBOfficeVersion) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfo, set_EncryptionVersionInfo)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oValue, TSBOfficeVersion_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfo_set_EncryptionVersionInfo(SBGetObjectHandle(getThis() TSRMLS_CC), *(TSBOfficeVersion *)SBGetStructPointer(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOfficeVersion)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeEncryptionInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfo_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfo_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfo_get_EncryptionVersionInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfo_set_EncryptionVersionInfo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TSBOfficeVersion, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeEncryptionInfo_methods[] = {
	PHP_ME(TElOfficeEncryptionInfo, LoadFromStream, arginfo_TElOfficeEncryptionInfo_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfo, SaveToStream, arginfo_TElOfficeEncryptionInfo_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfo, get_EncryptionVersionInfo, arginfo_TElOfficeEncryptionInfo_get_EncryptionVersionInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfo, set_EncryptionVersionInfo, arginfo_TElOfficeEncryptionInfo_set_EncryptionVersionInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfo, __construct, arginfo_TElOfficeEncryptionInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeEncryptionInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeEncryptionInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeEncryptionInfo", TElOfficeEncryptionInfo_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeEncryptionInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeEncryptionInfoV1_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeEncryptionInfoV1, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfoV1_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV1, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfoV1_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV1, get_Salt)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeEncryptionInfoV1_get_Salt(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1375349291, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV1, set_Salt)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeEncryptionInfoV1_set_Salt(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV1, get_EncryptedVerifier)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeEncryptionInfoV1_get_EncryptedVerifier(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(579308239, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV1, set_EncryptedVerifier)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeEncryptionInfoV1_set_EncryptedVerifier(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV1, get_EncryptedVerifierHash)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeEncryptionInfoV1_get_EncryptedVerifierHash(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(870333940, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV1, set_EncryptedVerifierHash)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeEncryptionInfoV1_set_EncryptedVerifierHash(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV1, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeEncryptionInfoV1_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV1_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV1_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV1_get_Salt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV1_set_Salt, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV1_get_EncryptedVerifier, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV1_set_EncryptedVerifier, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV1_get_EncryptedVerifierHash, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV1_set_EncryptedVerifierHash, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV1___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeEncryptionInfoV1_methods[] = {
	PHP_ME(TElOfficeEncryptionInfoV1, LoadFromStream, arginfo_TElOfficeEncryptionInfoV1_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV1, SaveToStream, arginfo_TElOfficeEncryptionInfoV1_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV1, get_Salt, arginfo_TElOfficeEncryptionInfoV1_get_Salt, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV1, set_Salt, arginfo_TElOfficeEncryptionInfoV1_set_Salt, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV1, get_EncryptedVerifier, arginfo_TElOfficeEncryptionInfoV1_get_EncryptedVerifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV1, set_EncryptedVerifier, arginfo_TElOfficeEncryptionInfoV1_set_EncryptedVerifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV1, get_EncryptedVerifierHash, arginfo_TElOfficeEncryptionInfoV1_get_EncryptedVerifierHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV1, set_EncryptedVerifierHash, arginfo_TElOfficeEncryptionInfoV1_set_EncryptedVerifierHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV1, __construct, arginfo_TElOfficeEncryptionInfoV1___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeEncryptionInfoV1(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeEncryptionInfoV1_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeEncryptionInfoV1", TElOfficeEncryptionInfoV1_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeEncryptionInfoV1_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeEncryptionInfoV2_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeEncryptionInfoV2, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfoV2_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV2, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfoV2_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV2, get_EncryptionHeaderFlags)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptionInfoV2_get_EncryptionHeaderFlags(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV2, set_EncryptionHeaderFlags)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfoV2_set_EncryptionHeaderFlags(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV2, get_EncryptionHeader)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeEncryptionInfoV2_get_EncryptionHeader(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeEncryptionHeader_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV2, set_EncryptionHeader)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElOfficeEncryptionHeader_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfoV2_set_EncryptionHeader(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficeEncryptionHeader)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV2, get_EncryptionVerifier)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeEncryptionInfoV2_get_EncryptionVerifier(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeEncryptionVerifier_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV2, set_EncryptionVerifier)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElOfficeEncryptionVerifier_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfoV2_set_EncryptionVerifier(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficeEncryptionVerifier)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV2, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeEncryptionInfoV2_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV2_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV2_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV2_get_EncryptionHeaderFlags, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV2_set_EncryptionHeaderFlags, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV2_get_EncryptionHeader, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV2_set_EncryptionHeader, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElOfficeEncryptionHeader, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV2_get_EncryptionVerifier, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV2_set_EncryptionVerifier, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElOfficeEncryptionVerifier, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV2___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeEncryptionInfoV2_methods[] = {
	PHP_ME(TElOfficeEncryptionInfoV2, LoadFromStream, arginfo_TElOfficeEncryptionInfoV2_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV2, SaveToStream, arginfo_TElOfficeEncryptionInfoV2_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV2, get_EncryptionHeaderFlags, arginfo_TElOfficeEncryptionInfoV2_get_EncryptionHeaderFlags, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV2, set_EncryptionHeaderFlags, arginfo_TElOfficeEncryptionInfoV2_set_EncryptionHeaderFlags, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV2, get_EncryptionHeader, arginfo_TElOfficeEncryptionInfoV2_get_EncryptionHeader, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV2, set_EncryptionHeader, arginfo_TElOfficeEncryptionInfoV2_set_EncryptionHeader, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV2, get_EncryptionVerifier, arginfo_TElOfficeEncryptionInfoV2_get_EncryptionVerifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV2, set_EncryptionVerifier, arginfo_TElOfficeEncryptionInfoV2_set_EncryptionVerifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV2, __construct, arginfo_TElOfficeEncryptionInfoV2___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeEncryptionInfoV2(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeEncryptionInfoV2_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeEncryptionInfoV2", TElOfficeEncryptionInfoV2_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeEncryptionInfoV2_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeEncryptionInfoV3_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeEncryptionInfoV3, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfoV3_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV3, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfoV3_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV3, get_EncryptionHeaderFlags)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptionInfoV3_get_EncryptionHeaderFlags(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV3, set_EncryptionHeaderFlags)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfoV3_set_EncryptionHeaderFlags(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV3, get_EncryptionHeader)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeEncryptionInfoV3_get_EncryptionHeader(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeEncryptionHeader_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV3, set_EncryptionHeader)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElOfficeEncryptionHeader_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfoV3_set_EncryptionHeader(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficeEncryptionHeader)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV3, get_EncryptionInfo)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeEncryptionInfoV3_get_EncryptionInfo(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(145205616, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV3, set_EncryptionInfo)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfoV3_set_EncryptionInfo(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV3, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeEncryptionInfoV3_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV3_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV3_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV3_get_EncryptionHeaderFlags, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV3_set_EncryptionHeaderFlags, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV3_get_EncryptionHeader, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV3_set_EncryptionHeader, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElOfficeEncryptionHeader, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV3_get_EncryptionInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV3_set_EncryptionInfo, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV3___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeEncryptionInfoV3_methods[] = {
	PHP_ME(TElOfficeEncryptionInfoV3, LoadFromStream, arginfo_TElOfficeEncryptionInfoV3_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV3, SaveToStream, arginfo_TElOfficeEncryptionInfoV3_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV3, get_EncryptionHeaderFlags, arginfo_TElOfficeEncryptionInfoV3_get_EncryptionHeaderFlags, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV3, set_EncryptionHeaderFlags, arginfo_TElOfficeEncryptionInfoV3_set_EncryptionHeaderFlags, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV3, get_EncryptionHeader, arginfo_TElOfficeEncryptionInfoV3_get_EncryptionHeader, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV3, set_EncryptionHeader, arginfo_TElOfficeEncryptionInfoV3_set_EncryptionHeader, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV3, get_EncryptionInfo, arginfo_TElOfficeEncryptionInfoV3_get_EncryptionInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV3, set_EncryptionInfo, arginfo_TElOfficeEncryptionInfoV3_set_EncryptionInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV3, __construct, arginfo_TElOfficeEncryptionInfoV3___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeEncryptionInfoV3(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeEncryptionInfoV3_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeEncryptionInfoV3", TElOfficeEncryptionInfoV3_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeEncryptionInfoV3_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeEncryptionInfoV4_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeEncryptionInfoV4, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfoV4_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV4, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptionInfoV4_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV4, get_XmlEncryptionDescriptor)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeEncryptionInfoV4_get_XmlEncryptionDescriptor(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1224412850, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV4, set_XmlEncryptionDescriptor)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeEncryptionInfoV4_set_XmlEncryptionDescriptor(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptionInfoV4, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeEncryptionInfoV4_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV4_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV4_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV4_get_XmlEncryptionDescriptor, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV4_set_XmlEncryptionDescriptor, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptionInfoV4___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeEncryptionInfoV4_methods[] = {
	PHP_ME(TElOfficeEncryptionInfoV4, LoadFromStream, arginfo_TElOfficeEncryptionInfoV4_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV4, SaveToStream, arginfo_TElOfficeEncryptionInfoV4_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV4, get_XmlEncryptionDescriptor, arginfo_TElOfficeEncryptionInfoV4_get_XmlEncryptionDescriptor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV4, set_XmlEncryptionDescriptor, arginfo_TElOfficeEncryptionInfoV4_set_XmlEncryptionDescriptor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptionInfoV4, __construct, arginfo_TElOfficeEncryptionInfoV4___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeEncryptionInfoV4(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeEncryptionInfoV4_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeEncryptionInfoV4", TElOfficeEncryptionInfoV4_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeEncryptionInfoV4_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeXORObfuscation_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeXORObfuscation, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeXORObfuscation_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeXORObfuscation, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeXORObfuscation_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeXORObfuscation, get_Key)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeXORObfuscation_get_Key(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeXORObfuscation, set_Key)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeXORObfuscation_set_Key(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeXORObfuscation, get_VerificationBytes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeXORObfuscation_get_VerificationBytes(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeXORObfuscation, set_VerificationBytes)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeXORObfuscation_set_VerificationBytes(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeXORObfuscation, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeXORObfuscation_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeXORObfuscation_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeXORObfuscation_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeXORObfuscation_get_Key, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeXORObfuscation_set_Key, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeXORObfuscation_get_VerificationBytes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeXORObfuscation_set_VerificationBytes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeXORObfuscation___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeXORObfuscation_methods[] = {
	PHP_ME(TElOfficeXORObfuscation, LoadFromStream, arginfo_TElOfficeXORObfuscation_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeXORObfuscation, SaveToStream, arginfo_TElOfficeXORObfuscation_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeXORObfuscation, get_Key, arginfo_TElOfficeXORObfuscation_get_Key, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeXORObfuscation, set_Key, arginfo_TElOfficeXORObfuscation_set_Key, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeXORObfuscation, get_VerificationBytes, arginfo_TElOfficeXORObfuscation_get_VerificationBytes, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeXORObfuscation, set_VerificationBytes, arginfo_TElOfficeXORObfuscation_set_VerificationBytes, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeXORObfuscation, __construct, arginfo_TElOfficeXORObfuscation___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeXORObfuscation(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeXORObfuscation_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeXORObfuscation", TElOfficeXORObfuscation_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeXORObfuscation_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeEncryptedStreamDescriptor_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeEncryptedStreamDescriptor, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptedStreamDescriptor_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptedStreamDescriptor, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptedStreamDescriptor_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptedStreamDescriptor, get_StreamName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeEncryptedStreamDescriptor_get_StreamName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2134018760, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptedStreamDescriptor, set_StreamName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptedStreamDescriptor_set_StreamName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptedStreamDescriptor, get_StreamOffset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptedStreamDescriptor_get_StreamOffset(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptedStreamDescriptor, set_StreamOffset)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptedStreamDescriptor_set_StreamOffset(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptedStreamDescriptor, get_StreamSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptedStreamDescriptor_get_StreamSize(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptedStreamDescriptor, set_StreamSize)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptedStreamDescriptor_set_StreamSize(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptedStreamDescriptor, get_Block)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptedStreamDescriptor_get_Block(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptedStreamDescriptor, set_Block)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptedStreamDescriptor_set_Block(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptedStreamDescriptor, get_Flags)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElOfficeEncryptedStreamDescriptor_get_Flags(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptedStreamDescriptor, set_Flags)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		SBCheckError(TElOfficeEncryptedStreamDescriptor_set_Flags(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeEncryptedStreamDescriptor, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeEncryptedStreamDescriptor_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptedStreamDescriptor_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptedStreamDescriptor_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptedStreamDescriptor_get_StreamName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptedStreamDescriptor_set_StreamName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptedStreamDescriptor_get_StreamOffset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptedStreamDescriptor_set_StreamOffset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptedStreamDescriptor_get_StreamSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptedStreamDescriptor_set_StreamSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptedStreamDescriptor_get_Block, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptedStreamDescriptor_set_Block, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptedStreamDescriptor_get_Flags, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptedStreamDescriptor_set_Flags, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeEncryptedStreamDescriptor___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeEncryptedStreamDescriptor_methods[] = {
	PHP_ME(TElOfficeEncryptedStreamDescriptor, LoadFromStream, arginfo_TElOfficeEncryptedStreamDescriptor_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptedStreamDescriptor, SaveToStream, arginfo_TElOfficeEncryptedStreamDescriptor_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptedStreamDescriptor, get_StreamName, arginfo_TElOfficeEncryptedStreamDescriptor_get_StreamName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptedStreamDescriptor, set_StreamName, arginfo_TElOfficeEncryptedStreamDescriptor_set_StreamName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptedStreamDescriptor, get_StreamOffset, arginfo_TElOfficeEncryptedStreamDescriptor_get_StreamOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptedStreamDescriptor, set_StreamOffset, arginfo_TElOfficeEncryptedStreamDescriptor_set_StreamOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptedStreamDescriptor, get_StreamSize, arginfo_TElOfficeEncryptedStreamDescriptor_get_StreamSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptedStreamDescriptor, set_StreamSize, arginfo_TElOfficeEncryptedStreamDescriptor_set_StreamSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptedStreamDescriptor, get_Block, arginfo_TElOfficeEncryptedStreamDescriptor_get_Block, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptedStreamDescriptor, set_Block, arginfo_TElOfficeEncryptedStreamDescriptor_set_Block, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptedStreamDescriptor, get_Flags, arginfo_TElOfficeEncryptedStreamDescriptor_get_Flags, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptedStreamDescriptor, set_Flags, arginfo_TElOfficeEncryptedStreamDescriptor_set_Flags, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeEncryptedStreamDescriptor, __construct, arginfo_TElOfficeEncryptedStreamDescriptor___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeEncryptedStreamDescriptor(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeEncryptedStreamDescriptor_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeEncryptedStreamDescriptor", TElOfficeEncryptedStreamDescriptor_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeEncryptedStreamDescriptor_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeCertificateInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeCertificateInfo, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeCertificateInfo_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeCertificateInfo_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, get_ExpireTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
#ifdef SB_WINDOWS
		windows_FILETIME roOutResult;
#else
		_FILETIME roOutResult;
#endif
		SBCheckError(TElOfficeCertificateInfo_get_ExpireTime(SBGetObjectHandle(getThis() TSRMLS_CC), &roOutResult) TSRMLS_CC);
#ifdef SB_WINDOWS
		object_init_ex(return_value, windows_FILETIME_ce_ptr);
		SBSetStruct(return_value, &roOutResult, sizeof(windows_FILETIME) TSRMLS_CC);
#else
		object_init_ex(return_value, _FILETIME_ce_ptr);
		SBSetStruct(return_value, &roOutResult, sizeof(_FILETIME) TSRMLS_CC);
#endif
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, set_ExpireTime)
{
	zval *oValue;
#ifdef SB_WINDOWS
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oValue, windows_FILETIME_ce_ptr) == SUCCESS)
#else
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oValue, _FILETIME_ce_ptr) == SUCCESS)
#endif
	{
#ifdef SB_WINDOWS
		SBCheckError(TElOfficeCertificateInfo_set_ExpireTime(SBGetObjectHandle(getThis() TSRMLS_CC), (windows_FILETIME *)SBGetStructPointer(oValue TSRMLS_CC)) TSRMLS_CC);
#else
		SBCheckError(TElOfficeCertificateInfo_set_ExpireTime(SBGetObjectHandle(getThis() TSRMLS_CC), (_FILETIME *)SBGetStructPointer(oValue TSRMLS_CC)) TSRMLS_CC);
#endif
	}
	else
	{
#ifdef SB_WINDOWS
		SBErrorExpectsArguments("(\\windows_FILETIME)" TSRMLS_CC);
#else
		SBErrorExpectsArguments("(\\_FILETIME)" TSRMLS_CC);
#endif
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, get_SignTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
#ifdef SB_WINDOWS
		windows_FILETIME roOutResult;
#else
		_FILETIME roOutResult;
#endif
		SBCheckError(TElOfficeCertificateInfo_get_SignTime(SBGetObjectHandle(getThis() TSRMLS_CC), &roOutResult) TSRMLS_CC);
#ifdef SB_WINDOWS
		object_init_ex(return_value, windows_FILETIME_ce_ptr);
		SBSetStruct(return_value, &roOutResult, sizeof(windows_FILETIME) TSRMLS_CC);
#else
		object_init_ex(return_value, _FILETIME_ce_ptr);
		SBSetStruct(return_value, &roOutResult, sizeof(_FILETIME) TSRMLS_CC);
#endif
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, set_SignTime)
{
	zval *oValue;
#ifdef SB_WINDOWS
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oValue, windows_FILETIME_ce_ptr) == SUCCESS)
#else
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oValue, _FILETIME_ce_ptr) == SUCCESS)
#endif
	{
#ifdef SB_WINDOWS
		SBCheckError(TElOfficeCertificateInfo_set_SignTime(SBGetObjectHandle(getThis() TSRMLS_CC), (windows_FILETIME *)SBGetStructPointer(oValue TSRMLS_CC)) TSRMLS_CC);
#else
		SBCheckError(TElOfficeCertificateInfo_set_SignTime(SBGetObjectHandle(getThis() TSRMLS_CC), (_FILETIME *)SBGetStructPointer(oValue TSRMLS_CC)) TSRMLS_CC);
#endif
	}
	else
	{
#ifdef SB_WINDOWS
		SBErrorExpectsArguments("(\\windows_FILETIME)" TSRMLS_CC);
#else
		SBErrorExpectsArguments("(\\_FILETIME)" TSRMLS_CC);
#endif
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, get_AlgIDHash)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeCertificateInfo_get_AlgIDHash(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, set_AlgIDHash)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeCertificateInfo_set_AlgIDHash(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, get_SignerName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeCertificateInfo_get_SignerName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(80889531, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, set_SignerName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeCertificateInfo_set_SignerName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, get_IssuerName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeCertificateInfo_get_IssuerName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1869059952, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, set_IssuerName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeCertificateInfo_set_IssuerName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, get_Signature)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeCertificateInfo_get_Signature(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1635675090, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, set_Signature)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeCertificateInfo_set_Signature(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, get_EncodedCertificate)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeCertificateInfo_get_EncodedCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1560605152, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, set_EncodedCertificate)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeCertificateInfo_set_EncodedCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, get_SerialNumber)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeCertificateInfo_get_SerialNumber(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1300798470, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, set_SerialNumber)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeCertificateInfo_set_SerialNumber(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, get_IssuerBlob)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeCertificateInfo_get_IssuerBlob(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(2126820186, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, set_IssuerBlob)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeCertificateInfo_set_IssuerBlob(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertificateInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeCertificateInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_get_ExpireTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_set_ExpireTime, 0, 0, 1)
#ifdef SB_WINDOWS
	ZEND_ARG_OBJ_INFO(0, Value, windows_FILETIME, 0)
#else
	ZEND_ARG_OBJ_INFO(0, Value, _FILETIME, 0)
#endif
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_get_SignTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_set_SignTime, 0, 0, 1)
#ifdef SB_WINDOWS
	ZEND_ARG_OBJ_INFO(0, Value, windows_FILETIME, 0)
#else
	ZEND_ARG_OBJ_INFO(0, Value, _FILETIME, 0)
#endif
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_get_AlgIDHash, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_set_AlgIDHash, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_get_SignerName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_set_SignerName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_get_IssuerName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_set_IssuerName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_get_Signature, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_set_Signature, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_get_EncodedCertificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_set_EncodedCertificate, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_get_SerialNumber, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_set_SerialNumber, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_get_IssuerBlob, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo_set_IssuerBlob, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertificateInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeCertificateInfo_methods[] = {
	PHP_ME(TElOfficeCertificateInfo, LoadFromStream, arginfo_TElOfficeCertificateInfo_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, SaveToStream, arginfo_TElOfficeCertificateInfo_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, get_ExpireTime, arginfo_TElOfficeCertificateInfo_get_ExpireTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, set_ExpireTime, arginfo_TElOfficeCertificateInfo_set_ExpireTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, get_SignTime, arginfo_TElOfficeCertificateInfo_get_SignTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, set_SignTime, arginfo_TElOfficeCertificateInfo_set_SignTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, get_AlgIDHash, arginfo_TElOfficeCertificateInfo_get_AlgIDHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, set_AlgIDHash, arginfo_TElOfficeCertificateInfo_set_AlgIDHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, get_SignerName, arginfo_TElOfficeCertificateInfo_get_SignerName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, set_SignerName, arginfo_TElOfficeCertificateInfo_set_SignerName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, get_IssuerName, arginfo_TElOfficeCertificateInfo_get_IssuerName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, set_IssuerName, arginfo_TElOfficeCertificateInfo_set_IssuerName, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, get_Signature, arginfo_TElOfficeCertificateInfo_get_Signature, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, set_Signature, arginfo_TElOfficeCertificateInfo_set_Signature, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, get_EncodedCertificate, arginfo_TElOfficeCertificateInfo_get_EncodedCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, set_EncodedCertificate, arginfo_TElOfficeCertificateInfo_set_EncodedCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, get_SerialNumber, arginfo_TElOfficeCertificateInfo_get_SerialNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, set_SerialNumber, arginfo_TElOfficeCertificateInfo_set_SerialNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, get_IssuerBlob, arginfo_TElOfficeCertificateInfo_get_IssuerBlob, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, set_IssuerBlob, arginfo_TElOfficeCertificateInfo_set_IssuerBlob, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertificateInfo, __construct, arginfo_TElOfficeCertificateInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeCertificateInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeCertificateInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeCertificateInfo", TElOfficeCertificateInfo_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeCertificateInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeCertStoreCertificateGroup_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeCertStoreCertificateGroup, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeCertStoreCertificateGroup_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertStoreCertificateGroup, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeCertStoreCertificateGroup_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertStoreCertificateGroup, get_CertificateData)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeCertStoreCertificateGroup_get_CertificateData(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(246815794, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertStoreCertificateGroup, set_CertificateData)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeCertStoreCertificateGroup_set_CertificateData(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertStoreCertificateGroup, get_EncodingType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeCertStoreCertificateGroup_get_EncodingType(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertStoreCertificateGroup, set_EncodingType)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeCertStoreCertificateGroup_set_EncodingType(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCertStoreCertificateGroup, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeCertStoreCertificateGroup_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertStoreCertificateGroup_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertStoreCertificateGroup_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertStoreCertificateGroup_get_CertificateData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertStoreCertificateGroup_set_CertificateData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertStoreCertificateGroup_get_EncodingType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertStoreCertificateGroup_set_EncodingType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCertStoreCertificateGroup___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeCertStoreCertificateGroup_methods[] = {
	PHP_ME(TElOfficeCertStoreCertificateGroup, LoadFromStream, arginfo_TElOfficeCertStoreCertificateGroup_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertStoreCertificateGroup, SaveToStream, arginfo_TElOfficeCertStoreCertificateGroup_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertStoreCertificateGroup, get_CertificateData, arginfo_TElOfficeCertStoreCertificateGroup_get_CertificateData, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertStoreCertificateGroup, set_CertificateData, arginfo_TElOfficeCertStoreCertificateGroup_set_CertificateData, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertStoreCertificateGroup, get_EncodingType, arginfo_TElOfficeCertStoreCertificateGroup_get_EncodingType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertStoreCertificateGroup, set_EncodingType, arginfo_TElOfficeCertStoreCertificateGroup_set_EncodingType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCertStoreCertificateGroup, __construct, arginfo_TElOfficeCertStoreCertificateGroup___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeCertStoreCertificateGroup(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeCertStoreCertificateGroup_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeCertStoreCertificateGroup", TElOfficeCertStoreCertificateGroup_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeCertStoreCertificateGroup_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeDocSigSerializedCertStore_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeDocSigSerializedCertStore, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDocSigSerializedCertStore_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDocSigSerializedCertStore, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDocSigSerializedCertStore_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDocSigSerializedCertStore, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeDocSigSerializedCertStore_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDocSigSerializedCertStore, AddCertificate)
{
	SBArrayZValInfo aiBuf;
	zval *oCert;
	zval *zaBuf;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuf) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuf) || SB_IS_ARRAY_TYPE_RP(zaBuf) || SB_IS_NULL_TYPE_RP(zaBuf)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuf, &aiBuf TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeDocSigSerializedCertStore_AddCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuf.data, aiBuf.len, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuf);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCert, TElOfficeCertStoreCertificateGroup_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeDocSigSerializedCertStore_AddCertificate_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL) or (\\TElOfficeCertStoreCertificateGroup)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDocSigSerializedCertStore, InsertCertificate)
{
	sb_zend_long l4Index;
	zval *oCert;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Index, &oCert, TElOfficeCertStoreCertificateGroup_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeDocSigSerializedCertStore_InsertCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, SBGetObjectHandle(oCert TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElOfficeCertStoreCertificateGroup)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDocSigSerializedCertStore, DeleteCertificate)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElOfficeDocSigSerializedCertStore_DeleteCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDocSigSerializedCertStore, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeDocSigSerializedCertStore_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDocSigSerializedCertStore, get_Certificates)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeDocSigSerializedCertStore_get_Certificates(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeCertStoreCertificateGroup_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeDocSigSerializedCertStore, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeDocSigSerializedCertStore_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDocSigSerializedCertStore_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDocSigSerializedCertStore_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDocSigSerializedCertStore_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDocSigSerializedCertStore_AddCertificate, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Buf_or_Cert, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDocSigSerializedCertStore_InsertCertificate, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_OBJ_INFO(0, Cert, TElOfficeCertStoreCertificateGroup, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDocSigSerializedCertStore_DeleteCertificate, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDocSigSerializedCertStore_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDocSigSerializedCertStore_get_Certificates, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeDocSigSerializedCertStore___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeDocSigSerializedCertStore_methods[] = {
	PHP_ME(TElOfficeDocSigSerializedCertStore, LoadFromStream, arginfo_TElOfficeDocSigSerializedCertStore_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDocSigSerializedCertStore, SaveToStream, arginfo_TElOfficeDocSigSerializedCertStore_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDocSigSerializedCertStore, Clear, arginfo_TElOfficeDocSigSerializedCertStore_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDocSigSerializedCertStore, AddCertificate, arginfo_TElOfficeDocSigSerializedCertStore_AddCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDocSigSerializedCertStore, InsertCertificate, arginfo_TElOfficeDocSigSerializedCertStore_InsertCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDocSigSerializedCertStore, DeleteCertificate, arginfo_TElOfficeDocSigSerializedCertStore_DeleteCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDocSigSerializedCertStore, get_Count, arginfo_TElOfficeDocSigSerializedCertStore_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDocSigSerializedCertStore, get_Certificates, arginfo_TElOfficeDocSigSerializedCertStore_get_Certificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeDocSigSerializedCertStore, __construct, arginfo_TElOfficeDocSigSerializedCertStore___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeDocSigSerializedCertStore(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeDocSigSerializedCertStore_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeDocSigSerializedCertStore", TElOfficeDocSigSerializedCertStore_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeDocSigSerializedCertStore_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeCryptoAPIDigitalSignature_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeCryptoAPIDigitalSignature, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeCryptoAPIDigitalSignature_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCryptoAPIDigitalSignature, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeCryptoAPIDigitalSignature_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCryptoAPIDigitalSignature, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeCryptoAPIDigitalSignature_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCryptoAPIDigitalSignature, AddCertificateInfo)
{
	zval *oCertInfo;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertInfo, TElOfficeCertificateInfo_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeCryptoAPIDigitalSignature_AddCertificateInfo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertInfo TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficeCertificateInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCryptoAPIDigitalSignature, InsertCertificateInfo)
{
	sb_zend_long l4Index;
	zval *oCertInfo;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Index, &oCertInfo, TElOfficeCertificateInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeCryptoAPIDigitalSignature_InsertCertificateInfo(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, SBGetObjectHandle(oCertInfo TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElOfficeCertificateInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCryptoAPIDigitalSignature, DeleteCertificateInfo)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElOfficeCryptoAPIDigitalSignature_DeleteCertificateInfo(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCryptoAPIDigitalSignature, get_CertificateInfoCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeCryptoAPIDigitalSignature_get_CertificateInfoCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCryptoAPIDigitalSignature, get_CertificateInfos)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeCryptoAPIDigitalSignature_get_CertificateInfos(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeCertificateInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCryptoAPIDigitalSignature, get_IntermediateCertificatesStore)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeCryptoAPIDigitalSignature_get_IntermediateCertificatesStore(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeDocSigSerializedCertStore_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeCryptoAPIDigitalSignature, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeCryptoAPIDigitalSignature_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCryptoAPIDigitalSignature_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCryptoAPIDigitalSignature_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCryptoAPIDigitalSignature_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCryptoAPIDigitalSignature_AddCertificateInfo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, CertInfo, TElOfficeCertificateInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCryptoAPIDigitalSignature_InsertCertificateInfo, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_OBJ_INFO(0, CertInfo, TElOfficeCertificateInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCryptoAPIDigitalSignature_DeleteCertificateInfo, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCryptoAPIDigitalSignature_get_CertificateInfoCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCryptoAPIDigitalSignature_get_CertificateInfos, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCryptoAPIDigitalSignature_get_IntermediateCertificatesStore, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeCryptoAPIDigitalSignature___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeCryptoAPIDigitalSignature_methods[] = {
	PHP_ME(TElOfficeCryptoAPIDigitalSignature, LoadFromStream, arginfo_TElOfficeCryptoAPIDigitalSignature_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCryptoAPIDigitalSignature, SaveToStream, arginfo_TElOfficeCryptoAPIDigitalSignature_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCryptoAPIDigitalSignature, Clear, arginfo_TElOfficeCryptoAPIDigitalSignature_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCryptoAPIDigitalSignature, AddCertificateInfo, arginfo_TElOfficeCryptoAPIDigitalSignature_AddCertificateInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCryptoAPIDigitalSignature, InsertCertificateInfo, arginfo_TElOfficeCryptoAPIDigitalSignature_InsertCertificateInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCryptoAPIDigitalSignature, DeleteCertificateInfo, arginfo_TElOfficeCryptoAPIDigitalSignature_DeleteCertificateInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCryptoAPIDigitalSignature, get_CertificateInfoCount, arginfo_TElOfficeCryptoAPIDigitalSignature_get_CertificateInfoCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCryptoAPIDigitalSignature, get_CertificateInfos, arginfo_TElOfficeCryptoAPIDigitalSignature_get_CertificateInfos, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCryptoAPIDigitalSignature, get_IntermediateCertificatesStore, arginfo_TElOfficeCryptoAPIDigitalSignature_get_IntermediateCertificatesStore, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeCryptoAPIDigitalSignature, __construct, arginfo_TElOfficeCryptoAPIDigitalSignature___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeCryptoAPIDigitalSignature(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeCryptoAPIDigitalSignature_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeCryptoAPIDigitalSignature", TElOfficeCryptoAPIDigitalSignature_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeCryptoAPIDigitalSignature_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeWordFIBBase_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeWordFIBBase, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIBBase_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIBBase_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, get_Ident)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeWordFIBBase_get_Ident(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, set_Ident)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIBBase_set_Ident(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, get_FIB)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeWordFIBBase_get_FIB(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, set_FIB)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIBBase_set_FIB(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, get_LID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeWordFIBBase_get_LID(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, set_LID)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIBBase_set_LID(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, get_Next)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeWordFIBBase_get_Next(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, set_Next)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIBBase_set_Next(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, get_Flags)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeWordFIBBase_get_Flags(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, set_Flags)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIBBase_set_Flags(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, get_FibBack)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeWordFIBBase_get_FibBack(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, set_FibBack)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIBBase_set_FibBack(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, get_Key)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeWordFIBBase_get_Key(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, set_Key)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIBBase_set_Key(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, get_Flags2)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElOfficeWordFIBBase_get_Flags2(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, set_Flags2)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIBBase_set_Flags2(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBBase, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeWordFIBBase_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_get_Ident, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_set_Ident, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_get_FIB, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_set_FIB, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_get_LID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_set_LID, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_get_Next, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_set_Next, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_get_Flags, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_set_Flags, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_get_FibBack, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_set_FibBack, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_get_Key, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_set_Key, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_get_Flags2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase_set_Flags2, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBBase___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeWordFIBBase_methods[] = {
	PHP_ME(TElOfficeWordFIBBase, LoadFromStream, arginfo_TElOfficeWordFIBBase_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, SaveToStream, arginfo_TElOfficeWordFIBBase_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, get_Ident, arginfo_TElOfficeWordFIBBase_get_Ident, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, set_Ident, arginfo_TElOfficeWordFIBBase_set_Ident, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, get_FIB, arginfo_TElOfficeWordFIBBase_get_FIB, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, set_FIB, arginfo_TElOfficeWordFIBBase_set_FIB, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, get_LID, arginfo_TElOfficeWordFIBBase_get_LID, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, set_LID, arginfo_TElOfficeWordFIBBase_set_LID, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, get_Next, arginfo_TElOfficeWordFIBBase_get_Next, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, set_Next, arginfo_TElOfficeWordFIBBase_set_Next, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, get_Flags, arginfo_TElOfficeWordFIBBase_get_Flags, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, set_Flags, arginfo_TElOfficeWordFIBBase_set_Flags, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, get_FibBack, arginfo_TElOfficeWordFIBBase_get_FibBack, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, set_FibBack, arginfo_TElOfficeWordFIBBase_set_FibBack, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, get_Key, arginfo_TElOfficeWordFIBBase_get_Key, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, set_Key, arginfo_TElOfficeWordFIBBase_set_Key, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, get_Flags2, arginfo_TElOfficeWordFIBBase_get_Flags2, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, set_Flags2, arginfo_TElOfficeWordFIBBase_set_Flags2, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBBase, __construct, arginfo_TElOfficeWordFIBBase___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeWordFIBBase(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeWordFIBBase_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeWordFIBBase", TElOfficeWordFIBBase_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeWordFIBBase_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeWordFIBRgFcLcb_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeWordFIBRgFcLcb, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIBRgFcLcb_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBRgFcLcb, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIBRgFcLcb_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBRgFcLcb, ChangeOffsets)
{
	sb_zend_long l4Shift;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Shift) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIBRgFcLcb_ChangeOffsets(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Shift) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBRgFcLcb, get_Blob)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeWordFIBRgFcLcb_get_Blob(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1504778513, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBRgFcLcb, set_Blob)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeWordFIBRgFcLcb_set_Blob(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIBRgFcLcb, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeWordFIBRgFcLcb_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBRgFcLcb_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBRgFcLcb_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBRgFcLcb_ChangeOffsets, 0, 0, 1)
	ZEND_ARG_INFO(0, Shift)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBRgFcLcb_get_Blob, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBRgFcLcb_set_Blob, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIBRgFcLcb___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeWordFIBRgFcLcb_methods[] = {
	PHP_ME(TElOfficeWordFIBRgFcLcb, LoadFromStream, arginfo_TElOfficeWordFIBRgFcLcb_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBRgFcLcb, SaveToStream, arginfo_TElOfficeWordFIBRgFcLcb_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBRgFcLcb, ChangeOffsets, arginfo_TElOfficeWordFIBRgFcLcb_ChangeOffsets, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBRgFcLcb, get_Blob, arginfo_TElOfficeWordFIBRgFcLcb_get_Blob, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBRgFcLcb, set_Blob, arginfo_TElOfficeWordFIBRgFcLcb_set_Blob, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIBRgFcLcb, __construct, arginfo_TElOfficeWordFIBRgFcLcb___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeWordFIBRgFcLcb(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeWordFIBRgFcLcb_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeWordFIBRgFcLcb", TElOfficeWordFIBRgFcLcb_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeWordFIBRgFcLcb_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeWordFIB_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeWordFIB, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIB_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIB, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeWordFIB_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIB, get_FIBBase)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeWordFIB_get_FIBBase(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeWordFIBBase_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIB, get_FIBRgFcLcb)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeWordFIB_get_FIBRgFcLcb(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeWordFIBRgFcLcb_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWordFIB, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeWordFIB_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIB_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIB_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIB_get_FIBBase, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIB_get_FIBRgFcLcb, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWordFIB___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeWordFIB_methods[] = {
	PHP_ME(TElOfficeWordFIB, LoadFromStream, arginfo_TElOfficeWordFIB_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIB, SaveToStream, arginfo_TElOfficeWordFIB_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIB, get_FIBBase, arginfo_TElOfficeWordFIB_get_FIBBase, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIB, get_FIBRgFcLcb, arginfo_TElOfficeWordFIB_get_FIBRgFcLcb, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWordFIB, __construct, arginfo_TElOfficeWordFIB___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeWordFIB(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeWordFIB_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeWordFIB", TElOfficeWordFIB_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeWordFIB_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeWorkbookRecordInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeWorkbookRecordInfo, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookRecordInfo_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookRecordInfo, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookRecordInfo_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookRecordInfo, get_RecordType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeWorkbookRecordInfo_get_RecordType(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookRecordInfo, set_RecordType)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookRecordInfo_set_RecordType(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookRecordInfo, get_RecordSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeWorkbookRecordInfo_get_RecordSize(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookRecordInfo, set_RecordSize)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookRecordInfo_set_RecordSize(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookRecordInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeWorkbookRecordInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookRecordInfo_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookRecordInfo_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookRecordInfo_get_RecordType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookRecordInfo_set_RecordType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookRecordInfo_get_RecordSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookRecordInfo_set_RecordSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookRecordInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeWorkbookRecordInfo_methods[] = {
	PHP_ME(TElOfficeWorkbookRecordInfo, LoadFromStream, arginfo_TElOfficeWorkbookRecordInfo_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookRecordInfo, SaveToStream, arginfo_TElOfficeWorkbookRecordInfo_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookRecordInfo, get_RecordType, arginfo_TElOfficeWorkbookRecordInfo_get_RecordType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookRecordInfo, set_RecordType, arginfo_TElOfficeWorkbookRecordInfo_set_RecordType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookRecordInfo, get_RecordSize, arginfo_TElOfficeWorkbookRecordInfo_get_RecordSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookRecordInfo, set_RecordSize, arginfo_TElOfficeWorkbookRecordInfo_set_RecordSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookRecordInfo, __construct, arginfo_TElOfficeWorkbookRecordInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeWorkbookRecordInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeWorkbookRecordInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeWorkbookRecordInfo", TElOfficeWorkbookRecordInfo_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeWorkbookRecordInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeWorkbookBOF_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeWorkbookBOF, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookBOF_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookBOF_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, get_Version)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeWorkbookBOF_get_Version(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, set_Version)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookBOF_set_Version(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, get_DocumentType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeWorkbookBOF_get_DocumentType(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, set_DocumentType)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookBOF_set_DocumentType(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, get_RupBuild)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeWorkbookBOF_get_RupBuild(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, set_RupBuild)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookBOF_set_RupBuild(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, get_RupYear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeWorkbookBOF_get_RupYear(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, set_RupYear)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookBOF_set_RupYear(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, get_Flags)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficeWorkbookBOF_get_Flags(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, set_Flags)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookBOF_set_Flags(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, get_VersionLowestBiff)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElOfficeWorkbookBOF_get_VersionLowestBiff(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, set_VersionLowestBiff)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookBOF_set_VersionLowestBiff(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, get_VersionLastXLSaved)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElOfficeWorkbookBOF_get_VersionLastXLSaved(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, set_VersionLastXLSaved)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookBOF_set_VersionLastXLSaved(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookBOF, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeWorkbookBOF_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_get_Version, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_set_Version, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_get_DocumentType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_set_DocumentType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_get_RupBuild, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_set_RupBuild, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_get_RupYear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_set_RupYear, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_get_Flags, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_set_Flags, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_get_VersionLowestBiff, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_set_VersionLowestBiff, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_get_VersionLastXLSaved, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF_set_VersionLastXLSaved, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookBOF___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeWorkbookBOF_methods[] = {
	PHP_ME(TElOfficeWorkbookBOF, LoadFromStream, arginfo_TElOfficeWorkbookBOF_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, SaveToStream, arginfo_TElOfficeWorkbookBOF_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, get_Version, arginfo_TElOfficeWorkbookBOF_get_Version, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, set_Version, arginfo_TElOfficeWorkbookBOF_set_Version, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, get_DocumentType, arginfo_TElOfficeWorkbookBOF_get_DocumentType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, set_DocumentType, arginfo_TElOfficeWorkbookBOF_set_DocumentType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, get_RupBuild, arginfo_TElOfficeWorkbookBOF_get_RupBuild, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, set_RupBuild, arginfo_TElOfficeWorkbookBOF_set_RupBuild, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, get_RupYear, arginfo_TElOfficeWorkbookBOF_get_RupYear, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, set_RupYear, arginfo_TElOfficeWorkbookBOF_set_RupYear, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, get_Flags, arginfo_TElOfficeWorkbookBOF_get_Flags, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, set_Flags, arginfo_TElOfficeWorkbookBOF_set_Flags, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, get_VersionLowestBiff, arginfo_TElOfficeWorkbookBOF_get_VersionLowestBiff, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, set_VersionLowestBiff, arginfo_TElOfficeWorkbookBOF_set_VersionLowestBiff, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, get_VersionLastXLSaved, arginfo_TElOfficeWorkbookBOF_get_VersionLastXLSaved, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, set_VersionLastXLSaved, arginfo_TElOfficeWorkbookBOF_set_VersionLastXLSaved, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookBOF, __construct, arginfo_TElOfficeWorkbookBOF___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeWorkbookBOF(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeWorkbookBOF_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeWorkbookBOF", TElOfficeWorkbookBOF_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeWorkbookBOF_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficeWorkbookFilePass_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeWorkbookFilePass, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookFilePass_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookFilePass, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookFilePass_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookFilePass, get_EncryptionType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficeWorkbookFilePass_get_EncryptionType(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookFilePass, set_EncryptionType)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficeWorkbookFilePass_set_EncryptionType(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeWorkbookFilePass, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeWorkbookFilePass_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookFilePass_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookFilePass_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookFilePass_get_EncryptionType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookFilePass_set_EncryptionType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeWorkbookFilePass___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeWorkbookFilePass_methods[] = {
	PHP_ME(TElOfficeWorkbookFilePass, LoadFromStream, arginfo_TElOfficeWorkbookFilePass_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookFilePass, SaveToStream, arginfo_TElOfficeWorkbookFilePass_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookFilePass, get_EncryptionType, arginfo_TElOfficeWorkbookFilePass_get_EncryptionType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookFilePass, set_EncryptionType, arginfo_TElOfficeWorkbookFilePass_set_EncryptionType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeWorkbookFilePass, __construct, arginfo_TElOfficeWorkbookFilePass___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeWorkbookFilePass(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeWorkbookFilePass_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeWorkbookFilePass", TElOfficeWorkbookFilePass_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficeWorkbookFilePass_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficePowerPointRecordHeader_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficePowerPointRecordHeader, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointRecordHeader_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointRecordHeader, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointRecordHeader_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointRecordHeader, get_RecordVersion)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointRecordHeader_get_RecordVersion(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointRecordHeader, set_RecordVersion)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointRecordHeader_set_RecordVersion(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointRecordHeader, get_RecordInstance)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointRecordHeader_get_RecordInstance(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointRecordHeader, set_RecordInstance)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointRecordHeader_set_RecordInstance(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointRecordHeader, get_RecordType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointRecordHeader_get_RecordType(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointRecordHeader, set_RecordType)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointRecordHeader_set_RecordType(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointRecordHeader, get_RecordLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointRecordHeader_get_RecordLength(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointRecordHeader, set_RecordLength)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointRecordHeader_set_RecordLength(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointRecordHeader, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficePowerPointRecordHeader_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointRecordHeader_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointRecordHeader_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointRecordHeader_get_RecordVersion, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointRecordHeader_set_RecordVersion, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointRecordHeader_get_RecordInstance, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointRecordHeader_set_RecordInstance, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointRecordHeader_get_RecordType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointRecordHeader_set_RecordType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointRecordHeader_get_RecordLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointRecordHeader_set_RecordLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointRecordHeader___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficePowerPointRecordHeader_methods[] = {
	PHP_ME(TElOfficePowerPointRecordHeader, LoadFromStream, arginfo_TElOfficePowerPointRecordHeader_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointRecordHeader, SaveToStream, arginfo_TElOfficePowerPointRecordHeader_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointRecordHeader, get_RecordVersion, arginfo_TElOfficePowerPointRecordHeader_get_RecordVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointRecordHeader, set_RecordVersion, arginfo_TElOfficePowerPointRecordHeader_set_RecordVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointRecordHeader, get_RecordInstance, arginfo_TElOfficePowerPointRecordHeader_get_RecordInstance, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointRecordHeader, set_RecordInstance, arginfo_TElOfficePowerPointRecordHeader_set_RecordInstance, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointRecordHeader, get_RecordType, arginfo_TElOfficePowerPointRecordHeader_get_RecordType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointRecordHeader, set_RecordType, arginfo_TElOfficePowerPointRecordHeader_set_RecordType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointRecordHeader, get_RecordLength, arginfo_TElOfficePowerPointRecordHeader_get_RecordLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointRecordHeader, set_RecordLength, arginfo_TElOfficePowerPointRecordHeader_set_RecordLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointRecordHeader, __construct, arginfo_TElOfficePowerPointRecordHeader___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficePowerPointRecordHeader(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficePowerPointRecordHeader_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficePowerPointRecordHeader", TElOfficePowerPointRecordHeader_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficePowerPointRecordHeader_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficePowerPointUserEditAtom_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, LoadFromStream)
{
	sb_zend_long u4RecordSize;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointUserEditAtom_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStream, TStream_ce_ptr, &u4RecordSize) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointUserEditAtom_LoadFromStream_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (uint32_t)u4RecordSize) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream) or (\\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, SaveToStream)
{
	zend_bool bIncludeEncryptSession;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointUserEditAtom_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oStream, TStream_ce_ptr, &bIncludeEncryptSession) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointUserEditAtom_SaveToStream_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (int8_t)bIncludeEncryptSession) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream) or (\\TStream, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, get_LastSlideIdRef)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointUserEditAtom_get_LastSlideIdRef(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, set_LastSlideIdRef)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointUserEditAtom_set_LastSlideIdRef(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, get_Version)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointUserEditAtom_get_Version(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, set_Version)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointUserEditAtom_set_Version(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, get_MinorVersion)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointUserEditAtom_get_MinorVersion(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, set_MinorVersion)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointUserEditAtom_set_MinorVersion(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, get_MajorVersion)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointUserEditAtom_get_MajorVersion(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, set_MajorVersion)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointUserEditAtom_set_MajorVersion(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, get_OffsetLastEdit)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointUserEditAtom_get_OffsetLastEdit(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, set_OffsetLastEdit)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointUserEditAtom_set_OffsetLastEdit(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, get_OffsetPersistDirectory)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointUserEditAtom_get_OffsetPersistDirectory(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, set_OffsetPersistDirectory)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointUserEditAtom_set_OffsetPersistDirectory(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, get_DocPersistIdRef)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointUserEditAtom_get_DocPersistIdRef(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, set_DocPersistIdRef)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointUserEditAtom_set_DocPersistIdRef(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, get_PersistIdSeed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointUserEditAtom_get_PersistIdSeed(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, set_PersistIdSeed)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointUserEditAtom_set_PersistIdSeed(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, get_LastView)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint16_t u2OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointUserEditAtom_get_LastView(SBGetObjectHandle(getThis() TSRMLS_CC), &u2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, set_LastView)
{
	sb_zend_long u2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u2Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointUserEditAtom_set_LastView(SBGetObjectHandle(getThis() TSRMLS_CC), (uint16_t)u2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, get_EncryptSessionPersistIdRef)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointUserEditAtom_get_EncryptSessionPersistIdRef(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, set_EncryptSessionPersistIdRef)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointUserEditAtom_set_EncryptSessionPersistIdRef(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointUserEditAtom, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficePowerPointUserEditAtom_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, RecordSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, IncludeEncryptSession)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_get_LastSlideIdRef, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_set_LastSlideIdRef, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_get_Version, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_set_Version, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_get_MinorVersion, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_set_MinorVersion, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_get_MajorVersion, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_set_MajorVersion, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_get_OffsetLastEdit, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_set_OffsetLastEdit, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_get_OffsetPersistDirectory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_set_OffsetPersistDirectory, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_get_DocPersistIdRef, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_set_DocPersistIdRef, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_get_PersistIdSeed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_set_PersistIdSeed, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_get_LastView, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_set_LastView, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_get_EncryptSessionPersistIdRef, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom_set_EncryptSessionPersistIdRef, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointUserEditAtom___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficePowerPointUserEditAtom_methods[] = {
	PHP_ME(TElOfficePowerPointUserEditAtom, LoadFromStream, arginfo_TElOfficePowerPointUserEditAtom_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, SaveToStream, arginfo_TElOfficePowerPointUserEditAtom_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, get_LastSlideIdRef, arginfo_TElOfficePowerPointUserEditAtom_get_LastSlideIdRef, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, set_LastSlideIdRef, arginfo_TElOfficePowerPointUserEditAtom_set_LastSlideIdRef, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, get_Version, arginfo_TElOfficePowerPointUserEditAtom_get_Version, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, set_Version, arginfo_TElOfficePowerPointUserEditAtom_set_Version, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, get_MinorVersion, arginfo_TElOfficePowerPointUserEditAtom_get_MinorVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, set_MinorVersion, arginfo_TElOfficePowerPointUserEditAtom_set_MinorVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, get_MajorVersion, arginfo_TElOfficePowerPointUserEditAtom_get_MajorVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, set_MajorVersion, arginfo_TElOfficePowerPointUserEditAtom_set_MajorVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, get_OffsetLastEdit, arginfo_TElOfficePowerPointUserEditAtom_get_OffsetLastEdit, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, set_OffsetLastEdit, arginfo_TElOfficePowerPointUserEditAtom_set_OffsetLastEdit, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, get_OffsetPersistDirectory, arginfo_TElOfficePowerPointUserEditAtom_get_OffsetPersistDirectory, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, set_OffsetPersistDirectory, arginfo_TElOfficePowerPointUserEditAtom_set_OffsetPersistDirectory, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, get_DocPersistIdRef, arginfo_TElOfficePowerPointUserEditAtom_get_DocPersistIdRef, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, set_DocPersistIdRef, arginfo_TElOfficePowerPointUserEditAtom_set_DocPersistIdRef, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, get_PersistIdSeed, arginfo_TElOfficePowerPointUserEditAtom_get_PersistIdSeed, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, set_PersistIdSeed, arginfo_TElOfficePowerPointUserEditAtom_set_PersistIdSeed, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, get_LastView, arginfo_TElOfficePowerPointUserEditAtom_get_LastView, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, set_LastView, arginfo_TElOfficePowerPointUserEditAtom_set_LastView, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, get_EncryptSessionPersistIdRef, arginfo_TElOfficePowerPointUserEditAtom_get_EncryptSessionPersistIdRef, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, set_EncryptSessionPersistIdRef, arginfo_TElOfficePowerPointUserEditAtom_set_EncryptSessionPersistIdRef, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointUserEditAtom, __construct, arginfo_TElOfficePowerPointUserEditAtom___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficePowerPointUserEditAtom(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficePowerPointUserEditAtom_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficePowerPointUserEditAtom", TElOfficePowerPointUserEditAtom_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficePowerPointUserEditAtom_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficePowerPointPersistDirectoryEntry_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryEntry, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointPersistDirectoryEntry_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryEntry, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointPersistDirectoryEntry_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryEntry, get_PersistId)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointPersistDirectoryEntry_get_PersistId(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryEntry, set_PersistId)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointPersistDirectoryEntry_set_PersistId(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryEntry, get_PersistOffsets)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBArrayZValInfo aiOutResult;
		SBInitArrayZValInfo(&aiOutResult);
		_err = TElOfficePowerPointPersistDirectoryEntry_get_PersistOffsets(SBGetObjectHandle(getThis() TSRMLS_CC), aiOutResult.data, &aiOutResult.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			aiOutResult.data = emalloc(aiOutResult.len);
			aiOutResult.ownData = 1;
			SBCheckError(SBGetLastReturnBuffer(-70655360, 1, aiOutResult.data, &aiOutResult.len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiOutResult);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetUInt32ArrayToZVal(&aiOutResult, return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryEntry, set_PersistOffsets)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetUInt32ArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficePowerPointPersistDirectoryEntry_set_PersistOffsets(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of uint32|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryEntry, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficePowerPointPersistDirectoryEntry_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryEntry_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryEntry_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryEntry_get_PersistId, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryEntry_set_PersistId, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryEntry_get_PersistOffsets, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryEntry_set_PersistOffsets, 0, 0, 1)
	ZEND_ARG_ARRAY_INFO(0, Value, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryEntry___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficePowerPointPersistDirectoryEntry_methods[] = {
	PHP_ME(TElOfficePowerPointPersistDirectoryEntry, LoadFromStream, arginfo_TElOfficePowerPointPersistDirectoryEntry_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryEntry, SaveToStream, arginfo_TElOfficePowerPointPersistDirectoryEntry_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryEntry, get_PersistId, arginfo_TElOfficePowerPointPersistDirectoryEntry_get_PersistId, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryEntry, set_PersistId, arginfo_TElOfficePowerPointPersistDirectoryEntry_set_PersistId, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryEntry, get_PersistOffsets, arginfo_TElOfficePowerPointPersistDirectoryEntry_get_PersistOffsets, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryEntry, set_PersistOffsets, arginfo_TElOfficePowerPointPersistDirectoryEntry_set_PersistOffsets, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryEntry, __construct, arginfo_TElOfficePowerPointPersistDirectoryEntry___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficePowerPointPersistDirectoryEntry(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficePowerPointPersistDirectoryEntry_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficePowerPointPersistDirectoryEntry", TElOfficePowerPointPersistDirectoryEntry_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficePowerPointPersistDirectoryEntry_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

zend_class_entry *TElOfficePowerPointPersistDirectoryAtom_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryAtom, LoadFromStream)
{
	sb_zend_long u4RecordSize;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointPersistDirectoryAtom_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStream, TStream_ce_ptr, &u4RecordSize) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointPersistDirectoryAtom_LoadFromStream_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), (uint32_t)u4RecordSize) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream) or (\\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryAtom, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointPersistDirectoryAtom_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryAtom, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointPersistDirectoryAtom_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryAtom, Add)
{
	zval *oAEntry;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAEntry, TElOfficePowerPointPersistDirectoryEntry_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointPersistDirectoryAtom_Add(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oAEntry TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficePowerPointPersistDirectoryEntry)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryAtom, Insert)
{
	sb_zend_long l4Index;
	zval *oAEntry;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Index, &oAEntry, TElOfficePowerPointPersistDirectoryEntry_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointPersistDirectoryAtom_Insert(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, SBGetObjectHandle(oAEntry TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElOfficePowerPointPersistDirectoryEntry)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryAtom, Delete)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointPersistDirectoryAtom_Delete(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryAtom, AddPersistId)
{
	sb_zend_long u4Offset;
	sb_zend_long u4PersistId;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &u4PersistId, &u4Offset) == SUCCESS)
	{
		SBCheckError(TElOfficePowerPointPersistDirectoryAtom_AddPersistId(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4PersistId, (uint32_t)u4Offset) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryAtom, GetOffsetById)
{
	sb_zend_long u4PersistId;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4PersistId) == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointPersistDirectoryAtom_GetOffsetById(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4PersistId, &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryAtom, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficePowerPointPersistDirectoryAtom_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryAtom, get_Entries)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficePowerPointPersistDirectoryAtom_get_Entries(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficePowerPointPersistDirectoryEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficePowerPointPersistDirectoryAtom, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficePowerPointPersistDirectoryAtom_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryAtom_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, RecordSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryAtom_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryAtom_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryAtom_Add, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AEntry, TElOfficePowerPointPersistDirectoryEntry, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryAtom_Insert, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_OBJ_INFO(0, AEntry, TElOfficePowerPointPersistDirectoryEntry, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryAtom_Delete, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryAtom_AddPersistId, 0, 0, 2)
	ZEND_ARG_INFO(0, PersistId)
	ZEND_ARG_INFO(0, Offset)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryAtom_GetOffsetById, 0, 0, 1)
	ZEND_ARG_INFO(0, PersistId)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryAtom_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryAtom_get_Entries, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficePowerPointPersistDirectoryAtom___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficePowerPointPersistDirectoryAtom_methods[] = {
	PHP_ME(TElOfficePowerPointPersistDirectoryAtom, LoadFromStream, arginfo_TElOfficePowerPointPersistDirectoryAtom_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryAtom, SaveToStream, arginfo_TElOfficePowerPointPersistDirectoryAtom_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryAtom, Clear, arginfo_TElOfficePowerPointPersistDirectoryAtom_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryAtom, Add, arginfo_TElOfficePowerPointPersistDirectoryAtom_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryAtom, Insert, arginfo_TElOfficePowerPointPersistDirectoryAtom_Insert, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryAtom, Delete, arginfo_TElOfficePowerPointPersistDirectoryAtom_Delete, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryAtom, AddPersistId, arginfo_TElOfficePowerPointPersistDirectoryAtom_AddPersistId, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryAtom, GetOffsetById, arginfo_TElOfficePowerPointPersistDirectoryAtom_GetOffsetById, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryAtom, get_Count, arginfo_TElOfficePowerPointPersistDirectoryAtom_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryAtom, get_Entries, arginfo_TElOfficePowerPointPersistDirectoryAtom_get_Entries, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficePowerPointPersistDirectoryAtom, __construct, arginfo_TElOfficePowerPointPersistDirectoryAtom___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficePowerPointPersistDirectoryAtom(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficePowerPointPersistDirectoryAtom_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficePowerPointPersistDirectoryAtom", TElOfficePowerPointPersistDirectoryAtom_methods);
	if (NULL == TElOfficeBinaryObject_ce_ptr)
		Register_TElOfficeBinaryObject(TSRMLS_C);
	TElOfficePowerPointPersistDirectoryAtom_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryObject_ce_ptr);
}

SB_PHP_FUNCTION(SBOfficeBinaryCore, BufferToInt32)
{
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaBuffer, &l4Index) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBOfficeBinaryCore_BufferToInt32(aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBOfficeBinaryCore, BufferToInt64)
{
	sb_zend_long l4Index;
	SBArrayZValInfo aiBuffer;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaBuffer, &l4Index) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		int64_t l8OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBOfficeBinaryCore_BufferToInt64(aiBuffer.data, aiBuffer.len, (int32_t)l4Index, &l8OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBOfficeBinaryCore, Int32ToBuffer)
{
	sb_zend_long l4Index;
	sb_zend_long l4Value;
	SBArrayZValInfo aiBuffer;
	uint32_t _err;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4Index, &l4Value) == SUCCESS) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = SBOfficeBinaryCore_Int32ToBuffer(aiBuffer.data, &aiBuffer.len, (int32_t)l4Index, (int32_t)l4Value);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-1648009463, 0, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(&array of byte|string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBOfficeBinaryCore, UInt32ToBuffer)
{
	sb_zend_long l4Index;
	sb_zend_long u4Value;
	SBArrayZValInfo aiBuffer;
	uint32_t _err;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4Index, &u4Value) == SUCCESS) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = SBOfficeBinaryCore_UInt32ToBuffer(aiBuffer.data, &aiBuffer.len, (int32_t)l4Index, (uint32_t)u4Value);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-1628337707, 0, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(&array of byte|string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBOfficeBinaryCore, Int64ToBuffer)
{
	sb_zend_long l4Index;
	sb_zend_long l8Value;
	SBArrayZValInfo aiBuffer;
	uint32_t _err;
	zval *zaBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4Index, &l8Value) == SUCCESS) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = SBOfficeBinaryCore_Int64ToBuffer(aiBuffer.data, &aiBuffer.len, (int32_t)l4Index, (int64_t)l8Value);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(1933928979, 0, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(&array of byte|string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBOfficeBinaryCore, SwapTimeEncoding)
{
	zval *oValue;
#ifdef SB_WINDOWS
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oValue, windows_FILETIME_ce_ptr) == SUCCESS)
#else
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oValue, _FILETIME_ce_ptr) == SUCCESS)
#endif
	{
#ifdef SB_WINDOWS
		windows_FILETIME roOutResult;
		SBCheckError(SBOfficeBinaryCore_SwapTimeEncoding((windows_FILETIME *)SBGetStructPointer(oValue TSRMLS_CC), &roOutResult) TSRMLS_CC);
		object_init_ex(return_value, windows_FILETIME_ce_ptr);
		SBSetStruct(return_value, &roOutResult, sizeof(windows_FILETIME) TSRMLS_CC);
#else
		_FILETIME roOutResult;
		SBCheckError(SBOfficeBinaryCore_SwapTimeEncoding((_FILETIME *)SBGetStructPointer(oValue TSRMLS_CC), &roOutResult) TSRMLS_CC);
		object_init_ex(return_value, _FILETIME_ce_ptr);
		SBSetStruct(return_value, &roOutResult, sizeof(_FILETIME) TSRMLS_CC);
#endif
	}
	else
	{
#ifdef SB_WINDOWS
		SBErrorExpectsArguments("(\\windows_FILETIME)" TSRMLS_CC);
#else
		SBErrorExpectsArguments("(\\_FILETIME)" TSRMLS_CC);
#endif
	}
}

void Register_SBOfficeBinaryCore_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_ENCRYPTION_HEADER_FLAG_CRYPTOAPI, SB_OFFICE_ENCRYPTION_HEADER_FLAG_CRYPTOAPI, SB_OFFICE_ENCRYPTION_HEADER_FLAG_CRYPTOAPI);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_ENCRYPTION_HEADER_FLAG_DOC_PROPS, SB_OFFICE_ENCRYPTION_HEADER_FLAG_DOC_PROPS, SB_OFFICE_ENCRYPTION_HEADER_FLAG_DOC_PROPS);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_ENCRYPTION_HEADER_FLAG_EXTERNAL, SB_OFFICE_ENCRYPTION_HEADER_FLAG_EXTERNAL, SB_OFFICE_ENCRYPTION_HEADER_FLAG_EXTERNAL);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_ENCRYPTION_HEADER_FLAG_AES, SB_OFFICE_ENCRYPTION_HEADER_FLAG_AES, SB_OFFICE_ENCRYPTION_HEADER_FLAG_AES);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_ENCRYPTION_HEADER_FLAGS_CRYPTOAPI_AES, SB_OFFICE_ENCRYPTION_HEADER_FLAGS_CRYPTOAPI_AES, SB_OFFICE_ENCRYPTION_HEADER_FLAGS_CRYPTOAPI_AES);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_ENCRYPTION_HEADER_FLAGS_CRYPTOAPI_DOCPROPS_AES, SB_OFFICE_ENCRYPTION_HEADER_FLAGS_CRYPTOAPI_DOCPROPS_AES, SB_OFFICE_ENCRYPTION_HEADER_FLAGS_CRYPTOAPI_DOCPROPS_AES);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_ENCRYPTED_STREAM_DESCRIPTOR_FLAG_STREAM, SB_OFFICE_ENCRYPTED_STREAM_DESCRIPTOR_FLAG_STREAM, SB_OFFICE_ENCRYPTED_STREAM_DESCRIPTOR_FLAG_STREAM);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORD_DOCUMENT_FIB_BASE_FLAG_ENCRYPTED, SB_OFFICE_WORD_DOCUMENT_FIB_BASE_FLAG_ENCRYPTED, SB_OFFICE_WORD_DOCUMENT_FIB_BASE_FLAG_ENCRYPTED);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORD_DOCUMENT_FIB_BASE_FLAG_OBFUSCATED, SB_OFFICE_WORD_DOCUMENT_FIB_BASE_FLAG_OBFUSCATED, SB_OFFICE_WORD_DOCUMENT_FIB_BASE_FLAG_OBFUSCATED);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORD_DOCUMENT_FIB_BASE_FLAG_WHICH_TABLE_STREAM, SB_OFFICE_WORD_DOCUMENT_FIB_BASE_FLAG_WHICH_TABLE_STREAM, SB_OFFICE_WORD_DOCUMENT_FIB_BASE_FLAG_WHICH_TABLE_STREAM);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_RECORD_INFO_SIZE, SB_OFFICE_WORKBOOK_RECORD_INFO_SIZE, SB_OFFICE_WORKBOOK_RECORD_INFO_SIZE);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_RECORD_TYPE_BOF, SB_OFFICE_WORKBOOK_RECORD_TYPE_BOF, SB_OFFICE_WORKBOOK_RECORD_TYPE_BOF);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_RECORD_TYPE_BOUND_SHEET8, SB_OFFICE_WORKBOOK_RECORD_TYPE_BOUND_SHEET8, SB_OFFICE_WORKBOOK_RECORD_TYPE_BOUND_SHEET8);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_RECORD_TYPE_EOF, SB_OFFICE_WORKBOOK_RECORD_TYPE_EOF, SB_OFFICE_WORKBOOK_RECORD_TYPE_EOF);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_RECORD_TYPE_EXT_SST, SB_OFFICE_WORKBOOK_RECORD_TYPE_EXT_SST, SB_OFFICE_WORKBOOK_RECORD_TYPE_EXT_SST);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_RECORD_TYPE_FILE_LOCK, SB_OFFICE_WORKBOOK_RECORD_TYPE_FILE_LOCK, SB_OFFICE_WORKBOOK_RECORD_TYPE_FILE_LOCK);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_RECORD_TYPE_FILE_PASS, SB_OFFICE_WORKBOOK_RECORD_TYPE_FILE_PASS, SB_OFFICE_WORKBOOK_RECORD_TYPE_FILE_PASS);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_RECORD_TYPE_INDEX, SB_OFFICE_WORKBOOK_RECORD_TYPE_INDEX, SB_OFFICE_WORKBOOK_RECORD_TYPE_INDEX);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_RECORD_TYPE_INTERFACE_HDR, SB_OFFICE_WORKBOOK_RECORD_TYPE_INTERFACE_HDR, SB_OFFICE_WORKBOOK_RECORD_TYPE_INTERFACE_HDR);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_RECORD_TYPE_RRD_HEAD, SB_OFFICE_WORKBOOK_RECORD_TYPE_RRD_HEAD, SB_OFFICE_WORKBOOK_RECORD_TYPE_RRD_HEAD);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_RECORD_TYPE_RRD_INFO, SB_OFFICE_WORKBOOK_RECORD_TYPE_RRD_INFO, SB_OFFICE_WORKBOOK_RECORD_TYPE_RRD_INFO);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_RECORD_TYPE_USR_EXCL, SB_OFFICE_WORKBOOK_RECORD_TYPE_USR_EXCL, SB_OFFICE_WORKBOOK_RECORD_TYPE_USR_EXCL);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_RECORD_TYPE_WRITE_ACCESS, SB_OFFICE_WORKBOOK_RECORD_TYPE_WRITE_ACCESS, SB_OFFICE_WORKBOOK_RECORD_TYPE_WRITE_ACCESS);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_RECORD_TYPE_WRITE_PROTECT, SB_OFFICE_WORKBOOK_RECORD_TYPE_WRITE_PROTECT, SB_OFFICE_WORKBOOK_RECORD_TYPE_WRITE_PROTECT);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_ENCRYPTION_TYPE_XOR_OBFUSCATION, SB_OFFICE_WORKBOOK_ENCRYPTION_TYPE_XOR_OBFUSCATION, SB_OFFICE_WORKBOOK_ENCRYPTION_TYPE_XOR_OBFUSCATION);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_WORKBOOK_ENCRYPTION_TYPE_RC4, SB_OFFICE_WORKBOOK_ENCRYPTION_TYPE_RC4, SB_OFFICE_WORKBOOK_ENCRYPTION_TYPE_RC4);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_POWERPOINT_RECORD_HEADER_SIZE, SB_OFFICE_POWERPOINT_RECORD_HEADER_SIZE, SB_OFFICE_POWERPOINT_RECORD_HEADER_SIZE);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_ART_RECORD_HEADER_SIZE, SB_OFFICE_ART_RECORD_HEADER_SIZE, SB_OFFICE_ART_RECORD_HEADER_SIZE);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_POWERPOINT_RECORD_TYPE_USER_EDIT_ATOM, SB_OFFICE_POWERPOINT_RECORD_TYPE_USER_EDIT_ATOM, SB_OFFICE_POWERPOINT_RECORD_TYPE_USER_EDIT_ATOM);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_POWERPOINT_RECORD_TYPE_PERSIST_DIRECTORY_ATOM, SB_OFFICE_POWERPOINT_RECORD_TYPE_PERSIST_DIRECTORY_ATOM, SB_OFFICE_POWERPOINT_RECORD_TYPE_PERSIST_DIRECTORY_ATOM);
	SB_REGISTER_LONG_CONSTANT(SBOfficeBinaryCore, SB_OFFICE_POWERPOINT_RECORD_TYPE_CRYPT_SESSION10_CONTAINER, SB_OFFICE_POWERPOINT_RECORD_TYPE_CRYPT_SESSION10_CONTAINER, SB_OFFICE_POWERPOINT_RECORD_TYPE_CRYPT_SESSION10_CONTAINER);
}

void Register_SBOfficeBinaryCore_Aliases(TSRMLS_D)
{
	if (NULL == TElOfficePowerPointRecordHeader_ce_ptr)
		Register_TElOfficePowerPointRecordHeader(TSRMLS_C);
	zend_register_class_alias("TElOfficeArtRecordHeader", TElOfficePowerPointRecordHeader_ce_ptr);
}
