#include "sbofficesecurity.h"

zend_class_entry *TSBOfficeBinaryEntryValidationStatus_ce_ptr = NULL;

zend_class_entry *TSBOfficeBinarySignatureValidationStatus_ce_ptr = NULL;

void SB_CALLBACK TSBOfficeXMLSignEventRaw(void * _ObjectData, TObjectHandle Sender, TElXMLSignerHandle Signer)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zSigner;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSigner, 1);
	SBInitObject(zSigner, TElXMLSigner_ce_ptr, Signer TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSigner);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSBOfficeOpenXMLPartValidationStatus_ce_ptr = NULL;

zend_class_entry *TSBOfficeOpenXMLSignatureValidationStatus_ce_ptr = NULL;

zend_class_entry *TSBOfficeOpenXMLEmbedCertificate_ce_ptr = NULL;

zend_class_entry *TSBOpenOfficeEntryValidationStatus_ce_ptr = NULL;

zend_class_entry *TSBOpenOfficeSignatureValidationStatus_ce_ptr = NULL;

zend_class_entry *TElOfficeOpenXMLStandardEncryptionHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeOpenXMLStandardEncryptionHandler, GetName_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXMLStandardEncryptionHandler_GetName_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1494064363, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLStandardEncryptionHandler, GetName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXMLStandardEncryptionHandler_GetName(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1494064363, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLStandardEncryptionHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLStandardEncryptionHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLStandardEncryptionHandler, IsPasswordValid)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLStandardEncryptionHandler_IsPasswordValid(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLStandardEncryptionHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLStandardEncryptionHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLStandardEncryptionHandler, get_EncryptionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLStandardEncryptionHandler_get_EncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLStandardEncryptionHandler, set_EncryptionAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLStandardEncryptionHandler_set_EncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLStandardEncryptionHandler, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXMLStandardEncryptionHandler_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1804785670, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLStandardEncryptionHandler, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLStandardEncryptionHandler_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLStandardEncryptionHandler, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLStandardEncryptionHandler_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLStandardEncryptionHandler_GetName_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLStandardEncryptionHandler_GetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLStandardEncryptionHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLStandardEncryptionHandler_IsPasswordValid, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLStandardEncryptionHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLStandardEncryptionHandler_get_EncryptionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLStandardEncryptionHandler_set_EncryptionAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLStandardEncryptionHandler_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLStandardEncryptionHandler_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLStandardEncryptionHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeOpenXMLStandardEncryptionHandler_methods[] = {
	PHP_ME(TElOfficeOpenXMLStandardEncryptionHandler, GetName_Inst, arginfo_TElOfficeOpenXMLStandardEncryptionHandler_GetName_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLStandardEncryptionHandler, GetName, arginfo_TElOfficeOpenXMLStandardEncryptionHandler_GetName, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeOpenXMLStandardEncryptionHandler, Reset, arginfo_TElOfficeOpenXMLStandardEncryptionHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLStandardEncryptionHandler, IsPasswordValid, arginfo_TElOfficeOpenXMLStandardEncryptionHandler_IsPasswordValid, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLStandardEncryptionHandler, ClassType, arginfo_TElOfficeOpenXMLStandardEncryptionHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeOpenXMLStandardEncryptionHandler, get_EncryptionAlgorithm, arginfo_TElOfficeOpenXMLStandardEncryptionHandler_get_EncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLStandardEncryptionHandler, set_EncryptionAlgorithm, arginfo_TElOfficeOpenXMLStandardEncryptionHandler_set_EncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLStandardEncryptionHandler, get_Password, arginfo_TElOfficeOpenXMLStandardEncryptionHandler_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLStandardEncryptionHandler, set_Password, arginfo_TElOfficeOpenXMLStandardEncryptionHandler_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLStandardEncryptionHandler, __construct, arginfo_TElOfficeOpenXMLStandardEncryptionHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeOpenXMLStandardEncryptionHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeOpenXMLStandardEncryptionHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeOpenXMLStandardEncryptionHandler", TElOfficeOpenXMLStandardEncryptionHandler_methods);
	if (NULL == TElOfficeOpenXMLCustomEncryptionHandler_ce_ptr)
		Register_TElOfficeOpenXMLCustomEncryptionHandler(TSRMLS_C);
	TElOfficeOpenXMLStandardEncryptionHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeOpenXMLCustomEncryptionHandler_ce_ptr);
}

zend_class_entry *TElOfficeOpenXMLAgileEncryptionHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, GetName_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXMLAgileEncryptionHandler_GetName_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2008936263, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, GetName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXMLAgileEncryptionHandler_GetName(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2008936263, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, AddPasswordKeyEncryptor)
{
	char *sPassword;
	sb_str_size sPassword_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPassword, &sPassword_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_AddPasswordKeyEncryptor(SBGetObjectHandle(getThis() TSRMLS_CC), sPassword, (int32_t)sPassword_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, AddKeyEncryptor)
{
	zval *oKeyEncryptor;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oKeyEncryptor, TElOfficeOpenXMLKeyEncryptor_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_AddKeyEncryptor(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKeyEncryptor TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficeOpenXMLKeyEncryptor)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, InsertKeyEncryptor)
{
	sb_zend_long l4Index;
	zval *oKeyEncryptor;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Index, &oKeyEncryptor, TElOfficeOpenXMLKeyEncryptor_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_InsertKeyEncryptor(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, SBGetObjectHandle(oKeyEncryptor TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElOfficeOpenXMLKeyEncryptor)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, DeleteKeyEncryptor)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_DeleteKeyEncryptor(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, get_KeyEncryptorCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_get_KeyEncryptorCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, get_KeyEncryptors)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_get_KeyEncryptors(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeOpenXMLKeyEncryptor_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, get_CipherAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_get_CipherAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, set_CipherAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_set_CipherAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, get_CipherChaining)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSymmetricCryptoModeRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_get_CipherChaining(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, set_CipherChaining)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_set_CipherChaining(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSymmetricCryptoModeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, get_HashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_get_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, set_HashAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_set_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, get_SaltSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_get_SaltSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, set_SaltSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_set_SaltSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLAgileEncryptionHandler, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLAgileEncryptionHandler_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_GetName_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_GetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_AddPasswordKeyEncryptor, 0, 0, 1)
	ZEND_ARG_INFO(0, Password)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_AddKeyEncryptor, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, KeyEncryptor, TElOfficeOpenXMLKeyEncryptor, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_InsertKeyEncryptor, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_OBJ_INFO(0, KeyEncryptor, TElOfficeOpenXMLKeyEncryptor, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_DeleteKeyEncryptor, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_get_KeyEncryptorCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_get_KeyEncryptors, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_get_CipherAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_set_CipherAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_get_CipherChaining, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_set_CipherChaining, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_get_HashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_set_HashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_get_SaltSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler_set_SaltSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLAgileEncryptionHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeOpenXMLAgileEncryptionHandler_methods[] = {
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, GetName_Inst, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_GetName_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, GetName, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_GetName, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, Reset, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, AddPasswordKeyEncryptor, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_AddPasswordKeyEncryptor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, AddKeyEncryptor, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_AddKeyEncryptor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, InsertKeyEncryptor, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_InsertKeyEncryptor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, DeleteKeyEncryptor, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_DeleteKeyEncryptor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, ClassType, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, get_KeyEncryptorCount, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_get_KeyEncryptorCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, get_KeyEncryptors, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_get_KeyEncryptors, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, get_CipherAlgorithm, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_get_CipherAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, set_CipherAlgorithm, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_set_CipherAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, get_CipherChaining, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_get_CipherChaining, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, set_CipherChaining, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_set_CipherChaining, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, get_HashAlgorithm, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_get_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, set_HashAlgorithm, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_set_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, get_SaltSize, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_get_SaltSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, set_SaltSize, arginfo_TElOfficeOpenXMLAgileEncryptionHandler_set_SaltSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLAgileEncryptionHandler, __construct, arginfo_TElOfficeOpenXMLAgileEncryptionHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeOpenXMLAgileEncryptionHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeOpenXMLAgileEncryptionHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeOpenXMLAgileEncryptionHandler", TElOfficeOpenXMLAgileEncryptionHandler_methods);
	if (NULL == TElOfficeOpenXMLCustomEncryptionHandler_ce_ptr)
		Register_TElOfficeOpenXMLCustomEncryptionHandler(TSRMLS_C);
	TElOfficeOpenXMLAgileEncryptionHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeOpenXMLCustomEncryptionHandler_ce_ptr);
}

zend_class_entry *TElOfficeOpenXMLKeyEncryptor_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeOpenXMLKeyEncryptor, __construct)
{
	zval *oHandler;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLKeyEncryptor_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oHandler, TElOfficeOpenXMLAgileEncryptionHandler_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLKeyEncryptor_Create_1(SBGetObjectHandle(oHandler TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElOfficeOpenXMLAgileEncryptionHandler)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLKeyEncryptor___construct, 0, 0, 0)
	ZEND_ARG_OBJ_INFO(0, Handler, TElOfficeOpenXMLAgileEncryptionHandler, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeOpenXMLKeyEncryptor_methods[] = {
	PHP_ME(TElOfficeOpenXMLKeyEncryptor, __construct, arginfo_TElOfficeOpenXMLKeyEncryptor___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeOpenXMLKeyEncryptor(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeOpenXMLKeyEncryptor_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeOpenXMLKeyEncryptor", TElOfficeOpenXMLKeyEncryptor_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElOfficeOpenXMLKeyEncryptor_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElOfficeOpenXMLPasswordKeyEncryptor_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeOpenXMLPasswordKeyEncryptor, IsPasswordValid)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLPasswordKeyEncryptor_IsPasswordValid(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLPasswordKeyEncryptor, get_CipherAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLPasswordKeyEncryptor_get_CipherAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLPasswordKeyEncryptor, set_CipherAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLPasswordKeyEncryptor_set_CipherAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLPasswordKeyEncryptor, get_CipherChaining)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSymmetricCryptoModeRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLPasswordKeyEncryptor_get_CipherChaining(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLPasswordKeyEncryptor, set_CipherChaining)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLPasswordKeyEncryptor_set_CipherChaining(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSymmetricCryptoModeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLPasswordKeyEncryptor, get_HashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLPasswordKeyEncryptor_get_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLPasswordKeyEncryptor, set_HashAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLPasswordKeyEncryptor_set_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLPasswordKeyEncryptor, get_SaltSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLPasswordKeyEncryptor_get_SaltSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLPasswordKeyEncryptor, set_SaltSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLPasswordKeyEncryptor_set_SaltSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLPasswordKeyEncryptor, get_SpinCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLPasswordKeyEncryptor_get_SpinCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLPasswordKeyEncryptor, set_SpinCount)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLPasswordKeyEncryptor_set_SpinCount(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLPasswordKeyEncryptor, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXMLPasswordKeyEncryptor_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2129269646, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLPasswordKeyEncryptor, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLPasswordKeyEncryptor_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLPasswordKeyEncryptor, __construct)
{
	zval *oHandler;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oHandler, TElOfficeOpenXMLAgileEncryptionHandler_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLPasswordKeyEncryptor_Create(SBGetObjectHandle(oHandler TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficeOpenXMLAgileEncryptionHandler)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_IsPasswordValid, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_get_CipherAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_set_CipherAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_get_CipherChaining, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_set_CipherChaining, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_get_HashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_set_HashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_get_SaltSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_set_SaltSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_get_SpinCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_set_SpinCount, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLPasswordKeyEncryptor___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElOfficeOpenXMLAgileEncryptionHandler, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeOpenXMLPasswordKeyEncryptor_methods[] = {
	PHP_ME(TElOfficeOpenXMLPasswordKeyEncryptor, IsPasswordValid, arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_IsPasswordValid, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLPasswordKeyEncryptor, get_CipherAlgorithm, arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_get_CipherAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLPasswordKeyEncryptor, set_CipherAlgorithm, arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_set_CipherAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLPasswordKeyEncryptor, get_CipherChaining, arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_get_CipherChaining, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLPasswordKeyEncryptor, set_CipherChaining, arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_set_CipherChaining, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLPasswordKeyEncryptor, get_HashAlgorithm, arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_get_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLPasswordKeyEncryptor, set_HashAlgorithm, arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_set_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLPasswordKeyEncryptor, get_SaltSize, arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_get_SaltSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLPasswordKeyEncryptor, set_SaltSize, arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_set_SaltSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLPasswordKeyEncryptor, get_SpinCount, arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_get_SpinCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLPasswordKeyEncryptor, set_SpinCount, arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_set_SpinCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLPasswordKeyEncryptor, get_Password, arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLPasswordKeyEncryptor, set_Password, arginfo_TElOfficeOpenXMLPasswordKeyEncryptor_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLPasswordKeyEncryptor, __construct, arginfo_TElOfficeOpenXMLPasswordKeyEncryptor___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeOpenXMLPasswordKeyEncryptor(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeOpenXMLPasswordKeyEncryptor_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeOpenXMLPasswordKeyEncryptor", TElOfficeOpenXMLPasswordKeyEncryptor_methods);
	if (NULL == TElOfficeOpenXMLKeyEncryptor_ce_ptr)
		Register_TElOfficeOpenXMLKeyEncryptor(TSRMLS_C);
	TElOfficeOpenXMLPasswordKeyEncryptor_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeOpenXMLKeyEncryptor_ce_ptr);
}

zend_class_entry *TElOpenOfficeEncryptionHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElOpenOfficeEncryptionHandler, GetName_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOpenOfficeEncryptionHandler_GetName_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-398570518, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeEncryptionHandler, GetName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOpenOfficeEncryptionHandler_GetName(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-398570518, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeEncryptionHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOpenOfficeEncryptionHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeEncryptionHandler, IsPasswordValid)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOpenOfficeEncryptionHandler_IsPasswordValid(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeEncryptionHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeEncryptionHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeEncryptionHandler, get_ChecksumAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOpenOfficeEncryptionHandler_get_ChecksumAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeEncryptionHandler, set_ChecksumAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeEncryptionHandler_set_ChecksumAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeEncryptionHandler, get_EncryptionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOpenOfficeEncryptionHandler_get_EncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeEncryptionHandler, set_EncryptionAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeEncryptionHandler_set_EncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeEncryptionHandler, get_StartKeyGenerationAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOpenOfficeEncryptionHandler_get_StartKeyGenerationAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeEncryptionHandler, set_StartKeyGenerationAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeEncryptionHandler_set_StartKeyGenerationAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeEncryptionHandler, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOpenOfficeEncryptionHandler_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(43415938, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeEncryptionHandler, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeEncryptionHandler_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeEncryptionHandler, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeEncryptionHandler_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeEncryptionHandler_GetName_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeEncryptionHandler_GetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeEncryptionHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeEncryptionHandler_IsPasswordValid, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeEncryptionHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeEncryptionHandler_get_ChecksumAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeEncryptionHandler_set_ChecksumAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeEncryptionHandler_get_EncryptionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeEncryptionHandler_set_EncryptionAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeEncryptionHandler_get_StartKeyGenerationAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeEncryptionHandler_set_StartKeyGenerationAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeEncryptionHandler_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeEncryptionHandler_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeEncryptionHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOpenOfficeEncryptionHandler_methods[] = {
	PHP_ME(TElOpenOfficeEncryptionHandler, GetName_Inst, arginfo_TElOpenOfficeEncryptionHandler_GetName_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeEncryptionHandler, GetName, arginfo_TElOpenOfficeEncryptionHandler_GetName, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOpenOfficeEncryptionHandler, Reset, arginfo_TElOpenOfficeEncryptionHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeEncryptionHandler, IsPasswordValid, arginfo_TElOpenOfficeEncryptionHandler_IsPasswordValid, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeEncryptionHandler, ClassType, arginfo_TElOpenOfficeEncryptionHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOpenOfficeEncryptionHandler, get_ChecksumAlgorithm, arginfo_TElOpenOfficeEncryptionHandler_get_ChecksumAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeEncryptionHandler, set_ChecksumAlgorithm, arginfo_TElOpenOfficeEncryptionHandler_set_ChecksumAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeEncryptionHandler, get_EncryptionAlgorithm, arginfo_TElOpenOfficeEncryptionHandler_get_EncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeEncryptionHandler, set_EncryptionAlgorithm, arginfo_TElOpenOfficeEncryptionHandler_set_EncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeEncryptionHandler, get_StartKeyGenerationAlgorithm, arginfo_TElOpenOfficeEncryptionHandler_get_StartKeyGenerationAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeEncryptionHandler, set_StartKeyGenerationAlgorithm, arginfo_TElOpenOfficeEncryptionHandler_set_StartKeyGenerationAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeEncryptionHandler, get_Password, arginfo_TElOpenOfficeEncryptionHandler_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeEncryptionHandler, set_Password, arginfo_TElOpenOfficeEncryptionHandler_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeEncryptionHandler, __construct, arginfo_TElOpenOfficeEncryptionHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOpenOfficeEncryptionHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOpenOfficeEncryptionHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOpenOfficeEncryptionHandler", TElOpenOfficeEncryptionHandler_methods);
	if (NULL == TElOpenOfficeCustomEncryptionHandler_ce_ptr)
		Register_TElOpenOfficeCustomEncryptionHandler(TSRMLS_C);
	TElOpenOfficeEncryptionHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOpenOfficeCustomEncryptionHandler_ce_ptr);
}

zend_class_entry *TElOfficeBinaryRC4EncryptionHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeBinaryRC4EncryptionHandler, GetName_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeBinaryRC4EncryptionHandler_GetName_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1235806124, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4EncryptionHandler, GetName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeBinaryRC4EncryptionHandler_GetName(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1235806124, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4EncryptionHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryRC4EncryptionHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4EncryptionHandler, IsPasswordValid)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeBinaryRC4EncryptionHandler_IsPasswordValid(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4EncryptionHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryRC4EncryptionHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4EncryptionHandler, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeBinaryRC4EncryptionHandler_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-922692190, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4EncryptionHandler, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryRC4EncryptionHandler_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4EncryptionHandler, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryRC4EncryptionHandler_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4EncryptionHandler_GetName_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4EncryptionHandler_GetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4EncryptionHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4EncryptionHandler_IsPasswordValid, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4EncryptionHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4EncryptionHandler_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4EncryptionHandler_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4EncryptionHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeBinaryRC4EncryptionHandler_methods[] = {
	PHP_ME(TElOfficeBinaryRC4EncryptionHandler, GetName_Inst, arginfo_TElOfficeBinaryRC4EncryptionHandler_GetName_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4EncryptionHandler, GetName, arginfo_TElOfficeBinaryRC4EncryptionHandler_GetName, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeBinaryRC4EncryptionHandler, Reset, arginfo_TElOfficeBinaryRC4EncryptionHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4EncryptionHandler, IsPasswordValid, arginfo_TElOfficeBinaryRC4EncryptionHandler_IsPasswordValid, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4EncryptionHandler, ClassType, arginfo_TElOfficeBinaryRC4EncryptionHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeBinaryRC4EncryptionHandler, get_Password, arginfo_TElOfficeBinaryRC4EncryptionHandler_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4EncryptionHandler, set_Password, arginfo_TElOfficeBinaryRC4EncryptionHandler_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4EncryptionHandler, __construct, arginfo_TElOfficeBinaryRC4EncryptionHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeBinaryRC4EncryptionHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeBinaryRC4EncryptionHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeBinaryRC4EncryptionHandler", TElOfficeBinaryRC4EncryptionHandler_methods);
	if (NULL == TElOfficeBinaryCustomEncryptionHandler_ce_ptr)
		Register_TElOfficeBinaryCustomEncryptionHandler(TSRMLS_C);
	TElOfficeBinaryRC4EncryptionHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryCustomEncryptionHandler_ce_ptr);
}

zend_class_entry *TElOfficeBinaryRC4CryptoAPIEncryptionHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, GetName_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeBinaryRC4CryptoAPIEncryptionHandler_GetName_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2042272767, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, GetName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeBinaryRC4CryptoAPIEncryptionHandler_GetName(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2042272767, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryRC4CryptoAPIEncryptionHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, IsPasswordValid)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeBinaryRC4CryptoAPIEncryptionHandler_IsPasswordValid(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryRC4CryptoAPIEncryptionHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, get_EncryptDocumentProperties)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeBinaryRC4CryptoAPIEncryptionHandler_get_EncryptDocumentProperties(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, set_EncryptDocumentProperties)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryRC4CryptoAPIEncryptionHandler_set_EncryptDocumentProperties(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, get_HardenedKeyGeneration)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeBinaryRC4CryptoAPIEncryptionHandler_get_HardenedKeyGeneration(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, set_HardenedKeyGeneration)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryRC4CryptoAPIEncryptionHandler_set_HardenedKeyGeneration(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, get_KeyLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeBinaryRC4CryptoAPIEncryptionHandler_get_KeyLength(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, set_KeyLength)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryRC4CryptoAPIEncryptionHandler_set_KeyLength(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeBinaryRC4CryptoAPIEncryptionHandler_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(483823878, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryRC4CryptoAPIEncryptionHandler_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryRC4CryptoAPIEncryptionHandler_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_GetName_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_GetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_IsPasswordValid, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_get_EncryptDocumentProperties, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_set_EncryptDocumentProperties, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_get_HardenedKeyGeneration, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_set_HardenedKeyGeneration, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_get_KeyLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_set_KeyLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeBinaryRC4CryptoAPIEncryptionHandler_methods[] = {
	PHP_ME(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, GetName_Inst, arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_GetName_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, GetName, arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_GetName, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, Reset, arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, IsPasswordValid, arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_IsPasswordValid, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, ClassType, arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, get_EncryptDocumentProperties, arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_get_EncryptDocumentProperties, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, set_EncryptDocumentProperties, arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_set_EncryptDocumentProperties, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, get_HardenedKeyGeneration, arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_get_HardenedKeyGeneration, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, set_HardenedKeyGeneration, arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_set_HardenedKeyGeneration, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, get_KeyLength, arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_get_KeyLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, set_KeyLength, arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_set_KeyLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, get_Password, arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, set_Password, arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryRC4CryptoAPIEncryptionHandler, __construct, arginfo_TElOfficeBinaryRC4CryptoAPIEncryptionHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeBinaryRC4CryptoAPIEncryptionHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeBinaryRC4CryptoAPIEncryptionHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeBinaryRC4CryptoAPIEncryptionHandler", TElOfficeBinaryRC4CryptoAPIEncryptionHandler_methods);
	if (NULL == TElOfficeBinaryCustomEncryptionHandler_ce_ptr)
		Register_TElOfficeBinaryCustomEncryptionHandler(TSRMLS_C);
	TElOfficeBinaryRC4CryptoAPIEncryptionHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryCustomEncryptionHandler_ce_ptr);
}

zend_class_entry *TElOfficeBinaryCryptoAPISignatureHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, GetName_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeBinaryCryptoAPISignatureHandler_GetName_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1671016153, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, GetName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeBinaryCryptoAPISignatureHandler_GetName(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1671016153, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, Sign)
{
	zval *oCert;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_Sign(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCert, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_Sign_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, Validate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeBinarySignatureValidationStatusRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_Validate(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, InitiateAsyncSign)
{
	SBArrayZValInfo aiAdditionalData;
	zval *oCertificate;
	zval *oPars;
	zval *zaAdditionalData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_InitiateAsyncSign(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_InitiateAsyncSign_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oPars, TElDCParameters_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_InitiateAsyncSign_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oPars, TElDCParameters_ce_ptr, &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_InitiateAsyncSign_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_InitiateAsyncSign_4(SBGetObjectHandle(getThis() TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oCertificate, TElX509Certificate_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_InitiateAsyncSign_5(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oPars, TElDCParameters_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_InitiateAsyncSign_6(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!z", &oPars, TElDCParameters_ce_ptr, &oCertificate, TElX509Certificate_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_InitiateAsyncSign_7(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElX509Certificate) or (\\TElDCParameters) or (\\TElDCParameters, \\TElX509Certificate) or (array of byte|string|NULL) or (\\TElX509Certificate, array of byte|string|NULL) or (\\TElDCParameters, array of byte|string|NULL) or (\\TElDCParameters, \\TElX509Certificate, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, CompleteAsyncSign)
{
	zval *oState;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oState, TElDCAsyncState_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_CompleteAsyncSign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oState TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDCAsyncState)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, get_ExpireTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_get_ExpireTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, set_ExpireTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_set_ExpireTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, get_SignTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_get_SignTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, set_SignTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_set_SignTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, get_Certificate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_get_Certificate(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, set_Certificate)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_set_Certificate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, get_IntermediateCertificatesStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_get_IntermediateCertificatesStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryCryptoAPISignatureHandler, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryCryptoAPISignatureHandler_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_GetName_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_GetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_Sign, 0, 0, 0)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_Validate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_InitiateAsyncSign, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, Certificate_or_Pars_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Certificate_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AdditionalData, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_CompleteAsyncSign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, State, TElDCAsyncState, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_get_ExpireTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_set_ExpireTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_get_SignTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_set_SignTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_get_Certificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_set_Certificate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler_get_IntermediateCertificatesStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryCryptoAPISignatureHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeBinaryCryptoAPISignatureHandler_methods[] = {
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, GetName_Inst, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_GetName_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, GetName, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_GetName, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, Reset, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, Sign, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_Sign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, Validate, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_Validate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, InitiateAsyncSign, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_InitiateAsyncSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, CompleteAsyncSign, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_CompleteAsyncSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, ClassType, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, get_ExpireTime, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_get_ExpireTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, set_ExpireTime, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_set_ExpireTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, get_SignTime, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_get_SignTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, set_SignTime, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_set_SignTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, get_Certificate, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_get_Certificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, set_Certificate, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_set_Certificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, get_IntermediateCertificatesStorage, arginfo_TElOfficeBinaryCryptoAPISignatureHandler_get_IntermediateCertificatesStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryCryptoAPISignatureHandler, __construct, arginfo_TElOfficeBinaryCryptoAPISignatureHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeBinaryCryptoAPISignatureHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeBinaryCryptoAPISignatureHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeBinaryCryptoAPISignatureHandler", TElOfficeBinaryCryptoAPISignatureHandler_methods);
	if (NULL == TElOfficeBinaryCustomSignatureHandler_ce_ptr)
		Register_TElOfficeBinaryCustomSignatureHandler(TSRMLS_C);
	TElOfficeBinaryCryptoAPISignatureHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryCustomSignatureHandler_ce_ptr);
}

zend_class_entry *TElOfficeBinarySignedEntry_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeBinarySignedEntry, get_DigestMethod)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElXMLDigestMethodRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeBinarySignedEntry_get_DigestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinarySignedEntry, set_DigestMethod)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElOfficeBinarySignedEntry_set_DigestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), (TElXMLDigestMethodRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinarySignedEntry, get_DigestValue)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeBinarySignedEntry_get_DigestValue(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-919081504, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinarySignedEntry, set_DigestValue)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeBinarySignedEntry_set_DigestValue(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinarySignedEntry, get_Path)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeBinarySignedEntry_get_Path(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1153312967, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinarySignedEntry, get_ContentType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeBinarySignedEntry_get_ContentType(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1284335338, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinarySignedEntry, get_ValidationStatus)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeBinaryEntryValidationStatusRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeBinarySignedEntry_get_ValidationStatus(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinarySignedEntry, __construct)
{
	zval *oHandler;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oHandler, TElOfficeBinaryCustomSignatureHandler_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinarySignedEntry_Create(SBGetObjectHandle(oHandler TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficeBinaryCustomSignatureHandler)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinarySignedEntry_get_DigestMethod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinarySignedEntry_set_DigestMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinarySignedEntry_get_DigestValue, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinarySignedEntry_set_DigestValue, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinarySignedEntry_get_Path, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinarySignedEntry_get_ContentType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinarySignedEntry_get_ValidationStatus, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinarySignedEntry___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElOfficeBinaryCustomSignatureHandler, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeBinarySignedEntry_methods[] = {
	PHP_ME(TElOfficeBinarySignedEntry, get_DigestMethod, arginfo_TElOfficeBinarySignedEntry_get_DigestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinarySignedEntry, set_DigestMethod, arginfo_TElOfficeBinarySignedEntry_set_DigestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinarySignedEntry, get_DigestValue, arginfo_TElOfficeBinarySignedEntry_get_DigestValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinarySignedEntry, set_DigestValue, arginfo_TElOfficeBinarySignedEntry_set_DigestValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinarySignedEntry, get_Path, arginfo_TElOfficeBinarySignedEntry_get_Path, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinarySignedEntry, get_ContentType, arginfo_TElOfficeBinarySignedEntry_get_ContentType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinarySignedEntry, get_ValidationStatus, arginfo_TElOfficeBinarySignedEntry_get_ValidationStatus, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinarySignedEntry, __construct, arginfo_TElOfficeBinarySignedEntry___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeBinarySignedEntry(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeBinarySignedEntry_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeBinarySignedEntry", TElOfficeBinarySignedEntry_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElOfficeBinarySignedEntry_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElOfficeBinaryXMLSignatureHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, GetName_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeBinaryXMLSignatureHandler_GetName_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(928968054, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, GetName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeBinaryXMLSignatureHandler_GetName(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(928968054, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, PrepareForSigning)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_PrepareForSigning(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, Sign)
{
	sb_zend_long fSignatureMethod;
	zend_bool bEmbedCertificate;
	zend_bool bEmbedKeyInSignature;
	zval *oCertificate;
	zval *oCertStorage;
	zval *oKeyData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_Sign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oCertificate, TElX509Certificate_ce_ptr, &bEmbedCertificate) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_Sign_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (int8_t)bEmbedCertificate) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertStorage, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_Sign_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lb", &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bEmbedKeyInSignature) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_Sign_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bEmbedKeyInSignature) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate) or (\\TElX509Certificate, bool) or (\\TElCustomCertStorage) or (\\TElXMLKeyInfoData, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, Validate)
{
	zval *oCertificate;
	zval *oKeyData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeBinarySignatureValidationStatusRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_Validate(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		TSBOfficeBinarySignatureValidationStatusRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_Validate_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oKeyData, TElXMLKeyInfoData_ce_ptr) == SUCCESS)
	{
		TSBOfficeBinarySignatureValidationStatusRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_Validate_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElX509Certificate) or (\\TElXMLKeyInfoData)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, GenerateXAdES)
{
	sb_zend_long fXAdESForm;
	zval *oSigningCertificate;
	zval *oTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &fXAdESForm, &oSigningCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_GenerateXAdES(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBXAdESFormRaw)fXAdESForm, SBGetObjectHandle(oSigningCertificate TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!O!", &fXAdESForm, &oSigningCertificate, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_GenerateXAdES_1(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBXAdESFormRaw)fXAdESForm, SBGetObjectHandle(oSigningCertificate TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElX509Certificate) or (integer, \\TElX509Certificate, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, InitiateAsyncSign)
{
	sb_zend_long fSignatureMethod;
	SBArrayZValInfo aiAdditionalData;
	zend_bool bEmbedCertificate;
	zend_bool bEmbedKeyInSignature;
	zval *oCertificate;
	zval *oCertStorage;
	zval *oKeyData;
	zval *oPars;
	zval *zaAdditionalData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oCertificate, TElX509Certificate_ce_ptr, &bEmbedCertificate) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (int8_t)bEmbedCertificate, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertStorage, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lb", &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bEmbedKeyInSignature) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_4(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bEmbedKeyInSignature, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oPars, TElDCParameters_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_5(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!b", &oPars, TElDCParameters_ce_ptr, &oCertificate, TElX509Certificate_ce_ptr, &bEmbedCertificate) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_6(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (int8_t)bEmbedCertificate, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oPars, TElDCParameters_ce_ptr, &oCertStorage, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_7(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!lb", &oPars, TElDCParameters_ce_ptr, &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bEmbedKeyInSignature) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_8(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bEmbedKeyInSignature, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_9(SBGetObjectHandle(getThis() TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oCertificate, TElX509Certificate_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_10(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!bz", &oCertificate, TElX509Certificate_ce_ptr, &bEmbedCertificate, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_11(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (int8_t)bEmbedCertificate, aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oCertStorage, TElCustomCertStorage_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_12(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lbz", &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bEmbedKeyInSignature, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_13(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bEmbedKeyInSignature, aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oPars, TElDCParameters_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_14(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!bz", &oPars, TElDCParameters_ce_ptr, &oCertificate, TElX509Certificate_ce_ptr, &bEmbedCertificate, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_15(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (int8_t)bEmbedCertificate, aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!z", &oPars, TElDCParameters_ce_ptr, &oCertStorage, TElCustomCertStorage_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_16(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!lbz", &oPars, TElDCParameters_ce_ptr, &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bEmbedKeyInSignature, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign_17(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bEmbedKeyInSignature, aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElX509Certificate) or (\\TElX509Certificate, bool) or (\\TElCustomCertStorage) or (\\TElXMLKeyInfoData, integer, bool) or (\\TElDCParameters) or (\\TElDCParameters, \\TElX509Certificate, bool) or (\\TElDCParameters, \\TElCustomCertStorage) or (\\TElDCParameters, \\TElXMLKeyInfoData, integer, bool) or (array of byte|string|NULL) or (\\TElX509Certificate, array of byte|string|NULL) or (\\TElX509Certificate, bool, array of byte|string|NULL) or (\\TElCustomCertStorage, array of byte|string|NULL) or (\\TElXMLKeyInfoData, integer, bool, array of byte|string|NULL) or (\\TElDCParameters, array of byte|string|NULL) or (\\TElDCParameters, \\TElX509Certificate, bool, array of byte|string|NULL) or (\\TElDCParameters, \\TElCustomCertStorage, array of byte|string|NULL) or (\\TElDCParameters, \\TElXMLKeyInfoData, integer, bool, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, CompleteAsyncSign)
{
	zend_bool bEmbedCertificate;
	zval *oCertificate;
	zval *oState;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oState, TElDCAsyncState_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_CompleteAsyncSign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oState TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!b", &oState, TElDCAsyncState_ce_ptr, &oCertificate, TElX509Certificate_ce_ptr, &bEmbedCertificate) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_CompleteAsyncSign_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oState TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (int8_t)bEmbedCertificate) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDCAsyncState) or (\\TElDCAsyncState, \\TElX509Certificate, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, UpdateSignature)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_UpdateSignature(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, get_DigestMethod)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElXMLDigestMethodRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_get_DigestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, set_DigestMethod)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_set_DigestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), (TElXMLDigestMethodRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, get_SignedEntryCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_get_SignedEntryCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, get_SignedEntries)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_get_SignedEntries(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeBinarySignedEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, get_Certificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_get_Certificates(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, get_SignerCertificate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_get_SignerCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, get_SignerKeyData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_get_SignerKeyData(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLKeyInfoData_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, get_SignatureTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_get_SignatureTime(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeXMLSignatureTime_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, get_SignatureInfoV1)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_get_SignatureInfoV1(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeXMLSignatureInfoV1_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, get_XAdESProcessor)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_get_XAdESProcessor(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXAdESProcessor_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, set_XAdESProcessor)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElXAdESProcessor_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_set_XAdESProcessor(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXAdESProcessor)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, get_OwnXAdESProcessor)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_get_OwnXAdESProcessor(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, set_OwnXAdESProcessor)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_set_OwnXAdESProcessor(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, get_OnPrepareSignature)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeXMLSignEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_get_OnPrepareSignature(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, set_OnPrepareSignature)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_set_OnPrepareSignature(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBOfficeXMLSignEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOfficeXMLSignEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, get_OnBeforeSign)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeXMLSignEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_get_OnBeforeSign(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, set_OnBeforeSign)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_set_OnBeforeSign(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBOfficeXMLSignEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOfficeXMLSignEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, get_OnAfterSign)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeXMLSignEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_get_OnAfterSign(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, set_OnAfterSign)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_set_OnAfterSign(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBOfficeXMLSignEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOfficeXMLSignEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeBinaryXMLSignatureHandler, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeBinaryXMLSignatureHandler_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_GetName_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_GetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_PrepareForSigning, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_Sign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Certificate_or_CertStorage_or_KeyData, 0, 1)
	ZEND_ARG_INFO(0, EmbedCertificate_or_SignatureMethod)
	ZEND_ARG_INFO(0, EmbedKeyInSignature)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_Validate, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, Certificate_or_KeyData, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_GenerateXAdES, 0, 0, 2)
	ZEND_ARG_INFO(0, XAdESForm)
	ZEND_ARG_OBJ_INFO(0, SigningCertificate, TElX509Certificate, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, Certificate_or_CertStorage_or_KeyData_or_Pars_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, EmbedCertificate_or_SignatureMethod_or_Certificate_or_CertStorage_or_KeyData_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, EmbedKeyInSignature_or_EmbedCertificate_or_SignatureMethod_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, EmbedKeyInSignature_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AdditionalData, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_CompleteAsyncSign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, State, TElDCAsyncState, 1)
	ZEND_ARG_OBJ_INFO(0, Certificate, TElX509Certificate, 1)
	ZEND_ARG_INFO(0, EmbedCertificate)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_UpdateSignature, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_get_DigestMethod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_set_DigestMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_get_SignedEntryCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_get_SignedEntries, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_get_Certificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_get_SignerCertificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_get_SignerKeyData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_get_SignatureTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_get_SignatureInfoV1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_get_XAdESProcessor, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_set_XAdESProcessor, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElXAdESProcessor, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_get_OwnXAdESProcessor, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_set_OwnXAdESProcessor, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_get_OnPrepareSignature, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_set_OnPrepareSignature, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_get_OnBeforeSign, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_set_OnBeforeSign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_get_OnAfterSign, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler_set_OnAfterSign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeBinaryXMLSignatureHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeBinaryXMLSignatureHandler_methods[] = {
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, GetName_Inst, arginfo_TElOfficeBinaryXMLSignatureHandler_GetName_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, GetName, arginfo_TElOfficeBinaryXMLSignatureHandler_GetName, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, Reset, arginfo_TElOfficeBinaryXMLSignatureHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, PrepareForSigning, arginfo_TElOfficeBinaryXMLSignatureHandler_PrepareForSigning, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, Sign, arginfo_TElOfficeBinaryXMLSignatureHandler_Sign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, Validate, arginfo_TElOfficeBinaryXMLSignatureHandler_Validate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, GenerateXAdES, arginfo_TElOfficeBinaryXMLSignatureHandler_GenerateXAdES, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, InitiateAsyncSign, arginfo_TElOfficeBinaryXMLSignatureHandler_InitiateAsyncSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, CompleteAsyncSign, arginfo_TElOfficeBinaryXMLSignatureHandler_CompleteAsyncSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, UpdateSignature, arginfo_TElOfficeBinaryXMLSignatureHandler_UpdateSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, ClassType, arginfo_TElOfficeBinaryXMLSignatureHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, get_DigestMethod, arginfo_TElOfficeBinaryXMLSignatureHandler_get_DigestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, set_DigestMethod, arginfo_TElOfficeBinaryXMLSignatureHandler_set_DigestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, get_SignedEntryCount, arginfo_TElOfficeBinaryXMLSignatureHandler_get_SignedEntryCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, get_SignedEntries, arginfo_TElOfficeBinaryXMLSignatureHandler_get_SignedEntries, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, get_Certificates, arginfo_TElOfficeBinaryXMLSignatureHandler_get_Certificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, get_SignerCertificate, arginfo_TElOfficeBinaryXMLSignatureHandler_get_SignerCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, get_SignerKeyData, arginfo_TElOfficeBinaryXMLSignatureHandler_get_SignerKeyData, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, get_SignatureTime, arginfo_TElOfficeBinaryXMLSignatureHandler_get_SignatureTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, get_SignatureInfoV1, arginfo_TElOfficeBinaryXMLSignatureHandler_get_SignatureInfoV1, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, get_XAdESProcessor, arginfo_TElOfficeBinaryXMLSignatureHandler_get_XAdESProcessor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, set_XAdESProcessor, arginfo_TElOfficeBinaryXMLSignatureHandler_set_XAdESProcessor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, get_OwnXAdESProcessor, arginfo_TElOfficeBinaryXMLSignatureHandler_get_OwnXAdESProcessor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, set_OwnXAdESProcessor, arginfo_TElOfficeBinaryXMLSignatureHandler_set_OwnXAdESProcessor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, get_OnPrepareSignature, arginfo_TElOfficeBinaryXMLSignatureHandler_get_OnPrepareSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, set_OnPrepareSignature, arginfo_TElOfficeBinaryXMLSignatureHandler_set_OnPrepareSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, get_OnBeforeSign, arginfo_TElOfficeBinaryXMLSignatureHandler_get_OnBeforeSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, set_OnBeforeSign, arginfo_TElOfficeBinaryXMLSignatureHandler_set_OnBeforeSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, get_OnAfterSign, arginfo_TElOfficeBinaryXMLSignatureHandler_get_OnAfterSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, set_OnAfterSign, arginfo_TElOfficeBinaryXMLSignatureHandler_set_OnAfterSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeBinaryXMLSignatureHandler, __construct, arginfo_TElOfficeBinaryXMLSignatureHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeBinaryXMLSignatureHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeBinaryXMLSignatureHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeBinaryXMLSignatureHandler", TElOfficeBinaryXMLSignatureHandler_methods);
	if (NULL == TElOfficeBinaryCustomSignatureHandler_ce_ptr)
		Register_TElOfficeBinaryCustomSignatureHandler(TSRMLS_C);
	TElOfficeBinaryXMLSignatureHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeBinaryCustomSignatureHandler_ce_ptr);
}

zend_class_entry *TElOfficeOpenXMLSignedPart_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeOpenXMLSignedPart, get_CanonicalizationMethod)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElXMLCanonicalizationMethodRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLSignedPart_get_CanonicalizationMethod(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedPart, set_CanonicalizationMethod)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLSignedPart_set_CanonicalizationMethod(SBGetObjectHandle(getThis() TSRMLS_CC), (TElXMLCanonicalizationMethodRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedPart, get_DigestMethod)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElXMLDigestMethodRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLSignedPart_get_DigestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedPart, set_DigestMethod)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLSignedPart_set_DigestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), (TElXMLDigestMethodRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedPart, get_DigestValue)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOfficeOpenXMLSignedPart_get_DigestValue(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1311258421, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedPart, set_DigestValue)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeOpenXMLSignedPart_set_DigestValue(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedPart, get_URI)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXMLSignedPart_get_URI(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1513216999, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedPart, get_ContentType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXMLSignedPart_get_ContentType(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(879576001, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedPart, get_IsRelationshipPart)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLSignedPart_get_IsRelationshipPart(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedPart, get_ValidationStatus)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeOpenXMLPartValidationStatusRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLSignedPart_get_ValidationStatus(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedPart, __construct)
{
	char *sAContentType;
	char *sAURI;
	sb_str_size sAContentType_len;
	sb_str_size sAURI_len;
	zval *oHandler;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oHandler, TElOfficeOpenXMLCustomSignatureHandler_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLSignedPart_Create(SBGetObjectHandle(oHandler TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!ss", &oHandler, TElOfficeOpenXMLCustomSignatureHandler_ce_ptr, &sAURI, &sAURI_len, &sAContentType, &sAContentType_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLSignedPart_Create_1(SBGetObjectHandle(oHandler TSRMLS_CC), sAURI, (int32_t)sAURI_len, sAContentType, (int32_t)sAContentType_len, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficeOpenXMLCustomSignatureHandler) or (\\TElOfficeOpenXMLCustomSignatureHandler, string, string)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedPart_get_CanonicalizationMethod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedPart_set_CanonicalizationMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedPart_get_DigestMethod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedPart_set_DigestMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedPart_get_DigestValue, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedPart_set_DigestValue, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedPart_get_URI, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedPart_get_ContentType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedPart_get_IsRelationshipPart, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedPart_get_ValidationStatus, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedPart___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElOfficeOpenXMLCustomSignatureHandler, 1)
	ZEND_ARG_INFO(0, AURI)
	ZEND_ARG_INFO(0, AContentType)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeOpenXMLSignedPart_methods[] = {
	PHP_ME(TElOfficeOpenXMLSignedPart, get_CanonicalizationMethod, arginfo_TElOfficeOpenXMLSignedPart_get_CanonicalizationMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedPart, set_CanonicalizationMethod, arginfo_TElOfficeOpenXMLSignedPart_set_CanonicalizationMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedPart, get_DigestMethod, arginfo_TElOfficeOpenXMLSignedPart_get_DigestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedPart, set_DigestMethod, arginfo_TElOfficeOpenXMLSignedPart_set_DigestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedPart, get_DigestValue, arginfo_TElOfficeOpenXMLSignedPart_get_DigestValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedPart, set_DigestValue, arginfo_TElOfficeOpenXMLSignedPart_set_DigestValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedPart, get_URI, arginfo_TElOfficeOpenXMLSignedPart_get_URI, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedPart, get_ContentType, arginfo_TElOfficeOpenXMLSignedPart_get_ContentType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedPart, get_IsRelationshipPart, arginfo_TElOfficeOpenXMLSignedPart_get_IsRelationshipPart, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedPart, get_ValidationStatus, arginfo_TElOfficeOpenXMLSignedPart_get_ValidationStatus, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedPart, __construct, arginfo_TElOfficeOpenXMLSignedPart___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeOpenXMLSignedPart(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeOpenXMLSignedPart_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeOpenXMLSignedPart", TElOfficeOpenXMLSignedPart_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElOfficeOpenXMLSignedPart_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElOfficeOpenXMLSignedRelationshipPart_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeOpenXMLSignedRelationshipPart, AddSourceId)
{
	char *sSourceId;
	sb_str_size sSourceId_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sSourceId, &sSourceId_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLSignedRelationshipPart_AddSourceId(SBGetObjectHandle(getThis() TSRMLS_CC), sSourceId, (int32_t)sSourceId_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedRelationshipPart, AddSourceType)
{
	char *sSourceType;
	sb_str_size sSourceType_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sSourceType, &sSourceType_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLSignedRelationshipPart_AddSourceType(SBGetObjectHandle(getThis() TSRMLS_CC), sSourceType, (int32_t)sSourceType_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedRelationshipPart, DeleteSourceId)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLSignedRelationshipPart_DeleteSourceId(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedRelationshipPart, DeleteSourceType)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLSignedRelationshipPart_DeleteSourceType(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedRelationshipPart, HasSourceId)
{
	char *sSourceId;
	sb_str_size sSourceId_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sSourceId, &sSourceId_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLSignedRelationshipPart_HasSourceId(SBGetObjectHandle(getThis() TSRMLS_CC), sSourceId, (int32_t)sSourceId_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedRelationshipPart, HasSourceType)
{
	char *sSourceType;
	sb_str_size sSourceType_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sSourceType, &sSourceType_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLSignedRelationshipPart_HasSourceType(SBGetObjectHandle(getThis() TSRMLS_CC), sSourceType, (int32_t)sSourceType_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedRelationshipPart, get_SourceIds)
{
	sb_zend_long l4Index;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXMLSignedRelationshipPart_get_SourceIds(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-550483727, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedRelationshipPart, get_SourceTypes)
{
	sb_zend_long l4Index;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXMLSignedRelationshipPart_get_SourceTypes(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-808854427, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedRelationshipPart, get_SourceTypeCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLSignedRelationshipPart_get_SourceTypeCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedRelationshipPart, get_SourceIdCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLSignedRelationshipPart_get_SourceIdCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedRelationshipPart, get_PartURI)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXMLSignedRelationshipPart_get_PartURI(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1825366453, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignedRelationshipPart, __construct)
{
	char *sAContentType;
	char *sAPartURI;
	char *sAURI;
	sb_str_size sAContentType_len;
	sb_str_size sAPartURI_len;
	sb_str_size sAURI_len;
	zval *oHandler;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oHandler, TElOfficeOpenXMLCustomSignatureHandler_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLSignedRelationshipPart_Create(SBGetObjectHandle(oHandler TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!sss", &oHandler, TElOfficeOpenXMLCustomSignatureHandler_ce_ptr, &sAURI, &sAURI_len, &sAContentType, &sAContentType_len, &sAPartURI, &sAPartURI_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLSignedRelationshipPart_Create_1(SBGetObjectHandle(oHandler TSRMLS_CC), sAURI, (int32_t)sAURI_len, sAContentType, (int32_t)sAContentType_len, sAPartURI, (int32_t)sAPartURI_len, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficeOpenXMLCustomSignatureHandler) or (\\TElOfficeOpenXMLCustomSignatureHandler, string, string, string)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedRelationshipPart_AddSourceId, 0, 0, 1)
	ZEND_ARG_INFO(0, SourceId)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedRelationshipPart_AddSourceType, 0, 0, 1)
	ZEND_ARG_INFO(0, SourceType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedRelationshipPart_DeleteSourceId, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedRelationshipPart_DeleteSourceType, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedRelationshipPart_HasSourceId, 0, 0, 1)
	ZEND_ARG_INFO(0, SourceId)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedRelationshipPart_HasSourceType, 0, 0, 1)
	ZEND_ARG_INFO(0, SourceType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedRelationshipPart_get_SourceIds, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedRelationshipPart_get_SourceTypes, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedRelationshipPart_get_SourceTypeCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedRelationshipPart_get_SourceIdCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedRelationshipPart_get_PartURI, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignedRelationshipPart___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElOfficeOpenXMLCustomSignatureHandler, 1)
	ZEND_ARG_INFO(0, AURI)
	ZEND_ARG_INFO(0, AContentType)
	ZEND_ARG_INFO(0, APartURI)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeOpenXMLSignedRelationshipPart_methods[] = {
	PHP_ME(TElOfficeOpenXMLSignedRelationshipPart, AddSourceId, arginfo_TElOfficeOpenXMLSignedRelationshipPart_AddSourceId, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedRelationshipPart, AddSourceType, arginfo_TElOfficeOpenXMLSignedRelationshipPart_AddSourceType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedRelationshipPart, DeleteSourceId, arginfo_TElOfficeOpenXMLSignedRelationshipPart_DeleteSourceId, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedRelationshipPart, DeleteSourceType, arginfo_TElOfficeOpenXMLSignedRelationshipPart_DeleteSourceType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedRelationshipPart, HasSourceId, arginfo_TElOfficeOpenXMLSignedRelationshipPart_HasSourceId, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedRelationshipPart, HasSourceType, arginfo_TElOfficeOpenXMLSignedRelationshipPart_HasSourceType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedRelationshipPart, get_SourceIds, arginfo_TElOfficeOpenXMLSignedRelationshipPart_get_SourceIds, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedRelationshipPart, get_SourceTypes, arginfo_TElOfficeOpenXMLSignedRelationshipPart_get_SourceTypes, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedRelationshipPart, get_SourceTypeCount, arginfo_TElOfficeOpenXMLSignedRelationshipPart_get_SourceTypeCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedRelationshipPart, get_SourceIdCount, arginfo_TElOfficeOpenXMLSignedRelationshipPart_get_SourceIdCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedRelationshipPart, get_PartURI, arginfo_TElOfficeOpenXMLSignedRelationshipPart_get_PartURI, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignedRelationshipPart, __construct, arginfo_TElOfficeOpenXMLSignedRelationshipPart___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeOpenXMLSignedRelationshipPart(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeOpenXMLSignedRelationshipPart_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeOpenXMLSignedRelationshipPart", TElOfficeOpenXMLSignedRelationshipPart_methods);
	if (NULL == TElOfficeOpenXMLSignedPart_ce_ptr)
		Register_TElOfficeOpenXMLSignedPart(TSRMLS_C);
	TElOfficeOpenXMLSignedRelationshipPart_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeOpenXMLSignedPart_ce_ptr);
}

zend_class_entry *TElOfficeOpenXMLBaseSignatureHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, Sign)
{
	sb_zend_long fEmbedCertificate;
	sb_zend_long fSignatureMethod;
	zend_bool bEmbedKeyInSignature;
	zval *oCertificate;
	zval *oCertStorage;
	zval *oKeyData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_Sign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oCertificate, TElX509Certificate_ce_ptr, &fEmbedCertificate) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_Sign_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (TSBOfficeOpenXMLEmbedCertificateRaw)fEmbedCertificate) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertStorage, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_Sign_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oCertStorage, TElCustomCertStorage_ce_ptr, &fEmbedCertificate) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_Sign_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), (TSBOfficeOpenXMLEmbedCertificateRaw)fEmbedCertificate) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lb", &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bEmbedKeyInSignature) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_Sign_4(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bEmbedKeyInSignature) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate) or (\\TElX509Certificate, integer) or (\\TElCustomCertStorage) or (\\TElCustomCertStorage, integer) or (\\TElXMLKeyInfoData, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, Validate)
{
	zval *oCertificate;
	zval *oKeyData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeOpenXMLSignatureValidationStatusRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_Validate(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		TSBOfficeOpenXMLSignatureValidationStatusRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_Validate_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oKeyData, TElXMLKeyInfoData_ce_ptr) == SUCCESS)
	{
		TSBOfficeOpenXMLSignatureValidationStatusRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_Validate_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElX509Certificate) or (\\TElXMLKeyInfoData)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, GenerateXAdES)
{
	sb_zend_long fXAdESForm;
	zval *oSigningCertificate;
	zval *oTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &fXAdESForm, &oSigningCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_GenerateXAdES(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBXAdESFormRaw)fXAdESForm, SBGetObjectHandle(oSigningCertificate TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!O!", &fXAdESForm, &oSigningCertificate, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_GenerateXAdES_1(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBXAdESFormRaw)fXAdESForm, SBGetObjectHandle(oSigningCertificate TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElX509Certificate) or (integer, \\TElX509Certificate, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, InitiateAsyncSign)
{
	sb_zend_long fEmbedCertificate;
	sb_zend_long fSignatureMethod;
	SBArrayZValInfo aiAdditionalData;
	zend_bool bEmbedKeyInSignature;
	zval *oCertificate;
	zval *oCertStorage;
	zval *oKeyData;
	zval *oPars;
	zval *zaAdditionalData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oCertificate, TElX509Certificate_ce_ptr, &fEmbedCertificate) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (TSBOfficeOpenXMLEmbedCertificateRaw)fEmbedCertificate, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertStorage, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oCertStorage, TElCustomCertStorage_ce_ptr, &fEmbedCertificate) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_4(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), (TSBOfficeOpenXMLEmbedCertificateRaw)fEmbedCertificate, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lb", &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bEmbedKeyInSignature) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_5(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bEmbedKeyInSignature, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oPars, TElDCParameters_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_6(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oPars, TElDCParameters_ce_ptr, &oCertificate, TElX509Certificate_ce_ptr, &fEmbedCertificate) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_7(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (TSBOfficeOpenXMLEmbedCertificateRaw)fEmbedCertificate, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oPars, TElDCParameters_ce_ptr, &oCertStorage, TElCustomCertStorage_ce_ptr, &fEmbedCertificate) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_8(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), (TSBOfficeOpenXMLEmbedCertificateRaw)fEmbedCertificate, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!lb", &oPars, TElDCParameters_ce_ptr, &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bEmbedKeyInSignature) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_9(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bEmbedKeyInSignature, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_10(SBGetObjectHandle(getThis() TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oCertificate, TElX509Certificate_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_11(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lz", &oCertificate, TElX509Certificate_ce_ptr, &fEmbedCertificate, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_12(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (TSBOfficeOpenXMLEmbedCertificateRaw)fEmbedCertificate, aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oCertStorage, TElCustomCertStorage_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_13(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lz", &oCertStorage, TElCustomCertStorage_ce_ptr, &fEmbedCertificate, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_14(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), (TSBOfficeOpenXMLEmbedCertificateRaw)fEmbedCertificate, aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lbz", &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bEmbedKeyInSignature, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_15(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bEmbedKeyInSignature, aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oPars, TElDCParameters_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_16(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!lz", &oPars, TElDCParameters_ce_ptr, &oCertificate, TElX509Certificate_ce_ptr, &fEmbedCertificate, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_17(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (TSBOfficeOpenXMLEmbedCertificateRaw)fEmbedCertificate, aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!lz", &oPars, TElDCParameters_ce_ptr, &oCertStorage, TElCustomCertStorage_ce_ptr, &fEmbedCertificate, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_18(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), (TSBOfficeOpenXMLEmbedCertificateRaw)fEmbedCertificate, aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!lbz", &oPars, TElDCParameters_ce_ptr, &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bEmbedKeyInSignature, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign_19(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bEmbedKeyInSignature, aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElX509Certificate) or (\\TElX509Certificate, integer) or (\\TElCustomCertStorage) or (\\TElCustomCertStorage, integer) or (\\TElXMLKeyInfoData, integer, bool) or (\\TElDCParameters) or (\\TElDCParameters, \\TElX509Certificate, integer) or (\\TElDCParameters, \\TElCustomCertStorage, integer) or (\\TElDCParameters, \\TElXMLKeyInfoData, integer, bool) or (array of byte|string|NULL) or (\\TElX509Certificate, array of byte|string|NULL) or (\\TElX509Certificate, integer, array of byte|string|NULL) or (\\TElCustomCertStorage, array of byte|string|NULL) or (\\TElCustomCertStorage, integer, array of byte|string|NULL) or (\\TElXMLKeyInfoData, integer, bool, array of byte|string|NULL) or (\\TElDCParameters, array of byte|string|NULL) or (\\TElDCParameters, \\TElX509Certificate, integer, array of byte|string|NULL) or (\\TElDCParameters, \\TElCustomCertStorage, integer, array of byte|string|NULL) or (\\TElDCParameters, \\TElXMLKeyInfoData, integer, bool, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, CompleteAsyncSign)
{
	sb_zend_long fEmbedCertificate;
	zval *oCertificate;
	zval *oState;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oState, TElDCAsyncState_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_CompleteAsyncSign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oState TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oState, TElDCAsyncState_ce_ptr, &oCertificate, TElX509Certificate_ce_ptr, &fEmbedCertificate) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_CompleteAsyncSign_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oState TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (TSBOfficeOpenXMLEmbedCertificateRaw)fEmbedCertificate) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDCAsyncState) or (\\TElDCAsyncState, \\TElX509Certificate, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, UpdateSignature)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_UpdateSignature(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, AddSignedPart)
{
	zval *oPart;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oPart, TElOfficeOpenXMLSignedPart_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_AddSignedPart(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPart TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficeOpenXMLSignedPart)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, InsertSignedPart)
{
	sb_zend_long l4Index;
	zval *oPart;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Index, &oPart, TElOfficeOpenXMLSignedPart_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_InsertSignedPart(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, SBGetObjectHandle(oPart TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElOfficeOpenXMLSignedPart)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, DeleteSignedPart)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_DeleteSignedPart(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, GetSignedPartByURI)
{
	char *sURI;
	sb_str_size sURI_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sURI, &sURI_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_GetSignedPartByURI(SBGetObjectHandle(getThis() TSRMLS_CC), sURI, (int32_t)sURI_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeOpenXMLSignedPart_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, GetSignedRelationshipPartByPartURI)
{
	char *sPartURI;
	sb_str_size sPartURI_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPartURI, &sPartURI_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_GetSignedRelationshipPartByPartURI(SBGetObjectHandle(getThis() TSRMLS_CC), sPartURI, (int32_t)sPartURI_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeOpenXMLSignedRelationshipPart_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, AddCoreProperties)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_AddCoreProperties(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, AddDocument)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_AddDocument(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, AddCounterSignature)
{
	zval *oASignaturePart;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oASignaturePart, TElOfficePackagePart_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_AddCounterSignature(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oASignaturePart TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficePackagePart)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, AddPart)
{
	char *sURI;
	sb_str_size sURI_len;
	zval *oPart;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oPart, TElOfficePackagePart_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_AddPart(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPart TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sURI, &sURI_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_AddPart_1(SBGetObjectHandle(getThis() TSRMLS_CC), sURI, (int32_t)sURI_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficePackagePart) or (string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, AddPartRelationshipSourceType)
{
	char *sPartURI;
	char *sSourceType;
	sb_str_size sPartURI_len;
	sb_str_size sSourceType_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sPartURI, &sPartURI_len, &sSourceType, &sSourceType_len) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_AddPartRelationshipSourceType(SBGetObjectHandle(getThis() TSRMLS_CC), sPartURI, (int32_t)sPartURI_len, sSourceType, (int32_t)sSourceType_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, AddPartRelationships)
{
	zval *oPart;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oPart, TElOfficePackagePart_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_AddPartRelationships(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPart TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficePackagePart)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, IsCorePropertiesSigned)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_IsCorePropertiesSigned(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, IsDocumentSigned)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_IsDocumentSigned(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, IsPartSigned)
{
	char *sURI;
	sb_str_size sURI_len;
	zval *oPart;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oPart, TElOfficePackagePart_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_IsPartSigned(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPart TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sURI, &sURI_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_IsPartSigned_1(SBGetObjectHandle(getThis() TSRMLS_CC), sURI, (int32_t)sURI_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOfficePackagePart) or (string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, get_DigestMethod)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElXMLDigestMethodRaw fOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_get_DigestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, set_DigestMethod)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_set_DigestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), (TElXMLDigestMethodRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, get_SignedPartCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_get_SignedPartCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, get_SignedParts)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_get_SignedParts(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeOpenXMLSignedPart_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, get_Certificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_get_Certificates(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, get_SignerCertificate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_get_SignerCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, get_SignerKeyData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_get_SignerKeyData(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLKeyInfoData_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, get_SignatureTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_get_SignatureTime(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeXMLSignatureTime_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, get_XAdESProcessor)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_get_XAdESProcessor(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXAdESProcessor_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, set_XAdESProcessor)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElXAdESProcessor_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_set_XAdESProcessor(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXAdESProcessor)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, get_OwnXAdESProcessor)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_get_OwnXAdESProcessor(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, set_OwnXAdESProcessor)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_set_OwnXAdESProcessor(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, get_OnPrepareSignature)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeXMLSignEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_get_OnPrepareSignature(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, set_OnPrepareSignature)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_set_OnPrepareSignature(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBOfficeXMLSignEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOfficeXMLSignEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, get_OnBeforeSign)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeXMLSignEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_get_OnBeforeSign(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, set_OnBeforeSign)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_set_OnBeforeSign(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBOfficeXMLSignEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOfficeXMLSignEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, get_OnAfterSign)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeXMLSignEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_get_OnAfterSign(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, set_OnAfterSign)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_set_OnAfterSign(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBOfficeXMLSignEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOfficeXMLSignEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLBaseSignatureHandler, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLBaseSignatureHandler_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_Sign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Certificate_or_CertStorage_or_KeyData, 0, 1)
	ZEND_ARG_INFO(0, EmbedCertificate_or_SignatureMethod)
	ZEND_ARG_INFO(0, EmbedKeyInSignature)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_Validate, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, Certificate_or_KeyData, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_GenerateXAdES, 0, 0, 2)
	ZEND_ARG_INFO(0, XAdESForm)
	ZEND_ARG_OBJ_INFO(0, SigningCertificate, TElX509Certificate, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, Certificate_or_CertStorage_or_KeyData_or_Pars_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, EmbedCertificate_or_SignatureMethod_or_Certificate_or_CertStorage_or_KeyData_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, EmbedKeyInSignature_or_EmbedCertificate_or_SignatureMethod_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, EmbedKeyInSignature_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AdditionalData, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_CompleteAsyncSign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, State, TElDCAsyncState, 1)
	ZEND_ARG_OBJ_INFO(0, Certificate, TElX509Certificate, 1)
	ZEND_ARG_INFO(0, EmbedCertificate)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_UpdateSignature, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_AddSignedPart, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Part, TElOfficeOpenXMLSignedPart, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_InsertSignedPart, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_OBJ_INFO(0, Part, TElOfficeOpenXMLSignedPart, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_DeleteSignedPart, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_GetSignedPartByURI, 0, 0, 1)
	ZEND_ARG_INFO(0, URI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_GetSignedRelationshipPartByPartURI, 0, 0, 1)
	ZEND_ARG_INFO(0, PartURI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_AddCoreProperties, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_AddDocument, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_AddCounterSignature, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, ASignaturePart, TElOfficePackagePart, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_AddPart, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Part_or_URI, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_AddPartRelationshipSourceType, 0, 0, 2)
	ZEND_ARG_INFO(0, PartURI)
	ZEND_ARG_INFO(0, SourceType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_AddPartRelationships, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Part, TElOfficePackagePart, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_IsCorePropertiesSigned, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_IsDocumentSigned, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_IsPartSigned, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Part_or_URI, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_DigestMethod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_set_DigestMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_SignedPartCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_SignedParts, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_Certificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_SignerCertificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_SignerKeyData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_SignatureTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_XAdESProcessor, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_set_XAdESProcessor, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElXAdESProcessor, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_OwnXAdESProcessor, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_set_OwnXAdESProcessor, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_OnPrepareSignature, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_set_OnPrepareSignature, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_OnBeforeSign, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_set_OnBeforeSign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_OnAfterSign, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler_set_OnAfterSign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLBaseSignatureHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeOpenXMLBaseSignatureHandler_methods[] = {
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, Reset, arginfo_TElOfficeOpenXMLBaseSignatureHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, Sign, arginfo_TElOfficeOpenXMLBaseSignatureHandler_Sign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, Validate, arginfo_TElOfficeOpenXMLBaseSignatureHandler_Validate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, GenerateXAdES, arginfo_TElOfficeOpenXMLBaseSignatureHandler_GenerateXAdES, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, InitiateAsyncSign, arginfo_TElOfficeOpenXMLBaseSignatureHandler_InitiateAsyncSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, CompleteAsyncSign, arginfo_TElOfficeOpenXMLBaseSignatureHandler_CompleteAsyncSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, UpdateSignature, arginfo_TElOfficeOpenXMLBaseSignatureHandler_UpdateSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, AddSignedPart, arginfo_TElOfficeOpenXMLBaseSignatureHandler_AddSignedPart, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, InsertSignedPart, arginfo_TElOfficeOpenXMLBaseSignatureHandler_InsertSignedPart, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, DeleteSignedPart, arginfo_TElOfficeOpenXMLBaseSignatureHandler_DeleteSignedPart, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, GetSignedPartByURI, arginfo_TElOfficeOpenXMLBaseSignatureHandler_GetSignedPartByURI, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, GetSignedRelationshipPartByPartURI, arginfo_TElOfficeOpenXMLBaseSignatureHandler_GetSignedRelationshipPartByPartURI, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, AddCoreProperties, arginfo_TElOfficeOpenXMLBaseSignatureHandler_AddCoreProperties, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, AddDocument, arginfo_TElOfficeOpenXMLBaseSignatureHandler_AddDocument, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, AddCounterSignature, arginfo_TElOfficeOpenXMLBaseSignatureHandler_AddCounterSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, AddPart, arginfo_TElOfficeOpenXMLBaseSignatureHandler_AddPart, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, AddPartRelationshipSourceType, arginfo_TElOfficeOpenXMLBaseSignatureHandler_AddPartRelationshipSourceType, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, AddPartRelationships, arginfo_TElOfficeOpenXMLBaseSignatureHandler_AddPartRelationships, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, IsCorePropertiesSigned, arginfo_TElOfficeOpenXMLBaseSignatureHandler_IsCorePropertiesSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, IsDocumentSigned, arginfo_TElOfficeOpenXMLBaseSignatureHandler_IsDocumentSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, IsPartSigned, arginfo_TElOfficeOpenXMLBaseSignatureHandler_IsPartSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, ClassType, arginfo_TElOfficeOpenXMLBaseSignatureHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, get_DigestMethod, arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_DigestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, set_DigestMethod, arginfo_TElOfficeOpenXMLBaseSignatureHandler_set_DigestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, get_SignedPartCount, arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_SignedPartCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, get_SignedParts, arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_SignedParts, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, get_Certificates, arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_Certificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, get_SignerCertificate, arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_SignerCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, get_SignerKeyData, arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_SignerKeyData, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, get_SignatureTime, arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_SignatureTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, get_XAdESProcessor, arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_XAdESProcessor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, set_XAdESProcessor, arginfo_TElOfficeOpenXMLBaseSignatureHandler_set_XAdESProcessor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, get_OwnXAdESProcessor, arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_OwnXAdESProcessor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, set_OwnXAdESProcessor, arginfo_TElOfficeOpenXMLBaseSignatureHandler_set_OwnXAdESProcessor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, get_OnPrepareSignature, arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_OnPrepareSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, set_OnPrepareSignature, arginfo_TElOfficeOpenXMLBaseSignatureHandler_set_OnPrepareSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, get_OnBeforeSign, arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_OnBeforeSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, set_OnBeforeSign, arginfo_TElOfficeOpenXMLBaseSignatureHandler_set_OnBeforeSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, get_OnAfterSign, arginfo_TElOfficeOpenXMLBaseSignatureHandler_get_OnAfterSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, set_OnAfterSign, arginfo_TElOfficeOpenXMLBaseSignatureHandler_set_OnAfterSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLBaseSignatureHandler, __construct, arginfo_TElOfficeOpenXMLBaseSignatureHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeOpenXMLBaseSignatureHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeOpenXMLBaseSignatureHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeOpenXMLBaseSignatureHandler", TElOfficeOpenXMLBaseSignatureHandler_methods);
	if (NULL == TElOfficeOpenXMLCustomSignatureHandler_ce_ptr)
		Register_TElOfficeOpenXMLCustomSignatureHandler(TSRMLS_C);
	TElOfficeOpenXMLBaseSignatureHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeOpenXMLCustomSignatureHandler_ce_ptr);
}

zend_class_entry *TElOfficeOpenXMLSignatureHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeOpenXMLSignatureHandler, GetName_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXMLSignatureHandler_GetName_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1887156877, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignatureHandler, GetName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXMLSignatureHandler_GetName(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1887156877, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignatureHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLSignatureHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignatureHandler, AddCoreProperties)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLSignatureHandler_AddCoreProperties(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignatureHandler, AddDocument)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXMLSignatureHandler_AddDocument(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignatureHandler, IsCorePropertiesSigned)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLSignatureHandler_IsCorePropertiesSigned(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignatureHandler, IsDocumentSigned)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXMLSignatureHandler_IsDocumentSigned(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignatureHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLSignatureHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignatureHandler, get_SignatureInfoV1)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLSignatureHandler_get_SignatureInfoV1(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeXMLSignatureInfoV1_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignatureHandler, get_SignatureLine)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLSignatureHandler_get_SignatureLine(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeOpenXMLSignatureLine_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXMLSignatureHandler, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXMLSignatureHandler_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignatureHandler_GetName_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignatureHandler_GetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignatureHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignatureHandler_AddCoreProperties, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignatureHandler_AddDocument, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignatureHandler_IsCorePropertiesSigned, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignatureHandler_IsDocumentSigned, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignatureHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignatureHandler_get_SignatureInfoV1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignatureHandler_get_SignatureLine, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXMLSignatureHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeOpenXMLSignatureHandler_methods[] = {
	PHP_ME(TElOfficeOpenXMLSignatureHandler, GetName_Inst, arginfo_TElOfficeOpenXMLSignatureHandler_GetName_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignatureHandler, GetName, arginfo_TElOfficeOpenXMLSignatureHandler_GetName, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeOpenXMLSignatureHandler, Reset, arginfo_TElOfficeOpenXMLSignatureHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignatureHandler, AddCoreProperties, arginfo_TElOfficeOpenXMLSignatureHandler_AddCoreProperties, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignatureHandler, AddDocument, arginfo_TElOfficeOpenXMLSignatureHandler_AddDocument, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignatureHandler, IsCorePropertiesSigned, arginfo_TElOfficeOpenXMLSignatureHandler_IsCorePropertiesSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignatureHandler, IsDocumentSigned, arginfo_TElOfficeOpenXMLSignatureHandler_IsDocumentSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignatureHandler, ClassType, arginfo_TElOfficeOpenXMLSignatureHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeOpenXMLSignatureHandler, get_SignatureInfoV1, arginfo_TElOfficeOpenXMLSignatureHandler_get_SignatureInfoV1, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignatureHandler, get_SignatureLine, arginfo_TElOfficeOpenXMLSignatureHandler_get_SignatureLine, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXMLSignatureHandler, __construct, arginfo_TElOfficeOpenXMLSignatureHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeOpenXMLSignatureHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeOpenXMLSignatureHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeOpenXMLSignatureHandler", TElOfficeOpenXMLSignatureHandler_methods);
	if (NULL == TElOfficeOpenXMLBaseSignatureHandler_ce_ptr)
		Register_TElOfficeOpenXMLBaseSignatureHandler(TSRMLS_C);
	TElOfficeOpenXMLSignatureHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeOpenXMLBaseSignatureHandler_ce_ptr);
}

zend_class_entry *TElOfficeOpenXPSSignatureHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElOfficeOpenXPSSignatureHandler, GetName_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXPSSignatureHandler_GetName_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-775433155, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXPSSignatureHandler, GetName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOfficeOpenXPSSignatureHandler_GetName(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-775433155, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXPSSignatureHandler, AddCoreProperties)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXPSSignatureHandler_AddCoreProperties(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXPSSignatureHandler, AddDocument)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXPSSignatureHandler_AddDocument(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXPSSignatureHandler, AddSignatureOrigin)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOfficeOpenXPSSignatureHandler_AddSignatureOrigin(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXPSSignatureHandler, IsCorePropertiesSigned)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXPSSignatureHandler_IsCorePropertiesSigned(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXPSSignatureHandler, IsDocumentSigned)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXPSSignatureHandler_IsDocumentSigned(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXPSSignatureHandler, IsSignatureOriginSigned)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOfficeOpenXPSSignatureHandler_IsSignatureOriginSigned(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXPSSignatureHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXPSSignatureHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXPSSignatureHandler, get_SignatureDefinition)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXPSSignatureHandler_get_SignatureDefinition(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeOpenXPSSignatureDefinition_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOfficeOpenXPSSignatureHandler, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOfficeOpenXPSSignatureHandler_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXPSSignatureHandler_GetName_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXPSSignatureHandler_GetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXPSSignatureHandler_AddCoreProperties, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXPSSignatureHandler_AddDocument, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXPSSignatureHandler_AddSignatureOrigin, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXPSSignatureHandler_IsCorePropertiesSigned, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXPSSignatureHandler_IsDocumentSigned, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXPSSignatureHandler_IsSignatureOriginSigned, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXPSSignatureHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXPSSignatureHandler_get_SignatureDefinition, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOfficeOpenXPSSignatureHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOfficeOpenXPSSignatureHandler_methods[] = {
	PHP_ME(TElOfficeOpenXPSSignatureHandler, GetName_Inst, arginfo_TElOfficeOpenXPSSignatureHandler_GetName_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXPSSignatureHandler, GetName, arginfo_TElOfficeOpenXPSSignatureHandler_GetName, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeOpenXPSSignatureHandler, AddCoreProperties, arginfo_TElOfficeOpenXPSSignatureHandler_AddCoreProperties, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXPSSignatureHandler, AddDocument, arginfo_TElOfficeOpenXPSSignatureHandler_AddDocument, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXPSSignatureHandler, AddSignatureOrigin, arginfo_TElOfficeOpenXPSSignatureHandler_AddSignatureOrigin, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXPSSignatureHandler, IsCorePropertiesSigned, arginfo_TElOfficeOpenXPSSignatureHandler_IsCorePropertiesSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXPSSignatureHandler, IsDocumentSigned, arginfo_TElOfficeOpenXPSSignatureHandler_IsDocumentSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXPSSignatureHandler, IsSignatureOriginSigned, arginfo_TElOfficeOpenXPSSignatureHandler_IsSignatureOriginSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXPSSignatureHandler, ClassType, arginfo_TElOfficeOpenXPSSignatureHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOfficeOpenXPSSignatureHandler, get_SignatureDefinition, arginfo_TElOfficeOpenXPSSignatureHandler_get_SignatureDefinition, ZEND_ACC_PUBLIC)
	PHP_ME(TElOfficeOpenXPSSignatureHandler, __construct, arginfo_TElOfficeOpenXPSSignatureHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOfficeOpenXPSSignatureHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOfficeOpenXPSSignatureHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOfficeOpenXPSSignatureHandler", TElOfficeOpenXPSSignatureHandler_methods);
	if (NULL == TElOfficeOpenXMLBaseSignatureHandler_ce_ptr)
		Register_TElOfficeOpenXMLBaseSignatureHandler(TSRMLS_C);
	TElOfficeOpenXPSSignatureHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOfficeOpenXMLBaseSignatureHandler_ce_ptr);
}

zend_class_entry *TElOpenOfficeSignedEntry_ce_ptr = NULL;

SB_PHP_METHOD(TElOpenOfficeSignedEntry, get_DigestMethod)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElXMLDigestMethodRaw fOutResultRaw = 0;
		SBCheckError(TElOpenOfficeSignedEntry_get_DigestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignedEntry, set_DigestMethod)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignedEntry_set_DigestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), (TElXMLDigestMethodRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignedEntry, get_DigestValue)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElOpenOfficeSignedEntry_get_DigestValue(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1106117697, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignedEntry, set_DigestValue)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOpenOfficeSignedEntry_set_DigestValue(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignedEntry, get_Path)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOpenOfficeSignedEntry_get_Path(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1689337962, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignedEntry, get_ValidationStatus)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOpenOfficeEntryValidationStatusRaw fOutResultRaw = 0;
		SBCheckError(TElOpenOfficeSignedEntry_get_ValidationStatus(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignedEntry, __construct)
{
	char *sAPath;
	sb_str_size sAPath_len;
	zval *oHandler;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oHandler, TElOpenOfficeCustomSignatureHandler_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignedEntry_Create(SBGetObjectHandle(oHandler TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!s", &oHandler, TElOpenOfficeCustomSignatureHandler_ce_ptr, &sAPath, &sAPath_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignedEntry_Create_1(SBGetObjectHandle(oHandler TSRMLS_CC), sAPath, (int32_t)sAPath_len, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOpenOfficeCustomSignatureHandler) or (\\TElOpenOfficeCustomSignatureHandler, string)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignedEntry_get_DigestMethod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignedEntry_set_DigestMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignedEntry_get_DigestValue, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignedEntry_set_DigestValue, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignedEntry_get_Path, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignedEntry_get_ValidationStatus, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignedEntry___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElOpenOfficeCustomSignatureHandler, 1)
	ZEND_ARG_INFO(0, APath)
ZEND_END_ARG_INFO()

static zend_function_entry TElOpenOfficeSignedEntry_methods[] = {
	PHP_ME(TElOpenOfficeSignedEntry, get_DigestMethod, arginfo_TElOpenOfficeSignedEntry_get_DigestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignedEntry, set_DigestMethod, arginfo_TElOpenOfficeSignedEntry_set_DigestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignedEntry, get_DigestValue, arginfo_TElOpenOfficeSignedEntry_get_DigestValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignedEntry, set_DigestValue, arginfo_TElOpenOfficeSignedEntry_set_DigestValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignedEntry, get_Path, arginfo_TElOpenOfficeSignedEntry_get_Path, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignedEntry, get_ValidationStatus, arginfo_TElOpenOfficeSignedEntry_get_ValidationStatus, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignedEntry, __construct, arginfo_TElOpenOfficeSignedEntry___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOpenOfficeSignedEntry(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOpenOfficeSignedEntry_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOpenOfficeSignedEntry", TElOpenOfficeSignedEntry_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElOpenOfficeSignedEntry_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElOpenOfficeSignatureHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, GetName_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOpenOfficeSignatureHandler_GetName_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(32430979, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, GetName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElOpenOfficeSignatureHandler_GetName(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(32430979, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, Sign)
{
	sb_zend_long fSignatureMethod;
	zend_bool bIncludeKey;
	zval *oCertificate;
	zval *oCertStorage;
	zval *oKeyData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_Sign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertStorage, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_Sign_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lb", &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bIncludeKey) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_Sign_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bIncludeKey) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate) or (\\TElCustomCertStorage) or (\\TElXMLKeyInfoData, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, Validate)
{
	zval *oCertificate;
	zval *oKeyData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOpenOfficeSignatureValidationStatusRaw fOutResultRaw = 0;
		SBCheckError(TElOpenOfficeSignatureHandler_Validate(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		TSBOpenOfficeSignatureValidationStatusRaw fOutResultRaw = 0;
		SBCheckError(TElOpenOfficeSignatureHandler_Validate_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oKeyData, TElXMLKeyInfoData_ce_ptr) == SUCCESS)
	{
		TSBOpenOfficeSignatureValidationStatusRaw fOutResultRaw = 0;
		SBCheckError(TElOpenOfficeSignatureHandler_Validate_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElX509Certificate) or (\\TElXMLKeyInfoData)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, GenerateXAdES)
{
	sb_zend_long fXAdESForm;
	zval *oSigningCertificate;
	zval *oTSPClient;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &fXAdESForm, &oSigningCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_GenerateXAdES(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBXAdESFormRaw)fXAdESForm, SBGetObjectHandle(oSigningCertificate TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!O!", &fXAdESForm, &oSigningCertificate, TElX509Certificate_ce_ptr, &oTSPClient, TElCustomTSPClient_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_GenerateXAdES_1(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBXAdESFormRaw)fXAdESForm, SBGetObjectHandle(oSigningCertificate TSRMLS_CC), SBGetObjectHandle(oTSPClient TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElX509Certificate) or (integer, \\TElX509Certificate, \\TElCustomTSPClient)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, InitiateAsyncSign)
{
	sb_zend_long fSignatureMethod;
	SBArrayZValInfo aiAdditionalData;
	zend_bool bIncludeKey;
	zval *oCertificate;
	zval *oCertStorage;
	zval *oKeyData;
	zval *oPars;
	zval *zaAdditionalData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCertStorage, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lb", &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bIncludeKey) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bIncludeKey, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oPars, TElDCParameters_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_4(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oPars, TElDCParameters_ce_ptr, &oCertificate, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_5(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oPars, TElDCParameters_ce_ptr, &oCertStorage, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_6(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!lb", &oPars, TElDCParameters_ce_ptr, &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bIncludeKey) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_7(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bIncludeKey, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_8(SBGetObjectHandle(getThis() TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oCertificate, TElX509Certificate_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_9(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oCertStorage, TElCustomCertStorage_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_10(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!lbz", &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bIncludeKey, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_11(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bIncludeKey, aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oPars, TElDCParameters_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_12(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!z", &oPars, TElDCParameters_ce_ptr, &oCertificate, TElX509Certificate_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_13(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!z", &oPars, TElDCParameters_ce_ptr, &oCertStorage, TElCustomCertStorage_ce_ptr, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_14(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oCertStorage TSRMLS_CC), aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!lbz", &oPars, TElDCParameters_ce_ptr, &oKeyData, TElXMLKeyInfoData_ce_ptr, &fSignatureMethod, &bIncludeKey, &zaAdditionalData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAdditionalData) || SB_IS_ARRAY_TYPE_RP(zaAdditionalData) || SB_IS_NULL_TYPE_RP(zaAdditionalData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaAdditionalData, &aiAdditionalData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElOpenOfficeSignatureHandler_InitiateAsyncSign_15(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), SBGetObjectHandle(oKeyData TSRMLS_CC), (TElXMLSignatureMethodRaw)fSignatureMethod, (int8_t)bIncludeKey, aiAdditionalData.data, aiAdditionalData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAdditionalData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElX509Certificate) or (\\TElCustomCertStorage) or (\\TElXMLKeyInfoData, integer, bool) or (\\TElDCParameters) or (\\TElDCParameters, \\TElX509Certificate) or (\\TElDCParameters, \\TElCustomCertStorage) or (\\TElDCParameters, \\TElXMLKeyInfoData, integer, bool) or (array of byte|string|NULL) or (\\TElX509Certificate, array of byte|string|NULL) or (\\TElCustomCertStorage, array of byte|string|NULL) or (\\TElXMLKeyInfoData, integer, bool, array of byte|string|NULL) or (\\TElDCParameters, array of byte|string|NULL) or (\\TElDCParameters, \\TElX509Certificate, array of byte|string|NULL) or (\\TElDCParameters, \\TElCustomCertStorage, array of byte|string|NULL) or (\\TElDCParameters, \\TElXMLKeyInfoData, integer, bool, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, CompleteAsyncSign)
{
	zend_bool bEmbedCertificate;
	zval *oCertificate;
	zval *oState;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oState, TElDCAsyncState_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_CompleteAsyncSign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oState TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!b", &oState, TElDCAsyncState_ce_ptr, &oCertificate, TElX509Certificate_ce_ptr, &bEmbedCertificate) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_CompleteAsyncSign_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oState TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (int8_t)bEmbedCertificate) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDCAsyncState) or (\\TElDCAsyncState, \\TElX509Certificate, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, UpdateSignature)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_UpdateSignature(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, AddSignedEntry)
{
	char *sPath;
	sb_str_size sPath_len;
	zval *oEntry;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oEntry, TElOpenOfficeSignedEntry_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOpenOfficeSignatureHandler_AddSignedEntry(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oEntry TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOpenOfficeSignatureHandler_AddSignedEntry_1(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOpenOfficeSignedEntry) or (string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, InsertSignedEntry)
{
	sb_zend_long l4Index;
	zval *oEntry;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Index, &oEntry, TElOpenOfficeSignedEntry_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_InsertSignedEntry(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, SBGetObjectHandle(oEntry TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElOpenOfficeSignedEntry)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, DeleteSignedEntry)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_DeleteSignedEntry(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, GetSignedEntryByPath)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_GetSignedEntryByPath(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOpenOfficeSignedEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, AddDocument)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_AddDocument(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, IsDocumentSigned)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOpenOfficeSignatureHandler_IsDocumentSigned(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, get_DigestMethod)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElXMLDigestMethodRaw fOutResultRaw = 0;
		SBCheckError(TElOpenOfficeSignatureHandler_get_DigestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, set_DigestMethod)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_set_DigestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), (TElXMLDigestMethodRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, get_SignedEntryCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElOpenOfficeSignatureHandler_get_SignedEntryCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, get_SignedEntries)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_get_SignedEntries(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOpenOfficeSignedEntry_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, get_Certificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_get_Certificates(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, get_SignerCertificate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_get_SignerCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, get_SignerKeyData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_get_SignerKeyData(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLKeyInfoData_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, get_SignatureTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_get_SignatureTime(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOfficeXMLDCDate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, get_XAdESProcessor)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_get_XAdESProcessor(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXAdESProcessor_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, set_XAdESProcessor)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElXAdESProcessor_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_set_XAdESProcessor(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXAdESProcessor)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, get_OwnXAdESProcessor)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElOpenOfficeSignatureHandler_get_OwnXAdESProcessor(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, set_OwnXAdESProcessor)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElOpenOfficeSignatureHandler_set_OwnXAdESProcessor(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, get_OnPrepareSignature)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeXMLSignEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_get_OnPrepareSignature(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, set_OnPrepareSignature)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElOpenOfficeSignatureHandler_set_OnPrepareSignature(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBOfficeXMLSignEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOfficeXMLSignEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, get_OnBeforeSign)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeXMLSignEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_get_OnBeforeSign(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, set_OnBeforeSign)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElOpenOfficeSignatureHandler_set_OnBeforeSign(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBOfficeXMLSignEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOfficeXMLSignEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, get_OnAfterSign)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOfficeXMLSignEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_get_OnAfterSign(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, set_OnAfterSign)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElOpenOfficeSignatureHandler_set_OnAfterSign(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBOfficeXMLSignEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOfficeXMLSignEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElOpenOfficeSignatureHandler, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElOpenOfficeSignatureHandler_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_GetName_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_GetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_Sign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Certificate_or_CertStorage_or_KeyData, 0, 1)
	ZEND_ARG_INFO(0, SignatureMethod)
	ZEND_ARG_INFO(0, IncludeKey)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_Validate, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, Certificate_or_KeyData, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_GenerateXAdES, 0, 0, 2)
	ZEND_ARG_INFO(0, XAdESForm)
	ZEND_ARG_OBJ_INFO(0, SigningCertificate, TElX509Certificate, 1)
	ZEND_ARG_OBJ_INFO(0, TSPClient, TElCustomTSPClient, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_InitiateAsyncSign, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, Certificate_or_CertStorage_or_KeyData_or_Pars_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, SignatureMethod_or_Certificate_or_CertStorage_or_KeyData_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, IncludeKey_or_SignatureMethod_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, IncludeKey_or_AdditionalData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AdditionalData, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_CompleteAsyncSign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, State, TElDCAsyncState, 1)
	ZEND_ARG_OBJ_INFO(0, Certificate, TElX509Certificate, 1)
	ZEND_ARG_INFO(0, EmbedCertificate)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_UpdateSignature, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_AddSignedEntry, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Entry_or_Path, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_InsertSignedEntry, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_OBJ_INFO(0, Entry, TElOpenOfficeSignedEntry, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_DeleteSignedEntry, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_GetSignedEntryByPath, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_AddDocument, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_IsDocumentSigned, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_get_DigestMethod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_set_DigestMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_get_SignedEntryCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_get_SignedEntries, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_get_Certificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_get_SignerCertificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_get_SignerKeyData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_get_SignatureTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_get_XAdESProcessor, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_set_XAdESProcessor, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElXAdESProcessor, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_get_OwnXAdESProcessor, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_set_OwnXAdESProcessor, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_get_OnPrepareSignature, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_set_OnPrepareSignature, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_get_OnBeforeSign, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_set_OnBeforeSign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_get_OnAfterSign, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler_set_OnAfterSign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElOpenOfficeSignatureHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElOpenOfficeSignatureHandler_methods[] = {
	PHP_ME(TElOpenOfficeSignatureHandler, GetName_Inst, arginfo_TElOpenOfficeSignatureHandler_GetName_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, GetName, arginfo_TElOpenOfficeSignatureHandler_GetName, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOpenOfficeSignatureHandler, Reset, arginfo_TElOpenOfficeSignatureHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, Sign, arginfo_TElOpenOfficeSignatureHandler_Sign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, Validate, arginfo_TElOpenOfficeSignatureHandler_Validate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, GenerateXAdES, arginfo_TElOpenOfficeSignatureHandler_GenerateXAdES, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, InitiateAsyncSign, arginfo_TElOpenOfficeSignatureHandler_InitiateAsyncSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, CompleteAsyncSign, arginfo_TElOpenOfficeSignatureHandler_CompleteAsyncSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, UpdateSignature, arginfo_TElOpenOfficeSignatureHandler_UpdateSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, AddSignedEntry, arginfo_TElOpenOfficeSignatureHandler_AddSignedEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, InsertSignedEntry, arginfo_TElOpenOfficeSignatureHandler_InsertSignedEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, DeleteSignedEntry, arginfo_TElOpenOfficeSignatureHandler_DeleteSignedEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, GetSignedEntryByPath, arginfo_TElOpenOfficeSignatureHandler_GetSignedEntryByPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, AddDocument, arginfo_TElOpenOfficeSignatureHandler_AddDocument, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, IsDocumentSigned, arginfo_TElOpenOfficeSignatureHandler_IsDocumentSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, ClassType, arginfo_TElOpenOfficeSignatureHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElOpenOfficeSignatureHandler, get_DigestMethod, arginfo_TElOpenOfficeSignatureHandler_get_DigestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, set_DigestMethod, arginfo_TElOpenOfficeSignatureHandler_set_DigestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, get_SignedEntryCount, arginfo_TElOpenOfficeSignatureHandler_get_SignedEntryCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, get_SignedEntries, arginfo_TElOpenOfficeSignatureHandler_get_SignedEntries, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, get_Certificates, arginfo_TElOpenOfficeSignatureHandler_get_Certificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, get_SignerCertificate, arginfo_TElOpenOfficeSignatureHandler_get_SignerCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, get_SignerKeyData, arginfo_TElOpenOfficeSignatureHandler_get_SignerKeyData, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, get_SignatureTime, arginfo_TElOpenOfficeSignatureHandler_get_SignatureTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, get_XAdESProcessor, arginfo_TElOpenOfficeSignatureHandler_get_XAdESProcessor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, set_XAdESProcessor, arginfo_TElOpenOfficeSignatureHandler_set_XAdESProcessor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, get_OwnXAdESProcessor, arginfo_TElOpenOfficeSignatureHandler_get_OwnXAdESProcessor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, set_OwnXAdESProcessor, arginfo_TElOpenOfficeSignatureHandler_set_OwnXAdESProcessor, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, get_OnPrepareSignature, arginfo_TElOpenOfficeSignatureHandler_get_OnPrepareSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, set_OnPrepareSignature, arginfo_TElOpenOfficeSignatureHandler_set_OnPrepareSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, get_OnBeforeSign, arginfo_TElOpenOfficeSignatureHandler_get_OnBeforeSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, set_OnBeforeSign, arginfo_TElOpenOfficeSignatureHandler_set_OnBeforeSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, get_OnAfterSign, arginfo_TElOpenOfficeSignatureHandler_get_OnAfterSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, set_OnAfterSign, arginfo_TElOpenOfficeSignatureHandler_set_OnAfterSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElOpenOfficeSignatureHandler, __construct, arginfo_TElOpenOfficeSignatureHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElOpenOfficeSignatureHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElOpenOfficeSignatureHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElOpenOfficeSignatureHandler", TElOpenOfficeSignatureHandler_methods);
	if (NULL == TElOpenOfficeCustomSignatureHandler_ce_ptr)
		Register_TElOpenOfficeCustomSignatureHandler(TSRMLS_C);
	TElOpenOfficeSignatureHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElOpenOfficeCustomSignatureHandler_ce_ptr);
}

void Register_SBOfficeSecurity_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_STRING_CONSTANT(SBOfficeSecurity, MS_BASE_PROV, SB_MS_BASE_PROV, SB_MS_BASE_PROV);
	SB_REGISTER_STRING_CONSTANT(SBOfficeSecurity, MS_STRONG_PROV, SB_MS_STRONG_PROV, SB_MS_STRONG_PROV);
	SB_REGISTER_STRING_CONSTANT(SBOfficeSecurity, MS_ENH_PROV, SB_MS_ENH_PROV, SB_MS_ENH_PROV);
	SB_REGISTER_STRING_CONSTANT(SBOfficeSecurity, MS_ENH_RSA_AES_PROV, SB_MS_ENH_RSA_AES_PROV, SB_MS_ENH_RSA_AES_PROV);
	SB_REGISTER_STRING_CONSTANT(SBOfficeSecurity, MS_ENH_RSA_AES_PROV_XP, SB_MS_ENH_RSA_AES_PROV_XP, SB_MS_ENH_RSA_AES_PROV_XP);
	SB_REGISTER_LONG_CONSTANT(SBOfficeSecurity, MS_ALGORITHM_AES128, SB_MS_ALGORITHM_AES128, SB_MS_ALGORITHM_AES128);
	SB_REGISTER_LONG_CONSTANT(SBOfficeSecurity, MS_ALGORITHM_AES192, SB_MS_ALGORITHM_AES192, SB_MS_ALGORITHM_AES192);
	SB_REGISTER_LONG_CONSTANT(SBOfficeSecurity, MS_ALGORITHM_AES256, SB_MS_ALGORITHM_AES256, SB_MS_ALGORITHM_AES256);
	SB_REGISTER_LONG_CONSTANT(SBOfficeSecurity, MS_ALGORITHM_RC4, SB_MS_ALGORITHM_RC4, SB_MS_ALGORITHM_RC4);
	SB_REGISTER_LONG_CONSTANT(SBOfficeSecurity, MS_ALGORITHM_DGST_MD5, SB_MS_ALGORITHM_DGST_MD5, SB_MS_ALGORITHM_DGST_MD5);
	SB_REGISTER_LONG_CONSTANT(SBOfficeSecurity, MS_ALGORITHM_DGST_SHA1, SB_MS_ALGORITHM_DGST_SHA1, SB_MS_ALGORITHM_DGST_SHA1);
	SB_REGISTER_LONG_CONSTANT(SBOfficeSecurity, MS_PROVIDER_TYPE_1, SB_MS_PROVIDER_TYPE_1, SB_MS_PROVIDER_TYPE_1);
	SB_REGISTER_LONG_CONSTANT(SBOfficeSecurity, MS_PROVIDER_TYPE_AES, SB_MS_PROVIDER_TYPE_AES, SB_MS_PROVIDER_TYPE_AES);
}

void Register_SBOfficeSecurity_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBOfficeBinaryEntryValidationStatus", NULL);
	TSBOfficeBinaryEntryValidationStatus_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBOfficeBinaryEntryValidationStatus_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeBinaryEntryValidationStatus_ce_ptr, "bevsUnknown", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeBinaryEntryValidationStatus_ce_ptr, "bevsValid", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeBinaryEntryValidationStatus_ce_ptr, "bevsInvalidSignature", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeBinaryEntryValidationStatus_ce_ptr, "bevsInvalidDigest", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeBinaryEntryValidationStatus_ce_ptr, "bevsEntryIsMissing", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeBinaryEntryValidationStatus_ce_ptr, "bevsEntryNotSigned", 5)
	
	INIT_CLASS_ENTRY(ce, "TSBOfficeBinarySignatureValidationStatus", NULL);
	TSBOfficeBinarySignatureValidationStatus_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBOfficeBinarySignatureValidationStatus_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeBinarySignatureValidationStatus_ce_ptr, "bsvsUnknown", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeBinarySignatureValidationStatus_ce_ptr, "bsvsValid", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeBinarySignatureValidationStatus_ce_ptr, "bsvsValidButNotEntries", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeBinarySignatureValidationStatus_ce_ptr, "bsvsInvalidSignature", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeBinarySignatureValidationStatus_ce_ptr, "bsvsNoCertificate", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeBinarySignatureValidationStatus_ce_ptr, "bsvsInvalidPackageObjectReferenceDigest", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeBinarySignatureValidationStatus_ce_ptr, "bsvsInvalidApplicationObjectReferenceDigest", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeBinarySignatureValidationStatus_ce_ptr, "bsvsInvalidReferenceDigest", 7)
	
	INIT_CLASS_ENTRY(ce, "TSBOfficeOpenXMLPartValidationStatus", NULL);
	TSBOfficeOpenXMLPartValidationStatus_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBOfficeOpenXMLPartValidationStatus_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLPartValidationStatus_ce_ptr, "pvsUnknown", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLPartValidationStatus_ce_ptr, "pvsValid", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLPartValidationStatus_ce_ptr, "pvsInvalidSignature", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLPartValidationStatus_ce_ptr, "pvsInvalidDigest", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLPartValidationStatus_ce_ptr, "pvsInvalidContentType", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLPartValidationStatus_ce_ptr, "pvsPartIsMissing", 5)
	
	INIT_CLASS_ENTRY(ce, "TSBOfficeOpenXMLSignatureValidationStatus", NULL);
	TSBOfficeOpenXMLSignatureValidationStatus_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBOfficeOpenXMLSignatureValidationStatus_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLSignatureValidationStatus_ce_ptr, "svsUnknown", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLSignatureValidationStatus_ce_ptr, "svsValid", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLSignatureValidationStatus_ce_ptr, "svsValidButNotParts", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLSignatureValidationStatus_ce_ptr, "svsInvalidSignature", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLSignatureValidationStatus_ce_ptr, "svsNoCertificate", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLSignatureValidationStatus_ce_ptr, "svsInvalidPackageObjectReferenceDigest", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLSignatureValidationStatus_ce_ptr, "svsInvalidApplicationObjectReferenceDigest", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLSignatureValidationStatus_ce_ptr, "svsInvalidReferenceDigest", 7)
	
	INIT_CLASS_ENTRY(ce, "TSBOfficeOpenXMLEmbedCertificate", NULL);
	TSBOfficeOpenXMLEmbedCertificate_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBOfficeOpenXMLEmbedCertificate_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLEmbedCertificate_ce_ptr, "ecInSignature", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLEmbedCertificate_ce_ptr, "ecInCertificatePart", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLEmbedCertificate_ce_ptr, "ecInSignedCertificatePart", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBOfficeOpenXMLEmbedCertificate_ce_ptr, "ecNone", 3)
	
	INIT_CLASS_ENTRY(ce, "TSBOpenOfficeEntryValidationStatus", NULL);
	TSBOpenOfficeEntryValidationStatus_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBOpenOfficeEntryValidationStatus_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBOpenOfficeEntryValidationStatus_ce_ptr, "oevsUnknown", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBOpenOfficeEntryValidationStatus_ce_ptr, "oevsValid", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBOpenOfficeEntryValidationStatus_ce_ptr, "oevsInvalidSignature", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBOpenOfficeEntryValidationStatus_ce_ptr, "oevsInvalidDigest", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBOpenOfficeEntryValidationStatus_ce_ptr, "oevsEntryIsMissing", 4)
	
	INIT_CLASS_ENTRY(ce, "TSBOpenOfficeSignatureValidationStatus", NULL);
	TSBOpenOfficeSignatureValidationStatus_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBOpenOfficeSignatureValidationStatus_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBOpenOfficeSignatureValidationStatus_ce_ptr, "osvsUnknown", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBOpenOfficeSignatureValidationStatus_ce_ptr, "osvsValid", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBOpenOfficeSignatureValidationStatus_ce_ptr, "osvsValidButNotEntries", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBOpenOfficeSignatureValidationStatus_ce_ptr, "osvsInvalidSignature", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBOpenOfficeSignatureValidationStatus_ce_ptr, "osvsNoCertificate", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBOpenOfficeSignatureValidationStatus_ce_ptr, "osvsInvalidReferenceDigest", 5)
}

