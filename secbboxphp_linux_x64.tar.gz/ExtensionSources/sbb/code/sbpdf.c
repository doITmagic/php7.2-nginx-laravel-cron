#include "sbpdf.h"

zend_class_entry *TSBPDFSignatureType_ce_ptr = NULL;

zend_class_entry *TSBPDFTransformMethod_ce_ptr = NULL;

zend_class_entry *TSBPDFDigestMethod_ce_ptr = NULL;

zend_class_entry *TSBPDFFieldMDPAction_ce_ptr = NULL;

zend_class_entry *TSBPDFDecryptionMode_ce_ptr = NULL;

zend_class_entry *TSBPDFSignatureRemoveOption_ce_ptr = NULL;

zend_class_entry *TSBPDFImageType_ce_ptr = NULL;

zend_class_entry *TSBPDFColorSpaceType_ce_ptr = NULL;

zend_class_entry *TSBPDFStandardType1Font_ce_ptr = NULL;

zend_class_entry *TSBPDFWidgetBackgroundStyle_ce_ptr = NULL;

void SB_CALLBACK TSBPDFConvertStringToAnsiEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcStr, int32_t szStr, uint8_t pOutResult[], int32_t * szOutResult)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zStr;
	SB_EVENT_DECL_RETVAL_PTR(pzOutResult);
	SBArrayZValInfo aiOutResult;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zStr, 1);
	SB_ZVAL_STRINGL_DUP(zStr, pcStr, szStr);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(pzOutResult), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zStr);
	if (pzOutResult)
	{
		if (SBGetByteArrayFromZVal(pzOutResult, &aiOutResult TSRMLS_CC))
			SBCheckError(SBSetEventReturnBuffer(3, aiOutResult.data, aiOutResult.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiOutResult);
		SB_EVENT_CLEAR_ZVAL(pzOutResult);
	}
}

void SB_CALLBACK TSBPDFLookupGlyphNameEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t UCS, char * pcOutResult, int32_t * szOutResult)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zUCS;
	SB_EVENT_DECL_RETVAL_PTR(pzOutResult);
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zUCS, 1);
	ZVAL_LONG(zUCS, (sb_zend_long)UCS);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(pzOutResult), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zUCS);
	if (pzOutResult)
	{
		convert_to_string(pzOutResult);
		SBCheckError(SBSetEventReturnStringA(3, Z_STRVAL_P(pzOutResult), (int32_t)Z_STRLEN_P(pzOutResult)) TSRMLS_CC);
		SB_EVENT_CLEAR_ZVAL(pzOutResult);
	}
}

void SB_CALLBACK TSBPDFLookupGlyphWidthEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t UCS, int32_t * Width)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zUCS;
	zval * zWidth;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zUCS, 1);
	ZVAL_LONG(zUCS, (sb_zend_long)UCS);
	SB_EVENT_INIT_ZVAL_REF(zWidth, 2);
	ZVAL_LONG(Z_REFVAL_P(zWidth), (sb_zend_long)*Width);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zUCS);
	convert_to_long(Z_REFVAL_P(zWidth));
	*Width = (int32_t)Z_LVAL_P(Z_REFVAL_P(zWidth));
	SB_EVENT_CLEAR_ZVAL(zWidth);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSBPDFSignatureAllowedChange_ce_ptr = NULL;

zend_class_entry *TSBPDFSignatureAllowedChanges_ce_ptr = NULL;

zend_class_entry *TSBPDFSignatureOption_ce_ptr = NULL;

zend_class_entry *TSBPDFSignatureOptions_ce_ptr = NULL;

zend_class_entry *TSBSVDConstraint_ce_ptr = NULL;

zend_class_entry *TSBSVDConstraints_ce_ptr = NULL;

zend_class_entry *TSBPDFFieldFlag_ce_ptr = NULL;

zend_class_entry *TSBPDFFieldFlags_ce_ptr = NULL;

zend_class_entry *TSBPDFSecurityHandlerEncryptionMethod_ce_ptr = NULL;

zend_class_entry *TSBPDFEncryptionSubject_ce_ptr = NULL;

zend_class_entry *TElPDFSecurityHandlerClass_ce_ptr = NULL;

zend_class_entry *TElPDFEncodingHandlerClass_ce_ptr = NULL;

zend_class_entry *TSBPDFAssociatedFileRelationship_ce_ptr = NULL;

zend_class_entry *TSBPDFAssemblyOption_ce_ptr = NULL;

zend_class_entry *TSBPDFAssemblyOptions_ce_ptr = NULL;

void SB_CALLBACK TSBPDFBeforeSignEventRaw(void * _ObjectData, TObjectHandle Sender, TElPDFSignatureHandle Signature)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zSignature;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSignature, 1);
	SBInitObject(zSignature, TElPDFSignature_ce_ptr, Signature TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSignature);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElPDFDocument_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFDocument, ExtractAdditionalDataFromAsyncState_Inst)
{
	uint32_t _err;
	zval *oHandler;
	zval *oState;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oHandler, TElPDFSecurityHandler_ce_ptr, &oState, TElDCAsyncState_ce_ptr) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPDFDocument_ExtractAdditionalDataFromAsyncState_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oHandler TSRMLS_CC), SBGetObjectHandle(oState TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-906567016, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFSecurityHandler, \\TElDCAsyncState)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, ExtractAdditionalDataFromAsyncState)
{
	uint32_t _err;
	zval *oHandler;
	zval *oState;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oHandler, TElPDFSecurityHandler_ce_ptr, &oState, TElDCAsyncState_ce_ptr) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPDFDocument_ExtractAdditionalDataFromAsyncState(SBGetObjectHandle(oHandler TSRMLS_CC), SBGetObjectHandle(oState TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-906567016, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFSecurityHandler, \\TElDCAsyncState)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, Open)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_Open(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, Close)
{
	zend_bool bSave;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bSave) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_Close(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bSave) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, Encrypt)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFDocument_Encrypt(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, SignAndEncrypt)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFDocument_SignAndEncrypt(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, Decrypt)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFDocument_Decrypt(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, AddSignature)
{
	sb_zend_long l4EmptySignatureField;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFDocument_AddSignature(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4EmptySignatureField) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFDocument_AddSignature_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4EmptySignatureField, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, InsertSignature)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_InsertSignature(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFSignature_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, ClearSignatures)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFDocument_ClearSignatures(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, RemoveSignature)
{
	sb_zend_long fSigRemoveOption;
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_RemoveSignature(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4Index, &fSigRemoveOption) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_RemoveSignature_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (TSBPDFSignatureRemoveOptionRaw)fSigRemoveOption) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer) or (integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, RemoveEmptySignatureField)
{
	sb_zend_long fSigRemoveOption;
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_RemoveEmptySignatureField(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4Index, &fSigRemoveOption) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_RemoveEmptySignatureField_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (TSBPDFSignatureRemoveOptionRaw)fSigRemoveOption) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer) or (integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, AddAttachedFile)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFDocument_AddAttachedFile(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, RemoveAttachedFile)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_RemoveAttachedFile(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, InitiateAsyncOperation)
{
	sb_zend_long fAsyncSignMethod;
	SBArrayZValInfo aiUserData;
	zval *oPars;
	zval *zaUserData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_InitiateAsyncOperation(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fAsyncSignMethod) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_InitiateAsyncOperation_1(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBDCAsyncSignMethodRaw)fAsyncSignMethod, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oPars, TElDCParameters_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_InitiateAsyncOperation_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaUserData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaUserData) || SB_IS_ARRAY_TYPE_RP(zaUserData) || SB_IS_NULL_TYPE_RP(zaUserData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaUserData, &aiUserData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFDocument_InitiateAsyncOperation_3(SBGetObjectHandle(getThis() TSRMLS_CC), aiUserData.data, aiUserData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiUserData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &fAsyncSignMethod, &zaUserData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaUserData) || SB_IS_ARRAY_TYPE_RP(zaUserData) || SB_IS_NULL_TYPE_RP(zaUserData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaUserData, &aiUserData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFDocument_InitiateAsyncOperation_4(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBDCAsyncSignMethodRaw)fAsyncSignMethod, aiUserData.data, aiUserData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiUserData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oPars, TElDCParameters_ce_ptr, &zaUserData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaUserData) || SB_IS_ARRAY_TYPE_RP(zaUserData) || SB_IS_NULL_TYPE_RP(zaUserData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaUserData, &aiUserData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFDocument_InitiateAsyncOperation_5(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oPars TSRMLS_CC), aiUserData.data, aiUserData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiUserData);
		SBInitObject(return_value, TElDCAsyncState_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (integer) or (\\TElDCParameters) or (array of byte|string|NULL) or (integer, array of byte|string|NULL) or (\\TElDCParameters, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, CompleteAsyncOperation)
{
	zval *oAsyncState;
	zval *oHandler;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!O!", &oStream, TStream_ce_ptr, &oAsyncState, TElDCAsyncState_ce_ptr, &oHandler, TElPDFSecurityHandler_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_CompleteAsyncOperation(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), SBGetObjectHandle(oAsyncState TSRMLS_CC), SBGetObjectHandle(oHandler TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, \\TElDCAsyncState, \\TElPDFSecurityHandler)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, ReloadRevocationInfoFromDSS)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFDocument_ReloadRevocationInfoFromDSS(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_PageInfos)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_get_PageInfos(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFPageInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_Signatures)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_get_Signatures(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFSignature_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_AttachedFiles)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_get_AttachedFiles(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFFileAttachment_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_EmptySignatureFields)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_get_EmptySignatureFields(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFSignatureInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_DocumentRequirements)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_get_DocumentRequirements(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFRequirement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_DocumentID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_get_DocumentID(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFArray_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_DocumentVersion)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_DocumentVersion(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, set_DocumentVersion)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_set_DocumentVersion(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_EmptySignatureFieldCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_EmptySignatureFieldCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_Decrypted)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_Decrypted(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_Encrypted)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_Encrypted(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_EncryptionHandler)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_get_EncryptionHandler(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFSecurityHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, set_EncryptionHandler)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPDFSecurityHandler_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_set_EncryptionHandler(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFSecurityHandler)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_Opened)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_Opened(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_DocumentRequirementCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_DocumentRequirementCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_PageInfoCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_PageInfoCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_SignatureCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_SignatureCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_Signed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_Signed(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_AttachedFileCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_AttachedFileCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_AssemblyOptions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFAssemblyOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_AssemblyOptions(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, set_AssemblyOptions)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_set_AssemblyOptions(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFAssemblyOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_DocumentRoot)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_get_DocumentRoot(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFArray_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_DocumentCatalog)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_get_DocumentCatalog(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFDictionary_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_PDFFile)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_get_PDFFile(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFFile_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_DecryptionMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFDecryptionModeRaw fOutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_DecryptionMode(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, set_DecryptionMode)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_set_DecryptionMode(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFDecryptionModeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_Adobe8Compatibility)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_Adobe8Compatibility(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, set_Adobe8Compatibility)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_set_Adobe8Compatibility(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_ExtractSignaturesFromPages)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_ExtractSignaturesFromPages(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, set_ExtractSignaturesFromPages)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_set_ExtractSignaturesFromPages(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_SignatureCustomDataName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFDocument_get_SignatureCustomDataName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2022351833, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, set_SignatureCustomDataName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_set_SignatureCustomDataName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_LegalContentAttestation)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_get_LegalContentAttestation(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFLegalContentAttestation_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_DSSRevocationInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_get_DSSRevocationInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFPublicKeyRevocationInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_ActivateSecurityHandlers)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_ActivateSecurityHandlers(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, set_ActivateSecurityHandlers)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_set_ActivateSecurityHandlers(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_OwnActivatedSecurityHandlers)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_OwnActivatedSecurityHandlers(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, set_OwnActivatedSecurityHandlers)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_set_OwnActivatedSecurityHandlers(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_Compress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFDocument_get_Compress(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, set_Compress)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFDocument_set_Compress(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_OnProgress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFProgressEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPDFDocument_get_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, set_OnProgress)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPDFDocument_set_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPDFProgressEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPDFProgressEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_OnCreateTemporaryStream)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFCreateTemporaryStreamEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPDFDocument_get_OnCreateTemporaryStream(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, set_OnCreateTemporaryStream)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPDFDocument_set_OnCreateTemporaryStream(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPDFCreateTemporaryStreamEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPDFCreateTemporaryStreamEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_OnDecryptionInfoNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPDFDocument_get_OnDecryptionInfoNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, set_OnDecryptionInfoNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPDFDocument_set_OnDecryptionInfoNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, get_OnBeforeSign)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFBeforeSignEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPDFDocument_get_OnBeforeSign(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, set_OnBeforeSign)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPDFDocument_set_OnBeforeSign(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPDFBeforeSignEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPDFBeforeSignEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFDocument, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFDocument_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_ExtractAdditionalDataFromAsyncState_Inst, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Handler, TElPDFSecurityHandler, 1)
	ZEND_ARG_OBJ_INFO(0, State, TElDCAsyncState, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_ExtractAdditionalDataFromAsyncState, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Handler, TElPDFSecurityHandler, 1)
	ZEND_ARG_OBJ_INFO(0, State, TElDCAsyncState, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_Open, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_Close, 0, 0, 1)
	ZEND_ARG_INFO(0, Save)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_Encrypt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_SignAndEncrypt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_Decrypt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_AddSignature, 0, 0, 0)
	ZEND_ARG_INFO(0, EmptySignatureField)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_InsertSignature, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_ClearSignatures, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_RemoveSignature, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, SigRemoveOption)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_RemoveEmptySignatureField, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, SigRemoveOption)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_AddAttachedFile, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_RemoveAttachedFile, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_InitiateAsyncOperation, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, AsyncSignMethod_or_Pars_or_UserData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, UserData, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_CompleteAsyncOperation, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_OBJ_INFO(0, AsyncState, TElDCAsyncState, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElPDFSecurityHandler, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_ReloadRevocationInfoFromDSS, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_PageInfos, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_Signatures, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_AttachedFiles, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_EmptySignatureFields, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_DocumentRequirements, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_DocumentID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_DocumentVersion, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_set_DocumentVersion, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_EmptySignatureFieldCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_Decrypted, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_Encrypted, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_EncryptionHandler, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_set_EncryptionHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPDFSecurityHandler, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_Opened, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_DocumentRequirementCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_PageInfoCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_SignatureCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_Signed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_AttachedFileCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_AssemblyOptions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_set_AssemblyOptions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_DocumentRoot, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_DocumentCatalog, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_PDFFile, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_DecryptionMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_set_DecryptionMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_Adobe8Compatibility, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_set_Adobe8Compatibility, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_ExtractSignaturesFromPages, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_set_ExtractSignaturesFromPages, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_SignatureCustomDataName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_set_SignatureCustomDataName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_LegalContentAttestation, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_DSSRevocationInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_ActivateSecurityHandlers, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_set_ActivateSecurityHandlers, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_OwnActivatedSecurityHandlers, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_set_OwnActivatedSecurityHandlers, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_Compress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_set_Compress, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_OnProgress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_set_OnProgress, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_OnCreateTemporaryStream, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_set_OnCreateTemporaryStream, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_OnDecryptionInfoNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_set_OnDecryptionInfoNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_get_OnBeforeSign, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument_set_OnBeforeSign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFDocument___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFDocument_methods[] = {
	PHP_ME(TElPDFDocument, ExtractAdditionalDataFromAsyncState_Inst, arginfo_TElPDFDocument_ExtractAdditionalDataFromAsyncState_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, ExtractAdditionalDataFromAsyncState, arginfo_TElPDFDocument_ExtractAdditionalDataFromAsyncState, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPDFDocument, Open, arginfo_TElPDFDocument_Open, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, Close, arginfo_TElPDFDocument_Close, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, Encrypt, arginfo_TElPDFDocument_Encrypt, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, SignAndEncrypt, arginfo_TElPDFDocument_SignAndEncrypt, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, Decrypt, arginfo_TElPDFDocument_Decrypt, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, AddSignature, arginfo_TElPDFDocument_AddSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, InsertSignature, arginfo_TElPDFDocument_InsertSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, ClearSignatures, arginfo_TElPDFDocument_ClearSignatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, RemoveSignature, arginfo_TElPDFDocument_RemoveSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, RemoveEmptySignatureField, arginfo_TElPDFDocument_RemoveEmptySignatureField, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, AddAttachedFile, arginfo_TElPDFDocument_AddAttachedFile, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, RemoveAttachedFile, arginfo_TElPDFDocument_RemoveAttachedFile, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, InitiateAsyncOperation, arginfo_TElPDFDocument_InitiateAsyncOperation, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, CompleteAsyncOperation, arginfo_TElPDFDocument_CompleteAsyncOperation, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, ReloadRevocationInfoFromDSS, arginfo_TElPDFDocument_ReloadRevocationInfoFromDSS, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_PageInfos, arginfo_TElPDFDocument_get_PageInfos, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_Signatures, arginfo_TElPDFDocument_get_Signatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_AttachedFiles, arginfo_TElPDFDocument_get_AttachedFiles, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_EmptySignatureFields, arginfo_TElPDFDocument_get_EmptySignatureFields, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_DocumentRequirements, arginfo_TElPDFDocument_get_DocumentRequirements, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_DocumentID, arginfo_TElPDFDocument_get_DocumentID, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_DocumentVersion, arginfo_TElPDFDocument_get_DocumentVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, set_DocumentVersion, arginfo_TElPDFDocument_set_DocumentVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_EmptySignatureFieldCount, arginfo_TElPDFDocument_get_EmptySignatureFieldCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_Decrypted, arginfo_TElPDFDocument_get_Decrypted, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_Encrypted, arginfo_TElPDFDocument_get_Encrypted, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_EncryptionHandler, arginfo_TElPDFDocument_get_EncryptionHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, set_EncryptionHandler, arginfo_TElPDFDocument_set_EncryptionHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_Opened, arginfo_TElPDFDocument_get_Opened, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_DocumentRequirementCount, arginfo_TElPDFDocument_get_DocumentRequirementCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_PageInfoCount, arginfo_TElPDFDocument_get_PageInfoCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_SignatureCount, arginfo_TElPDFDocument_get_SignatureCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_Signed, arginfo_TElPDFDocument_get_Signed, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_AttachedFileCount, arginfo_TElPDFDocument_get_AttachedFileCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_AssemblyOptions, arginfo_TElPDFDocument_get_AssemblyOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, set_AssemblyOptions, arginfo_TElPDFDocument_set_AssemblyOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_DocumentRoot, arginfo_TElPDFDocument_get_DocumentRoot, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_DocumentCatalog, arginfo_TElPDFDocument_get_DocumentCatalog, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_PDFFile, arginfo_TElPDFDocument_get_PDFFile, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_DecryptionMode, arginfo_TElPDFDocument_get_DecryptionMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, set_DecryptionMode, arginfo_TElPDFDocument_set_DecryptionMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_Adobe8Compatibility, arginfo_TElPDFDocument_get_Adobe8Compatibility, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, set_Adobe8Compatibility, arginfo_TElPDFDocument_set_Adobe8Compatibility, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_ExtractSignaturesFromPages, arginfo_TElPDFDocument_get_ExtractSignaturesFromPages, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, set_ExtractSignaturesFromPages, arginfo_TElPDFDocument_set_ExtractSignaturesFromPages, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_SignatureCustomDataName, arginfo_TElPDFDocument_get_SignatureCustomDataName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, set_SignatureCustomDataName, arginfo_TElPDFDocument_set_SignatureCustomDataName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_LegalContentAttestation, arginfo_TElPDFDocument_get_LegalContentAttestation, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_DSSRevocationInfo, arginfo_TElPDFDocument_get_DSSRevocationInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_ActivateSecurityHandlers, arginfo_TElPDFDocument_get_ActivateSecurityHandlers, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, set_ActivateSecurityHandlers, arginfo_TElPDFDocument_set_ActivateSecurityHandlers, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_OwnActivatedSecurityHandlers, arginfo_TElPDFDocument_get_OwnActivatedSecurityHandlers, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, set_OwnActivatedSecurityHandlers, arginfo_TElPDFDocument_set_OwnActivatedSecurityHandlers, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_Compress, arginfo_TElPDFDocument_get_Compress, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, set_Compress, arginfo_TElPDFDocument_set_Compress, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_OnProgress, arginfo_TElPDFDocument_get_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, set_OnProgress, arginfo_TElPDFDocument_set_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_OnCreateTemporaryStream, arginfo_TElPDFDocument_get_OnCreateTemporaryStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, set_OnCreateTemporaryStream, arginfo_TElPDFDocument_set_OnCreateTemporaryStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_OnDecryptionInfoNeeded, arginfo_TElPDFDocument_get_OnDecryptionInfoNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, set_OnDecryptionInfoNeeded, arginfo_TElPDFDocument_set_OnDecryptionInfoNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, get_OnBeforeSign, arginfo_TElPDFDocument_get_OnBeforeSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, set_OnBeforeSign, arginfo_TElPDFDocument_set_OnBeforeSign, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFDocument, __construct, arginfo_TElPDFDocument___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFDocument(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFDocument_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFDocument", TElPDFDocument_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElPDFDocument_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElPDFSignature_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFSignature, Validate)
{
	zend_bool bMDPLiberalMode;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignature_Validate(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bMDPLiberalMode) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignature_Validate_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bMDPLiberalMode, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, GetSignedVersion)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_GetSignedVersion(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, IsDocumentSigned)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignature_IsDocumentSigned(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, Update)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFSignature_Update(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, Timestamp)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFSignature_Timestamp(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_SignatureType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFSignatureTypeRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_SignatureType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_SignatureType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_SignatureType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFSignatureTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_AllowedChanges)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFSignatureAllowedChangesRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_AllowedChanges(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_AllowedChanges)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_AllowedChanges(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFSignatureAllowedChangesRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_Handler)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignature_get_Handler(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFSecurityHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_Handler)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPDFSecurityHandler_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_Handler(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFSecurityHandler)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_SignatureName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignature_get_SignatureName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2007394611, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_SignatureName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_SignatureName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_AuthorName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignature_get_AuthorName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(778980586, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_AuthorName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_AuthorName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_ContactInfo)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignature_get_ContactInfo(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-667992697, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_ContactInfo)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_ContactInfo(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_Location)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignature_get_Location(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-504309128, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_Location)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_Location(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_Reason)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignature_get_Reason(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1743702289, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_Reason)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_Reason(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_SigningTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_SigningTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_SigningTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_SigningTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_WidgetProps)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignature_get_WidgetProps(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFSignatureWidgetProps_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_Invisible)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_Invisible(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_Invisible)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_Invisible(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_Page)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_Page(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_Page)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_Page(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_UseHexEncoding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_UseHexEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_UseHexEncoding)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_UseHexEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_MDPHashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFDigestMethodRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_MDPHashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_MDPHashAlgorithm)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_MDPHashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFDigestMethodRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_DisableDocMDPTransformDigestValue)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_DisableDocMDPTransformDigestValue(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_DisableDocMDPTransformDigestValue)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_DisableDocMDPTransformDigestValue(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_DisableFieldMDPTransformDigestValue)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_DisableFieldMDPTransformDigestValue(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_DisableFieldMDPTransformDigestValue)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_DisableFieldMDPTransformDigestValue(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_ExtraSpace)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_ExtraSpace(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_ExtraSpace)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_ExtraSpace(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_EmptyField)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_EmptyField(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_EmptyField)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_EmptyField(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_ExplicitElementSignature)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_ExplicitElementSignature(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_ExplicitElementSignature)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_ExplicitElementSignature(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_ExplicitElement)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignature_get_ExplicitElement(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_ExplicitElement)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPDFObject_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_ExplicitElement(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_CustomData)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPDFSignature_get_CustomData(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1858015678, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_CustomData)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFSignature_set_CustomData(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_CustomDataEncoding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TPDFStringEncodingRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_CustomDataEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_CustomDataEncoding)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_CustomDataEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), (TPDFStringEncodingRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_Options)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFSignatureOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_Options(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_Options)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_Options(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFSignatureOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_PDFObject)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignature_get_PDFObject(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFObject_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_LockAction)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFFieldMDPActionRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_LockAction(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_LockAction)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_LockAction(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFFieldMDPActionRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_LockFields)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignature_get_LockFields(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, get_LockAllowedChanges)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFSignatureAllowedChangesRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSignature_get_LockAllowedChanges(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, set_LockAllowedChanges)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignature_set_LockAllowedChanges(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFSignatureAllowedChangesRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignature, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TElPDFDocument_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignature_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFDocument)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_Validate, 0, 0, 0)
	ZEND_ARG_INFO(0, MDPLiberalMode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_GetSignedVersion, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_IsDocumentSigned, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_Update, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_Timestamp, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_SignatureType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_SignatureType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_AllowedChanges, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_AllowedChanges, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_Handler, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_Handler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPDFSecurityHandler, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_SignatureName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_SignatureName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_AuthorName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_AuthorName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_ContactInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_ContactInfo, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_Location, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_Location, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_Reason, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_Reason, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_SigningTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_SigningTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_WidgetProps, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_Invisible, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_Invisible, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_Page, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_Page, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_UseHexEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_UseHexEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_MDPHashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_MDPHashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_DisableDocMDPTransformDigestValue, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_DisableDocMDPTransformDigestValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_DisableFieldMDPTransformDigestValue, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_DisableFieldMDPTransformDigestValue, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_ExtraSpace, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_ExtraSpace, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_EmptyField, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_EmptyField, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_ExplicitElementSignature, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_ExplicitElementSignature, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_ExplicitElement, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_ExplicitElement, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPDFObject, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_CustomData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_CustomData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_CustomDataEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_CustomDataEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_Options, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_Options, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_PDFObject, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_LockAction, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_LockAction, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_LockFields, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_get_LockAllowedChanges, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature_set_LockAllowedChanges, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignature___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TElPDFDocument, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFSignature_methods[] = {
	PHP_ME(TElPDFSignature, Validate, arginfo_TElPDFSignature_Validate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, GetSignedVersion, arginfo_TElPDFSignature_GetSignedVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, IsDocumentSigned, arginfo_TElPDFSignature_IsDocumentSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, Update, arginfo_TElPDFSignature_Update, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, Timestamp, arginfo_TElPDFSignature_Timestamp, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_SignatureType, arginfo_TElPDFSignature_get_SignatureType, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_SignatureType, arginfo_TElPDFSignature_set_SignatureType, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_AllowedChanges, arginfo_TElPDFSignature_get_AllowedChanges, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_AllowedChanges, arginfo_TElPDFSignature_set_AllowedChanges, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_Handler, arginfo_TElPDFSignature_get_Handler, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_Handler, arginfo_TElPDFSignature_set_Handler, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_SignatureName, arginfo_TElPDFSignature_get_SignatureName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_SignatureName, arginfo_TElPDFSignature_set_SignatureName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_AuthorName, arginfo_TElPDFSignature_get_AuthorName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_AuthorName, arginfo_TElPDFSignature_set_AuthorName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_ContactInfo, arginfo_TElPDFSignature_get_ContactInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_ContactInfo, arginfo_TElPDFSignature_set_ContactInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_Location, arginfo_TElPDFSignature_get_Location, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_Location, arginfo_TElPDFSignature_set_Location, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_Reason, arginfo_TElPDFSignature_get_Reason, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_Reason, arginfo_TElPDFSignature_set_Reason, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_SigningTime, arginfo_TElPDFSignature_get_SigningTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_SigningTime, arginfo_TElPDFSignature_set_SigningTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_WidgetProps, arginfo_TElPDFSignature_get_WidgetProps, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_Invisible, arginfo_TElPDFSignature_get_Invisible, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_Invisible, arginfo_TElPDFSignature_set_Invisible, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_Page, arginfo_TElPDFSignature_get_Page, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_Page, arginfo_TElPDFSignature_set_Page, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_UseHexEncoding, arginfo_TElPDFSignature_get_UseHexEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_UseHexEncoding, arginfo_TElPDFSignature_set_UseHexEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_MDPHashAlgorithm, arginfo_TElPDFSignature_get_MDPHashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_MDPHashAlgorithm, arginfo_TElPDFSignature_set_MDPHashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_DisableDocMDPTransformDigestValue, arginfo_TElPDFSignature_get_DisableDocMDPTransformDigestValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_DisableDocMDPTransformDigestValue, arginfo_TElPDFSignature_set_DisableDocMDPTransformDigestValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_DisableFieldMDPTransformDigestValue, arginfo_TElPDFSignature_get_DisableFieldMDPTransformDigestValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_DisableFieldMDPTransformDigestValue, arginfo_TElPDFSignature_set_DisableFieldMDPTransformDigestValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_ExtraSpace, arginfo_TElPDFSignature_get_ExtraSpace, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_ExtraSpace, arginfo_TElPDFSignature_set_ExtraSpace, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_EmptyField, arginfo_TElPDFSignature_get_EmptyField, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_EmptyField, arginfo_TElPDFSignature_set_EmptyField, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_ExplicitElementSignature, arginfo_TElPDFSignature_get_ExplicitElementSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_ExplicitElementSignature, arginfo_TElPDFSignature_set_ExplicitElementSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_ExplicitElement, arginfo_TElPDFSignature_get_ExplicitElement, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_ExplicitElement, arginfo_TElPDFSignature_set_ExplicitElement, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_CustomData, arginfo_TElPDFSignature_get_CustomData, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_CustomData, arginfo_TElPDFSignature_set_CustomData, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_CustomDataEncoding, arginfo_TElPDFSignature_get_CustomDataEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_CustomDataEncoding, arginfo_TElPDFSignature_set_CustomDataEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_Options, arginfo_TElPDFSignature_get_Options, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_Options, arginfo_TElPDFSignature_set_Options, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_PDFObject, arginfo_TElPDFSignature_get_PDFObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_LockAction, arginfo_TElPDFSignature_get_LockAction, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_LockAction, arginfo_TElPDFSignature_set_LockAction, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_LockFields, arginfo_TElPDFSignature_get_LockFields, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, get_LockAllowedChanges, arginfo_TElPDFSignature_get_LockAllowedChanges, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, set_LockAllowedChanges, arginfo_TElPDFSignature_set_LockAllowedChanges, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignature, __construct, arginfo_TElPDFSignature___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFSignature(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFSignature_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFSignature", TElPDFSignature_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFSignature_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFURProperties_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFURProperties, get_AnnotationRights)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFURProperties_get_AnnotationRights(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, set_AnnotationRights)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFURProperties_set_AnnotationRights(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, get_DocumentRights)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFURProperties_get_DocumentRights(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, set_DocumentRights)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFURProperties_set_DocumentRights(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, get_EmbeddedFileRights)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFURProperties_get_EmbeddedFileRights(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, set_EmbeddedFileRights)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFURProperties_set_EmbeddedFileRights(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, get_FormExRights)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFURProperties_get_FormExRights(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, set_FormExRights)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFURProperties_set_FormExRights(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, get_FormRights)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFURProperties_get_FormRights(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, set_FormRights)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFURProperties_set_FormRights(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, get_Message)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFURProperties_get_Message(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1456968177, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, set_Message)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFURProperties_set_Message(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, get_P)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFURProperties_get_P(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, set_P)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFURProperties_set_P(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, get_SignatureRights)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFURProperties_get_SignatureRights(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, set_SignatureRights)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFURProperties_set_SignatureRights(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFURProperties, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFURProperties_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_get_AnnotationRights, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_set_AnnotationRights, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_get_DocumentRights, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_set_DocumentRights, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_get_EmbeddedFileRights, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_set_EmbeddedFileRights, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_get_FormExRights, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_set_FormExRights, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_get_FormRights, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_set_FormRights, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_get_Message, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_set_Message, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_get_P, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_set_P, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_get_SignatureRights, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties_set_SignatureRights, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFURProperties___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFURProperties_methods[] = {
	PHP_ME(TElPDFURProperties, get_AnnotationRights, arginfo_TElPDFURProperties_get_AnnotationRights, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, set_AnnotationRights, arginfo_TElPDFURProperties_set_AnnotationRights, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, get_DocumentRights, arginfo_TElPDFURProperties_get_DocumentRights, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, set_DocumentRights, arginfo_TElPDFURProperties_set_DocumentRights, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, get_EmbeddedFileRights, arginfo_TElPDFURProperties_get_EmbeddedFileRights, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, set_EmbeddedFileRights, arginfo_TElPDFURProperties_set_EmbeddedFileRights, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, get_FormExRights, arginfo_TElPDFURProperties_get_FormExRights, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, set_FormExRights, arginfo_TElPDFURProperties_set_FormExRights, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, get_FormRights, arginfo_TElPDFURProperties_get_FormRights, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, set_FormRights, arginfo_TElPDFURProperties_set_FormRights, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, get_Message, arginfo_TElPDFURProperties_get_Message, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, set_Message, arginfo_TElPDFURProperties_set_Message, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, get_P, arginfo_TElPDFURProperties_get_P, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, set_P, arginfo_TElPDFURProperties_set_P, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, get_SignatureRights, arginfo_TElPDFURProperties_get_SignatureRights, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, set_SignatureRights, arginfo_TElPDFURProperties_set_SignatureRights, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFURProperties, __construct, arginfo_TElPDFURProperties___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFURProperties(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFURProperties_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFURProperties", TElPDFURProperties_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFURProperties_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFSigRefEntry_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFSigRefEntry, get_Valid)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSigRefEntry_get_Valid(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSigRefEntry, get_DocMDPAccessPermissions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int16_t l2OutResultRaw = 0;
		SBCheckError(TElPDFSigRefEntry_get_DocMDPAccessPermissions(SBGetObjectHandle(getThis() TSRMLS_CC), &l2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSigRefEntry, set_DocMDPAccessPermissions)
{
	sb_zend_long l2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l2Value) == SUCCESS)
	{
		SBCheckError(TElPDFSigRefEntry_set_DocMDPAccessPermissions(SBGetObjectHandle(getThis() TSRMLS_CC), (int16_t)l2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSigRefEntry, get_FieldMDPAction)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFFieldMDPActionRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSigRefEntry_get_FieldMDPAction(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSigRefEntry, set_FieldMDPAction)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFSigRefEntry_set_FieldMDPAction(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFFieldMDPActionRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSigRefEntry, get_FieldMDPFields)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSigRefEntry_get_FieldMDPFields(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSigRefEntry, get_DigestMethod)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFDigestMethodRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSigRefEntry_get_DigestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSigRefEntry, set_DigestMethod)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFSigRefEntry_set_DigestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFDigestMethodRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSigRefEntry, get_TransformMethod)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFTransformMethodRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSigRefEntry_get_TransformMethod(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSigRefEntry, set_TransformMethod)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFSigRefEntry_set_TransformMethod(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFTransformMethodRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSigRefEntry, get_URProperties)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSigRefEntry_get_URProperties(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFURProperties_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSigRefEntry, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSigRefEntry_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSigRefEntry_get_Valid, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSigRefEntry_get_DocMDPAccessPermissions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSigRefEntry_set_DocMDPAccessPermissions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSigRefEntry_get_FieldMDPAction, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSigRefEntry_set_FieldMDPAction, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSigRefEntry_get_FieldMDPFields, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSigRefEntry_get_DigestMethod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSigRefEntry_set_DigestMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSigRefEntry_get_TransformMethod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSigRefEntry_set_TransformMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSigRefEntry_get_URProperties, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSigRefEntry___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFSigRefEntry_methods[] = {
	PHP_ME(TElPDFSigRefEntry, get_Valid, arginfo_TElPDFSigRefEntry_get_Valid, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSigRefEntry, get_DocMDPAccessPermissions, arginfo_TElPDFSigRefEntry_get_DocMDPAccessPermissions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSigRefEntry, set_DocMDPAccessPermissions, arginfo_TElPDFSigRefEntry_set_DocMDPAccessPermissions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSigRefEntry, get_FieldMDPAction, arginfo_TElPDFSigRefEntry_get_FieldMDPAction, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSigRefEntry, set_FieldMDPAction, arginfo_TElPDFSigRefEntry_set_FieldMDPAction, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSigRefEntry, get_FieldMDPFields, arginfo_TElPDFSigRefEntry_get_FieldMDPFields, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSigRefEntry, get_DigestMethod, arginfo_TElPDFSigRefEntry_get_DigestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSigRefEntry, set_DigestMethod, arginfo_TElPDFSigRefEntry_set_DigestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSigRefEntry, get_TransformMethod, arginfo_TElPDFSigRefEntry_get_TransformMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSigRefEntry, set_TransformMethod, arginfo_TElPDFSigRefEntry_set_TransformMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSigRefEntry, get_URProperties, arginfo_TElPDFSigRefEntry_get_URProperties, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSigRefEntry, __construct, arginfo_TElPDFSigRefEntry___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFSigRefEntry(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFSigRefEntry_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFSigRefEntry", TElPDFSigRefEntry_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFSigRefEntry_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFSecurityHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFSecurityHandler, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFSecurityHandler_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, GetName_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSecurityHandler_GetName_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1039705289, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, GetName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSecurityHandler_GetName(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1039705289, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, GetDescription_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSecurityHandler_GetDescription_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1737411733, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSecurityHandler_GetDescription(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1737411733, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSecurityHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, get_StreamEncryptionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSecurityHandler_get_StreamEncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, set_StreamEncryptionAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFSecurityHandler_set_StreamEncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, get_StringEncryptionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSecurityHandler_get_StringEncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, set_StringEncryptionAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFSecurityHandler_set_StringEncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, get_StreamEncryptionKeyBits)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSecurityHandler_get_StreamEncryptionKeyBits(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, set_StreamEncryptionKeyBits)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFSecurityHandler_set_StreamEncryptionKeyBits(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, get_StringEncryptionKeyBits)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSecurityHandler_get_StringEncryptionKeyBits(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, set_StringEncryptionKeyBits)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFSecurityHandler_set_StringEncryptionKeyBits(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, get_EncryptMetadata)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSecurityHandler_get_EncryptMetadata(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, set_EncryptMetadata)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSecurityHandler_set_EncryptMetadata(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, get_CustomName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSecurityHandler_get_CustomName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1202431368, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, set_CustomName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSecurityHandler_set_CustomName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, get_CryptoProviderManager)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSecurityHandler_get_CryptoProviderManager(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoProviderManager_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, set_CryptoProviderManager)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCryptoProviderManager_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFSecurityHandler_set_CryptoProviderManager(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoProviderManager)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSecurityHandler, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSecurityHandler_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_GetName_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_GetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_GetDescription_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_get_StreamEncryptionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_set_StreamEncryptionAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_get_StringEncryptionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_set_StringEncryptionAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_get_StreamEncryptionKeyBits, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_set_StreamEncryptionKeyBits, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_get_StringEncryptionKeyBits, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_set_StringEncryptionKeyBits, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_get_EncryptMetadata, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_set_EncryptMetadata, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_get_CustomName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_set_CustomName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_get_CryptoProviderManager, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler_set_CryptoProviderManager, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCryptoProviderManager, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSecurityHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFSecurityHandler_methods[] = {
	PHP_ME(TElPDFSecurityHandler, Reset, arginfo_TElPDFSecurityHandler_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, GetName_Inst, arginfo_TElPDFSecurityHandler_GetName_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, GetName, arginfo_TElPDFSecurityHandler_GetName, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPDFSecurityHandler, GetDescription_Inst, arginfo_TElPDFSecurityHandler_GetDescription_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, GetDescription, arginfo_TElPDFSecurityHandler_GetDescription, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPDFSecurityHandler, ClassType, arginfo_TElPDFSecurityHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPDFSecurityHandler, get_StreamEncryptionAlgorithm, arginfo_TElPDFSecurityHandler_get_StreamEncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, set_StreamEncryptionAlgorithm, arginfo_TElPDFSecurityHandler_set_StreamEncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, get_StringEncryptionAlgorithm, arginfo_TElPDFSecurityHandler_get_StringEncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, set_StringEncryptionAlgorithm, arginfo_TElPDFSecurityHandler_set_StringEncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, get_StreamEncryptionKeyBits, arginfo_TElPDFSecurityHandler_get_StreamEncryptionKeyBits, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, set_StreamEncryptionKeyBits, arginfo_TElPDFSecurityHandler_set_StreamEncryptionKeyBits, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, get_StringEncryptionKeyBits, arginfo_TElPDFSecurityHandler_get_StringEncryptionKeyBits, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, set_StringEncryptionKeyBits, arginfo_TElPDFSecurityHandler_set_StringEncryptionKeyBits, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, get_EncryptMetadata, arginfo_TElPDFSecurityHandler_get_EncryptMetadata, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, set_EncryptMetadata, arginfo_TElPDFSecurityHandler_set_EncryptMetadata, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, get_CustomName, arginfo_TElPDFSecurityHandler_get_CustomName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, set_CustomName, arginfo_TElPDFSecurityHandler_set_CustomName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, get_CryptoProviderManager, arginfo_TElPDFSecurityHandler_get_CryptoProviderManager, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, set_CryptoProviderManager, arginfo_TElPDFSecurityHandler_set_CryptoProviderManager, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSecurityHandler, __construct, arginfo_TElPDFSecurityHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFSecurityHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFSecurityHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFSecurityHandler", TElPDFSecurityHandler_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElPDFSecurityHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElPDFByteRange_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFByteRange, get_StartOffset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFByteRange_get_StartOffset(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFByteRange, set_StartOffset)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFByteRange_set_StartOffset(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFByteRange, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFByteRange_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFByteRange, set_Count)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFByteRange_set_Count(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFByteRange, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFByteRange_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFByteRange_get_StartOffset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFByteRange_set_StartOffset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFByteRange_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFByteRange_set_Count, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFByteRange___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFByteRange_methods[] = {
	PHP_ME(TElPDFByteRange, get_StartOffset, arginfo_TElPDFByteRange_get_StartOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFByteRange, set_StartOffset, arginfo_TElPDFByteRange_set_StartOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFByteRange, get_Count, arginfo_TElPDFByteRange_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFByteRange, set_Count, arginfo_TElPDFByteRange_set_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFByteRange, __construct, arginfo_TElPDFByteRange___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFByteRange(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFByteRange_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFByteRange", TElPDFByteRange_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFByteRange_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFImage_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFImage, AddMaskColorComponent)
{
	sb_zend_long l4MaxCC;
	sb_zend_long l4MinCC;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4MinCC, &l4MaxCC) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFImage_AddMaskColorComponent(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4MinCC, (int32_t)l4MaxCC, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, DeleteMaskColorComponent)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElPDFImage_DeleteMaskColorComponent(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, get_ImageType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFImageTypeRaw fOutResultRaw = 0;
		SBCheckError(TElPDFImage_get_ImageType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, set_ImageType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFImage_set_ImageType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFImageTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, get_Data)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPDFImage_get_Data(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1211564542, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, set_Data)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFImage_set_Data(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, get_Width)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFImage_get_Width(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, set_Width)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFImage_set_Width(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, get_Height)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFImage_get_Height(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, set_Height)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFImage_set_Height(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, get_MaskImage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFImage_get_MaskImage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFImage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, get_MaskColorComponentCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFImage_get_MaskColorComponentCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, get_MaskColorComponentsMin)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFImage_get_MaskColorComponentsMin(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, get_MaskColorComponentsMax)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFImage_get_MaskColorComponentsMax(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, get_BitsPerComponent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFImage_get_BitsPerComponent(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, set_BitsPerComponent)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFImage_set_BitsPerComponent(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, get_ColorSpaceType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFColorSpaceTypeRaw fOutResultRaw = 0;
		SBCheckError(TElPDFImage_get_ColorSpaceType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, set_ColorSpaceType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFImage_set_ColorSpaceType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFColorSpaceTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, get_Interpolate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFImage_get_Interpolate(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, set_Interpolate)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFImage_set_Interpolate(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, get_ResourceName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFImage_get_ResourceName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-618133697, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, set_ResourceName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFImage_set_ResourceName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFImage, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFImage_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_AddMaskColorComponent, 0, 0, 2)
	ZEND_ARG_INFO(0, MinCC)
	ZEND_ARG_INFO(0, MaxCC)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_DeleteMaskColorComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_get_ImageType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_set_ImageType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_get_Data, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_set_Data, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_get_Width, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_set_Width, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_get_Height, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_set_Height, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_get_MaskImage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_get_MaskColorComponentCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_get_MaskColorComponentsMin, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_get_MaskColorComponentsMax, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_get_BitsPerComponent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_set_BitsPerComponent, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_get_ColorSpaceType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_set_ColorSpaceType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_get_Interpolate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_set_Interpolate, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_get_ResourceName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage_set_ResourceName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFImage___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFImage_methods[] = {
	PHP_ME(TElPDFImage, AddMaskColorComponent, arginfo_TElPDFImage_AddMaskColorComponent, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, DeleteMaskColorComponent, arginfo_TElPDFImage_DeleteMaskColorComponent, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, get_ImageType, arginfo_TElPDFImage_get_ImageType, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, set_ImageType, arginfo_TElPDFImage_set_ImageType, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, get_Data, arginfo_TElPDFImage_get_Data, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, set_Data, arginfo_TElPDFImage_set_Data, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, get_Width, arginfo_TElPDFImage_get_Width, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, set_Width, arginfo_TElPDFImage_set_Width, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, get_Height, arginfo_TElPDFImage_get_Height, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, set_Height, arginfo_TElPDFImage_set_Height, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, get_MaskImage, arginfo_TElPDFImage_get_MaskImage, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, get_MaskColorComponentCount, arginfo_TElPDFImage_get_MaskColorComponentCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, get_MaskColorComponentsMin, arginfo_TElPDFImage_get_MaskColorComponentsMin, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, get_MaskColorComponentsMax, arginfo_TElPDFImage_get_MaskColorComponentsMax, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, get_BitsPerComponent, arginfo_TElPDFImage_get_BitsPerComponent, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, set_BitsPerComponent, arginfo_TElPDFImage_set_BitsPerComponent, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, get_ColorSpaceType, arginfo_TElPDFImage_get_ColorSpaceType, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, set_ColorSpaceType, arginfo_TElPDFImage_set_ColorSpaceType, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, get_Interpolate, arginfo_TElPDFImage_get_Interpolate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, set_Interpolate, arginfo_TElPDFImage_set_Interpolate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, get_ResourceName, arginfo_TElPDFImage_get_ResourceName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, set_ResourceName, arginfo_TElPDFImage_set_ResourceName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFImage, __construct, arginfo_TElPDFImage___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFImage(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFImage_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFImage", TElPDFImage_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFImage_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFCustomFontObject_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFCustomFontObject, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFCustomFontObject_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCustomFontObject___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFCustomFontObject_methods[] = {
	PHP_ME(TElPDFCustomFontObject, __construct, arginfo_TElPDFCustomFontObject___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFCustomFontObject(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFCustomFontObject_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFCustomFontObject", TElPDFCustomFontObject_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFCustomFontObject_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFEncoding_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFEncoding, get_BaseEncoding)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFEncoding_get_BaseEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1290215054, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFEncoding, set_BaseEncoding)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFEncoding_set_BaseEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFEncoding, get_Differences)
{
	sb_zend_long l4Index;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFEncoding_get_Differences(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1559324114, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFEncoding, set_Differences)
{
	char *sName;
	sb_str_size sName_len;
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ls", &l4Index, &sName, &sName_len) == SUCCESS)
	{
		SBCheckError(TElPDFEncoding_set_Differences(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, sName, (int32_t)sName_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFEncoding, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFEncoding_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFEncoding_get_BaseEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFEncoding_set_BaseEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFEncoding_get_Differences, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFEncoding_set_Differences, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFEncoding___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFEncoding_methods[] = {
	PHP_ME(TElPDFEncoding, get_BaseEncoding, arginfo_TElPDFEncoding_get_BaseEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFEncoding, set_BaseEncoding, arginfo_TElPDFEncoding_set_BaseEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFEncoding, get_Differences, arginfo_TElPDFEncoding_get_Differences, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFEncoding, set_Differences, arginfo_TElPDFEncoding_set_Differences, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFEncoding, __construct, arginfo_TElPDFEncoding___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFEncoding(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFEncoding_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFEncoding", TElPDFEncoding_methods);
	if (NULL == TElPDFCustomFontObject_ce_ptr)
		Register_TElPDFCustomFontObject(TSRMLS_C);
	TElPDFEncoding_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPDFCustomFontObject_ce_ptr);
}

zend_class_entry *TElPDFFontDescriptor_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFFontDescriptor, get_FontName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFFontDescriptor_get_FontName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1696188091, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_FontName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_FontName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_FontFamily)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFFontDescriptor_get_FontFamily(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-674021484, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_FontFamily)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_FontFamily(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_FontStretch)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFFontDescriptor_get_FontStretch(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-664798543, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_FontStretch)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_FontStretch(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_FontWeight)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_FontWeight(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_FontWeight)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_FontWeight(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_Flags)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_Flags(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_Flags)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_Flags(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_FontBBoxX1)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_FontBBoxX1(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_FontBBoxX1)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_FontBBoxX1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_FontBBoxX2)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_FontBBoxX2(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_FontBBoxX2)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_FontBBoxX2(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_FontBBoxY1)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_FontBBoxY1(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_FontBBoxY1)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_FontBBoxY1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_FontBBoxY2)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_FontBBoxY2(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_FontBBoxY2)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_FontBBoxY2(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_ItalicAngle)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFFontDescriptor_get_ItalicAngle(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_ItalicAngle)
{
	double dValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "d", &dValue) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_ItalicAngle(SBGetObjectHandle(getThis() TSRMLS_CC), (double)dValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_Ascent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_Ascent(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_Ascent)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_Ascent(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_Descent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_Descent(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_Descent)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_Descent(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_Leading)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_Leading(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_Leading)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_Leading(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_CapHeight)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_CapHeight(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_CapHeight)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_CapHeight(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_XHeight)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_XHeight(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_XHeight)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_XHeight(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_StemV)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_StemV(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_StemV)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_StemV(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_StemH)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_StemH(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_StemH)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_StemH(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_AvgWidth)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_AvgWidth(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_AvgWidth)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_AvgWidth(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_MaxWidth)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_MaxWidth(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_MaxWidth)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_MaxWidth(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_MissingWidth)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFFontDescriptor_get_MissingWidth(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_MissingWidth)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_MissingWidth(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_FontFile)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPDFFontDescriptor_get_FontFile(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1213886803, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_FontFile)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFFontDescriptor_set_FontFile(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_FontFile2)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPDFFontDescriptor_get_FontFile2(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(989662143, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_FontFile2)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFFontDescriptor_set_FontFile2(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_FontFile3)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPDFFontDescriptor_get_FontFile3(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1308244777, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_FontFile3)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFFontDescriptor_set_FontFile3(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, get_CharSet)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFFontDescriptor_get_CharSet(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1519027951, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, set_CharSet)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFFontDescriptor_set_CharSet(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFontDescriptor, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFFontDescriptor_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_FontName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_FontName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_FontFamily, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_FontFamily, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_FontStretch, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_FontStretch, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_FontWeight, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_FontWeight, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_Flags, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_Flags, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_FontBBoxX1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_FontBBoxX1, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_FontBBoxX2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_FontBBoxX2, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_FontBBoxY1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_FontBBoxY1, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_FontBBoxY2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_FontBBoxY2, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_ItalicAngle, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_ItalicAngle, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_Ascent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_Ascent, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_Descent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_Descent, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_Leading, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_Leading, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_CapHeight, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_CapHeight, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_XHeight, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_XHeight, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_StemV, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_StemV, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_StemH, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_StemH, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_AvgWidth, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_AvgWidth, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_MaxWidth, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_MaxWidth, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_MissingWidth, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_MissingWidth, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_FontFile, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_FontFile, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_FontFile2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_FontFile2, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_FontFile3, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_FontFile3, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_get_CharSet, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor_set_CharSet, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFontDescriptor___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFFontDescriptor_methods[] = {
	PHP_ME(TElPDFFontDescriptor, get_FontName, arginfo_TElPDFFontDescriptor_get_FontName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_FontName, arginfo_TElPDFFontDescriptor_set_FontName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_FontFamily, arginfo_TElPDFFontDescriptor_get_FontFamily, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_FontFamily, arginfo_TElPDFFontDescriptor_set_FontFamily, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_FontStretch, arginfo_TElPDFFontDescriptor_get_FontStretch, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_FontStretch, arginfo_TElPDFFontDescriptor_set_FontStretch, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_FontWeight, arginfo_TElPDFFontDescriptor_get_FontWeight, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_FontWeight, arginfo_TElPDFFontDescriptor_set_FontWeight, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_Flags, arginfo_TElPDFFontDescriptor_get_Flags, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_Flags, arginfo_TElPDFFontDescriptor_set_Flags, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_FontBBoxX1, arginfo_TElPDFFontDescriptor_get_FontBBoxX1, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_FontBBoxX1, arginfo_TElPDFFontDescriptor_set_FontBBoxX1, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_FontBBoxX2, arginfo_TElPDFFontDescriptor_get_FontBBoxX2, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_FontBBoxX2, arginfo_TElPDFFontDescriptor_set_FontBBoxX2, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_FontBBoxY1, arginfo_TElPDFFontDescriptor_get_FontBBoxY1, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_FontBBoxY1, arginfo_TElPDFFontDescriptor_set_FontBBoxY1, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_FontBBoxY2, arginfo_TElPDFFontDescriptor_get_FontBBoxY2, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_FontBBoxY2, arginfo_TElPDFFontDescriptor_set_FontBBoxY2, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_ItalicAngle, arginfo_TElPDFFontDescriptor_get_ItalicAngle, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_ItalicAngle, arginfo_TElPDFFontDescriptor_set_ItalicAngle, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_Ascent, arginfo_TElPDFFontDescriptor_get_Ascent, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_Ascent, arginfo_TElPDFFontDescriptor_set_Ascent, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_Descent, arginfo_TElPDFFontDescriptor_get_Descent, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_Descent, arginfo_TElPDFFontDescriptor_set_Descent, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_Leading, arginfo_TElPDFFontDescriptor_get_Leading, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_Leading, arginfo_TElPDFFontDescriptor_set_Leading, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_CapHeight, arginfo_TElPDFFontDescriptor_get_CapHeight, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_CapHeight, arginfo_TElPDFFontDescriptor_set_CapHeight, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_XHeight, arginfo_TElPDFFontDescriptor_get_XHeight, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_XHeight, arginfo_TElPDFFontDescriptor_set_XHeight, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_StemV, arginfo_TElPDFFontDescriptor_get_StemV, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_StemV, arginfo_TElPDFFontDescriptor_set_StemV, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_StemH, arginfo_TElPDFFontDescriptor_get_StemH, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_StemH, arginfo_TElPDFFontDescriptor_set_StemH, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_AvgWidth, arginfo_TElPDFFontDescriptor_get_AvgWidth, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_AvgWidth, arginfo_TElPDFFontDescriptor_set_AvgWidth, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_MaxWidth, arginfo_TElPDFFontDescriptor_get_MaxWidth, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_MaxWidth, arginfo_TElPDFFontDescriptor_set_MaxWidth, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_MissingWidth, arginfo_TElPDFFontDescriptor_get_MissingWidth, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_MissingWidth, arginfo_TElPDFFontDescriptor_set_MissingWidth, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_FontFile, arginfo_TElPDFFontDescriptor_get_FontFile, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_FontFile, arginfo_TElPDFFontDescriptor_set_FontFile, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_FontFile2, arginfo_TElPDFFontDescriptor_get_FontFile2, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_FontFile2, arginfo_TElPDFFontDescriptor_set_FontFile2, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_FontFile3, arginfo_TElPDFFontDescriptor_get_FontFile3, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_FontFile3, arginfo_TElPDFFontDescriptor_set_FontFile3, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, get_CharSet, arginfo_TElPDFFontDescriptor_get_CharSet, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, set_CharSet, arginfo_TElPDFFontDescriptor_set_CharSet, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFontDescriptor, __construct, arginfo_TElPDFFontDescriptor___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFFontDescriptor(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFFontDescriptor_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFFontDescriptor", TElPDFFontDescriptor_methods);
	if (NULL == TElPDFCustomFontObject_ce_ptr)
		Register_TElPDFCustomFontObject(TSRMLS_C);
	TElPDFFontDescriptor_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPDFCustomFontObject_ce_ptr);
}

zend_class_entry *TElPDFCIDFontDescriptor_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFCIDFontDescriptor, get_Lang)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFCIDFontDescriptor_get_Lang(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1656086900, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFontDescriptor, set_Lang)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFCIDFontDescriptor_set_Lang(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFontDescriptor, get_CIDSet)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPDFCIDFontDescriptor_get_CIDSet(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1068954216, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFontDescriptor, set_CIDSet)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFCIDFontDescriptor_set_CIDSet(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFontDescriptor, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFCIDFontDescriptor_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFontDescriptor_get_Lang, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFontDescriptor_set_Lang, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFontDescriptor_get_CIDSet, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFontDescriptor_set_CIDSet, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFontDescriptor___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFCIDFontDescriptor_methods[] = {
	PHP_ME(TElPDFCIDFontDescriptor, get_Lang, arginfo_TElPDFCIDFontDescriptor_get_Lang, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFontDescriptor, set_Lang, arginfo_TElPDFCIDFontDescriptor_set_Lang, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFontDescriptor, get_CIDSet, arginfo_TElPDFCIDFontDescriptor_get_CIDSet, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFontDescriptor, set_CIDSet, arginfo_TElPDFCIDFontDescriptor_set_CIDSet, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFontDescriptor, __construct, arginfo_TElPDFCIDFontDescriptor___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFCIDFontDescriptor(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFCIDFontDescriptor_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFCIDFontDescriptor", TElPDFCIDFontDescriptor_methods);
	if (NULL == TElPDFFontDescriptor_ce_ptr)
		Register_TElPDFFontDescriptor(TSRMLS_C);
	TElPDFCIDFontDescriptor_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPDFFontDescriptor_ce_ptr);
}

zend_class_entry *TElPDFCIDSystemInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFCIDSystemInfo, get_Registry)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFCIDSystemInfo_get_Registry(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1525943708, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDSystemInfo, set_Registry)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFCIDSystemInfo_set_Registry(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDSystemInfo, get_Ordering)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFCIDSystemInfo_get_Ordering(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-328391695, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDSystemInfo, set_Ordering)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFCIDSystemInfo_set_Ordering(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDSystemInfo, get_Supplement)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFCIDSystemInfo_get_Supplement(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDSystemInfo, set_Supplement)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFCIDSystemInfo_set_Supplement(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDSystemInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFCIDSystemInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDSystemInfo_get_Registry, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDSystemInfo_set_Registry, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDSystemInfo_get_Ordering, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDSystemInfo_set_Ordering, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDSystemInfo_get_Supplement, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDSystemInfo_set_Supplement, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDSystemInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFCIDSystemInfo_methods[] = {
	PHP_ME(TElPDFCIDSystemInfo, get_Registry, arginfo_TElPDFCIDSystemInfo_get_Registry, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDSystemInfo, set_Registry, arginfo_TElPDFCIDSystemInfo_set_Registry, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDSystemInfo, get_Ordering, arginfo_TElPDFCIDSystemInfo_get_Ordering, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDSystemInfo, set_Ordering, arginfo_TElPDFCIDSystemInfo_set_Ordering, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDSystemInfo, get_Supplement, arginfo_TElPDFCIDSystemInfo_get_Supplement, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDSystemInfo, set_Supplement, arginfo_TElPDFCIDSystemInfo_set_Supplement, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDSystemInfo, __construct, arginfo_TElPDFCIDSystemInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFCIDSystemInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFCIDSystemInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFCIDSystemInfo", TElPDFCIDSystemInfo_methods);
	if (NULL == TElPDFCustomFontObject_ce_ptr)
		Register_TElPDFCustomFontObject(TSRMLS_C);
	TElPDFCIDSystemInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPDFCustomFontObject_ce_ptr);
}

zend_class_entry *TElPDFCustomFont_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFCustomFont, get_Subtype)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFCustomFont_get_Subtype(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-216579571, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCustomFont, set_Subtype)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFCustomFont_set_Subtype(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCustomFont, get_BaseFont)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFCustomFont_get_BaseFont(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1016664625, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCustomFont, set_BaseFont)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFCustomFont_set_BaseFont(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCustomFont, get_ResourceName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFCustomFont_get_ResourceName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1540228048, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCustomFont, set_ResourceName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFCustomFont_set_ResourceName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCustomFont, get_ToUnicode)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPDFCustomFont_get_ToUnicode(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(2021492412, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCustomFont, set_ToUnicode)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFCustomFont_set_ToUnicode(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCustomFont, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFCustomFont_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCustomFont_get_Subtype, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCustomFont_set_Subtype, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCustomFont_get_BaseFont, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCustomFont_set_BaseFont, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCustomFont_get_ResourceName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCustomFont_set_ResourceName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCustomFont_get_ToUnicode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCustomFont_set_ToUnicode, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCustomFont___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFCustomFont_methods[] = {
	PHP_ME(TElPDFCustomFont, get_Subtype, arginfo_TElPDFCustomFont_get_Subtype, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCustomFont, set_Subtype, arginfo_TElPDFCustomFont_set_Subtype, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCustomFont, get_BaseFont, arginfo_TElPDFCustomFont_get_BaseFont, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCustomFont, set_BaseFont, arginfo_TElPDFCustomFont_set_BaseFont, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCustomFont, get_ResourceName, arginfo_TElPDFCustomFont_get_ResourceName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCustomFont, set_ResourceName, arginfo_TElPDFCustomFont_set_ResourceName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCustomFont, get_ToUnicode, arginfo_TElPDFCustomFont_get_ToUnicode, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCustomFont, set_ToUnicode, arginfo_TElPDFCustomFont_set_ToUnicode, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCustomFont, __construct, arginfo_TElPDFCustomFont___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFCustomFont(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFCustomFont_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFCustomFont", TElPDFCustomFont_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFCustomFont_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFSimpleFont_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFSimpleFont, get_Encoding)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSimpleFont_get_Encoding(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-752652175, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSimpleFont, set_Encoding)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSimpleFont_set_Encoding(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSimpleFont, get_EncodingObject)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSimpleFont_get_EncodingObject(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFEncoding_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSimpleFont, set_EncodingObject)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPDFEncoding_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFSimpleFont_set_EncodingObject(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFEncoding)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSimpleFont, get_FontDescriptor)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSimpleFont_get_FontDescriptor(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFFontDescriptor_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSimpleFont, set_FontDescriptor)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPDFFontDescriptor_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFSimpleFont_set_FontDescriptor(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFFontDescriptor)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSimpleFont, get_FontName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSimpleFont_get_FontName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1422583142, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSimpleFont, set_FontName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSimpleFont_set_FontName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSimpleFont, get_FirstChar)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSimpleFont_get_FirstChar(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSimpleFont, set_FirstChar)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFSimpleFont_set_FirstChar(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSimpleFont, get_LastChar)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSimpleFont_get_LastChar(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSimpleFont, set_LastChar)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFSimpleFont_set_LastChar(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSimpleFont, get_Widths)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBArrayZValInfo aiOutResult;
		SBInitArrayZValInfo(&aiOutResult);
		_err = TElPDFSimpleFont_get_Widths(SBGetObjectHandle(getThis() TSRMLS_CC), aiOutResult.data, &aiOutResult.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			aiOutResult.data = emalloc(aiOutResult.len);
			aiOutResult.ownData = 1;
			SBCheckError(SBGetLastReturnBuffer(-1425806617, 1, aiOutResult.data, &aiOutResult.len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiOutResult);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetInt32ArrayToZVal(&aiOutResult, return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSimpleFont, set_Widths)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetInt32ArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFSimpleFont_set_Widths(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of int32|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSimpleFont, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSimpleFont_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont_get_Encoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont_set_Encoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont_get_EncodingObject, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont_set_EncodingObject, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPDFEncoding, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont_get_FontDescriptor, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont_set_FontDescriptor, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPDFFontDescriptor, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont_get_FontName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont_set_FontName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont_get_FirstChar, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont_set_FirstChar, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont_get_LastChar, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont_set_LastChar, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont_get_Widths, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont_set_Widths, 0, 0, 1)
	ZEND_ARG_ARRAY_INFO(0, Value, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSimpleFont___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFSimpleFont_methods[] = {
	PHP_ME(TElPDFSimpleFont, get_Encoding, arginfo_TElPDFSimpleFont_get_Encoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSimpleFont, set_Encoding, arginfo_TElPDFSimpleFont_set_Encoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSimpleFont, get_EncodingObject, arginfo_TElPDFSimpleFont_get_EncodingObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSimpleFont, set_EncodingObject, arginfo_TElPDFSimpleFont_set_EncodingObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSimpleFont, get_FontDescriptor, arginfo_TElPDFSimpleFont_get_FontDescriptor, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSimpleFont, set_FontDescriptor, arginfo_TElPDFSimpleFont_set_FontDescriptor, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSimpleFont, get_FontName, arginfo_TElPDFSimpleFont_get_FontName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSimpleFont, set_FontName, arginfo_TElPDFSimpleFont_set_FontName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSimpleFont, get_FirstChar, arginfo_TElPDFSimpleFont_get_FirstChar, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSimpleFont, set_FirstChar, arginfo_TElPDFSimpleFont_set_FirstChar, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSimpleFont, get_LastChar, arginfo_TElPDFSimpleFont_get_LastChar, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSimpleFont, set_LastChar, arginfo_TElPDFSimpleFont_set_LastChar, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSimpleFont, get_Widths, arginfo_TElPDFSimpleFont_get_Widths, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSimpleFont, set_Widths, arginfo_TElPDFSimpleFont_set_Widths, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSimpleFont, __construct, arginfo_TElPDFSimpleFont___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFSimpleFont(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFSimpleFont_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFSimpleFont", TElPDFSimpleFont_methods);
	if (NULL == TElPDFCustomFont_ce_ptr)
		Register_TElPDFCustomFont(TSRMLS_C);
	TElPDFSimpleFont_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPDFCustomFont_ce_ptr);
}

zend_class_entry *TElPDFCompositeFont_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFCompositeFont, get_DescendantFonts)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFCompositeFont_get_DescendantFonts(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFCustomFont_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCompositeFont, set_DescendantFonts)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPDFCustomFont_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFCompositeFont_set_DescendantFonts(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFCustomFont)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCompositeFont, get_Encoding)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFCompositeFont_get_Encoding(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(764844208, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCompositeFont, set_Encoding)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFCompositeFont_set_Encoding(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCompositeFont, get_EncodingData)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPDFCompositeFont_get_EncodingData(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1607248518, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCompositeFont, set_EncodingData)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFCompositeFont_set_EncodingData(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCompositeFont, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFCompositeFont_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCompositeFont_get_DescendantFonts, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCompositeFont_set_DescendantFonts, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPDFCustomFont, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCompositeFont_get_Encoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCompositeFont_set_Encoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCompositeFont_get_EncodingData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCompositeFont_set_EncodingData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCompositeFont___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFCompositeFont_methods[] = {
	PHP_ME(TElPDFCompositeFont, get_DescendantFonts, arginfo_TElPDFCompositeFont_get_DescendantFonts, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCompositeFont, set_DescendantFonts, arginfo_TElPDFCompositeFont_set_DescendantFonts, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCompositeFont, get_Encoding, arginfo_TElPDFCompositeFont_get_Encoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCompositeFont, set_Encoding, arginfo_TElPDFCompositeFont_set_Encoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCompositeFont, get_EncodingData, arginfo_TElPDFCompositeFont_get_EncodingData, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCompositeFont, set_EncodingData, arginfo_TElPDFCompositeFont_set_EncodingData, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCompositeFont, __construct, arginfo_TElPDFCompositeFont___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFCompositeFont(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFCompositeFont_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFCompositeFont", TElPDFCompositeFont_methods);
	if (NULL == TElPDFCustomFont_ce_ptr)
		Register_TElPDFCustomFont(TSRMLS_C);
	TElPDFCompositeFont_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPDFCustomFont_ce_ptr);
}

zend_class_entry *TElPDFMetricW_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFMetricW, Add)
{
	sb_zend_long l4CID;
	sb_zend_long l4Width;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4CID, &l4Width) == SUCCESS)
	{
		SBCheckError(TElPDFMetricW_Add(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4CID, (int32_t)l4Width) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFMetricW, AddRange)
{
	sb_zend_long l4First;
	sb_zend_long l4Last;
	sb_zend_long l4Width;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lll", &l4First, &l4Last, &l4Width) == SUCCESS)
	{
		SBCheckError(TElPDFMetricW_AddRange(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4First, (int32_t)l4Last, (int32_t)l4Width) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFMetricW, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFMetricW_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFMetricW_Add, 0, 0, 2)
	ZEND_ARG_INFO(0, CID)
	ZEND_ARG_INFO(0, Width)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFMetricW_AddRange, 0, 0, 3)
	ZEND_ARG_INFO(0, First)
	ZEND_ARG_INFO(0, Last)
	ZEND_ARG_INFO(0, Width)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFMetricW___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFMetricW_methods[] = {
	PHP_ME(TElPDFMetricW, Add, arginfo_TElPDFMetricW_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFMetricW, AddRange, arginfo_TElPDFMetricW_AddRange, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFMetricW, __construct, arginfo_TElPDFMetricW___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFMetricW(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFMetricW_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFMetricW", TElPDFMetricW_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFMetricW_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFMetricW2_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFMetricW2, Add)
{
	sb_zend_long l4CID;
	sb_zend_long l4VX;
	sb_zend_long l4VY;
	sb_zend_long l4Width;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llll", &l4CID, &l4Width, &l4VX, &l4VY) == SUCCESS)
	{
		SBCheckError(TElPDFMetricW2_Add(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4CID, (int32_t)l4Width, (int32_t)l4VX, (int32_t)l4VY) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFMetricW2, AddRange)
{
	sb_zend_long l4First;
	sb_zend_long l4Last;
	sb_zend_long l4VX;
	sb_zend_long l4VY;
	sb_zend_long l4Width;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lllll", &l4First, &l4Last, &l4Width, &l4VX, &l4VY) == SUCCESS)
	{
		SBCheckError(TElPDFMetricW2_AddRange(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4First, (int32_t)l4Last, (int32_t)l4Width, (int32_t)l4VX, (int32_t)l4VY) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, integer, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFMetricW2, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFMetricW2_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFMetricW2_Add, 0, 0, 4)
	ZEND_ARG_INFO(0, CID)
	ZEND_ARG_INFO(0, Width)
	ZEND_ARG_INFO(0, VX)
	ZEND_ARG_INFO(0, VY)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFMetricW2_AddRange, 0, 0, 5)
	ZEND_ARG_INFO(0, First)
	ZEND_ARG_INFO(0, Last)
	ZEND_ARG_INFO(0, Width)
	ZEND_ARG_INFO(0, VX)
	ZEND_ARG_INFO(0, VY)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFMetricW2___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFMetricW2_methods[] = {
	PHP_ME(TElPDFMetricW2, Add, arginfo_TElPDFMetricW2_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFMetricW2, AddRange, arginfo_TElPDFMetricW2_AddRange, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFMetricW2, __construct, arginfo_TElPDFMetricW2___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFMetricW2(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFMetricW2_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFMetricW2", TElPDFMetricW2_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFMetricW2_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFCIDFont_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFCIDFont, get_CIDSystemInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFCIDFont_get_CIDSystemInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFCIDSystemInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, set_CIDSystemInfo)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPDFCIDSystemInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFCIDFont_set_CIDSystemInfo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFCIDSystemInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, get_FontDescriptor)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFCIDFont_get_FontDescriptor(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFCIDFontDescriptor_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, set_FontDescriptor)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPDFCIDFontDescriptor_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFCIDFont_set_FontDescriptor(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFCIDFontDescriptor)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, get_DW)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFCIDFont_get_DW(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, set_DW)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFCIDFont_set_DW(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, get_W)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFCIDFont_get_W(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFMetricW_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, get_DW2)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBArrayZValInfo aiOutResult;
		SBInitArrayZValInfo(&aiOutResult);
		_err = TElPDFCIDFont_get_DW2(SBGetObjectHandle(getThis() TSRMLS_CC), aiOutResult.data, &aiOutResult.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			aiOutResult.data = emalloc(aiOutResult.len);
			aiOutResult.ownData = 1;
			SBCheckError(SBGetLastReturnBuffer(2118271612, 1, aiOutResult.data, &aiOutResult.len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiOutResult);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetInt32ArrayToZVal(&aiOutResult, return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, set_DW2)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetInt32ArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFCIDFont_set_DW2(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of int32|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, get_W2)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFCIDFont_get_W2(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFMetricW2_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, set_W2)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPDFMetricW2_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFCIDFont_set_W2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFMetricW2)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, get_CIDToGIDMap)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFCIDFont_get_CIDToGIDMap(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(336015422, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, set_CIDToGIDMap)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFCIDFont_set_CIDToGIDMap(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, get_CIDToGIDMapData)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPDFCIDFont_get_CIDToGIDMapData(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1300343801, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, set_CIDToGIDMapData)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFCIDFont_set_CIDToGIDMapData(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFCIDFont, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFCIDFont_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_get_CIDSystemInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_set_CIDSystemInfo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPDFCIDSystemInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_get_FontDescriptor, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_set_FontDescriptor, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPDFCIDFontDescriptor, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_get_DW, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_set_DW, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_get_W, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_get_DW2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_set_DW2, 0, 0, 1)
	ZEND_ARG_ARRAY_INFO(0, Value, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_get_W2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_set_W2, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPDFMetricW2, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_get_CIDToGIDMap, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_set_CIDToGIDMap, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_get_CIDToGIDMapData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont_set_CIDToGIDMapData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFCIDFont___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFCIDFont_methods[] = {
	PHP_ME(TElPDFCIDFont, get_CIDSystemInfo, arginfo_TElPDFCIDFont_get_CIDSystemInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, set_CIDSystemInfo, arginfo_TElPDFCIDFont_set_CIDSystemInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, get_FontDescriptor, arginfo_TElPDFCIDFont_get_FontDescriptor, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, set_FontDescriptor, arginfo_TElPDFCIDFont_set_FontDescriptor, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, get_DW, arginfo_TElPDFCIDFont_get_DW, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, set_DW, arginfo_TElPDFCIDFont_set_DW, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, get_W, arginfo_TElPDFCIDFont_get_W, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, get_DW2, arginfo_TElPDFCIDFont_get_DW2, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, set_DW2, arginfo_TElPDFCIDFont_set_DW2, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, get_W2, arginfo_TElPDFCIDFont_get_W2, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, set_W2, arginfo_TElPDFCIDFont_set_W2, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, get_CIDToGIDMap, arginfo_TElPDFCIDFont_get_CIDToGIDMap, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, set_CIDToGIDMap, arginfo_TElPDFCIDFont_set_CIDToGIDMap, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, get_CIDToGIDMapData, arginfo_TElPDFCIDFont_get_CIDToGIDMapData, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, set_CIDToGIDMapData, arginfo_TElPDFCIDFont_set_CIDToGIDMapData, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFCIDFont, __construct, arginfo_TElPDFCIDFont___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFCIDFont(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFCIDFont_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFCIDFont", TElPDFCIDFont_methods);
	if (NULL == TElPDFCustomFont_ce_ptr)
		Register_TElPDFCustomFont(TSRMLS_C);
	TElPDFCIDFont_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPDFCustomFont_ce_ptr);
}

zend_class_entry *TElPDFSignatureWidgetText_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFSignatureWidgetText, get_Text)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureWidgetText_get_Text(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-275365401, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetText, set_Text)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetText_set_Text(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetText, get_FontSizeX)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFSignatureWidgetText_get_FontSizeX(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetText, set_FontSizeX)
{
	double dValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "d", &dValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetText_set_FontSizeX(SBGetObjectHandle(getThis() TSRMLS_CC), (double)dValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetText, get_FontSizeY)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFSignatureWidgetText_get_FontSizeY(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetText, set_FontSizeY)
{
	double dValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "d", &dValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetText_set_FontSizeY(SBGetObjectHandle(getThis() TSRMLS_CC), (double)dValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetText, get_X)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFSignatureWidgetText_get_X(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetText, set_X)
{
	double dValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "d", &dValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetText_set_X(SBGetObjectHandle(getThis() TSRMLS_CC), (double)dValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetText, get_Y)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFSignatureWidgetText_get_Y(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetText, set_Y)
{
	double dValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "d", &dValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetText_set_Y(SBGetObjectHandle(getThis() TSRMLS_CC), (double)dValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetText, get_FontResourceName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureWidgetText_get_FontResourceName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1791938801, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetText, set_FontResourceName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetText_set_FontResourceName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetText, get_CustomData)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureWidgetText_get_CustomData(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-736478558, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetText, set_CustomData)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetText_set_CustomData(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetText, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignatureWidgetText_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText_get_Text, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText_set_Text, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText_get_FontSizeX, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText_set_FontSizeX, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText_get_FontSizeY, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText_set_FontSizeY, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText_get_X, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText_set_X, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText_get_Y, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText_set_Y, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText_get_FontResourceName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText_set_FontResourceName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText_get_CustomData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText_set_CustomData, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetText___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFSignatureWidgetText_methods[] = {
	PHP_ME(TElPDFSignatureWidgetText, get_Text, arginfo_TElPDFSignatureWidgetText_get_Text, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetText, set_Text, arginfo_TElPDFSignatureWidgetText_set_Text, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetText, get_FontSizeX, arginfo_TElPDFSignatureWidgetText_get_FontSizeX, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetText, set_FontSizeX, arginfo_TElPDFSignatureWidgetText_set_FontSizeX, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetText, get_FontSizeY, arginfo_TElPDFSignatureWidgetText_get_FontSizeY, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetText, set_FontSizeY, arginfo_TElPDFSignatureWidgetText_set_FontSizeY, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetText, get_X, arginfo_TElPDFSignatureWidgetText_get_X, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetText, set_X, arginfo_TElPDFSignatureWidgetText_set_X, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetText, get_Y, arginfo_TElPDFSignatureWidgetText_get_Y, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetText, set_Y, arginfo_TElPDFSignatureWidgetText_set_Y, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetText, get_FontResourceName, arginfo_TElPDFSignatureWidgetText_get_FontResourceName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetText, set_FontResourceName, arginfo_TElPDFSignatureWidgetText_set_FontResourceName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetText, get_CustomData, arginfo_TElPDFSignatureWidgetText_get_CustomData, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetText, set_CustomData, arginfo_TElPDFSignatureWidgetText_set_CustomData, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetText, __construct, arginfo_TElPDFSignatureWidgetText___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFSignatureWidgetText(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFSignatureWidgetText_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFSignatureWidgetText", TElPDFSignatureWidgetText_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFSignatureWidgetText_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFSignatureWidgetTextList_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFSignatureWidgetTextList, Add)
{
	char *sText;
	double dFontSize;
	double dFontSizeX;
	double dFontSizeY;
	double dX;
	double dY;
	sb_str_size sText_len;
	zval *oATextData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sddd", &sText, &sText_len, &dX, &dY, &dFontSize) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetTextList_Add(SBGetObjectHandle(getThis() TSRMLS_CC), sText, (int32_t)sText_len, (double)dX, (double)dY, (double)dFontSize, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sdddd", &sText, &sText_len, &dX, &dY, &dFontSizeX, &dFontSizeY) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetTextList_Add_1(SBGetObjectHandle(getThis() TSRMLS_CC), sText, (int32_t)sText_len, (double)dX, (double)dY, (double)dFontSizeX, (double)dFontSizeY, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oATextData, TElPDFSignatureWidgetText_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetTextList_Add_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oATextData TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetTextList_Add_3(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, double, double, double) or (string, double, double, double, double) or (\\TElPDFSignatureWidgetText) or ()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetTextList, Delete)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetTextList_Delete(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetTextList, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetTextList_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetTextList, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetTextList_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetTextList, get_TextData)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignatureWidgetTextList_get_TextData(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFSignatureWidgetText_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetTextList, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignatureWidgetTextList_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetTextList_Add, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, Text_or_ATextData, 0, 1)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(0, Y)
	ZEND_ARG_INFO(0, FontSize_or_FontSizeX)
	ZEND_ARG_INFO(0, FontSizeY)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetTextList_Delete, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetTextList_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetTextList_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetTextList_get_TextData, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetTextList___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFSignatureWidgetTextList_methods[] = {
	PHP_ME(TElPDFSignatureWidgetTextList, Add, arginfo_TElPDFSignatureWidgetTextList_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetTextList, Delete, arginfo_TElPDFSignatureWidgetTextList_Delete, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetTextList, Clear, arginfo_TElPDFSignatureWidgetTextList_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetTextList, get_Count, arginfo_TElPDFSignatureWidgetTextList_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetTextList, get_TextData, arginfo_TElPDFSignatureWidgetTextList_get_TextData, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetTextList, __construct, arginfo_TElPDFSignatureWidgetTextList___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFSignatureWidgetTextList(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFSignatureWidgetTextList_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFSignatureWidgetTextList", TElPDFSignatureWidgetTextList_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFSignatureWidgetTextList_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFSignatureWidgetProps_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFSignatureWidgetProps, AddFont)
{
	zval *oFont;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oFont, TElPDFCustomFont_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_AddFont(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oFont TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFCustomFont)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, AddFontObject)
{
	zval *oFontObject;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oFontObject, TElPDFCustomFontObject_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_AddFontObject(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oFontObject TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFCustomFontObject)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, AddImage)
{
	double dSizeX;
	double dSizeY;
	double dX;
	double dY;
	zval *oImage;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oImage, TElPDFImage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_AddImage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oImage TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!dddd", &oImage, TElPDFImage_ce_ptr, &dX, &dY, &dSizeX, &dSizeY) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_AddImage_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oImage TSRMLS_CC), (double)dX, (double)dY, (double)dSizeX, (double)dSizeY) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFImage) or (\\TElPDFImage, double, double, double, double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, ClearFonts)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_ClearFonts(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, ClearFontObjects)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_ClearFontObjects(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, ClearImages)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_ClearImages(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_AlgorithmInfo)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureWidgetProps_get_AlgorithmInfo(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1546345732, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_AlgorithmInfo)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_AlgorithmInfo(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_AutoAdjustEncoding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_AutoAdjustEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_AutoAdjustEncoding)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_AutoAdjustEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_AutoText)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_AutoText(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_AutoText)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_AutoText(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_AutoFontSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_AutoFontSize(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_AutoFontSize)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_AutoFontSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_AutoSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_AutoSize(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_AutoSize)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_AutoSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_AutoPos)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_AutoPos(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_AutoPos)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_AutoPos(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_AutoStretchBackground)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_AutoStretchBackground(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_AutoStretchBackground)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_AutoStretchBackground(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_Header)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureWidgetProps_get_Header(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(795439122, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_Header)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_Header(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_Height)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_Height(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_Height)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_Height(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_Locked)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_Locked(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_Locked)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_Locked(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_LockedContents)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_LockedContents(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_LockedContents)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_LockedContents(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_NoRotate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_NoRotate(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_NoRotate)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_NoRotate(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_NoView)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_NoView(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_NoView)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_NoView(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_NoZoom)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_NoZoom(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_NoZoom)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_NoZoom(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_Print)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_Print(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_Print)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_Print(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_ReadOnly)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_ReadOnly(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_ReadOnly)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_ReadOnly(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_ToggleNoView)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_ToggleNoView(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_ToggleNoView)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_ToggleNoView(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_ShowTimestamp)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_ShowTimestamp(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_ShowTimestamp)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_ShowTimestamp(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_SignerInfo)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureWidgetProps_get_SignerInfo(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1600814012, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_SignerInfo)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_SignerInfo(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_Width)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_Width(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_Width)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_Width(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_OffsetX)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_OffsetX(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_OffsetX)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_OffsetX(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_OffsetY)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_OffsetY(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_OffsetY)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_OffsetY(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_TitleFontSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFSignatureWidgetProps_get_TitleFontSize(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_TitleFontSize)
{
	double dValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "d", &dValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_TitleFontSize(SBGetObjectHandle(getThis() TSRMLS_CC), (double)dValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_TimestampFontSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFSignatureWidgetProps_get_TimestampFontSize(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_TimestampFontSize)
{
	double dValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "d", &dValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_TimestampFontSize(SBGetObjectHandle(getThis() TSRMLS_CC), (double)dValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_SectionTitleFontSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFSignatureWidgetProps_get_SectionTitleFontSize(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_SectionTitleFontSize)
{
	double dValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "d", &dValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_SectionTitleFontSize(SBGetObjectHandle(getThis() TSRMLS_CC), (double)dValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_SectionTextFontSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFSignatureWidgetProps_get_SectionTextFontSize(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_SectionTextFontSize)
{
	double dValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "d", &dValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_SectionTextFontSize(SBGetObjectHandle(getThis() TSRMLS_CC), (double)dValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_Background)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignatureWidgetProps_get_Background(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFImage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_BackgroundStyle)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFWidgetBackgroundStyleRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_BackgroundStyle(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_BackgroundStyle)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_BackgroundStyle(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFWidgetBackgroundStyleRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_StretchX)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFSignatureWidgetProps_get_StretchX(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_StretchX)
{
	double dValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "d", &dValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_StretchX(SBGetObjectHandle(getThis() TSRMLS_CC), (double)dValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_StretchY)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFSignatureWidgetProps_get_StretchY(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_StretchY)
{
	double dValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "d", &dValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_StretchY(SBGetObjectHandle(getThis() TSRMLS_CC), (double)dValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(double)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_Rotate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_Rotate(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_Rotate)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_Rotate(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_SignerCaption)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureWidgetProps_get_SignerCaption(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1695642745, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_SignerCaption)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_SignerCaption(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_AlgorithmCaption)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureWidgetProps_get_AlgorithmCaption(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1817782770, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_AlgorithmCaption)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_AlgorithmCaption(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_DateCaptionFormat)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureWidgetProps_get_DateCaptionFormat(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1481499612, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_DateCaptionFormat)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_DateCaptionFormat(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_CustomAppearance)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPDFSignatureWidgetProps_get_CustomAppearance(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-644433066, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_CustomAppearance)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFSignatureWidgetProps_set_CustomAppearance(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_CustomText)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignatureWidgetProps_get_CustomText(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFSignatureWidgetTextList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_HideDefaultText)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_HideDefaultText(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_HideDefaultText)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_HideDefaultText(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_CompressWidgetData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_CompressWidgetData(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_CompressWidgetData)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_CompressWidgetData(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_CustomBackgroundContentStream)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureWidgetProps_get_CustomBackgroundContentStream(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-197378615, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_CustomBackgroundContentStream)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_CustomBackgroundContentStream(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_ShowVisualStatus)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_ShowVisualStatus(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_ShowVisualStatus)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_ShowVisualStatus(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_CustomVisualStatusMatrix)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureWidgetProps_get_CustomVisualStatusMatrix(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(413712805, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_CustomVisualStatusMatrix)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_CustomVisualStatusMatrix(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_SigningTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_SigningTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_SigningTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_SigningTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_IgnoreExistingAppearance)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_IgnoreExistingAppearance(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_IgnoreExistingAppearance)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_IgnoreExistingAppearance(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_ShowOnAllPages)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_ShowOnAllPages(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_ShowOnAllPages)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_ShowOnAllPages(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_PagesToPlaceOn)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_PagesToPlaceOn(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_PagesToPlaceOn)
{
	sb_zend_long l4Index;
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &l4Index, &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_PagesToPlaceOn(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_SaveStringsInUnicodeEncoding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureWidgetProps_get_SaveStringsInUnicodeEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_SaveStringsInUnicodeEncoding)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFSignatureWidgetProps_set_SaveStringsInUnicodeEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_OnConvertStringToAnsi)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFConvertStringToAnsiEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPDFSignatureWidgetProps_get_OnConvertStringToAnsi(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_OnConvertStringToAnsi)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPDFSignatureWidgetProps_set_OnConvertStringToAnsi(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPDFConvertStringToAnsiEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPDFConvertStringToAnsiEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_OnLookupGlyphName)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFLookupGlyphNameEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPDFSignatureWidgetProps_get_OnLookupGlyphName(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_OnLookupGlyphName)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPDFSignatureWidgetProps_set_OnLookupGlyphName(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPDFLookupGlyphNameEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPDFLookupGlyphNameEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, get_OnLookupGlyphWidth)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFLookupGlyphWidthEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPDFSignatureWidgetProps_get_OnLookupGlyphWidth(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, set_OnLookupGlyphWidth)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPDFSignatureWidgetProps_set_OnLookupGlyphWidth(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPDFLookupGlyphWidthEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPDFLookupGlyphWidthEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureWidgetProps, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TElPDFSignature_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignatureWidgetProps_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFSignature)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_AddFont, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Font, TElPDFCustomFont, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_AddFontObject, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, FontObject, TElPDFCustomFontObject, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_AddImage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Image, TElPDFImage, 1)
	ZEND_ARG_INFO(0, X)
	ZEND_ARG_INFO(0, Y)
	ZEND_ARG_INFO(0, SizeX)
	ZEND_ARG_INFO(0, SizeY)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_ClearFonts, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_ClearFontObjects, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_ClearImages, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_AlgorithmInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_AlgorithmInfo, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_AutoAdjustEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_AutoAdjustEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_AutoText, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_AutoText, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_AutoFontSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_AutoFontSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_AutoSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_AutoSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_AutoPos, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_AutoPos, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_AutoStretchBackground, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_AutoStretchBackground, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_Header, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_Header, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_Height, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_Height, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_Locked, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_Locked, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_LockedContents, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_LockedContents, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_NoRotate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_NoRotate, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_NoView, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_NoView, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_NoZoom, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_NoZoom, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_Print, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_Print, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_ReadOnly, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_ReadOnly, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_ToggleNoView, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_ToggleNoView, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_ShowTimestamp, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_ShowTimestamp, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_SignerInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_SignerInfo, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_Width, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_Width, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_OffsetX, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_OffsetX, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_OffsetY, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_OffsetY, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_TitleFontSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_TitleFontSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_TimestampFontSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_TimestampFontSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_SectionTitleFontSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_SectionTitleFontSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_SectionTextFontSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_SectionTextFontSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_Background, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_BackgroundStyle, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_BackgroundStyle, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_StretchX, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_StretchX, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_StretchY, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_StretchY, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_Rotate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_Rotate, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_SignerCaption, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_SignerCaption, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_AlgorithmCaption, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_AlgorithmCaption, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_DateCaptionFormat, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_DateCaptionFormat, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_CustomAppearance, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_CustomAppearance, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_CustomText, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_HideDefaultText, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_HideDefaultText, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_CompressWidgetData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_CompressWidgetData, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_CustomBackgroundContentStream, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_CustomBackgroundContentStream, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_ShowVisualStatus, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_ShowVisualStatus, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_CustomVisualStatusMatrix, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_CustomVisualStatusMatrix, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_SigningTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_SigningTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_IgnoreExistingAppearance, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_IgnoreExistingAppearance, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_ShowOnAllPages, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_ShowOnAllPages, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_PagesToPlaceOn, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_PagesToPlaceOn, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_SaveStringsInUnicodeEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_SaveStringsInUnicodeEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_OnConvertStringToAnsi, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_OnConvertStringToAnsi, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_OnLookupGlyphName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_OnLookupGlyphName, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_get_OnLookupGlyphWidth, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps_set_OnLookupGlyphWidth, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureWidgetProps___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TElPDFSignature, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFSignatureWidgetProps_methods[] = {
	PHP_ME(TElPDFSignatureWidgetProps, AddFont, arginfo_TElPDFSignatureWidgetProps_AddFont, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, AddFontObject, arginfo_TElPDFSignatureWidgetProps_AddFontObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, AddImage, arginfo_TElPDFSignatureWidgetProps_AddImage, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, ClearFonts, arginfo_TElPDFSignatureWidgetProps_ClearFonts, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, ClearFontObjects, arginfo_TElPDFSignatureWidgetProps_ClearFontObjects, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, ClearImages, arginfo_TElPDFSignatureWidgetProps_ClearImages, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_AlgorithmInfo, arginfo_TElPDFSignatureWidgetProps_get_AlgorithmInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_AlgorithmInfo, arginfo_TElPDFSignatureWidgetProps_set_AlgorithmInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_AutoAdjustEncoding, arginfo_TElPDFSignatureWidgetProps_get_AutoAdjustEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_AutoAdjustEncoding, arginfo_TElPDFSignatureWidgetProps_set_AutoAdjustEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_AutoText, arginfo_TElPDFSignatureWidgetProps_get_AutoText, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_AutoText, arginfo_TElPDFSignatureWidgetProps_set_AutoText, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_AutoFontSize, arginfo_TElPDFSignatureWidgetProps_get_AutoFontSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_AutoFontSize, arginfo_TElPDFSignatureWidgetProps_set_AutoFontSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_AutoSize, arginfo_TElPDFSignatureWidgetProps_get_AutoSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_AutoSize, arginfo_TElPDFSignatureWidgetProps_set_AutoSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_AutoPos, arginfo_TElPDFSignatureWidgetProps_get_AutoPos, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_AutoPos, arginfo_TElPDFSignatureWidgetProps_set_AutoPos, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_AutoStretchBackground, arginfo_TElPDFSignatureWidgetProps_get_AutoStretchBackground, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_AutoStretchBackground, arginfo_TElPDFSignatureWidgetProps_set_AutoStretchBackground, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_Header, arginfo_TElPDFSignatureWidgetProps_get_Header, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_Header, arginfo_TElPDFSignatureWidgetProps_set_Header, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_Height, arginfo_TElPDFSignatureWidgetProps_get_Height, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_Height, arginfo_TElPDFSignatureWidgetProps_set_Height, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_Locked, arginfo_TElPDFSignatureWidgetProps_get_Locked, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_Locked, arginfo_TElPDFSignatureWidgetProps_set_Locked, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_LockedContents, arginfo_TElPDFSignatureWidgetProps_get_LockedContents, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_LockedContents, arginfo_TElPDFSignatureWidgetProps_set_LockedContents, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_NoRotate, arginfo_TElPDFSignatureWidgetProps_get_NoRotate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_NoRotate, arginfo_TElPDFSignatureWidgetProps_set_NoRotate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_NoView, arginfo_TElPDFSignatureWidgetProps_get_NoView, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_NoView, arginfo_TElPDFSignatureWidgetProps_set_NoView, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_NoZoom, arginfo_TElPDFSignatureWidgetProps_get_NoZoom, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_NoZoom, arginfo_TElPDFSignatureWidgetProps_set_NoZoom, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_Print, arginfo_TElPDFSignatureWidgetProps_get_Print, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_Print, arginfo_TElPDFSignatureWidgetProps_set_Print, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_ReadOnly, arginfo_TElPDFSignatureWidgetProps_get_ReadOnly, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_ReadOnly, arginfo_TElPDFSignatureWidgetProps_set_ReadOnly, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_ToggleNoView, arginfo_TElPDFSignatureWidgetProps_get_ToggleNoView, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_ToggleNoView, arginfo_TElPDFSignatureWidgetProps_set_ToggleNoView, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_ShowTimestamp, arginfo_TElPDFSignatureWidgetProps_get_ShowTimestamp, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_ShowTimestamp, arginfo_TElPDFSignatureWidgetProps_set_ShowTimestamp, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_SignerInfo, arginfo_TElPDFSignatureWidgetProps_get_SignerInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_SignerInfo, arginfo_TElPDFSignatureWidgetProps_set_SignerInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_Width, arginfo_TElPDFSignatureWidgetProps_get_Width, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_Width, arginfo_TElPDFSignatureWidgetProps_set_Width, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_OffsetX, arginfo_TElPDFSignatureWidgetProps_get_OffsetX, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_OffsetX, arginfo_TElPDFSignatureWidgetProps_set_OffsetX, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_OffsetY, arginfo_TElPDFSignatureWidgetProps_get_OffsetY, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_OffsetY, arginfo_TElPDFSignatureWidgetProps_set_OffsetY, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_TitleFontSize, arginfo_TElPDFSignatureWidgetProps_get_TitleFontSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_TitleFontSize, arginfo_TElPDFSignatureWidgetProps_set_TitleFontSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_TimestampFontSize, arginfo_TElPDFSignatureWidgetProps_get_TimestampFontSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_TimestampFontSize, arginfo_TElPDFSignatureWidgetProps_set_TimestampFontSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_SectionTitleFontSize, arginfo_TElPDFSignatureWidgetProps_get_SectionTitleFontSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_SectionTitleFontSize, arginfo_TElPDFSignatureWidgetProps_set_SectionTitleFontSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_SectionTextFontSize, arginfo_TElPDFSignatureWidgetProps_get_SectionTextFontSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_SectionTextFontSize, arginfo_TElPDFSignatureWidgetProps_set_SectionTextFontSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_Background, arginfo_TElPDFSignatureWidgetProps_get_Background, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_BackgroundStyle, arginfo_TElPDFSignatureWidgetProps_get_BackgroundStyle, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_BackgroundStyle, arginfo_TElPDFSignatureWidgetProps_set_BackgroundStyle, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_StretchX, arginfo_TElPDFSignatureWidgetProps_get_StretchX, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_StretchX, arginfo_TElPDFSignatureWidgetProps_set_StretchX, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_StretchY, arginfo_TElPDFSignatureWidgetProps_get_StretchY, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_StretchY, arginfo_TElPDFSignatureWidgetProps_set_StretchY, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_Rotate, arginfo_TElPDFSignatureWidgetProps_get_Rotate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_Rotate, arginfo_TElPDFSignatureWidgetProps_set_Rotate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_SignerCaption, arginfo_TElPDFSignatureWidgetProps_get_SignerCaption, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_SignerCaption, arginfo_TElPDFSignatureWidgetProps_set_SignerCaption, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_AlgorithmCaption, arginfo_TElPDFSignatureWidgetProps_get_AlgorithmCaption, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_AlgorithmCaption, arginfo_TElPDFSignatureWidgetProps_set_AlgorithmCaption, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_DateCaptionFormat, arginfo_TElPDFSignatureWidgetProps_get_DateCaptionFormat, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_DateCaptionFormat, arginfo_TElPDFSignatureWidgetProps_set_DateCaptionFormat, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_CustomAppearance, arginfo_TElPDFSignatureWidgetProps_get_CustomAppearance, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_CustomAppearance, arginfo_TElPDFSignatureWidgetProps_set_CustomAppearance, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_CustomText, arginfo_TElPDFSignatureWidgetProps_get_CustomText, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_HideDefaultText, arginfo_TElPDFSignatureWidgetProps_get_HideDefaultText, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_HideDefaultText, arginfo_TElPDFSignatureWidgetProps_set_HideDefaultText, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_CompressWidgetData, arginfo_TElPDFSignatureWidgetProps_get_CompressWidgetData, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_CompressWidgetData, arginfo_TElPDFSignatureWidgetProps_set_CompressWidgetData, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_CustomBackgroundContentStream, arginfo_TElPDFSignatureWidgetProps_get_CustomBackgroundContentStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_CustomBackgroundContentStream, arginfo_TElPDFSignatureWidgetProps_set_CustomBackgroundContentStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_ShowVisualStatus, arginfo_TElPDFSignatureWidgetProps_get_ShowVisualStatus, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_ShowVisualStatus, arginfo_TElPDFSignatureWidgetProps_set_ShowVisualStatus, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_CustomVisualStatusMatrix, arginfo_TElPDFSignatureWidgetProps_get_CustomVisualStatusMatrix, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_CustomVisualStatusMatrix, arginfo_TElPDFSignatureWidgetProps_set_CustomVisualStatusMatrix, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_SigningTime, arginfo_TElPDFSignatureWidgetProps_get_SigningTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_SigningTime, arginfo_TElPDFSignatureWidgetProps_set_SigningTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_IgnoreExistingAppearance, arginfo_TElPDFSignatureWidgetProps_get_IgnoreExistingAppearance, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_IgnoreExistingAppearance, arginfo_TElPDFSignatureWidgetProps_set_IgnoreExistingAppearance, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_ShowOnAllPages, arginfo_TElPDFSignatureWidgetProps_get_ShowOnAllPages, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_ShowOnAllPages, arginfo_TElPDFSignatureWidgetProps_set_ShowOnAllPages, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_PagesToPlaceOn, arginfo_TElPDFSignatureWidgetProps_get_PagesToPlaceOn, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_PagesToPlaceOn, arginfo_TElPDFSignatureWidgetProps_set_PagesToPlaceOn, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_SaveStringsInUnicodeEncoding, arginfo_TElPDFSignatureWidgetProps_get_SaveStringsInUnicodeEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_SaveStringsInUnicodeEncoding, arginfo_TElPDFSignatureWidgetProps_set_SaveStringsInUnicodeEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_OnConvertStringToAnsi, arginfo_TElPDFSignatureWidgetProps_get_OnConvertStringToAnsi, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_OnConvertStringToAnsi, arginfo_TElPDFSignatureWidgetProps_set_OnConvertStringToAnsi, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_OnLookupGlyphName, arginfo_TElPDFSignatureWidgetProps_get_OnLookupGlyphName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_OnLookupGlyphName, arginfo_TElPDFSignatureWidgetProps_set_OnLookupGlyphName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, get_OnLookupGlyphWidth, arginfo_TElPDFSignatureWidgetProps_get_OnLookupGlyphWidth, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, set_OnLookupGlyphWidth, arginfo_TElPDFSignatureWidgetProps_set_OnLookupGlyphWidth, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureWidgetProps, __construct, arginfo_TElPDFSignatureWidgetProps___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFSignatureWidgetProps(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFSignatureWidgetProps_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFSignatureWidgetProps", TElPDFSignatureWidgetProps_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFSignatureWidgetProps_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFSignatureInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFSignatureInfo, get_FieldName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureInfo_get_FieldName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-999789477, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_FieldFlags)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFFieldFlagsRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSignatureInfo_get_FieldFlags(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_MappingName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureInfo_get_MappingName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1371549705, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_AlternateName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureInfo_get_AlternateName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-948889422, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_RequiredConstraints)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSVDConstraintsRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSignatureInfo_get_RequiredConstraints(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_RequiredFilter)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureInfo_get_RequiredFilter(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1440386764, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_RequiredSubfilters)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignatureInfo_get_RequiredSubfilters(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_RequiredDigestAlgorithms)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBArrayZValInfo aiOutResult;
		SBInitArrayZValInfo(&aiOutResult);
		_err = TElPDFSignatureInfo_get_RequiredDigestAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), aiOutResult.data, &aiOutResult.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			aiOutResult.data = emalloc(aiOutResult.len);
			aiOutResult.ownData = 1;
			SBCheckError(SBGetLastReturnBuffer(-2058563343, 1, aiOutResult.data, &aiOutResult.len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiOutResult);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetInt32ArrayToZVal(&aiOutResult, return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_RequiredReasons)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignatureInfo_get_RequiredReasons(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_RequiredLockAction)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFFieldMDPActionRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSignatureInfo_get_RequiredLockAction(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_RequiredLockFields)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignatureInfo_get_RequiredLockFields(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_RequiredAllowedChanges)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFSignatureAllowedChangesRaw fOutResultRaw = 0;
		SBCheckError(TElPDFSignatureInfo_get_RequiredAllowedChanges(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_TSPURL)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFSignatureInfo_get_TSPURL(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1048106252, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_TimestampRequired)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureInfo_get_TimestampRequired(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_LegalAttestations)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignatureInfo_get_LegalAttestations(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_AddRevInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureInfo_get_AddRevInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_Height)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureInfo_get_Height(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_Width)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureInfo_get_Width(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_OffsetX)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureInfo_get_OffsetX(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_OffsetY)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureInfo_get_OffsetY(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_Page)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFSignatureInfo_get_Page(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, get_Invisible)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFSignatureInfo_get_Invisible(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFSignatureInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFSignatureInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_FieldName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_FieldFlags, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_MappingName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_AlternateName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_RequiredConstraints, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_RequiredFilter, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_RequiredSubfilters, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_RequiredDigestAlgorithms, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_RequiredReasons, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_RequiredLockAction, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_RequiredLockFields, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_RequiredAllowedChanges, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_TSPURL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_TimestampRequired, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_LegalAttestations, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_AddRevInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_Height, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_Width, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_OffsetX, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_OffsetY, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_Page, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo_get_Invisible, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFSignatureInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFSignatureInfo_methods[] = {
	PHP_ME(TElPDFSignatureInfo, get_FieldName, arginfo_TElPDFSignatureInfo_get_FieldName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_FieldFlags, arginfo_TElPDFSignatureInfo_get_FieldFlags, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_MappingName, arginfo_TElPDFSignatureInfo_get_MappingName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_AlternateName, arginfo_TElPDFSignatureInfo_get_AlternateName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_RequiredConstraints, arginfo_TElPDFSignatureInfo_get_RequiredConstraints, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_RequiredFilter, arginfo_TElPDFSignatureInfo_get_RequiredFilter, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_RequiredSubfilters, arginfo_TElPDFSignatureInfo_get_RequiredSubfilters, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_RequiredDigestAlgorithms, arginfo_TElPDFSignatureInfo_get_RequiredDigestAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_RequiredReasons, arginfo_TElPDFSignatureInfo_get_RequiredReasons, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_RequiredLockAction, arginfo_TElPDFSignatureInfo_get_RequiredLockAction, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_RequiredLockFields, arginfo_TElPDFSignatureInfo_get_RequiredLockFields, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_RequiredAllowedChanges, arginfo_TElPDFSignatureInfo_get_RequiredAllowedChanges, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_TSPURL, arginfo_TElPDFSignatureInfo_get_TSPURL, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_TimestampRequired, arginfo_TElPDFSignatureInfo_get_TimestampRequired, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_LegalAttestations, arginfo_TElPDFSignatureInfo_get_LegalAttestations, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_AddRevInfo, arginfo_TElPDFSignatureInfo_get_AddRevInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_Height, arginfo_TElPDFSignatureInfo_get_Height, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_Width, arginfo_TElPDFSignatureInfo_get_Width, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_OffsetX, arginfo_TElPDFSignatureInfo_get_OffsetX, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_OffsetY, arginfo_TElPDFSignatureInfo_get_OffsetY, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_Page, arginfo_TElPDFSignatureInfo_get_Page, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, get_Invisible, arginfo_TElPDFSignatureInfo_get_Invisible, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFSignatureInfo, __construct, arginfo_TElPDFSignatureInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFSignatureInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFSignatureInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFSignatureInfo", TElPDFSignatureInfo_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFSignatureInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFEncodingHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFEncodingHandler, GetName_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFEncodingHandler_GetName_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(540965987, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFEncodingHandler, GetName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFEncodingHandler_GetName(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(540965987, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFEncodingHandler, GetDescription_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFEncodingHandler_GetDescription_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2063230971, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFEncodingHandler, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFEncodingHandler_GetDescription(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2063230971, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFEncodingHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFEncodingHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFEncodingHandler, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFEncodingHandler_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFEncodingHandler_GetName_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFEncodingHandler_GetName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFEncodingHandler_GetDescription_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFEncodingHandler_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFEncodingHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFEncodingHandler___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFEncodingHandler_methods[] = {
	PHP_ME(TElPDFEncodingHandler, GetName_Inst, arginfo_TElPDFEncodingHandler_GetName_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFEncodingHandler, GetName, arginfo_TElPDFEncodingHandler_GetName, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPDFEncodingHandler, GetDescription_Inst, arginfo_TElPDFEncodingHandler_GetDescription_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFEncodingHandler, GetDescription, arginfo_TElPDFEncodingHandler_GetDescription, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPDFEncodingHandler, ClassType, arginfo_TElPDFEncodingHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPDFEncodingHandler, __construct, arginfo_TElPDFEncodingHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFEncodingHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFEncodingHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFEncodingHandler", TElPDFEncodingHandler_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFEncodingHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFRequirementHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFRequirementHandler, get_HandlerType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFRequirementHandler_get_HandlerType(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1112122929, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFRequirementHandler, get_ScriptName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFRequirementHandler_get_ScriptName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1291885185, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFRequirementHandler, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFRequirementHandler_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFRequirementHandler_get_HandlerType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFRequirementHandler_get_ScriptName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFRequirementHandler___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFRequirementHandler_methods[] = {
	PHP_ME(TElPDFRequirementHandler, get_HandlerType, arginfo_TElPDFRequirementHandler_get_HandlerType, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFRequirementHandler, get_ScriptName, arginfo_TElPDFRequirementHandler_get_ScriptName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFRequirementHandler, __construct, arginfo_TElPDFRequirementHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFRequirementHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFRequirementHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFRequirementHandler", TElPDFRequirementHandler_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFRequirementHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFRequirement_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFRequirement, get_RequirementType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFRequirement_get_RequirementType(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2136318487, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFRequirement, get_HandlerCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFRequirement_get_HandlerCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFRequirement, get_Handlers)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFRequirement_get_Handlers(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFRequirementHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFRequirement, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFRequirement_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFRequirement_get_RequirementType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFRequirement_get_HandlerCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFRequirement_get_Handlers, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFRequirement___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFRequirement_methods[] = {
	PHP_ME(TElPDFRequirement, get_RequirementType, arginfo_TElPDFRequirement_get_RequirementType, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFRequirement, get_HandlerCount, arginfo_TElPDFRequirement_get_HandlerCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFRequirement, get_Handlers, arginfo_TElPDFRequirement_get_Handlers, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFRequirement, __construct, arginfo_TElPDFRequirement___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFRequirement(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFRequirement_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFRequirement", TElPDFRequirement_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFRequirement_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFPageInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFPageInfo, CropBoxEmpty)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFPageInfo_CropBoxEmpty(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPageInfo, get_Width)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFPageInfo_get_Width(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPageInfo, get_Height)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFPageInfo_get_Height(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPageInfo, get_Rotate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFPageInfo_get_Rotate(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPageInfo, get_CropLLX)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFPageInfo_get_CropLLX(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPageInfo, get_CropLLY)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFPageInfo_get_CropLLY(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPageInfo, get_CropURX)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFPageInfo_get_CropURX(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPageInfo, get_CropURY)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFPageInfo_get_CropURY(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPageInfo, get_MediaLLX)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFPageInfo_get_MediaLLX(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPageInfo, get_MediaLLY)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFPageInfo_get_MediaLLY(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPageInfo, get_MediaURX)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFPageInfo_get_MediaURX(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPageInfo, get_MediaURY)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		double dOutResult = 0.0;
		SBCheckError(TElPDFPageInfo_get_MediaURY(SBGetObjectHandle(getThis() TSRMLS_CC), &dOutResult) TSRMLS_CC);
		RETURN_DOUBLE(dOutResult);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPageInfo, get_PageObject)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFPageInfo_get_PageObject(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFDictionary_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPageInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFPageInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPageInfo_CropBoxEmpty, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPageInfo_get_Width, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPageInfo_get_Height, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPageInfo_get_Rotate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPageInfo_get_CropLLX, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPageInfo_get_CropLLY, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPageInfo_get_CropURX, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPageInfo_get_CropURY, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPageInfo_get_MediaLLX, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPageInfo_get_MediaLLY, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPageInfo_get_MediaURX, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPageInfo_get_MediaURY, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPageInfo_get_PageObject, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPageInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFPageInfo_methods[] = {
	PHP_ME(TElPDFPageInfo, CropBoxEmpty, arginfo_TElPDFPageInfo_CropBoxEmpty, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPageInfo, get_Width, arginfo_TElPDFPageInfo_get_Width, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPageInfo, get_Height, arginfo_TElPDFPageInfo_get_Height, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPageInfo, get_Rotate, arginfo_TElPDFPageInfo_get_Rotate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPageInfo, get_CropLLX, arginfo_TElPDFPageInfo_get_CropLLX, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPageInfo, get_CropLLY, arginfo_TElPDFPageInfo_get_CropLLY, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPageInfo, get_CropURX, arginfo_TElPDFPageInfo_get_CropURX, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPageInfo, get_CropURY, arginfo_TElPDFPageInfo_get_CropURY, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPageInfo, get_MediaLLX, arginfo_TElPDFPageInfo_get_MediaLLX, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPageInfo, get_MediaLLY, arginfo_TElPDFPageInfo_get_MediaLLY, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPageInfo, get_MediaURX, arginfo_TElPDFPageInfo_get_MediaURX, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPageInfo, get_MediaURY, arginfo_TElPDFPageInfo_get_MediaURY, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPageInfo, get_PageObject, arginfo_TElPDFPageInfo_get_PageObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPageInfo, __construct, arginfo_TElPDFPageInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFPageInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFPageInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFPageInfo", TElPDFPageInfo_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFPageInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFFileAttachment_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFFileAttachment, Init)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFFileAttachment_Init(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, Save)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFFileAttachment_Save(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, get_ObjectName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFFileAttachment_get_ObjectName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1007273765, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, set_ObjectName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFFileAttachment_set_ObjectName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, get_Filename)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFFileAttachment_get_Filename(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1190608879, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, set_Filename)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFFileAttachment_set_Filename(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, get_UnicodeFilename)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFFileAttachment_get_UnicodeFilename(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-425671165, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, set_UnicodeFilename)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFFileAttachment_set_UnicodeFilename(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, get_Description)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFFileAttachment_get_Description(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(470980460, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, set_Description)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFFileAttachment_set_Description(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, get_SubType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFFileAttachment_get_SubType(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1674946840, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, set_SubType)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFFileAttachment_set_SubType(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, get_Size)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElPDFFileAttachment_get_Size(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, get_CreationDate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElPDFFileAttachment_get_CreationDate(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, set_CreationDate)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElPDFFileAttachment_set_CreationDate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, get_ModificationDate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElPDFFileAttachment_get_ModificationDate(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, set_ModificationDate)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElPDFFileAttachment_set_ModificationDate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, get_MD5Checksum)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPDFFileAttachment_get_MD5Checksum(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(821951867, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, get_AssociatedFilePDFObject)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFFileAttachment_get_AssociatedFilePDFObject(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPDFDictionary_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, set_AssociatedFilePDFObject)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPDFDictionary_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFFileAttachment_set_AssociatedFilePDFObject(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFDictionary)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, get_AssociatedFileRelationship)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPDFAssociatedFileRelationshipRaw fOutResultRaw = 0;
		SBCheckError(TElPDFFileAttachment_get_AssociatedFileRelationship(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, set_AssociatedFileRelationship)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPDFFileAttachment_set_AssociatedFileRelationship(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPDFAssociatedFileRelationshipRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, get_AssociatedFileRelationshipName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFFileAttachment_get_AssociatedFileRelationshipName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(934492948, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, set_AssociatedFileRelationshipName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFFileAttachment_set_AssociatedFileRelationshipName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFFileAttachment, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFFileAttachment_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_Init, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_Save, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_get_ObjectName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_set_ObjectName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_get_Filename, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_set_Filename, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_get_UnicodeFilename, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_set_UnicodeFilename, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_get_Description, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_set_Description, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_get_SubType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_set_SubType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_get_Size, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_get_CreationDate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_set_CreationDate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_get_ModificationDate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_set_ModificationDate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_get_MD5Checksum, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_get_AssociatedFilePDFObject, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_set_AssociatedFilePDFObject, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPDFDictionary, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_get_AssociatedFileRelationship, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_set_AssociatedFileRelationship, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_get_AssociatedFileRelationshipName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment_set_AssociatedFileRelationshipName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFFileAttachment___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFFileAttachment_methods[] = {
	PHP_ME(TElPDFFileAttachment, Init, arginfo_TElPDFFileAttachment_Init, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, Save, arginfo_TElPDFFileAttachment_Save, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, get_ObjectName, arginfo_TElPDFFileAttachment_get_ObjectName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, set_ObjectName, arginfo_TElPDFFileAttachment_set_ObjectName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, get_Filename, arginfo_TElPDFFileAttachment_get_Filename, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, set_Filename, arginfo_TElPDFFileAttachment_set_Filename, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, get_UnicodeFilename, arginfo_TElPDFFileAttachment_get_UnicodeFilename, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, set_UnicodeFilename, arginfo_TElPDFFileAttachment_set_UnicodeFilename, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, get_Description, arginfo_TElPDFFileAttachment_get_Description, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, set_Description, arginfo_TElPDFFileAttachment_set_Description, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, get_SubType, arginfo_TElPDFFileAttachment_get_SubType, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, set_SubType, arginfo_TElPDFFileAttachment_set_SubType, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, get_Size, arginfo_TElPDFFileAttachment_get_Size, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, get_CreationDate, arginfo_TElPDFFileAttachment_get_CreationDate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, set_CreationDate, arginfo_TElPDFFileAttachment_set_CreationDate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, get_ModificationDate, arginfo_TElPDFFileAttachment_get_ModificationDate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, set_ModificationDate, arginfo_TElPDFFileAttachment_set_ModificationDate, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, get_MD5Checksum, arginfo_TElPDFFileAttachment_get_MD5Checksum, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, get_AssociatedFilePDFObject, arginfo_TElPDFFileAttachment_get_AssociatedFilePDFObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, set_AssociatedFilePDFObject, arginfo_TElPDFFileAttachment_set_AssociatedFilePDFObject, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, get_AssociatedFileRelationship, arginfo_TElPDFFileAttachment_get_AssociatedFileRelationship, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, set_AssociatedFileRelationship, arginfo_TElPDFFileAttachment_set_AssociatedFileRelationship, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, get_AssociatedFileRelationshipName, arginfo_TElPDFFileAttachment_get_AssociatedFileRelationshipName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, set_AssociatedFileRelationshipName, arginfo_TElPDFFileAttachment_set_AssociatedFileRelationshipName, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFFileAttachment, __construct, arginfo_TElPDFFileAttachment___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFFileAttachment(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFFileAttachment_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFFileAttachment", TElPDFFileAttachment_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFFileAttachment_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFLegalContentAttestation_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_JavascriptActions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_JavascriptActions(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_JavascriptActions)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_JavascriptActions(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_LaunchActions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_LaunchActions(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_LaunchActions)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_LaunchActions(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_URIActions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_URIActions(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_URIActions)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_URIActions(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_MovieActions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_MovieActions(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_MovieActions)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_MovieActions(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_SoundActions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_SoundActions(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_SoundActions)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_SoundActions(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_HideAnnotationActions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_HideAnnotationActions(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_HideAnnotationActions)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_HideAnnotationActions(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_GoToRemoteActions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_GoToRemoteActions(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_GoToRemoteActions)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_GoToRemoteActions(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_AlternateImages)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_AlternateImages(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_AlternateImages)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_AlternateImages(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_ExternalStreams)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_ExternalStreams(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_ExternalStreams)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_ExternalStreams(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_TrueTypeFonts)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_TrueTypeFonts(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_TrueTypeFonts)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_TrueTypeFonts(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_ExternalRefXObjects)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_ExternalRefXObjects(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_ExternalRefXObjects)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_ExternalRefXObjects(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_ExternalOPIDicts)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_ExternalOPIDicts(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_ExternalOPIDicts)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_ExternalOPIDicts(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_NonEmbeddedFonts)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_NonEmbeddedFonts(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_NonEmbeddedFonts)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_NonEmbeddedFonts(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_DevDepGSOP)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_DevDepGSOP(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_DevDepGSOP)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_DevDepGSOP(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_DevDepGSHT)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_DevDepGSHT(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_DevDepGSHT)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_DevDepGSHT(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_DevDepGSTR)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_DevDepGSTR(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_DevDepGSTR)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_DevDepGSTR(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_DevDepGSUCR)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_DevDepGSUCR(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_DevDepGSUCR)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_DevDepGSUCR(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_DevDepGSBG)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_DevDepGSBG(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_DevDepGSBG)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_DevDepGSBG(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_DevDepGSFL)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_DevDepGSFL(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_DevDepGSFL)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_DevDepGSFL(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_Annotations)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_Annotations(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_Annotations)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_Annotations(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_OptionalContent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_OptionalContent(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_OptionalContent)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_OptionalContent(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_Attestation)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPDFLegalContentAttestation_get_Attestation(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-859175818, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_Attestation)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_Attestation(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, get_Include)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFLegalContentAttestation_get_Include(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, set_Include)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPDFLegalContentAttestation_set_Include(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFLegalContentAttestation, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFLegalContentAttestation_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_JavascriptActions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_JavascriptActions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_LaunchActions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_LaunchActions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_URIActions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_URIActions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_MovieActions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_MovieActions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_SoundActions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_SoundActions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_HideAnnotationActions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_HideAnnotationActions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_GoToRemoteActions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_GoToRemoteActions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_AlternateImages, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_AlternateImages, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_ExternalStreams, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_ExternalStreams, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_TrueTypeFonts, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_TrueTypeFonts, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_ExternalRefXObjects, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_ExternalRefXObjects, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_ExternalOPIDicts, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_ExternalOPIDicts, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_NonEmbeddedFonts, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_NonEmbeddedFonts, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_DevDepGSOP, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_DevDepGSOP, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_DevDepGSHT, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_DevDepGSHT, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_DevDepGSTR, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_DevDepGSTR, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_DevDepGSUCR, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_DevDepGSUCR, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_DevDepGSBG, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_DevDepGSBG, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_DevDepGSFL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_DevDepGSFL, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_Annotations, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_Annotations, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_OptionalContent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_OptionalContent, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_Attestation, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_Attestation, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_get_Include, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation_set_Include, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFLegalContentAttestation___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFLegalContentAttestation_methods[] = {
	PHP_ME(TElPDFLegalContentAttestation, get_JavascriptActions, arginfo_TElPDFLegalContentAttestation_get_JavascriptActions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_JavascriptActions, arginfo_TElPDFLegalContentAttestation_set_JavascriptActions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_LaunchActions, arginfo_TElPDFLegalContentAttestation_get_LaunchActions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_LaunchActions, arginfo_TElPDFLegalContentAttestation_set_LaunchActions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_URIActions, arginfo_TElPDFLegalContentAttestation_get_URIActions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_URIActions, arginfo_TElPDFLegalContentAttestation_set_URIActions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_MovieActions, arginfo_TElPDFLegalContentAttestation_get_MovieActions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_MovieActions, arginfo_TElPDFLegalContentAttestation_set_MovieActions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_SoundActions, arginfo_TElPDFLegalContentAttestation_get_SoundActions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_SoundActions, arginfo_TElPDFLegalContentAttestation_set_SoundActions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_HideAnnotationActions, arginfo_TElPDFLegalContentAttestation_get_HideAnnotationActions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_HideAnnotationActions, arginfo_TElPDFLegalContentAttestation_set_HideAnnotationActions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_GoToRemoteActions, arginfo_TElPDFLegalContentAttestation_get_GoToRemoteActions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_GoToRemoteActions, arginfo_TElPDFLegalContentAttestation_set_GoToRemoteActions, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_AlternateImages, arginfo_TElPDFLegalContentAttestation_get_AlternateImages, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_AlternateImages, arginfo_TElPDFLegalContentAttestation_set_AlternateImages, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_ExternalStreams, arginfo_TElPDFLegalContentAttestation_get_ExternalStreams, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_ExternalStreams, arginfo_TElPDFLegalContentAttestation_set_ExternalStreams, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_TrueTypeFonts, arginfo_TElPDFLegalContentAttestation_get_TrueTypeFonts, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_TrueTypeFonts, arginfo_TElPDFLegalContentAttestation_set_TrueTypeFonts, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_ExternalRefXObjects, arginfo_TElPDFLegalContentAttestation_get_ExternalRefXObjects, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_ExternalRefXObjects, arginfo_TElPDFLegalContentAttestation_set_ExternalRefXObjects, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_ExternalOPIDicts, arginfo_TElPDFLegalContentAttestation_get_ExternalOPIDicts, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_ExternalOPIDicts, arginfo_TElPDFLegalContentAttestation_set_ExternalOPIDicts, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_NonEmbeddedFonts, arginfo_TElPDFLegalContentAttestation_get_NonEmbeddedFonts, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_NonEmbeddedFonts, arginfo_TElPDFLegalContentAttestation_set_NonEmbeddedFonts, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_DevDepGSOP, arginfo_TElPDFLegalContentAttestation_get_DevDepGSOP, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_DevDepGSOP, arginfo_TElPDFLegalContentAttestation_set_DevDepGSOP, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_DevDepGSHT, arginfo_TElPDFLegalContentAttestation_get_DevDepGSHT, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_DevDepGSHT, arginfo_TElPDFLegalContentAttestation_set_DevDepGSHT, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_DevDepGSTR, arginfo_TElPDFLegalContentAttestation_get_DevDepGSTR, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_DevDepGSTR, arginfo_TElPDFLegalContentAttestation_set_DevDepGSTR, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_DevDepGSUCR, arginfo_TElPDFLegalContentAttestation_get_DevDepGSUCR, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_DevDepGSUCR, arginfo_TElPDFLegalContentAttestation_set_DevDepGSUCR, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_DevDepGSBG, arginfo_TElPDFLegalContentAttestation_get_DevDepGSBG, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_DevDepGSBG, arginfo_TElPDFLegalContentAttestation_set_DevDepGSBG, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_DevDepGSFL, arginfo_TElPDFLegalContentAttestation_get_DevDepGSFL, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_DevDepGSFL, arginfo_TElPDFLegalContentAttestation_set_DevDepGSFL, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_Annotations, arginfo_TElPDFLegalContentAttestation_get_Annotations, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_Annotations, arginfo_TElPDFLegalContentAttestation_set_Annotations, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_OptionalContent, arginfo_TElPDFLegalContentAttestation_get_OptionalContent, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_OptionalContent, arginfo_TElPDFLegalContentAttestation_set_OptionalContent, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_Attestation, arginfo_TElPDFLegalContentAttestation_get_Attestation, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_Attestation, arginfo_TElPDFLegalContentAttestation_set_Attestation, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, get_Include, arginfo_TElPDFLegalContentAttestation_get_Include, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, set_Include, arginfo_TElPDFLegalContentAttestation_set_Include, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFLegalContentAttestation, __construct, arginfo_TElPDFLegalContentAttestation___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFLegalContentAttestation(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFLegalContentAttestation_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFLegalContentAttestation", TElPDFLegalContentAttestation_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFLegalContentAttestation_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPDFPublicKeyRevocationInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, Assign)
{
	zend_bool bClear;
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElPDFPublicKeyRevocationInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPDFPublicKeyRevocationInfo_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oSource, TElPDFPublicKeyRevocationInfo_ce_ptr, &bClear) == SUCCESS)
	{
		SBCheckError(TElPDFPublicKeyRevocationInfo_Assign_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC), (int8_t)bClear) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFPublicKeyRevocationInfo) or (\\TElPDFPublicKeyRevocationInfo, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, AddCRL)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFPublicKeyRevocationInfo_AddCRL(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, RemoveCRL)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElPDFPublicKeyRevocationInfo_RemoveCRL(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, ClearCRLs)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFPublicKeyRevocationInfo_ClearCRLs(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, ContainsCRL)
{
	zval *oCrl;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCrl, TElAbstractCRL_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFPublicKeyRevocationInfo_ContainsCRL(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCrl TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElAbstractCRL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, AddOCSPResponse)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFPublicKeyRevocationInfo_AddOCSPResponse(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, RemoveOCSPResponse)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElPDFPublicKeyRevocationInfo_RemoveOCSPResponse(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, ClearOCSPResponses)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFPublicKeyRevocationInfo_ClearOCSPResponses(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, ContainsOCSPResponse)
{
	SBArrayZValInfo aiResponse;
	zval *zaResponse;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaResponse) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaResponse) || SB_IS_ARRAY_TYPE_RP(zaResponse) || SB_IS_NULL_TYPE_RP(zaResponse)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaResponse, &aiResponse TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFPublicKeyRevocationInfo_ContainsOCSPResponse(SBGetObjectHandle(getThis() TSRMLS_CC), aiResponse.data, aiResponse.len, &bOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiResponse);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPDFPublicKeyRevocationInfo_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, IsEmpty)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPDFPublicKeyRevocationInfo_IsEmpty(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, get_CRLs)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFPublicKeyRevocationInfo_get_CRLs(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElAbstractCRL_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, get_OCSPResponses)
{
	sb_zend_long l4Index;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPDFPublicKeyRevocationInfo_get_OCSPResponses(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-573874016, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, set_OCSPResponses)
{
	sb_zend_long l4Index;
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &l4Index, &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPDFPublicKeyRevocationInfo_set_OCSPResponses(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(integer, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, get_CRLCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFPublicKeyRevocationInfo_get_CRLCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, get_OCSPResponseCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPDFPublicKeyRevocationInfo_get_OCSPResponseCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, get_Certificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFPublicKeyRevocationInfo_get_Certificates(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElMemoryCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, get_OtherInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFPublicKeyRevocationInfo_get_OtherInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElRelativeDistinguishedName_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPDFPublicKeyRevocationInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPDFPublicKeyRevocationInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElPDFPublicKeyRevocationInfo, 1)
	ZEND_ARG_INFO(0, Clear)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_AddCRL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_RemoveCRL, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_ClearCRLs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_ContainsCRL, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Crl, TElAbstractCRL, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_AddOCSPResponse, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_RemoveOCSPResponse, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_ClearOCSPResponses, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_ContainsOCSPResponse, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Response, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_IsEmpty, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_get_CRLs, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_get_OCSPResponses, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_set_OCSPResponses, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_get_CRLCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_get_OCSPResponseCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_get_Certificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo_get_OtherInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPDFPublicKeyRevocationInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPDFPublicKeyRevocationInfo_methods[] = {
	PHP_ME(TElPDFPublicKeyRevocationInfo, Assign, arginfo_TElPDFPublicKeyRevocationInfo_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, AddCRL, arginfo_TElPDFPublicKeyRevocationInfo_AddCRL, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, RemoveCRL, arginfo_TElPDFPublicKeyRevocationInfo_RemoveCRL, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, ClearCRLs, arginfo_TElPDFPublicKeyRevocationInfo_ClearCRLs, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, ContainsCRL, arginfo_TElPDFPublicKeyRevocationInfo_ContainsCRL, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, AddOCSPResponse, arginfo_TElPDFPublicKeyRevocationInfo_AddOCSPResponse, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, RemoveOCSPResponse, arginfo_TElPDFPublicKeyRevocationInfo_RemoveOCSPResponse, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, ClearOCSPResponses, arginfo_TElPDFPublicKeyRevocationInfo_ClearOCSPResponses, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, ContainsOCSPResponse, arginfo_TElPDFPublicKeyRevocationInfo_ContainsOCSPResponse, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, Clear, arginfo_TElPDFPublicKeyRevocationInfo_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, IsEmpty, arginfo_TElPDFPublicKeyRevocationInfo_IsEmpty, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, get_CRLs, arginfo_TElPDFPublicKeyRevocationInfo_get_CRLs, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, get_OCSPResponses, arginfo_TElPDFPublicKeyRevocationInfo_get_OCSPResponses, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, set_OCSPResponses, arginfo_TElPDFPublicKeyRevocationInfo_set_OCSPResponses, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, get_CRLCount, arginfo_TElPDFPublicKeyRevocationInfo_get_CRLCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, get_OCSPResponseCount, arginfo_TElPDFPublicKeyRevocationInfo_get_OCSPResponseCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, get_Certificates, arginfo_TElPDFPublicKeyRevocationInfo_get_Certificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, get_OtherInfo, arginfo_TElPDFPublicKeyRevocationInfo_get_OtherInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPDFPublicKeyRevocationInfo, __construct, arginfo_TElPDFPublicKeyRevocationInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPDFPublicKeyRevocationInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPDFPublicKeyRevocationInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPDFPublicKeyRevocationInfo", TElPDFPublicKeyRevocationInfo_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPDFPublicKeyRevocationInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

SB_PHP_FUNCTION(SBPDF, RegisterSecurityHandler)
{
	zval *oHandlerClass;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oHandlerClass, TElPDFSecurityHandlerClass_ce_ptr) == SUCCESS)
	{
		SBCheckError(SBPDF_RegisterSecurityHandler(SBGetObjectHandle(oHandlerClass TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFSecurityHandlerClass)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPDF, UnregisterSecurityHandler)
{
	zval *oHandlerClass;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oHandlerClass, TElPDFSecurityHandlerClass_ce_ptr) == SUCCESS)
	{
		SBCheckError(SBPDF_UnregisterSecurityHandler(SBGetObjectHandle(oHandlerClass TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPDFSecurityHandlerClass)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPDF, GetPDFStandardType1FontName)
{
	sb_zend_long fFont;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fFont) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBPDF_GetPDFStandardType1FontName((TSBPDFStandardType1FontRaw)fFont, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(482896354, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

void Register_SBPDF_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_STRING_CONSTANT(SBPDF, SPDFNotImplemented, SB_SPDFNotImplemented, SB_SPDFNotImplemented);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SPDFInvalidSecurityHandlerInformation, SB_SPDFInvalidSecurityHandlerInformation, SB_SPDFInvalidSecurityHandlerInformation);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SPDFInvalidPassword, SB_SPDFInvalidPassword, SB_SPDFInvalidPassword);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SPDFNoDecryptionKeyFound, SB_SPDFNoDecryptionKeyFound, SB_SPDFNoDecryptionKeyFound);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SPDFCannotTimestampEncryptedDocument, SB_SPDFCannotTimestampEncryptedDocument, SB_SPDFCannotTimestampEncryptedDocument);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SPDFCannotModifyDocumentAfterSignatureUpdate, SB_SPDFCannotModifyDocumentAfterSignatureUpdate, SB_SPDFCannotModifyDocumentAfterSignatureUpdate);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SPDFCannotUpdateSignatureInEncryptedDocument, SB_SPDFCannotUpdateSignatureInEncryptedDocument, SB_SPDFCannotUpdateSignatureInEncryptedDocument);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SPDFUnsupportedTimestampType, SB_SPDFUnsupportedTimestampType, SB_SPDFUnsupportedTimestampType);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SPDFBadAsyncState, SB_SPDFBadAsyncState, SB_SPDFBadAsyncState);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SPDFSecurityHandlerNotFound, SB_SPDFSecurityHandlerNotFound, SB_SPDFSecurityHandlerNotFound);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SPDFDCModuleUnavailable, SB_SPDFDCModuleUnavailable, SB_SPDFDCModuleUnavailable);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SPDFSignatureSizeEstimatedIncorrectly, SB_SPDFSignatureSizeEstimatedIncorrectly, SB_SPDFSignatureSizeEstimatedIncorrectly);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SPDFCannotChangeDecryptionModePropertyForOpenedDocument, SB_SPDFCannotChangeDecryptionModePropertyForOpenedDocument, SB_SPDFCannotChangeDecryptionModePropertyForOpenedDocument);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SFPDFUnsupportedSecurityHandlerSubfilter, SB_SFPDFUnsupportedSecurityHandlerSubfilter, SB_SFPDFUnsupportedSecurityHandlerSubfilter);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SFPDFInternalError, SB_SFPDFInternalError, SB_SFPDFInternalError);
	SB_REGISTER_STRING_CONSTANT(SBPDF, SFPDFIndexOutOfBounds, SB_SFPDFIndexOutOfBounds, SB_SFPDFIndexOutOfBounds);
}

void Register_SBPDF_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBPDFSignatureType", NULL);
	TSBPDFSignatureType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFSignatureType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureType_ce_ptr, "stDocument", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureType_ce_ptr, "stMDP", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureType_ce_ptr, "stUsageRights", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureType_ce_ptr, "stObject", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureType_ce_ptr, "stUnknown", 4)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFTransformMethod", NULL);
	TSBPDFTransformMethod_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFTransformMethod_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFTransformMethod_ce_ptr, "tmDocMDP", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFTransformMethod_ce_ptr, "tmUR", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFTransformMethod_ce_ptr, "tmUR3", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFTransformMethod_ce_ptr, "tmFieldMDP", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFTransformMethod_ce_ptr, "tmIdentity", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFTransformMethod_ce_ptr, "tmObject", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFTransformMethod_ce_ptr, "tmUnknown", 6)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFDigestMethod", NULL);
	TSBPDFDigestMethod_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFDigestMethod_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFDigestMethod_ce_ptr, "dmMD5", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFDigestMethod_ce_ptr, "dmSHA1", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFDigestMethod_ce_ptr, "dmUnknown", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFFieldMDPAction", NULL);
	TSBPDFFieldMDPAction_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFFieldMDPAction_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFFieldMDPAction_ce_ptr, "fmaAll", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFFieldMDPAction_ce_ptr, "fmaInclude", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFFieldMDPAction_ce_ptr, "fmaExclude", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFFieldMDPAction_ce_ptr, "fmaUnknown", 3)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFDecryptionMode", NULL);
	TSBPDFDecryptionMode_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFDecryptionMode_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFDecryptionMode_ce_ptr, "dmFull", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFDecryptionMode_ce_ptr, "dmOnDemand", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFDecryptionMode_ce_ptr, "dmSign", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFSignatureRemoveOption", NULL);
	TSBPDFSignatureRemoveOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFSignatureRemoveOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureRemoveOption_ce_ptr, "sroFull", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureRemoveOption_ce_ptr, "sroKeepField", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureRemoveOption_ce_ptr, "sroKeepAppearance", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFImageType", NULL);
	TSBPDFImageType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFImageType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFImageType_ce_ptr, "pitJPEG2000", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFImageType_ce_ptr, "pitJPEG", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFImageType_ce_ptr, "pitMask", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFImageType_ce_ptr, "pitMaskInverted", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFImageType_ce_ptr, "pitCustom", 4)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFColorSpaceType", NULL);
	TSBPDFColorSpaceType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFColorSpaceType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFColorSpaceType_ce_ptr, "pcstNone", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFColorSpaceType_ce_ptr, "pcstGray", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFColorSpaceType_ce_ptr, "pcstRGB", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFColorSpaceType_ce_ptr, "pcstCMYK", 3)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFStandardType1Font", NULL);
	TSBPDFStandardType1Font_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFStandardType1Font_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfUnknown", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfHelvetica", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfTimesRoman", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfCourier", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfHelveticaBold", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfTimesBold", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfCourierBold", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfHelveticaOblique", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfTimesItalic", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfCourierOblique", 9)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfHelveticaBoldOblique", 10)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfTimesBoldItalic", 11)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfCourierBoldOblique", 12)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfSymbol", 13)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFStandardType1Font_ce_ptr, "psfZapfDingbats", 14)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFWidgetBackgroundStyle", NULL);
	TSBPDFWidgetBackgroundStyle_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFWidgetBackgroundStyle_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFWidgetBackgroundStyle_ce_ptr, "pbsDefault", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFWidgetBackgroundStyle_ce_ptr, "pbsNoBackground", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFWidgetBackgroundStyle_ce_ptr, "pbsCustom", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFSignatureAllowedChange", NULL);
	TSBPDFSignatureAllowedChange_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFSignatureAllowedChange_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureAllowedChange_ce_ptr, "sacFillInForms", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureAllowedChange_ce_ptr, "sacComment", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFSignatureAllowedChanges", NULL);
	TSBPDFSignatureAllowedChanges_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBPDFSignatureAllowedChanges_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureAllowedChanges_ce_ptr, "sacFillInForms", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureAllowedChanges_ce_ptr, "sacComment", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFSignatureOption", NULL);
	TSBPDFSignatureOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFSignatureOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureOption_ce_ptr, "psoSuppressEmptyAuthorName", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureOption_ce_ptr, "psoAddAnnotationForInvisibleSignature", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFSignatureOptions", NULL);
	TSBPDFSignatureOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBPDFSignatureOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureOptions_ce_ptr, "psoSuppressEmptyAuthorName", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSignatureOptions_ce_ptr, "psoAddAnnotationForInvisibleSignature", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBSVDConstraint", NULL);
	TSBSVDConstraint_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSVDConstraint_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraint_ce_ptr, "svdcFilter", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraint_ce_ptr, "svdcSubFilter", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraint_ce_ptr, "svdcV", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraint_ce_ptr, "svdcReasons", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraint_ce_ptr, "svdcLegalAttestation", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraint_ce_ptr, "svdcAddRevInfo", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraint_ce_ptr, "svdcDigestMethod", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraint_ce_ptr, "svdcLockDocument", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraint_ce_ptr, "svdcAppearanceFilter", 8)
	
	INIT_CLASS_ENTRY(ce, "TSBSVDConstraints", NULL);
	TSBSVDConstraints_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBSVDConstraints_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraints_ce_ptr, "svdcFilter", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraints_ce_ptr, "svdcSubFilter", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraints_ce_ptr, "svdcV", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraints_ce_ptr, "svdcReasons", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraints_ce_ptr, "svdcLegalAttestation", 16)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraints_ce_ptr, "svdcAddRevInfo", 32)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraints_ce_ptr, "svdcDigestMethod", 64)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraints_ce_ptr, "svdcLockDocument", 128)
	SB_DECLARE_CLASS_LONG_CONST(TSBSVDConstraints_ce_ptr, "svdcAppearanceFilter", 256)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFFieldFlag", NULL);
	TSBPDFFieldFlag_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFFieldFlag_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFFieldFlag_ce_ptr, "ffReadOnly", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFFieldFlag_ce_ptr, "ffRequired", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFFieldFlag_ce_ptr, "ffNoExport", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFFieldFlags", NULL);
	TSBPDFFieldFlags_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBPDFFieldFlags_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFFieldFlags_ce_ptr, "ffReadOnly", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFFieldFlags_ce_ptr, "ffRequired", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFFieldFlags_ce_ptr, "ffNoExport", 4)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFSecurityHandlerEncryptionMethod", NULL);
	TSBPDFSecurityHandlerEncryptionMethod_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFSecurityHandlerEncryptionMethod_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSecurityHandlerEncryptionMethod_ce_ptr, "emNone", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSecurityHandlerEncryptionMethod_ce_ptr, "emV2", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSecurityHandlerEncryptionMethod_ce_ptr, "emAESV2", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSecurityHandlerEncryptionMethod_ce_ptr, "emAESV3", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFSecurityHandlerEncryptionMethod_ce_ptr, "emUnknown", 4)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFEncryptionSubject", NULL);
	TSBPDFEncryptionSubject_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFEncryptionSubject_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFEncryptionSubject_ce_ptr, "esStream", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFEncryptionSubject_ce_ptr, "esString", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFAssociatedFileRelationship", NULL);
	TSBPDFAssociatedFileRelationship_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFAssociatedFileRelationship_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFAssociatedFileRelationship_ce_ptr, "afrNone", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFAssociatedFileRelationship_ce_ptr, "afrSource", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFAssociatedFileRelationship_ce_ptr, "afrData", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFAssociatedFileRelationship_ce_ptr, "afrAlternative", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFAssociatedFileRelationship_ce_ptr, "afrSupplement", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFAssociatedFileRelationship_ce_ptr, "afrCustom", 5)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFAssemblyOption", NULL);
	TSBPDFAssemblyOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPDFAssemblyOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFAssemblyOption_ce_ptr, "aoAcrobatFriendlyAcroForm", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFAssemblyOption_ce_ptr, "aoAdjustTimesToUTC", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBPDFAssemblyOptions", NULL);
	TSBPDFAssemblyOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBPDFAssemblyOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFAssemblyOptions_ce_ptr, "aoAcrobatFriendlyAcroForm", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPDFAssemblyOptions_ce_ptr, "aoAdjustTimesToUTC", 2)
}

void Register_SBPDF_Aliases(TSRMLS_D)
{
	if (NULL == TElPDFDocument_ce_ptr)
		Register_TElPDFDocument(TSRMLS_C);
	zend_register_class_alias("ElPDFDocument", TElPDFDocument_ce_ptr);
	if (NULL == TElPDFSignature_ce_ptr)
		Register_TElPDFSignature(TSRMLS_C);
	zend_register_class_alias("ElPDFSignature", TElPDFSignature_ce_ptr);
	if (NULL == TElPDFURProperties_ce_ptr)
		Register_TElPDFURProperties(TSRMLS_C);
	zend_register_class_alias("ElPDFURProperties", TElPDFURProperties_ce_ptr);
	if (NULL == TElPDFSigRefEntry_ce_ptr)
		Register_TElPDFSigRefEntry(TSRMLS_C);
	zend_register_class_alias("ElPDFSigRefEntry", TElPDFSigRefEntry_ce_ptr);
	if (NULL == TElPDFSecurityHandler_ce_ptr)
		Register_TElPDFSecurityHandler(TSRMLS_C);
	zend_register_class_alias("ElPDFSecurityHandler", TElPDFSecurityHandler_ce_ptr);
	if (NULL == TElPDFByteRange_ce_ptr)
		Register_TElPDFByteRange(TSRMLS_C);
	zend_register_class_alias("ElPDFByteRange", TElPDFByteRange_ce_ptr);
	if (NULL == TElPDFImage_ce_ptr)
		Register_TElPDFImage(TSRMLS_C);
	zend_register_class_alias("ElPDFImage", TElPDFImage_ce_ptr);
	if (NULL == TElPDFCustomFontObject_ce_ptr)
		Register_TElPDFCustomFontObject(TSRMLS_C);
	zend_register_class_alias("ElPDFCustomFontObject", TElPDFCustomFontObject_ce_ptr);
	if (NULL == TElPDFEncoding_ce_ptr)
		Register_TElPDFEncoding(TSRMLS_C);
	zend_register_class_alias("ElPDFEncoding", TElPDFEncoding_ce_ptr);
	if (NULL == TElPDFFontDescriptor_ce_ptr)
		Register_TElPDFFontDescriptor(TSRMLS_C);
	zend_register_class_alias("ElPDFFontDescriptor", TElPDFFontDescriptor_ce_ptr);
	if (NULL == TElPDFCIDFontDescriptor_ce_ptr)
		Register_TElPDFCIDFontDescriptor(TSRMLS_C);
	zend_register_class_alias("ElPDFCIDFontDescriptor", TElPDFCIDFontDescriptor_ce_ptr);
	if (NULL == TElPDFCIDSystemInfo_ce_ptr)
		Register_TElPDFCIDSystemInfo(TSRMLS_C);
	zend_register_class_alias("ElPDFCIDSystemInfo", TElPDFCIDSystemInfo_ce_ptr);
	if (NULL == TElPDFCustomFont_ce_ptr)
		Register_TElPDFCustomFont(TSRMLS_C);
	zend_register_class_alias("ElPDFCustomFont", TElPDFCustomFont_ce_ptr);
	if (NULL == TElPDFSimpleFont_ce_ptr)
		Register_TElPDFSimpleFont(TSRMLS_C);
	zend_register_class_alias("ElPDFSimpleFont", TElPDFSimpleFont_ce_ptr);
	if (NULL == TElPDFCompositeFont_ce_ptr)
		Register_TElPDFCompositeFont(TSRMLS_C);
	zend_register_class_alias("ElPDFCompositeFont", TElPDFCompositeFont_ce_ptr);
	if (NULL == TElPDFMetricW_ce_ptr)
		Register_TElPDFMetricW(TSRMLS_C);
	zend_register_class_alias("ElPDFMetricW", TElPDFMetricW_ce_ptr);
	if (NULL == TElPDFMetricW2_ce_ptr)
		Register_TElPDFMetricW2(TSRMLS_C);
	zend_register_class_alias("ElPDFMetricW2", TElPDFMetricW2_ce_ptr);
	if (NULL == TElPDFCIDFont_ce_ptr)
		Register_TElPDFCIDFont(TSRMLS_C);
	zend_register_class_alias("ElPDFCIDFont", TElPDFCIDFont_ce_ptr);
	if (NULL == TElPDFSignatureWidgetText_ce_ptr)
		Register_TElPDFSignatureWidgetText(TSRMLS_C);
	zend_register_class_alias("ElPDFSignatureWidgetText", TElPDFSignatureWidgetText_ce_ptr);
	if (NULL == TElPDFSignatureWidgetTextList_ce_ptr)
		Register_TElPDFSignatureWidgetTextList(TSRMLS_C);
	zend_register_class_alias("ElPDFSignatureWidgetTextList", TElPDFSignatureWidgetTextList_ce_ptr);
	if (NULL == TElPDFSignatureWidgetProps_ce_ptr)
		Register_TElPDFSignatureWidgetProps(TSRMLS_C);
	zend_register_class_alias("ElPDFSignatureWidgetProps", TElPDFSignatureWidgetProps_ce_ptr);
	if (NULL == TElPDFSignatureInfo_ce_ptr)
		Register_TElPDFSignatureInfo(TSRMLS_C);
	zend_register_class_alias("ElPDFSignatureInfo", TElPDFSignatureInfo_ce_ptr);
	if (NULL == TElPDFEncodingHandler_ce_ptr)
		Register_TElPDFEncodingHandler(TSRMLS_C);
	zend_register_class_alias("ElPDFEncodingHandler", TElPDFEncodingHandler_ce_ptr);
	if (NULL == TElPDFRequirementHandler_ce_ptr)
		Register_TElPDFRequirementHandler(TSRMLS_C);
	zend_register_class_alias("ElPDFRequirementHandler", TElPDFRequirementHandler_ce_ptr);
	if (NULL == TElPDFRequirement_ce_ptr)
		Register_TElPDFRequirement(TSRMLS_C);
	zend_register_class_alias("ElPDFRequirement", TElPDFRequirement_ce_ptr);
	if (NULL == TElPDFPageInfo_ce_ptr)
		Register_TElPDFPageInfo(TSRMLS_C);
	zend_register_class_alias("ElPDFPageInfo", TElPDFPageInfo_ce_ptr);
	TElPDFSecurityHandlerClass_ce_ptr = TObject_ce_ptr;
	zend_register_class_alias("TElPDFSecurityHandlerClass", TElPDFSecurityHandlerClass_ce_ptr);
	TElPDFEncodingHandlerClass_ce_ptr = TObject_ce_ptr;
	zend_register_class_alias("TElPDFEncodingHandlerClass", TElPDFEncodingHandlerClass_ce_ptr);
	zend_register_class_alias("ElPDFEncodingHandlerClass", TObject_ce_ptr);
}

