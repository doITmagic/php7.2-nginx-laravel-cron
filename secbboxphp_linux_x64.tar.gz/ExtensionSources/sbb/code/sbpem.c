#include "sbpem.h"

zend_class_entry *TElPEMProcessor_ce_ptr = NULL;

SB_PHP_METHOD(TElPEMProcessor, PEMEncode)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	SBArrayZValInfo aiInBuffer;
	SBArrayZValInfo aiOutBuffer;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	uint32_t _err;
	zend_bool bEncrypt;
	zval *zaInBuffer;
	zval *zaOutBuffer;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzb", &zaInBuffer, &zaOutBuffer, &bEncrypt) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaInBuffer) || SB_IS_ARRAY_TYPE_RP(zaInBuffer) || SB_IS_NULL_TYPE_RP(zaInBuffer)) && Z_ISREF_P(zaOutBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaOutBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaOutBuffer)))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaInBuffer, &aiInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaOutBuffer, &aiOutBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = TElPEMProcessor_PEMEncode(SBGetObjectHandle(getThis() TSRMLS_CC), aiInBuffer.data, aiInBuffer.len, aiOutBuffer.data, &aiOutBuffer.len, (int8_t)bEncrypt, &bOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaOutBuffer, &aiOutBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-297683313, 2, aiOutBuffer.data, &aiOutBuffer.len) TSRMLS_CC);
			((char *)aiOutBuffer.data)[aiOutBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiOutBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiInBuffer);
		SBSetByteArrayToZVal(&aiOutBuffer, zaOutBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzb", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize, &bEncrypt) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElPEMProcessor_PEMEncode_1(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, (int8_t)bEncrypt, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &array of byte|string, bool) or (\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPEMProcessor, PEMDecode)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	SBArrayZValInfo aiInBuffer;
	SBArrayZValInfo aiOutBuffer;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	uint32_t _err;
	zval *zaInBuffer;
	zval *zaOutBuffer;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaInBuffer, &zaOutBuffer) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaInBuffer) || SB_IS_ARRAY_TYPE_RP(zaInBuffer) || SB_IS_NULL_TYPE_RP(zaInBuffer)) && Z_ISREF_P(zaOutBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaOutBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaOutBuffer)))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaInBuffer, &aiInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaOutBuffer, &aiOutBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = TElPEMProcessor_PEMDecode(SBGetObjectHandle(getThis() TSRMLS_CC), aiInBuffer.data, aiInBuffer.len, aiOutBuffer.data, &aiOutBuffer.len, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaOutBuffer, &aiOutBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(751372596, 2, aiOutBuffer.data, &aiOutBuffer.len) TSRMLS_CC);
			((char *)aiOutBuffer.data)[aiOutBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiOutBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiInBuffer);
		SBSetByteArrayToZVal(&aiOutBuffer, zaOutBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzz", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElPEMProcessor_PEMDecode_1(SBGetObjectHandle(getThis() TSRMLS_CC), piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &array of byte|string) or (\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPEMProcessor, get_Header)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPEMProcessor_get_Header(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(943463020, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPEMProcessor, set_Header)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPEMProcessor_set_Header(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPEMProcessor, get_Passphrase)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPEMProcessor_get_Passphrase(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(107004307, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPEMProcessor, set_Passphrase)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPEMProcessor_set_Passphrase(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPEMProcessor, get_EncryptionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPEMProcessor_get_EncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPEMProcessor, set_EncryptionAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPEMProcessor_set_EncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPEMProcessor, get_EncryptionMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSymmetricCryptoModeRaw fOutResultRaw = 0;
		SBCheckError(TElPEMProcessor_get_EncryptionMode(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPEMProcessor, set_EncryptionMode)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPEMProcessor_set_EncryptionMode(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSymmetricCryptoModeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPEMProcessor, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPEMProcessor_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPEMProcessor_PEMEncode, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutBuffer_or_InSize)
	ZEND_ARG_TYPE_INFO(0, Encrypt_or_OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
	ZEND_ARG_INFO(0, Encrypt)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPEMProcessor_PEMDecode, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, InBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutBuffer_or_InSize)
	ZEND_ARG_TYPE_INFO(0, OutBuffer, 0, 1)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPEMProcessor_get_Header, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPEMProcessor_set_Header, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPEMProcessor_get_Passphrase, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPEMProcessor_set_Passphrase, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPEMProcessor_get_EncryptionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPEMProcessor_set_EncryptionAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPEMProcessor_get_EncryptionMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPEMProcessor_set_EncryptionMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPEMProcessor___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElPEMProcessor_methods[] = {
	PHP_ME(TElPEMProcessor, PEMEncode, arginfo_TElPEMProcessor_PEMEncode, ZEND_ACC_PUBLIC)
	PHP_ME(TElPEMProcessor, PEMDecode, arginfo_TElPEMProcessor_PEMDecode, ZEND_ACC_PUBLIC)
	PHP_ME(TElPEMProcessor, get_Header, arginfo_TElPEMProcessor_get_Header, ZEND_ACC_PUBLIC)
	PHP_ME(TElPEMProcessor, set_Header, arginfo_TElPEMProcessor_set_Header, ZEND_ACC_PUBLIC)
	PHP_ME(TElPEMProcessor, get_Passphrase, arginfo_TElPEMProcessor_get_Passphrase, ZEND_ACC_PUBLIC)
	PHP_ME(TElPEMProcessor, set_Passphrase, arginfo_TElPEMProcessor_set_Passphrase, ZEND_ACC_PUBLIC)
	PHP_ME(TElPEMProcessor, get_EncryptionAlgorithm, arginfo_TElPEMProcessor_get_EncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPEMProcessor, set_EncryptionAlgorithm, arginfo_TElPEMProcessor_set_EncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPEMProcessor, get_EncryptionMode, arginfo_TElPEMProcessor_get_EncryptionMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElPEMProcessor, set_EncryptionMode, arginfo_TElPEMProcessor_set_EncryptionMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElPEMProcessor, __construct, arginfo_TElPEMProcessor___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPEMProcessor(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPEMProcessor_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPEMProcessor", TElPEMProcessor_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElPEMProcessor_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

SB_PHP_FUNCTION(SBPEM, Encode)
{
	char *sHeader;
	char *sPassPhrase;
	int32_t l4OutSizeRaw;
	sb_str_size sHeader_len;
	sb_str_size sPassPhrase_len;
	sb_zend_long l4InSize;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	zend_bool bEncrypt;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzsbs", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize, &sHeader, &sHeader_len, &bEncrypt, &sPassPhrase, &sPassPhrase_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(SBPEM_Encode(piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, sHeader, (int32_t)sHeader_len, (int8_t)bEncrypt, sPassPhrase, (int32_t)sPassPhrase_len, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer, string, bool, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPEM, EncodeEx)
{
	char *sHeader;
	char *sPassPhrase;
	int32_t l4OutSizeRaw;
	sb_str_size sHeader_len;
	sb_str_size sPassPhrase_len;
	sb_zend_long fEncryptionMode;
	sb_zend_long l4EncryptionAlgorithm;
	sb_zend_long l4InSize;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzsls", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize, &sHeader, &sHeader_len, &l4EncryptionAlgorithm, &sPassPhrase, &sPassPhrase_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(SBPEM_EncodeEx(piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, sHeader, (int32_t)sHeader_len, (int32_t)l4EncryptionAlgorithm, sPassPhrase, (int32_t)sPassPhrase_len, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzslls", &zpInBuffer, &l4InSize, &zpOutBuffer, &zl4OutSize, &sHeader, &sHeader_len, &l4EncryptionAlgorithm, &fEncryptionMode, &sPassPhrase, &sPassPhrase_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(SBPEM_EncodeEx_1(piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, &l4OutSizeRaw, sHeader, (int32_t)sHeader_len, (int32_t)l4EncryptionAlgorithm, (TSBSymmetricCryptoModeRaw)fEncryptionMode, sPassPhrase, (int32_t)sPassPhrase_len, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer, string, integer, string) or (\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer, string, integer, integer, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPEM, Decode)
{
	char *sHeader;
	char *sPassPhrase;
	int32_t l4OutSizeRaw;
	int32_t sHeader_len;
	sb_str_size sPassPhrase_len;
	sb_zend_long l4InSize;
	SBArrayZValInfo piInBuffer;
	SBArrayZValInfo piOutBuffer;
	uint32_t _err;
	zval *zl4OutSize;
	zval *zpInBuffer;
	zval *zpOutBuffer;
	zval *zsHeader;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzszz", &zpInBuffer, &l4InSize, &zpOutBuffer, &sPassPhrase, &sPassPhrase_len, &zl4OutSize, &zsHeader) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInBuffer) || SB_IS_ARRAY_TYPE_RP(zpInBuffer) || SB_IS_NULL_TYPE_RP(zpInBuffer) || (SB_IS_OBJECT_TYPE_RP(zpInBuffer) && (Z_OBJCE_P(zpInBuffer) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutBuffer) || SB_IS_ARRAY_TYPE_RP(zpOutBuffer) || SB_IS_NULL_TYPE_RP(zpOutBuffer) || (SB_IS_OBJECT_TYPE_RP(zpOutBuffer) && (Z_OBJCE_P(zpOutBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))) && Z_ISREF_P(zsHeader) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsHeader))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInBuffer, &piInBuffer TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutBuffer, &piOutBuffer TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		sHeader = Z_STRVAL_P(Z_REFVAL_P(zsHeader));
		sHeader_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsHeader));
		_err = SBPEM_Decode(piInBuffer.data, (int32_t)l4InSize, piOutBuffer.data, sPassPhrase, (int32_t)sPassPhrase_len, &l4OutSizeRaw, sHeader, &sHeader_len, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sHeader = emalloc(sHeader_len + 1);
			SBCheckError(SBGetLastReturnStringA(-988907671, 5, sHeader, &sHeader_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsHeader));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piInBuffer);
		SBFreePointerZValInfo(&piOutBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		sHeader[sHeader_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsHeader), sHeader, sHeader_len);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, string, &integer, &string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPEM, IsBase64UnicodeSequence)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBPEM_IsBase64UnicodeSequence(piBuffer.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPEM, IsBase64Sequence)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBPEM_IsBase64Sequence(piBuffer.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPEM, IsPEMSequence)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBPEM_IsPEMSequence(piBuffer.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPEM, RaisePEMError)
{
	sb_zend_long l4ErrorCode;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4ErrorCode) == SUCCESS)
	{
		SBCheckError(SBPEM_RaisePEMError((int32_t)l4ErrorCode) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

void Register_SBPEM_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBPEM, PEM_DECODE_RESULT_OK, SB_PEM_DECODE_RESULT_OK, SB_PEM_DECODE_RESULT_OK);
	SB_REGISTER_LONG_CONSTANT(SBPEM, PEM_DECODE_RESULT_INVALID_FORMAT, SB_PEM_DECODE_RESULT_INVALID_FORMAT, SB_PEM_DECODE_RESULT_INVALID_FORMAT);
	SB_REGISTER_LONG_CONSTANT(SBPEM, PEM_DECODE_RESULT_INVALID_PASSPHRASE, SB_PEM_DECODE_RESULT_INVALID_PASSPHRASE, SB_PEM_DECODE_RESULT_INVALID_PASSPHRASE);
	SB_REGISTER_LONG_CONSTANT(SBPEM, PEM_DECODE_RESULT_NOT_ENOUGH_SPACE, SB_PEM_DECODE_RESULT_NOT_ENOUGH_SPACE, SB_PEM_DECODE_RESULT_NOT_ENOUGH_SPACE);
	SB_REGISTER_LONG_CONSTANT(SBPEM, PEM_DECODE_RESULT_UNKNOWN_CIPHER, SB_PEM_DECODE_RESULT_UNKNOWN_CIPHER, SB_PEM_DECODE_RESULT_UNKNOWN_CIPHER);
}

