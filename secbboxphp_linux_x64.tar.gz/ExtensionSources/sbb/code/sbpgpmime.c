#include "sbpgpmime.h"

zend_class_entry *TSBPGPMIMEType_ce_ptr = NULL;

zend_class_entry *TSBPGPMIMEError_ce_ptr = NULL;

zend_class_entry *TSBPGPMIMEErrors_ce_ptr = NULL;

zend_class_entry *TSBPGPKeysError_ce_ptr = NULL;

zend_class_entry *TSBPGPKeysErrors_ce_ptr = NULL;

void SB_CALLBACK TSBPGPKeyNotFoundEventRaw(void * _ObjectData, TObjectHandle Sender, TElMailAddressHandle Address, int8_t * ExcludeFromList)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zAddress;
	zval * zExcludeFromList;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zAddress, 1);
	SBInitObject(zAddress, TElMailAddress_ce_ptr, Address TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zExcludeFromList, 2);
	ZVAL_BOOL(Z_REFVAL_P(zExcludeFromList), (zend_bool)*ExcludeFromList);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zAddress);
	convert_to_boolean(Z_REFVAL_P(zExcludeFromList));
	*ExcludeFromList = (int8_t)SB_BVAL_P(Z_REFVAL_P(zExcludeFromList));
	SB_EVENT_CLEAR_ZVAL(zExcludeFromList);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElMessagePartHandlerPGPMime_ce_ptr = NULL;

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, GetDescription_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElMessagePartHandlerPGPMime_GetDescription_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1909824976, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElMessagePartHandlerPGPMime_GetDescription(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1909824976, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, IsSigned)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_IsSigned(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, IsEncrypted)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_IsEncrypted(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_Errors)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPMIMEErrorsRaw fOutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_get_Errors(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_Encrypt)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_get_Encrypt(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_Encrypt)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_Encrypt(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_Sign)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_get_Sign(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_Sign)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_Sign(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_Compress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_get_Compress(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_Compress)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_Compress(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_IgnoreHeaderRecipients)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_get_IgnoreHeaderRecipients(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_IgnoreHeaderRecipients)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_IgnoreHeaderRecipients(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_IgnoreHeaderSigners)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_get_IgnoreHeaderSigners(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_IgnoreHeaderSigners)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_IgnoreHeaderSigners(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_DecryptingKeys)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_get_DecryptingKeys(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPKeyring_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_DecryptingKeys)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPGPKeyring_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_DecryptingKeys(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPKeyring)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_VerifyingKeys)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_get_VerifyingKeys(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPKeyring_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_VerifyingKeys)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPGPKeyring_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_VerifyingKeys(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPKeyring)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_EncryptingKeys)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_get_EncryptingKeys(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPKeyring_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_EncryptingKeys)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPGPKeyring_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_EncryptingKeys(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPKeyring)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_SigningKeys)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_get_SigningKeys(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPKeyring_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_SigningKeys)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPGPKeyring_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_SigningKeys(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPKeyring)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_EncryptionType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPEncryptionTypeRaw fOutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_get_EncryptionType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_EncryptionType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_EncryptionType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPGPEncryptionTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_Passphrases)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_get_Passphrases(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_Passphrases)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_Passphrases(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_Protection)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPProtectionTypeRaw fOutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_get_Protection(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_Protection)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_Protection(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPGPProtectionTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_CompressionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_get_CompressionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_CompressionAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_CompressionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_CompressionLevel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_get_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_CompressionLevel)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_HashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_get_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_HashAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_SymmetricKeyAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_get_SymmetricKeyAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_SymmetricKeyAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_SymmetricKeyAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_UseNewFeatures)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_get_UseNewFeatures(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_UseNewFeatures)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_UseNewFeatures(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_UseOldPackets)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElMessagePartHandlerPGPMime_get_UseOldPackets(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_UseOldPackets)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_UseOldPackets(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_ArmorHeaders)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_get_ArmorHeaders(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_ArmorHeaders)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMessagePartHandlerPGPMime_set_ArmorHeaders(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_OnEncrypted)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPEncryptedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_get_OnEncrypted(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_OnEncrypted)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElMessagePartHandlerPGPMime_set_OnEncrypted(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPEncryptedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPEncryptedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_OnSigned)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPSignedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_get_OnSigned(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_OnSigned)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElMessagePartHandlerPGPMime_set_OnSigned(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPSignedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPSignedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_OnKeyPassphrase)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPKeyPassphraseEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_get_OnKeyPassphrase(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_OnKeyPassphrase)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElMessagePartHandlerPGPMime_set_OnKeyPassphrase(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPKeyPassphraseEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPKeyPassphraseEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_OnPassphrase)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPPassphraseEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_get_OnPassphrase(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_OnPassphrase)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElMessagePartHandlerPGPMime_set_OnPassphrase(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPPassphraseEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPPassphraseEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_OnSignatures)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPSignaturesEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_get_OnSignatures(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_OnSignatures)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElMessagePartHandlerPGPMime_set_OnSignatures(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPSignaturesEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPSignaturesEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_OnEncryptingKeyNotFound)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPKeyNotFoundEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_get_OnEncryptingKeyNotFound(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_OnEncryptingKeyNotFound)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElMessagePartHandlerPGPMime_set_OnEncryptingKeyNotFound(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPKeyNotFoundEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPKeyNotFoundEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, get_OnSigningKeyNotFound)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPKeyNotFoundEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_get_OnSigningKeyNotFound(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, set_OnSigningKeyNotFound)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElMessagePartHandlerPGPMime_set_OnSigningKeyNotFound(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPKeyNotFoundEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPKeyNotFoundEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPMime, __construct)
{
	zval *oaParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oaParams, TObject_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPMime_Create(SBGetObjectHandle(oaParams TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_GetDescription_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_IsSigned, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_IsEncrypted, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_Errors, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_Encrypt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_Encrypt, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_Sign, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_Sign, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_Compress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_Compress, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_IgnoreHeaderRecipients, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_IgnoreHeaderRecipients, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_IgnoreHeaderSigners, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_IgnoreHeaderSigners, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_DecryptingKeys, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_DecryptingKeys, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPGPKeyring, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_VerifyingKeys, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_VerifyingKeys, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPGPKeyring, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_EncryptingKeys, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_EncryptingKeys, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPGPKeyring, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_SigningKeys, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_SigningKeys, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPGPKeyring, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_EncryptionType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_EncryptionType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_Passphrases, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_Passphrases, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_Protection, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_Protection, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_CompressionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_CompressionAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_CompressionLevel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_CompressionLevel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_HashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_HashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_SymmetricKeyAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_SymmetricKeyAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_UseNewFeatures, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_UseNewFeatures, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_UseOldPackets, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_UseOldPackets, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_ArmorHeaders, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_ArmorHeaders, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_OnEncrypted, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_OnEncrypted, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_OnSigned, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_OnSigned, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_OnKeyPassphrase, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_OnKeyPassphrase, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_OnPassphrase, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_OnPassphrase, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_OnSignatures, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_OnSignatures, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_OnEncryptingKeyNotFound, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_OnEncryptingKeyNotFound, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_get_OnSigningKeyNotFound, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime_set_OnSigningKeyNotFound, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPMime___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, aParams, TObject, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElMessagePartHandlerPGPMime_methods[] = {
	PHP_ME(TElMessagePartHandlerPGPMime, GetDescription_Inst, arginfo_TElMessagePartHandlerPGPMime_GetDescription_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, GetDescription, arginfo_TElMessagePartHandlerPGPMime_GetDescription, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElMessagePartHandlerPGPMime, IsSigned, arginfo_TElMessagePartHandlerPGPMime_IsSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, IsEncrypted, arginfo_TElMessagePartHandlerPGPMime_IsEncrypted, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, ClassType, arginfo_TElMessagePartHandlerPGPMime_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_Errors, arginfo_TElMessagePartHandlerPGPMime_get_Errors, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_Encrypt, arginfo_TElMessagePartHandlerPGPMime_get_Encrypt, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_Encrypt, arginfo_TElMessagePartHandlerPGPMime_set_Encrypt, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_Sign, arginfo_TElMessagePartHandlerPGPMime_get_Sign, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_Sign, arginfo_TElMessagePartHandlerPGPMime_set_Sign, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_Compress, arginfo_TElMessagePartHandlerPGPMime_get_Compress, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_Compress, arginfo_TElMessagePartHandlerPGPMime_set_Compress, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_IgnoreHeaderRecipients, arginfo_TElMessagePartHandlerPGPMime_get_IgnoreHeaderRecipients, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_IgnoreHeaderRecipients, arginfo_TElMessagePartHandlerPGPMime_set_IgnoreHeaderRecipients, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_IgnoreHeaderSigners, arginfo_TElMessagePartHandlerPGPMime_get_IgnoreHeaderSigners, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_IgnoreHeaderSigners, arginfo_TElMessagePartHandlerPGPMime_set_IgnoreHeaderSigners, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_DecryptingKeys, arginfo_TElMessagePartHandlerPGPMime_get_DecryptingKeys, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_DecryptingKeys, arginfo_TElMessagePartHandlerPGPMime_set_DecryptingKeys, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_VerifyingKeys, arginfo_TElMessagePartHandlerPGPMime_get_VerifyingKeys, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_VerifyingKeys, arginfo_TElMessagePartHandlerPGPMime_set_VerifyingKeys, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_EncryptingKeys, arginfo_TElMessagePartHandlerPGPMime_get_EncryptingKeys, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_EncryptingKeys, arginfo_TElMessagePartHandlerPGPMime_set_EncryptingKeys, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_SigningKeys, arginfo_TElMessagePartHandlerPGPMime_get_SigningKeys, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_SigningKeys, arginfo_TElMessagePartHandlerPGPMime_set_SigningKeys, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_EncryptionType, arginfo_TElMessagePartHandlerPGPMime_get_EncryptionType, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_EncryptionType, arginfo_TElMessagePartHandlerPGPMime_set_EncryptionType, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_Passphrases, arginfo_TElMessagePartHandlerPGPMime_get_Passphrases, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_Passphrases, arginfo_TElMessagePartHandlerPGPMime_set_Passphrases, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_Protection, arginfo_TElMessagePartHandlerPGPMime_get_Protection, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_Protection, arginfo_TElMessagePartHandlerPGPMime_set_Protection, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_CompressionAlgorithm, arginfo_TElMessagePartHandlerPGPMime_get_CompressionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_CompressionAlgorithm, arginfo_TElMessagePartHandlerPGPMime_set_CompressionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_CompressionLevel, arginfo_TElMessagePartHandlerPGPMime_get_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_CompressionLevel, arginfo_TElMessagePartHandlerPGPMime_set_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_HashAlgorithm, arginfo_TElMessagePartHandlerPGPMime_get_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_HashAlgorithm, arginfo_TElMessagePartHandlerPGPMime_set_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_SymmetricKeyAlgorithm, arginfo_TElMessagePartHandlerPGPMime_get_SymmetricKeyAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_SymmetricKeyAlgorithm, arginfo_TElMessagePartHandlerPGPMime_set_SymmetricKeyAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_UseNewFeatures, arginfo_TElMessagePartHandlerPGPMime_get_UseNewFeatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_UseNewFeatures, arginfo_TElMessagePartHandlerPGPMime_set_UseNewFeatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_UseOldPackets, arginfo_TElMessagePartHandlerPGPMime_get_UseOldPackets, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_UseOldPackets, arginfo_TElMessagePartHandlerPGPMime_set_UseOldPackets, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_ArmorHeaders, arginfo_TElMessagePartHandlerPGPMime_get_ArmorHeaders, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_ArmorHeaders, arginfo_TElMessagePartHandlerPGPMime_set_ArmorHeaders, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_OnEncrypted, arginfo_TElMessagePartHandlerPGPMime_get_OnEncrypted, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_OnEncrypted, arginfo_TElMessagePartHandlerPGPMime_set_OnEncrypted, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_OnSigned, arginfo_TElMessagePartHandlerPGPMime_get_OnSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_OnSigned, arginfo_TElMessagePartHandlerPGPMime_set_OnSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_OnKeyPassphrase, arginfo_TElMessagePartHandlerPGPMime_get_OnKeyPassphrase, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_OnKeyPassphrase, arginfo_TElMessagePartHandlerPGPMime_set_OnKeyPassphrase, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_OnPassphrase, arginfo_TElMessagePartHandlerPGPMime_get_OnPassphrase, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_OnPassphrase, arginfo_TElMessagePartHandlerPGPMime_set_OnPassphrase, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_OnSignatures, arginfo_TElMessagePartHandlerPGPMime_get_OnSignatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_OnSignatures, arginfo_TElMessagePartHandlerPGPMime_set_OnSignatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_OnEncryptingKeyNotFound, arginfo_TElMessagePartHandlerPGPMime_get_OnEncryptingKeyNotFound, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_OnEncryptingKeyNotFound, arginfo_TElMessagePartHandlerPGPMime_set_OnEncryptingKeyNotFound, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, get_OnSigningKeyNotFound, arginfo_TElMessagePartHandlerPGPMime_get_OnSigningKeyNotFound, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, set_OnSigningKeyNotFound, arginfo_TElMessagePartHandlerPGPMime_set_OnSigningKeyNotFound, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPMime, __construct, arginfo_TElMessagePartHandlerPGPMime___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMessagePartHandlerPGPMime(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMessagePartHandlerPGPMime_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMessagePartHandlerPGPMime", TElMessagePartHandlerPGPMime_methods);
	if (NULL == TElMessagePartHandler_ce_ptr)
		Register_TElMessagePartHandler(TSRMLS_C);
	TElMessagePartHandlerPGPMime_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElMessagePartHandler_ce_ptr);
}

zend_class_entry *TElMessagePartHandlerPGPKeys_ce_ptr = NULL;

SB_PHP_METHOD(TElMessagePartHandlerPGPKeys, GetDescription_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElMessagePartHandlerPGPKeys_GetDescription_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1362447709, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPKeys, GetDescription)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElMessagePartHandlerPGPKeys_GetDescription(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1362447709, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPKeys, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPKeys_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPKeys, get_Keys)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPKeys_get_Keys(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPKeyring_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMessagePartHandlerPGPKeys, __construct)
{
	zval *oaParams;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oaParams, TObject_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMessagePartHandlerPGPKeys_Create(SBGetObjectHandle(oaParams TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TObject)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPKeys_GetDescription_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPKeys_GetDescription, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPKeys_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPKeys_get_Keys, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMessagePartHandlerPGPKeys___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, aParams, TObject, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElMessagePartHandlerPGPKeys_methods[] = {
	PHP_ME(TElMessagePartHandlerPGPKeys, GetDescription_Inst, arginfo_TElMessagePartHandlerPGPKeys_GetDescription_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPKeys, GetDescription, arginfo_TElMessagePartHandlerPGPKeys_GetDescription, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElMessagePartHandlerPGPKeys, ClassType, arginfo_TElMessagePartHandlerPGPKeys_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElMessagePartHandlerPGPKeys, get_Keys, arginfo_TElMessagePartHandlerPGPKeys_get_Keys, ZEND_ACC_PUBLIC)
	PHP_ME(TElMessagePartHandlerPGPKeys, __construct, arginfo_TElMessagePartHandlerPGPKeys___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMessagePartHandlerPGPKeys(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMessagePartHandlerPGPKeys_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMessagePartHandlerPGPKeys", TElMessagePartHandlerPGPKeys_methods);
	if (NULL == TElMessagePartHandler_ce_ptr)
		Register_TElMessagePartHandler(TSRMLS_C);
	TElMessagePartHandlerPGPKeys_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElMessagePartHandler_ce_ptr);
}

zend_class_entry *TElSimplePGPMIMEOptions_ce_ptr = NULL;

SB_PHP_METHOD(TElSimplePGPMIMEOptions, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_EncryptionType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPEncryptionTypeRaw fOutResultRaw = 0;
		SBCheckError(TElSimplePGPMIMEOptions_get_EncryptionType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_EncryptionType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_EncryptionType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPGPEncryptionTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_Passphrases)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimplePGPMIMEOptions_get_Passphrases(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_Passphrases)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_Passphrases(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_Protection)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPProtectionTypeRaw fOutResultRaw = 0;
		SBCheckError(TElSimplePGPMIMEOptions_get_Protection(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_Protection)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_Protection(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPGPProtectionTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_HashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimplePGPMIMEOptions_get_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_HashAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_CompressionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimplePGPMIMEOptions_get_CompressionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_CompressionAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_CompressionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_CompressionLevel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimplePGPMIMEOptions_get_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_CompressionLevel)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_SymmetricKeyAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimplePGPMIMEOptions_get_SymmetricKeyAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_SymmetricKeyAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_SymmetricKeyAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_UseOldPackets)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimplePGPMIMEOptions_get_UseOldPackets(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_UseOldPackets)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_UseOldPackets(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_UseNewFeatures)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimplePGPMIMEOptions_get_UseNewFeatures(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_UseNewFeatures)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_UseNewFeatures(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_CompressMessage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimplePGPMIMEOptions_get_CompressMessage(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_CompressMessage)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_CompressMessage(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_EncryptMessage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimplePGPMIMEOptions_get_EncryptMessage(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_EncryptMessage)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_EncryptMessage(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_IgnoreHeaderRecipients)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimplePGPMIMEOptions_get_IgnoreHeaderRecipients(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_IgnoreHeaderRecipients)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_IgnoreHeaderRecipients(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_IgnoreHeaderSigners)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimplePGPMIMEOptions_get_IgnoreHeaderSigners(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_IgnoreHeaderSigners)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_IgnoreHeaderSigners(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_SignMessage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimplePGPMIMEOptions_get_SignMessage(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_SignMessage)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_SignMessage(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, get_ArmorHeaders)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimplePGPMIMEOptions_get_ArmorHeaders(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, set_ArmorHeaders)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEOptions_set_ArmorHeaders(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEOptions, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimplePGPMIMEOptions_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_EncryptionType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_EncryptionType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_Passphrases, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_Passphrases, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_Protection, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_Protection, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_HashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_HashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_CompressionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_CompressionAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_CompressionLevel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_CompressionLevel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_SymmetricKeyAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_SymmetricKeyAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_UseOldPackets, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_UseOldPackets, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_UseNewFeatures, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_UseNewFeatures, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_CompressMessage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_CompressMessage, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_EncryptMessage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_EncryptMessage, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_IgnoreHeaderRecipients, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_IgnoreHeaderRecipients, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_IgnoreHeaderSigners, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_IgnoreHeaderSigners, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_SignMessage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_SignMessage, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_get_ArmorHeaders, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions_set_ArmorHeaders, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEOptions___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSimplePGPMIMEOptions_methods[] = {
	PHP_ME(TElSimplePGPMIMEOptions, Assign, arginfo_TElSimplePGPMIMEOptions_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_EncryptionType, arginfo_TElSimplePGPMIMEOptions_get_EncryptionType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_EncryptionType, arginfo_TElSimplePGPMIMEOptions_set_EncryptionType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_Passphrases, arginfo_TElSimplePGPMIMEOptions_get_Passphrases, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_Passphrases, arginfo_TElSimplePGPMIMEOptions_set_Passphrases, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_Protection, arginfo_TElSimplePGPMIMEOptions_get_Protection, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_Protection, arginfo_TElSimplePGPMIMEOptions_set_Protection, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_HashAlgorithm, arginfo_TElSimplePGPMIMEOptions_get_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_HashAlgorithm, arginfo_TElSimplePGPMIMEOptions_set_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_CompressionAlgorithm, arginfo_TElSimplePGPMIMEOptions_get_CompressionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_CompressionAlgorithm, arginfo_TElSimplePGPMIMEOptions_set_CompressionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_CompressionLevel, arginfo_TElSimplePGPMIMEOptions_get_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_CompressionLevel, arginfo_TElSimplePGPMIMEOptions_set_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_SymmetricKeyAlgorithm, arginfo_TElSimplePGPMIMEOptions_get_SymmetricKeyAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_SymmetricKeyAlgorithm, arginfo_TElSimplePGPMIMEOptions_set_SymmetricKeyAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_UseOldPackets, arginfo_TElSimplePGPMIMEOptions_get_UseOldPackets, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_UseOldPackets, arginfo_TElSimplePGPMIMEOptions_set_UseOldPackets, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_UseNewFeatures, arginfo_TElSimplePGPMIMEOptions_get_UseNewFeatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_UseNewFeatures, arginfo_TElSimplePGPMIMEOptions_set_UseNewFeatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_CompressMessage, arginfo_TElSimplePGPMIMEOptions_get_CompressMessage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_CompressMessage, arginfo_TElSimplePGPMIMEOptions_set_CompressMessage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_EncryptMessage, arginfo_TElSimplePGPMIMEOptions_get_EncryptMessage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_EncryptMessage, arginfo_TElSimplePGPMIMEOptions_set_EncryptMessage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_IgnoreHeaderRecipients, arginfo_TElSimplePGPMIMEOptions_get_IgnoreHeaderRecipients, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_IgnoreHeaderRecipients, arginfo_TElSimplePGPMIMEOptions_set_IgnoreHeaderRecipients, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_IgnoreHeaderSigners, arginfo_TElSimplePGPMIMEOptions_get_IgnoreHeaderSigners, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_IgnoreHeaderSigners, arginfo_TElSimplePGPMIMEOptions_set_IgnoreHeaderSigners, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_SignMessage, arginfo_TElSimplePGPMIMEOptions_get_SignMessage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_SignMessage, arginfo_TElSimplePGPMIMEOptions_set_SignMessage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, get_ArmorHeaders, arginfo_TElSimplePGPMIMEOptions_get_ArmorHeaders, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, set_ArmorHeaders, arginfo_TElSimplePGPMIMEOptions_set_ArmorHeaders, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEOptions, __construct, arginfo_TElSimplePGPMIMEOptions___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSimplePGPMIMEOptions(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSimplePGPMIMEOptions_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSimplePGPMIMEOptions", TElSimplePGPMIMEOptions_methods);
	if (NULL == TPersistent_ce_ptr)
		Register_TPersistent(TSRMLS_C);
	TElSimplePGPMIMEOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPersistent_ce_ptr);
}

zend_class_entry *TElSimplePGPMIMEMessage_ce_ptr = NULL;

SB_PHP_METHOD(TElSimplePGPMIMEMessage, get_EncryptingKeys)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimplePGPMIMEMessage_get_EncryptingKeys(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPKeyring_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEMessage, set_EncryptingKeys)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPGPKeyring_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEMessage_set_EncryptingKeys(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPKeyring)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEMessage, get_PGPMIMEOptions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimplePGPMIMEMessage_get_PGPMIMEOptions(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSimplePGPMIMEOptions_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEMessage, set_PGPMIMEOptions)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElSimplePGPMIMEOptions_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEMessage_set_PGPMIMEOptions(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSimplePGPMIMEOptions)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEMessage, get_SigningKeys)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimplePGPMIMEMessage_get_SigningKeys(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPKeyring_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEMessage, set_SigningKeys)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPGPKeyring_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimplePGPMIMEMessage_set_SigningKeys(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPKeyring)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEMessage, get_OnEncryptingKeyNotFound)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPKeyNotFoundEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimplePGPMIMEMessage_get_OnEncryptingKeyNotFound(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEMessage, set_OnEncryptingKeyNotFound)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimplePGPMIMEMessage_set_OnEncryptingKeyNotFound(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPKeyNotFoundEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPKeyNotFoundEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEMessage, get_OnKeyPassphrase)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPKeyPassphraseEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimplePGPMIMEMessage_get_OnKeyPassphrase(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEMessage, set_OnKeyPassphrase)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimplePGPMIMEMessage_set_OnKeyPassphrase(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPKeyPassphraseEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPKeyPassphraseEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEMessage, get_OnSigningKeyNotFound)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPKeyNotFoundEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimplePGPMIMEMessage_get_OnSigningKeyNotFound(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEMessage, set_OnSigningKeyNotFound)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimplePGPMIMEMessage_set_OnSigningKeyNotFound(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPKeyNotFoundEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPKeyNotFoundEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimplePGPMIMEMessage, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimplePGPMIMEMessage_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEMessage_get_EncryptingKeys, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEMessage_set_EncryptingKeys, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPGPKeyring, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEMessage_get_PGPMIMEOptions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEMessage_set_PGPMIMEOptions, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElSimplePGPMIMEOptions, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEMessage_get_SigningKeys, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEMessage_set_SigningKeys, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPGPKeyring, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEMessage_get_OnEncryptingKeyNotFound, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEMessage_set_OnEncryptingKeyNotFound, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEMessage_get_OnKeyPassphrase, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEMessage_set_OnKeyPassphrase, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEMessage_get_OnSigningKeyNotFound, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEMessage_set_OnSigningKeyNotFound, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimplePGPMIMEMessage___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSimplePGPMIMEMessage_methods[] = {
	PHP_ME(TElSimplePGPMIMEMessage, get_EncryptingKeys, arginfo_TElSimplePGPMIMEMessage_get_EncryptingKeys, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEMessage, set_EncryptingKeys, arginfo_TElSimplePGPMIMEMessage_set_EncryptingKeys, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEMessage, get_PGPMIMEOptions, arginfo_TElSimplePGPMIMEMessage_get_PGPMIMEOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEMessage, set_PGPMIMEOptions, arginfo_TElSimplePGPMIMEMessage_set_PGPMIMEOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEMessage, get_SigningKeys, arginfo_TElSimplePGPMIMEMessage_get_SigningKeys, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEMessage, set_SigningKeys, arginfo_TElSimplePGPMIMEMessage_set_SigningKeys, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEMessage, get_OnEncryptingKeyNotFound, arginfo_TElSimplePGPMIMEMessage_get_OnEncryptingKeyNotFound, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEMessage, set_OnEncryptingKeyNotFound, arginfo_TElSimplePGPMIMEMessage_set_OnEncryptingKeyNotFound, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEMessage, get_OnKeyPassphrase, arginfo_TElSimplePGPMIMEMessage_get_OnKeyPassphrase, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEMessage, set_OnKeyPassphrase, arginfo_TElSimplePGPMIMEMessage_set_OnKeyPassphrase, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEMessage, get_OnSigningKeyNotFound, arginfo_TElSimplePGPMIMEMessage_get_OnSigningKeyNotFound, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEMessage, set_OnSigningKeyNotFound, arginfo_TElSimplePGPMIMEMessage_set_OnSigningKeyNotFound, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimplePGPMIMEMessage, __construct, arginfo_TElSimplePGPMIMEMessage___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSimplePGPMIMEMessage(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSimplePGPMIMEMessage_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSimplePGPMIMEMessage", TElSimplePGPMIMEMessage_methods);
	if (NULL == TElSimpleMIMEMessage_ce_ptr)
		Register_TElSimpleMIMEMessage(TSRMLS_C);
	TElSimplePGPMIMEMessage_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSimpleMIMEMessage_ce_ptr);
}

SB_PHP_FUNCTION(SBPGPMIME, Initialize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(SBPGPMIME_Initialize() TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

void Register_SBPGPMIME_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBPGPMIMEType", NULL);
	TSBPGPMIMEType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPGPMIMEType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEType_ce_ptr, "pmtUnknown", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEType_ce_ptr, "pmtSigned", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEType_ce_ptr, "pmtEncrypted", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEType_ce_ptr, "pmtSignedEncrypted", 3)
	
	INIT_CLASS_ENTRY(ce, "TSBPGPMIMEError", NULL);
	TSBPGPMIMEError_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPGPMIMEError_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEError_ce_ptr, "pmeUnknown", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEError_ce_ptr, "pmePGPPartNotFound", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEError_ce_ptr, "pmeInvalidSignature", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEError_ce_ptr, "pmeUnverifiableSignature", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEError_ce_ptr, "pmeRecipientKeyNotFound", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEError_ce_ptr, "pmeSenderKeyNotFound", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEError_ce_ptr, "pmeNoRecipients", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEError_ce_ptr, "pmeNoSigners", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEError_ce_ptr, "pmeActionNotSelected", 8)
	
	INIT_CLASS_ENTRY(ce, "TSBPGPMIMEErrors", NULL);
	TSBPGPMIMEErrors_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBPGPMIMEErrors_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEErrors_ce_ptr, "pmeUnknown", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEErrors_ce_ptr, "pmePGPPartNotFound", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEErrors_ce_ptr, "pmeInvalidSignature", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEErrors_ce_ptr, "pmeUnverifiableSignature", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEErrors_ce_ptr, "pmeRecipientKeyNotFound", 16)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEErrors_ce_ptr, "pmeSenderKeyNotFound", 32)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEErrors_ce_ptr, "pmeNoRecipients", 64)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEErrors_ce_ptr, "pmeNoSigners", 128)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPMIMEErrors_ce_ptr, "pmeActionNotSelected", 256)
	
	INIT_CLASS_ENTRY(ce, "TSBPGPKeysError", NULL);
	TSBPGPKeysError_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPGPKeysError_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPKeysError_ce_ptr, "pkeUnknown", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPKeysError_ce_ptr, "pkeKeysPartNotFound", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPKeysError_ce_ptr, "pkeNoPublicKeys", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBPGPKeysErrors", NULL);
	TSBPGPKeysErrors_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBPGPKeysErrors_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPKeysErrors_ce_ptr, "pkeUnknown", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPKeysErrors_ce_ptr, "pkeKeysPartNotFound", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPKeysErrors_ce_ptr, "pkeNoPublicKeys", 4)
}

void Register_SBPGPMIME_Aliases(TSRMLS_D)
{
	if (NULL == TElMessagePartHandlerPGPMime_ce_ptr)
		Register_TElMessagePartHandlerPGPMime(TSRMLS_C);
	zend_register_class_alias("ElMessagePartHandlerPGPMime", TElMessagePartHandlerPGPMime_ce_ptr);
	if (NULL == TElMessagePartHandlerPGPKeys_ce_ptr)
		Register_TElMessagePartHandlerPGPKeys(TSRMLS_C);
	zend_register_class_alias("ElMessagePartHandlerPGPKeys", TElMessagePartHandlerPGPKeys_ce_ptr);
	if (NULL == TElSimplePGPMIMEOptions_ce_ptr)
		Register_TElSimplePGPMIMEOptions(TSRMLS_C);
	zend_register_class_alias("ElSimplePGPMIMEOptions", TElSimplePGPMIMEOptions_ce_ptr);
	if (NULL == TElSimplePGPMIMEMessage_ce_ptr)
		Register_TElSimplePGPMIMEMessage(TSRMLS_C);
	zend_register_class_alias("ElSimplePGPMIMEMessage", TElSimplePGPMIMEMessage_ce_ptr);
}

