#include "sbpgpstreams.h"

zend_class_entry *TSBPGPSignatureValidity_ce_ptr = NULL;

void SB_CALLBACK TSBOutputFuncRaw(void * _ObjectData, void * Buffer, int32_t Size)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zBuffer;
	zval * zSize;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zBuffer, 0);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSize, 1);
	ZVAL_LONG(zSize, (sb_zend_long)Size);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zSize);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBInputFuncRaw(void * _ObjectData, void * Buffer, int32_t Size, int8_t * Last, int32_t * OutResult)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_INIT_PARAMS(3);
	zval * zBuffer;
	zval * zSize;
	zval * zLast;
	SB_EVENT_DECL_RETVAL_PTR(pzOutResult);
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zBuffer, 0);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSize, 1);
	ZVAL_LONG(zSize, (sb_zend_long)Size);
	SB_EVENT_INIT_ZVAL_REF(zLast, 2);
	ZVAL_BOOL(Z_REFVAL_P(zLast), (zend_bool)*Last);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(pzOutResult), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zSize);
	convert_to_boolean(Z_REFVAL_P(zLast));
	*Last = (int8_t)SB_BVAL_P(Z_REFVAL_P(zLast));
	SB_EVENT_CLEAR_ZVAL(zLast);
	if (pzOutResult)
	{
		convert_to_long(pzOutResult);
		*OutResult = (int32_t)Z_LVAL_P(pzOutResult);
		SB_EVENT_CLEAR_ZVAL(pzOutResult);
	}
}

void SB_CALLBACK TSBPGPPassphraseEventRaw(void * _ObjectData, TObjectHandle Sender, char * pcPassphrase, int32_t * szPassphrase, int8_t * Cancel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zPassphrase;
	zval * zCancel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zPassphrase, 1);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zPassphrase), pcPassphrase, *szPassphrase);
	SB_EVENT_INIT_ZVAL_REF(zCancel, 2);
	ZVAL_BOOL(Z_REFVAL_P(zCancel), (zend_bool)*Cancel);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	convert_to_string(Z_REFVAL_P(zPassphrase));
	SBCheckError(SBSetEventReturnStringA(2, Z_STRVAL_P(Z_REFVAL_P(zPassphrase)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zPassphrase))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zPassphrase);
	convert_to_boolean(Z_REFVAL_P(zCancel));
	*Cancel = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCancel));
	SB_EVENT_CLEAR_ZVAL(zCancel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBPGPKeyPassphraseEventRaw(void * _ObjectData, TObjectHandle Sender, TElPGPCustomSecretKeyHandle Key, char * pcPassphrase, int32_t * szPassphrase, int8_t * Cancel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zKey;
	zval * zPassphrase;
	zval * zCancel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zKey, 1);
	SBInitObject(zKey, TElPGPCustomSecretKey_ce_ptr, Key TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zPassphrase, 2);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zPassphrase), pcPassphrase, *szPassphrase);
	SB_EVENT_INIT_ZVAL_REF(zCancel, 3);
	ZVAL_BOOL(Z_REFVAL_P(zCancel), (zend_bool)*Cancel);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zKey);
	convert_to_string(Z_REFVAL_P(zPassphrase));
	SBCheckError(SBSetEventReturnStringA(3, Z_STRVAL_P(Z_REFVAL_P(zPassphrase)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zPassphrase))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zPassphrase);
	convert_to_boolean(Z_REFVAL_P(zCancel));
	*Cancel = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCancel));
	SB_EVENT_CLEAR_ZVAL(zCancel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBPGPSignaturesEventRaw(void * _ObjectData, TObjectHandle Sender, const TElPGPSignatureHandle pSignatures[], int32_t szSignatures, const TSBPGPSignatureValidityRaw pValidities[], int32_t szValidities)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zSignatures;
	zval * zValidities;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSignatures, 1);
	SBSetObjectArrayToZValP((TElClassHandle *)pSignatures, szSignatures, TElPGPSignature_ce_ptr, zSignatures TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zValidities, 2);
	SBSetByteArrayToZValP((uint8_t *)pValidities, szValidities, zValidities);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSignatures);
	SB_EVENT_CLEAR_ZVAL(zValidities);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBPGPKeyIDsEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pKeyIDs[][8], int32_t szKeyIDs)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zKeyIDs;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zKeyIDs, 1);
	SBSetStructArrayToZValP((void *)pKeyIDs, szKeyIDs, sizeof(TSBKeyID), TSBKeyID_ce_ptr, zKeyIDs TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zKeyIDs);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElPGPStreamClass_ce_ptr = NULL;

zend_class_entry *TElPGPStream_ce_ptr = NULL;

SB_PHP_METHOD(TElPGPStream, DataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPGPStream_DataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, Process)
{
	SBArrayZValInfo piAReadUserData;
	SBArrayZValInfo piAWriteUserData;
	zval *zpAReadUserData;
	zval *zpAWriteUserData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zpAReadUserData, &zpAWriteUserData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpAReadUserData) || SB_IS_ARRAY_TYPE_RP(zpAReadUserData) || SB_IS_NULL_TYPE_RP(zpAReadUserData) || (SB_IS_OBJECT_TYPE_RP(zpAReadUserData) && (Z_OBJCE_P(zpAReadUserData) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpAWriteUserData) || SB_IS_ARRAY_TYPE_RP(zpAWriteUserData) || SB_IS_NULL_TYPE_RP(zpAWriteUserData) || (SB_IS_OBJECT_TYPE_RP(zpAWriteUserData) && (Z_OBJCE_P(zpAWriteUserData) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpAReadUserData, &piAReadUserData TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpAWriteUserData, &piAWriteUserData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPGPStream_Process(SBGetObjectHandle(getThis() TSRMLS_CC), piAReadUserData.data, piAWriteUserData.data) TSRMLS_CC);
		SBFreePointerZValInfo(&piAReadUserData);
		SBFreePointerZValInfo(&piAWriteUserData);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, \\TSBPointer|array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, ProcessStream)
{
	sb_zend_long l4Count;
	zval *oAInputStream;
	zval *oAOutputStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oAInputStream, TStream_ce_ptr, &oAOutputStream, TStream_ce_ptr, &l4Count) == SUCCESS)
	{
		SBCheckError(TElPGPStream_ProcessStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oAInputStream TSRMLS_CC), SBGetObjectHandle(oAOutputStream TSRMLS_CC), (int32_t)l4Count) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, \\TStream, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPStream_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, get_PassTo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPStream_get_PassTo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPStream_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, set_PassTo)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPGPStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPGPStream_set_PassTo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, get_UseOldPackets)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPGPStream_get_UseOldPackets(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, set_UseOldPackets)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPGPStream_set_UseOldPackets(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, get_ProcessedLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElPGPStream_get_ProcessedLength(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, get_IgnoreDataPacketLengthTag)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPGPStream_get_IgnoreDataPacketLengthTag(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, set_IgnoreDataPacketLengthTag)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPGPStream_set_IgnoreDataPacketLengthTag(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, get_OnRead)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPReadEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPGPStream_get_OnRead(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, set_OnRead)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPGPStream_set_OnRead(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPReadEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPReadEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, get_OnWrite)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPWriteEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPGPStream_get_OnWrite(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, set_OnWrite)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPGPStream_set_OnWrite(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPWriteEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPWriteEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, get_OnFinish)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPGPStream_get_OnFinish(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, set_OnFinish)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPGPStream_set_OnFinish(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, get_OnTemporaryStream)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPTemporaryStreamEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPGPStream_get_OnTemporaryStream(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, set_OnTemporaryStream)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPGPStream_set_OnTemporaryStream(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPTemporaryStreamEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPTemporaryStreamEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPStream, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPStream_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_DataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_Process, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, AReadUserData, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AWriteUserData, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_ProcessStream, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, AInputStream, TStream, 1)
	ZEND_ARG_OBJ_INFO(0, AOutputStream, TStream, 1)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_get_PassTo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_set_PassTo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPGPStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_get_UseOldPackets, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_set_UseOldPackets, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_get_ProcessedLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_get_IgnoreDataPacketLengthTag, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_set_IgnoreDataPacketLengthTag, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_get_OnRead, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_set_OnRead, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_get_OnWrite, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_set_OnWrite, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_get_OnFinish, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_set_OnFinish, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_get_OnTemporaryStream, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream_set_OnTemporaryStream, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPStream___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPGPStream_methods[] = {
	PHP_ME(TElPGPStream, DataAvailable, arginfo_TElPGPStream_DataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, Process, arginfo_TElPGPStream_Process, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, ProcessStream, arginfo_TElPGPStream_ProcessStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, ClassType, arginfo_TElPGPStream_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPGPStream, get_PassTo, arginfo_TElPGPStream_get_PassTo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, set_PassTo, arginfo_TElPGPStream_set_PassTo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, get_UseOldPackets, arginfo_TElPGPStream_get_UseOldPackets, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, set_UseOldPackets, arginfo_TElPGPStream_set_UseOldPackets, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, get_ProcessedLength, arginfo_TElPGPStream_get_ProcessedLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, get_IgnoreDataPacketLengthTag, arginfo_TElPGPStream_get_IgnoreDataPacketLengthTag, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, set_IgnoreDataPacketLengthTag, arginfo_TElPGPStream_set_IgnoreDataPacketLengthTag, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, get_OnRead, arginfo_TElPGPStream_get_OnRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, set_OnRead, arginfo_TElPGPStream_set_OnRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, get_OnWrite, arginfo_TElPGPStream_get_OnWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, set_OnWrite, arginfo_TElPGPStream_set_OnWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, get_OnFinish, arginfo_TElPGPStream_get_OnFinish, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, set_OnFinish, arginfo_TElPGPStream_set_OnFinish, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, get_OnTemporaryStream, arginfo_TElPGPStream_get_OnTemporaryStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, set_OnTemporaryStream, arginfo_TElPGPStream_set_OnTemporaryStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPStream, __construct, arginfo_TElPGPStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPGPStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPGPStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPGPStream", TElPGPStream_methods);
	if (NULL == TPersistent_ce_ptr)
		Register_TPersistent(TSRMLS_C);
	TElPGPStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPersistent_ce_ptr);
}

zend_class_entry *TElPGPArmoringStream_ce_ptr = NULL;

SB_PHP_METHOD(TElPGPArmoringStream, DataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPGPArmoringStream_DataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPArmoringStream, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPArmoringStream_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPArmoringStream, get_LineLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPGPArmoringStream_get_LineLength(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPArmoringStream, set_LineLength)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPGPArmoringStream_set_LineLength(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPArmoringStream, get_Boundary)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPGPArmoringStream_get_Boundary(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(822015759, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPArmoringStream, set_Boundary)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPGPArmoringStream_set_Boundary(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPArmoringStream, get_Headers)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPArmoringStream_get_Headers(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPArmoringStream, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPArmoringStream_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPArmoringStream_DataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPArmoringStream_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPArmoringStream_get_LineLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPArmoringStream_set_LineLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPArmoringStream_get_Boundary, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPArmoringStream_set_Boundary, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPArmoringStream_get_Headers, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPArmoringStream___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPGPArmoringStream_methods[] = {
	PHP_ME(TElPGPArmoringStream, DataAvailable, arginfo_TElPGPArmoringStream_DataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPArmoringStream, ClassType, arginfo_TElPGPArmoringStream_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPGPArmoringStream, get_LineLength, arginfo_TElPGPArmoringStream_get_LineLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPArmoringStream, set_LineLength, arginfo_TElPGPArmoringStream_set_LineLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPArmoringStream, get_Boundary, arginfo_TElPGPArmoringStream_get_Boundary, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPArmoringStream, set_Boundary, arginfo_TElPGPArmoringStream_set_Boundary, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPArmoringStream, get_Headers, arginfo_TElPGPArmoringStream_get_Headers, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPArmoringStream, __construct, arginfo_TElPGPArmoringStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPGPArmoringStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPGPArmoringStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPGPArmoringStream", TElPGPArmoringStream_methods);
	if (NULL == TElPGPStream_ce_ptr)
		Register_TElPGPStream(TSRMLS_C);
	TElPGPArmoringStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPGPStream_ce_ptr);
}

zend_class_entry *TElPGPDearmoringStream_ce_ptr = NULL;

SB_PHP_METHOD(TElPGPDearmoringStream, DataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPGPDearmoringStream_DataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDearmoringStream, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPDearmoringStream_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDearmoringStream, get_Boundary)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPGPDearmoringStream_get_Boundary(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1047222395, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDearmoringStream, get_Headers)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPDearmoringStream_get_Headers(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDearmoringStream, get_MultiPart)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPGPDearmoringStream_get_MultiPart(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDearmoringStream, set_MultiPart)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPGPDearmoringStream_set_MultiPart(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDearmoringStream, get_InputEncoding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPGPDearmoringStream_get_InputEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDearmoringStream, set_InputEncoding)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPGPDearmoringStream_set_InputEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDearmoringStream, get_OnInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPGPDearmoringStream_get_OnInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDearmoringStream, set_OnInfo)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPGPDearmoringStream_set_OnInfo(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDearmoringStream, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPDearmoringStream_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDearmoringStream_DataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDearmoringStream_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDearmoringStream_get_Boundary, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDearmoringStream_get_Headers, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDearmoringStream_get_MultiPart, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDearmoringStream_set_MultiPart, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDearmoringStream_get_InputEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDearmoringStream_set_InputEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDearmoringStream_get_OnInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDearmoringStream_set_OnInfo, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDearmoringStream___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPGPDearmoringStream_methods[] = {
	PHP_ME(TElPGPDearmoringStream, DataAvailable, arginfo_TElPGPDearmoringStream_DataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDearmoringStream, ClassType, arginfo_TElPGPDearmoringStream_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPGPDearmoringStream, get_Boundary, arginfo_TElPGPDearmoringStream_get_Boundary, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDearmoringStream, get_Headers, arginfo_TElPGPDearmoringStream_get_Headers, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDearmoringStream, get_MultiPart, arginfo_TElPGPDearmoringStream_get_MultiPart, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDearmoringStream, set_MultiPart, arginfo_TElPGPDearmoringStream_set_MultiPart, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDearmoringStream, get_InputEncoding, arginfo_TElPGPDearmoringStream_get_InputEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDearmoringStream, set_InputEncoding, arginfo_TElPGPDearmoringStream_set_InputEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDearmoringStream, get_OnInfo, arginfo_TElPGPDearmoringStream_get_OnInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDearmoringStream, set_OnInfo, arginfo_TElPGPDearmoringStream_set_OnInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDearmoringStream, __construct, arginfo_TElPGPDearmoringStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPGPDearmoringStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPGPDearmoringStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPGPDearmoringStream", TElPGPDearmoringStream_methods);
	if (NULL == TElPGPStream_ce_ptr)
		Register_TElPGPStream(TSRMLS_C);
	TElPGPDearmoringStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPGPStream_ce_ptr);
}

zend_class_entry *TElPGPEnvelopingStream_ce_ptr = NULL;

SB_PHP_METHOD(TElPGPEnvelopingStream, DataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPGPEnvelopingStream_DataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, AddSignature)
{
	zval *oSignature;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSignature, TElPGPSignature_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPGPEnvelopingStream_AddSignature(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSignature TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPSignature)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, RemoveSignature)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElPGPEnvelopingStream_RemoveSignature(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, ClearSignatures)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPGPEnvelopingStream_ClearSignatures(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPEnvelopingStream_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, get_Filename)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPGPEnvelopingStream_get_Filename(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-431682611, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, set_Filename)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElPGPEnvelopingStream_set_Filename(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, get_Timestamp)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElPGPEnvelopingStream_get_Timestamp(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, set_Timestamp)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElPGPEnvelopingStream_set_Timestamp(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, get_TextMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPGPEnvelopingStream_get_TextMode(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, set_TextMode)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPGPEnvelopingStream_set_TextMode(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, get_Signatures)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPEnvelopingStream_get_Signatures(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPSignature_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, get_SignatureCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPGPEnvelopingStream_get_SignatureCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, get_UseOnePassSignatures)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPGPEnvelopingStream_get_UseOnePassSignatures(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, set_UseOnePassSignatures)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPGPEnvelopingStream_set_UseOnePassSignatures(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEnvelopingStream, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPEnvelopingStream_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_DataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_AddSignature, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Signature, TElPGPSignature, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_RemoveSignature, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_ClearSignatures, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_get_Filename, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_set_Filename, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_get_Timestamp, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_set_Timestamp, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_get_TextMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_set_TextMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_get_Signatures, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_get_SignatureCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_get_UseOnePassSignatures, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream_set_UseOnePassSignatures, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEnvelopingStream___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPGPEnvelopingStream_methods[] = {
	PHP_ME(TElPGPEnvelopingStream, DataAvailable, arginfo_TElPGPEnvelopingStream_DataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEnvelopingStream, AddSignature, arginfo_TElPGPEnvelopingStream_AddSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEnvelopingStream, RemoveSignature, arginfo_TElPGPEnvelopingStream_RemoveSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEnvelopingStream, ClearSignatures, arginfo_TElPGPEnvelopingStream_ClearSignatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEnvelopingStream, ClassType, arginfo_TElPGPEnvelopingStream_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPGPEnvelopingStream, get_Filename, arginfo_TElPGPEnvelopingStream_get_Filename, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEnvelopingStream, set_Filename, arginfo_TElPGPEnvelopingStream_set_Filename, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEnvelopingStream, get_Timestamp, arginfo_TElPGPEnvelopingStream_get_Timestamp, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEnvelopingStream, set_Timestamp, arginfo_TElPGPEnvelopingStream_set_Timestamp, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEnvelopingStream, get_TextMode, arginfo_TElPGPEnvelopingStream_get_TextMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEnvelopingStream, set_TextMode, arginfo_TElPGPEnvelopingStream_set_TextMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEnvelopingStream, get_Signatures, arginfo_TElPGPEnvelopingStream_get_Signatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEnvelopingStream, get_SignatureCount, arginfo_TElPGPEnvelopingStream_get_SignatureCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEnvelopingStream, get_UseOnePassSignatures, arginfo_TElPGPEnvelopingStream_get_UseOnePassSignatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEnvelopingStream, set_UseOnePassSignatures, arginfo_TElPGPEnvelopingStream_set_UseOnePassSignatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEnvelopingStream, __construct, arginfo_TElPGPEnvelopingStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPGPEnvelopingStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPGPEnvelopingStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPGPEnvelopingStream", TElPGPEnvelopingStream_methods);
	if (NULL == TElPGPStream_ce_ptr)
		Register_TElPGPStream(TSRMLS_C);
	TElPGPEnvelopingStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPGPStream_ce_ptr);
}

zend_class_entry *TElPGPUnenvelopingStream_ce_ptr = NULL;

SB_PHP_METHOD(TElPGPUnenvelopingStream, DataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPGPUnenvelopingStream_DataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPUnenvelopingStream, DataCompleted)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPGPUnenvelopingStream_DataCompleted(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPUnenvelopingStream, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPUnenvelopingStream_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPUnenvelopingStream, get_Filename)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElPGPUnenvelopingStream_get_Filename(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1999722763, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPUnenvelopingStream, get_Timestamp)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElPGPUnenvelopingStream_get_Timestamp(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPUnenvelopingStream, set_Timestamp)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElPGPUnenvelopingStream_set_Timestamp(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPUnenvelopingStream, get_HashingPool)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPUnenvelopingStream_get_HashingPool(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPHashingPool_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPUnenvelopingStream, set_HashingPool)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPGPHashingPool_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPGPUnenvelopingStream_set_HashingPool(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPHashingPool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPUnenvelopingStream, get_TextHashingPool)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPUnenvelopingStream_get_TextHashingPool(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPHashingPool_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPUnenvelopingStream, set_TextHashingPool)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPGPHashingPool_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPGPUnenvelopingStream_set_TextHashingPool(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPHashingPool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPUnenvelopingStream, get_BuggyTextHashingPool)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPUnenvelopingStream_get_BuggyTextHashingPool(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPHashingPool_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPUnenvelopingStream, set_BuggyTextHashingPool)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPGPHashingPool_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPGPUnenvelopingStream_set_BuggyTextHashingPool(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPHashingPool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPUnenvelopingStream, get_OnInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPGPUnenvelopingStream_get_OnInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPUnenvelopingStream, set_OnInfo)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPGPUnenvelopingStream_set_OnInfo(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPUnenvelopingStream, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPUnenvelopingStream_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream_DataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream_DataCompleted, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream_get_Filename, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream_get_Timestamp, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream_set_Timestamp, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream_get_HashingPool, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream_set_HashingPool, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPGPHashingPool, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream_get_TextHashingPool, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream_set_TextHashingPool, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPGPHashingPool, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream_get_BuggyTextHashingPool, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream_set_BuggyTextHashingPool, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPGPHashingPool, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream_get_OnInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream_set_OnInfo, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPUnenvelopingStream___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPGPUnenvelopingStream_methods[] = {
	PHP_ME(TElPGPUnenvelopingStream, DataAvailable, arginfo_TElPGPUnenvelopingStream_DataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPUnenvelopingStream, DataCompleted, arginfo_TElPGPUnenvelopingStream_DataCompleted, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPUnenvelopingStream, ClassType, arginfo_TElPGPUnenvelopingStream_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPGPUnenvelopingStream, get_Filename, arginfo_TElPGPUnenvelopingStream_get_Filename, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPUnenvelopingStream, get_Timestamp, arginfo_TElPGPUnenvelopingStream_get_Timestamp, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPUnenvelopingStream, set_Timestamp, arginfo_TElPGPUnenvelopingStream_set_Timestamp, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPUnenvelopingStream, get_HashingPool, arginfo_TElPGPUnenvelopingStream_get_HashingPool, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPUnenvelopingStream, set_HashingPool, arginfo_TElPGPUnenvelopingStream_set_HashingPool, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPUnenvelopingStream, get_TextHashingPool, arginfo_TElPGPUnenvelopingStream_get_TextHashingPool, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPUnenvelopingStream, set_TextHashingPool, arginfo_TElPGPUnenvelopingStream_set_TextHashingPool, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPUnenvelopingStream, get_BuggyTextHashingPool, arginfo_TElPGPUnenvelopingStream_get_BuggyTextHashingPool, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPUnenvelopingStream, set_BuggyTextHashingPool, arginfo_TElPGPUnenvelopingStream_set_BuggyTextHashingPool, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPUnenvelopingStream, get_OnInfo, arginfo_TElPGPUnenvelopingStream_get_OnInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPUnenvelopingStream, set_OnInfo, arginfo_TElPGPUnenvelopingStream_set_OnInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPUnenvelopingStream, __construct, arginfo_TElPGPUnenvelopingStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPGPUnenvelopingStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPGPUnenvelopingStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPGPUnenvelopingStream", TElPGPUnenvelopingStream_methods);
	if (NULL == TElPGPStream_ce_ptr)
		Register_TElPGPStream(TSRMLS_C);
	TElPGPUnenvelopingStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPGPStream_ce_ptr);
}

zend_class_entry *TElPGPEncryptingStream_ce_ptr = NULL;

SB_PHP_METHOD(TElPGPEncryptingStream, DataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPGPEncryptingStream_DataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEncryptingStream, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPEncryptingStream_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEncryptingStream, get_Keyring)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPEncryptingStream_get_Keyring(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPKeyring_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEncryptingStream, set_Keyring)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPGPKeyring_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPGPEncryptingStream_set_Keyring(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPKeyring)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEncryptingStream, get_Passphrases)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPEncryptingStream_get_Passphrases(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEncryptingStream, get_IntegrityProtected)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPGPEncryptingStream_get_IntegrityProtected(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEncryptingStream, set_IntegrityProtected)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElPGPEncryptingStream_set_IntegrityProtected(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEncryptingStream, get_Algorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPGPEncryptingStream_get_Algorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEncryptingStream, set_Algorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPGPEncryptingStream_set_Algorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEncryptingStream, get_PassphraseAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPGPEncryptingStream_get_PassphraseAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEncryptingStream, set_PassphraseAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPGPEncryptingStream_set_PassphraseAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEncryptingStream, get_Protection)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPProtectionTypeRaw fOutResultRaw = 0;
		SBCheckError(TElPGPEncryptingStream_get_Protection(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEncryptingStream, set_Protection)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPGPEncryptingStream_set_Protection(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPGPProtectionTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEncryptingStream, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPEncryptingStream_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEncryptingStream_DataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEncryptingStream_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEncryptingStream_get_Keyring, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEncryptingStream_set_Keyring, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPGPKeyring, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEncryptingStream_get_Passphrases, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEncryptingStream_get_IntegrityProtected, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEncryptingStream_set_IntegrityProtected, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEncryptingStream_get_Algorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEncryptingStream_set_Algorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEncryptingStream_get_PassphraseAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEncryptingStream_set_PassphraseAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEncryptingStream_get_Protection, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEncryptingStream_set_Protection, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEncryptingStream___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPGPEncryptingStream_methods[] = {
	PHP_ME(TElPGPEncryptingStream, DataAvailable, arginfo_TElPGPEncryptingStream_DataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEncryptingStream, ClassType, arginfo_TElPGPEncryptingStream_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPGPEncryptingStream, get_Keyring, arginfo_TElPGPEncryptingStream_get_Keyring, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEncryptingStream, set_Keyring, arginfo_TElPGPEncryptingStream_set_Keyring, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEncryptingStream, get_Passphrases, arginfo_TElPGPEncryptingStream_get_Passphrases, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEncryptingStream, get_IntegrityProtected, arginfo_TElPGPEncryptingStream_get_IntegrityProtected, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEncryptingStream, set_IntegrityProtected, arginfo_TElPGPEncryptingStream_set_IntegrityProtected, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEncryptingStream, get_Algorithm, arginfo_TElPGPEncryptingStream_get_Algorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEncryptingStream, set_Algorithm, arginfo_TElPGPEncryptingStream_set_Algorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEncryptingStream, get_PassphraseAlgorithm, arginfo_TElPGPEncryptingStream_get_PassphraseAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEncryptingStream, set_PassphraseAlgorithm, arginfo_TElPGPEncryptingStream_set_PassphraseAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEncryptingStream, get_Protection, arginfo_TElPGPEncryptingStream_get_Protection, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEncryptingStream, set_Protection, arginfo_TElPGPEncryptingStream_set_Protection, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEncryptingStream, __construct, arginfo_TElPGPEncryptingStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPGPEncryptingStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPGPEncryptingStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPGPEncryptingStream", TElPGPEncryptingStream_methods);
	if (NULL == TElPGPStream_ce_ptr)
		Register_TElPGPStream(TSRMLS_C);
	TElPGPEncryptingStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPGPStream_ce_ptr);
}

zend_class_entry *TElPGPDecryptingStream_ce_ptr = NULL;

SB_PHP_METHOD(TElPGPDecryptingStream, DataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPGPDecryptingStream_DataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPDecryptingStream_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, get_Keyring)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPDecryptingStream_get_Keyring(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPKeyring_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, set_Keyring)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPGPKeyring_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPGPDecryptingStream_set_Keyring(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPKeyring)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, get_IntegrityProtected)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPGPDecryptingStream_get_IntegrityProtected(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, get_Algorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPGPDecryptingStream_get_Algorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, get_Protection)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPProtectionTypeRaw fOutResultRaw = 0;
		SBCheckError(TElPGPDecryptingStream_get_Protection(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, get_SymmetricallyEncrypted)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPGPDecryptingStream_get_SymmetricallyEncrypted(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, get_OnPassphrase)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPPassphraseEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPGPDecryptingStream_get_OnPassphrase(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, set_OnPassphrase)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPGPDecryptingStream_set_OnPassphrase(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPPassphraseEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPPassphraseEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, get_OnKeyPassphrase)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPKeyPassphraseEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPGPDecryptingStream_get_OnKeyPassphrase(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, set_OnKeyPassphrase)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPGPDecryptingStream_set_OnKeyPassphrase(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPKeyPassphraseEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPKeyPassphraseEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, get_OnKeyIDs)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPKeyIDsEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPGPDecryptingStream_get_OnKeyIDs(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, set_OnKeyIDs)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPGPDecryptingStream_set_OnKeyIDs(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPKeyIDsEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPKeyIDsEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, get_OnDecryptionStart)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPGPDecryptingStream_get_OnDecryptionStart(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, set_OnDecryptionStart)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPGPDecryptingStream_set_OnDecryptionStart(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecryptingStream, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPDecryptingStream_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_DataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_get_Keyring, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_set_Keyring, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPGPKeyring, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_get_IntegrityProtected, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_get_Algorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_get_Protection, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_get_SymmetricallyEncrypted, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_get_OnPassphrase, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_set_OnPassphrase, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_get_OnKeyPassphrase, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_set_OnKeyPassphrase, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_get_OnKeyIDs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_set_OnKeyIDs, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_get_OnDecryptionStart, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream_set_OnDecryptionStart, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecryptingStream___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPGPDecryptingStream_methods[] = {
	PHP_ME(TElPGPDecryptingStream, DataAvailable, arginfo_TElPGPDecryptingStream_DataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, ClassType, arginfo_TElPGPDecryptingStream_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPGPDecryptingStream, get_Keyring, arginfo_TElPGPDecryptingStream_get_Keyring, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, set_Keyring, arginfo_TElPGPDecryptingStream_set_Keyring, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, get_IntegrityProtected, arginfo_TElPGPDecryptingStream_get_IntegrityProtected, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, get_Algorithm, arginfo_TElPGPDecryptingStream_get_Algorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, get_Protection, arginfo_TElPGPDecryptingStream_get_Protection, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, get_SymmetricallyEncrypted, arginfo_TElPGPDecryptingStream_get_SymmetricallyEncrypted, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, get_OnPassphrase, arginfo_TElPGPDecryptingStream_get_OnPassphrase, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, set_OnPassphrase, arginfo_TElPGPDecryptingStream_set_OnPassphrase, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, get_OnKeyPassphrase, arginfo_TElPGPDecryptingStream_get_OnKeyPassphrase, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, set_OnKeyPassphrase, arginfo_TElPGPDecryptingStream_set_OnKeyPassphrase, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, get_OnKeyIDs, arginfo_TElPGPDecryptingStream_get_OnKeyIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, set_OnKeyIDs, arginfo_TElPGPDecryptingStream_set_OnKeyIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, get_OnDecryptionStart, arginfo_TElPGPDecryptingStream_get_OnDecryptionStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, set_OnDecryptionStart, arginfo_TElPGPDecryptingStream_set_OnDecryptionStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecryptingStream, __construct, arginfo_TElPGPDecryptingStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPGPDecryptingStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPGPDecryptingStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPGPDecryptingStream", TElPGPDecryptingStream_methods);
	if (NULL == TElPGPStream_ce_ptr)
		Register_TElPGPStream(TSRMLS_C);
	TElPGPDecryptingStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPGPStream_ce_ptr);
}

zend_class_entry *TElPGPCompressingStream_ce_ptr = NULL;

SB_PHP_METHOD(TElPGPCompressingStream, DataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPGPCompressingStream_DataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPCompressingStream, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPCompressingStream_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPCompressingStream, get_Algorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPGPCompressingStream_get_Algorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPCompressingStream, set_Algorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPGPCompressingStream_set_Algorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPCompressingStream, get_CompressionLevel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPGPCompressingStream_get_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPCompressingStream, set_CompressionLevel)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPGPCompressingStream_set_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPCompressingStream, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPCompressingStream_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPCompressingStream_DataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPCompressingStream_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPCompressingStream_get_Algorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPCompressingStream_set_Algorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPCompressingStream_get_CompressionLevel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPCompressingStream_set_CompressionLevel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPCompressingStream___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPGPCompressingStream_methods[] = {
	PHP_ME(TElPGPCompressingStream, DataAvailable, arginfo_TElPGPCompressingStream_DataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPCompressingStream, ClassType, arginfo_TElPGPCompressingStream_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPGPCompressingStream, get_Algorithm, arginfo_TElPGPCompressingStream_get_Algorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPCompressingStream, set_Algorithm, arginfo_TElPGPCompressingStream_set_Algorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPCompressingStream, get_CompressionLevel, arginfo_TElPGPCompressingStream_get_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPCompressingStream, set_CompressionLevel, arginfo_TElPGPCompressingStream_set_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPCompressingStream, __construct, arginfo_TElPGPCompressingStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPGPCompressingStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPGPCompressingStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPGPCompressingStream", TElPGPCompressingStream_methods);
	if (NULL == TElPGPStream_ce_ptr)
		Register_TElPGPStream(TSRMLS_C);
	TElPGPCompressingStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPGPStream_ce_ptr);
}

zend_class_entry *TElPGPDecompressingStream_ce_ptr = NULL;

SB_PHP_METHOD(TElPGPDecompressingStream, DataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPGPDecompressingStream_DataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecompressingStream, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPDecompressingStream_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecompressingStream, get_Algorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPGPDecompressingStream_get_Algorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecompressingStream, get_OnDecompressionStart)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPGPDecompressingStream_get_OnDecompressionStart(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecompressingStream, set_OnDecompressionStart)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPGPDecompressingStream_set_OnDecompressionStart(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPDecompressingStream, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPDecompressingStream_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecompressingStream_DataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecompressingStream_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecompressingStream_get_Algorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecompressingStream_get_OnDecompressionStart, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecompressingStream_set_OnDecompressionStart, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPDecompressingStream___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPGPDecompressingStream_methods[] = {
	PHP_ME(TElPGPDecompressingStream, DataAvailable, arginfo_TElPGPDecompressingStream_DataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecompressingStream, ClassType, arginfo_TElPGPDecompressingStream_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPGPDecompressingStream, get_Algorithm, arginfo_TElPGPDecompressingStream_get_Algorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecompressingStream, get_OnDecompressionStart, arginfo_TElPGPDecompressingStream_get_OnDecompressionStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecompressingStream, set_OnDecompressionStart, arginfo_TElPGPDecompressingStream_set_OnDecompressionStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPDecompressingStream, __construct, arginfo_TElPGPDecompressingStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPGPDecompressingStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPGPDecompressingStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPGPDecompressingStream", TElPGPDecompressingStream_methods);
	if (NULL == TElPGPStream_ce_ptr)
		Register_TElPGPStream(TSRMLS_C);
	TElPGPDecompressingStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPGPStream_ce_ptr);
}

zend_class_entry *TElPGPSigningStream_ce_ptr = NULL;

SB_PHP_METHOD(TElPGPSigningStream, DataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPGPSigningStream_DataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPSigningStream, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPSigningStream_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPSigningStream, get_HashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPGPSigningStream_get_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPSigningStream, set_HashAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPGPSigningStream_set_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPSigningStream, get_Keyring)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPSigningStream_get_Keyring(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPKeyring_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPSigningStream, set_Keyring)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPGPKeyring_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPGPSigningStream_set_Keyring(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPKeyring)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPSigningStream, get_Headers)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPSigningStream_get_Headers(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPSigningStream, get_OnKeyPassphrase)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPKeyPassphraseEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPGPSigningStream_get_OnKeyPassphrase(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPSigningStream, set_OnKeyPassphrase)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPGPSigningStream_set_OnKeyPassphrase(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPKeyPassphraseEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPKeyPassphraseEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPSigningStream, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPSigningStream_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPSigningStream_DataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPSigningStream_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPSigningStream_get_HashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPSigningStream_set_HashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPSigningStream_get_Keyring, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPSigningStream_set_Keyring, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPGPKeyring, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPSigningStream_get_Headers, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPSigningStream_get_OnKeyPassphrase, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPSigningStream_set_OnKeyPassphrase, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPSigningStream___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPGPSigningStream_methods[] = {
	PHP_ME(TElPGPSigningStream, DataAvailable, arginfo_TElPGPSigningStream_DataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPSigningStream, ClassType, arginfo_TElPGPSigningStream_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPGPSigningStream, get_HashAlgorithm, arginfo_TElPGPSigningStream_get_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPSigningStream, set_HashAlgorithm, arginfo_TElPGPSigningStream_set_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPSigningStream, get_Keyring, arginfo_TElPGPSigningStream_get_Keyring, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPSigningStream, set_Keyring, arginfo_TElPGPSigningStream_set_Keyring, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPSigningStream, get_Headers, arginfo_TElPGPSigningStream_get_Headers, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPSigningStream, get_OnKeyPassphrase, arginfo_TElPGPSigningStream_get_OnKeyPassphrase, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPSigningStream, set_OnKeyPassphrase, arginfo_TElPGPSigningStream_set_OnKeyPassphrase, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPSigningStream, __construct, arginfo_TElPGPSigningStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPGPSigningStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPGPSigningStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPGPSigningStream", TElPGPSigningStream_methods);
	if (NULL == TElPGPStream_ce_ptr)
		Register_TElPGPStream(TSRMLS_C);
	TElPGPSigningStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPGPStream_ce_ptr);
}

zend_class_entry *TElPGPClearTextVerifyingStream_ce_ptr = NULL;

SB_PHP_METHOD(TElPGPClearTextVerifyingStream, DataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPGPClearTextVerifyingStream_DataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPClearTextVerifyingStream, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPClearTextVerifyingStream_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPClearTextVerifyingStream, get_Keyring)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPClearTextVerifyingStream_get_Keyring(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPKeyring_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPClearTextVerifyingStream, set_Keyring)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPGPKeyring_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPGPClearTextVerifyingStream_set_Keyring(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPGPKeyring)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPClearTextVerifyingStream, get_InputEncoding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPGPClearTextVerifyingStream_get_InputEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPClearTextVerifyingStream, set_InputEncoding)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPGPClearTextVerifyingStream_set_InputEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPClearTextVerifyingStream, get_OnKeyIDs)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPKeyIDsEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPGPClearTextVerifyingStream_get_OnKeyIDs(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPClearTextVerifyingStream, set_OnKeyIDs)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPGPClearTextVerifyingStream_set_OnKeyIDs(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPKeyIDsEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPKeyIDsEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPClearTextVerifyingStream, get_OnSignatures)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPGPSignaturesEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElPGPClearTextVerifyingStream_get_OnSignatures(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPClearTextVerifyingStream, set_OnSignatures)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElPGPClearTextVerifyingStream_set_OnSignatures(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBPGPSignaturesEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPGPSignaturesEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPClearTextVerifyingStream, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPClearTextVerifyingStream_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPClearTextVerifyingStream_DataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPClearTextVerifyingStream_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPClearTextVerifyingStream_get_Keyring, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPClearTextVerifyingStream_set_Keyring, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPGPKeyring, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPClearTextVerifyingStream_get_InputEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPClearTextVerifyingStream_set_InputEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPClearTextVerifyingStream_get_OnKeyIDs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPClearTextVerifyingStream_set_OnKeyIDs, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPClearTextVerifyingStream_get_OnSignatures, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPClearTextVerifyingStream_set_OnSignatures, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPClearTextVerifyingStream___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPGPClearTextVerifyingStream_methods[] = {
	PHP_ME(TElPGPClearTextVerifyingStream, DataAvailable, arginfo_TElPGPClearTextVerifyingStream_DataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPClearTextVerifyingStream, ClassType, arginfo_TElPGPClearTextVerifyingStream_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPGPClearTextVerifyingStream, get_Keyring, arginfo_TElPGPClearTextVerifyingStream_get_Keyring, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPClearTextVerifyingStream, set_Keyring, arginfo_TElPGPClearTextVerifyingStream_set_Keyring, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPClearTextVerifyingStream, get_InputEncoding, arginfo_TElPGPClearTextVerifyingStream_get_InputEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPClearTextVerifyingStream, set_InputEncoding, arginfo_TElPGPClearTextVerifyingStream_set_InputEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPClearTextVerifyingStream, get_OnKeyIDs, arginfo_TElPGPClearTextVerifyingStream_get_OnKeyIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPClearTextVerifyingStream, set_OnKeyIDs, arginfo_TElPGPClearTextVerifyingStream_set_OnKeyIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPClearTextVerifyingStream, get_OnSignatures, arginfo_TElPGPClearTextVerifyingStream_get_OnSignatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPClearTextVerifyingStream, set_OnSignatures, arginfo_TElPGPClearTextVerifyingStream_set_OnSignatures, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPClearTextVerifyingStream, __construct, arginfo_TElPGPClearTextVerifyingStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPGPClearTextVerifyingStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPGPClearTextVerifyingStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPGPClearTextVerifyingStream", TElPGPClearTextVerifyingStream_methods);
	if (NULL == TElPGPStream_ce_ptr)
		Register_TElPGPStream(TSRMLS_C);
	TElPGPClearTextVerifyingStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPGPStream_ce_ptr);
}

zend_class_entry *TElPGPEntityStream_ce_ptr = NULL;

SB_PHP_METHOD(TElPGPEntityStream, DataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPGPEntityStream_DataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEntityStream, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPEntityStream_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEntityStream, get_Entity)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPEntityStream_get_Entity(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPGPEntity_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPGPEntityStream, __construct)
{
	sb_zend_long u1PktType;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPEntityStream_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1PktType) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPGPEntityStream_Create_1((uint8_t)u1PktType, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEntityStream_DataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEntityStream_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEntityStream_get_Entity, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPGPEntityStream___construct, 0, 0, 0)
	ZEND_ARG_INFO(0, PktType)
ZEND_END_ARG_INFO()

static zend_function_entry TElPGPEntityStream_methods[] = {
	PHP_ME(TElPGPEntityStream, DataAvailable, arginfo_TElPGPEntityStream_DataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEntityStream, ClassType, arginfo_TElPGPEntityStream_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElPGPEntityStream, get_Entity, arginfo_TElPGPEntityStream_get_Entity, ZEND_ACC_PUBLIC)
	PHP_ME(TElPGPEntityStream, __construct, arginfo_TElPGPEntityStream___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPGPEntityStream(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPGPEntityStream_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPGPEntityStream", TElPGPEntityStream_methods);
	if (NULL == TElPGPStream_ce_ptr)
		Register_TElPGPStream(TSRMLS_C);
	TElPGPEntityStream_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElPGPStream_ce_ptr);
}

void Register_SBPGPStreams_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBPGPSignatureValidity", NULL);
	TSBPGPSignatureValidity_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPGPSignatureValidity_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPSignatureValidity_ce_ptr, "svValid", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPSignatureValidity_ce_ptr, "svCorrupted", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPSignatureValidity_ce_ptr, "svUnknownAlgorithm", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPSignatureValidity_ce_ptr, "svNoKey", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBPGPSignatureValidity_ce_ptr, "svUnknown", 4)
}

void Register_SBPGPStreams_Aliases(TSRMLS_D)
{
	if (NULL == TElPGPStream_ce_ptr)
		Register_TElPGPStream(TSRMLS_C);
	zend_register_class_alias("ElPGPStream", TElPGPStream_ce_ptr);
	if (NULL == TElPGPArmoringStream_ce_ptr)
		Register_TElPGPArmoringStream(TSRMLS_C);
	zend_register_class_alias("ElPGPArmoringStream", TElPGPArmoringStream_ce_ptr);
	if (NULL == TElPGPDearmoringStream_ce_ptr)
		Register_TElPGPDearmoringStream(TSRMLS_C);
	zend_register_class_alias("ElPGPDearmoringStream", TElPGPDearmoringStream_ce_ptr);
	if (NULL == TElPGPEnvelopingStream_ce_ptr)
		Register_TElPGPEnvelopingStream(TSRMLS_C);
	zend_register_class_alias("ElPGPEnvelopingStream", TElPGPEnvelopingStream_ce_ptr);
	if (NULL == TElPGPUnenvelopingStream_ce_ptr)
		Register_TElPGPUnenvelopingStream(TSRMLS_C);
	zend_register_class_alias("ElPGPUnenvelopingStream", TElPGPUnenvelopingStream_ce_ptr);
	if (NULL == TElPGPEncryptingStream_ce_ptr)
		Register_TElPGPEncryptingStream(TSRMLS_C);
	zend_register_class_alias("ElPGPEncryptingStream", TElPGPEncryptingStream_ce_ptr);
	if (NULL == TElPGPDecryptingStream_ce_ptr)
		Register_TElPGPDecryptingStream(TSRMLS_C);
	zend_register_class_alias("ElPGPDecryptingStream", TElPGPDecryptingStream_ce_ptr);
	if (NULL == TElPGPCompressingStream_ce_ptr)
		Register_TElPGPCompressingStream(TSRMLS_C);
	zend_register_class_alias("ElPGPCompressingStream", TElPGPCompressingStream_ce_ptr);
	if (NULL == TElPGPDecompressingStream_ce_ptr)
		Register_TElPGPDecompressingStream(TSRMLS_C);
	zend_register_class_alias("ElPGPDecompressingStream", TElPGPDecompressingStream_ce_ptr);
	if (NULL == TElPGPSigningStream_ce_ptr)
		Register_TElPGPSigningStream(TSRMLS_C);
	zend_register_class_alias("ElPGPSigningStream", TElPGPSigningStream_ce_ptr);
	if (NULL == TElPGPClearTextVerifyingStream_ce_ptr)
		Register_TElPGPClearTextVerifyingStream(TSRMLS_C);
	zend_register_class_alias("ElPGPClearTextVerifyingStream", TElPGPClearTextVerifyingStream_ce_ptr);
	if (NULL == TElPGPEntityStream_ce_ptr)
		Register_TElPGPEntityStream(TSRMLS_C);
	zend_register_class_alias("ElPGPEntityStream", TElPGPEntityStream_ce_ptr);
	TElPGPStreamClass_ce_ptr = TObject_ce_ptr;
	zend_register_class_alias("TElPGPStreamClass", TElPGPStreamClass_ce_ptr);
	zend_register_class_alias("ElPGPStreamClass", TObject_ce_ptr);
}

