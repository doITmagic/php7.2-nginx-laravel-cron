#include "sbdefs.h"
#ifdef SB_WINDOWS
#include "sbpivkey.h"

SB_PHP_FUNCTION(SBPIVKey, PivECDSASignature)
{
	sb_zend_long l4size;
#ifndef CPU64
	sb_zend_long u4hCard;
#endif
	sb_zend_long u4hKey;
#ifdef CPU64
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo aioutbuf;
	SBArrayZValInfo piinbuf;
	zval *zaoutbuf;
	zval *zpinbuf;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llzlz", &u4hCard, &u4hKey, &zpinbuf, &l4size, &zaoutbuf) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))) && ((IS_STRING == Z_TYPE_P(zaoutbuf)) || (IS_ARRAY == Z_TYPE_P(zaoutbuf)) || (IS_NULL == Z_TYPE_P(zaoutbuf))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llzlz", &u8hCard, &u4hKey, &zpinbuf, &l4size, &zaoutbuf) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))) && ((IS_STRING == Z_TYPE_P(zaoutbuf)) || (IS_ARRAY == Z_TYPE_P(zaoutbuf)) || (IS_NULL == Z_TYPE_P(zaoutbuf))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpinbuf, &piinbuf TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaoutbuf, &aioutbuf TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivECDSASignature((uint32_t)u4hCard, (uint32_t)u4hKey, piinbuf.data, (int32_t)l4size, aioutbuf.data, aioutbuf.len, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivECDSASignature((uint64_t)u8hCard, (uint32_t)u4hKey, piinbuf.data, (int32_t)l4size, aioutbuf.data, aioutbuf.len, &u4OutResultRaw) TSRMLS_CC);
#endif
		SBFreePointerZValInfo(&piinbuf);
		SBFreeArrayZValInfo(&aioutbuf);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, TSBPointer|array of byte|string|NULL, integer, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivRSASignature)
{
	sb_zend_long l4size;
#ifndef CPU64
	sb_zend_long u4hCard;
#endif
	sb_zend_long u4hKey;
#ifdef CPU64
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo aioutbuf;
	SBArrayZValInfo piinbuf;
	zval *zaoutbuf;
	zval *zpinbuf;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llzlz", &u4hCard, &u4hKey, &zpinbuf, &l4size, &zaoutbuf) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))) && ((IS_STRING == Z_TYPE_P(zaoutbuf)) || (IS_ARRAY == Z_TYPE_P(zaoutbuf)) || (IS_NULL == Z_TYPE_P(zaoutbuf))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llzlz", &u8hCard, &u4hKey, &zpinbuf, &l4size, &zaoutbuf) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))) && ((IS_STRING == Z_TYPE_P(zaoutbuf)) || (IS_ARRAY == Z_TYPE_P(zaoutbuf)) || (IS_NULL == Z_TYPE_P(zaoutbuf))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpinbuf, &piinbuf TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaoutbuf, &aioutbuf TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivRSASignature((uint32_t)u4hCard, (uint32_t)u4hKey, piinbuf.data, (int32_t)l4size, aioutbuf.data, aioutbuf.len, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivRSASignature((uint64_t)u8hCard, (uint32_t)u4hKey, piinbuf.data, (int32_t)l4size, aioutbuf.data, aioutbuf.len, &u4OutResultRaw) TSRMLS_CC);
#endif
		SBFreePointerZValInfo(&piinbuf);
		SBFreeArrayZValInfo(&aioutbuf);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, TSBPointer|array of byte|string|NULL, integer, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivEncryptAES128)
{
	sb_zend_long l4size;
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo piinbuf;
	zval *zpinbuf;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u4hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u8hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpinbuf, &piinbuf TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivEncryptAES128((uint32_t)u4hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivEncryptAES128((uint64_t)u8hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#endif
		SBFreePointerZValInfo(&piinbuf);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivEncryptAES192)
{
	sb_zend_long l4size;
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo piinbuf;
	zval *zpinbuf;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u4hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u8hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpinbuf, &piinbuf TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivEncryptAES192((uint32_t)u4hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivEncryptAES192((uint64_t)u8hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#endif
		SBFreePointerZValInfo(&piinbuf);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivEncryptAES256)
{
	sb_zend_long l4size;
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo piinbuf;
	zval *zpinbuf;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u4hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u8hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpinbuf, &piinbuf TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivEncryptAES256((uint32_t)u4hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivEncryptAES256((uint64_t)u8hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#endif
		SBFreePointerZValInfo(&piinbuf);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivEncrypt3DES)
{
	sb_zend_long l4size;
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo piinbuf;
	zval *zpinbuf;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u4hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u8hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpinbuf, &piinbuf TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivEncrypt3DES((uint32_t)u4hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivEncrypt3DES((uint64_t)u8hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#endif
		SBFreePointerZValInfo(&piinbuf);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivDecryptAES128)
{
	sb_zend_long l4size;
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo piinbuf;
	zval *zpinbuf;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u4hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u8hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpinbuf, &piinbuf TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivDecryptAES128((uint32_t)u4hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivDecryptAES128((uint64_t)u8hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#endif
		SBFreePointerZValInfo(&piinbuf);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivDecryptAES192)
{
	sb_zend_long l4size;
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo piinbuf;
	zval *zpinbuf;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u4hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u8hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpinbuf, &piinbuf TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivDecryptAES192((uint32_t)u4hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivDecryptAES192((uint64_t)u8hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#endif
		SBFreePointerZValInfo(&piinbuf);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivDecryptAES256)
{
	sb_zend_long l4size;
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo piinbuf;
	zval *zpinbuf;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u4hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u8hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpinbuf, &piinbuf TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivDecryptAES256((uint32_t)u4hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivDecryptAES256((uint64_t)u8hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#endif
		SBFreePointerZValInfo(&piinbuf);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivDecrypt3DES)
{
	sb_zend_long l4size;
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo piinbuf;
	zval *zpinbuf;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u4hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u8hCard, &zpinbuf, &l4size) == SUCCESS) && ((Z_TYPE_P(zpinbuf) == IS_STRING) || (Z_TYPE_P(zpinbuf) == IS_ARRAY) || (Z_TYPE_P(zpinbuf) == IS_NULL) || ((Z_TYPE_P(zpinbuf) == IS_OBJECT) && (Z_OBJCE_P(zpinbuf) == TSBPointer_ce_ptr))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpinbuf, &piinbuf TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivDecrypt3DES((uint32_t)u4hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivDecrypt3DES((uint64_t)u8hCard, piinbuf.data, (int32_t)l4size, &u4OutResultRaw) TSRMLS_CC);
#endif
		SBFreePointerZValInfo(&piinbuf);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivGetAuthX509Cert)
{
#ifndef CPU64
	sb_zend_long u4hCard;
#endif
	sb_zend_long u4hKey;
#ifndef CPU64
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &u4hCard, &u4hKey) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &u8hCard, &u4hKey) == SUCCESS)
#endif
	{
		TElClassHandle hoOutResult = NULL;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivGetAuthX509Cert((uint32_t)u4hCard, (uint32_t)u4hKey, &hoOutResult) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivGetAuthX509Cert((uint64_t)u8hCard, (uint32_t)u4hKey, &hoOutResult) TSRMLS_CC);
#endif
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, SCCardGetCardHandle)
{
	char *sReader;
	sb_str_size sReader_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sReader, &sReader_len) == SUCCESS)
	{
#ifndef CPU64
		uint32_t u4OutResultRaw = 0;
		SBCheckError(SBPIVKey_SCCardGetCardHandle(sReader, (int32_t)sReader_len, &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
#else
		uint64_t u8OutResultRaw = 0;
		SBCheckError(SBPIVKey_SCCardGetCardHandle(sReader, (int32_t)sReader_len, &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
#endif
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivTestKeyByHandle)
{
#ifndef CPU64
	sb_zend_long u4hCard;
#endif
	sb_zend_long u4hKey;
#ifndef CPU64
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &u4hCard, &u4hKey) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &u8hCard, &u4hKey) == SUCCESS)
#endif
	{
		int8_t bOutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivTestKeyByHandle((uint32_t)u4hCard, (uint32_t)u4hKey, &bOutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivTestKeyByHandle((uint64_t)u8hCard, (uint32_t)u4hKey, &bOutResultRaw) TSRMLS_CC);
#endif
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivIsVerifyNeeded)
{
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	uint8_t u1VerifyCounterLeftRaw;
	zval *zu1VerifyCounterLeft;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u4hCard, &zu1VerifyCounterLeft) == SUCCESS) && Z_ISREF_P(zu1VerifyCounterLeft) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu1VerifyCounterLeft))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u8hCard, &zu1VerifyCounterLeft) == SUCCESS) && Z_ISREF_P(zu1VerifyCounterLeft) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu1VerifyCounterLeft))))
#endif
	{
		int8_t bOutResultRaw = 0;
		u1VerifyCounterLeftRaw = (uint8_t)Z_LVAL_P(Z_REFVAL_P(zu1VerifyCounterLeft));
#ifndef CPU64
		SBCheckError(SBPIVKey_PivIsVerifyNeeded((uint32_t)u4hCard, &u1VerifyCounterLeftRaw, &bOutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivIsVerifyNeeded((uint64_t)u8hCard, &u1VerifyCounterLeftRaw, &bOutResultRaw) TSRMLS_CC);
#endif
		ZVAL_LONG(Z_REFVAL_P(zu1VerifyCounterLeft), (sb_zend_long)u1VerifyCounterLeftRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, GetPIVKeyErrorNameByCode)
{
	sb_zend_long u4Code;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Code) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBPIVKey_GetPIVKeyErrorNameByCode((uint32_t)u4Code, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1324457668, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivGetStatus)
{
#ifndef CPU64
	sb_zend_long u4hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4hCard) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8hCard) == SUCCESS)
#endif
	{
		uint32_t u4OutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivGetStatus((uint32_t)u4hCard, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivGetStatus((uint64_t)u8hCard, &u4OutResultRaw) TSRMLS_CC);
#endif
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivGetCardCapabilityContainer)
{
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u4hCard, &zaData) == SUCCESS) && Z_ISREF_P(zaData) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaData))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaData)))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u8hCard, &zaData) == SUCCESS) && Z_ISREF_P(zaData) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaData))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaData)))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		_err = SBPIVKey_PivGetCardCapabilityContainer((uint32_t)u4hCard, aiData.data, &aiData.len, &u4OutResultRaw);
#else
		_err = SBPIVKey_PivGetCardCapabilityContainer((uint64_t)u8hCard, aiData.data, &aiData.len, &u4OutResultRaw);
#endif
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaData, &aiData TSRMLS_CC);
#ifndef CPU64
			SBCheckError(SBGetLastReturnBuffer(1140221995, 1, aiData.data, &aiData.len) TSRMLS_CC);
#else
			SBCheckError(SBGetLastReturnBuffer(-317883626, 1, aiData.data, &aiData.len) TSRMLS_CC);
#endif
			((char *)aiData.data)[aiData.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiData);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiData, zaData);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivSelectCardManager)
{
#ifndef CPU64
	sb_zend_long u4hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4hCard) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8hCard) == SUCCESS)
#endif
	{
		uint32_t u4OutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivSelectCardManager((uint32_t)u4hCard, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivSelectCardManager((uint64_t)u8hCard, &u4OutResultRaw) TSRMLS_CC);
#endif
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivSelectGlobalPlatformPackage)
{
#ifndef CPU64
	sb_zend_long u4hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4hCard) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8hCard) == SUCCESS)
#endif
	{
		uint32_t u4OutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivSelectGlobalPlatformPackage((uint32_t)u4hCard, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivSelectGlobalPlatformPackage((uint64_t)u8hCard, &u4OutResultRaw) TSRMLS_CC);
#endif
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivMutualAuth)
{
	sb_zend_long u1Key;
#ifndef CPU64
	sb_zend_long u4hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &u4hCard, &u1Key) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &u8hCard, &u1Key) == SUCCESS)
#endif
	{
		uint32_t u4OutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivMutualAuth((uint32_t)u4hCard, (uint8_t)u1Key, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivMutualAuth((uint64_t)u8hCard, (uint8_t)u1Key, &u4OutResultRaw) TSRMLS_CC);
#endif
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivUnblockApplicationPin)
{
	char *snewPin;
	char *sPUK;
	sb_str_size snewPin_len;
	sb_str_size sPUK_len;
#ifndef CPU64
	sb_zend_long u4hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lss", &u4hCard, &sPUK, &sPUK_len, &snewPin, &snewPin_len) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lss", &u8hCard, &sPUK, &sPUK_len, &snewPin, &snewPin_len) == SUCCESS)
#endif
	{
		uint32_t u4OutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivUnblockApplicationPin((uint32_t)u4hCard, sPUK, (int32_t)sPUK_len, snewPin, (int32_t)snewPin_len, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivUnblockApplicationPin((uint64_t)u8hCard, sPUK, (int32_t)sPUK_len, snewPin, (int32_t)snewPin_len, &u4OutResultRaw) TSRMLS_CC);
#endif
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivGenerateECDSA256KeyPair)
{
#ifndef CPU64
	sb_zend_long u4hCard;
#endif
	sb_zend_long u4hKey;
#ifdef CPU64
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo aipublickey;
	uint32_t _err;
	zval *zapublickey;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llz", &u4hCard, &u4hKey, &zapublickey) == SUCCESS) && Z_ISREF_P(zapublickey) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zapublickey))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zapublickey)))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llz", &u8hCard, &u4hKey, &zapublickey) == SUCCESS) && Z_ISREF_P(zapublickey) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zapublickey))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zapublickey)))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zapublickey, &aipublickey TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		_err = SBPIVKey_PivGenerateECDSA256KeyPair((uint32_t)u4hCard, (uint32_t)u4hKey, aipublickey.data, &aipublickey.len, &u4OutResultRaw);
#else
		_err = SBPIVKey_PivGenerateECDSA256KeyPair((uint64_t)u8hCard, (uint32_t)u4hKey, aipublickey.data, &aipublickey.len, &u4OutResultRaw);
#endif
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zapublickey, &aipublickey TSRMLS_CC);
#ifndef CPU64
			SBCheckError(SBGetLastReturnBuffer(2060531913, 2, aipublickey.data, &aipublickey.len) TSRMLS_CC);
#else
			SBCheckError(SBGetLastReturnBuffer(-1836146014, 2, aipublickey.data, &aipublickey.len) TSRMLS_CC);
#endif
			((char *)aipublickey.data)[aipublickey.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aipublickey);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aipublickey, zapublickey);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivGenerateECDSA384KeyPair)
{
#ifndef CPU64
	sb_zend_long u4hCard;
#endif
	sb_zend_long u4hKey;
#ifdef CPU64
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo aipublickey;
	uint32_t _err;
	zval *zapublickey;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llz", &u4hCard, &u4hKey, &zapublickey) == SUCCESS) && Z_ISREF_P(zapublickey) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zapublickey))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zapublickey)))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llz", &u8hCard, &u4hKey, &zapublickey) == SUCCESS) && Z_ISREF_P(zapublickey) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zapublickey))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zapublickey)))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zapublickey, &aipublickey TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		_err = SBPIVKey_PivGenerateECDSA384KeyPair((uint32_t)u4hCard, (uint32_t)u4hKey, aipublickey.data, &aipublickey.len, &u4OutResultRaw);
#else
		_err = SBPIVKey_PivGenerateECDSA384KeyPair((uint64_t)u8hCard, (uint32_t)u4hKey, aipublickey.data, &aipublickey.len, &u4OutResultRaw);
#endif
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zapublickey, &aipublickey TSRMLS_CC);
#ifndef CPU64
			SBCheckError(SBGetLastReturnBuffer(-1664792847, 2, aipublickey.data, &aipublickey.len) TSRMLS_CC);
#else
			SBCheckError(SBGetLastReturnBuffer(-192609520, 2, aipublickey.data, &aipublickey.len) TSRMLS_CC);
#endif
			((char *)aipublickey.data)[aipublickey.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aipublickey);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aipublickey, zapublickey);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivGenerateRSAKeyPair)
{
#ifndef CPU64
	sb_zend_long u4hCard;
#endif
	sb_zend_long u4hKey;
#ifdef CPU64
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo aiexponent;
	SBArrayZValInfo aimodulus;
	uint32_t _err;
	zval *zaexponent;
	zval *zamodulus;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llzz", &u4hCard, &u4hKey, &zamodulus, &zaexponent) == SUCCESS) && Z_ISREF_P(zamodulus) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zamodulus))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zamodulus)))) && Z_ISREF_P(zaexponent) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaexponent))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaexponent)))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llzz", &u8hCard, &u4hKey, &zamodulus, &zaexponent) == SUCCESS) && Z_ISREF_P(zamodulus) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zamodulus))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zamodulus)))) && Z_ISREF_P(zaexponent) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaexponent))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaexponent)))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zamodulus, &aimodulus TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaexponent, &aiexponent TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		_err = SBPIVKey_PivGenerateRSAKeyPair((uint32_t)u4hCard, (uint32_t)u4hKey, aimodulus.data, &aimodulus.len, aiexponent.data, &aiexponent.len, &u4OutResultRaw);
#else
		_err = SBPIVKey_PivGenerateRSAKeyPair((uint64_t)u8hCard, (uint32_t)u4hKey, aimodulus.data, &aimodulus.len, aiexponent.data, &aiexponent.len, &u4OutResultRaw);
#endif
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zamodulus, &aimodulus TSRMLS_CC);
#ifndef CPU64
			SBCheckError(SBGetLastReturnBuffer(2099801209, 2, aimodulus.data, &aimodulus.len) TSRMLS_CC);
#else
			SBCheckError(SBGetLastReturnBuffer(1219459326, 2, aimodulus.data, &aimodulus.len) TSRMLS_CC);
#endif
			((char *)aimodulus.data)[aimodulus.len] = 0;
			SBDetachDataFromZValAndResize(zaexponent, &aiexponent TSRMLS_CC);
#ifndef CPU64
			SBCheckError(SBGetLastReturnBuffer(2099801209, 3, aiexponent.data, &aiexponent.len) TSRMLS_CC);
#else
			SBCheckError(SBGetLastReturnBuffer(1219459326, 3, aiexponent.data, &aiexponent.len) TSRMLS_CC);
#endif
			((char *)aiexponent.data)[aiexponent.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aimodulus);
			SBFreeArrayZValInfo(&aiexponent);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aimodulus, zamodulus);
		SBSetByteArrayToZVal(&aiexponent, zaexponent);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, &array of byte|string, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivApplicationAdminAuth)
{
#ifndef CPU64
	sb_zend_long u4hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4hCard) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8hCard) == SUCCESS)
#endif
	{
		uint32_t u4OutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivApplicationAdminAuth((uint32_t)u4hCard, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivApplicationAdminAuth((uint64_t)u8hCard, &u4OutResultRaw) TSRMLS_CC);
#endif
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, SCEstablishContext)
{
#ifndef CPU64
	uint32_t u4CtxRaw;
	zval *zu4Ctx;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zu4Ctx) == SUCCESS) && Z_ISREF_P(zu4Ctx) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4Ctx))))
#else
	uint64_t u8CtxRaw;
	zval *zu8Ctx;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zu8Ctx) == SUCCESS) && Z_ISREF_P(zu8Ctx) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu8Ctx))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
#ifndef CPU64
		u4CtxRaw = (uint32_t)Z_LVAL_P(Z_REFVAL_P(zu4Ctx));
		SBCheckError(SBPIVKey_SCEstablishContext(&u4CtxRaw, &u4OutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zu4Ctx), (sb_zend_long)u4CtxRaw);
#else
		u8CtxRaw = (uint64_t)Z_LVAL_P(Z_REFVAL_P(zu8Ctx));
		SBCheckError(SBPIVKey_SCEstablishContext(&u8CtxRaw, &u4OutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zu8Ctx), (sb_zend_long)u8CtxRaw);
#endif
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(&integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, SCReleaseContext)
{
#ifndef CPU64
	sb_zend_long u4Ctx;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Ctx) == SUCCESS)
#else
	sb_zend_long u8Ctx;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Ctx) == SUCCESS)
#endif
	{
#ifndef CPU64
		SBCheckError(SBPIVKey_SCReleaseContext((uint32_t)u4Ctx) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_SCReleaseContext((uint64_t)u8Ctx) TSRMLS_CC);
#endif
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, SCListReaders)
{
#ifndef CPU64
	sb_zend_long u4Ctx;
#else
	sb_zend_long u8Ctx;
#endif
	TElClassHandle hoReaderList;
	zval *oReaderList;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO", &u4Ctx, &oReaderList, TStringList_ce_ptr) == SUCCESS) && SB_ISREF_OBJECT_P(oReaderList))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO", &u8Ctx, &oReaderList, TStringList_ce_ptr) == SUCCESS) && SB_ISREF_OBJECT_P(oReaderList))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		hoReaderList = SBGetObjectHandle(oReaderList TSRMLS_CC);
#ifndef CPU64
		SBCheckError(SBPIVKey_SCListReaders((uint32_t)u4Ctx, &hoReaderList, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_SCListReaders((uint64_t)u8Ctx, &hoReaderList, &u4OutResultRaw) TSRMLS_CC);
#endif
		SBUpdateObjectHandle(oReaderList, hoReaderList TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, &TStringList)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, SCGetReaderStatus)
{
	char *sReader;
	sb_str_size sReader_len;
#ifndef CPU64
	sb_zend_long u4Ctx;
#else
	sb_zend_long u8Ctx;
#endif
	zval *oReaderState;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lsO", &u4Ctx, &sReader, &sReader_len, &oReaderState, SCARD_READERSTATE_ce_ptr) == SUCCESS) && SB_ISREF_STRUCT_P(oReaderState))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lsO", &u8Ctx, &sReader, &sReader_len, &oReaderState, SCARD_READERSTATE_ce_ptr) == SUCCESS) && SB_ISREF_STRUCT_P(oReaderState))
#endif
	{
		uint32_t u4OutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_SCGetReaderStatus((uint32_t)u4Ctx, sReader, (int32_t)sReader_len, (SCARD_READERSTATE *)SBGetStructPointer(oReaderState TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_SCGetReaderStatus((uint64_t)u8Ctx, sReader, (int32_t)sReader_len, (SCARD_READERSTATE *)SBGetStructPointer(oReaderState TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
#endif
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, string, &SCARD_READERSTATE)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, SCIsCardInserted)
{
	zval *oReader;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oReader, SCARD_READERSTATE_ce_ptr) == SUCCESS) && SB_ISREF_STRUCT_P(oReader))
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBPIVKey_SCIsCardInserted((SCARD_READERSTATE *)SBGetStructPointer(oReader TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(&SCARD_READERSTATE)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, SCCardConnect)
{
#ifndef CPU64
	sb_zend_long u4Ctx;
	uint32_t u4hCardHandleRaw;
#else
	sb_zend_long u8Ctx;
	uint64_t u8hCardHandleRaw;
#endif
	zval *oReader;
#ifndef CPU64
	zval *zu4hCardHandle;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lOz", &u4Ctx, &oReader, SCARD_READERSTATE_ce_ptr, &zu4hCardHandle) == SUCCESS) && SB_ISREF_STRUCT_P(oReader) && Z_ISREF_P(zu4hCardHandle) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu4hCardHandle))))
#else
	zval *zu8hCardHandle;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lOz", &u8Ctx, &oReader, SCARD_READERSTATE_ce_ptr, &zu8hCardHandle) == SUCCESS) && SB_ISREF_STRUCT_P(oReader) && Z_ISREF_P(zu8hCardHandle) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu8hCardHandle))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
#ifndef CPU64
		u4hCardHandleRaw = (uint32_t)Z_LVAL_P(Z_REFVAL_P(zu4hCardHandle));
		SBCheckError(SBPIVKey_SCCardConnect((uint32_t)u4Ctx, (SCARD_READERSTATE *)SBGetStructPointer(oReader TSRMLS_CC), &u4hCardHandleRaw, &u4OutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zu4hCardHandle), (sb_zend_long)u4hCardHandleRaw);
#else
		u8hCardHandleRaw = (uint64_t)Z_LVAL_P(Z_REFVAL_P(zu8hCardHandle));
		SBCheckError(SBPIVKey_SCCardConnect((uint64_t)u8Ctx, (SCARD_READERSTATE *)SBGetStructPointer(oReader TSRMLS_CC), &u8hCardHandleRaw, &u4OutResultRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zu8hCardHandle), (sb_zend_long)u8hCardHandleRaw);
#endif
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, &SCARD_READERSTATE, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, SCCardReconnect)
{
#ifndef CPU64
	sb_zend_long u4hCardHandle;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4hCardHandle) == SUCCESS)
#else
	sb_zend_long u8hCardHandle;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8hCardHandle) == SUCCESS)
#endif
	{
		uint32_t u4OutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_SCCardReconnect((uint32_t)u4hCardHandle, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_SCCardReconnect((uint64_t)u8hCardHandle, &u4OutResultRaw) TSRMLS_CC);
#endif
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, SCCardDisconnect)
{
#ifndef CPU64
	sb_zend_long u4hCardHandle;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4hCardHandle) == SUCCESS)
#else
	sb_zend_long u8hCardHandle;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8hCardHandle) == SUCCESS)
#endif
	{
		uint32_t u4OutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_SCCardDisconnect((uint32_t)u4hCardHandle, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_SCCardDisconnect((uint64_t)u8hCardHandle, &u4OutResultRaw) TSRMLS_CC);
#endif
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, SCGetIFDSerialNumber)
{
#ifndef CPU64
	sb_zend_long u4Ctx;
	sb_zend_long u4hCard;
#else
	sb_zend_long u8Ctx;
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo aiSerialNo;
	uint32_t _err;
	zval *zaSerialNo;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llz", &u4Ctx, &u4hCard, &zaSerialNo) == SUCCESS) && Z_ISREF_P(zaSerialNo) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaSerialNo))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaSerialNo)))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llz", &u8Ctx, &u8hCard, &zaSerialNo) == SUCCESS) && Z_ISREF_P(zaSerialNo) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaSerialNo))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaSerialNo)))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaSerialNo, &aiSerialNo TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		_err = SBPIVKey_SCGetIFDSerialNumber((uint32_t)u4Ctx, (uint32_t)u4hCard, aiSerialNo.data, &aiSerialNo.len, &u4OutResultRaw);
#else
		_err = SBPIVKey_SCGetIFDSerialNumber((uint64_t)u8Ctx, (uint64_t)u8hCard, aiSerialNo.data, &aiSerialNo.len, &u4OutResultRaw);
#endif
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaSerialNo, &aiSerialNo TSRMLS_CC);
#ifndef CPU64
			SBCheckError(SBGetLastReturnBuffer(1091394885, 2, aiSerialNo.data, &aiSerialNo.len) TSRMLS_CC);
#else
			SBCheckError(SBGetLastReturnBuffer(1349038773, 2, aiSerialNo.data, &aiSerialNo.len) TSRMLS_CC);
#endif
			((char *)aiSerialNo.data)[aiSerialNo.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiSerialNo);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiSerialNo, zaSerialNo);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, SCSuccess)
{
	sb_zend_long u4status;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4status) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBPIVKey_SCSuccess((uint32_t)u4status, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivVerifyGlobal)
{
	char *sPinCode;
	sb_str_size sPinCode_len;
#ifndef CPU64
	sb_zend_long u4hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ls", &u4hCard, &sPinCode, &sPinCode_len) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ls", &u8hCard, &sPinCode, &sPinCode_len) == SUCCESS)
#endif
	{
		uint32_t u4OutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivVerifyGlobal((uint32_t)u4hCard, sPinCode, (int32_t)sPinCode_len, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivVerifyGlobal((uint64_t)u8hCard, sPinCode, (int32_t)sPinCode_len, &u4OutResultRaw) TSRMLS_CC);
#endif
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivVerifyCardApp)
{
	char *sPinCode;
	sb_str_size sPinCode_len;
#ifndef CPU64
	sb_zend_long u4hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ls", &u4hCard, &sPinCode, &sPinCode_len) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ls", &u8hCard, &sPinCode, &sPinCode_len) == SUCCESS)
#endif
	{
		uint32_t u4OutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivVerifyCardApp((uint32_t)u4hCard, sPinCode, (int32_t)sPinCode_len, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivVerifyCardApp((uint64_t)u8hCard, sPinCode, (int32_t)sPinCode_len, &u4OutResultRaw) TSRMLS_CC);
#endif
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivSelectDefaultApplication)
{
#ifndef CPU64
	sb_zend_long u4hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4hCard) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8hCard) == SUCCESS)
#endif
	{
		int32_t l4OutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivSelectDefaultApplication((uint32_t)u4hCard, &l4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivSelectDefaultApplication((uint64_t)u8hCard, &l4OutResultRaw) TSRMLS_CC);
#endif
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivGetSMkey)
{
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo aioutbuf;
	uint32_t _err;
	zval *zaoutbuf;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u4hCard, &zaoutbuf) == SUCCESS) && Z_ISREF_P(zaoutbuf) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaoutbuf))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaoutbuf)))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u8hCard, &zaoutbuf) == SUCCESS) && Z_ISREF_P(zaoutbuf) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaoutbuf))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaoutbuf)))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaoutbuf, &aioutbuf TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		_err = SBPIVKey_PivGetSMkey((uint32_t)u4hCard, aioutbuf.data, &aioutbuf.len, &u4OutResultRaw);
#else
		_err = SBPIVKey_PivGetSMkey((uint64_t)u8hCard, aioutbuf.data, &aioutbuf.len, &u4OutResultRaw);
#endif
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaoutbuf, &aioutbuf TSRMLS_CC);
#ifndef CPU64
			SBCheckError(SBGetLastReturnBuffer(-2107461060, 1, aioutbuf.data, &aioutbuf.len) TSRMLS_CC);
#else
			SBCheckError(SBGetLastReturnBuffer(1110813732, 1, aioutbuf.data, &aioutbuf.len) TSRMLS_CC);
#endif
			((char *)aioutbuf.data)[aioutbuf.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aioutbuf);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aioutbuf, zaoutbuf);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivGetPairingCodeRefData)
{
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo aioutbuf;
	uint32_t _err;
	zval *zaoutbuf;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u4hCard, &zaoutbuf) == SUCCESS) && Z_ISREF_P(zaoutbuf) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaoutbuf))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaoutbuf)))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u8hCard, &zaoutbuf) == SUCCESS) && Z_ISREF_P(zaoutbuf) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaoutbuf))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaoutbuf)))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaoutbuf, &aioutbuf TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		_err = SBPIVKey_PivGetPairingCodeRefData((uint32_t)u4hCard, aioutbuf.data, &aioutbuf.len, &u4OutResultRaw);
#else
		_err = SBPIVKey_PivGetPairingCodeRefData((uint64_t)u8hCard, aioutbuf.data, &aioutbuf.len, &u4OutResultRaw);
#endif
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaoutbuf, &aioutbuf TSRMLS_CC);
#ifndef CPU64
			SBCheckError(SBGetLastReturnBuffer(-265406591, 1, aioutbuf.data, &aioutbuf.len) TSRMLS_CC);
#else
			SBCheckError(SBGetLastReturnBuffer(-840398741, 1, aioutbuf.data, &aioutbuf.len) TSRMLS_CC);
#endif
			((char *)aioutbuf.data)[aioutbuf.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aioutbuf);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aioutbuf, zaoutbuf);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivGetDiscoveryObject)
{
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo aioutbuf;
	uint32_t _err;
	zval *zaoutbuf;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u4hCard, &zaoutbuf) == SUCCESS) && Z_ISREF_P(zaoutbuf) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaoutbuf))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaoutbuf)))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u8hCard, &zaoutbuf) == SUCCESS) && Z_ISREF_P(zaoutbuf) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaoutbuf))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaoutbuf)))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaoutbuf, &aioutbuf TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		_err = SBPIVKey_PivGetDiscoveryObject((uint32_t)u4hCard, aioutbuf.data, &aioutbuf.len, &u4OutResultRaw);
#else
		_err = SBPIVKey_PivGetDiscoveryObject((uint64_t)u8hCard, aioutbuf.data, &aioutbuf.len, &u4OutResultRaw);
#endif
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaoutbuf, &aioutbuf TSRMLS_CC);
#ifndef CPU64
			SBCheckError(SBGetLastReturnBuffer(1713479906, 1, aioutbuf.data, &aioutbuf.len) TSRMLS_CC);
#else
			SBCheckError(SBGetLastReturnBuffer(1184247282, 1, aioutbuf.data, &aioutbuf.len) TSRMLS_CC);
#endif
			((char *)aioutbuf.data)[aioutbuf.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aioutbuf);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aioutbuf, zaoutbuf);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivGetCHUID)
{
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo aiGuid;
	uint32_t _err;
	zval *zaGuid;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u4hCard, &zaGuid) == SUCCESS) && Z_ISREF_P(zaGuid) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaGuid))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaGuid)))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u8hCard, &zaGuid) == SUCCESS) && Z_ISREF_P(zaGuid) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaGuid))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaGuid)))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaGuid, &aiGuid TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		_err = SBPIVKey_PivGetCHUID((uint32_t)u4hCard, aiGuid.data, &aiGuid.len, &u4OutResultRaw);
#else
		_err = SBPIVKey_PivGetCHUID((uint64_t)u8hCard, aiGuid.data, &aiGuid.len, &u4OutResultRaw);
#endif
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaGuid, &aiGuid TSRMLS_CC);
#ifndef CPU64
			SBCheckError(SBGetLastReturnBuffer(-2116809171, 1, aiGuid.data, &aiGuid.len) TSRMLS_CC);
#else
			SBCheckError(SBGetLastReturnBuffer(-2125553060, 1, aiGuid.data, &aiGuid.len) TSRMLS_CC);
#endif
			((char *)aiGuid.data)[aiGuid.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiGuid);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiGuid, zaGuid);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivTestAuthCert9A)
{
#ifndef CPU64
	sb_zend_long u4hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4hCard) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8hCard) == SUCCESS)
#endif
	{
		int8_t bOutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivTestAuthCert9A((uint32_t)u4hCard, &bOutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivTestAuthCert9A((uint64_t)u8hCard, &bOutResultRaw) TSRMLS_CC);
#endif
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivTestAuthCert9C)
{
#ifndef CPU64
	sb_zend_long u4hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4hCard) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8hCard) == SUCCESS)
#endif
	{
		int8_t bOutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivTestAuthCert9C((uint32_t)u4hCard, &bOutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivTestAuthCert9C((uint64_t)u8hCard, &bOutResultRaw) TSRMLS_CC);
#endif
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivTestAuthCert9D)
{
#ifndef CPU64
	sb_zend_long u4hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4hCard) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8hCard) == SUCCESS)
#endif
	{
		int8_t bOutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivTestAuthCert9D((uint32_t)u4hCard, &bOutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivTestAuthCert9D((uint64_t)u8hCard, &bOutResultRaw) TSRMLS_CC);
#endif
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivTestAuthCert9E)
{
#ifndef CPU64
	sb_zend_long u4hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4hCard) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8hCard) == SUCCESS)
#endif
	{
		int8_t bOutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivTestAuthCert9E((uint32_t)u4hCard, &bOutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivTestAuthCert9E((uint64_t)u8hCard, &bOutResultRaw) TSRMLS_CC);
#endif
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivCardHolderAuthVCI)
{
#ifndef CPU64
	sb_zend_long u4hCard;
#else
	sb_zend_long u8hCard;
#endif
	SBArrayZValInfo aiinbuf;
	SBArrayZValInfo aioutbuf;
	uint32_t _err;
	zval *zainbuf;
	zval *zaoutbuf;
#ifndef CPU64
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzz", &u4hCard, &zainbuf, &zaoutbuf) == SUCCESS) && Z_ISREF_P(zainbuf) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zainbuf))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zainbuf)))) && Z_ISREF_P(zaoutbuf) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaoutbuf))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaoutbuf)))))
#else
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzz", &u8hCard, &zainbuf, &zaoutbuf) == SUCCESS) && Z_ISREF_P(zainbuf) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zainbuf))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zainbuf)))) && Z_ISREF_P(zaoutbuf) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaoutbuf))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaoutbuf)))))
#endif
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zainbuf, &aiinbuf TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaoutbuf, &aioutbuf TSRMLS_CC)) RETURN_FALSE;
#ifndef CPU64
		_err = SBPIVKey_PivCardHolderAuthVCI((uint32_t)u4hCard, aiinbuf.data, &aiinbuf.len, aioutbuf.data, &aioutbuf.len, &u4OutResultRaw);
#else
		_err = SBPIVKey_PivCardHolderAuthVCI((uint64_t)u8hCard, aiinbuf.data, &aiinbuf.len, aioutbuf.data, &aioutbuf.len, &u4OutResultRaw);
#endif
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zainbuf, &aiinbuf TSRMLS_CC);
#ifndef CPU64
			SBCheckError(SBGetLastReturnBuffer(-2129605879, 1, aiinbuf.data, &aiinbuf.len) TSRMLS_CC);
#else
			SBCheckError(SBGetLastReturnBuffer(-1475658084, 1, aiinbuf.data, &aiinbuf.len) TSRMLS_CC);
#endif
			((char *)aiinbuf.data)[aiinbuf.len] = 0;
			SBDetachDataFromZValAndResize(zaoutbuf, &aioutbuf TSRMLS_CC);
#ifndef CPU64
			SBCheckError(SBGetLastReturnBuffer(-2129605879, 2, aioutbuf.data, &aioutbuf.len) TSRMLS_CC);
#else
			SBCheckError(SBGetLastReturnBuffer(-1475658084, 2, aioutbuf.data, &aioutbuf.len) TSRMLS_CC);
#endif
			((char *)aioutbuf.data)[aioutbuf.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiinbuf);
			SBFreeArrayZValInfo(&aioutbuf);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiinbuf, zainbuf);
		SBSetByteArrayToZVal(&aioutbuf, zaoutbuf);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, &array of byte|string, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPIVKey, PivPutPairingCodeRefData)
{
#ifndef CPU64
	sb_zend_long u4hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4hCard) == SUCCESS)
#else
	sb_zend_long u8hCard;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8hCard) == SUCCESS)
#endif
	{
		uint32_t u4OutResultRaw = 0;
#ifndef CPU64
		SBCheckError(SBPIVKey_PivPutPairingCodeRefData((uint32_t)u4hCard, &u4OutResultRaw) TSRMLS_CC);
#else
		SBCheckError(SBPIVKey_PivPutPairingCodeRefData((uint64_t)u8hCard, &u4OutResultRaw) TSRMLS_CC);
#endif
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

void Register_SBPIVKey_Aliases(TSRMLS_D)
{
	if (NULL == SCARD_READERSTATE_ce_ptr)
		Register_SCARD_READERSTATE(TSRMLS_C);
	zend_register_class_alias("TElReaderState", SCARD_READERSTATE_ce_ptr);
}
#endif
