#include "sbpkcs7utils.h"

zend_class_entry *TSBPKCS7IssuerType_ce_ptr = NULL;

zend_class_entry *TElPKCS7Attributes_ce_ptr = NULL;

SB_PHP_METHOD(TElPKCS7Attributes, Remove)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElPKCS7Attributes_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, Copy)
{
	zval *oDest;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDest, TElPKCS7Attributes_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPKCS7Attributes_Copy(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDest TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPKCS7Attributes)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, SaveToBuffer)
{
	int32_t l4SizeRaw;
	SBArrayZValInfo piBuffer;
	zval *zl4Size;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zpBuffer, &zl4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		SBCheckError(TElPKCS7Attributes_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, &l4SizeRaw, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, LoadFromBuffer)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPKCS7Attributes_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, FindAttribute)
{
	SBArrayZValInfo aiName;
	zval *zaName;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaName) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaName) || SB_IS_ARRAY_TYPE_RP(zaName) || SB_IS_NULL_TYPE_RP(zaName)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaName, &aiName TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPKCS7Attributes_FindAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), aiName.data, aiName.len, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiName);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, SortLexicographically)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPKCS7Attributes_SortLexicographically(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, RecalculateRawAttributeSequences)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPKCS7Attributes_RecalculateRawAttributeSequences(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPKCS7Attributes_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, get_Attributes)
{
	sb_zend_long l4Index;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPKCS7Attributes_get_Attributes(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1395840250, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, set_Attributes)
{
	sb_zend_long l4Index;
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &l4Index, &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPKCS7Attributes_set_Attributes(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(integer, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, get_Values)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPKCS7Attributes_get_Values(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElByteArrayList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, get_RawAttributeSequences)
{
	sb_zend_long l4Index;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPKCS7Attributes_get_RawAttributeSequences(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(70360388, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, set_RawAttributeSequences)
{
	sb_zend_long l4Index;
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &l4Index, &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPKCS7Attributes_set_RawAttributeSequences(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(integer, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElPKCS7Attributes_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, set_Count)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElPKCS7Attributes_set_Count(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Attributes, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPKCS7Attributes_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_Copy, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Dest, TElPKCS7Attributes, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_SaveToBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_LoadFromBuffer, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_FindAttribute, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Name, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_SortLexicographically, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_RecalculateRawAttributeSequences, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_get_Attributes, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_set_Attributes, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_get_Values, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_get_RawAttributeSequences, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_set_RawAttributeSequences, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes_set_Count, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Attributes___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPKCS7Attributes_methods[] = {
	PHP_ME(TElPKCS7Attributes, Remove, arginfo_TElPKCS7Attributes_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, Copy, arginfo_TElPKCS7Attributes_Copy, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, SaveToBuffer, arginfo_TElPKCS7Attributes_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, LoadFromBuffer, arginfo_TElPKCS7Attributes_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, FindAttribute, arginfo_TElPKCS7Attributes_FindAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, SortLexicographically, arginfo_TElPKCS7Attributes_SortLexicographically, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, RecalculateRawAttributeSequences, arginfo_TElPKCS7Attributes_RecalculateRawAttributeSequences, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, Clear, arginfo_TElPKCS7Attributes_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, get_Attributes, arginfo_TElPKCS7Attributes_get_Attributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, set_Attributes, arginfo_TElPKCS7Attributes_set_Attributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, get_Values, arginfo_TElPKCS7Attributes_get_Values, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, get_RawAttributeSequences, arginfo_TElPKCS7Attributes_get_RawAttributeSequences, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, set_RawAttributeSequences, arginfo_TElPKCS7Attributes_set_RawAttributeSequences, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, get_Count, arginfo_TElPKCS7Attributes_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, set_Count, arginfo_TElPKCS7Attributes_set_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Attributes, __construct, arginfo_TElPKCS7Attributes___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPKCS7Attributes(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPKCS7Attributes_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPKCS7Attributes", TElPKCS7Attributes_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPKCS7Attributes_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElPKCS7Issuer_ce_ptr = NULL;

SB_PHP_METHOD(TElPKCS7Issuer, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElPKCS7Issuer_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElPKCS7Issuer_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPKCS7Issuer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Issuer, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElPKCS7Issuer_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Issuer, get_Issuer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPKCS7Issuer_get_Issuer(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElRelativeDistinguishedName_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Issuer, get_SerialNumber)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPKCS7Issuer_get_SerialNumber(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1258832997, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Issuer, set_SerialNumber)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPKCS7Issuer_set_SerialNumber(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Issuer, get_SubjectKeyIdentifier)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPKCS7Issuer_get_SubjectKeyIdentifier(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1850540398, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Issuer, set_SubjectKeyIdentifier)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElPKCS7Issuer_set_SubjectKeyIdentifier(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Issuer, get_IssuerType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBPKCS7IssuerTypeRaw fOutResultRaw = 0;
		SBCheckError(TElPKCS7Issuer_get_IssuerType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Issuer, set_IssuerType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElPKCS7Issuer_set_IssuerType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBPKCS7IssuerTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPKCS7Issuer, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPKCS7Issuer_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Issuer_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElPKCS7Issuer, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Issuer_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Issuer_get_Issuer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Issuer_get_SerialNumber, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Issuer_set_SerialNumber, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Issuer_get_SubjectKeyIdentifier, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Issuer_set_SubjectKeyIdentifier, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Issuer_get_IssuerType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Issuer_set_IssuerType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPKCS7Issuer___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPKCS7Issuer_methods[] = {
	PHP_ME(TElPKCS7Issuer, Assign, arginfo_TElPKCS7Issuer_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Issuer, Reset, arginfo_TElPKCS7Issuer_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Issuer, get_Issuer, arginfo_TElPKCS7Issuer_get_Issuer, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Issuer, get_SerialNumber, arginfo_TElPKCS7Issuer_get_SerialNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Issuer, set_SerialNumber, arginfo_TElPKCS7Issuer_set_SerialNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Issuer, get_SubjectKeyIdentifier, arginfo_TElPKCS7Issuer_get_SubjectKeyIdentifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Issuer, set_SubjectKeyIdentifier, arginfo_TElPKCS7Issuer_set_SubjectKeyIdentifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Issuer, get_IssuerType, arginfo_TElPKCS7Issuer_get_IssuerType, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Issuer, set_IssuerType, arginfo_TElPKCS7Issuer_set_IssuerType, ZEND_ACC_PUBLIC)
	PHP_ME(TElPKCS7Issuer, __construct, arginfo_TElPKCS7Issuer___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPKCS7Issuer(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPKCS7Issuer_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPKCS7Issuer", TElPKCS7Issuer_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElPKCS7Issuer_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

SB_PHP_FUNCTION(SBPKCS7Utils, SaveAttributes)
{
	sb_zend_long u1TagID;
	zval *oAttributes;
	zval *oTag;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oTag, TElASN1ConstrainedTag_ce_ptr, &oAttributes, TElPKCS7Attributes_ce_ptr, &u1TagID) == SUCCESS)
	{
		SBCheckError(SBPKCS7Utils_SaveAttributes(SBGetObjectHandle(oTag TSRMLS_CC), SBGetObjectHandle(oAttributes TSRMLS_CC), (uint8_t)u1TagID) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1ConstrainedTag, \\TElPKCS7Attributes, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPKCS7Utils, ProcessAttributes)
{
	zval *oAttributes;
	zval *oTag;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oTag, TElASN1CustomTag_ce_ptr, &oAttributes, TElPKCS7Attributes_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBPKCS7Utils_ProcessAttributes(SBGetObjectHandle(oTag TSRMLS_CC), SBGetObjectHandle(oAttributes TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1CustomTag, \\TElPKCS7Attributes)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPKCS7Utils, ProcessAlgorithmIdentifier)
{
	SBArrayZValInfo aiAlgorithm;
	SBArrayZValInfo aiParams;
	uint32_t _err;
	zend_bool bImplicitTagging;
	zval *oTag;
	zval *zaAlgorithm;
	zval *zaParams;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zzb", &oTag, TElASN1CustomTag_ce_ptr, &zaAlgorithm, &zaParams, &bImplicitTagging) == SUCCESS) && Z_ISREF_P(zaAlgorithm) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaAlgorithm))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaAlgorithm)))) && Z_ISREF_P(zaParams) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaParams))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaParams)))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaAlgorithm, &aiAlgorithm TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaParams, &aiParams TSRMLS_CC)) RETURN_FALSE;
		_err = SBPKCS7Utils_ProcessAlgorithmIdentifier(SBGetObjectHandle(oTag TSRMLS_CC), aiAlgorithm.data, &aiAlgorithm.len, aiParams.data, &aiParams.len, (int8_t)bImplicitTagging, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaAlgorithm, &aiAlgorithm TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(1020150581, 1, aiAlgorithm.data, &aiAlgorithm.len) TSRMLS_CC);
			((char *)aiAlgorithm.data)[aiAlgorithm.len] = 0;
			SBDetachDataFromZValAndResize(zaParams, &aiParams TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(1020150581, 2, aiParams.data, &aiParams.len) TSRMLS_CC);
			((char *)aiParams.data)[aiParams.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiAlgorithm);
			SBFreeArrayZValInfo(&aiParams);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiAlgorithm, zaAlgorithm);
		SBSetByteArrayToZVal(&aiParams, zaParams);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1CustomTag, &array of byte|string, &array of byte|string, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPKCS7Utils, SaveAlgorithmIdentifier)
{
	sb_zend_long u1ImplicitTag;
	SBArrayZValInfo aiAlgorithm;
	SBArrayZValInfo aiParams;
	zend_bool bWriteNullIfParamsAreEmpty;
	zval *oTag;
	zval *zaAlgorithm;
	zval *zaParams;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zzlb", &oTag, TElASN1ConstrainedTag_ce_ptr, &zaAlgorithm, &zaParams, &u1ImplicitTag, &bWriteNullIfParamsAreEmpty) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAlgorithm) || SB_IS_ARRAY_TYPE_RP(zaAlgorithm) || SB_IS_NULL_TYPE_RP(zaAlgorithm)) && (SB_IS_STRING_TYPE_RP(zaParams) || SB_IS_ARRAY_TYPE_RP(zaParams) || SB_IS_NULL_TYPE_RP(zaParams)))
	{
		if (!SBGetByteArrayFromZVal(zaAlgorithm, &aiAlgorithm TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaParams, &aiParams TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBPKCS7Utils_SaveAlgorithmIdentifier(SBGetObjectHandle(oTag TSRMLS_CC), aiAlgorithm.data, aiAlgorithm.len, aiParams.data, aiParams.len, (uint8_t)u1ImplicitTag, (int8_t)bWriteNullIfParamsAreEmpty) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAlgorithm);
		SBFreeArrayZValInfo(&aiParams);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElASN1ConstrainedTag, array of byte|string|NULL, array of byte|string|NULL, integer, bool)" TSRMLS_CC);
	}
}

void Register_SBPKCS7Utils_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, ERROR_FACILITY_PKCS7, SB_ERROR_FACILITY_PKCS7, SB_ERROR_FACILITY_PKCS7);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_ASN_DATA, SB_PKCS7_ERROR_INVALID_ASN_DATA, SB_PKCS7_ERROR_INVALID_ASN_DATA);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_NO_DATA, SB_PKCS7_ERROR_NO_DATA, SB_PKCS7_ERROR_NO_DATA);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_CONTENT_INFO, SB_PKCS7_ERROR_INVALID_CONTENT_INFO, SB_PKCS7_ERROR_INVALID_CONTENT_INFO);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_UNKNOWN_DATA_TYPE, SB_PKCS7_ERROR_UNKNOWN_DATA_TYPE, SB_PKCS7_ERROR_UNKNOWN_DATA_TYPE);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_DATA, SB_PKCS7_ERROR_INVALID_DATA, SB_PKCS7_ERROR_INVALID_DATA);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_ENVELOPED_DATA, SB_PKCS7_ERROR_INVALID_ENVELOPED_DATA, SB_PKCS7_ERROR_INVALID_ENVELOPED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_ENVELOPED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_ENVELOPED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_ENVELOPED_DATA_VERSION);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_ENVELOPED_DATA_CONTENT, SB_PKCS7_ERROR_INVALID_ENVELOPED_DATA_CONTENT, SB_PKCS7_ERROR_INVALID_ENVELOPED_DATA_CONTENT);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_RECIPIENT_INFOS, SB_PKCS7_ERROR_INVALID_RECIPIENT_INFOS, SB_PKCS7_ERROR_INVALID_RECIPIENT_INFOS);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_RECIPIENT_INFO, SB_PKCS7_ERROR_INVALID_RECIPIENT_INFO, SB_PKCS7_ERROR_INVALID_RECIPIENT_INFO);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_RECIPIENT_INFO_VERSION, SB_PKCS7_ERROR_INVALID_RECIPIENT_INFO_VERSION, SB_PKCS7_ERROR_INVALID_RECIPIENT_INFO_VERSION);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_RECIPIENT_INFO_KEY, SB_PKCS7_ERROR_INVALID_RECIPIENT_INFO_KEY, SB_PKCS7_ERROR_INVALID_RECIPIENT_INFO_KEY);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_ISSUER, SB_PKCS7_ERROR_INVALID_ISSUER, SB_PKCS7_ERROR_INVALID_ISSUER);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_ALGORITHM, SB_PKCS7_ERROR_INVALID_ALGORITHM, SB_PKCS7_ERROR_INVALID_ALGORITHM);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_SIGNED_DATA, SB_PKCS7_ERROR_INVALID_SIGNED_DATA, SB_PKCS7_ERROR_INVALID_SIGNED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_SIGNED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_SIGNED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_SIGNED_DATA_VERSION);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_SIGNER_INFOS, SB_PKCS7_ERROR_INVALID_SIGNER_INFOS, SB_PKCS7_ERROR_INVALID_SIGNER_INFOS);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_SIGNER_INFO_VERSION, SB_PKCS7_ERROR_INVALID_SIGNER_INFO_VERSION, SB_PKCS7_ERROR_INVALID_SIGNER_INFO_VERSION);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_SIGNER_INFO, SB_PKCS7_ERROR_INVALID_SIGNER_INFO, SB_PKCS7_ERROR_INVALID_SIGNER_INFO);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INTERNAL_ERROR, SB_PKCS7_ERROR_INTERNAL_ERROR, SB_PKCS7_ERROR_INTERNAL_ERROR);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_ATTRIBUTES, SB_PKCS7_ERROR_INVALID_ATTRIBUTES, SB_PKCS7_ERROR_INVALID_ATTRIBUTES);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_DIGESTED_DATA, SB_PKCS7_ERROR_INVALID_DIGESTED_DATA, SB_PKCS7_ERROR_INVALID_DIGESTED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_DIGESTED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_DIGESTED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_DIGESTED_DATA_VERSION);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_ENCRYPTED_DATA, SB_PKCS7_ERROR_INVALID_ENCRYPTED_DATA, SB_PKCS7_ERROR_INVALID_ENCRYPTED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_ENCRYPTED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_ENCRYPTED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_ENCRYPTED_DATA_VERSION);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_SIGNED_AND_ENVELOPED_DATA, SB_PKCS7_ERROR_INVALID_SIGNED_AND_ENVELOPED_DATA, SB_PKCS7_ERROR_INVALID_SIGNED_AND_ENVELOPED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_SIGNED_AND_ENVELOPED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_SIGNED_AND_ENVELOPED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_SIGNED_AND_ENVELOPED_DATA_VERSION);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_AUTHENTICATED_DATA, SB_PKCS7_ERROR_INVALID_AUTHENTICATED_DATA, SB_PKCS7_ERROR_INVALID_AUTHENTICATED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_AUTHENTICATED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_AUTHENTICATED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_AUTHENTICATED_DATA_VERSION);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_COMPRESSED_DATA, SB_PKCS7_ERROR_INVALID_COMPRESSED_DATA, SB_PKCS7_ERROR_INVALID_COMPRESSED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_COMPRESSED_DATA_CONTENT, SB_PKCS7_ERROR_INVALID_COMPRESSED_DATA_CONTENT, SB_PKCS7_ERROR_INVALID_COMPRESSED_DATA_CONTENT);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_TIMESTAMPED_DATA, SB_PKCS7_ERROR_INVALID_TIMESTAMPED_DATA, SB_PKCS7_ERROR_INVALID_TIMESTAMPED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_TIMESTAMPED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_TIMESTAMPED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_TIMESTAMPED_DATA_VERSION);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_TIMESTAMPED_DATA_CONTENT, SB_PKCS7_ERROR_INVALID_TIMESTAMPED_DATA_CONTENT, SB_PKCS7_ERROR_INVALID_TIMESTAMPED_DATA_CONTENT);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_ASN_LIMIT_EXCEEDED, SB_PKCS7_ERROR_ASN_LIMIT_EXCEEDED, SB_PKCS7_ERROR_ASN_LIMIT_EXCEEDED);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_AUTH_ENVELOPED_DATA, SB_PKCS7_ERROR_INVALID_AUTH_ENVELOPED_DATA, SB_PKCS7_ERROR_INVALID_AUTH_ENVELOPED_DATA);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_AUTH_ENVELOPED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_AUTH_ENVELOPED_DATA_VERSION, SB_PKCS7_ERROR_INVALID_AUTH_ENVELOPED_DATA_VERSION);
	SB_REGISTER_LONG_CONSTANT(SBPKCS7Utils, SB_PKCS7_ERROR_INVALID_ORIGINATOR_INFO, SB_PKCS7_ERROR_INVALID_ORIGINATOR_INFO, SB_PKCS7_ERROR_INVALID_ORIGINATOR_INFO);
}

void Register_SBPKCS7Utils_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBPKCS7IssuerType", NULL);
	TSBPKCS7IssuerType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPKCS7IssuerType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPKCS7IssuerType_ce_ptr, "itIssuerAndSerialNumber", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKCS7IssuerType_ce_ptr, "itSubjectKeyIdentifier", 1)
}

