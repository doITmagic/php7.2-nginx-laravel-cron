#include "sbpkicommon.h"

zend_class_entry *TSBCMSSignatureValidity_ce_ptr = NULL;

zend_class_entry *TSBCMSValidationOption_ce_ptr = NULL;

zend_class_entry *TSBCMSValidationOptions_ce_ptr = NULL;

zend_class_entry *TSBCMSAdvancedSignatureValidity_ce_ptr = NULL;

zend_class_entry *TSBPKIStatus_ce_ptr = NULL;

zend_class_entry *TSBPKIFailureInfo_ce_ptr = NULL;

void Register_SBPKICommon_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBCMSSignatureValidity", NULL);
	TSBCMSSignatureValidity_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBCMSSignatureValidity_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSSignatureValidity_ce_ptr, "csvValid", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSSignatureValidity_ce_ptr, "csvInvalid", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSSignatureValidity_ce_ptr, "csvSignerNotFound", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSSignatureValidity_ce_ptr, "csvGeneralFailure", 3)
	
	INIT_CLASS_ENTRY(ce, "TSBCMSValidationOption", NULL);
	TSBCMSValidationOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBCMSValidationOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSValidationOption_ce_ptr, "cvoRecursiveValidation", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSValidationOption_ce_ptr, "cvoValidateChains", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSValidationOption_ce_ptr, "cvoValidateTimes", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSValidationOption_ce_ptr, "cvoCheckRevocationStatus", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSValidationOption_ce_ptr, "cvoRequireTimestamps", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSValidationOption_ce_ptr, "cvoIgnoreLocalTimestamps", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSValidationOption_ce_ptr, "cvoValidateTrusts", 6)
	
	INIT_CLASS_ENTRY(ce, "TSBCMSValidationOptions", NULL);
	TSBCMSValidationOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBCMSValidationOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSValidationOptions_ce_ptr, "cvoRecursiveValidation", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSValidationOptions_ce_ptr, "cvoValidateChains", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSValidationOptions_ce_ptr, "cvoValidateTimes", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSValidationOptions_ce_ptr, "cvoCheckRevocationStatus", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSValidationOptions_ce_ptr, "cvoRequireTimestamps", 16)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSValidationOptions_ce_ptr, "cvoIgnoreLocalTimestamps", 32)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSValidationOptions_ce_ptr, "cvoValidateTrusts", 64)
	
	INIT_CLASS_ENTRY(ce, "TSBCMSAdvancedSignatureValidity", NULL);
	TSBCMSAdvancedSignatureValidity_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBCMSAdvancedSignatureValidity_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvValid", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvSignatureCorrupted", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvSignerNotFound", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvIncompleteChain", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvBadCountersignature", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvBadTimestamp", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvCertificateExpired", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvCertificateRevoked", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvCertificateCorrupted", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvUntrustedCA", 9)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvRevInfoNotFound", 10)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvTimestampInfoNotFound", 11)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvFailure", 12)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvCertificateMalformed", 13)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvUnknown", 14)
	SB_DECLARE_CLASS_LONG_CONST(TSBCMSAdvancedSignatureValidity_ce_ptr, "casvChainValidationFailed", 15)
	
	INIT_CLASS_ENTRY(ce, "TSBPKIStatus", NULL);
	TSBPKIStatus_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPKIStatus_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIStatus_ce_ptr, "psGranted", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIStatus_ce_ptr, "psGrantedWithMods", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIStatus_ce_ptr, "psRejection", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIStatus_ce_ptr, "psWaiting", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIStatus_ce_ptr, "psRevocationWarning", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIStatus_ce_ptr, "psRevocationNotification", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIStatus_ce_ptr, "psKeyUpdateWarning", 6)
	
	INIT_CLASS_ENTRY(ce, "TSBPKIFailureInfo", NULL);
	TSBPKIFailureInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBPKIFailureInfo_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIFailureInfo_ce_ptr, "pfiBadAlg", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIFailureInfo_ce_ptr, "pfiBadMessageCheck", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIFailureInfo_ce_ptr, "pfiBadRequest", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIFailureInfo_ce_ptr, "pfiBadTime", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIFailureInfo_ce_ptr, "pfiBadCertId", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIFailureInfo_ce_ptr, "pfiBadDataFormat", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIFailureInfo_ce_ptr, "pfiWrongAuthority", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIFailureInfo_ce_ptr, "pfiIncorrectData", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIFailureInfo_ce_ptr, "pfiMissingTimeStamp", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBPKIFailureInfo_ce_ptr, "pfiBadPOP", 9)
}

