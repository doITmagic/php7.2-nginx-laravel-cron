#include "sbpunycode.h"

SB_PHP_FUNCTION(SBPunycode, PunycodeEncode)
{
	char *sInput;
	sb_str_size sInput_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sInput, &sInput_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBPunycode_PunycodeEncode(sInput, (int32_t)sInput_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-9376730, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPunycode, PunycodeDecode)
{
	char *sInput;
	sb_str_size sInput_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sInput, &sInput_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBPunycode_PunycodeDecode(sInput, (int32_t)sInput_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1774476448, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPunycode, ToASCII)
{
	char *sDomain;
	sb_str_size sDomain_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sDomain, &sDomain_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBPunycode_ToASCII(sDomain, (int32_t)sDomain_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1806839574, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBPunycode, ToUnicode)
{
	char *sDomain;
	sb_str_size sDomain_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sDomain, &sDomain_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBPunycode_ToUnicode(sDomain, (int32_t)sDomain_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(741503488, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

void Register_SBPunycode_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBPunycode, BASE, SB_BASE, SB_BASE);
	SB_REGISTER_LONG_CONSTANT(SBPunycode, TMIN, SB_TMIN, SB_TMIN);
	SB_REGISTER_LONG_CONSTANT(SBPunycode, TMAX, SB_TMAX, SB_TMAX);
	SB_REGISTER_LONG_CONSTANT(SBPunycode, SKEW, SB_SKEW, SB_SKEW);
	SB_REGISTER_LONG_CONSTANT(SBPunycode, DAMP, SB_DAMP, SB_DAMP);
	SB_REGISTER_LONG_CONSTANT(SBPunycode, INITIAL_BIAS, SB_INITIAL_BIAS, SB_INITIAL_BIAS);
	SB_REGISTER_LONG_CONSTANT(SBPunycode, INITIAL_N, SB_INITIAL_N, SB_INITIAL_N);
	SB_REGISTER_LONG_CONSTANT(SBPunycode, DELIMITER, SB_DELIMITER, SB_DELIMITER);
	SB_REGISTER_LONG_CONSTANT(SBPunycode, MAXUINTGR, SB_MAXUINTGR, SB_MAXUINTGR);
	SB_REGISTER_LONG_CONSTANT(SBPunycode, MAXPUNYLEN, SB_MAXPUNYLEN, SB_MAXPUNYLEN);
	SB_REGISTER_LONG_CONSTANT(SBPunycode, SB_PUNYCODE_BAD_INPUT, SB_PUNYCODE_BAD_INPUT, SB_PUNYCODE_BAD_INPUT);
	SB_REGISTER_LONG_CONSTANT(SBPunycode, SB_PUNYCODE_BIG_OUTPUT, SB_PUNYCODE_BIG_OUTPUT, SB_PUNYCODE_BIG_OUTPUT);
	SB_REGISTER_LONG_CONSTANT(SBPunycode, SB_PUNYCODE_OVERFLOW, SB_PUNYCODE_OVERFLOW, SB_PUNYCODE_OVERFLOW);
	SB_REGISTER_STRING_CONSTANT(SBPunycode, SBadInput, SB_SBadInput, SB_SBadInput);
	SB_REGISTER_STRING_CONSTANT(SBPunycode, SBigOutput, SB_SBigOutput, SB_SBigOutput);
	SB_REGISTER_STRING_CONSTANT(SBPunycode, SOverflow, SB_SOverflow, SB_SOverflow);
}

