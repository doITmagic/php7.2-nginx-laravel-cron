#include "sbsamlidentityprovider.h"

zend_class_entry *TSBSAMLIDPCompatibilityOption_ce_ptr = NULL;

zend_class_entry *TSBSAMLIDPCompatibilityOptions_ce_ptr = NULL;

zend_class_entry *TSBSAMLIDPStage_ce_ptr = NULL;

void SB_CALLBACK SBSAMLIdentityProvider_TSBSAMLBeforeHTTPSServerUseEventRaw(void * _ObjectData, TObjectHandle Sender, TElHTTPSServerHandle HTTPSServer)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zHTTPSServer;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zHTTPSServer, 1);
	SBInitObject(zHTTPSServer, TElHTTPSServer_ce_ptr, HTTPSServer TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zHTTPSServer);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSAMLPageContentEventRaw(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle Request, TElHTTPServerResponseParamsHandle Response, uint8_t pContent[], int32_t * szContent, int32_t * Size)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zRequest;
	zval * zResponse;
	zval * zContent;
	SBArrayZValInfo aiContent;
	zval * zSize;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zRequest, 1);
	SBInitObject(zRequest, TElHTTPServerRequestParams_ce_ptr, Request TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zResponse, 2);
	SBInitObject(zResponse, TElHTTPServerResponseParams_ce_ptr, Response TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zContent, 3);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zContent), pContent, *szContent);
	SB_EVENT_INIT_ZVAL_REF(zSize, 4);
	ZVAL_LONG(Z_REFVAL_P(zSize), (sb_zend_long)*Size);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zRequest);
	SB_EVENT_CLEAR_ZVAL(zResponse);
	if (SBGetByteArrayFromZVal(zContent, &aiContent TSRMLS_CC))
		SBCheckError(SBSetEventReturnBuffer(4, aiContent.data, aiContent.len) TSRMLS_CC);
	SBFreeArrayZValInfo(&aiContent);
	SB_EVENT_CLEAR_ZVAL(zContent);
	convert_to_long(Z_REFVAL_P(zSize));
	*Size = (int32_t)Z_LVAL_P(Z_REFVAL_P(zSize));
	SB_EVENT_CLEAR_ZVAL(zSize);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSAMLChangeIDPSessionStageEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLIDPSessionHandle Session, TSBSAMLIDPStageRaw Stage)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zSession;
	zval * zStage;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSession, 1);
	SBInitObject(zSession, TElSAMLIDPSession_ce_ptr, Session TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zStage, 2);
	ZVAL_LONG(zStage, (sb_zend_long)Stage);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSession);
	SB_EVENT_CLEAR_ZVAL(zStage);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK SBSAMLIdentityProvider_TSBSAMLSessionEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLIDPSessionHandle Session)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zSession;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSession, 1);
	SBInitObject(zSession, TElSAMLIDPSession_ce_ptr, Session TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSession);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK SBSAMLIdentityProvider_TSBSAMLLogoutEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLIDPSessionHandle Session, TElHTTPServerResponseParamsHandle ResponseParams)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zSession;
	zval * zResponseParams;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSession, 1);
	SBInitObject(zSession, TElSAMLIDPSession_ce_ptr, Session TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zResponseParams, 2);
	SBInitObject(zResponseParams, TElHTTPServerResponseParams_ce_ptr, ResponseParams TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSession);
	SB_EVENT_CLEAR_ZVAL(zResponseParams);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSAMLChooseAuthnContextRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLAuthnRequestElementHandle Request, char * pcAuthnContextClassRef, int32_t * szAuthnContextClassRef)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zRequest;
	zval * zAuthnContextClassRef;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zRequest, 1);
	SBInitObject(zRequest, TElSAMLAuthnRequestElement_ce_ptr, Request TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zAuthnContextClassRef, 2);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zAuthnContextClassRef), pcAuthnContextClassRef, *szAuthnContextClassRef);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zRequest);
	convert_to_string(Z_REFVAL_P(zAuthnContextClassRef));
	SBCheckError(SBSetEventReturnStringA(3, Z_STRVAL_P(Z_REFVAL_P(zAuthnContextClassRef)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zAuthnContextClassRef))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zAuthnContextClassRef);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSAMLChooseNameIDPolicyFormatEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLIDPSessionHandle Session, char * pcNameIDPolicy, int32_t * szNameIDPolicy)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zSession;
	zval * zNameIDPolicy;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSession, 1);
	SBInitObject(zSession, TElSAMLIDPSession_ce_ptr, Session TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zNameIDPolicy, 2);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zNameIDPolicy), pcNameIDPolicy, *szNameIDPolicy);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSession);
	convert_to_string(Z_REFVAL_P(zNameIDPolicy));
	SBCheckError(SBSetEventReturnStringA(3, Z_STRVAL_P(Z_REFVAL_P(zNameIDPolicy)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zNameIDPolicy))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zNameIDPolicy);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSAMLIDPGetAttributeEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcID, int32_t szID, const char * pcFormat, int32_t szFormat, TElSAMLAttributeElementHandle Attribute, TElSAMLAttributeElementHandle Res)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zID;
	zval * zFormat;
	zval * zAttribute;
	zval * zRes;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zID, 1);
	SB_ZVAL_STRINGL_DUP(zID, pcID, szID);
	SB_EVENT_INIT_ZVAL(zFormat, 2);
	SB_ZVAL_STRINGL_DUP(zFormat, pcFormat, szFormat);
	SB_EVENT_INIT_ZVAL(zAttribute, 3);
	SBInitObject(zAttribute, TElSAMLAttributeElement_ce_ptr, Attribute TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zRes, 4);
	SBInitObject(zRes, TElSAMLAttributeElement_ce_ptr, Res TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zID);
	SB_EVENT_CLEAR_ZVAL(zFormat);
	SB_EVENT_CLEAR_ZVAL(zAttribute);
	SB_EVENT_CLEAR_ZVAL(zRes);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSAMLIDPSetAttributeEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcID, int32_t szID, const char * pcFormat, int32_t szFormat, TElSAMLAttributeElementHandle Attribute, int8_t * Res)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zID;
	zval * zFormat;
	zval * zAttribute;
	zval * zRes;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zID, 1);
	SB_ZVAL_STRINGL_DUP(zID, pcID, szID);
	SB_EVENT_INIT_ZVAL(zFormat, 2);
	SB_ZVAL_STRINGL_DUP(zFormat, pcFormat, szFormat);
	SB_EVENT_INIT_ZVAL(zAttribute, 3);
	SBInitObject(zAttribute, TElSAMLAttributeElement_ce_ptr, Attribute TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zRes, 4);
	ZVAL_BOOL(Z_REFVAL_P(zRes), (zend_bool)*Res);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zID);
	SB_EVENT_CLEAR_ZVAL(zFormat);
	SB_EVENT_CLEAR_ZVAL(zAttribute);
	convert_to_boolean(Z_REFVAL_P(zRes));
	*Res = (int8_t)SB_BVAL_P(Z_REFVAL_P(zRes));
	SB_EVENT_CLEAR_ZVAL(zRes);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElSAMLIDPSession_ce_ptr = NULL;

SB_PHP_METHOD(TElSAMLIDPSession, AddServiceProvider)
{
	char *sSessionIndex;
	sb_str_size sSessionIndex_len;
	zval *oSPInfo;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sSessionIndex, &sSessionIndex_len, &oSPInfo, TElSAMLServiceProviderInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_AddServiceProvider(SBGetObjectHandle(getThis() TSRMLS_CC), sSessionIndex, (int32_t)sSessionIndex_len, SBGetObjectHandle(oSPInfo TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElSAMLServiceProviderInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, RemoveServiceProvider)
{
	char *sSessionIndex;
	sb_str_size sSessionIndex_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sSessionIndex, &sSessionIndex_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_RemoveServiceProvider(SBGetObjectHandle(getThis() TSRMLS_CC), sSessionIndex, (int32_t)sSessionIndex_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_LoggedIn)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIDPSession_get_LoggedIn(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_Stage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLIDPStageRaw fOutResultRaw = 0;
		SBCheckError(TElSAMLIDPSession_get_Stage(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, set_Stage)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_set_Stage(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSAMLIDPStageRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_Login)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIDPSession_get_Login(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1139914951, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, set_Login)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_set_Login(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_Certificate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIDPSession_get_Certificate(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, set_Certificate)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_set_Certificate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_SAMLCookieSet)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIDPSession_get_SAMLCookieSet(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, set_SAMLCookieSet)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_set_SAMLCookieSet(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_NameID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIDPSession_get_NameID(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLID_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, set_NameID)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElSAMLID_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_set_NameID(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSAMLID)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_LoginAttempts)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLIDPSession_get_LoginAttempts(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, set_LoginAttempts)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_set_LoginAttempts(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_ServiceProviders)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIDPSession_get_ServiceProviders(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDictionary_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_LastSP)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIDPSession_get_LastSP(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLServiceProviderInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, set_LastSP)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElSAMLServiceProviderInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_set_LastSP(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSAMLServiceProviderInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_Binding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLBindingTypeRaw fOutResultRaw = 0;
		SBCheckError(TElSAMLIDPSession_get_Binding(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, set_Binding)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_set_Binding(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSAMLBindingTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_ResponseLocation)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIDPSession_get_ResponseLocation(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-608443255, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, set_ResponseLocation)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_set_ResponseLocation(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_AuthnContextClassRef)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIDPSession_get_AuthnContextClassRef(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(165003165, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, set_AuthnContextClassRef)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_set_AuthnContextClassRef(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_NameIDPolicyFormat)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIDPSession_get_NameIDPolicyFormat(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1450418200, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, set_NameIDPolicyFormat)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_set_NameIDPolicyFormat(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_SessionIndex)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIDPSession_get_SessionIndex(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1896893883, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, set_SessionIndex)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_set_SessionIndex(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, get_IdPSSO)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIDPSession_get_IdPSSO(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, set_IdPSSO)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPSession_set_IdPSSO(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPSession, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIDPSession_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_AddServiceProvider, 0, 0, 2)
	ZEND_ARG_INFO(0, SessionIndex)
	ZEND_ARG_OBJ_INFO(0, SPInfo, TElSAMLServiceProviderInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_RemoveServiceProvider, 0, 0, 1)
	ZEND_ARG_INFO(0, SessionIndex)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_LoggedIn, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_Stage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_set_Stage, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_Login, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_set_Login, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_Certificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_set_Certificate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_SAMLCookieSet, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_set_SAMLCookieSet, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_NameID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_set_NameID, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElSAMLID, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_LoginAttempts, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_set_LoginAttempts, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_ServiceProviders, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_LastSP, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_set_LastSP, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElSAMLServiceProviderInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_Binding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_set_Binding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_ResponseLocation, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_set_ResponseLocation, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_AuthnContextClassRef, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_set_AuthnContextClassRef, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_NameIDPolicyFormat, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_set_NameIDPolicyFormat, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_SessionIndex, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_set_SessionIndex, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_get_IdPSSO, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession_set_IdPSSO, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPSession___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSAMLIDPSession_methods[] = {
	PHP_ME(TElSAMLIDPSession, AddServiceProvider, arginfo_TElSAMLIDPSession_AddServiceProvider, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, RemoveServiceProvider, arginfo_TElSAMLIDPSession_RemoveServiceProvider, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_LoggedIn, arginfo_TElSAMLIDPSession_get_LoggedIn, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_Stage, arginfo_TElSAMLIDPSession_get_Stage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, set_Stage, arginfo_TElSAMLIDPSession_set_Stage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_Login, arginfo_TElSAMLIDPSession_get_Login, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, set_Login, arginfo_TElSAMLIDPSession_set_Login, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_Certificate, arginfo_TElSAMLIDPSession_get_Certificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, set_Certificate, arginfo_TElSAMLIDPSession_set_Certificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_SAMLCookieSet, arginfo_TElSAMLIDPSession_get_SAMLCookieSet, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, set_SAMLCookieSet, arginfo_TElSAMLIDPSession_set_SAMLCookieSet, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_NameID, arginfo_TElSAMLIDPSession_get_NameID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, set_NameID, arginfo_TElSAMLIDPSession_set_NameID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_LoginAttempts, arginfo_TElSAMLIDPSession_get_LoginAttempts, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, set_LoginAttempts, arginfo_TElSAMLIDPSession_set_LoginAttempts, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_ServiceProviders, arginfo_TElSAMLIDPSession_get_ServiceProviders, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_LastSP, arginfo_TElSAMLIDPSession_get_LastSP, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, set_LastSP, arginfo_TElSAMLIDPSession_set_LastSP, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_Binding, arginfo_TElSAMLIDPSession_get_Binding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, set_Binding, arginfo_TElSAMLIDPSession_set_Binding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_ResponseLocation, arginfo_TElSAMLIDPSession_get_ResponseLocation, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, set_ResponseLocation, arginfo_TElSAMLIDPSession_set_ResponseLocation, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_AuthnContextClassRef, arginfo_TElSAMLIDPSession_get_AuthnContextClassRef, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, set_AuthnContextClassRef, arginfo_TElSAMLIDPSession_set_AuthnContextClassRef, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_NameIDPolicyFormat, arginfo_TElSAMLIDPSession_get_NameIDPolicyFormat, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, set_NameIDPolicyFormat, arginfo_TElSAMLIDPSession_set_NameIDPolicyFormat, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_SessionIndex, arginfo_TElSAMLIDPSession_get_SessionIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, set_SessionIndex, arginfo_TElSAMLIDPSession_set_SessionIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, get_IdPSSO, arginfo_TElSAMLIDPSession_get_IdPSSO, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, set_IdPSSO, arginfo_TElSAMLIDPSession_set_IdPSSO, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPSession, __construct, arginfo_TElSAMLIDPSession___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSAMLIDPSession(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSAMLIDPSession_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSAMLIDPSession", TElSAMLIDPSession_methods);
	if (NULL == TElSAMLSession_ce_ptr)
		Register_TElSAMLSession(TSRMLS_C);
	TElSAMLIDPSession_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSAMLSession_ce_ptr);
}

zend_class_entry *TElSAMLServiceProviderInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElSAMLServiceProviderInfo, CreateForGoogleAppEngine_Inst)
{
	char *sDomain;
	sb_str_size sDomain_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sDomain, &sDomain_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_CreateForGoogleAppEngine_1(SBGetObjectHandle(getThis() TSRMLS_CC), sDomain, (int32_t)sDomain_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLServiceProviderInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, CreateForGoogleAppEngine)
{
	char *sDomain;
	sb_str_size sDomain_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sDomain, &sDomain_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_CreateForGoogleAppEngine(sDomain, (int32_t)sDomain_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLServiceProviderInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, AddAssertionConsumerService)
{
	zval *oEndpoint;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oEndpoint, TElSAMLEndpoint_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLServiceProviderInfo_AddAssertionConsumerService(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oEndpoint TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSAMLEndpoint)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, AddSingleLogoutService)
{
	zval *oEndpoint;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oEndpoint, TElSAMLEndpoint_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLServiceProviderInfo_AddSingleLogoutService(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oEndpoint TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSAMLEndpoint)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, AddArtifactResolutionService)
{
	zval *oEndpoint;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oEndpoint, TElSAMLEndpoint_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLServiceProviderInfo_AddArtifactResolutionService(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oEndpoint TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSAMLEndpoint)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, RemoveAssertionConsumerService)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElSAMLServiceProviderInfo_RemoveAssertionConsumerService(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, RemoveSingleLogoutService)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElSAMLServiceProviderInfo_RemoveSingleLogoutService(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, RemoveArtifactResolutionService)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElSAMLServiceProviderInfo_RemoveArtifactResolutionService(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, FindDefaultAssertionConsumerServiceEP)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_FindDefaultAssertionConsumerServiceEP(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLEndpoint_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, FindAssertionConsumerServiceEP)
{
	char *sLocation;
	sb_str_size sLocation_len;
	sb_zend_long fBinding;
	sb_zend_long l4Idx;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fBinding) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_FindAssertionConsumerServiceEP(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSAMLBindingTypeRaw)fBinding, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLEndpoint_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sLocation, &sLocation_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_FindAssertionConsumerServiceEP_1(SBGetObjectHandle(getThis() TSRMLS_CC), sLocation, (int32_t)sLocation_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Idx) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_FindAssertionConsumerServiceEP_2(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Idx, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLEndpoint_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer) or (string) or (integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, FindSingleLogoutServiceEP)
{
	sb_zend_long fBinding;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fBinding) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_FindSingleLogoutServiceEP(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSAMLBindingTypeRaw)fBinding, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLEndpoint_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, FindArtifactResolutionServiceEP)
{
	sb_zend_long fBinding;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fBinding) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_FindArtifactResolutionServiceEP(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSAMLBindingTypeRaw)fBinding, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLEndpoint_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, ChooseNameIDFormat)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLServiceProviderInfo_ChooseNameIDFormat(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(518030096, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, LoadMetadata)
{
	char *sURI;
	sb_str_size sURI_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sURI, &sURI_len) == SUCCESS)
	{
		SBCheckError(TElSAMLServiceProviderInfo_LoadMetadata(SBGetObjectHandle(getThis() TSRMLS_CC), sURI, (int32_t)sURI_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, GetUniqueID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLServiceProviderInfo_GetUniqueID(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1620401763, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_EntityID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLServiceProviderInfo_get_EntityID(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-748037897, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, set_EntityID)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLServiceProviderInfo_set_EntityID(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_SPNameQualifier)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLServiceProviderInfo_get_SPNameQualifier(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1304517708, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, set_SPNameQualifier)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLServiceProviderInfo_set_SPNameQualifier(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_IDPNameIDFormats)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_get_IDPNameIDFormats(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_AssertionConsumerServices)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_get_AssertionConsumerServices(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLEndpoint_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_SingleLogoutServices)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_get_SingleLogoutServices(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLEndpoint_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_ArtifactResolutionServices)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_get_ArtifactResolutionServices(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLEndpoint_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_AssertionConsumerServiceCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLServiceProviderInfo_get_AssertionConsumerServiceCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_SingleLogoutServiceCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLServiceProviderInfo_get_SingleLogoutServiceCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_ArtifactResolutionServiceCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLServiceProviderInfo_get_ArtifactResolutionServiceCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_SigningCertificate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_get_SigningCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, set_SigningCertificate)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLServiceProviderInfo_set_SigningCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_EncryptionCertificate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_get_EncryptionCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, set_EncryptionCertificate)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLServiceProviderInfo_set_EncryptionCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_MetaSigningCertificate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_get_MetaSigningCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, set_MetaSigningCertificate)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLServiceProviderInfo_set_MetaSigningCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_SourceID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSAMLServiceProviderInfo_get_SourceID(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-883643413, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, set_SourceID)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSAMLServiceProviderInfo_set_SourceID(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_OnBeforeHTTPSClientUse)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLBeforeHTTPSClientUseEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_get_OnBeforeHTTPSClientUse(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, set_OnBeforeHTTPSClientUse)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLServiceProviderInfo_set_OnBeforeHTTPSClientUse(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLBeforeHTTPSClientUseEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLBeforeHTTPSClientUseEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, get_OnChooseMetadataSPDescriptor)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLChooseMetadataDescriptorEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_get_OnChooseMetadataSPDescriptor(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, set_OnChooseMetadataSPDescriptor)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLServiceProviderInfo_set_OnChooseMetadataSPDescriptor(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLChooseMetadataDescriptorEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLChooseMetadataDescriptorEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLServiceProviderInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLServiceProviderInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_CreateForGoogleAppEngine_Inst, 0, 0, 1)
	ZEND_ARG_INFO(0, Domain)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_CreateForGoogleAppEngine, 0, 0, 1)
	ZEND_ARG_INFO(0, Domain)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_AddAssertionConsumerService, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Endpoint, TElSAMLEndpoint, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_AddSingleLogoutService, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Endpoint, TElSAMLEndpoint, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_AddArtifactResolutionService, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Endpoint, TElSAMLEndpoint, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_RemoveAssertionConsumerService, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_RemoveSingleLogoutService, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_RemoveArtifactResolutionService, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_FindDefaultAssertionConsumerServiceEP, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_FindAssertionConsumerServiceEP, 0, 0, 1)
	ZEND_ARG_INFO(0, Binding_or_Location_or_Idx)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_FindSingleLogoutServiceEP, 0, 0, 1)
	ZEND_ARG_INFO(0, Binding)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_FindArtifactResolutionServiceEP, 0, 0, 1)
	ZEND_ARG_INFO(0, Binding)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_ChooseNameIDFormat, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_LoadMetadata, 0, 0, 1)
	ZEND_ARG_INFO(0, URI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_GetUniqueID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_EntityID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_set_EntityID, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_SPNameQualifier, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_set_SPNameQualifier, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_IDPNameIDFormats, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_AssertionConsumerServices, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_SingleLogoutServices, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_ArtifactResolutionServices, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_AssertionConsumerServiceCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_SingleLogoutServiceCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_ArtifactResolutionServiceCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_SigningCertificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_set_SigningCertificate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_EncryptionCertificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_set_EncryptionCertificate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_MetaSigningCertificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_set_MetaSigningCertificate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_SourceID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_set_SourceID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_OnBeforeHTTPSClientUse, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_set_OnBeforeHTTPSClientUse, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_get_OnChooseMetadataSPDescriptor, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo_set_OnChooseMetadataSPDescriptor, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLServiceProviderInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSAMLServiceProviderInfo_methods[] = {
	PHP_ME(TElSAMLServiceProviderInfo, CreateForGoogleAppEngine_Inst, arginfo_TElSAMLServiceProviderInfo_CreateForGoogleAppEngine_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, CreateForGoogleAppEngine, arginfo_TElSAMLServiceProviderInfo_CreateForGoogleAppEngine, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElSAMLServiceProviderInfo, AddAssertionConsumerService, arginfo_TElSAMLServiceProviderInfo_AddAssertionConsumerService, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, AddSingleLogoutService, arginfo_TElSAMLServiceProviderInfo_AddSingleLogoutService, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, AddArtifactResolutionService, arginfo_TElSAMLServiceProviderInfo_AddArtifactResolutionService, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, RemoveAssertionConsumerService, arginfo_TElSAMLServiceProviderInfo_RemoveAssertionConsumerService, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, RemoveSingleLogoutService, arginfo_TElSAMLServiceProviderInfo_RemoveSingleLogoutService, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, RemoveArtifactResolutionService, arginfo_TElSAMLServiceProviderInfo_RemoveArtifactResolutionService, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, FindDefaultAssertionConsumerServiceEP, arginfo_TElSAMLServiceProviderInfo_FindDefaultAssertionConsumerServiceEP, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, FindAssertionConsumerServiceEP, arginfo_TElSAMLServiceProviderInfo_FindAssertionConsumerServiceEP, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, FindSingleLogoutServiceEP, arginfo_TElSAMLServiceProviderInfo_FindSingleLogoutServiceEP, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, FindArtifactResolutionServiceEP, arginfo_TElSAMLServiceProviderInfo_FindArtifactResolutionServiceEP, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, ChooseNameIDFormat, arginfo_TElSAMLServiceProviderInfo_ChooseNameIDFormat, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, LoadMetadata, arginfo_TElSAMLServiceProviderInfo_LoadMetadata, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, GetUniqueID, arginfo_TElSAMLServiceProviderInfo_GetUniqueID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_EntityID, arginfo_TElSAMLServiceProviderInfo_get_EntityID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, set_EntityID, arginfo_TElSAMLServiceProviderInfo_set_EntityID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_SPNameQualifier, arginfo_TElSAMLServiceProviderInfo_get_SPNameQualifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, set_SPNameQualifier, arginfo_TElSAMLServiceProviderInfo_set_SPNameQualifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_IDPNameIDFormats, arginfo_TElSAMLServiceProviderInfo_get_IDPNameIDFormats, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_AssertionConsumerServices, arginfo_TElSAMLServiceProviderInfo_get_AssertionConsumerServices, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_SingleLogoutServices, arginfo_TElSAMLServiceProviderInfo_get_SingleLogoutServices, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_ArtifactResolutionServices, arginfo_TElSAMLServiceProviderInfo_get_ArtifactResolutionServices, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_AssertionConsumerServiceCount, arginfo_TElSAMLServiceProviderInfo_get_AssertionConsumerServiceCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_SingleLogoutServiceCount, arginfo_TElSAMLServiceProviderInfo_get_SingleLogoutServiceCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_ArtifactResolutionServiceCount, arginfo_TElSAMLServiceProviderInfo_get_ArtifactResolutionServiceCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_SigningCertificate, arginfo_TElSAMLServiceProviderInfo_get_SigningCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, set_SigningCertificate, arginfo_TElSAMLServiceProviderInfo_set_SigningCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_EncryptionCertificate, arginfo_TElSAMLServiceProviderInfo_get_EncryptionCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, set_EncryptionCertificate, arginfo_TElSAMLServiceProviderInfo_set_EncryptionCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_MetaSigningCertificate, arginfo_TElSAMLServiceProviderInfo_get_MetaSigningCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, set_MetaSigningCertificate, arginfo_TElSAMLServiceProviderInfo_set_MetaSigningCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_SourceID, arginfo_TElSAMLServiceProviderInfo_get_SourceID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, set_SourceID, arginfo_TElSAMLServiceProviderInfo_set_SourceID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_OnBeforeHTTPSClientUse, arginfo_TElSAMLServiceProviderInfo_get_OnBeforeHTTPSClientUse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, set_OnBeforeHTTPSClientUse, arginfo_TElSAMLServiceProviderInfo_set_OnBeforeHTTPSClientUse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, get_OnChooseMetadataSPDescriptor, arginfo_TElSAMLServiceProviderInfo_get_OnChooseMetadataSPDescriptor, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, set_OnChooseMetadataSPDescriptor, arginfo_TElSAMLServiceProviderInfo_set_OnChooseMetadataSPDescriptor, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLServiceProviderInfo, __construct, arginfo_TElSAMLServiceProviderInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSAMLServiceProviderInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSAMLServiceProviderInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSAMLServiceProviderInfo", TElSAMLServiceProviderInfo_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElSAMLServiceProviderInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElSAMLSPData_ce_ptr = NULL;

SB_PHP_METHOD(TElSAMLSPData, get_SessionIndex)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLSPData_get_SessionIndex(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-282585837, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLSPData, set_SessionIndex)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLSPData_set_SessionIndex(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLSPData, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLSPData_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLSPData_get_SessionIndex, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLSPData_set_SessionIndex, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLSPData___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSAMLSPData_methods[] = {
	PHP_ME(TElSAMLSPData, get_SessionIndex, arginfo_TElSAMLSPData_get_SessionIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLSPData, set_SessionIndex, arginfo_TElSAMLSPData_set_SessionIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLSPData, __construct, arginfo_TElSAMLSPData___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSAMLSPData(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSAMLSPData_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSAMLSPData", TElSAMLSPData_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSAMLSPData_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSAMLIDPCustomAuthSource_ce_ptr = NULL;

SB_PHP_METHOD(TElSAMLIDPCustomAuthSource, Add)
{
	char *sAuthToken;
	char *sID;
	sb_str_size sAuthToken_len;
	sb_str_size sID_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sID, &sID_len, &sAuthToken, &sAuthToken_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPCustomAuthSource_Add(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len, sAuthToken, (int32_t)sAuthToken_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPCustomAuthSource, Remove)
{
	char *sID;
	sb_str_size sID_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sID, &sID_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPCustomAuthSource_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPCustomAuthSource, Check)
{
	char *sAuthToken;
	char *sID;
	sb_str_size sAuthToken_len;
	sb_str_size sID_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sID, &sID_len, &sAuthToken, &sAuthToken_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIDPCustomAuthSource_Check(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len, sAuthToken, (int32_t)sAuthToken_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPCustomAuthSource, GetSupportedIdentifierTypes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TStringList_Create(&hoOutResult) TSRMLS_CC);
		SBCheckError(TElSAMLIDPCustomAuthSource_GetSupportedIdentifierTypes(SBGetObjectHandle(getThis() TSRMLS_CC), hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TStringList_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPCustomAuthSource, GetIdentifier)
{
	char *sFormat;
	char *sID;
	sb_str_size sFormat_len;
	sb_str_size sID_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sID, &sID_len, &sFormat, &sFormat_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIDPCustomAuthSource_GetIdentifier(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len, sFormat, (int32_t)sFormat_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(801983416, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPCustomAuthSource, SetIdentifier)
{
	char *sFormat;
	char *sID;
	char *sValue;
	sb_str_size sFormat_len;
	sb_str_size sID_len;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sss", &sID, &sID_len, &sFormat, &sFormat_len, &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPCustomAuthSource_SetIdentifier(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len, sFormat, (int32_t)sFormat_len, sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPCustomAuthSource, GetAttribute)
{
	char *sFormat;
	char *sID;
	sb_str_size sFormat_len;
	sb_str_size sID_len;
	zval *oAttribute;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssO!", &sID, &sID_len, &sFormat, &sFormat_len, &oAttribute, TElSAMLAttributeElement_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIDPCustomAuthSource_GetAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len, sFormat, (int32_t)sFormat_len, SBGetObjectHandle(oAttribute TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLAttributeElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, \\TElSAMLAttributeElement)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPCustomAuthSource, SetAttribute)
{
	char *sFormat;
	char *sID;
	sb_str_size sFormat_len;
	sb_str_size sID_len;
	zval *oAttribute;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssO!", &sID, &sID_len, &sFormat, &sFormat_len, &oAttribute, TElSAMLAttributeElement_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIDPCustomAuthSource_SetAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len, sFormat, (int32_t)sFormat_len, SBGetObjectHandle(oAttribute TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, \\TElSAMLAttributeElement)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPCustomAuthSource, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIDPCustomAuthSource_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPCustomAuthSource_Add, 0, 0, 2)
	ZEND_ARG_INFO(0, ID)
	ZEND_ARG_INFO(0, AuthToken)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPCustomAuthSource_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, ID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPCustomAuthSource_Check, 0, 0, 2)
	ZEND_ARG_INFO(0, ID)
	ZEND_ARG_INFO(0, AuthToken)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPCustomAuthSource_GetSupportedIdentifierTypes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPCustomAuthSource_GetIdentifier, 0, 0, 2)
	ZEND_ARG_INFO(0, ID)
	ZEND_ARG_INFO(0, Format)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPCustomAuthSource_SetIdentifier, 0, 0, 3)
	ZEND_ARG_INFO(0, ID)
	ZEND_ARG_INFO(0, Format)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPCustomAuthSource_GetAttribute, 0, 0, 3)
	ZEND_ARG_INFO(0, ID)
	ZEND_ARG_INFO(0, Format)
	ZEND_ARG_OBJ_INFO(0, Attribute, TElSAMLAttributeElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPCustomAuthSource_SetAttribute, 0, 0, 3)
	ZEND_ARG_INFO(0, ID)
	ZEND_ARG_INFO(0, Format)
	ZEND_ARG_OBJ_INFO(0, Attribute, TElSAMLAttributeElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPCustomAuthSource___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSAMLIDPCustomAuthSource_methods[] = {
	PHP_ME(TElSAMLIDPCustomAuthSource, Add, arginfo_TElSAMLIDPCustomAuthSource_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPCustomAuthSource, Remove, arginfo_TElSAMLIDPCustomAuthSource_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPCustomAuthSource, Check, arginfo_TElSAMLIDPCustomAuthSource_Check, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPCustomAuthSource, GetSupportedIdentifierTypes, arginfo_TElSAMLIDPCustomAuthSource_GetSupportedIdentifierTypes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPCustomAuthSource, GetIdentifier, arginfo_TElSAMLIDPCustomAuthSource_GetIdentifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPCustomAuthSource, SetIdentifier, arginfo_TElSAMLIDPCustomAuthSource_SetIdentifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPCustomAuthSource, GetAttribute, arginfo_TElSAMLIDPCustomAuthSource_GetAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPCustomAuthSource, SetAttribute, arginfo_TElSAMLIDPCustomAuthSource_SetAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPCustomAuthSource, __construct, arginfo_TElSAMLIDPCustomAuthSource___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSAMLIDPCustomAuthSource(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSAMLIDPCustomAuthSource_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSAMLIDPCustomAuthSource", TElSAMLIDPCustomAuthSource_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElSAMLIDPCustomAuthSource_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElSAMLIDRecord_ce_ptr = NULL;

SB_PHP_METHOD(TElSAMLIDRecord, get_Identifiers)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIDRecord_get_Identifiers(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDictionary_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDRecord, get_AuthToken)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIDRecord_get_AuthToken(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-174823222, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDRecord, set_AuthToken)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDRecord_set_AuthToken(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDRecord, get_Email)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIDRecord_get_Email(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1683583421, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDRecord, set_Email)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDRecord_set_Email(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDRecord, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIDRecord_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDRecord_get_Identifiers, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDRecord_get_AuthToken, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDRecord_set_AuthToken, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDRecord_get_Email, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDRecord_set_Email, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDRecord___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSAMLIDRecord_methods[] = {
	PHP_ME(TElSAMLIDRecord, get_Identifiers, arginfo_TElSAMLIDRecord_get_Identifiers, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDRecord, get_AuthToken, arginfo_TElSAMLIDRecord_get_AuthToken, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDRecord, set_AuthToken, arginfo_TElSAMLIDRecord_set_AuthToken, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDRecord, get_Email, arginfo_TElSAMLIDRecord_get_Email, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDRecord, set_Email, arginfo_TElSAMLIDRecord_set_Email, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDRecord, __construct, arginfo_TElSAMLIDRecord___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSAMLIDRecord(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSAMLIDRecord_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSAMLIDRecord", TElSAMLIDRecord_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSAMLIDRecord_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSAMLIDPPasswordMemoryAuthSource_ce_ptr = NULL;

SB_PHP_METHOD(TElSAMLIDPPasswordMemoryAuthSource, GetSupportedIdentifierTypes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TStringList_Create(&hoOutResult) TSRMLS_CC);
		SBCheckError(TElSAMLIDPPasswordMemoryAuthSource_GetSupportedIdentifierTypes(SBGetObjectHandle(getThis() TSRMLS_CC), hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TStringList_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPPasswordMemoryAuthSource, GetIdentifier)
{
	char *sFormat;
	char *sID;
	sb_str_size sFormat_len;
	sb_str_size sID_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sID, &sID_len, &sFormat, &sFormat_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIDPPasswordMemoryAuthSource_GetIdentifier(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len, sFormat, (int32_t)sFormat_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1141190337, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPPasswordMemoryAuthSource, SetIdentifier)
{
	char *sFormat;
	char *sID;
	char *sValue;
	sb_str_size sFormat_len;
	sb_str_size sID_len;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sss", &sID, &sID_len, &sFormat, &sFormat_len, &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPPasswordMemoryAuthSource_SetIdentifier(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len, sFormat, (int32_t)sFormat_len, sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPPasswordMemoryAuthSource, GetAttribute)
{
	char *sFormat;
	char *sID;
	sb_str_size sFormat_len;
	sb_str_size sID_len;
	zval *oAttribute;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssO!", &sID, &sID_len, &sFormat, &sFormat_len, &oAttribute, TElSAMLAttributeElement_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIDPPasswordMemoryAuthSource_GetAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len, sFormat, (int32_t)sFormat_len, SBGetObjectHandle(oAttribute TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLAttributeElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, \\TElSAMLAttributeElement)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPPasswordMemoryAuthSource, SetAttribute)
{
	char *sFormat;
	char *sID;
	sb_str_size sFormat_len;
	sb_str_size sID_len;
	zval *oAttribute;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssO!", &sID, &sID_len, &sFormat, &sFormat_len, &oAttribute, TElSAMLAttributeElement_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIDPPasswordMemoryAuthSource_SetAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len, sFormat, (int32_t)sFormat_len, SBGetObjectHandle(oAttribute TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, \\TElSAMLAttributeElement)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPPasswordMemoryAuthSource, Add)
{
	char *sAuthToken;
	char *sEmail;
	char *sID;
	sb_str_size sAuthToken_len;
	sb_str_size sEmail_len;
	sb_str_size sID_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sID, &sID_len, &sAuthToken, &sAuthToken_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPPasswordMemoryAuthSource_Add(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len, sAuthToken, (int32_t)sAuthToken_len) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sss", &sID, &sID_len, &sEmail, &sEmail_len, &sAuthToken, &sAuthToken_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPPasswordMemoryAuthSource_Add_1(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len, sEmail, (int32_t)sEmail_len, sAuthToken, (int32_t)sAuthToken_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string) or (string, string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPPasswordMemoryAuthSource, Remove)
{
	char *sID;
	sb_str_size sID_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sID, &sID_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIDPPasswordMemoryAuthSource_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPPasswordMemoryAuthSource, Check)
{
	char *sAuthToken;
	char *sID;
	sb_str_size sAuthToken_len;
	sb_str_size sID_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sID, &sID_len, &sAuthToken, &sAuthToken_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIDPPasswordMemoryAuthSource_Check(SBGetObjectHandle(getThis() TSRMLS_CC), sID, (int32_t)sID_len, sAuthToken, (int32_t)sAuthToken_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPPasswordMemoryAuthSource, get_OnGetAttribute)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLIDPGetAttributeEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIDPPasswordMemoryAuthSource_get_OnGetAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPPasswordMemoryAuthSource, set_OnGetAttribute)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIDPPasswordMemoryAuthSource_set_OnGetAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLIDPGetAttributeEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLIDPGetAttributeEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPPasswordMemoryAuthSource, get_OnSetAttribute)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLIDPSetAttributeEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIDPPasswordMemoryAuthSource_get_OnSetAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPPasswordMemoryAuthSource, set_OnSetAttribute)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIDPPasswordMemoryAuthSource_set_OnSetAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLIDPSetAttributeEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLIDPSetAttributeEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIDPPasswordMemoryAuthSource, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIDPPasswordMemoryAuthSource_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPPasswordMemoryAuthSource_GetSupportedIdentifierTypes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPPasswordMemoryAuthSource_GetIdentifier, 0, 0, 2)
	ZEND_ARG_INFO(0, ID)
	ZEND_ARG_INFO(0, Format)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPPasswordMemoryAuthSource_SetIdentifier, 0, 0, 3)
	ZEND_ARG_INFO(0, ID)
	ZEND_ARG_INFO(0, Format)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPPasswordMemoryAuthSource_GetAttribute, 0, 0, 3)
	ZEND_ARG_INFO(0, ID)
	ZEND_ARG_INFO(0, Format)
	ZEND_ARG_OBJ_INFO(0, Attribute, TElSAMLAttributeElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPPasswordMemoryAuthSource_SetAttribute, 0, 0, 3)
	ZEND_ARG_INFO(0, ID)
	ZEND_ARG_INFO(0, Format)
	ZEND_ARG_OBJ_INFO(0, Attribute, TElSAMLAttributeElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPPasswordMemoryAuthSource_Add, 0, 0, 2)
	ZEND_ARG_INFO(0, ID)
	ZEND_ARG_INFO(0, AuthToken_or_Email)
	ZEND_ARG_INFO(0, AuthToken)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPPasswordMemoryAuthSource_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, ID)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPPasswordMemoryAuthSource_Check, 0, 0, 2)
	ZEND_ARG_INFO(0, ID)
	ZEND_ARG_INFO(0, AuthToken)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPPasswordMemoryAuthSource_get_OnGetAttribute, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPPasswordMemoryAuthSource_set_OnGetAttribute, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPPasswordMemoryAuthSource_get_OnSetAttribute, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPPasswordMemoryAuthSource_set_OnSetAttribute, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIDPPasswordMemoryAuthSource___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSAMLIDPPasswordMemoryAuthSource_methods[] = {
	PHP_ME(TElSAMLIDPPasswordMemoryAuthSource, GetSupportedIdentifierTypes, arginfo_TElSAMLIDPPasswordMemoryAuthSource_GetSupportedIdentifierTypes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPPasswordMemoryAuthSource, GetIdentifier, arginfo_TElSAMLIDPPasswordMemoryAuthSource_GetIdentifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPPasswordMemoryAuthSource, SetIdentifier, arginfo_TElSAMLIDPPasswordMemoryAuthSource_SetIdentifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPPasswordMemoryAuthSource, GetAttribute, arginfo_TElSAMLIDPPasswordMemoryAuthSource_GetAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPPasswordMemoryAuthSource, SetAttribute, arginfo_TElSAMLIDPPasswordMemoryAuthSource_SetAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPPasswordMemoryAuthSource, Add, arginfo_TElSAMLIDPPasswordMemoryAuthSource_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPPasswordMemoryAuthSource, Remove, arginfo_TElSAMLIDPPasswordMemoryAuthSource_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPPasswordMemoryAuthSource, Check, arginfo_TElSAMLIDPPasswordMemoryAuthSource_Check, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPPasswordMemoryAuthSource, get_OnGetAttribute, arginfo_TElSAMLIDPPasswordMemoryAuthSource_get_OnGetAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPPasswordMemoryAuthSource, set_OnGetAttribute, arginfo_TElSAMLIDPPasswordMemoryAuthSource_set_OnGetAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPPasswordMemoryAuthSource, get_OnSetAttribute, arginfo_TElSAMLIDPPasswordMemoryAuthSource_get_OnSetAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPPasswordMemoryAuthSource, set_OnSetAttribute, arginfo_TElSAMLIDPPasswordMemoryAuthSource_set_OnSetAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIDPPasswordMemoryAuthSource, __construct, arginfo_TElSAMLIDPPasswordMemoryAuthSource___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSAMLIDPPasswordMemoryAuthSource(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSAMLIDPPasswordMemoryAuthSource_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSAMLIDPPasswordMemoryAuthSource", TElSAMLIDPPasswordMemoryAuthSource_methods);
	if (NULL == TElSAMLIDPCustomAuthSource_ce_ptr)
		Register_TElSAMLIDPCustomAuthSource(TSRMLS_C);
	TElSAMLIDPPasswordMemoryAuthSource_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSAMLIDPCustomAuthSource_ce_ptr);
}

zend_class_entry *TElSAMLIdPSSOLink_ce_ptr = NULL;

SB_PHP_METHOD(TElSAMLIdPSSOLink, get_URL)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdPSSOLink_get_URL(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-273686382, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdPSSOLink, set_URL)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdPSSOLink_set_URL(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdPSSOLink, get_RelayState)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdPSSOLink_get_RelayState(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-434184144, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdPSSOLink, set_RelayState)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdPSSOLink_set_RelayState(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdPSSOLink, get_SPIndex)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLIdPSSOLink_get_SPIndex(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdPSSOLink, set_SPIndex)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSAMLIdPSSOLink_set_SPIndex(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdPSSOLink, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdPSSOLink_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdPSSOLink_get_URL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdPSSOLink_set_URL, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdPSSOLink_get_RelayState, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdPSSOLink_set_RelayState, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdPSSOLink_get_SPIndex, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdPSSOLink_set_SPIndex, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdPSSOLink___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSAMLIdPSSOLink_methods[] = {
	PHP_ME(TElSAMLIdPSSOLink, get_URL, arginfo_TElSAMLIdPSSOLink_get_URL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdPSSOLink, set_URL, arginfo_TElSAMLIdPSSOLink_set_URL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdPSSOLink, get_RelayState, arginfo_TElSAMLIdPSSOLink_get_RelayState, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdPSSOLink, set_RelayState, arginfo_TElSAMLIdPSSOLink_set_RelayState, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdPSSOLink, get_SPIndex, arginfo_TElSAMLIdPSSOLink_get_SPIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdPSSOLink, set_SPIndex, arginfo_TElSAMLIdPSSOLink_set_SPIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdPSSOLink, __construct, arginfo_TElSAMLIdPSSOLink___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSAMLIdPSSOLink(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSAMLIdPSSOLink_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSAMLIdPSSOLink", TElSAMLIdPSSOLink_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSAMLIdPSSOLink_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSAMLIdentityProvider_ce_ptr = NULL;

SB_PHP_METHOD(TElSAMLIdentityProvider, Open)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_Open(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, DataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_DataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, Close)
{
	zend_bool bSilent;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bSilent) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_Close(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bSilent) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, SaveMetadata)
{
	zval *oStrm;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStrm, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_SaveMetadata(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStrm TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, AddServiceProvider)
{
	zval *oSPInfo;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSPInfo, TElSAMLServiceProviderInfo_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_AddServiceProvider(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSPInfo TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSAMLServiceProviderInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, RemoveServiceProvider)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_RemoveServiceProvider(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, AddIdPSSOLink)
{
	zval *oLink;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oLink, TElSAMLIdPSSOLink_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_AddIdPSSOLink(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oLink TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSAMLIdPSSOLink)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, RemoveIdPSSOLink)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_RemoveIdPSSOLink(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_ServiceProviders)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_ServiceProviders(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLServiceProviderInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_ServiceProviderCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_ServiceProviderCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_IdPSSOLinks)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_IdPSSOLinks(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLIdPSSOLink_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_IdPSSOLinkCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_IdPSSOLinkCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_Control)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_Control(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElHTTPSServer_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_Active)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_Active(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SupportedAuthnContextClasses)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_SupportedAuthnContextClasses(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SourceID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSAMLIdentityProvider_get_SourceID(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1392219731, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SourceID)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSAMLIdentityProvider_set_SourceID(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_CurrentSession)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_CurrentSession(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLIDPSession_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SendBufferSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_SendBufferSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SendBufferSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_SendBufferSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_ServerName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdentityProvider_get_ServerName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1457694327, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_ServerName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_ServerName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_URL)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdentityProvider_get_URL(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-367659450, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_URL)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_URL(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SingleSignOnService)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdentityProvider_get_SingleSignOnService(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2095491971, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SingleSignOnService)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_SingleSignOnService(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SingleLogoutService)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdentityProvider_get_SingleLogoutService(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1190498019, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SingleLogoutService)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_SingleLogoutService(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_ArtifactResolutionService)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdentityProvider_get_ArtifactResolutionService(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-625457696, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_ArtifactResolutionService)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_ArtifactResolutionService(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_AttributeQueryService)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdentityProvider_get_AttributeQueryService(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1254534828, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_AttributeQueryService)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_AttributeQueryService(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SessionCookieName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdentityProvider_get_SessionCookieName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-242824402, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SessionCookieName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_SessionCookieName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_CertStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_CertStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_AccessLevel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLAccessLevelRaw fOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_AccessLevel(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_AccessLevel)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_AccessLevel(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSAMLAccessLevelRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SessionTTL)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_SessionTTL(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SessionTTL)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_SessionTTL(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SAMLSessionTTL)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_SAMLSessionTTL(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SAMLSessionTTL)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_SAMLSessionTTL(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_MaxIssueInstantTimeDiff)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_MaxIssueInstantTimeDiff(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_MaxIssueInstantTimeDiff)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_MaxIssueInstantTimeDiff(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SessionManager)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_SessionManager(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomSessionManager_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SessionManager)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomSessionManager_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_SessionManager(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSessionManager)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_AuthSource)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_AuthSource(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLIDPCustomAuthSource_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_AuthSource)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElSAMLIDPCustomAuthSource_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_AuthSource(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSAMLIDPCustomAuthSource)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_WantAuthnRequestsSigned)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_WantAuthnRequestsSigned(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_WantAuthnRequestsSigned)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_WantAuthnRequestsSigned(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SigningCertificate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_SigningCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SigningCertificate)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_SigningCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_EncryptionCertificate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_EncryptionCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_EncryptionCertificate)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_EncryptionCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_MetaSigningCertificate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_MetaSigningCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_MetaSigningCertificate)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_MetaSigningCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_ConfirmationCertificate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_ConfirmationCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_ConfirmationCertificate)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_ConfirmationCertificate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SingleLogoutServiceBindings)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLBindingTypesRaw fOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_SingleLogoutServiceBindings(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SingleLogoutServiceBindings)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_SingleLogoutServiceBindings(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSAMLBindingTypesRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SingleSignOnServiceBindings)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLBindingTypesRaw fOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_SingleSignOnServiceBindings(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SingleSignOnServiceBindings)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_SingleSignOnServiceBindings(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSAMLBindingTypesRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_ArtifactResolutionServiceBindings)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLBindingTypesRaw fOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_ArtifactResolutionServiceBindings(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_MetadataURL)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdentityProvider_get_MetadataURL(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1620593321, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_MetadataURL)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_MetadataURL(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_AuthFormTemplate)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdentityProvider_get_AuthFormTemplate(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-322829925, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_AuthFormTemplate)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_AuthFormTemplate(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_LoginAttemptsLimit)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_LoginAttemptsLimit(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_LoginAttemptsLimit)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_LoginAttemptsLimit(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_CurrentSP)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_CurrentSP(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSAMLServiceProviderInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_AssertionsTTL)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_AssertionsTTL(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_AssertionsTTL)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_AssertionsTTL(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_AssertionsOneTimeUse)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_AssertionsOneTimeUse(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_AssertionsOneTimeUse)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_AssertionsOneTimeUse(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SignResponse)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_SignResponse(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SignResponse)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_SignResponse(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SignAssertions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_SignAssertions(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SignAssertions)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_SignAssertions(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_PreferredSingleSignOnResponseBinding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLBindingTypeRaw fOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_PreferredSingleSignOnResponseBinding(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_PreferredSingleSignOnResponseBinding)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_PreferredSingleSignOnResponseBinding(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSAMLBindingTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_PreferredSingleLogoutResponseBinding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLBindingTypeRaw fOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_PreferredSingleLogoutResponseBinding(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_PreferredSingleLogoutResponseBinding)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_PreferredSingleLogoutResponseBinding(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSAMLBindingTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_BlockedClientIP)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_BlockedClientIP(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_BlockedClientIP)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_BlockedClientIP(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_ArtifactStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_ArtifactStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomArtifactStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_ArtifactStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomArtifactStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_ArtifactStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomArtifactStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SignMetadata)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_SignMetadata(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SignMetadata)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_SignMetadata(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_EncryptAssertions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_EncryptAssertions(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_EncryptAssertions)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_EncryptAssertions(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_DefaultPassiveAuthnContextClassRef)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdentityProvider_get_DefaultPassiveAuthnContextClassRef(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1424669546, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_DefaultPassiveAuthnContextClassRef)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_DefaultPassiveAuthnContextClassRef(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_SubjectConfirmationMethod)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdentityProvider_get_SubjectConfirmationMethod(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(75511354, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_SubjectConfirmationMethod)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_SubjectConfirmationMethod(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_DefaultNameIDPolicyFormat)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdentityProvider_get_DefaultNameIDPolicyFormat(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(600726339, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_DefaultNameIDPolicyFormat)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_DefaultNameIDPolicyFormat(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_NotBeforeTimeout)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_NotBeforeTimeout(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_NotBeforeTimeout)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_NotBeforeTimeout(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_AllowIDPSSO)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_AllowIDPSSO(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_AllowIDPSSO)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_AllowIDPSSO(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_IDPSSOPage)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSAMLIdentityProvider_get_IDPSSOPage(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-344523271, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_IDPSSOPage)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_IDPSSOPage(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_CompatibilityOptions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLIDPCompatibilityOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElSAMLIdentityProvider_get_CompatibilityOptions(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_CompatibilityOptions)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSAMLIdentityProvider_set_CompatibilityOptions(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSAMLIDPCompatibilityOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnSessionCreate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBSAMLIdentityProvider_TSBSAMLSessionEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnSessionCreate(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnSessionCreate)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnSessionCreate(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &SBSAMLIdentityProvider_TSBSAMLSessionEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLSessionEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnSessionDestroy)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBSAMLIdentityProvider_TSBSAMLSessionEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnSessionDestroy(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnSessionDestroy)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnSessionDestroy(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &SBSAMLIdentityProvider_TSBSAMLSessionEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLSessionEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnSessionChanged)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBSAMLIdentityProvider_TSBSAMLSessionEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnSessionChanged(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnSessionChanged)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnSessionChanged(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &SBSAMLIdentityProvider_TSBSAMLSessionEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLSessionEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnLogout)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBSAMLIdentityProvider_TSBSAMLLogoutEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnLogout(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnLogout)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnLogout(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &SBSAMLIdentityProvider_TSBSAMLLogoutEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLLogoutEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnBeforeHTTPSServerUse)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBSAMLIdentityProvider_TSBSAMLBeforeHTTPSServerUseEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnBeforeHTTPSServerUse(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnBeforeHTTPSServerUse)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnBeforeHTTPSServerUse(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &SBSAMLIdentityProvider_TSBSAMLBeforeHTTPSServerUseEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLBeforeHTTPSServerUseEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnRequestPrepared)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLRequestPreparedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnRequestPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnRequestPrepared)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnRequestPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLRequestPreparedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLRequestPreparedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnResponseReceived)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLResponseReceivedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnResponseReceived(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnResponseReceived)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnResponseReceived(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLResponseReceivedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLResponseReceivedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnResponsePrepared)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLResponsePreparedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnResponsePrepared(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnResponsePrepared)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnResponsePrepared(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLResponsePreparedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLResponsePreparedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnMetadataPrepared)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLMetadataPreparedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnMetadataPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnMetadataPrepared)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnMetadataPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLMetadataPreparedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLMetadataPreparedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnChangeSessionStage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLChangeIDPSessionStageEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnChangeSessionStage(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnChangeSessionStage)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnChangeSessionStage(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLChangeIDPSessionStageEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLChangeIDPSessionStageEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnSend)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSendEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnSend(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnSend)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnSend(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSendEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSendEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnReceive)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBReceiveEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnReceive(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnReceive)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnReceive(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBReceiveEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBReceiveEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnOpenConnection)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOpenConnectionEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnOpenConnection(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnOpenConnection)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnOpenConnection(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBOpenConnectionEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOpenConnectionEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnSSLError)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBErrorEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnSSLError(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnSSLError)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnSSLError(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBErrorEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBErrorEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnCloseConnection)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCloseConnectionEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnCloseConnection(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnCloseConnection)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnCloseConnection(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCloseConnectionEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCloseConnectionEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnCertificateValidate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCertificateValidateEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnCertificateValidate(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnCertificateValidate)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnCertificateValidate(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCertificateValidateEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCertificateValidateEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnChooseAuthnContext)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLChooseAuthnContext pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnChooseAuthnContext(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnChooseAuthnContext)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnChooseAuthnContext(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLChooseAuthnContextRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLChooseAuthnContext|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnBeforeHTTPSClientUse)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLBeforeHTTPSClientUseEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnBeforeHTTPSClientUse(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnBeforeHTTPSClientUse)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnBeforeHTTPSClientUse(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLBeforeHTTPSClientUseEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLBeforeHTTPSClientUseEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnBindingXMLPrepared)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLBindingXMLPreparedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnBindingXMLPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnBindingXMLPrepared)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnBindingXMLPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLBindingXMLPreparedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLBindingXMLPreparedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnBeforeBindingUse)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLBeforeBindingUseEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnBeforeBindingUse(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnBeforeBindingUse)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnBeforeBindingUse(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLBeforeBindingUseEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLBeforeBindingUseEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnChooseNameIDPolicyFormat)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLChooseNameIDPolicyFormatEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnChooseNameIDPolicyFormat(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnChooseNameIDPolicyFormat)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnChooseNameIDPolicyFormat(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLChooseNameIDPolicyFormatEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLChooseNameIDPolicyFormatEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnResponseStatusCode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLResponseStatusCodeEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnResponseStatusCode(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnResponseStatusCode)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnResponseStatusCode(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLResponseStatusCodeEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLResponseStatusCodeEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, get_OnPageContent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSAMLPageContentEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_get_OnPageContent(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, set_OnPageContent)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSAMLIdentityProvider_set_OnPageContent(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSAMLPageContentEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSAMLPageContentEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSAMLIdentityProvider, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSAMLIdentityProvider_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_Open, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_DataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_Close, 0, 0, 1)
	ZEND_ARG_INFO(0, Silent)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_SaveMetadata, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Strm, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_AddServiceProvider, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, SPInfo, TElSAMLServiceProviderInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_RemoveServiceProvider, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_AddIdPSSOLink, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Link, TElSAMLIdPSSOLink, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_RemoveIdPSSOLink, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_ServiceProviders, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_ServiceProviderCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_IdPSSOLinks, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_IdPSSOLinkCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_Control, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_Active, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SupportedAuthnContextClasses, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SourceID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SourceID, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_CurrentSession, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SendBufferSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SendBufferSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_ServerName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_ServerName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_URL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_URL, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SingleSignOnService, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SingleSignOnService, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SingleLogoutService, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SingleLogoutService, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_ArtifactResolutionService, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_ArtifactResolutionService, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_AttributeQueryService, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_AttributeQueryService, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SessionCookieName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SessionCookieName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_CertStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_CertStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_AccessLevel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_AccessLevel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SessionTTL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SessionTTL, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SAMLSessionTTL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SAMLSessionTTL, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_MaxIssueInstantTimeDiff, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_MaxIssueInstantTimeDiff, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SessionManager, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SessionManager, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomSessionManager, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_AuthSource, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_AuthSource, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElSAMLIDPCustomAuthSource, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_WantAuthnRequestsSigned, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_WantAuthnRequestsSigned, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SigningCertificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SigningCertificate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_EncryptionCertificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_EncryptionCertificate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_MetaSigningCertificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_MetaSigningCertificate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_ConfirmationCertificate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_ConfirmationCertificate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SingleLogoutServiceBindings, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SingleLogoutServiceBindings, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SingleSignOnServiceBindings, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SingleSignOnServiceBindings, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_ArtifactResolutionServiceBindings, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_MetadataURL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_MetadataURL, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_AuthFormTemplate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_AuthFormTemplate, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_LoginAttemptsLimit, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_LoginAttemptsLimit, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_CurrentSP, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_AssertionsTTL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_AssertionsTTL, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_AssertionsOneTimeUse, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_AssertionsOneTimeUse, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SignResponse, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SignResponse, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SignAssertions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SignAssertions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_PreferredSingleSignOnResponseBinding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_PreferredSingleSignOnResponseBinding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_PreferredSingleLogoutResponseBinding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_PreferredSingleLogoutResponseBinding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_BlockedClientIP, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_BlockedClientIP, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_ArtifactStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_ArtifactStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomArtifactStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SignMetadata, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SignMetadata, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_EncryptAssertions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_EncryptAssertions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_DefaultPassiveAuthnContextClassRef, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_DefaultPassiveAuthnContextClassRef, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_SubjectConfirmationMethod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_SubjectConfirmationMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_DefaultNameIDPolicyFormat, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_DefaultNameIDPolicyFormat, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_NotBeforeTimeout, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_NotBeforeTimeout, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_AllowIDPSSO, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_AllowIDPSSO, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_IDPSSOPage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_IDPSSOPage, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_CompatibilityOptions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_CompatibilityOptions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnSessionCreate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnSessionCreate, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnSessionDestroy, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnSessionDestroy, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnSessionChanged, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnSessionChanged, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnLogout, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnLogout, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnBeforeHTTPSServerUse, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnBeforeHTTPSServerUse, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnRequestPrepared, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnRequestPrepared, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnResponseReceived, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnResponseReceived, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnResponsePrepared, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnResponsePrepared, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnMetadataPrepared, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnMetadataPrepared, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnChangeSessionStage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnChangeSessionStage, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnSend, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnSend, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnReceive, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnReceive, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnOpenConnection, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnOpenConnection, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnSSLError, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnSSLError, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnCloseConnection, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnCloseConnection, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnCertificateValidate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnCertificateValidate, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnChooseAuthnContext, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnChooseAuthnContext, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnBeforeHTTPSClientUse, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnBeforeHTTPSClientUse, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnBindingXMLPrepared, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnBindingXMLPrepared, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnBeforeBindingUse, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnBeforeBindingUse, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnChooseNameIDPolicyFormat, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnChooseNameIDPolicyFormat, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnResponseStatusCode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnResponseStatusCode, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_get_OnPageContent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider_set_OnPageContent, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSAMLIdentityProvider___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSAMLIdentityProvider_methods[] = {
	PHP_ME(TElSAMLIdentityProvider, Open, arginfo_TElSAMLIdentityProvider_Open, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, DataAvailable, arginfo_TElSAMLIdentityProvider_DataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, Close, arginfo_TElSAMLIdentityProvider_Close, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, SaveMetadata, arginfo_TElSAMLIdentityProvider_SaveMetadata, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, AddServiceProvider, arginfo_TElSAMLIdentityProvider_AddServiceProvider, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, RemoveServiceProvider, arginfo_TElSAMLIdentityProvider_RemoveServiceProvider, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, AddIdPSSOLink, arginfo_TElSAMLIdentityProvider_AddIdPSSOLink, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, RemoveIdPSSOLink, arginfo_TElSAMLIdentityProvider_RemoveIdPSSOLink, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_ServiceProviders, arginfo_TElSAMLIdentityProvider_get_ServiceProviders, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_ServiceProviderCount, arginfo_TElSAMLIdentityProvider_get_ServiceProviderCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_IdPSSOLinks, arginfo_TElSAMLIdentityProvider_get_IdPSSOLinks, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_IdPSSOLinkCount, arginfo_TElSAMLIdentityProvider_get_IdPSSOLinkCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_Control, arginfo_TElSAMLIdentityProvider_get_Control, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_Active, arginfo_TElSAMLIdentityProvider_get_Active, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SupportedAuthnContextClasses, arginfo_TElSAMLIdentityProvider_get_SupportedAuthnContextClasses, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SourceID, arginfo_TElSAMLIdentityProvider_get_SourceID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SourceID, arginfo_TElSAMLIdentityProvider_set_SourceID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_CurrentSession, arginfo_TElSAMLIdentityProvider_get_CurrentSession, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SendBufferSize, arginfo_TElSAMLIdentityProvider_get_SendBufferSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SendBufferSize, arginfo_TElSAMLIdentityProvider_set_SendBufferSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_ServerName, arginfo_TElSAMLIdentityProvider_get_ServerName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_ServerName, arginfo_TElSAMLIdentityProvider_set_ServerName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_URL, arginfo_TElSAMLIdentityProvider_get_URL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_URL, arginfo_TElSAMLIdentityProvider_set_URL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SingleSignOnService, arginfo_TElSAMLIdentityProvider_get_SingleSignOnService, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SingleSignOnService, arginfo_TElSAMLIdentityProvider_set_SingleSignOnService, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SingleLogoutService, arginfo_TElSAMLIdentityProvider_get_SingleLogoutService, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SingleLogoutService, arginfo_TElSAMLIdentityProvider_set_SingleLogoutService, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_ArtifactResolutionService, arginfo_TElSAMLIdentityProvider_get_ArtifactResolutionService, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_ArtifactResolutionService, arginfo_TElSAMLIdentityProvider_set_ArtifactResolutionService, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_AttributeQueryService, arginfo_TElSAMLIdentityProvider_get_AttributeQueryService, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_AttributeQueryService, arginfo_TElSAMLIdentityProvider_set_AttributeQueryService, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SessionCookieName, arginfo_TElSAMLIdentityProvider_get_SessionCookieName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SessionCookieName, arginfo_TElSAMLIdentityProvider_set_SessionCookieName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_CertStorage, arginfo_TElSAMLIdentityProvider_get_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_CertStorage, arginfo_TElSAMLIdentityProvider_set_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_AccessLevel, arginfo_TElSAMLIdentityProvider_get_AccessLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_AccessLevel, arginfo_TElSAMLIdentityProvider_set_AccessLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SessionTTL, arginfo_TElSAMLIdentityProvider_get_SessionTTL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SessionTTL, arginfo_TElSAMLIdentityProvider_set_SessionTTL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SAMLSessionTTL, arginfo_TElSAMLIdentityProvider_get_SAMLSessionTTL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SAMLSessionTTL, arginfo_TElSAMLIdentityProvider_set_SAMLSessionTTL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_MaxIssueInstantTimeDiff, arginfo_TElSAMLIdentityProvider_get_MaxIssueInstantTimeDiff, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_MaxIssueInstantTimeDiff, arginfo_TElSAMLIdentityProvider_set_MaxIssueInstantTimeDiff, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SessionManager, arginfo_TElSAMLIdentityProvider_get_SessionManager, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SessionManager, arginfo_TElSAMLIdentityProvider_set_SessionManager, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_AuthSource, arginfo_TElSAMLIdentityProvider_get_AuthSource, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_AuthSource, arginfo_TElSAMLIdentityProvider_set_AuthSource, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_WantAuthnRequestsSigned, arginfo_TElSAMLIdentityProvider_get_WantAuthnRequestsSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_WantAuthnRequestsSigned, arginfo_TElSAMLIdentityProvider_set_WantAuthnRequestsSigned, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SigningCertificate, arginfo_TElSAMLIdentityProvider_get_SigningCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SigningCertificate, arginfo_TElSAMLIdentityProvider_set_SigningCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_EncryptionCertificate, arginfo_TElSAMLIdentityProvider_get_EncryptionCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_EncryptionCertificate, arginfo_TElSAMLIdentityProvider_set_EncryptionCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_MetaSigningCertificate, arginfo_TElSAMLIdentityProvider_get_MetaSigningCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_MetaSigningCertificate, arginfo_TElSAMLIdentityProvider_set_MetaSigningCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_ConfirmationCertificate, arginfo_TElSAMLIdentityProvider_get_ConfirmationCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_ConfirmationCertificate, arginfo_TElSAMLIdentityProvider_set_ConfirmationCertificate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SingleLogoutServiceBindings, arginfo_TElSAMLIdentityProvider_get_SingleLogoutServiceBindings, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SingleLogoutServiceBindings, arginfo_TElSAMLIdentityProvider_set_SingleLogoutServiceBindings, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SingleSignOnServiceBindings, arginfo_TElSAMLIdentityProvider_get_SingleSignOnServiceBindings, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SingleSignOnServiceBindings, arginfo_TElSAMLIdentityProvider_set_SingleSignOnServiceBindings, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_ArtifactResolutionServiceBindings, arginfo_TElSAMLIdentityProvider_get_ArtifactResolutionServiceBindings, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_MetadataURL, arginfo_TElSAMLIdentityProvider_get_MetadataURL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_MetadataURL, arginfo_TElSAMLIdentityProvider_set_MetadataURL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_AuthFormTemplate, arginfo_TElSAMLIdentityProvider_get_AuthFormTemplate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_AuthFormTemplate, arginfo_TElSAMLIdentityProvider_set_AuthFormTemplate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_LoginAttemptsLimit, arginfo_TElSAMLIdentityProvider_get_LoginAttemptsLimit, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_LoginAttemptsLimit, arginfo_TElSAMLIdentityProvider_set_LoginAttemptsLimit, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_CurrentSP, arginfo_TElSAMLIdentityProvider_get_CurrentSP, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_AssertionsTTL, arginfo_TElSAMLIdentityProvider_get_AssertionsTTL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_AssertionsTTL, arginfo_TElSAMLIdentityProvider_set_AssertionsTTL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_AssertionsOneTimeUse, arginfo_TElSAMLIdentityProvider_get_AssertionsOneTimeUse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_AssertionsOneTimeUse, arginfo_TElSAMLIdentityProvider_set_AssertionsOneTimeUse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SignResponse, arginfo_TElSAMLIdentityProvider_get_SignResponse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SignResponse, arginfo_TElSAMLIdentityProvider_set_SignResponse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SignAssertions, arginfo_TElSAMLIdentityProvider_get_SignAssertions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SignAssertions, arginfo_TElSAMLIdentityProvider_set_SignAssertions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_PreferredSingleSignOnResponseBinding, arginfo_TElSAMLIdentityProvider_get_PreferredSingleSignOnResponseBinding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_PreferredSingleSignOnResponseBinding, arginfo_TElSAMLIdentityProvider_set_PreferredSingleSignOnResponseBinding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_PreferredSingleLogoutResponseBinding, arginfo_TElSAMLIdentityProvider_get_PreferredSingleLogoutResponseBinding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_PreferredSingleLogoutResponseBinding, arginfo_TElSAMLIdentityProvider_set_PreferredSingleLogoutResponseBinding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_BlockedClientIP, arginfo_TElSAMLIdentityProvider_get_BlockedClientIP, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_BlockedClientIP, arginfo_TElSAMLIdentityProvider_set_BlockedClientIP, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_ArtifactStorage, arginfo_TElSAMLIdentityProvider_get_ArtifactStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_ArtifactStorage, arginfo_TElSAMLIdentityProvider_set_ArtifactStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SignMetadata, arginfo_TElSAMLIdentityProvider_get_SignMetadata, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SignMetadata, arginfo_TElSAMLIdentityProvider_set_SignMetadata, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_EncryptAssertions, arginfo_TElSAMLIdentityProvider_get_EncryptAssertions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_EncryptAssertions, arginfo_TElSAMLIdentityProvider_set_EncryptAssertions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_DefaultPassiveAuthnContextClassRef, arginfo_TElSAMLIdentityProvider_get_DefaultPassiveAuthnContextClassRef, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_DefaultPassiveAuthnContextClassRef, arginfo_TElSAMLIdentityProvider_set_DefaultPassiveAuthnContextClassRef, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_SubjectConfirmationMethod, arginfo_TElSAMLIdentityProvider_get_SubjectConfirmationMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_SubjectConfirmationMethod, arginfo_TElSAMLIdentityProvider_set_SubjectConfirmationMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_DefaultNameIDPolicyFormat, arginfo_TElSAMLIdentityProvider_get_DefaultNameIDPolicyFormat, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_DefaultNameIDPolicyFormat, arginfo_TElSAMLIdentityProvider_set_DefaultNameIDPolicyFormat, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_NotBeforeTimeout, arginfo_TElSAMLIdentityProvider_get_NotBeforeTimeout, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_NotBeforeTimeout, arginfo_TElSAMLIdentityProvider_set_NotBeforeTimeout, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_AllowIDPSSO, arginfo_TElSAMLIdentityProvider_get_AllowIDPSSO, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_AllowIDPSSO, arginfo_TElSAMLIdentityProvider_set_AllowIDPSSO, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_IDPSSOPage, arginfo_TElSAMLIdentityProvider_get_IDPSSOPage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_IDPSSOPage, arginfo_TElSAMLIdentityProvider_set_IDPSSOPage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_CompatibilityOptions, arginfo_TElSAMLIdentityProvider_get_CompatibilityOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_CompatibilityOptions, arginfo_TElSAMLIdentityProvider_set_CompatibilityOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnSessionCreate, arginfo_TElSAMLIdentityProvider_get_OnSessionCreate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnSessionCreate, arginfo_TElSAMLIdentityProvider_set_OnSessionCreate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnSessionDestroy, arginfo_TElSAMLIdentityProvider_get_OnSessionDestroy, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnSessionDestroy, arginfo_TElSAMLIdentityProvider_set_OnSessionDestroy, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnSessionChanged, arginfo_TElSAMLIdentityProvider_get_OnSessionChanged, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnSessionChanged, arginfo_TElSAMLIdentityProvider_set_OnSessionChanged, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnLogout, arginfo_TElSAMLIdentityProvider_get_OnLogout, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnLogout, arginfo_TElSAMLIdentityProvider_set_OnLogout, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnBeforeHTTPSServerUse, arginfo_TElSAMLIdentityProvider_get_OnBeforeHTTPSServerUse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnBeforeHTTPSServerUse, arginfo_TElSAMLIdentityProvider_set_OnBeforeHTTPSServerUse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnRequestPrepared, arginfo_TElSAMLIdentityProvider_get_OnRequestPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnRequestPrepared, arginfo_TElSAMLIdentityProvider_set_OnRequestPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnResponseReceived, arginfo_TElSAMLIdentityProvider_get_OnResponseReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnResponseReceived, arginfo_TElSAMLIdentityProvider_set_OnResponseReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnResponsePrepared, arginfo_TElSAMLIdentityProvider_get_OnResponsePrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnResponsePrepared, arginfo_TElSAMLIdentityProvider_set_OnResponsePrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnMetadataPrepared, arginfo_TElSAMLIdentityProvider_get_OnMetadataPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnMetadataPrepared, arginfo_TElSAMLIdentityProvider_set_OnMetadataPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnChangeSessionStage, arginfo_TElSAMLIdentityProvider_get_OnChangeSessionStage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnChangeSessionStage, arginfo_TElSAMLIdentityProvider_set_OnChangeSessionStage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnSend, arginfo_TElSAMLIdentityProvider_get_OnSend, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnSend, arginfo_TElSAMLIdentityProvider_set_OnSend, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnReceive, arginfo_TElSAMLIdentityProvider_get_OnReceive, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnReceive, arginfo_TElSAMLIdentityProvider_set_OnReceive, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnOpenConnection, arginfo_TElSAMLIdentityProvider_get_OnOpenConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnOpenConnection, arginfo_TElSAMLIdentityProvider_set_OnOpenConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnSSLError, arginfo_TElSAMLIdentityProvider_get_OnSSLError, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnSSLError, arginfo_TElSAMLIdentityProvider_set_OnSSLError, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnCloseConnection, arginfo_TElSAMLIdentityProvider_get_OnCloseConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnCloseConnection, arginfo_TElSAMLIdentityProvider_set_OnCloseConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnCertificateValidate, arginfo_TElSAMLIdentityProvider_get_OnCertificateValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnCertificateValidate, arginfo_TElSAMLIdentityProvider_set_OnCertificateValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnChooseAuthnContext, arginfo_TElSAMLIdentityProvider_get_OnChooseAuthnContext, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnChooseAuthnContext, arginfo_TElSAMLIdentityProvider_set_OnChooseAuthnContext, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnBeforeHTTPSClientUse, arginfo_TElSAMLIdentityProvider_get_OnBeforeHTTPSClientUse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnBeforeHTTPSClientUse, arginfo_TElSAMLIdentityProvider_set_OnBeforeHTTPSClientUse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnBindingXMLPrepared, arginfo_TElSAMLIdentityProvider_get_OnBindingXMLPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnBindingXMLPrepared, arginfo_TElSAMLIdentityProvider_set_OnBindingXMLPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnBeforeBindingUse, arginfo_TElSAMLIdentityProvider_get_OnBeforeBindingUse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnBeforeBindingUse, arginfo_TElSAMLIdentityProvider_set_OnBeforeBindingUse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnChooseNameIDPolicyFormat, arginfo_TElSAMLIdentityProvider_get_OnChooseNameIDPolicyFormat, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnChooseNameIDPolicyFormat, arginfo_TElSAMLIdentityProvider_set_OnChooseNameIDPolicyFormat, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnResponseStatusCode, arginfo_TElSAMLIdentityProvider_get_OnResponseStatusCode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnResponseStatusCode, arginfo_TElSAMLIdentityProvider_set_OnResponseStatusCode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, get_OnPageContent, arginfo_TElSAMLIdentityProvider_get_OnPageContent, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, set_OnPageContent, arginfo_TElSAMLIdentityProvider_set_OnPageContent, ZEND_ACC_PUBLIC)
	PHP_ME(TElSAMLIdentityProvider, __construct, arginfo_TElSAMLIdentityProvider___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSAMLIdentityProvider(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSAMLIdentityProvider_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSAMLIdentityProvider", TElSAMLIdentityProvider_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElSAMLIdentityProvider_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

void Register_SBSAMLIdentityProvider_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBSAMLIDPCompatibilityOption", NULL);
	TSBSAMLIDPCompatibilityOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSAMLIDPCompatibilityOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPCompatibilityOption_ce_ptr, "idcoMicrosoft", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPCompatibilityOption_ce_ptr, "idcoGoogleNoLogout", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBSAMLIDPCompatibilityOptions", NULL);
	TSBSAMLIDPCompatibilityOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBSAMLIDPCompatibilityOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPCompatibilityOptions_ce_ptr, "idcoMicrosoft", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPCompatibilityOptions_ce_ptr, "idcoGoogleNoLogout", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBSAMLIDPStage", NULL);
	TSBSAMLIDPStage_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSAMLIDPStage_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPStage_ce_ptr, "idpsStart", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPStage_ce_ptr, "idpsIdPSSORecv", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPStage_ce_ptr, "idpsAuthnRequestRecv", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPStage_ce_ptr, "idpsChallengeSent", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPStage_ce_ptr, "idpsCredentialsRecv", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPStage_ce_ptr, "idpsResponseSent", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPStage_ce_ptr, "idpsLoggedIn", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPStage_ce_ptr, "idpsLogoutRequestRecv", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPStage_ce_ptr, "idpsLogoutResponseSent", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPStage_ce_ptr, "idpsArtifactResolveRecv", 9)
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPStage_ce_ptr, "idpsArtifactResponseSent", 10)
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPStage_ce_ptr, "idpsAttributeQueryRecv", 11)
	SB_DECLARE_CLASS_LONG_CONST(TSBSAMLIDPStage_ce_ptr, "idpsAttributeResponseSent", 12)
}

