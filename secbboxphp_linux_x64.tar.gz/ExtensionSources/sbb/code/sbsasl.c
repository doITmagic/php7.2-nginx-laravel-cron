#include "sbsasl.h"

zend_class_entry *TSBSASLSecurityLevel_ce_ptr = NULL;

void SB_CALLBACK TSBSASLChallengeEventRaw(void * _ObjectData, TElStringListHandle Options)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(1);
	zval * zOptions;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zOptions, 0);
	SBInitObject(zOptions, TElStringList_ce_ptr, Options TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 1, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zOptions);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSASLGetValueEventRaw(void * _ObjectData, const char * pcName, int32_t szName, char * pcValue, int32_t * szValue)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zName;
	zval * zValue;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zName, 0);
	SB_ZVAL_STRINGL_DUP(zName, pcName, szName);
	SB_EVENT_INIT_ZVAL_REF(zValue, 1);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zValue), NULL, 0);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zName);
	convert_to_string(Z_REFVAL_P(zValue));
	SBCheckError(SBSetEventReturnStringA(2, Z_STRVAL_P(Z_REFVAL_P(zValue)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zValue))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zValue);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElSASLClient_ce_ptr = NULL;

SB_PHP_METHOD(TElSASLClient, ProcessChallenge)
{
	SBArrayZValInfo aiChallenge;
	SBArrayZValInfo aiResponse;
	uint32_t _err;
	zval *zaChallenge;
	zval *zaResponse;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaChallenge, &zaResponse) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaChallenge) || SB_IS_ARRAY_TYPE_RP(zaChallenge) || SB_IS_NULL_TYPE_RP(zaChallenge)) && Z_ISREF_P(zaResponse) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaResponse))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaResponse)))))
	{
		if (!SBGetByteArrayFromZVal(zaChallenge, &aiChallenge TSRMLS_CC)) RETURN_FALSE;
		SBInitArrayZValInfo(&aiResponse);
		_err = TElSASLClient_ProcessChallenge(SBGetObjectHandle(getThis() TSRMLS_CC), aiChallenge.data, aiChallenge.len, aiResponse.data, &aiResponse.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaResponse, &aiResponse TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(1384566645, 2, aiResponse.data, &aiResponse.len) TSRMLS_CC);
			((char *)aiResponse.data)[aiResponse.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiResponse);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiChallenge);
		SBSetByteArrayToZVal(&aiResponse, zaResponse);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLClient, ValueExists)
{
	char *sName;
	sb_str_size sName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSASLClient_ValueExists(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLClient, WrapData)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	sb_zend_long l4InStartIndex;
	sb_zend_long l4OutStartIndex;
	SBArrayZValInfo aiInData;
	SBArrayZValInfo aiOutData;
	SBArrayZValInfo piInData;
	SBArrayZValInfo piOutData;
	uint32_t _err;
	zval *zaInData;
	zval *zaOutData;
	zval *zl4OutSize;
	zval *zpInData;
	zval *zpOutData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzz", &zpInData, &l4InSize, &zpOutData, &zl4OutSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInData) || SB_IS_ARRAY_TYPE_RP(zpInData) || SB_IS_NULL_TYPE_RP(zpInData) || (SB_IS_OBJECT_TYPE_RP(zpInData) && (Z_OBJCE_P(zpInData) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutData) || SB_IS_ARRAY_TYPE_RP(zpOutData) || SB_IS_NULL_TYPE_RP(zpOutData) || (SB_IS_OBJECT_TYPE_RP(zpOutData) && (Z_OBJCE_P(zpOutData) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInData, &piInData TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutData, &piOutData TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElSASLClient_WrapData(SBGetObjectHandle(getThis() TSRMLS_CC), piInData.data, (int32_t)l4InSize, piOutData.data, &l4OutSizeRaw, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInData);
		SBFreePointerZValInfo(&piOutData);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zllzlz", &zaInData, &l4InStartIndex, &l4InSize, &zaOutData, &l4OutStartIndex, &zl4OutSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaInData) || SB_IS_ARRAY_TYPE_RP(zaInData) || SB_IS_NULL_TYPE_RP(zaInData)) && Z_ISREF_P(zaOutData) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaOutData))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaOutData)))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaInData, &aiInData TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaOutData, &aiOutData TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		_err = TElSASLClient_WrapData_1(SBGetObjectHandle(getThis() TSRMLS_CC), aiInData.data, aiInData.len, (int32_t)l4InStartIndex, (int32_t)l4InSize, aiOutData.data, &aiOutData.len, (int32_t)l4OutStartIndex, &l4OutSizeRaw, &bOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaOutData, &aiOutData TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(431124727, 4, aiOutData.data, &aiOutData.len) TSRMLS_CC);
			((char *)aiOutData.data)[aiOutData.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiOutData);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiInData);
		SBSetByteArrayToZVal(&aiOutData, zaOutData);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer) or (array of byte|string|NULL, integer, integer, &array of byte|string, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLClient, UnwrapData)
{
	int32_t l4OutSizeRaw;
	sb_zend_long l4InSize;
	sb_zend_long l4InStartIndex;
	sb_zend_long l4OutStartIndex;
	SBArrayZValInfo aiInData;
	SBArrayZValInfo aiOutData;
	SBArrayZValInfo piInData;
	SBArrayZValInfo piOutData;
	uint32_t _err;
	zval *zaInData;
	zval *zaOutData;
	zval *zl4OutSize;
	zval *zpInData;
	zval *zpOutData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzz", &zpInData, &l4InSize, &zpOutData, &zl4OutSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpInData) || SB_IS_ARRAY_TYPE_RP(zpInData) || SB_IS_NULL_TYPE_RP(zpInData) || (SB_IS_OBJECT_TYPE_RP(zpInData) && (Z_OBJCE_P(zpInData) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpOutData) || SB_IS_ARRAY_TYPE_RP(zpOutData) || SB_IS_NULL_TYPE_RP(zpOutData) || (SB_IS_OBJECT_TYPE_RP(zpOutData) && (Z_OBJCE_P(zpOutData) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpInData, &piInData TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpOutData, &piOutData TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		SBCheckError(TElSASLClient_UnwrapData(SBGetObjectHandle(getThis() TSRMLS_CC), piInData.data, (int32_t)l4InSize, piOutData.data, &l4OutSizeRaw, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piInData);
		SBFreePointerZValInfo(&piOutData);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zllzlz", &zaInData, &l4InStartIndex, &l4InSize, &zaOutData, &l4OutStartIndex, &zl4OutSize) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaInData) || SB_IS_ARRAY_TYPE_RP(zaInData) || SB_IS_NULL_TYPE_RP(zaInData)) && Z_ISREF_P(zaOutData) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaOutData))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaOutData)))) && Z_ISREF_P(zl4OutSize) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4OutSize))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaInData, &aiInData TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaOutData, &aiOutData TSRMLS_CC)) RETURN_FALSE;
		l4OutSizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4OutSize));
		_err = TElSASLClient_UnwrapData_1(SBGetObjectHandle(getThis() TSRMLS_CC), aiInData.data, aiInData.len, (int32_t)l4InStartIndex, (int32_t)l4InSize, aiOutData.data, &aiOutData.len, (int32_t)l4OutStartIndex, &l4OutSizeRaw, &bOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaOutData, &aiOutData TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(183852564, 4, aiOutData.data, &aiOutData.len) TSRMLS_CC);
			((char *)aiOutData.data)[aiOutData.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiOutData);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiInData);
		SBSetByteArrayToZVal(&aiOutData, zaOutData);
		ZVAL_LONG(Z_REFVAL_P(zl4OutSize), (sb_zend_long)l4OutSizeRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, &integer) or (array of byte|string|NULL, integer, integer, &array of byte|string, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLClient, get_Complete)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSASLClient_get_Complete(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLClient, get_MechanismName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLClient_get_MechanismName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-167251316, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLClient, get_SecurityLevel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSASLSecurityLevelRaw fOutResultRaw = 0;
		SBCheckError(TElSASLClient_get_SecurityLevel(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLClient, get_Value)
{
	char *sName;
	sb_str_size sName_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sName, &sName_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLClient_get_Value(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1020384672, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLClient, set_Value)
{
	char *sName;
	char *sNewValue;
	sb_str_size sName_len;
	sb_str_size sNewValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sName, &sName_len, &sNewValue, &sNewValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLClient_set_Value(SBGetObjectHandle(getThis() TSRMLS_CC), sName, (int32_t)sName_len, sNewValue, (int32_t)sNewValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLClient, get_OnChallenge)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSASLChallengeEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSASLClient_get_OnChallenge(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLClient, set_OnChallenge)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSASLClient_set_OnChallenge(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSASLChallengeEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSASLChallengeEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLClient, get_OnGetValue)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSASLGetValueEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSASLClient_get_OnGetValue(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLClient, set_OnGetValue)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSASLClient_set_OnGetValue(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSASLGetValueEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSASLGetValueEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLClient, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSASLClient_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLClient_ProcessChallenge, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Challenge, 0, 1)
	ZEND_ARG_INFO(1, Response)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLClient_ValueExists, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLClient_WrapData, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, InData, 0, 1)
	ZEND_ARG_INFO(0, InSize_or_InStartIndex)
	ZEND_ARG_TYPE_INFO(0, OutData_or_InSize, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_OutData)
	ZEND_ARG_INFO(0, OutStartIndex)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLClient_UnwrapData, 0, 0, 4)
	ZEND_ARG_TYPE_INFO(0, InData, 0, 1)
	ZEND_ARG_INFO(0, InSize_or_InStartIndex)
	ZEND_ARG_TYPE_INFO(0, OutData_or_InSize, 0, 1)
	ZEND_ARG_INFO(1, OutSize_or_OutData)
	ZEND_ARG_INFO(0, OutStartIndex)
	ZEND_ARG_INFO(1, OutSize)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLClient_get_Complete, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLClient_get_MechanismName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLClient_get_SecurityLevel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLClient_get_Value, 0, 0, 1)
	ZEND_ARG_INFO(0, Name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLClient_set_Value, 0, 0, 2)
	ZEND_ARG_INFO(0, Name)
	ZEND_ARG_INFO(0, NewValue)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLClient_get_OnChallenge, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLClient_set_OnChallenge, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLClient_get_OnGetValue, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLClient_set_OnGetValue, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLClient___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSASLClient_methods[] = {
	PHP_ME(TElSASLClient, ProcessChallenge, arginfo_TElSASLClient_ProcessChallenge, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLClient, ValueExists, arginfo_TElSASLClient_ValueExists, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLClient, WrapData, arginfo_TElSASLClient_WrapData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLClient, UnwrapData, arginfo_TElSASLClient_UnwrapData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLClient, get_Complete, arginfo_TElSASLClient_get_Complete, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLClient, get_MechanismName, arginfo_TElSASLClient_get_MechanismName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLClient, get_SecurityLevel, arginfo_TElSASLClient_get_SecurityLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLClient, get_Value, arginfo_TElSASLClient_get_Value, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLClient, set_Value, arginfo_TElSASLClient_set_Value, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLClient, get_OnChallenge, arginfo_TElSASLClient_get_OnChallenge, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLClient, set_OnChallenge, arginfo_TElSASLClient_set_OnChallenge, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLClient, get_OnGetValue, arginfo_TElSASLClient_get_OnGetValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLClient, set_OnGetValue, arginfo_TElSASLClient_set_OnGetValue, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLClient, __construct, arginfo_TElSASLClient___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSASLClient(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSASLClient_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSASLClient", TElSASLClient_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSASLClient_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSASLPlainClient_ce_ptr = NULL;

SB_PHP_METHOD(TElSASLPlainClient, ProcessChallenge)
{
	SBArrayZValInfo aiChallenge;
	SBArrayZValInfo aiResponse;
	uint32_t _err;
	zval *zaChallenge;
	zval *zaResponse;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaChallenge, &zaResponse) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaChallenge) || SB_IS_ARRAY_TYPE_RP(zaChallenge) || SB_IS_NULL_TYPE_RP(zaChallenge)) && Z_ISREF_P(zaResponse) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaResponse))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaResponse)))))
	{
		if (!SBGetByteArrayFromZVal(zaChallenge, &aiChallenge TSRMLS_CC)) RETURN_FALSE;
		SBInitArrayZValInfo(&aiResponse);
		_err = TElSASLPlainClient_ProcessChallenge(SBGetObjectHandle(getThis() TSRMLS_CC), aiChallenge.data, aiChallenge.len, aiResponse.data, &aiResponse.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaResponse, &aiResponse TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(2119569682, 2, aiResponse.data, &aiResponse.len) TSRMLS_CC);
			((char *)aiResponse.data)[aiResponse.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiResponse);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiChallenge);
		SBSetByteArrayToZVal(&aiResponse, zaResponse);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLPlainClient, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLPlainClient_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1388351888, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLPlainClient, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLPlainClient_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLPlainClient, get_UserName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLPlainClient_get_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1064205836, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLPlainClient, set_UserName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLPlainClient_set_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLPlainClient, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSASLPlainClient_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLPlainClient_ProcessChallenge, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Challenge, 0, 1)
	ZEND_ARG_INFO(1, Response)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLPlainClient_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLPlainClient_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLPlainClient_get_UserName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLPlainClient_set_UserName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLPlainClient___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSASLPlainClient_methods[] = {
	PHP_ME(TElSASLPlainClient, ProcessChallenge, arginfo_TElSASLPlainClient_ProcessChallenge, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLPlainClient, get_Password, arginfo_TElSASLPlainClient_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLPlainClient, set_Password, arginfo_TElSASLPlainClient_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLPlainClient, get_UserName, arginfo_TElSASLPlainClient_get_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLPlainClient, set_UserName, arginfo_TElSASLPlainClient_set_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLPlainClient, __construct, arginfo_TElSASLPlainClient___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSASLPlainClient(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSASLPlainClient_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSASLPlainClient", TElSASLPlainClient_methods);
	if (NULL == TElSASLClient_ce_ptr)
		Register_TElSASLClient(TSRMLS_C);
	TElSASLPlainClient_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSASLClient_ce_ptr);
}

zend_class_entry *TElSASLLoginClient_ce_ptr = NULL;

SB_PHP_METHOD(TElSASLLoginClient, ProcessChallenge)
{
	SBArrayZValInfo aiChallenge;
	SBArrayZValInfo aiResponse;
	uint32_t _err;
	zval *zaChallenge;
	zval *zaResponse;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaChallenge, &zaResponse) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaChallenge) || SB_IS_ARRAY_TYPE_RP(zaChallenge) || SB_IS_NULL_TYPE_RP(zaChallenge)) && Z_ISREF_P(zaResponse) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaResponse))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaResponse)))))
	{
		if (!SBGetByteArrayFromZVal(zaChallenge, &aiChallenge TSRMLS_CC)) RETURN_FALSE;
		SBInitArrayZValInfo(&aiResponse);
		_err = TElSASLLoginClient_ProcessChallenge(SBGetObjectHandle(getThis() TSRMLS_CC), aiChallenge.data, aiChallenge.len, aiResponse.data, &aiResponse.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaResponse, &aiResponse TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(930307472, 2, aiResponse.data, &aiResponse.len) TSRMLS_CC);
			((char *)aiResponse.data)[aiResponse.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiResponse);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiChallenge);
		SBSetByteArrayToZVal(&aiResponse, zaResponse);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLLoginClient, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLLoginClient_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1833685007, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLLoginClient, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLLoginClient_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLLoginClient, get_UserName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLLoginClient_get_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-15024019, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLLoginClient, set_UserName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLLoginClient_set_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLLoginClient, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSASLLoginClient_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLLoginClient_ProcessChallenge, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Challenge, 0, 1)
	ZEND_ARG_INFO(1, Response)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLLoginClient_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLLoginClient_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLLoginClient_get_UserName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLLoginClient_set_UserName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLLoginClient___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSASLLoginClient_methods[] = {
	PHP_ME(TElSASLLoginClient, ProcessChallenge, arginfo_TElSASLLoginClient_ProcessChallenge, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLLoginClient, get_Password, arginfo_TElSASLLoginClient_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLLoginClient, set_Password, arginfo_TElSASLLoginClient_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLLoginClient, get_UserName, arginfo_TElSASLLoginClient_get_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLLoginClient, set_UserName, arginfo_TElSASLLoginClient_set_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLLoginClient, __construct, arginfo_TElSASLLoginClient___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSASLLoginClient(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSASLLoginClient_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSASLLoginClient", TElSASLLoginClient_methods);
	if (NULL == TElSASLClient_ce_ptr)
		Register_TElSASLClient(TSRMLS_C);
	TElSASLLoginClient_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSASLClient_ce_ptr);
}

zend_class_entry *TElSASLCRAMMD5Client_ce_ptr = NULL;

SB_PHP_METHOD(TElSASLCRAMMD5Client, ProcessChallenge)
{
	SBArrayZValInfo aiChallenge;
	SBArrayZValInfo aiResponse;
	uint32_t _err;
	zval *zaChallenge;
	zval *zaResponse;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaChallenge, &zaResponse) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaChallenge) || SB_IS_ARRAY_TYPE_RP(zaChallenge) || SB_IS_NULL_TYPE_RP(zaChallenge)) && Z_ISREF_P(zaResponse) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaResponse))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaResponse)))))
	{
		if (!SBGetByteArrayFromZVal(zaChallenge, &aiChallenge TSRMLS_CC)) RETURN_FALSE;
		SBInitArrayZValInfo(&aiResponse);
		_err = TElSASLCRAMMD5Client_ProcessChallenge(SBGetObjectHandle(getThis() TSRMLS_CC), aiChallenge.data, aiChallenge.len, aiResponse.data, &aiResponse.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaResponse, &aiResponse TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-47758895, 2, aiResponse.data, &aiResponse.len) TSRMLS_CC);
			((char *)aiResponse.data)[aiResponse.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiResponse);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiChallenge);
		SBSetByteArrayToZVal(&aiResponse, zaResponse);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLCRAMMD5Client, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLCRAMMD5Client_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1928767470, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLCRAMMD5Client, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLCRAMMD5Client_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLCRAMMD5Client, get_UserName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLCRAMMD5Client_get_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-525879410, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLCRAMMD5Client, set_UserName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLCRAMMD5Client_set_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLCRAMMD5Client, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSASLCRAMMD5Client_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLCRAMMD5Client_ProcessChallenge, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Challenge, 0, 1)
	ZEND_ARG_INFO(1, Response)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLCRAMMD5Client_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLCRAMMD5Client_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLCRAMMD5Client_get_UserName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLCRAMMD5Client_set_UserName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLCRAMMD5Client___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSASLCRAMMD5Client_methods[] = {
	PHP_ME(TElSASLCRAMMD5Client, ProcessChallenge, arginfo_TElSASLCRAMMD5Client_ProcessChallenge, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLCRAMMD5Client, get_Password, arginfo_TElSASLCRAMMD5Client_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLCRAMMD5Client, set_Password, arginfo_TElSASLCRAMMD5Client_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLCRAMMD5Client, get_UserName, arginfo_TElSASLCRAMMD5Client_get_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLCRAMMD5Client, set_UserName, arginfo_TElSASLCRAMMD5Client_set_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLCRAMMD5Client, __construct, arginfo_TElSASLCRAMMD5Client___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSASLCRAMMD5Client(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSASLCRAMMD5Client_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSASLCRAMMD5Client", TElSASLCRAMMD5Client_methods);
	if (NULL == TElSASLClient_ce_ptr)
		Register_TElSASLClient(TSRMLS_C);
	TElSASLCRAMMD5Client_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSASLClient_ce_ptr);
}

zend_class_entry *TElSASLAnonymousClient_ce_ptr = NULL;

SB_PHP_METHOD(TElSASLAnonymousClient, ProcessChallenge)
{
	SBArrayZValInfo aiChallenge;
	SBArrayZValInfo aiResponse;
	uint32_t _err;
	zval *zaChallenge;
	zval *zaResponse;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaChallenge, &zaResponse) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaChallenge) || SB_IS_ARRAY_TYPE_RP(zaChallenge) || SB_IS_NULL_TYPE_RP(zaChallenge)) && Z_ISREF_P(zaResponse) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaResponse))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaResponse)))))
	{
		if (!SBGetByteArrayFromZVal(zaChallenge, &aiChallenge TSRMLS_CC)) RETURN_FALSE;
		SBInitArrayZValInfo(&aiResponse);
		_err = TElSASLAnonymousClient_ProcessChallenge(SBGetObjectHandle(getThis() TSRMLS_CC), aiChallenge.data, aiChallenge.len, aiResponse.data, &aiResponse.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaResponse, &aiResponse TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(786201360, 2, aiResponse.data, &aiResponse.len) TSRMLS_CC);
			((char *)aiResponse.data)[aiResponse.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiResponse);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiChallenge);
		SBSetByteArrayToZVal(&aiResponse, zaResponse);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLAnonymousClient, get_AuthID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLAnonymousClient_get_AuthID(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1542853016, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLAnonymousClient, set_AuthID)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLAnonymousClient_set_AuthID(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLAnonymousClient, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSASLAnonymousClient_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLAnonymousClient_ProcessChallenge, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Challenge, 0, 1)
	ZEND_ARG_INFO(1, Response)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLAnonymousClient_get_AuthID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLAnonymousClient_set_AuthID, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLAnonymousClient___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSASLAnonymousClient_methods[] = {
	PHP_ME(TElSASLAnonymousClient, ProcessChallenge, arginfo_TElSASLAnonymousClient_ProcessChallenge, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLAnonymousClient, get_AuthID, arginfo_TElSASLAnonymousClient_get_AuthID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLAnonymousClient, set_AuthID, arginfo_TElSASLAnonymousClient_set_AuthID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLAnonymousClient, __construct, arginfo_TElSASLAnonymousClient___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSASLAnonymousClient(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSASLAnonymousClient_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSASLAnonymousClient", TElSASLAnonymousClient_methods);
	if (NULL == TElSASLClient_ce_ptr)
		Register_TElSASLClient(TSRMLS_C);
	TElSASLAnonymousClient_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSASLClient_ce_ptr);
}

zend_class_entry *TElSASLExternalClient_ce_ptr = NULL;

SB_PHP_METHOD(TElSASLExternalClient, ProcessChallenge)
{
	SBArrayZValInfo aiChallenge;
	SBArrayZValInfo aiResponse;
	uint32_t _err;
	zval *zaChallenge;
	zval *zaResponse;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaChallenge, &zaResponse) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaChallenge) || SB_IS_ARRAY_TYPE_RP(zaChallenge) || SB_IS_NULL_TYPE_RP(zaChallenge)) && Z_ISREF_P(zaResponse) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaResponse))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaResponse)))))
	{
		if (!SBGetByteArrayFromZVal(zaChallenge, &aiChallenge TSRMLS_CC)) RETURN_FALSE;
		SBInitArrayZValInfo(&aiResponse);
		_err = TElSASLExternalClient_ProcessChallenge(SBGetObjectHandle(getThis() TSRMLS_CC), aiChallenge.data, aiChallenge.len, aiResponse.data, &aiResponse.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaResponse, &aiResponse TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-1566527046, 2, aiResponse.data, &aiResponse.len) TSRMLS_CC);
			((char *)aiResponse.data)[aiResponse.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiResponse);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiChallenge);
		SBSetByteArrayToZVal(&aiResponse, zaResponse);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLExternalClient, get_AuthID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLExternalClient_get_AuthID(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2035996419, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLExternalClient, set_AuthID)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLExternalClient_set_AuthID(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLExternalClient, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSASLExternalClient_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLExternalClient_ProcessChallenge, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Challenge, 0, 1)
	ZEND_ARG_INFO(1, Response)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLExternalClient_get_AuthID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLExternalClient_set_AuthID, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLExternalClient___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSASLExternalClient_methods[] = {
	PHP_ME(TElSASLExternalClient, ProcessChallenge, arginfo_TElSASLExternalClient_ProcessChallenge, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLExternalClient, get_AuthID, arginfo_TElSASLExternalClient_get_AuthID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLExternalClient, set_AuthID, arginfo_TElSASLExternalClient_set_AuthID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLExternalClient, __construct, arginfo_TElSASLExternalClient___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSASLExternalClient(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSASLExternalClient_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSASLExternalClient", TElSASLExternalClient_methods);
	if (NULL == TElSASLClient_ce_ptr)
		Register_TElSASLClient(TSRMLS_C);
	TElSASLExternalClient_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSASLClient_ce_ptr);
}

zend_class_entry *TElSASLDigestMD5Client_ce_ptr = NULL;

SB_PHP_METHOD(TElSASLDigestMD5Client, ProcessChallenge)
{
	SBArrayZValInfo aiChallenge;
	SBArrayZValInfo aiResponse;
	uint32_t _err;
	zval *zaChallenge;
	zval *zaResponse;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaChallenge, &zaResponse) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaChallenge) || SB_IS_ARRAY_TYPE_RP(zaChallenge) || SB_IS_NULL_TYPE_RP(zaChallenge)) && Z_ISREF_P(zaResponse) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaResponse))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaResponse)))))
	{
		if (!SBGetByteArrayFromZVal(zaChallenge, &aiChallenge TSRMLS_CC)) RETURN_FALSE;
		SBInitArrayZValInfo(&aiResponse);
		_err = TElSASLDigestMD5Client_ProcessChallenge(SBGetObjectHandle(getThis() TSRMLS_CC), aiChallenge.data, aiChallenge.len, aiResponse.data, &aiResponse.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaResponse, &aiResponse TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-276318265, 2, aiResponse.data, &aiResponse.len) TSRMLS_CC);
			((char *)aiResponse.data)[aiResponse.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiResponse);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiChallenge);
		SBSetByteArrayToZVal(&aiResponse, zaResponse);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLDigestMD5Client, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLDigestMD5Client_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-709642655, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLDigestMD5Client, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLDigestMD5Client_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLDigestMD5Client, get_UserName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLDigestMD5Client_get_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1206035971, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLDigestMD5Client, set_UserName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLDigestMD5Client_set_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLDigestMD5Client, get_RequestURI)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLDigestMD5Client_get_RequestURI(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1246356752, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLDigestMD5Client, set_RequestURI)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLDigestMD5Client_set_RequestURI(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLDigestMD5Client, get_RequestMethod)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSASLDigestMD5Client_get_RequestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLDigestMD5Client, set_RequestMethod)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSASLDigestMD5Client_set_RequestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLDigestMD5Client, get_CustomRequestMethod)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLDigestMD5Client_get_CustomRequestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-320236757, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLDigestMD5Client, set_CustomRequestMethod)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLDigestMD5Client_set_CustomRequestMethod(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLDigestMD5Client, get_HTTPAuth)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSASLDigestMD5Client_get_HTTPAuth(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLDigestMD5Client, set_HTTPAuth)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSASLDigestMD5Client_set_HTTPAuth(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLDigestMD5Client, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSASLDigestMD5Client_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLDigestMD5Client_ProcessChallenge, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Challenge, 0, 1)
	ZEND_ARG_INFO(1, Response)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLDigestMD5Client_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLDigestMD5Client_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLDigestMD5Client_get_UserName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLDigestMD5Client_set_UserName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLDigestMD5Client_get_RequestURI, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLDigestMD5Client_set_RequestURI, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLDigestMD5Client_get_RequestMethod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLDigestMD5Client_set_RequestMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLDigestMD5Client_get_CustomRequestMethod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLDigestMD5Client_set_CustomRequestMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLDigestMD5Client_get_HTTPAuth, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLDigestMD5Client_set_HTTPAuth, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLDigestMD5Client___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSASLDigestMD5Client_methods[] = {
	PHP_ME(TElSASLDigestMD5Client, ProcessChallenge, arginfo_TElSASLDigestMD5Client_ProcessChallenge, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLDigestMD5Client, get_Password, arginfo_TElSASLDigestMD5Client_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLDigestMD5Client, set_Password, arginfo_TElSASLDigestMD5Client_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLDigestMD5Client, get_UserName, arginfo_TElSASLDigestMD5Client_get_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLDigestMD5Client, set_UserName, arginfo_TElSASLDigestMD5Client_set_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLDigestMD5Client, get_RequestURI, arginfo_TElSASLDigestMD5Client_get_RequestURI, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLDigestMD5Client, set_RequestURI, arginfo_TElSASLDigestMD5Client_set_RequestURI, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLDigestMD5Client, get_RequestMethod, arginfo_TElSASLDigestMD5Client_get_RequestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLDigestMD5Client, set_RequestMethod, arginfo_TElSASLDigestMD5Client_set_RequestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLDigestMD5Client, get_CustomRequestMethod, arginfo_TElSASLDigestMD5Client_get_CustomRequestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLDigestMD5Client, set_CustomRequestMethod, arginfo_TElSASLDigestMD5Client_set_CustomRequestMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLDigestMD5Client, get_HTTPAuth, arginfo_TElSASLDigestMD5Client_get_HTTPAuth, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLDigestMD5Client, set_HTTPAuth, arginfo_TElSASLDigestMD5Client_set_HTTPAuth, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLDigestMD5Client, __construct, arginfo_TElSASLDigestMD5Client___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSASLDigestMD5Client(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSASLDigestMD5Client_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSASLDigestMD5Client", TElSASLDigestMD5Client_methods);
	if (NULL == TElSASLClient_ce_ptr)
		Register_TElSASLClient(TSRMLS_C);
	TElSASLDigestMD5Client_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSASLClient_ce_ptr);
}

#ifdef SB_WINDOWS
zend_class_entry *TElSASLNTLMClient_ce_ptr = NULL;

SB_PHP_METHOD(TElSASLNTLMClient, ProcessChallenge)
{
	SBArrayZValInfo aiChallenge;
	SBArrayZValInfo aiResponse;
	uint32_t _err;
	zval *zaChallenge;
	zval *zaResponse;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaChallenge, &zaResponse) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaChallenge) || SB_IS_ARRAY_TYPE_RP(zaChallenge) || SB_IS_NULL_TYPE_RP(zaChallenge)) && Z_ISREF_P(zaResponse) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaResponse))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaResponse)))))
	{
		if (!SBGetByteArrayFromZVal(zaChallenge, &aiChallenge TSRMLS_CC)) RETURN_FALSE;
		SBInitArrayZValInfo(&aiResponse);
		_err = TElSASLNTLMClient_ProcessChallenge(SBGetObjectHandle(getThis() TSRMLS_CC), aiChallenge.data, aiChallenge.len, aiResponse.data, &aiResponse.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaResponse, &aiResponse TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(1685498732, 2, aiResponse.data, &aiResponse.len) TSRMLS_CC);
			((char *)aiResponse.data)[aiResponse.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiResponse);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiChallenge);
		SBSetByteArrayToZVal(&aiResponse, zaResponse);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLNTLMClient, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLNTLMClient_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(893668085, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLNTLMClient, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLNTLMClient_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLNTLMClient, get_UserName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLNTLMClient_get_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1491772777, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLNTLMClient, set_UserName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLNTLMClient_set_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLNTLMClient, get_UsernameOption)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBUsernameOptionRaw fOutResultRaw = 0;
		SBCheckError(TElSASLNTLMClient_get_UsernameOption(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLNTLMClient, set_UsernameOption)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSASLNTLMClient_set_UsernameOption(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBUsernameOptionRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLNTLMClient, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSASLNTLMClient_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLNTLMClient_ProcessChallenge, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Challenge, 0, 1)
	ZEND_ARG_INFO(1, Response)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLNTLMClient_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLNTLMClient_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLNTLMClient_get_UserName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLNTLMClient_set_UserName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLNTLMClient_get_UsernameOption, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLNTLMClient_set_UsernameOption, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLNTLMClient___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSASLNTLMClient_methods[] = {
	PHP_ME(TElSASLNTLMClient, ProcessChallenge, arginfo_TElSASLNTLMClient_ProcessChallenge, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLNTLMClient, get_Password, arginfo_TElSASLNTLMClient_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLNTLMClient, set_Password, arginfo_TElSASLNTLMClient_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLNTLMClient, get_UserName, arginfo_TElSASLNTLMClient_get_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLNTLMClient, set_UserName, arginfo_TElSASLNTLMClient_set_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLNTLMClient, get_UsernameOption, arginfo_TElSASLNTLMClient_get_UsernameOption, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLNTLMClient, set_UsernameOption, arginfo_TElSASLNTLMClient_set_UsernameOption, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLNTLMClient, __construct, arginfo_TElSASLNTLMClient___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSASLNTLMClient(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSASLNTLMClient_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSASLNTLMClient", TElSASLNTLMClient_methods);
	if (NULL == TElSASLClient_ce_ptr)
		Register_TElSASLClient(TSRMLS_C);
	TElSASLNTLMClient_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSASLClient_ce_ptr);
}
#endif

zend_class_entry *TElSASLXOAuth2Client_ce_ptr = NULL;

SB_PHP_METHOD(TElSASLXOAuth2Client, ProcessChallenge)
{
	SBArrayZValInfo aiChallenge;
	SBArrayZValInfo aiResponse;
	uint32_t _err;
	zval *zaChallenge;
	zval *zaResponse;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaChallenge, &zaResponse) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaChallenge) || SB_IS_ARRAY_TYPE_RP(zaChallenge) || SB_IS_NULL_TYPE_RP(zaChallenge)) && Z_ISREF_P(zaResponse) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaResponse))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaResponse)))))
	{
		if (!SBGetByteArrayFromZVal(zaChallenge, &aiChallenge TSRMLS_CC)) RETURN_FALSE;
		SBInitArrayZValInfo(&aiResponse);
		_err = TElSASLXOAuth2Client_ProcessChallenge(SBGetObjectHandle(getThis() TSRMLS_CC), aiChallenge.data, aiChallenge.len, aiResponse.data, &aiResponse.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaResponse, &aiResponse TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(1539125077, 2, aiResponse.data, &aiResponse.len) TSRMLS_CC);
			((char *)aiResponse.data)[aiResponse.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiResponse);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiChallenge);
		SBSetByteArrayToZVal(&aiResponse, zaResponse);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLXOAuth2Client, get_AccessToken)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLXOAuth2Client_get_AccessToken(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(950115963, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLXOAuth2Client, set_AccessToken)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLXOAuth2Client_set_AccessToken(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLXOAuth2Client, get_UserName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSASLXOAuth2Client_get_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(168533928, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLXOAuth2Client, set_UserName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSASLXOAuth2Client_set_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSASLXOAuth2Client, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSASLXOAuth2Client_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLXOAuth2Client_ProcessChallenge, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Challenge, 0, 1)
	ZEND_ARG_INFO(1, Response)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLXOAuth2Client_get_AccessToken, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLXOAuth2Client_set_AccessToken, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLXOAuth2Client_get_UserName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLXOAuth2Client_set_UserName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSASLXOAuth2Client___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSASLXOAuth2Client_methods[] = {
	PHP_ME(TElSASLXOAuth2Client, ProcessChallenge, arginfo_TElSASLXOAuth2Client_ProcessChallenge, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLXOAuth2Client, get_AccessToken, arginfo_TElSASLXOAuth2Client_get_AccessToken, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLXOAuth2Client, set_AccessToken, arginfo_TElSASLXOAuth2Client_set_AccessToken, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLXOAuth2Client, get_UserName, arginfo_TElSASLXOAuth2Client_get_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLXOAuth2Client, set_UserName, arginfo_TElSASLXOAuth2Client_set_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSASLXOAuth2Client, __construct, arginfo_TElSASLXOAuth2Client___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSASLXOAuth2Client(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSASLXOAuth2Client_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSASLXOAuth2Client", TElSASLXOAuth2Client_methods);
	if (NULL == TElSASLClient_ce_ptr)
		Register_TElSASLClient(TSRMLS_C);
	TElSASLXOAuth2Client_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSASLClient_ce_ptr);
}

SB_PHP_FUNCTION(SBSASL, CreateSASLClient)
{
	char *sMechanism;
	sb_str_size sMechanism_len;
	zval *oMechanisms;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sMechanism, &sMechanism_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(SBSASL_CreateSASLClient(sMechanism, (int32_t)sMechanism_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSASLClient_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oMechanisms, TStringList_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(SBSASL_CreateSASLClient_1(SBGetObjectHandle(oMechanisms TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSASLClient_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (\\TStringList)" TSRMLS_CC);
	}
}

void Register_SBSASL_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_STRING_CONSTANT(SBSASL, SB_SASL_MECHANISM_PLAIN, SB_SASL_MECHANISM_PLAIN, SB_SASL_MECHANISM_PLAIN);
	SB_REGISTER_STRING_CONSTANT(SBSASL, SB_SASL_MECHANISM_LOGIN, SB_SASL_MECHANISM_LOGIN, SB_SASL_MECHANISM_LOGIN);
	SB_REGISTER_STRING_CONSTANT(SBSASL, SB_SASL_MECHANISM_CRAM_MD5, SB_SASL_MECHANISM_CRAM_MD5, SB_SASL_MECHANISM_CRAM_MD5);
	SB_REGISTER_STRING_CONSTANT(SBSASL, SB_SASL_MECHANISM_EXTERNAL, SB_SASL_MECHANISM_EXTERNAL, SB_SASL_MECHANISM_EXTERNAL);
	SB_REGISTER_STRING_CONSTANT(SBSASL, SB_SASL_MECHANISM_ANONYMOUS, SB_SASL_MECHANISM_ANONYMOUS, SB_SASL_MECHANISM_ANONYMOUS);
	SB_REGISTER_STRING_CONSTANT(SBSASL, SB_SASL_MECHANISM_DIGEST_MD5, SB_SASL_MECHANISM_DIGEST_MD5, SB_SASL_MECHANISM_DIGEST_MD5);
	SB_REGISTER_STRING_CONSTANT(SBSASL, SB_SASL_MECHANISM_NTLM, SB_SASL_MECHANISM_NTLM, SB_SASL_MECHANISM_NTLM);
	SB_REGISTER_STRING_CONSTANT(SBSASL, SB_SASL_MECHANISM_GSSAPI, SB_SASL_MECHANISM_GSSAPI, SB_SASL_MECHANISM_GSSAPI);
	SB_REGISTER_STRING_CONSTANT(SBSASL, SB_SASL_MECHANISM_XOAUTH2, SB_SASL_MECHANISM_XOAUTH2, SB_SASL_MECHANISM_XOAUTH2);
	SB_REGISTER_LONG_CONSTANT(SBSASL, SB_SASL_ERROR_BASE, SB_SASL_ERROR_BASE, SB_SASL_ERROR_BASE);
	SB_REGISTER_LONG_CONSTANT(SBSASL, SB_SASL_CRAM_ERROR_EMPTY_CHALLENGE, SB_SASL_CRAM_ERROR_EMPTY_CHALLENGE, SB_SASL_CRAM_ERROR_EMPTY_CHALLENGE);
	SB_REGISTER_LONG_CONSTANT(SBSASL, SB_SASL_CRAM_ERROR_INVALID_CHALLENGE, SB_SASL_CRAM_ERROR_INVALID_CHALLENGE, SB_SASL_CRAM_ERROR_INVALID_CHALLENGE);
	SB_REGISTER_LONG_CONSTANT(SBSASL, SB_SASL_DIGEST_ERROR_INVALID_CHALLENGE, SB_SASL_DIGEST_ERROR_INVALID_CHALLENGE, SB_SASL_DIGEST_ERROR_INVALID_CHALLENGE);
	SB_REGISTER_LONG_CONSTANT(SBSASL, SB_SASL_DIGEST_ERROR_INVALID_REALM, SB_SASL_DIGEST_ERROR_INVALID_REALM, SB_SASL_DIGEST_ERROR_INVALID_REALM);
	SB_REGISTER_LONG_CONSTANT(SBSASL, SB_SASL_DIGEST_ERROR_PARAMETER_NOT_SPECIFIED, SB_SASL_DIGEST_ERROR_PARAMETER_NOT_SPECIFIED, SB_SASL_DIGEST_ERROR_PARAMETER_NOT_SPECIFIED);
	SB_REGISTER_LONG_CONSTANT(SBSASL, SB_SASL_XOAUTH2_ERROR_UNKNOWN_RESPONSE, SB_SASL_XOAUTH2_ERROR_UNKNOWN_RESPONSE, SB_SASL_XOAUTH2_ERROR_UNKNOWN_RESPONSE);
	SB_REGISTER_LONG_CONSTANT(SBSASL, SB_SASL_XOAUTH2_ERROR_AUTHENTICATION_FAILED, SB_SASL_XOAUTH2_ERROR_AUTHENTICATION_FAILED, SB_SASL_XOAUTH2_ERROR_AUTHENTICATION_FAILED);
}

void Register_SBSASL_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBSASLSecurityLevel", NULL);
	TSBSASLSecurityLevel_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSASLSecurityLevel_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSASLSecurityLevel_ce_ptr, "saslAuthOnly", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSASLSecurityLevel_ce_ptr, "saslAuthIntegrity", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSASLSecurityLevel_ce_ptr, "saslAuthConfidentiality", 2)
}
