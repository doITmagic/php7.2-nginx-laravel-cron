#include "sbsftpcommon.h"

zend_class_entry *TSBSftpFileOpenMode_ce_ptr = NULL;

zend_class_entry *TSBSftpFileOpenModes_ce_ptr = NULL;

zend_class_entry *TSBSftpFileOpenAccessItem_ce_ptr = NULL;

zend_class_entry *TSBSftpFileOpenAccess_ce_ptr = NULL;

zend_class_entry *TSBSftpVersion_ce_ptr = NULL;

zend_class_entry *TSBSftpVersions_ce_ptr = NULL;

zend_class_entry *TSBSftpAttribute_ce_ptr = NULL;

zend_class_entry *TSBSftpAttributes_ce_ptr = NULL;

zend_class_entry *TSBSftpRenameFlag_ce_ptr = NULL;

zend_class_entry *TSBSftpRenameFlags_ce_ptr = NULL;

zend_class_entry *TSBSftpTextHint_ce_ptr = NULL;

zend_class_entry *TSBSftpRealpathControl_ce_ptr = NULL;

zend_class_entry *TSBSftpFileOperation_ce_ptr = NULL;

zend_class_entry *TSBSftpFileType_ce_ptr = NULL;

zend_class_entry *TSBSftpTransferDirection_ce_ptr = NULL;

void SB_CALLBACK TSBSftpFileOpenEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pHandle[], int32_t szHandle)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zHandle;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zHandle, 1);
	SB_ZVAL_STRINGL_DUP(zHandle, pHandle, szHandle);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zHandle);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpErrorEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode, const char * pcComment, int32_t szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zErrorCode, 1);
	ZVAL_LONG(zErrorCode, (sb_zend_long)ErrorCode);
	SB_EVENT_INIT_ZVAL(zComment, 2);
	SB_ZVAL_STRINGL_DUP(zComment, pcComment, szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpSuccessEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcComment, int32_t szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zComment, 1);
	SB_ZVAL_STRINGL_DUP(zComment, pcComment, szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpDirectoryListingEventRaw(void * _ObjectData, TObjectHandle Sender, const TElSftpFileInfoHandle pListing[], int32_t szListing)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zListing;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zListing, 1);
	SBSetObjectArrayToZValP((TElClassHandle *)pListing, szListing, TElSftpFileInfo_ce_ptr, zListing TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zListing);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpFileAttributesEventRaw(void * _ObjectData, TObjectHandle Sender, TElSftpFileAttributesHandle Attributes)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zAttributes;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zAttributes, 1);
	SBInitObject(zAttributes, TElSftpFileAttributes_ce_ptr, Attributes TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zAttributes);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpDataEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zBuffer;
	zval * zSize;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 1);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSize, 2);
	ZVAL_LONG(zSize, (sb_zend_long)Size);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zSize);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpAbsolutePathEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zPath;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SB_ZVAL_STRINGL_DUP(zPath, pcPath, szPath);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpVersionSelectEventRaw(void * _ObjectData, TObjectHandle Sender, TSBSftpVersionsRaw Versions, TSBSftpVersionRaw * Version)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zVersions;
	zval * zVersion;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zVersions, 1);
	ZVAL_LONG(zVersions, (sb_zend_long)Versions);
	SB_EVENT_INIT_ZVAL_REF(zVersion, 2);
	ZVAL_LONG(Z_REFVAL_P(zVersion), (sb_zend_long)*Version);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zVersions);
	convert_to_long(Z_REFVAL_P(zVersion));
	*Version = (TSBSftpVersionRaw)Z_LVAL_P(Z_REFVAL_P(zVersion));
	SB_EVENT_CLEAR_ZVAL(zVersion);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpAvailableSpaceEventRaw(void * _ObjectData, TObjectHandle Sender, TElSftpSpaceAvailableReplyHandle AvailSpace)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zAvailSpace;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zAvailSpace, 1);
	SBInitObject(zAvailSpace, TElSftpSpaceAvailableReply_ce_ptr, AvailSpace TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zAvailSpace);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpFileHashEventRaw(void * _ObjectData, TObjectHandle Sender, TElSftpCheckFileReplyHandle Reply, int8_t * Cont)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zReply;
	zval * zCont;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zReply, 1);
	SBInitObject(zReply, TElSftpCheckFileReply_ce_ptr, Reply TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zCont, 2);
	ZVAL_BOOL(Z_REFVAL_P(zCont), (zend_bool)*Cont);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zReply);
	convert_to_boolean(Z_REFVAL_P(zCont));
	*Cont = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCont));
	SB_EVENT_CLEAR_ZVAL(zCont);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpNameEventRaw(void * _ObjectData, TObjectHandle Sender, TElSftpFileInfoHandle FileInfo)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zFileInfo;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zFileInfo, 1);
	SBInitObject(zFileInfo, TElSftpFileInfo_ce_ptr, FileInfo TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zFileInfo);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpTransferCompletedEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t Count)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zCount;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCount, 1);
	ZVAL_LONG(zCount, (sb_zend_long)Count);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zCount);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpBlockTransferPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, int64_t Offset, int64_t Size, TSBSftpTransferDirectionRaw Direction, int8_t TextMode, int32_t * BlockSize, int32_t * PipelineLength)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(7);
	zval * zSender;
	zval * zOffset;
	zval * zSize;
	zval * zDirection;
	zval * zTextMode;
	zval * zBlockSize;
	zval * zPipelineLength;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOffset, 1);
	ZVAL_LONG(zOffset, (sb_zend_long)Offset);
	SB_EVENT_INIT_ZVAL(zSize, 2);
	ZVAL_LONG(zSize, (sb_zend_long)Size);
	SB_EVENT_INIT_ZVAL(zDirection, 3);
	ZVAL_LONG(zDirection, (sb_zend_long)Direction);
	SB_EVENT_INIT_ZVAL(zTextMode, 4);
	ZVAL_BOOL(zTextMode, (zend_bool)TextMode);
	SB_EVENT_INIT_ZVAL_REF(zBlockSize, 5);
	ZVAL_LONG(Z_REFVAL_P(zBlockSize), (sb_zend_long)*BlockSize);
	SB_EVENT_INIT_ZVAL_REF(zPipelineLength, 6);
	ZVAL_LONG(Z_REFVAL_P(zPipelineLength), (sb_zend_long)*PipelineLength);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 7, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zOffset);
	SB_EVENT_CLEAR_ZVAL(zSize);
	SB_EVENT_CLEAR_ZVAL(zDirection);
	SB_EVENT_CLEAR_ZVAL(zTextMode);
	convert_to_long(Z_REFVAL_P(zBlockSize));
	*BlockSize = (int32_t)Z_LVAL_P(Z_REFVAL_P(zBlockSize));
	SB_EVENT_CLEAR_ZVAL(zBlockSize);
	convert_to_long(Z_REFVAL_P(zPipelineLength));
	*PipelineLength = (int32_t)Z_LVAL_P(Z_REFVAL_P(zPipelineLength));
	SB_EVENT_CLEAR_ZVAL(zPipelineLength);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpMessageLoopEventRaw(void * _ObjectData, int8_t * OutResult)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(pzOutResult);
	TSRMLS_FETCH();

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(pzOutResult), 0, NULL TSRMLS_CC);

	if (pzOutResult)
	{
		convert_to_boolean(pzOutResult);
		*OutResult = (int8_t)SB_BVAL_P(pzOutResult);
		SB_EVENT_CLEAR_ZVAL(pzOutResult);
	}
}

void SB_CALLBACK TSBSftpTunnelOpenFailedEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomSSHTunnelHandle Tunnel, int8_t * AbortConnection)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zTunnel;
	zval * zAbortConnection;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTunnel, 1);
	SBInitObject(zTunnel, TElCustomSSHTunnel_ce_ptr, Tunnel TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zAbortConnection, 2);
	ZVAL_BOOL(Z_REFVAL_P(zAbortConnection), (zend_bool)*AbortConnection);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zTunnel);
	convert_to_boolean(Z_REFVAL_P(zAbortConnection));
	*AbortConnection = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAbortConnection));
	SB_EVENT_CLEAR_ZVAL(zAbortConnection);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpSecondaryChannelEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomSSHTunnelHandle Tunnel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zTunnel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTunnel, 1);
	SBInitObject(zTunnel, TElCustomSSHTunnel_ce_ptr, Tunnel TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zTunnel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpSecondaryChannelErrorEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomSSHTunnelHandle Tunnel, int32_t ErrorCode)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zTunnel;
	zval * zErrorCode;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTunnel, 1);
	SBInitObject(zTunnel, TElCustomSSHTunnel_ce_ptr, Tunnel TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zErrorCode, 2);
	ZVAL_LONG(zErrorCode, (sb_zend_long)ErrorCode);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zTunnel);
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpStatvfsEventRaw(void * _ObjectData, TObjectHandle Sender, TElSftpStatVFSReplyHandle Statvfs)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zStatvfs;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zStatvfs, 1);
	SBInitObject(zStatvfs, TElSftpStatVFSReply_ce_ptr, Statvfs TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zStatvfs);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerBlockEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t Offset, int64_t Length, TSBSftpFileOpenAccessRaw LockMask, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(7);
	zval * zSender;
	zval * zData;
	zval * zOffset;
	zval * zLength;
	zval * zLockMask;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOffset, 2);
	ZVAL_LONG(zOffset, (sb_zend_long)Offset);
	SB_EVENT_INIT_ZVAL(zLength, 3);
	ZVAL_LONG(zLength, (sb_zend_long)Length);
	SB_EVENT_INIT_ZVAL(zLockMask, 4);
	ZVAL_LONG(zLockMask, (sb_zend_long)LockMask);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 5);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 6);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 7, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zOffset);
	SB_EVENT_CLEAR_ZVAL(zLength);
	SB_EVENT_CLEAR_ZVAL(zLockMask);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(7, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerUnblockEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t Offset, int64_t Length, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(6);
	zval * zSender;
	zval * zData;
	zval * zOffset;
	zval * zLength;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOffset, 2);
	ZVAL_LONG(zOffset, (sb_zend_long)Offset);
	SB_EVENT_INIT_ZVAL(zLength, 3);
	ZVAL_LONG(zLength, (sb_zend_long)Length);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 4);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 5);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 6, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zOffset);
	SB_EVENT_CLEAR_ZVAL(zLength);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(6, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerCreateDirectoryEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zPath;
	zval * zAttributes;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SB_ZVAL_STRINGL_DUP(zPath, pcPath, szPath);
	SB_EVENT_INIT_ZVAL(zAttributes, 2);
	SBInitObject(zAttributes, TElSftpFileAttributes_ce_ptr, Attributes TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 3);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	SB_EVENT_CLEAR_ZVAL(zAttributes);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerCreateSymLinkEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcLinkPath, int32_t szLinkPath, const char * pcTargetPath, int32_t szTargetPath, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zLinkPath;
	zval * zTargetPath;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zLinkPath, 1);
	SB_ZVAL_STRINGL_DUP(zLinkPath, pcLinkPath, szLinkPath);
	SB_EVENT_INIT_ZVAL(zTargetPath, 2);
	SB_ZVAL_STRINGL_DUP(zTargetPath, pcTargetPath, szTargetPath);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 3);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zLinkPath);
	SB_EVENT_CLEAR_ZVAL(zTargetPath);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerCreateHardLinkEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcNewLinkPath, int32_t szNewLinkPath, const char * pcExistingPath, int32_t szExistingPath, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zNewLinkPath;
	zval * zExistingPath;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zNewLinkPath, 1);
	SB_ZVAL_STRINGL_DUP(zNewLinkPath, pcNewLinkPath, szNewLinkPath);
	SB_EVENT_INIT_ZVAL(zExistingPath, 2);
	SB_ZVAL_STRINGL_DUP(zExistingPath, pcExistingPath, szExistingPath);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 3);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zNewLinkPath);
	SB_EVENT_CLEAR_ZVAL(zExistingPath);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerOpenFileEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TSBSftpFileOpenModesRaw Modes, TSBSftpFileOpenAccessRaw Access, uint32_t DesiredAccess, TElSftpFileAttributesHandle Attributes, void * (* Data), int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(9);
	zval * zSender;
	zval * zPath;
	zval * zModes;
	zval * zAccess;
	zval * zDesiredAccess;
	zval * zAttributes;
	zval * zData;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SB_ZVAL_STRINGL_DUP(zPath, pcPath, szPath);
	SB_EVENT_INIT_ZVAL(zModes, 2);
	ZVAL_LONG(zModes, (sb_zend_long)Modes);
	SB_EVENT_INIT_ZVAL(zAccess, 3);
	ZVAL_LONG(zAccess, (sb_zend_long)Access);
	SB_EVENT_INIT_ZVAL(zDesiredAccess, 4);
	ZVAL_LONG(zDesiredAccess, (sb_zend_long)DesiredAccess);
	SB_EVENT_INIT_ZVAL(zAttributes, 5);
	SBInitObject(zAttributes, TElSftpFileAttributes_ce_ptr, Attributes TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zData, 6);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 7);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 8);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 9, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	SB_EVENT_CLEAR_ZVAL(zModes);
	SB_EVENT_CLEAR_ZVAL(zAccess);
	SB_EVENT_CLEAR_ZVAL(zDesiredAccess);
	SB_EVENT_CLEAR_ZVAL(zAttributes);
	Data = SBGetPointerValue(zData TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zData);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(9, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerRemoveEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zPath;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SB_ZVAL_STRINGL_DUP(zPath, pcPath, szPath);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 2);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 3);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(4, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerRenameFileEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcOldPath, int32_t szOldPath, const char * pcNewPath, int32_t szNewPath, TSBSftpRenameFlagsRaw Flags, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(6);
	zval * zSender;
	zval * zOldPath;
	zval * zNewPath;
	zval * zFlags;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOldPath, 1);
	SB_ZVAL_STRINGL_DUP(zOldPath, pcOldPath, szOldPath);
	SB_EVENT_INIT_ZVAL(zNewPath, 2);
	SB_ZVAL_STRINGL_DUP(zNewPath, pcNewPath, szNewPath);
	SB_EVENT_INIT_ZVAL(zFlags, 3);
	ZVAL_LONG(zFlags, (sb_zend_long)Flags);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 4);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 5);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 6, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zOldPath);
	SB_EVENT_CLEAR_ZVAL(zNewPath);
	SB_EVENT_CLEAR_ZVAL(zFlags);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(6, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerReadSymLinkEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpFileInfoHandle Info, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zPath;
	zval * zInfo;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SB_ZVAL_STRINGL_DUP(zPath, pcPath, szPath);
	SB_EVENT_INIT_ZVAL(zInfo, 2);
	SBInitObject(zInfo, TElSftpFileInfo_ce_ptr, Info TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 3);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	SB_EVENT_CLEAR_ZVAL(zInfo);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerSetAttributesEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zPath;
	zval * zAttributes;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SB_ZVAL_STRINGL_DUP(zPath, pcPath, szPath);
	SB_EVENT_INIT_ZVAL(zAttributes, 2);
	SBInitObject(zAttributes, TElSftpFileAttributes_ce_ptr, Attributes TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 3);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	SB_EVENT_CLEAR_ZVAL(zAttributes);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerSetAttributes2EventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zData;
	zval * zAttributes;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zAttributes, 2);
	SBInitObject(zAttributes, TElSftpFileAttributes_ce_ptr, Attributes TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 3);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zAttributes);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerRequestAttributesEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, int8_t FollowSymLinks, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(6);
	zval * zSender;
	zval * zPath;
	zval * zFollowSymLinks;
	zval * zAttributes;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SB_ZVAL_STRINGL_DUP(zPath, pcPath, szPath);
	SB_EVENT_INIT_ZVAL(zFollowSymLinks, 2);
	ZVAL_BOOL(zFollowSymLinks, (zend_bool)FollowSymLinks);
	SB_EVENT_INIT_ZVAL(zAttributes, 3);
	SBInitObject(zAttributes, TElSftpFileAttributes_ce_ptr, Attributes TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 4);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 5);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 6, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	SB_EVENT_CLEAR_ZVAL(zFollowSymLinks);
	SB_EVENT_CLEAR_ZVAL(zAttributes);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(6, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerRequestAbsolutePathEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, char * pcAbsolutePath, int32_t * szAbsolutePath, TSBSftpRealpathControlRaw Control, TStringListHandle ComposePath, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(7);
	zval * zSender;
	zval * zPath;
	zval * zAbsolutePath;
	zval * zControl;
	zval * zComposePath;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SB_ZVAL_STRINGL_DUP(zPath, pcPath, szPath);
	SB_EVENT_INIT_ZVAL_REF(zAbsolutePath, 2);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zAbsolutePath), pcAbsolutePath, *szAbsolutePath);
	SB_EVENT_INIT_ZVAL(zControl, 3);
	ZVAL_LONG(zControl, (sb_zend_long)Control);
	SB_EVENT_INIT_ZVAL(zComposePath, 4);
	SBInitObject(zComposePath, TStringList_ce_ptr, ComposePath TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 5);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 6);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 7, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	convert_to_string(Z_REFVAL_P(zAbsolutePath));
	SBCheckError(SBSetEventReturnStringA(3, Z_STRVAL_P(Z_REFVAL_P(zAbsolutePath)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zAbsolutePath))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zAbsolutePath);
	SB_EVENT_CLEAR_ZVAL(zControl);
	SB_EVENT_CLEAR_ZVAL(zComposePath);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(7, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerRequestAttributes2EventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zData;
	zval * zAttributes;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zAttributes, 2);
	SBInitObject(zAttributes, TElSftpFileAttributes_ce_ptr, Attributes TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 3);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zAttributes);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerFindFirstEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, void * (* Data), TElSftpFileInfoHandle Info, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(6);
	zval * zSender;
	zval * zPath;
	zval * zData;
	zval * zInfo;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SB_ZVAL_STRINGL_DUP(zPath, pcPath, szPath);
	SB_EVENT_INIT_ZVAL_REF(zData, 2);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zInfo, 3);
	SBInitObject(zInfo, TElSftpFileInfo_ce_ptr, Info TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 4);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 5);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 6, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	Data = SBGetPointerValue(zData TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zInfo);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(6, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerFindNextEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, TElSftpFileInfoHandle Info, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zData;
	zval * zInfo;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zInfo, 2);
	SBInitObject(zInfo, TElSftpFileInfo_ce_ptr, Info TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 3);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zInfo);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerFindCloseEventRaw(void * _ObjectData, TObjectHandle Sender, void * SearchRec, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zSearchRec;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSearchRec, 1);
	SBInitPointerObject(zSearchRec, SearchRec TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 2);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 3);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSearchRec);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(4, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerReadEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t Offset, void * Buffer, int32_t Count, int32_t * Read, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(8);
	zval * zSender;
	zval * zData;
	zval * zOffset;
	zval * zBuffer;
	zval * zCount;
	zval * zRead;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOffset, 2);
	ZVAL_LONG(zOffset, (sb_zend_long)Offset);
	SB_EVENT_INIT_ZVAL(zBuffer, 3);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCount, 4);
	ZVAL_LONG(zCount, (sb_zend_long)Count);
	SB_EVENT_INIT_ZVAL_REF(zRead, 5);
	ZVAL_LONG(Z_REFVAL_P(zRead), (sb_zend_long)*Read);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 6);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 7);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 8, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zOffset);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zCount);
	convert_to_long(Z_REFVAL_P(zRead));
	*Read = (int32_t)Z_LVAL_P(Z_REFVAL_P(zRead));
	SB_EVENT_CLEAR_ZVAL(zRead);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(8, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerWriteEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t Offset, void * Buffer, int32_t Count, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(7);
	zval * zSender;
	zval * zData;
	zval * zOffset;
	zval * zBuffer;
	zval * zCount;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOffset, 2);
	ZVAL_LONG(zOffset, (sb_zend_long)Offset);
	SB_EVENT_INIT_ZVAL(zBuffer, 3);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCount, 4);
	ZVAL_LONG(zCount, (sb_zend_long)Count);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 5);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 6);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 7, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zOffset);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zCount);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(7, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerTextSeekEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t LineNumber, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zData;
	zval * zLineNumber;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zLineNumber, 2);
	ZVAL_LONG(zLineNumber, (sb_zend_long)LineNumber);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 3);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zLineNumber);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerCloseHandleEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zData;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 2);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 3);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(4, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerSendEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zBuffer;
	zval * zSize;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 1);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSize, 2);
	ZVAL_LONG(zSize, (sb_zend_long)Size);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zSize);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerReceiveEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t MaxSize, int32_t * Written)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zBuffer;
	zval * zMaxSize;
	zval * zWritten;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 1);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zMaxSize, 2);
	ZVAL_LONG(zMaxSize, (sb_zend_long)MaxSize);
	SB_EVENT_INIT_ZVAL_REF(zWritten, 3);
	ZVAL_LONG(Z_REFVAL_P(zWritten), (sb_zend_long)*Written);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zMaxSize);
	convert_to_long(Z_REFVAL_P(zWritten));
	*Written = (int32_t)Z_LVAL_P(Z_REFVAL_P(zWritten));
	SB_EVENT_CLEAR_ZVAL(zWritten);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerExtendedRequestEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcRequest, int32_t szRequest, void * Buffer, int32_t Size, TStreamHandle Response, int32_t * ErrorCode, char * pcComment, int32_t * szComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(7);
	zval * zSender;
	zval * zRequest;
	zval * zBuffer;
	zval * zSize;
	zval * zResponse;
	zval * zErrorCode;
	zval * zComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zRequest, 1);
	SB_ZVAL_STRINGL_DUP(zRequest, pcRequest, szRequest);
	SB_EVENT_INIT_ZVAL(zBuffer, 2);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSize, 3);
	ZVAL_LONG(zSize, (sb_zend_long)Size);
	SB_EVENT_INIT_ZVAL(zResponse, 4);
	SBInitObject(zResponse, TStream_ce_ptr, Response TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrorCode, 5);
	ZVAL_LONG(Z_REFVAL_P(zErrorCode), (sb_zend_long)*ErrorCode);
	SB_EVENT_INIT_ZVAL_REF(zComment, 6);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zComment), pcComment, *szComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 7, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zRequest);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zSize);
	SB_EVENT_CLEAR_ZVAL(zResponse);
	convert_to_long(Z_REFVAL_P(zErrorCode));
	*ErrorCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrorCode));
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	convert_to_string(Z_REFVAL_P(zComment));
	SBCheckError(SBSetEventReturnStringA(7, Z_STRVAL_P(Z_REFVAL_P(zComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSftpServerVersionChangeEventRaw(void * _ObjectData, TObjectHandle Sender, TSBSftpVersionRaw Version)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zVersion;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zVersion, 1);
	ZVAL_LONG(zVersion, (sb_zend_long)Version);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zVersion);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerSendVendorIDEventRaw(void * _ObjectData, TObjectHandle Sender, TElSftpVendorIDExtensionHandle VendorID, int8_t * Send)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zVendorID;
	zval * zSend;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zVendorID, 1);
	SBInitObject(zVendorID, TElSftpVendorIDExtension_ce_ptr, VendorID TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zSend, 2);
	ZVAL_FALSE(Z_REFVAL_P(zSend));

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zVendorID);
	convert_to_boolean(Z_REFVAL_P(zSend));
	*Send = (int8_t)SB_BVAL_P(Z_REFVAL_P(zSend));
	SB_EVENT_CLEAR_ZVAL(zSend);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerRequestFileHashEventRaw(void * _ObjectData, TObjectHandle Sender, TElSftpCheckFileExtensionHandle Extension, TElSftpCheckFileReplyHandle Reply, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zExtension;
	zval * zReply;
	zval * zErrCode;
	zval * zErrComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zExtension, 1);
	SBInitObject(zExtension, TElSftpCheckFileExtension_ce_ptr, Extension TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zReply, 2);
	SBInitObject(zReply, TElSftpCheckFileReply_ce_ptr, Reply TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrCode, 3);
	ZVAL_LONG(Z_REFVAL_P(zErrCode), (sb_zend_long)*ErrCode);
	SB_EVENT_INIT_ZVAL_REF(zErrComment, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zErrComment), pcErrComment, *szErrComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zExtension);
	SB_EVENT_CLEAR_ZVAL(zReply);
	convert_to_long(Z_REFVAL_P(zErrCode));
	*ErrCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrCode));
	SB_EVENT_CLEAR_ZVAL(zErrCode);
	convert_to_string(Z_REFVAL_P(zErrComment));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zErrComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zErrComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zErrComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerRequestFileHashByHandleEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, TElSftpCheckFileExtensionHandle Extension, TElSftpCheckFileReplyHandle Reply, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(6);
	zval * zSender;
	zval * zData;
	zval * zExtension;
	zval * zReply;
	zval * zErrCode;
	zval * zErrComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SBInitPointerObject(zData, Data TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zExtension, 2);
	SBInitObject(zExtension, TElSftpCheckFileExtension_ce_ptr, Extension TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zReply, 3);
	SBInitObject(zReply, TElSftpCheckFileReply_ce_ptr, Reply TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrCode, 4);
	ZVAL_LONG(Z_REFVAL_P(zErrCode), (sb_zend_long)*ErrCode);
	SB_EVENT_INIT_ZVAL_REF(zErrComment, 5);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zErrComment), pcErrComment, *szErrComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 6, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	SB_EVENT_CLEAR_ZVAL(zExtension);
	SB_EVENT_CLEAR_ZVAL(zReply);
	convert_to_long(Z_REFVAL_P(zErrCode));
	*ErrCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrCode));
	SB_EVENT_CLEAR_ZVAL(zErrCode);
	convert_to_string(Z_REFVAL_P(zErrComment));
	SBCheckError(SBSetEventReturnStringA(6, Z_STRVAL_P(Z_REFVAL_P(zErrComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zErrComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zErrComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerRequestAvailableSpaceEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpSpaceAvailableReplyHandle Reply, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zPath;
	zval * zReply;
	zval * zErrCode;
	zval * zErrComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SB_ZVAL_STRINGL_DUP(zPath, pcPath, szPath);
	SB_EVENT_INIT_ZVAL(zReply, 2);
	SBInitObject(zReply, TElSftpSpaceAvailableReply_ce_ptr, Reply TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrCode, 3);
	ZVAL_LONG(Z_REFVAL_P(zErrCode), (sb_zend_long)*ErrCode);
	SB_EVENT_INIT_ZVAL_REF(zErrComment, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zErrComment), pcErrComment, *szErrComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	SB_EVENT_CLEAR_ZVAL(zReply);
	convert_to_long(Z_REFVAL_P(zErrCode));
	*ErrCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrCode));
	SB_EVENT_CLEAR_ZVAL(zErrCode);
	convert_to_string(Z_REFVAL_P(zErrComment));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zErrComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zErrComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zErrComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerRequestStatVFSEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpStatVFSReplyHandle Reply, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zPath;
	zval * zReply;
	zval * zErrCode;
	zval * zErrComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPath, 1);
	SB_ZVAL_STRINGL_DUP(zPath, pcPath, szPath);
	SB_EVENT_INIT_ZVAL(zReply, 2);
	SBInitObject(zReply, TElSftpStatVFSReply_ce_ptr, Reply TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zErrCode, 3);
	ZVAL_LONG(Z_REFVAL_P(zErrCode), (sb_zend_long)*ErrCode);
	SB_EVENT_INIT_ZVAL_REF(zErrComment, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zErrComment), pcErrComment, *szErrComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPath);
	SB_EVENT_CLEAR_ZVAL(zReply);
	convert_to_long(Z_REFVAL_P(zErrCode));
	*ErrCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrCode));
	SB_EVENT_CLEAR_ZVAL(zErrCode);
	convert_to_string(Z_REFVAL_P(zErrComment));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zErrComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zErrComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zErrComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerRequestHomeDirectoryEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, char * pcHomeDir, int32_t * szHomeDir, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zUsername;
	zval * zHomeDir;
	zval * zErrCode;
	zval * zErrComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zUsername, 1);
	SB_ZVAL_STRINGL_DUP(zUsername, pcUsername, szUsername);
	SB_EVENT_INIT_ZVAL_REF(zHomeDir, 2);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zHomeDir), pcHomeDir, *szHomeDir);
	SB_EVENT_INIT_ZVAL_REF(zErrCode, 3);
	ZVAL_LONG(Z_REFVAL_P(zErrCode), (sb_zend_long)*ErrCode);
	SB_EVENT_INIT_ZVAL_REF(zErrComment, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zErrComment), pcErrComment, *szErrComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zUsername);
	convert_to_string(Z_REFVAL_P(zHomeDir));
	SBCheckError(SBSetEventReturnStringA(3, Z_STRVAL_P(Z_REFVAL_P(zHomeDir)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zHomeDir))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zHomeDir);
	convert_to_long(Z_REFVAL_P(zErrCode));
	*ErrCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrCode));
	SB_EVENT_CLEAR_ZVAL(zErrCode);
	convert_to_string(Z_REFVAL_P(zErrComment));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zErrComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zErrComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zErrComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerCopyRemoteFileEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcSource, int32_t szSource, const char * pcDestination, int32_t szDestination, int8_t Overwrite, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(6);
	zval * zSender;
	zval * zSource;
	zval * zDestination;
	zval * zOverwrite;
	zval * zErrCode;
	zval * zErrComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSource, 1);
	SB_ZVAL_STRINGL_DUP(zSource, pcSource, szSource);
	SB_EVENT_INIT_ZVAL(zDestination, 2);
	SB_ZVAL_STRINGL_DUP(zDestination, pcDestination, szDestination);
	SB_EVENT_INIT_ZVAL(zOverwrite, 3);
	ZVAL_BOOL(zOverwrite, (zend_bool)Overwrite);
	SB_EVENT_INIT_ZVAL_REF(zErrCode, 4);
	ZVAL_LONG(Z_REFVAL_P(zErrCode), (sb_zend_long)*ErrCode);
	SB_EVENT_INIT_ZVAL_REF(zErrComment, 5);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zErrComment), pcErrComment, *szErrComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 6, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSource);
	SB_EVENT_CLEAR_ZVAL(zDestination);
	SB_EVENT_CLEAR_ZVAL(zOverwrite);
	convert_to_long(Z_REFVAL_P(zErrCode));
	*ErrCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrCode));
	SB_EVENT_CLEAR_ZVAL(zErrCode);
	convert_to_string(Z_REFVAL_P(zErrComment));
	SBCheckError(SBSetEventReturnStringA(6, Z_STRVAL_P(Z_REFVAL_P(zErrComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zErrComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zErrComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerCopyRemoteDataEventRaw(void * _ObjectData, TObjectHandle Sender, void * ReadFromData, int64_t ReadFromOffset, void * WriteToData, int64_t WriteToOffset, int64_t DataLength, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(8);
	zval * zSender;
	zval * zReadFromData;
	zval * zReadFromOffset;
	zval * zWriteToData;
	zval * zWriteToOffset;
	zval * zDataLength;
	zval * zErrCode;
	zval * zErrComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zReadFromData, 1);
	SBInitPointerObject(zReadFromData, ReadFromData TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zReadFromOffset, 2);
	ZVAL_LONG(zReadFromOffset, (sb_zend_long)ReadFromOffset);
	SB_EVENT_INIT_ZVAL(zWriteToData, 3);
	SBInitPointerObject(zWriteToData, WriteToData TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zWriteToOffset, 4);
	ZVAL_LONG(zWriteToOffset, (sb_zend_long)WriteToOffset);
	SB_EVENT_INIT_ZVAL(zDataLength, 5);
	ZVAL_LONG(zDataLength, (sb_zend_long)DataLength);
	SB_EVENT_INIT_ZVAL_REF(zErrCode, 6);
	ZVAL_LONG(Z_REFVAL_P(zErrCode), (sb_zend_long)*ErrCode);
	SB_EVENT_INIT_ZVAL_REF(zErrComment, 7);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zErrComment), pcErrComment, *szErrComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 8, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zReadFromData);
	SB_EVENT_CLEAR_ZVAL(zReadFromOffset);
	SB_EVENT_CLEAR_ZVAL(zWriteToData);
	SB_EVENT_CLEAR_ZVAL(zWriteToOffset);
	SB_EVENT_CLEAR_ZVAL(zDataLength);
	convert_to_long(Z_REFVAL_P(zErrCode));
	*ErrCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrCode));
	SB_EVENT_CLEAR_ZVAL(zErrCode);
	convert_to_string(Z_REFVAL_P(zErrComment));
	SBCheckError(SBSetEventReturnStringA(8, Z_STRVAL_P(Z_REFVAL_P(zErrComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zErrComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zErrComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSFTPServerReturnPathEventRaw(void * _ObjectData, TObjectHandle Sender, char * pcPath, int32_t * szPath, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zPath;
	zval * zErrCode;
	zval * zErrComment;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zPath, 1);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zPath), pcPath, *szPath);
	SB_EVENT_INIT_ZVAL_REF(zErrCode, 2);
	ZVAL_LONG(Z_REFVAL_P(zErrCode), (sb_zend_long)*ErrCode);
	SB_EVENT_INIT_ZVAL_REF(zErrComment, 3);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zErrComment), pcErrComment, *szErrComment);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	convert_to_string(Z_REFVAL_P(zPath));
	SBCheckError(SBSetEventReturnStringA(2, Z_STRVAL_P(Z_REFVAL_P(zPath)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zPath))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zPath);
	convert_to_long(Z_REFVAL_P(zErrCode));
	*ErrCode = (int32_t)Z_LVAL_P(Z_REFVAL_P(zErrCode));
	SB_EVENT_CLEAR_ZVAL(zErrCode);
	convert_to_string(Z_REFVAL_P(zErrComment));
	SBCheckError(SBSetEventReturnStringA(4, Z_STRVAL_P(Z_REFVAL_P(zErrComment)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zErrComment))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zErrComment);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSftpFileOperationEventRaw(void * _ObjectData, TObjectHandle Sender, TSBSftpFileOperationRaw Operation, const char * pcRemotePath, int32_t szRemotePath, const char * pcLocalPath, int32_t szLocalPath, int8_t * Skip, int8_t * Cancel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(6);
	zval * zSender;
	zval * zOperation;
	zval * zRemotePath;
	zval * zLocalPath;
	zval * zSkip;
	zval * zCancel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOperation, 1);
	ZVAL_LONG(zOperation, (sb_zend_long)Operation);
	SB_EVENT_INIT_ZVAL(zRemotePath, 2);
	SB_ZVAL_STRINGL_DUP(zRemotePath, pcRemotePath, szRemotePath);
	SB_EVENT_INIT_ZVAL(zLocalPath, 3);
	SB_ZVAL_STRINGL_DUP(zLocalPath, pcLocalPath, szLocalPath);
	SB_EVENT_INIT_ZVAL_REF(zSkip, 4);
	ZVAL_BOOL(Z_REFVAL_P(zSkip), (zend_bool)*Skip);
	SB_EVENT_INIT_ZVAL_REF(zCancel, 5);
	ZVAL_BOOL(Z_REFVAL_P(zCancel), (zend_bool)*Cancel);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 6, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zOperation);
	SB_EVENT_CLEAR_ZVAL(zRemotePath);
	SB_EVENT_CLEAR_ZVAL(zLocalPath);
	convert_to_boolean(Z_REFVAL_P(zSkip));
	*Skip = (int8_t)SB_BVAL_P(Z_REFVAL_P(zSkip));
	SB_EVENT_CLEAR_ZVAL(zSkip);
	convert_to_boolean(Z_REFVAL_P(zCancel));
	*Cancel = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCancel));
	SB_EVENT_CLEAR_ZVAL(zCancel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElSftpFileOperationResultEventRaw(void * _ObjectData, TObjectHandle Sender, TSBSftpFileOperationRaw Operation, const char * pcRemotePath, int32_t szRemotePath, const char * pcLocalPath, int32_t szLocalPath, int32_t ErrorCode, const char * pcComment, int32_t szComment, int8_t * Cancel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(7);
	zval * zSender;
	zval * zOperation;
	zval * zRemotePath;
	zval * zLocalPath;
	zval * zErrorCode;
	zval * zComment;
	zval * zCancel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOperation, 1);
	ZVAL_LONG(zOperation, (sb_zend_long)Operation);
	SB_EVENT_INIT_ZVAL(zRemotePath, 2);
	SB_ZVAL_STRINGL_DUP(zRemotePath, pcRemotePath, szRemotePath);
	SB_EVENT_INIT_ZVAL(zLocalPath, 3);
	SB_ZVAL_STRINGL_DUP(zLocalPath, pcLocalPath, szLocalPath);
	SB_EVENT_INIT_ZVAL(zErrorCode, 4);
	ZVAL_LONG(zErrorCode, (sb_zend_long)ErrorCode);
	SB_EVENT_INIT_ZVAL(zComment, 5);
	SB_ZVAL_STRINGL_DUP(zComment, pcComment, szComment);
	SB_EVENT_INIT_ZVAL_REF(zCancel, 6);
	ZVAL_BOOL(Z_REFVAL_P(zCancel), (zend_bool)*Cancel);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 7, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zOperation);
	SB_EVENT_CLEAR_ZVAL(zRemotePath);
	SB_EVENT_CLEAR_ZVAL(zLocalPath);
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	SB_EVENT_CLEAR_ZVAL(zComment);
	convert_to_boolean(Z_REFVAL_P(zCancel));
	*Cancel = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCancel));
	SB_EVENT_CLEAR_ZVAL(zCancel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpFileNameChangeNeededEventRaw(void * _ObjectData, TObjectHandle Sender, char * pcFileName, int32_t * szFileName, int8_t * Force)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zFileName;
	zval * zForce;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zFileName, 1);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zFileName), pcFileName, *szFileName);
	SB_EVENT_INIT_ZVAL_REF(zForce, 2);
	ZVAL_BOOL(Z_REFVAL_P(zForce), (zend_bool)*Force);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	convert_to_string(Z_REFVAL_P(zFileName));
	SBCheckError(SBSetEventReturnStringA(2, Z_STRVAL_P(Z_REFVAL_P(zFileName)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zFileName))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zFileName);
	convert_to_boolean(Z_REFVAL_P(zForce));
	*Force = (int8_t)SB_BVAL_P(Z_REFVAL_P(zForce));
	SB_EVENT_CLEAR_ZVAL(zForce);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElSftpOperation_ce_ptr = NULL;

SB_PHP_METHOD(TSBSftpRequestInfo, __construct)
{
	if (ZEND_NUM_ARGS() == 0)
	{
		php_sbb_struct * intern = Z_SBSTRUCT_P(getThis());
		intern->data = emalloc(sizeof(TSBSftpRequestInfo));
		intern->len = sizeof(TSBSftpRequestInfo);
		memset(intern->data, 0, sizeof(TSBSftpRequestInfo));
		intern->ownData = 1;
	}
	else
		ZEND_WRONG_PARAM_COUNT();
}

SB_PHP_METHOD(TSBSftpRequestInfo, getSizeOf)
{
	if (ZEND_NUM_ARGS() > 0)
		ZEND_WRONG_PARAM_COUNT();

	RETURN_LONG(sizeof(TSBSftpRequestInfo));
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBBaseStruct_GetField, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBBaseStruct_SetField, 0, 0, 1)
	ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

SB_PHP_METHOD(TSBSftpRequestInfo, get_Id)
{
	SBStuctGetFieldUInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}

SB_PHP_METHOD(TSBSftpRequestInfo, set_Id)
{
	SBStuctSetFieldUInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}

SB_PHP_METHOD(TSBSftpRequestInfo, get_Request)
{
	SBStuctGetFieldUInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 4);
}

SB_PHP_METHOD(TSBSftpRequestInfo, set_Request)
{
	SBStuctSetFieldUInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 4);
}

SB_PHP_METHOD(TSBSftpRequestInfo, get_ExtType)
{
	SBStuctGetFieldStringA(INTERNAL_FUNCTION_PARAM_PASSTHRU, 8);
}

SB_PHP_METHOD(TSBSftpRequestInfo, set_ExtType)
{
	SBStuctSetFieldStringA(INTERNAL_FUNCTION_PARAM_PASSTHRU, 8);
}

zend_class_entry *TSBSftpRequestInfo_ce_ptr = NULL;

static zend_function_entry TSBSftpRequestInfo_methods[] = {
	PHP_ME(TSBSftpRequestInfo, __construct, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpRequestInfo, getSizeOf, NULL, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TSBSftpRequestInfo, get_Id, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpRequestInfo, set_Id, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpRequestInfo, get_Request, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpRequestInfo, set_Request, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpRequestInfo, get_ExtType, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpRequestInfo, set_ExtType, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TSBSftpRequestInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TSBSftpRequestInfo_ce_ptr != NULL)
		return;
	INIT_CLASS_ENTRY(ce, "TSBSftpRequestInfo", TSBSftpRequestInfo_methods);
	TSBSftpRequestInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseStruct_ce_ptr);
}

SB_PHP_METHOD(TSBSftpDataRequestInfo, __construct)
{
	if (ZEND_NUM_ARGS() == 0)
	{
		php_sbb_struct * intern = Z_SBSTRUCT_P(getThis());
		intern->data = emalloc(sizeof(TSBSftpDataRequestInfo));
		intern->len = sizeof(TSBSftpDataRequestInfo);
		memset(intern->data, 0, sizeof(TSBSftpDataRequestInfo));
		intern->ownData = 1;
	}
	else
		ZEND_WRONG_PARAM_COUNT();
}

SB_PHP_METHOD(TSBSftpDataRequestInfo, getSizeOf)
{
	if (ZEND_NUM_ARGS() > 0)
		ZEND_WRONG_PARAM_COUNT();

	RETURN_LONG(sizeof(TSBSftpDataRequestInfo));
}

SB_PHP_METHOD(TSBSftpDataRequestInfo, get_Id)
{
	SBStuctGetFieldUInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}

SB_PHP_METHOD(TSBSftpDataRequestInfo, set_Id)
{
	SBStuctSetFieldUInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}

SB_PHP_METHOD(TSBSftpDataRequestInfo, get_DataID)
{
	SBStuctGetFieldUInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 4);
}

SB_PHP_METHOD(TSBSftpDataRequestInfo, set_DataID)
{
	SBStuctSetFieldUInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 4);
}

SB_PHP_METHOD(TSBSftpDataRequestInfo, get_FileOffset)
{
#ifndef CPU64
	SBStuctGetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 16);
#else
	SBStuctGetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 20);
#endif
}

SB_PHP_METHOD(TSBSftpDataRequestInfo, set_FileOffset)
{
#ifndef CPU64
	SBStuctSetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 16);
#else
	SBStuctSetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 20);
#endif
}

SB_PHP_METHOD(TSBSftpDataRequestInfo, get_ChunkOffset)
{
#ifndef CPU64
	SBStuctGetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 24);
#else
	SBStuctGetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 28);
#endif
}

SB_PHP_METHOD(TSBSftpDataRequestInfo, set_ChunkOffset)
{
#ifndef CPU64
	SBStuctSetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 24);
#else
	SBStuctSetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 28);
#endif
}

SB_PHP_METHOD(TSBSftpDataRequestInfo, get_Size)
{
#ifndef CPU64
	SBStuctGetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 32);
#else
	SBStuctGetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 36);
#endif
}

SB_PHP_METHOD(TSBSftpDataRequestInfo, set_Size)
{
#ifndef CPU64
	SBStuctSetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 32);
#else
	SBStuctSetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 36);
#endif
}

zend_class_entry *TSBSftpDataRequestInfo_ce_ptr = NULL;

static zend_function_entry TSBSftpDataRequestInfo_methods[] = {
	PHP_ME(TSBSftpDataRequestInfo, __construct, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpDataRequestInfo, getSizeOf, NULL, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TSBSftpDataRequestInfo, get_Id, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpDataRequestInfo, set_Id, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpDataRequestInfo, get_DataID, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpDataRequestInfo, set_DataID, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpDataRequestInfo, get_FileOffset, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpDataRequestInfo, set_FileOffset, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpDataRequestInfo, get_ChunkOffset, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpDataRequestInfo, set_ChunkOffset, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpDataRequestInfo, get_Size, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpDataRequestInfo, set_Size, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TSBSftpDataRequestInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TSBSftpDataRequestInfo_ce_ptr != NULL)
		return;
	INIT_CLASS_ENTRY(ce, "TSBSftpDataRequestInfo", TSBSftpDataRequestInfo_methods);
	TSBSftpDataRequestInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseStruct_ce_ptr);
}

zend_class_entry *TSBSftpTransferBlockState_ce_ptr = NULL;

void SB_CALLBACK TSBSftpReadRequestEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, int32_t Size, uint32_t * Id)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zHandle;
	zval * zOffset;
	zval * zSize;
	zval * zId;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zHandle, 1);
	SB_ZVAL_STRINGL_DUP(zHandle, pHandle, szHandle);
	SB_EVENT_INIT_ZVAL(zOffset, 2);
	ZVAL_LONG(zOffset, (sb_zend_long)Offset);
	SB_EVENT_INIT_ZVAL(zSize, 3);
	ZVAL_LONG(zSize, (sb_zend_long)Size);
	SB_EVENT_INIT_ZVAL_REF(zId, 4);
	ZVAL_LONG(Z_REFVAL_P(zId), (sb_zend_long)*Id);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zHandle);
	SB_EVENT_CLEAR_ZVAL(zOffset);
	SB_EVENT_CLEAR_ZVAL(zSize);
	convert_to_long(Z_REFVAL_P(zId));
	*Id = (uint32_t)Z_LVAL_P(Z_REFVAL_P(zId));
	SB_EVENT_CLEAR_ZVAL(zId);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpWriteRequestEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pHandle[], int32_t szHandle, void * Buffer, int64_t Offset, int32_t Size, uint32_t * Id, int8_t Last)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(7);
	zval * zSender;
	zval * zHandle;
	zval * zBuffer;
	zval * zOffset;
	zval * zSize;
	zval * zId;
	zval * zLast;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zHandle, 1);
	SB_ZVAL_STRINGL_DUP(zHandle, pHandle, szHandle);
	SB_EVENT_INIT_ZVAL(zBuffer, 2);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOffset, 3);
	ZVAL_LONG(zOffset, (sb_zend_long)Offset);
	SB_EVENT_INIT_ZVAL(zSize, 4);
	ZVAL_LONG(zSize, (sb_zend_long)Size);
	SB_EVENT_INIT_ZVAL_REF(zId, 5);
	ZVAL_LONG(Z_REFVAL_P(zId), (sb_zend_long)*Id);
	SB_EVENT_INIT_ZVAL(zLast, 6);
	ZVAL_BOOL(zLast, (zend_bool)Last);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 7, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zHandle);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zOffset);
	SB_EVENT_CLEAR_ZVAL(zSize);
	convert_to_long(Z_REFVAL_P(zId));
	*Id = (uint32_t)Z_LVAL_P(Z_REFVAL_P(zId));
	SB_EVENT_CLEAR_ZVAL(zId);
	SB_EVENT_CLEAR_ZVAL(zLast);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSftpRemovalRequestEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcName, int32_t szName, uint32_t * Id)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zName;
	zval * zId;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zName, 1);
	SB_ZVAL_STRINGL_DUP(zName, pcName, szName);
	SB_EVENT_INIT_ZVAL_REF(zId, 2);
	ZVAL_LONG(Z_REFVAL_P(zId), (sb_zend_long)*Id);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zName);
	convert_to_long(Z_REFVAL_P(zId));
	*Id = (uint32_t)Z_LVAL_P(Z_REFVAL_P(zId));
	SB_EVENT_CLEAR_ZVAL(zId);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSBSftpExtendedAttribute_ce_ptr = NULL;

SB_PHP_METHOD(TSBSftpExtendedAttribute, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TSBSftpExtendedAttribute_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, AssignTo)
{
	zval *oDest;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDest, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TSBSftpExtendedAttribute_AssignTo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDest TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TSBSftpExtendedAttribute_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TSBSftpExtendedAttribute_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, Write)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TSBSftpExtendedAttribute_Write(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-193916653, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, get_ExtType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TSBSftpExtendedAttribute_get_ExtType(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1063142528, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, set_ExtType)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TSBSftpExtendedAttribute_set_ExtType(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, get_ExtData)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TSBSftpExtendedAttribute_get_ExtData(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-510910518, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, set_ExtData)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TSBSftpExtendedAttribute_set_ExtData(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, get_UseUTF8)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TSBSftpExtendedAttribute_get_UseUTF8(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, set_UseUTF8)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TSBSftpExtendedAttribute_set_UseUTF8(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, get_NoCharacterEncoding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TSBSftpExtendedAttribute_get_NoCharacterEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, set_NoCharacterEncoding)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TSBSftpExtendedAttribute_set_NoCharacterEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, get_LocalCharset)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TSBSftpExtendedAttribute_get_LocalCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1105578817, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, set_LocalCharset)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TSBSftpExtendedAttribute_set_LocalCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, get_RemoteCharset)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TSBSftpExtendedAttribute_get_RemoteCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-228878015, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, set_RemoteCharset)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TSBSftpExtendedAttribute_set_RemoteCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpExtendedAttribute, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TSBSftpExtendedAttribute_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_AssignTo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Dest, TPersistent, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_Write, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_get_ExtType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_set_ExtType, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_get_ExtData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_set_ExtData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_get_UseUTF8, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_set_UseUTF8, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_get_NoCharacterEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_set_NoCharacterEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_get_LocalCharset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_set_LocalCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_get_RemoteCharset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute_set_RemoteCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpExtendedAttribute___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TSBSftpExtendedAttribute_methods[] = {
	PHP_ME(TSBSftpExtendedAttribute, Assign, arginfo_TSBSftpExtendedAttribute_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, AssignTo, arginfo_TSBSftpExtendedAttribute_AssignTo, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, LoadFromBuffer, arginfo_TSBSftpExtendedAttribute_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, SaveToBuffer, arginfo_TSBSftpExtendedAttribute_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, Write, arginfo_TSBSftpExtendedAttribute_Write, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, get_ExtType, arginfo_TSBSftpExtendedAttribute_get_ExtType, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, set_ExtType, arginfo_TSBSftpExtendedAttribute_set_ExtType, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, get_ExtData, arginfo_TSBSftpExtendedAttribute_get_ExtData, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, set_ExtData, arginfo_TSBSftpExtendedAttribute_set_ExtData, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, get_UseUTF8, arginfo_TSBSftpExtendedAttribute_get_UseUTF8, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, set_UseUTF8, arginfo_TSBSftpExtendedAttribute_set_UseUTF8, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, get_NoCharacterEncoding, arginfo_TSBSftpExtendedAttribute_get_NoCharacterEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, set_NoCharacterEncoding, arginfo_TSBSftpExtendedAttribute_set_NoCharacterEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, get_LocalCharset, arginfo_TSBSftpExtendedAttribute_get_LocalCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, set_LocalCharset, arginfo_TSBSftpExtendedAttribute_set_LocalCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, get_RemoteCharset, arginfo_TSBSftpExtendedAttribute_get_RemoteCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, set_RemoteCharset, arginfo_TSBSftpExtendedAttribute_set_RemoteCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpExtendedAttribute, __construct, arginfo_TSBSftpExtendedAttribute___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TSBSftpExtendedAttribute(TSRMLS_D)
{
	zend_class_entry ce;
	if (TSBSftpExtendedAttribute_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TSBSftpExtendedAttribute", TSBSftpExtendedAttribute_methods);
	if (NULL == TPersistent_ce_ptr)
		Register_TPersistent(TSRMLS_C);
	TSBSftpExtendedAttribute_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPersistent_ce_ptr);
}

zend_class_entry *TElSftpExtendedReply_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpExtendedReply, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedReply_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, AssignTo)
{
	zval *oDest;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDest, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedReply_AssignTo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDest TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpExtendedReply_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpExtendedReply_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, Write)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSftpExtendedReply_Write(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-863790581, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, get_UseUTF8)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpExtendedReply_get_UseUTF8(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, set_UseUTF8)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedReply_set_UseUTF8(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, get_NoCharacterEncoding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpExtendedReply_get_NoCharacterEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, set_NoCharacterEncoding)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedReply_set_NoCharacterEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, get_LocalCharset)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpExtendedReply_get_LocalCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1290433932, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, set_LocalCharset)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedReply_set_LocalCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, get_RemoteCharset)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpExtendedReply_get_RemoteCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1299777558, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, set_RemoteCharset)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedReply_set_RemoteCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, get_ReplyData)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSftpExtendedReply_get_ReplyData(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1478958108, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, set_ReplyData)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSftpExtendedReply_set_ReplyData(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedReply, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpExtendedReply_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_AssignTo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Dest, TPersistent, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_Write, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_get_UseUTF8, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_set_UseUTF8, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_get_NoCharacterEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_set_NoCharacterEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_get_LocalCharset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_set_LocalCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_get_RemoteCharset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_set_RemoteCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_get_ReplyData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply_set_ReplyData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedReply___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpExtendedReply_methods[] = {
	PHP_ME(TElSftpExtendedReply, Assign, arginfo_TElSftpExtendedReply_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, AssignTo, arginfo_TElSftpExtendedReply_AssignTo, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, LoadFromBuffer, arginfo_TElSftpExtendedReply_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, SaveToBuffer, arginfo_TElSftpExtendedReply_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, Write, arginfo_TElSftpExtendedReply_Write, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, get_UseUTF8, arginfo_TElSftpExtendedReply_get_UseUTF8, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, set_UseUTF8, arginfo_TElSftpExtendedReply_set_UseUTF8, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, get_NoCharacterEncoding, arginfo_TElSftpExtendedReply_get_NoCharacterEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, set_NoCharacterEncoding, arginfo_TElSftpExtendedReply_set_NoCharacterEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, get_LocalCharset, arginfo_TElSftpExtendedReply_get_LocalCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, set_LocalCharset, arginfo_TElSftpExtendedReply_set_LocalCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, get_RemoteCharset, arginfo_TElSftpExtendedReply_get_RemoteCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, set_RemoteCharset, arginfo_TElSftpExtendedReply_set_RemoteCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, get_ReplyData, arginfo_TElSftpExtendedReply_get_ReplyData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, set_ReplyData, arginfo_TElSftpExtendedReply_set_ReplyData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedReply, __construct, arginfo_TElSftpExtendedReply___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpExtendedReply(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpExtendedReply_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpExtendedReply", TElSftpExtendedReply_methods);
	if (NULL == TPersistent_ce_ptr)
		Register_TPersistent(TSRMLS_C);
	TElSftpExtendedReply_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPersistent_ce_ptr);
}

zend_class_entry *TElSftpNewlineExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpNewlineExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpNewlineExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpNewlineExtension, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpNewlineExtension_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpNewlineExtension, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpNewlineExtension_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpNewlineExtension, get_Newline)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSftpNewlineExtension_get_Newline(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1312189200, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpNewlineExtension, set_Newline)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSftpNewlineExtension_set_Newline(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpNewlineExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpNewlineExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpNewlineExtension_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpNewlineExtension_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpNewlineExtension_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpNewlineExtension_get_Newline, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpNewlineExtension_set_Newline, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpNewlineExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpNewlineExtension_methods[] = {
	PHP_ME(TElSftpNewlineExtension, Assign, arginfo_TElSftpNewlineExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpNewlineExtension, LoadFromBuffer, arginfo_TElSftpNewlineExtension_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpNewlineExtension, SaveToBuffer, arginfo_TElSftpNewlineExtension_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpNewlineExtension, get_Newline, arginfo_TElSftpNewlineExtension_get_Newline, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpNewlineExtension, set_Newline, arginfo_TElSftpNewlineExtension_set_Newline, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpNewlineExtension, __construct, arginfo_TElSftpNewlineExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpNewlineExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpNewlineExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpNewlineExtension", TElSftpNewlineExtension_methods);
	if (NULL == TSBSftpExtendedAttribute_ce_ptr)
		Register_TSBSftpExtendedAttribute(TSRMLS_C);
	TElSftpNewlineExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBSftpExtendedAttribute_ce_ptr);
}

zend_class_entry *TElSftpVersionsExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpVersionsExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpVersionsExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionsExtension, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpVersionsExtension_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionsExtension, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpVersionsExtension_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionsExtension, get_Versions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpVersionsRaw fOutResultRaw = 0;
		SBCheckError(TElSftpVersionsExtension_get_Versions(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionsExtension, set_Versions)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSftpVersionsExtension_set_Versions(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpVersionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionsExtension, get_VersionsStr)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpVersionsExtension_get_VersionsStr(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1775132155, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionsExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpVersionsExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionsExtension_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionsExtension_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionsExtension_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionsExtension_get_Versions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionsExtension_set_Versions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionsExtension_get_VersionsStr, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionsExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpVersionsExtension_methods[] = {
	PHP_ME(TElSftpVersionsExtension, Assign, arginfo_TElSftpVersionsExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionsExtension, LoadFromBuffer, arginfo_TElSftpVersionsExtension_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionsExtension, SaveToBuffer, arginfo_TElSftpVersionsExtension_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionsExtension, get_Versions, arginfo_TElSftpVersionsExtension_get_Versions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionsExtension, set_Versions, arginfo_TElSftpVersionsExtension_set_Versions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionsExtension, get_VersionsStr, arginfo_TElSftpVersionsExtension_get_VersionsStr, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionsExtension, __construct, arginfo_TElSftpVersionsExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpVersionsExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpVersionsExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpVersionsExtension", TElSftpVersionsExtension_methods);
	if (NULL == TSBSftpExtendedAttribute_ce_ptr)
		Register_TSBSftpExtendedAttribute(TSRMLS_C);
	TElSftpVersionsExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBSftpExtendedAttribute_ce_ptr);
}

zend_class_entry *TElSftpFilenameTranslationExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpFilenameTranslationExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpFilenameTranslationExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFilenameTranslationExtension, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFilenameTranslationExtension_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFilenameTranslationExtension, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpFilenameTranslationExtension_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFilenameTranslationExtension, get_DoTranslate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFilenameTranslationExtension_get_DoTranslate(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFilenameTranslationExtension, set_DoTranslate)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpFilenameTranslationExtension_set_DoTranslate(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFilenameTranslationExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpFilenameTranslationExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFilenameTranslationExtension_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFilenameTranslationExtension_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFilenameTranslationExtension_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFilenameTranslationExtension_get_DoTranslate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFilenameTranslationExtension_set_DoTranslate, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFilenameTranslationExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpFilenameTranslationExtension_methods[] = {
	PHP_ME(TElSftpFilenameTranslationExtension, Assign, arginfo_TElSftpFilenameTranslationExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFilenameTranslationExtension, LoadFromBuffer, arginfo_TElSftpFilenameTranslationExtension_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFilenameTranslationExtension, SaveToBuffer, arginfo_TElSftpFilenameTranslationExtension_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFilenameTranslationExtension, get_DoTranslate, arginfo_TElSftpFilenameTranslationExtension_get_DoTranslate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFilenameTranslationExtension, set_DoTranslate, arginfo_TElSftpFilenameTranslationExtension_set_DoTranslate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFilenameTranslationExtension, __construct, arginfo_TElSftpFilenameTranslationExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpFilenameTranslationExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpFilenameTranslationExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpFilenameTranslationExtension", TElSftpFilenameTranslationExtension_methods);
	if (NULL == TSBSftpExtendedAttribute_ce_ptr)
		Register_TSBSftpExtendedAttribute(TSRMLS_C);
	TElSftpFilenameTranslationExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBSftpExtendedAttribute_ce_ptr);
}

zend_class_entry *TElSftpFilenameCharsetExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpFilenameCharsetExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpFilenameCharsetExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFilenameCharsetExtension, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFilenameCharsetExtension_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFilenameCharsetExtension, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpFilenameCharsetExtension_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFilenameCharsetExtension, get_Charset)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpFilenameCharsetExtension_get_Charset(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1727243874, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFilenameCharsetExtension, set_Charset)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpFilenameCharsetExtension_set_Charset(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFilenameCharsetExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpFilenameCharsetExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFilenameCharsetExtension_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFilenameCharsetExtension_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFilenameCharsetExtension_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFilenameCharsetExtension_get_Charset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFilenameCharsetExtension_set_Charset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFilenameCharsetExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpFilenameCharsetExtension_methods[] = {
	PHP_ME(TElSftpFilenameCharsetExtension, Assign, arginfo_TElSftpFilenameCharsetExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFilenameCharsetExtension, LoadFromBuffer, arginfo_TElSftpFilenameCharsetExtension_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFilenameCharsetExtension, SaveToBuffer, arginfo_TElSftpFilenameCharsetExtension_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFilenameCharsetExtension, get_Charset, arginfo_TElSftpFilenameCharsetExtension_get_Charset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFilenameCharsetExtension, set_Charset, arginfo_TElSftpFilenameCharsetExtension_set_Charset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFilenameCharsetExtension, __construct, arginfo_TElSftpFilenameCharsetExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpFilenameCharsetExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpFilenameCharsetExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpFilenameCharsetExtension", TElSftpFilenameCharsetExtension_methods);
	if (NULL == TSBSftpExtendedAttribute_ce_ptr)
		Register_TSBSftpExtendedAttribute(TSRMLS_C);
	TElSftpFilenameCharsetExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBSftpExtendedAttribute_ce_ptr);
}

zend_class_entry *TElSftpVersionSelectExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpVersionSelectExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpVersionSelectExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionSelectExtension, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpVersionSelectExtension_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionSelectExtension, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpVersionSelectExtension_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionSelectExtension, get_Version)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpVersionRaw fOutResultRaw = 0;
		SBCheckError(TElSftpVersionSelectExtension_get_Version(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionSelectExtension, set_Version)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSftpVersionSelectExtension_set_Version(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpVersionRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionSelectExtension, get_VersionInt)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSftpVersionSelectExtension_get_VersionInt(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionSelectExtension, set_VersionInt)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSftpVersionSelectExtension_set_VersionInt(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionSelectExtension, get_VersionStr)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpVersionSelectExtension_get_VersionStr(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(647061371, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionSelectExtension, set_VersionStr)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpVersionSelectExtension_set_VersionStr(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVersionSelectExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpVersionSelectExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionSelectExtension_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionSelectExtension_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionSelectExtension_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionSelectExtension_get_Version, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionSelectExtension_set_Version, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionSelectExtension_get_VersionInt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionSelectExtension_set_VersionInt, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionSelectExtension_get_VersionStr, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionSelectExtension_set_VersionStr, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVersionSelectExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpVersionSelectExtension_methods[] = {
	PHP_ME(TElSftpVersionSelectExtension, Assign, arginfo_TElSftpVersionSelectExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionSelectExtension, LoadFromBuffer, arginfo_TElSftpVersionSelectExtension_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionSelectExtension, SaveToBuffer, arginfo_TElSftpVersionSelectExtension_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionSelectExtension, get_Version, arginfo_TElSftpVersionSelectExtension_get_Version, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionSelectExtension, set_Version, arginfo_TElSftpVersionSelectExtension_set_Version, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionSelectExtension, get_VersionInt, arginfo_TElSftpVersionSelectExtension_get_VersionInt, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionSelectExtension, set_VersionInt, arginfo_TElSftpVersionSelectExtension_set_VersionInt, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionSelectExtension, get_VersionStr, arginfo_TElSftpVersionSelectExtension_get_VersionStr, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionSelectExtension, set_VersionStr, arginfo_TElSftpVersionSelectExtension_set_VersionStr, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVersionSelectExtension, __construct, arginfo_TElSftpVersionSelectExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpVersionSelectExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpVersionSelectExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpVersionSelectExtension", TElSftpVersionSelectExtension_methods);
	if (NULL == TSBSftpExtendedAttribute_ce_ptr)
		Register_TSBSftpExtendedAttribute(TSRMLS_C);
	TElSftpVersionSelectExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBSftpExtendedAttribute_ce_ptr);
}

zend_class_entry *TElSftpSupportedExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpSupportedExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, FillDefault)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_FillDefault(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpSupportedExtension_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, IsSupportedOpenBlockMode)
{
	sb_zend_long fMode;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fMode) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpSupportedExtension_IsSupportedOpenBlockMode(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpFileOpenAccessRaw)fMode, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, SetSupportedOpenBlockMode)
{
	sb_zend_long fMode;
	zend_bool bSupported;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &fMode, &bSupported) == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_SetSupportedOpenBlockMode(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpFileOpenAccessRaw)fMode, (int8_t)bSupported) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, IsSupportedBlockMode)
{
	sb_zend_long fMode;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fMode) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpSupportedExtension_IsSupportedBlockMode(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpFileOpenAccessRaw)fMode, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, SetSupportedBlockMode)
{
	sb_zend_long fMode;
	zend_bool bSupported;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &fMode, &bSupported) == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_SetSupportedBlockMode(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpFileOpenAccessRaw)fMode, (int8_t)bSupported) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, IsSupportedExtension)
{
	char *sExtName;
	sb_str_size sExtName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sExtName, &sExtName_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpSupportedExtension_IsSupportedExtension(SBGetObjectHandle(getThis() TSRMLS_CC), sExtName, (int32_t)sExtName_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, SetSupportedExtension)
{
	char *sExtName;
	sb_str_size sExtName_len;
	zend_bool bSupport;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sb", &sExtName, &sExtName_len, &bSupport) == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_SetSupportedExtension(SBGetObjectHandle(getThis() TSRMLS_CC), sExtName, (int32_t)sExtName_len, (int8_t)bSupport) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, IsSupportedAttrExtension)
{
	char *sExtName;
	sb_str_size sExtName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sExtName, &sExtName_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpSupportedExtension_IsSupportedAttrExtension(SBGetObjectHandle(getThis() TSRMLS_CC), sExtName, (int32_t)sExtName_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, SetSupportedAttrExtension)
{
	char *sExtName;
	sb_str_size sExtName_len;
	zend_bool bSupport;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sb", &sExtName, &sExtName_len, &bSupport) == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_SetSupportedAttrExtension(SBGetObjectHandle(getThis() TSRMLS_CC), sExtName, (int32_t)sExtName_len, (int8_t)bSupport) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, get_SupportedAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpAttributesRaw fOutResultRaw = 0;
		SBCheckError(TElSftpSupportedExtension_get_SupportedAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, set_SupportedAttributes)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_set_SupportedAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpAttributesRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, get_SupportedAttribBits)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpSupportedExtension_get_SupportedAttribBits(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, set_SupportedAttribBits)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_set_SupportedAttribBits(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, get_SupportedOpenModes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpFileOpenModesRaw fOutResultRaw = 0;
		SBCheckError(TElSftpSupportedExtension_get_SupportedOpenModes(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, set_SupportedOpenModes)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_set_SupportedOpenModes(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpFileOpenModesRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, get_SupportedAccessModes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpFileOpenAccessRaw fOutResultRaw = 0;
		SBCheckError(TElSftpSupportedExtension_get_SupportedAccessModes(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, set_SupportedAccessModes)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_set_SupportedAccessModes(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpFileOpenAccessRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, get_SupportedAccessMask)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpSupportedExtension_get_SupportedAccessMask(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, set_SupportedAccessMask)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_set_SupportedAccessMask(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, get_MaxReadSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpSupportedExtension_get_MaxReadSize(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, set_MaxReadSize)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_set_MaxReadSize(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, get_SupportedAttrExtensions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpSupportedExtension_get_SupportedAttrExtensions(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, get_SupportedExtensions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpSupportedExtension_get_SupportedExtensions(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, get_Version)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSftpSupportedExtension_get_Version(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, set_Version)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSftpSupportedExtension_set_Version(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSupportedExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpSupportedExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_FillDefault, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_IsSupportedOpenBlockMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Mode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_SetSupportedOpenBlockMode, 0, 0, 2)
	ZEND_ARG_INFO(0, Mode)
	ZEND_ARG_INFO(0, Supported)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_IsSupportedBlockMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Mode)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_SetSupportedBlockMode, 0, 0, 2)
	ZEND_ARG_INFO(0, Mode)
	ZEND_ARG_INFO(0, Supported)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_IsSupportedExtension, 0, 0, 1)
	ZEND_ARG_INFO(0, ExtName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_SetSupportedExtension, 0, 0, 2)
	ZEND_ARG_INFO(0, ExtName)
	ZEND_ARG_INFO(0, Support)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_IsSupportedAttrExtension, 0, 0, 1)
	ZEND_ARG_INFO(0, ExtName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_SetSupportedAttrExtension, 0, 0, 2)
	ZEND_ARG_INFO(0, ExtName)
	ZEND_ARG_INFO(0, Support)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_get_SupportedAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_set_SupportedAttributes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_get_SupportedAttribBits, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_set_SupportedAttribBits, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_get_SupportedOpenModes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_set_SupportedOpenModes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_get_SupportedAccessModes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_set_SupportedAccessModes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_get_SupportedAccessMask, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_set_SupportedAccessMask, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_get_MaxReadSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_set_MaxReadSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_get_SupportedAttrExtensions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_get_SupportedExtensions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_get_Version, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension_set_Version, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSupportedExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpSupportedExtension_methods[] = {
	PHP_ME(TElSftpSupportedExtension, Assign, arginfo_TElSftpSupportedExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, Clear, arginfo_TElSftpSupportedExtension_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, FillDefault, arginfo_TElSftpSupportedExtension_FillDefault, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, LoadFromBuffer, arginfo_TElSftpSupportedExtension_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, SaveToBuffer, arginfo_TElSftpSupportedExtension_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, IsSupportedOpenBlockMode, arginfo_TElSftpSupportedExtension_IsSupportedOpenBlockMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, SetSupportedOpenBlockMode, arginfo_TElSftpSupportedExtension_SetSupportedOpenBlockMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, IsSupportedBlockMode, arginfo_TElSftpSupportedExtension_IsSupportedBlockMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, SetSupportedBlockMode, arginfo_TElSftpSupportedExtension_SetSupportedBlockMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, IsSupportedExtension, arginfo_TElSftpSupportedExtension_IsSupportedExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, SetSupportedExtension, arginfo_TElSftpSupportedExtension_SetSupportedExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, IsSupportedAttrExtension, arginfo_TElSftpSupportedExtension_IsSupportedAttrExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, SetSupportedAttrExtension, arginfo_TElSftpSupportedExtension_SetSupportedAttrExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, get_SupportedAttributes, arginfo_TElSftpSupportedExtension_get_SupportedAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, set_SupportedAttributes, arginfo_TElSftpSupportedExtension_set_SupportedAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, get_SupportedAttribBits, arginfo_TElSftpSupportedExtension_get_SupportedAttribBits, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, set_SupportedAttribBits, arginfo_TElSftpSupportedExtension_set_SupportedAttribBits, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, get_SupportedOpenModes, arginfo_TElSftpSupportedExtension_get_SupportedOpenModes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, set_SupportedOpenModes, arginfo_TElSftpSupportedExtension_set_SupportedOpenModes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, get_SupportedAccessModes, arginfo_TElSftpSupportedExtension_get_SupportedAccessModes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, set_SupportedAccessModes, arginfo_TElSftpSupportedExtension_set_SupportedAccessModes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, get_SupportedAccessMask, arginfo_TElSftpSupportedExtension_get_SupportedAccessMask, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, set_SupportedAccessMask, arginfo_TElSftpSupportedExtension_set_SupportedAccessMask, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, get_MaxReadSize, arginfo_TElSftpSupportedExtension_get_MaxReadSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, set_MaxReadSize, arginfo_TElSftpSupportedExtension_set_MaxReadSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, get_SupportedAttrExtensions, arginfo_TElSftpSupportedExtension_get_SupportedAttrExtensions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, get_SupportedExtensions, arginfo_TElSftpSupportedExtension_get_SupportedExtensions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, get_Version, arginfo_TElSftpSupportedExtension_get_Version, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, set_Version, arginfo_TElSftpSupportedExtension_set_Version, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSupportedExtension, __construct, arginfo_TElSftpSupportedExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpSupportedExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpSupportedExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpSupportedExtension", TElSftpSupportedExtension_methods);
	if (NULL == TSBSftpExtendedAttribute_ce_ptr)
		Register_TSBSftpExtendedAttribute(TSRMLS_C);
	TElSftpSupportedExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBSftpExtendedAttribute_ce_ptr);
}

zend_class_entry *TElSftpVendorIDExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpVendorIDExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpVendorIDExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVendorIDExtension, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpVendorIDExtension_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVendorIDExtension, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpVendorIDExtension_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVendorIDExtension, get_VendorName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpVendorIDExtension_get_VendorName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1105471774, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVendorIDExtension, set_VendorName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpVendorIDExtension_set_VendorName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVendorIDExtension, get_ProductName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpVendorIDExtension_get_ProductName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(604862097, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVendorIDExtension, set_ProductName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpVendorIDExtension_set_ProductName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVendorIDExtension, get_ProductVersion)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpVendorIDExtension_get_ProductVersion(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1408359655, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVendorIDExtension, set_ProductVersion)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpVendorIDExtension_set_ProductVersion(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVendorIDExtension, get_BuildNumber)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpVendorIDExtension_get_BuildNumber(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVendorIDExtension, set_BuildNumber)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpVendorIDExtension_set_BuildNumber(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpVendorIDExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpVendorIDExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVendorIDExtension_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVendorIDExtension_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVendorIDExtension_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVendorIDExtension_get_VendorName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVendorIDExtension_set_VendorName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVendorIDExtension_get_ProductName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVendorIDExtension_set_ProductName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVendorIDExtension_get_ProductVersion, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVendorIDExtension_set_ProductVersion, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVendorIDExtension_get_BuildNumber, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVendorIDExtension_set_BuildNumber, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpVendorIDExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpVendorIDExtension_methods[] = {
	PHP_ME(TElSftpVendorIDExtension, Assign, arginfo_TElSftpVendorIDExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVendorIDExtension, LoadFromBuffer, arginfo_TElSftpVendorIDExtension_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVendorIDExtension, SaveToBuffer, arginfo_TElSftpVendorIDExtension_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVendorIDExtension, get_VendorName, arginfo_TElSftpVendorIDExtension_get_VendorName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVendorIDExtension, set_VendorName, arginfo_TElSftpVendorIDExtension_set_VendorName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVendorIDExtension, get_ProductName, arginfo_TElSftpVendorIDExtension_get_ProductName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVendorIDExtension, set_ProductName, arginfo_TElSftpVendorIDExtension_set_ProductName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVendorIDExtension, get_ProductVersion, arginfo_TElSftpVendorIDExtension_get_ProductVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVendorIDExtension, set_ProductVersion, arginfo_TElSftpVendorIDExtension_set_ProductVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVendorIDExtension, get_BuildNumber, arginfo_TElSftpVendorIDExtension_get_BuildNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVendorIDExtension, set_BuildNumber, arginfo_TElSftpVendorIDExtension_set_BuildNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpVendorIDExtension, __construct, arginfo_TElSftpVendorIDExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpVendorIDExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpVendorIDExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpVendorIDExtension", TElSftpVendorIDExtension_methods);
	if (NULL == TSBSftpExtendedAttribute_ce_ptr)
		Register_TSBSftpExtendedAttribute(TSRMLS_C);
	TElSftpVendorIDExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBSftpExtendedAttribute_ce_ptr);
}

zend_class_entry *TElSftpCheckFileExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpCheckFileExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpCheckFileExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpCheckFileExtension_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpCheckFileExtension_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, get_Name)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpCheckFileExtension_get_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(841278150, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, set_Name)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpCheckFileExtension_set_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, get_Handle)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSftpCheckFileExtension_get_Handle(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-501590528, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, set_Handle)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSftpCheckFileExtension_set_Handle(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, get_HashAlgorithms)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpCheckFileExtension_get_HashAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-265315002, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, set_HashAlgorithms)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpCheckFileExtension_set_HashAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, get_StartOffset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpCheckFileExtension_get_StartOffset(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, set_StartOffset)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpCheckFileExtension_set_StartOffset(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, get_DataLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpCheckFileExtension_get_DataLength(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, set_DataLength)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpCheckFileExtension_set_DataLength(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, get_BlockSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpCheckFileExtension_get_BlockSize(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, set_BlockSize)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpCheckFileExtension_set_BlockSize(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpCheckFileExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_get_Name, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_set_Name, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_get_Handle, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_set_Handle, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_get_HashAlgorithms, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_set_HashAlgorithms, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_get_StartOffset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_set_StartOffset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_get_DataLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_set_DataLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_get_BlockSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension_set_BlockSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpCheckFileExtension_methods[] = {
	PHP_ME(TElSftpCheckFileExtension, Assign, arginfo_TElSftpCheckFileExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, LoadFromBuffer, arginfo_TElSftpCheckFileExtension_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, SaveToBuffer, arginfo_TElSftpCheckFileExtension_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, get_Name, arginfo_TElSftpCheckFileExtension_get_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, set_Name, arginfo_TElSftpCheckFileExtension_set_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, get_Handle, arginfo_TElSftpCheckFileExtension_get_Handle, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, set_Handle, arginfo_TElSftpCheckFileExtension_set_Handle, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, get_HashAlgorithms, arginfo_TElSftpCheckFileExtension_get_HashAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, set_HashAlgorithms, arginfo_TElSftpCheckFileExtension_set_HashAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, get_StartOffset, arginfo_TElSftpCheckFileExtension_get_StartOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, set_StartOffset, arginfo_TElSftpCheckFileExtension_set_StartOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, get_DataLength, arginfo_TElSftpCheckFileExtension_get_DataLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, set_DataLength, arginfo_TElSftpCheckFileExtension_set_DataLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, get_BlockSize, arginfo_TElSftpCheckFileExtension_get_BlockSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, set_BlockSize, arginfo_TElSftpCheckFileExtension_set_BlockSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileExtension, __construct, arginfo_TElSftpCheckFileExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpCheckFileExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpCheckFileExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpCheckFileExtension", TElSftpCheckFileExtension_methods);
	if (NULL == TSBSftpExtendedAttribute_ce_ptr)
		Register_TSBSftpExtendedAttribute(TSRMLS_C);
	TElSftpCheckFileExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBSftpExtendedAttribute_ce_ptr);
}

zend_class_entry *TElSftpStatvfsExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpStatvfsExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpStatvfsExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatvfsExtension, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpStatvfsExtension_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatvfsExtension, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpStatvfsExtension_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatvfsExtension, get_Path)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpStatvfsExtension_get_Path(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2031745659, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatvfsExtension, set_Path)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpStatvfsExtension_set_Path(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatvfsExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpStatvfsExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatvfsExtension_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatvfsExtension_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatvfsExtension_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatvfsExtension_get_Path, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatvfsExtension_set_Path, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatvfsExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpStatvfsExtension_methods[] = {
	PHP_ME(TElSftpStatvfsExtension, Assign, arginfo_TElSftpStatvfsExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatvfsExtension, LoadFromBuffer, arginfo_TElSftpStatvfsExtension_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatvfsExtension, SaveToBuffer, arginfo_TElSftpStatvfsExtension_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatvfsExtension, get_Path, arginfo_TElSftpStatvfsExtension_get_Path, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatvfsExtension, set_Path, arginfo_TElSftpStatvfsExtension_set_Path, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatvfsExtension, __construct, arginfo_TElSftpStatvfsExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpStatvfsExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpStatvfsExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpStatvfsExtension", TElSftpStatvfsExtension_methods);
	if (NULL == TSBSftpExtendedAttribute_ce_ptr)
		Register_TSBSftpExtendedAttribute(TSRMLS_C);
	TElSftpStatvfsExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBSftpExtendedAttribute_ce_ptr);
}

zend_class_entry *TElSftpSpaceAvailableExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpSpaceAvailableExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpSpaceAvailableExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableExtension, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpSpaceAvailableExtension_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableExtension, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpSpaceAvailableExtension_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableExtension, get_Path)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpSpaceAvailableExtension_get_Path(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(476077082, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableExtension, set_Path)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpSpaceAvailableExtension_set_Path(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpSpaceAvailableExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableExtension_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableExtension_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableExtension_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableExtension_get_Path, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableExtension_set_Path, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpSpaceAvailableExtension_methods[] = {
	PHP_ME(TElSftpSpaceAvailableExtension, Assign, arginfo_TElSftpSpaceAvailableExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableExtension, LoadFromBuffer, arginfo_TElSftpSpaceAvailableExtension_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableExtension, SaveToBuffer, arginfo_TElSftpSpaceAvailableExtension_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableExtension, get_Path, arginfo_TElSftpSpaceAvailableExtension_get_Path, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableExtension, set_Path, arginfo_TElSftpSpaceAvailableExtension_set_Path, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableExtension, __construct, arginfo_TElSftpSpaceAvailableExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpSpaceAvailableExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpSpaceAvailableExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpSpaceAvailableExtension", TElSftpSpaceAvailableExtension_methods);
	if (NULL == TSBSftpExtendedAttribute_ce_ptr)
		Register_TSBSftpExtendedAttribute(TSRMLS_C);
	TElSftpSpaceAvailableExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBSftpExtendedAttribute_ce_ptr);
}

zend_class_entry *TElSftpHomeDirectoryExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpHomeDirectoryExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpHomeDirectoryExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpHomeDirectoryExtension, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpHomeDirectoryExtension_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpHomeDirectoryExtension, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpHomeDirectoryExtension_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpHomeDirectoryExtension, get_Username)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpHomeDirectoryExtension_get_Username(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1730193940, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpHomeDirectoryExtension, set_Username)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpHomeDirectoryExtension_set_Username(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpHomeDirectoryExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpHomeDirectoryExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpHomeDirectoryExtension_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpHomeDirectoryExtension_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpHomeDirectoryExtension_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpHomeDirectoryExtension_get_Username, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpHomeDirectoryExtension_set_Username, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpHomeDirectoryExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpHomeDirectoryExtension_methods[] = {
	PHP_ME(TElSftpHomeDirectoryExtension, Assign, arginfo_TElSftpHomeDirectoryExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpHomeDirectoryExtension, LoadFromBuffer, arginfo_TElSftpHomeDirectoryExtension_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpHomeDirectoryExtension, SaveToBuffer, arginfo_TElSftpHomeDirectoryExtension_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpHomeDirectoryExtension, get_Username, arginfo_TElSftpHomeDirectoryExtension_get_Username, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpHomeDirectoryExtension, set_Username, arginfo_TElSftpHomeDirectoryExtension_set_Username, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpHomeDirectoryExtension, __construct, arginfo_TElSftpHomeDirectoryExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpHomeDirectoryExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpHomeDirectoryExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpHomeDirectoryExtension", TElSftpHomeDirectoryExtension_methods);
	if (NULL == TSBSftpExtendedAttribute_ce_ptr)
		Register_TSBSftpExtendedAttribute(TSRMLS_C);
	TElSftpHomeDirectoryExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBSftpExtendedAttribute_ce_ptr);
}

zend_class_entry *TElSftpCopyFileExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpCopyFileExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpCopyFileExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyFileExtension, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpCopyFileExtension_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyFileExtension, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpCopyFileExtension_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyFileExtension, get_Source)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpCopyFileExtension_get_Source(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1422584766, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyFileExtension, set_Source)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpCopyFileExtension_set_Source(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyFileExtension, get_Destination)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpCopyFileExtension_get_Destination(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1210959653, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyFileExtension, set_Destination)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpCopyFileExtension_set_Destination(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyFileExtension, get_Overwrite)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpCopyFileExtension_get_Overwrite(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyFileExtension, set_Overwrite)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpCopyFileExtension_set_Overwrite(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyFileExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpCopyFileExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyFileExtension_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyFileExtension_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyFileExtension_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyFileExtension_get_Source, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyFileExtension_set_Source, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyFileExtension_get_Destination, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyFileExtension_set_Destination, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyFileExtension_get_Overwrite, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyFileExtension_set_Overwrite, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyFileExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpCopyFileExtension_methods[] = {
	PHP_ME(TElSftpCopyFileExtension, Assign, arginfo_TElSftpCopyFileExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyFileExtension, LoadFromBuffer, arginfo_TElSftpCopyFileExtension_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyFileExtension, SaveToBuffer, arginfo_TElSftpCopyFileExtension_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyFileExtension, get_Source, arginfo_TElSftpCopyFileExtension_get_Source, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyFileExtension, set_Source, arginfo_TElSftpCopyFileExtension_set_Source, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyFileExtension, get_Destination, arginfo_TElSftpCopyFileExtension_get_Destination, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyFileExtension, set_Destination, arginfo_TElSftpCopyFileExtension_set_Destination, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyFileExtension, get_Overwrite, arginfo_TElSftpCopyFileExtension_get_Overwrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyFileExtension, set_Overwrite, arginfo_TElSftpCopyFileExtension_set_Overwrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyFileExtension, __construct, arginfo_TElSftpCopyFileExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpCopyFileExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpCopyFileExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpCopyFileExtension", TElSftpCopyFileExtension_methods);
	if (NULL == TSBSftpExtendedAttribute_ce_ptr)
		Register_TSBSftpExtendedAttribute(TSRMLS_C);
	TElSftpCopyFileExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBSftpExtendedAttribute_ce_ptr);
}

zend_class_entry *TElSftpCopyDataExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpCopyDataExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpCopyDataExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyDataExtension, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpCopyDataExtension_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyDataExtension, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpCopyDataExtension_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyDataExtension, get_ReadHandle)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSftpCopyDataExtension_get_ReadHandle(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1100363186, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyDataExtension, set_ReadHandle)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSftpCopyDataExtension_set_ReadHandle(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyDataExtension, get_ReadOffset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpCopyDataExtension_get_ReadOffset(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyDataExtension, set_ReadOffset)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpCopyDataExtension_set_ReadOffset(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyDataExtension, get_WriteHandle)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSftpCopyDataExtension_get_WriteHandle(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1672586380, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyDataExtension, set_WriteHandle)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSftpCopyDataExtension_set_WriteHandle(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyDataExtension, get_WriteOffset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpCopyDataExtension_get_WriteOffset(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyDataExtension, set_WriteOffset)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpCopyDataExtension_set_WriteOffset(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyDataExtension, get_DataLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpCopyDataExtension_get_DataLength(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyDataExtension, set_DataLength)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpCopyDataExtension_set_DataLength(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCopyDataExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpCopyDataExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyDataExtension_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyDataExtension_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyDataExtension_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyDataExtension_get_ReadHandle, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyDataExtension_set_ReadHandle, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyDataExtension_get_ReadOffset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyDataExtension_set_ReadOffset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyDataExtension_get_WriteHandle, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyDataExtension_set_WriteHandle, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyDataExtension_get_WriteOffset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyDataExtension_set_WriteOffset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyDataExtension_get_DataLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyDataExtension_set_DataLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCopyDataExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpCopyDataExtension_methods[] = {
	PHP_ME(TElSftpCopyDataExtension, Assign, arginfo_TElSftpCopyDataExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyDataExtension, LoadFromBuffer, arginfo_TElSftpCopyDataExtension_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyDataExtension, SaveToBuffer, arginfo_TElSftpCopyDataExtension_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyDataExtension, get_ReadHandle, arginfo_TElSftpCopyDataExtension_get_ReadHandle, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyDataExtension, set_ReadHandle, arginfo_TElSftpCopyDataExtension_set_ReadHandle, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyDataExtension, get_ReadOffset, arginfo_TElSftpCopyDataExtension_get_ReadOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyDataExtension, set_ReadOffset, arginfo_TElSftpCopyDataExtension_set_ReadOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyDataExtension, get_WriteHandle, arginfo_TElSftpCopyDataExtension_get_WriteHandle, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyDataExtension, set_WriteHandle, arginfo_TElSftpCopyDataExtension_set_WriteHandle, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyDataExtension, get_WriteOffset, arginfo_TElSftpCopyDataExtension_get_WriteOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyDataExtension, set_WriteOffset, arginfo_TElSftpCopyDataExtension_set_WriteOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyDataExtension, get_DataLength, arginfo_TElSftpCopyDataExtension_get_DataLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyDataExtension, set_DataLength, arginfo_TElSftpCopyDataExtension_set_DataLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCopyDataExtension, __construct, arginfo_TElSftpCopyDataExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpCopyDataExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpCopyDataExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpCopyDataExtension", TElSftpCopyDataExtension_methods);
	if (NULL == TSBSftpExtendedAttribute_ce_ptr)
		Register_TSBSftpExtendedAttribute(TSRMLS_C);
	TElSftpCopyDataExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBSftpExtendedAttribute_ce_ptr);
}

zend_class_entry *TElSftpCheckFileReply_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpCheckFileReply, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpCheckFileReply_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileReply, AssignTo)
{
	zval *oDest;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDest, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpCheckFileReply_AssignTo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDest TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileReply, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpCheckFileReply_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileReply, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpCheckFileReply_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileReply, get_Hashes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpCheckFileReply_get_Hashes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElByteArrayList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileReply, get_RawHashes)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSftpCheckFileReply_get_RawHashes(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-349007334, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileReply, get_HashAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSftpCheckFileReply_get_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileReply, set_HashAlgorithm)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSftpCheckFileReply_set_HashAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileReply, get_HashSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSftpCheckFileReply_get_HashSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpCheckFileReply, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpCheckFileReply_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileReply_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileReply_AssignTo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Dest, TPersistent, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileReply_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileReply_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileReply_get_Hashes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileReply_get_RawHashes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileReply_get_HashAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileReply_set_HashAlgorithm, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileReply_get_HashSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpCheckFileReply___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpCheckFileReply_methods[] = {
	PHP_ME(TElSftpCheckFileReply, Assign, arginfo_TElSftpCheckFileReply_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileReply, AssignTo, arginfo_TElSftpCheckFileReply_AssignTo, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileReply, LoadFromBuffer, arginfo_TElSftpCheckFileReply_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileReply, SaveToBuffer, arginfo_TElSftpCheckFileReply_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileReply, get_Hashes, arginfo_TElSftpCheckFileReply_get_Hashes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileReply, get_RawHashes, arginfo_TElSftpCheckFileReply_get_RawHashes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileReply, get_HashAlgorithm, arginfo_TElSftpCheckFileReply_get_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileReply, set_HashAlgorithm, arginfo_TElSftpCheckFileReply_set_HashAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileReply, get_HashSize, arginfo_TElSftpCheckFileReply_get_HashSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpCheckFileReply, __construct, arginfo_TElSftpCheckFileReply___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpCheckFileReply(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpCheckFileReply_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpCheckFileReply", TElSftpCheckFileReply_methods);
	if (NULL == TElSftpExtendedReply_ce_ptr)
		Register_TElSftpExtendedReply(TSRMLS_C);
	TElSftpCheckFileReply_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSftpExtendedReply_ce_ptr);
}

zend_class_entry *TElSftpSpaceAvailableReply_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpSpaceAvailableReply, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpSpaceAvailableReply_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableReply, AssignTo)
{
	zval *oDest;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDest, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpSpaceAvailableReply_AssignTo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDest TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableReply, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpSpaceAvailableReply_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableReply, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpSpaceAvailableReply_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableReply, get_BytesOnDevice)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpSpaceAvailableReply_get_BytesOnDevice(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableReply, set_BytesOnDevice)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpSpaceAvailableReply_set_BytesOnDevice(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableReply, get_UnusedBytesOnDevice)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpSpaceAvailableReply_get_UnusedBytesOnDevice(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableReply, set_UnusedBytesOnDevice)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpSpaceAvailableReply_set_UnusedBytesOnDevice(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableReply, get_BytesAvailableToUser)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpSpaceAvailableReply_get_BytesAvailableToUser(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableReply, set_BytesAvailableToUser)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpSpaceAvailableReply_set_BytesAvailableToUser(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableReply, get_UnusedBytesAvailableToUser)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpSpaceAvailableReply_get_UnusedBytesAvailableToUser(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableReply, set_UnusedBytesAvailableToUser)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpSpaceAvailableReply_set_UnusedBytesAvailableToUser(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableReply, get_BytesPerAllocationUnit)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpSpaceAvailableReply_get_BytesPerAllocationUnit(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableReply, set_BytesPerAllocationUnit)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpSpaceAvailableReply_set_BytesPerAllocationUnit(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpSpaceAvailableReply, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpSpaceAvailableReply_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply_AssignTo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Dest, TPersistent, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply_get_BytesOnDevice, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply_set_BytesOnDevice, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply_get_UnusedBytesOnDevice, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply_set_UnusedBytesOnDevice, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply_get_BytesAvailableToUser, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply_set_BytesAvailableToUser, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply_get_UnusedBytesAvailableToUser, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply_set_UnusedBytesAvailableToUser, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply_get_BytesPerAllocationUnit, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply_set_BytesPerAllocationUnit, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpSpaceAvailableReply___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpSpaceAvailableReply_methods[] = {
	PHP_ME(TElSftpSpaceAvailableReply, Assign, arginfo_TElSftpSpaceAvailableReply_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableReply, AssignTo, arginfo_TElSftpSpaceAvailableReply_AssignTo, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableReply, LoadFromBuffer, arginfo_TElSftpSpaceAvailableReply_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableReply, SaveToBuffer, arginfo_TElSftpSpaceAvailableReply_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableReply, get_BytesOnDevice, arginfo_TElSftpSpaceAvailableReply_get_BytesOnDevice, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableReply, set_BytesOnDevice, arginfo_TElSftpSpaceAvailableReply_set_BytesOnDevice, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableReply, get_UnusedBytesOnDevice, arginfo_TElSftpSpaceAvailableReply_get_UnusedBytesOnDevice, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableReply, set_UnusedBytesOnDevice, arginfo_TElSftpSpaceAvailableReply_set_UnusedBytesOnDevice, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableReply, get_BytesAvailableToUser, arginfo_TElSftpSpaceAvailableReply_get_BytesAvailableToUser, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableReply, set_BytesAvailableToUser, arginfo_TElSftpSpaceAvailableReply_set_BytesAvailableToUser, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableReply, get_UnusedBytesAvailableToUser, arginfo_TElSftpSpaceAvailableReply_get_UnusedBytesAvailableToUser, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableReply, set_UnusedBytesAvailableToUser, arginfo_TElSftpSpaceAvailableReply_set_UnusedBytesAvailableToUser, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableReply, get_BytesPerAllocationUnit, arginfo_TElSftpSpaceAvailableReply_get_BytesPerAllocationUnit, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableReply, set_BytesPerAllocationUnit, arginfo_TElSftpSpaceAvailableReply_set_BytesPerAllocationUnit, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpSpaceAvailableReply, __construct, arginfo_TElSftpSpaceAvailableReply___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpSpaceAvailableReply(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpSpaceAvailableReply_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpSpaceAvailableReply", TElSftpSpaceAvailableReply_methods);
	if (NULL == TElSftpExtendedReply_ce_ptr)
		Register_TElSftpExtendedReply(TSRMLS_C);
	TElSftpSpaceAvailableReply_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSftpExtendedReply_ce_ptr);
}

zend_class_entry *TElSftpStatVFSReply_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpStatVFSReply, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpStatVFSReply_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, AssignTo)
{
	zval *oDest;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDest, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpStatVFSReply_AssignTo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDest TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, LoadFromBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpStatVFSReply_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, SaveToBuffer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpStatVFSReply_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, get_BSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElSftpStatVFSReply_get_BSize(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, set_BSize)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElSftpStatVFSReply_set_BSize(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, get_FRSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElSftpStatVFSReply_get_FRSize(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, set_FRSize)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElSftpStatVFSReply_set_FRSize(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, get_Blocks)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElSftpStatVFSReply_get_Blocks(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, set_Blocks)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElSftpStatVFSReply_set_Blocks(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, get_BFree)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElSftpStatVFSReply_get_BFree(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, set_BFree)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElSftpStatVFSReply_set_BFree(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, get_BAvail)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElSftpStatVFSReply_get_BAvail(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, set_BAvail)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElSftpStatVFSReply_set_BAvail(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, get_Files)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElSftpStatVFSReply_get_Files(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, set_Files)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElSftpStatVFSReply_set_Files(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, get_FFree)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElSftpStatVFSReply_get_FFree(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, set_FFree)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElSftpStatVFSReply_set_FFree(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, get_FAvail)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElSftpStatVFSReply_get_FAvail(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, set_FAvail)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElSftpStatVFSReply_set_FAvail(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, get_FSid)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElSftpStatVFSReply_get_FSid(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, set_FSid)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElSftpStatVFSReply_set_FSid(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, get_Flag)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElSftpStatVFSReply_get_Flag(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, set_Flag)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElSftpStatVFSReply_set_Flag(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, get_Namemax)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint64_t u8OutResultRaw = 0;
		SBCheckError(TElSftpStatVFSReply_get_Namemax(SBGetObjectHandle(getThis() TSRMLS_CC), &u8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, set_Namemax)
{
	sb_zend_long u8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u8Value) == SUCCESS)
	{
		SBCheckError(TElSftpStatVFSReply_set_Namemax(SBGetObjectHandle(getThis() TSRMLS_CC), (uint64_t)u8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpStatVFSReply, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpStatVFSReply_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_AssignTo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Dest, TPersistent, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_LoadFromBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_SaveToBuffer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_get_BSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_set_BSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_get_FRSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_set_FRSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_get_Blocks, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_set_Blocks, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_get_BFree, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_set_BFree, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_get_BAvail, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_set_BAvail, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_get_Files, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_set_Files, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_get_FFree, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_set_FFree, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_get_FAvail, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_set_FAvail, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_get_FSid, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_set_FSid, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_get_Flag, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_set_Flag, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_get_Namemax, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply_set_Namemax, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpStatVFSReply___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpStatVFSReply_methods[] = {
	PHP_ME(TElSftpStatVFSReply, Assign, arginfo_TElSftpStatVFSReply_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, AssignTo, arginfo_TElSftpStatVFSReply_AssignTo, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, LoadFromBuffer, arginfo_TElSftpStatVFSReply_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, SaveToBuffer, arginfo_TElSftpStatVFSReply_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, get_BSize, arginfo_TElSftpStatVFSReply_get_BSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, set_BSize, arginfo_TElSftpStatVFSReply_set_BSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, get_FRSize, arginfo_TElSftpStatVFSReply_get_FRSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, set_FRSize, arginfo_TElSftpStatVFSReply_set_FRSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, get_Blocks, arginfo_TElSftpStatVFSReply_get_Blocks, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, set_Blocks, arginfo_TElSftpStatVFSReply_set_Blocks, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, get_BFree, arginfo_TElSftpStatVFSReply_get_BFree, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, set_BFree, arginfo_TElSftpStatVFSReply_set_BFree, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, get_BAvail, arginfo_TElSftpStatVFSReply_get_BAvail, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, set_BAvail, arginfo_TElSftpStatVFSReply_set_BAvail, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, get_Files, arginfo_TElSftpStatVFSReply_get_Files, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, set_Files, arginfo_TElSftpStatVFSReply_set_Files, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, get_FFree, arginfo_TElSftpStatVFSReply_get_FFree, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, set_FFree, arginfo_TElSftpStatVFSReply_set_FFree, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, get_FAvail, arginfo_TElSftpStatVFSReply_get_FAvail, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, set_FAvail, arginfo_TElSftpStatVFSReply_set_FAvail, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, get_FSid, arginfo_TElSftpStatVFSReply_get_FSid, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, set_FSid, arginfo_TElSftpStatVFSReply_set_FSid, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, get_Flag, arginfo_TElSftpStatVFSReply_get_Flag, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, set_Flag, arginfo_TElSftpStatVFSReply_set_Flag, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, get_Namemax, arginfo_TElSftpStatVFSReply_get_Namemax, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, set_Namemax, arginfo_TElSftpStatVFSReply_set_Namemax, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpStatVFSReply, __construct, arginfo_TElSftpStatVFSReply___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpStatVFSReply(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpStatVFSReply_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpStatVFSReply", TElSftpStatVFSReply_methods);
	if (NULL == TElSftpExtendedReply_ce_ptr)
		Register_TElSftpExtendedReply(TSRMLS_C);
	TElSftpStatVFSReply_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSftpExtendedReply_ce_ptr);
}

zend_class_entry *TSBSftpACE_ce_ptr = NULL;

SB_PHP_METHOD(TSBSftpACE, get_ACEType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TSBSftpACE_get_ACEType(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpACE, set_ACEType)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TSBSftpACE_set_ACEType(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpACE, get_ACEFlags)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TSBSftpACE_get_ACEFlags(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpACE, set_ACEFlags)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TSBSftpACE_set_ACEFlags(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpACE, get_ACEMask)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TSBSftpACE_get_ACEMask(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpACE, set_ACEMask)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TSBSftpACE_set_ACEMask(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpACE, get_Who)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TSBSftpACE_get_Who(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(2070958753, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpACE, set_Who)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TSBSftpACE_set_Who(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TSBSftpACE, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TSBSftpACE_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpACE_get_ACEType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpACE_set_ACEType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpACE_get_ACEFlags, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpACE_set_ACEFlags, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpACE_get_ACEMask, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpACE_set_ACEMask, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpACE_get_Who, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpACE_set_Who, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpACE___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TSBSftpACE_methods[] = {
	PHP_ME(TSBSftpACE, get_ACEType, arginfo_TSBSftpACE_get_ACEType, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpACE, set_ACEType, arginfo_TSBSftpACE_set_ACEType, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpACE, get_ACEFlags, arginfo_TSBSftpACE_get_ACEFlags, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpACE, set_ACEFlags, arginfo_TSBSftpACE_set_ACEFlags, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpACE, get_ACEMask, arginfo_TSBSftpACE_get_ACEMask, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpACE, set_ACEMask, arginfo_TSBSftpACE_set_ACEMask, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpACE, get_Who, arginfo_TSBSftpACE_get_Who, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpACE, set_Who, arginfo_TSBSftpACE_set_Who, ZEND_ACC_PUBLIC)
	PHP_ME(TSBSftpACE, __construct, arginfo_TSBSftpACE___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TSBSftpACE(TSRMLS_D)
{
	zend_class_entry ce;
	if (TSBSftpACE_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TSBSftpACE", TSBSftpACE_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TSBSftpACE_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSftpExtendedProperties_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpExtendedProperties, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, AssignTo)
{
	zval *oDest;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDest, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_AssignTo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDest TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, RequestAttributesByVersion)
{
	sb_zend_long l4Version;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Version) == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpExtendedProperties_RequestAttributesByVersion(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Version, &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_DesiredAccess)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpExtendedProperties_get_DesiredAccess(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, set_DesiredAccess)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_set_DesiredAccess(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_AutoAdjustDesiredAccess)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpExtendedProperties_get_AutoAdjustDesiredAccess(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, set_AutoAdjustDesiredAccess)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_set_AutoAdjustDesiredAccess(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_RenameFlags)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpRenameFlagsRaw fOutResultRaw = 0;
		SBCheckError(TElSftpExtendedProperties_get_RenameFlags(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, set_RenameFlags)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_set_RenameFlags(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpRenameFlagsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_RenameFlagsUInt32)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpExtendedProperties_get_RenameFlagsUInt32(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_RequestAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpAttributesRaw fOutResultRaw = 0;
		SBCheckError(TElSftpExtendedProperties_get_RequestAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, set_RequestAttributes)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_set_RequestAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpAttributesRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_RequestAttributesUInt32)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpExtendedProperties_get_RequestAttributesUInt32(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_AutoAdjustRequestAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpExtendedProperties_get_AutoAdjustRequestAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, set_AutoAdjustRequestAttributes)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_set_AutoAdjustRequestAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_SupportedAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpExtendedProperties_get_SupportedAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, set_SupportedAvailable)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_set_SupportedAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_SupportedExtension)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpExtendedProperties_get_SupportedExtension(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSftpSupportedExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, set_SupportedExtension)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElSftpSupportedExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_set_SupportedExtension(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSftpSupportedExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_NewlineAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpExtendedProperties_get_NewlineAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, set_NewlineAvailable)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_set_NewlineAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_NewlineExtension)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpExtendedProperties_get_NewlineExtension(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSftpNewlineExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, set_NewlineExtension)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElSftpNewlineExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_set_NewlineExtension(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSftpNewlineExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_VersionsAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpExtendedProperties_get_VersionsAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, set_VersionsAvailable)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_set_VersionsAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_VersionsExtension)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpExtendedProperties_get_VersionsExtension(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSftpVersionsExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, set_VersionsExtension)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElSftpVersionsExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_set_VersionsExtension(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSftpVersionsExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_VendorIDAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpExtendedProperties_get_VendorIDAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, set_VendorIDAvailable)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_set_VendorIDAvailable(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_VendorIDExtension)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpExtendedProperties_get_VendorIDExtension(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSftpVendorIDExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, set_VendorIDExtension)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElSftpVendorIDExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_set_VendorIDExtension(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSftpVendorIDExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, get_FilenameCharset)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpExtendedProperties_get_FilenameCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-94500820, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, set_FilenameCharset)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpExtendedProperties_set_FilenameCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpExtendedProperties, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpExtendedProperties_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_AssignTo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Dest, TPersistent, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_RequestAttributesByVersion, 0, 0, 1)
	ZEND_ARG_INFO(0, Version)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_DesiredAccess, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_set_DesiredAccess, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_AutoAdjustDesiredAccess, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_set_AutoAdjustDesiredAccess, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_RenameFlags, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_set_RenameFlags, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_RenameFlagsUInt32, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_RequestAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_set_RequestAttributes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_RequestAttributesUInt32, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_AutoAdjustRequestAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_set_AutoAdjustRequestAttributes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_SupportedAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_set_SupportedAvailable, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_SupportedExtension, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_set_SupportedExtension, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElSftpSupportedExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_NewlineAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_set_NewlineAvailable, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_NewlineExtension, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_set_NewlineExtension, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElSftpNewlineExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_VersionsAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_set_VersionsAvailable, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_VersionsExtension, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_set_VersionsExtension, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElSftpVersionsExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_VendorIDAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_set_VendorIDAvailable, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_VendorIDExtension, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_set_VendorIDExtension, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElSftpVendorIDExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_get_FilenameCharset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties_set_FilenameCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpExtendedProperties___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpExtendedProperties_methods[] = {
	PHP_ME(TElSftpExtendedProperties, Assign, arginfo_TElSftpExtendedProperties_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, AssignTo, arginfo_TElSftpExtendedProperties_AssignTo, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, RequestAttributesByVersion, arginfo_TElSftpExtendedProperties_RequestAttributesByVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_DesiredAccess, arginfo_TElSftpExtendedProperties_get_DesiredAccess, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, set_DesiredAccess, arginfo_TElSftpExtendedProperties_set_DesiredAccess, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_AutoAdjustDesiredAccess, arginfo_TElSftpExtendedProperties_get_AutoAdjustDesiredAccess, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, set_AutoAdjustDesiredAccess, arginfo_TElSftpExtendedProperties_set_AutoAdjustDesiredAccess, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_RenameFlags, arginfo_TElSftpExtendedProperties_get_RenameFlags, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, set_RenameFlags, arginfo_TElSftpExtendedProperties_set_RenameFlags, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_RenameFlagsUInt32, arginfo_TElSftpExtendedProperties_get_RenameFlagsUInt32, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_RequestAttributes, arginfo_TElSftpExtendedProperties_get_RequestAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, set_RequestAttributes, arginfo_TElSftpExtendedProperties_set_RequestAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_RequestAttributesUInt32, arginfo_TElSftpExtendedProperties_get_RequestAttributesUInt32, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_AutoAdjustRequestAttributes, arginfo_TElSftpExtendedProperties_get_AutoAdjustRequestAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, set_AutoAdjustRequestAttributes, arginfo_TElSftpExtendedProperties_set_AutoAdjustRequestAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_SupportedAvailable, arginfo_TElSftpExtendedProperties_get_SupportedAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, set_SupportedAvailable, arginfo_TElSftpExtendedProperties_set_SupportedAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_SupportedExtension, arginfo_TElSftpExtendedProperties_get_SupportedExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, set_SupportedExtension, arginfo_TElSftpExtendedProperties_set_SupportedExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_NewlineAvailable, arginfo_TElSftpExtendedProperties_get_NewlineAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, set_NewlineAvailable, arginfo_TElSftpExtendedProperties_set_NewlineAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_NewlineExtension, arginfo_TElSftpExtendedProperties_get_NewlineExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, set_NewlineExtension, arginfo_TElSftpExtendedProperties_set_NewlineExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_VersionsAvailable, arginfo_TElSftpExtendedProperties_get_VersionsAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, set_VersionsAvailable, arginfo_TElSftpExtendedProperties_set_VersionsAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_VersionsExtension, arginfo_TElSftpExtendedProperties_get_VersionsExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, set_VersionsExtension, arginfo_TElSftpExtendedProperties_set_VersionsExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_VendorIDAvailable, arginfo_TElSftpExtendedProperties_get_VendorIDAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, set_VendorIDAvailable, arginfo_TElSftpExtendedProperties_set_VendorIDAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_VendorIDExtension, arginfo_TElSftpExtendedProperties_get_VendorIDExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, set_VendorIDExtension, arginfo_TElSftpExtendedProperties_set_VendorIDExtension, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, get_FilenameCharset, arginfo_TElSftpExtendedProperties_get_FilenameCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, set_FilenameCharset, arginfo_TElSftpExtendedProperties_set_FilenameCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpExtendedProperties, __construct, arginfo_TElSftpExtendedProperties___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpExtendedProperties(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpExtendedProperties_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpExtendedProperties", TElSftpExtendedProperties_methods);
	if (NULL == TPersistent_ce_ptr)
		Register_TPersistent(TSRMLS_C);
	TElSftpExtendedProperties_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPersistent_ce_ptr);
}

zend_class_entry *TElSftpFileAttributes_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpFileAttributes, CopyTo)
{
	zval *odst;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &odst, TElSftpFileAttributes_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_CopyTo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(odst TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSftpFileAttributes)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, SaveToBuffer)
{
	sb_zend_long l4Ver;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Ver) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSftpFileAttributes_SaveToBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Ver, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-913241863, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, LoadFromBuffer)
{
	sb_zend_long l4Size;
	sb_zend_long l4Ver;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zpBuffer, &l4Size, &l4Ver) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSftpFileAttributes_LoadFromBuffer(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, (int32_t)l4Ver, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, AddACE)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_AddACE(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, RemoveACE)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_RemoveACE(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, ClearACEs)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_ClearACEs(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, AddExtendedAttribute)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_AddExtendedAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, RemoveExtendedAttribute)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_RemoveExtendedAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, ClearExtendedAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_ClearExtendedAttributes(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, IsAttributeIncluded)
{
	sb_zend_long fAttribute;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fAttribute) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_IsAttributeIncluded(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpAttributeRaw)fAttribute, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_Size)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_Size(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_Size)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_Size(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_AllocationSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_AllocationSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_AllocationSize)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_AllocationSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_UID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_UID(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_UID)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_UID(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_GID)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_GID(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_GID)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_GID(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_Owner)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSftpFileAttributes_get_Owner(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1182897418, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_Owner)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSftpFileAttributes_set_Owner(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_Group)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSftpFileAttributes_get_Group(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(467585103, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_Group)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSftpFileAttributes_set_Group(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_CTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_CTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_CTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_CTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_CATime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_CATime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_CATime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_CATime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_FileType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpFileTypeRaw fOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_FileType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_FileType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_FileType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpFileTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_ATime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_ATime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_ATime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_ATime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_MTime)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_MTime(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_MTime)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_MTime(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_ExtendedAttributeCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_ExtendedAttributeCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_ExtendedAttributes)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpFileAttributes_get_ExtendedAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TSBSftpExtendedAttribute_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_IncludedAttributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpAttributesRaw fOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_IncludedAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_IncludedAttributes)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_IncludedAttributes(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpAttributesRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_UserRead)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_UserRead(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_UserRead)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_UserRead(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_UserWrite)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_UserWrite(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_UserWrite)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_UserWrite(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_UserExecute)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_UserExecute(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_UserExecute)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_UserExecute(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_GroupRead)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_GroupRead(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_GroupRead)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_GroupRead(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_GroupWrite)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_GroupWrite(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_GroupWrite)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_GroupWrite(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_GroupExecute)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_GroupExecute(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_GroupExecute)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_GroupExecute(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_OtherRead)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_OtherRead(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_OtherRead)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_OtherRead(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_OtherWrite)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_OtherWrite(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_OtherWrite)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_OtherWrite(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_OtherExecute)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_OtherExecute(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_OtherExecute)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_OtherExecute(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_UIDBit)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_UIDBit(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_UIDBit)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_UIDBit(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_GIDBit)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_GIDBit(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_GIDBit)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_GIDBit(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_StickyBit)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_StickyBit(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_StickyBit)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_StickyBit(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_Directory)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_Directory(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_Directory)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_Directory(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_ACLFlags)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_ACLFlags(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_ACLFlags)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_ACLFlags(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_ACECount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_ACECount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_ACEs)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpFileAttributes_get_ACEs(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TSBSftpACE_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_ATimeInt64)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_ATimeInt64(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_ATimeInt64)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_ATimeInt64(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_MTimeInt64)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_MTimeInt64(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_MTimeInt64)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_MTimeInt64(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_CTimeInt64)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_CTimeInt64(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_CTimeInt64)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_CTimeInt64(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_CATimeInt64)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_CATimeInt64(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_CATimeInt64)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_CATimeInt64(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_ATimeCardinal)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_ATimeCardinal(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_ATimeCardinal)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_ATimeCardinal(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_MTimeCardinal)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_MTimeCardinal(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_MTimeCardinal)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_MTimeCardinal(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_CTimeCardinal)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_CTimeCardinal(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_CTimeCardinal)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_CTimeCardinal(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_CATimeCardinal)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_CATimeCardinal(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_CATimeCardinal)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_CATimeCardinal(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_ATimeSeconds)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_ATimeSeconds(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_MTimeSeconds)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_MTimeSeconds(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_CTimeSeconds)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_CTimeSeconds(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_CATimeSeconds)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_CATimeSeconds(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_ATimeMS)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_ATimeMS(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_ATimeMS)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_ATimeMS(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_CTimeMS)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_CTimeMS(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_CTimeMS)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_CTimeMS(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_CATimeMS)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_CATimeMS(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_CATimeMS)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_CATimeMS(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_MTimeMS)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_MTimeMS(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_MTimeMS)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_MTimeMS(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_AttribBits)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_AttribBits(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_AttribBits)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_AttribBits(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_AttribBitsValid)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_AttribBitsValid(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_AttribBitsValid)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_AttribBitsValid(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_FileTypeByte)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_FileTypeByte(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_FileTypeByte)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_FileTypeByte(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_Permissions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_Permissions(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_Permissions)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_Permissions(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_TextHint)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpTextHintRaw fOutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_TextHint(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_TextHint)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_TextHint(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSftpTextHintRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_MimeType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpFileAttributes_get_MimeType(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1507324527, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_MimeType)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_MimeType(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_LinkCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(TElSftpFileAttributes_get_LinkCount(SBGetObjectHandle(getThis() TSRMLS_CC), &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_LinkCount)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_LinkCount(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, get_UntranslatedName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpFileAttributes_get_UntranslatedName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(984317438, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, set_UntranslatedName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpFileAttributes_set_UntranslatedName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileAttributes, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpFileAttributes_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_CopyTo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, dst, TElSftpFileAttributes, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_SaveToBuffer, 0, 0, 1)
	ZEND_ARG_INFO(0, Ver)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_LoadFromBuffer, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, Ver)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_AddACE, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_RemoveACE, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_ClearACEs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_AddExtendedAttribute, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_RemoveExtendedAttribute, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_ClearExtendedAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_IsAttributeIncluded, 0, 0, 1)
	ZEND_ARG_INFO(0, Attribute)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_Size, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_Size, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_AllocationSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_AllocationSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_UID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_UID, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_GID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_GID, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_Owner, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_Owner, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_Group, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_Group, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_CTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_CTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_CATime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_CATime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_FileType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_FileType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_ATime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_ATime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_MTime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_MTime, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_ExtendedAttributeCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_ExtendedAttributes, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_IncludedAttributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_IncludedAttributes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_UserRead, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_UserRead, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_UserWrite, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_UserWrite, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_UserExecute, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_UserExecute, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_GroupRead, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_GroupRead, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_GroupWrite, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_GroupWrite, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_GroupExecute, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_GroupExecute, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_OtherRead, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_OtherRead, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_OtherWrite, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_OtherWrite, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_OtherExecute, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_OtherExecute, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_UIDBit, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_UIDBit, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_GIDBit, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_GIDBit, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_StickyBit, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_StickyBit, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_Directory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_Directory, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_ACLFlags, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_ACLFlags, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_ACECount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_ACEs, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_ATimeInt64, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_ATimeInt64, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_MTimeInt64, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_MTimeInt64, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_CTimeInt64, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_CTimeInt64, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_CATimeInt64, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_CATimeInt64, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_ATimeCardinal, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_ATimeCardinal, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_MTimeCardinal, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_MTimeCardinal, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_CTimeCardinal, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_CTimeCardinal, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_CATimeCardinal, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_CATimeCardinal, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_ATimeSeconds, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_MTimeSeconds, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_CTimeSeconds, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_CATimeSeconds, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_ATimeMS, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_ATimeMS, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_CTimeMS, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_CTimeMS, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_CATimeMS, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_CATimeMS, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_MTimeMS, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_MTimeMS, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_AttribBits, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_AttribBits, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_AttribBitsValid, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_AttribBitsValid, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_FileTypeByte, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_FileTypeByte, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_Permissions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_Permissions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_TextHint, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_TextHint, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_MimeType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_MimeType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_LinkCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_LinkCount, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_get_UntranslatedName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes_set_UntranslatedName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileAttributes___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpFileAttributes_methods[] = {
	PHP_ME(TElSftpFileAttributes, CopyTo, arginfo_TElSftpFileAttributes_CopyTo, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, SaveToBuffer, arginfo_TElSftpFileAttributes_SaveToBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, LoadFromBuffer, arginfo_TElSftpFileAttributes_LoadFromBuffer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, AddACE, arginfo_TElSftpFileAttributes_AddACE, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, RemoveACE, arginfo_TElSftpFileAttributes_RemoveACE, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, ClearACEs, arginfo_TElSftpFileAttributes_ClearACEs, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, AddExtendedAttribute, arginfo_TElSftpFileAttributes_AddExtendedAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, RemoveExtendedAttribute, arginfo_TElSftpFileAttributes_RemoveExtendedAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, ClearExtendedAttributes, arginfo_TElSftpFileAttributes_ClearExtendedAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, IsAttributeIncluded, arginfo_TElSftpFileAttributes_IsAttributeIncluded, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_Size, arginfo_TElSftpFileAttributes_get_Size, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_Size, arginfo_TElSftpFileAttributes_set_Size, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_AllocationSize, arginfo_TElSftpFileAttributes_get_AllocationSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_AllocationSize, arginfo_TElSftpFileAttributes_set_AllocationSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_UID, arginfo_TElSftpFileAttributes_get_UID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_UID, arginfo_TElSftpFileAttributes_set_UID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_GID, arginfo_TElSftpFileAttributes_get_GID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_GID, arginfo_TElSftpFileAttributes_set_GID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_Owner, arginfo_TElSftpFileAttributes_get_Owner, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_Owner, arginfo_TElSftpFileAttributes_set_Owner, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_Group, arginfo_TElSftpFileAttributes_get_Group, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_Group, arginfo_TElSftpFileAttributes_set_Group, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_CTime, arginfo_TElSftpFileAttributes_get_CTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_CTime, arginfo_TElSftpFileAttributes_set_CTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_CATime, arginfo_TElSftpFileAttributes_get_CATime, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_CATime, arginfo_TElSftpFileAttributes_set_CATime, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_FileType, arginfo_TElSftpFileAttributes_get_FileType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_FileType, arginfo_TElSftpFileAttributes_set_FileType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_ATime, arginfo_TElSftpFileAttributes_get_ATime, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_ATime, arginfo_TElSftpFileAttributes_set_ATime, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_MTime, arginfo_TElSftpFileAttributes_get_MTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_MTime, arginfo_TElSftpFileAttributes_set_MTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_ExtendedAttributeCount, arginfo_TElSftpFileAttributes_get_ExtendedAttributeCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_ExtendedAttributes, arginfo_TElSftpFileAttributes_get_ExtendedAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_IncludedAttributes, arginfo_TElSftpFileAttributes_get_IncludedAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_IncludedAttributes, arginfo_TElSftpFileAttributes_set_IncludedAttributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_UserRead, arginfo_TElSftpFileAttributes_get_UserRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_UserRead, arginfo_TElSftpFileAttributes_set_UserRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_UserWrite, arginfo_TElSftpFileAttributes_get_UserWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_UserWrite, arginfo_TElSftpFileAttributes_set_UserWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_UserExecute, arginfo_TElSftpFileAttributes_get_UserExecute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_UserExecute, arginfo_TElSftpFileAttributes_set_UserExecute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_GroupRead, arginfo_TElSftpFileAttributes_get_GroupRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_GroupRead, arginfo_TElSftpFileAttributes_set_GroupRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_GroupWrite, arginfo_TElSftpFileAttributes_get_GroupWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_GroupWrite, arginfo_TElSftpFileAttributes_set_GroupWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_GroupExecute, arginfo_TElSftpFileAttributes_get_GroupExecute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_GroupExecute, arginfo_TElSftpFileAttributes_set_GroupExecute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_OtherRead, arginfo_TElSftpFileAttributes_get_OtherRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_OtherRead, arginfo_TElSftpFileAttributes_set_OtherRead, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_OtherWrite, arginfo_TElSftpFileAttributes_get_OtherWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_OtherWrite, arginfo_TElSftpFileAttributes_set_OtherWrite, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_OtherExecute, arginfo_TElSftpFileAttributes_get_OtherExecute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_OtherExecute, arginfo_TElSftpFileAttributes_set_OtherExecute, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_UIDBit, arginfo_TElSftpFileAttributes_get_UIDBit, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_UIDBit, arginfo_TElSftpFileAttributes_set_UIDBit, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_GIDBit, arginfo_TElSftpFileAttributes_get_GIDBit, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_GIDBit, arginfo_TElSftpFileAttributes_set_GIDBit, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_StickyBit, arginfo_TElSftpFileAttributes_get_StickyBit, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_StickyBit, arginfo_TElSftpFileAttributes_set_StickyBit, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_Directory, arginfo_TElSftpFileAttributes_get_Directory, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_Directory, arginfo_TElSftpFileAttributes_set_Directory, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_ACLFlags, arginfo_TElSftpFileAttributes_get_ACLFlags, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_ACLFlags, arginfo_TElSftpFileAttributes_set_ACLFlags, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_ACECount, arginfo_TElSftpFileAttributes_get_ACECount, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_ACEs, arginfo_TElSftpFileAttributes_get_ACEs, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_ATimeInt64, arginfo_TElSftpFileAttributes_get_ATimeInt64, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_ATimeInt64, arginfo_TElSftpFileAttributes_set_ATimeInt64, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_MTimeInt64, arginfo_TElSftpFileAttributes_get_MTimeInt64, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_MTimeInt64, arginfo_TElSftpFileAttributes_set_MTimeInt64, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_CTimeInt64, arginfo_TElSftpFileAttributes_get_CTimeInt64, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_CTimeInt64, arginfo_TElSftpFileAttributes_set_CTimeInt64, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_CATimeInt64, arginfo_TElSftpFileAttributes_get_CATimeInt64, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_CATimeInt64, arginfo_TElSftpFileAttributes_set_CATimeInt64, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_ATimeCardinal, arginfo_TElSftpFileAttributes_get_ATimeCardinal, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_ATimeCardinal, arginfo_TElSftpFileAttributes_set_ATimeCardinal, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_MTimeCardinal, arginfo_TElSftpFileAttributes_get_MTimeCardinal, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_MTimeCardinal, arginfo_TElSftpFileAttributes_set_MTimeCardinal, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_CTimeCardinal, arginfo_TElSftpFileAttributes_get_CTimeCardinal, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_CTimeCardinal, arginfo_TElSftpFileAttributes_set_CTimeCardinal, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_CATimeCardinal, arginfo_TElSftpFileAttributes_get_CATimeCardinal, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_CATimeCardinal, arginfo_TElSftpFileAttributes_set_CATimeCardinal, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_ATimeSeconds, arginfo_TElSftpFileAttributes_get_ATimeSeconds, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_MTimeSeconds, arginfo_TElSftpFileAttributes_get_MTimeSeconds, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_CTimeSeconds, arginfo_TElSftpFileAttributes_get_CTimeSeconds, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_CATimeSeconds, arginfo_TElSftpFileAttributes_get_CATimeSeconds, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_ATimeMS, arginfo_TElSftpFileAttributes_get_ATimeMS, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_ATimeMS, arginfo_TElSftpFileAttributes_set_ATimeMS, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_CTimeMS, arginfo_TElSftpFileAttributes_get_CTimeMS, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_CTimeMS, arginfo_TElSftpFileAttributes_set_CTimeMS, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_CATimeMS, arginfo_TElSftpFileAttributes_get_CATimeMS, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_CATimeMS, arginfo_TElSftpFileAttributes_set_CATimeMS, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_MTimeMS, arginfo_TElSftpFileAttributes_get_MTimeMS, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_MTimeMS, arginfo_TElSftpFileAttributes_set_MTimeMS, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_AttribBits, arginfo_TElSftpFileAttributes_get_AttribBits, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_AttribBits, arginfo_TElSftpFileAttributes_set_AttribBits, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_AttribBitsValid, arginfo_TElSftpFileAttributes_get_AttribBitsValid, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_AttribBitsValid, arginfo_TElSftpFileAttributes_set_AttribBitsValid, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_FileTypeByte, arginfo_TElSftpFileAttributes_get_FileTypeByte, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_FileTypeByte, arginfo_TElSftpFileAttributes_set_FileTypeByte, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_Permissions, arginfo_TElSftpFileAttributes_get_Permissions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_Permissions, arginfo_TElSftpFileAttributes_set_Permissions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_TextHint, arginfo_TElSftpFileAttributes_get_TextHint, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_TextHint, arginfo_TElSftpFileAttributes_set_TextHint, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_MimeType, arginfo_TElSftpFileAttributes_get_MimeType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_MimeType, arginfo_TElSftpFileAttributes_set_MimeType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_LinkCount, arginfo_TElSftpFileAttributes_get_LinkCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_LinkCount, arginfo_TElSftpFileAttributes_set_LinkCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, get_UntranslatedName, arginfo_TElSftpFileAttributes_get_UntranslatedName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, set_UntranslatedName, arginfo_TElSftpFileAttributes_set_UntranslatedName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileAttributes, __construct, arginfo_TElSftpFileAttributes___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpFileAttributes(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpFileAttributes_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpFileAttributes", TElSftpFileAttributes_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSftpFileAttributes_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSftpFileInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpFileInfo, CopyTo)
{
	zval *oFileInfo;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oFileInfo, TElSftpFileInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSftpFileInfo_CopyTo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oFileInfo TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSftpFileInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileInfo, get_Name)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpFileInfo_get_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1294141107, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileInfo, set_Name)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpFileInfo_set_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileInfo, get_LongName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpFileInfo_get_LongName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1936358336, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileInfo, set_LongName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpFileInfo_set_LongName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileInfo, get_Path)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpFileInfo_get_Path(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(408220602, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileInfo, set_Path)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSftpFileInfo_set_Path(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileInfo, get_Attributes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpFileInfo_get_Attributes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSftpFileAttributes_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpFileInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpFileInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileInfo_CopyTo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, FileInfo, TElSftpFileInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileInfo_get_Name, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileInfo_set_Name, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileInfo_get_LongName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileInfo_set_LongName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileInfo_get_Path, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileInfo_set_Path, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileInfo_get_Attributes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpFileInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpFileInfo_methods[] = {
	PHP_ME(TElSftpFileInfo, CopyTo, arginfo_TElSftpFileInfo_CopyTo, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileInfo, get_Name, arginfo_TElSftpFileInfo_get_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileInfo, set_Name, arginfo_TElSftpFileInfo_set_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileInfo, get_LongName, arginfo_TElSftpFileInfo_get_LongName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileInfo, set_LongName, arginfo_TElSftpFileInfo_set_LongName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileInfo, get_Path, arginfo_TElSftpFileInfo_get_Path, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileInfo, set_Path, arginfo_TElSftpFileInfo_set_Path, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileInfo, get_Attributes, arginfo_TElSftpFileInfo_get_Attributes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpFileInfo, __construct, arginfo_TElSftpFileInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpFileInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpFileInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpFileInfo", TElSftpFileInfo_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSftpFileInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TSBSftpOpenRequestInfo_ce_ptr = NULL;

SB_PHP_METHOD(TSBSftpOpenRequestInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TSBSftpOpenRequestInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpOpenRequestInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TSBSftpOpenRequestInfo_methods[] = {
	PHP_ME(TSBSftpOpenRequestInfo, __construct, arginfo_TSBSftpOpenRequestInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TSBSftpOpenRequestInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TSBSftpOpenRequestInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TSBSftpOpenRequestInfo", TSBSftpOpenRequestInfo_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TSBSftpOpenRequestInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TSBSftpTextHandleInfo_ce_ptr = NULL;

SB_PHP_METHOD(TSBSftpTextHandleInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TSBSftpTextHandleInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBSftpTextHandleInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TSBSftpTextHandleInfo_methods[] = {
	PHP_ME(TSBSftpTextHandleInfo, __construct, arginfo_TSBSftpTextHandleInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TSBSftpTextHandleInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TSBSftpTextHandleInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TSBSftpTextHandleInfo", TSBSftpTextHandleInfo_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TSBSftpTextHandleInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSftpTransferBlock_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpTransferBlock, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpTransferBlock_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferBlock___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpTransferBlock_methods[] = {
	PHP_ME(TElSftpTransferBlock, __construct, arginfo_TElSftpTransferBlock___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpTransferBlock(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpTransferBlock_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpTransferBlock", TElSftpTransferBlock_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSftpTransferBlock_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSftpTransferManager_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpTransferManager, Run)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpTransferManager_Run(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, ProcessData)
{
	sb_zend_long l4Size;
	sb_zend_long u4Id;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzl", &u4Id, &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSftpTransferManager_ProcessData(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Id, piBuffer.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, ProcessStatus)
{
	char *sComment;
	sb_str_size sComment_len;
	sb_zend_long l4StatusCode;
	sb_zend_long u4Id;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lls", &u4Id, &l4StatusCode, &sComment, &sComment_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpTransferManager_ProcessStatus(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Id, (int32_t)l4StatusCode, sComment, (int32_t)sComment_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, OperationFinished)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpTransferManager_OperationFinished(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, Terminate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpTransferManager_Terminate(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, get_Direction)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpTransferDirectionRaw fOutResultRaw = 0;
		SBCheckError(TElSftpTransferManager_get_Direction(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, get_Received)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSftpTransferManager_get_Received(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, get_Handle)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSftpTransferManager_get_Handle(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-402888580, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, get_TextMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpTransferManager_get_TextMode(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, get_LastError)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSftpTransferManager_get_LastError(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, get_LastComment)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSftpTransferManager_get_LastComment(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(741791428, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, get_OnData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpDataEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSftpTransferManager_get_OnData(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, set_OnData)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSftpTransferManager_set_OnData(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSftpDataEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSftpDataEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, get_OnASCIIData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpDataEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSftpTransferManager_get_OnASCIIData(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, set_OnASCIIData)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSftpTransferManager_set_OnASCIIData(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSftpDataEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSftpDataEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, get_OnReadRequest)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpReadRequestEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSftpTransferManager_get_OnReadRequest(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, set_OnReadRequest)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSftpTransferManager_set_OnReadRequest(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSftpReadRequestEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSftpReadRequestEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, get_OnWriteRequest)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpWriteRequestEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSftpTransferManager_get_OnWriteRequest(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, set_OnWriteRequest)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSftpTransferManager_set_OnWriteRequest(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSftpWriteRequestEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSftpWriteRequestEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, get_OnFinish)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSftpTransferManager_get_OnFinish(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, set_OnFinish)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSftpTransferManager_set_OnFinish(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, get_OnProgress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBProgressEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSftpTransferManager_get_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, set_OnProgress)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSftpTransferManager_set_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBProgressEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBProgressEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpTransferManager, __construct)
{
	sb_zend_long fDirection;
	sb_zend_long l4ChunkSize;
	sb_zend_long l4MaxActiveCount;
	sb_zend_long l4Size;
	sb_zend_long l8Offset;
	SBArrayZValInfo aiHandle;
	SBArrayZValInfo piBuffer;
	zend_bool bTextMode;
	zval *zaHandle;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzllllb", &zaHandle, &l8Offset, &zpBuffer, &l4Size, &l4ChunkSize, &l4MaxActiveCount, &fDirection, &bTextMode) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaHandle) || SB_IS_ARRAY_TYPE_RP(zaHandle) || SB_IS_NULL_TYPE_RP(zaHandle)) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaHandle, &aiHandle TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSftpTransferManager_Create(aiHandle.data, aiHandle.len, (int64_t)l8Offset, piBuffer.data, (int32_t)l4Size, (int32_t)l4ChunkSize, (int32_t)l4MaxActiveCount, (TSBSftpTransferDirectionRaw)fDirection, (int8_t)bTextMode, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiHandle);
		SBFreePointerZValInfo(&piBuffer);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, integer, integer, integer, integer, bool)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_Run, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_ProcessData, 0, 0, 3)
	ZEND_ARG_INFO(0, Id)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_ProcessStatus, 0, 0, 3)
	ZEND_ARG_INFO(0, Id)
	ZEND_ARG_INFO(0, StatusCode)
	ZEND_ARG_INFO(0, Comment)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_OperationFinished, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_Terminate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_get_Direction, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_get_Received, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_get_Handle, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_get_TextMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_get_LastError, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_get_LastComment, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_get_OnData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_set_OnData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_get_OnASCIIData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_set_OnASCIIData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_get_OnReadRequest, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_set_OnReadRequest, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_get_OnWriteRequest, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_set_OnWriteRequest, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_get_OnFinish, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_set_OnFinish, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_get_OnProgress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager_set_OnProgress, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpTransferManager___construct, 0, 0, 8)
	ZEND_ARG_TYPE_INFO(0, Handle, 0, 1)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
	ZEND_ARG_INFO(0, ChunkSize)
	ZEND_ARG_INFO(0, MaxActiveCount)
	ZEND_ARG_INFO(0, Direction)
	ZEND_ARG_INFO(0, TextMode)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpTransferManager_methods[] = {
	PHP_ME(TElSftpTransferManager, Run, arginfo_TElSftpTransferManager_Run, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, ProcessData, arginfo_TElSftpTransferManager_ProcessData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, ProcessStatus, arginfo_TElSftpTransferManager_ProcessStatus, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, OperationFinished, arginfo_TElSftpTransferManager_OperationFinished, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, Terminate, arginfo_TElSftpTransferManager_Terminate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, get_Direction, arginfo_TElSftpTransferManager_get_Direction, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, get_Received, arginfo_TElSftpTransferManager_get_Received, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, get_Handle, arginfo_TElSftpTransferManager_get_Handle, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, get_TextMode, arginfo_TElSftpTransferManager_get_TextMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, get_LastError, arginfo_TElSftpTransferManager_get_LastError, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, get_LastComment, arginfo_TElSftpTransferManager_get_LastComment, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, get_OnData, arginfo_TElSftpTransferManager_get_OnData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, set_OnData, arginfo_TElSftpTransferManager_set_OnData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, get_OnASCIIData, arginfo_TElSftpTransferManager_get_OnASCIIData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, set_OnASCIIData, arginfo_TElSftpTransferManager_set_OnASCIIData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, get_OnReadRequest, arginfo_TElSftpTransferManager_get_OnReadRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, set_OnReadRequest, arginfo_TElSftpTransferManager_set_OnReadRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, get_OnWriteRequest, arginfo_TElSftpTransferManager_get_OnWriteRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, set_OnWriteRequest, arginfo_TElSftpTransferManager_set_OnWriteRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, get_OnFinish, arginfo_TElSftpTransferManager_get_OnFinish, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, set_OnFinish, arginfo_TElSftpTransferManager_set_OnFinish, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, get_OnProgress, arginfo_TElSftpTransferManager_get_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, set_OnProgress, arginfo_TElSftpTransferManager_set_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpTransferManager, __construct, arginfo_TElSftpTransferManager___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpTransferManager(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpTransferManager_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpTransferManager", TElSftpTransferManager_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSftpTransferManager_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSftpRemovalTarget_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpRemovalTarget, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpRemovalTarget_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpRemovalTarget___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpRemovalTarget_methods[] = {
	PHP_ME(TElSftpRemovalTarget, __construct, arginfo_TElSftpRemovalTarget___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpRemovalTarget(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpRemovalTarget_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpRemovalTarget", TElSftpRemovalTarget_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSftpRemovalTarget_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSftpRemovalManager_ce_ptr = NULL;

SB_PHP_METHOD(TElSftpRemovalManager, Run)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpRemovalManager_Run(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpRemovalManager, ProcessStatus)
{
	char *sErrorMsg;
	sb_str_size sErrorMsg_len;
	sb_zend_long l4StatusCode;
	sb_zend_long u4Id;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lls", &u4Id, &l4StatusCode, &sErrorMsg, &sErrorMsg_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpRemovalManager_ProcessStatus(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Id, (int32_t)l4StatusCode, sErrorMsg, (int32_t)sErrorMsg_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpRemovalManager, OperationFinished)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSftpRemovalManager_OperationFinished(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpRemovalManager, Terminate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSftpRemovalManager_Terminate(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpRemovalManager, get_ErrorList)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpRemovalManager_get_ErrorList(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpRemovalManager, get_ErrorFilenames)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpRemovalManager_get_ErrorFilenames(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpRemovalManager, get_OnFinish)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSftpRemovalManager_get_OnFinish(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpRemovalManager, set_OnFinish)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSftpRemovalManager_set_OnFinish(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpRemovalManager, get_OnProgress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBProgressEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSftpRemovalManager_get_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpRemovalManager, set_OnProgress)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSftpRemovalManager_set_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBProgressEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBProgressEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpRemovalManager, get_OnRemovalRequest)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSftpRemovalRequestEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSftpRemovalManager_get_OnRemovalRequest(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpRemovalManager, set_OnRemovalRequest)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSftpRemovalManager_set_OnRemovalRequest(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSftpRemovalRequestEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSftpRemovalRequestEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSftpRemovalManager, __construct)
{
	sb_zend_long l4MaxActiveCount;
	zval *oFilenames;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oFilenames, TStrings_ce_ptr, &l4MaxActiveCount) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSftpRemovalManager_Create(SBGetObjectHandle(oFilenames TSRMLS_CC), (int32_t)l4MaxActiveCount, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStrings, integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpRemovalManager_Run, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpRemovalManager_ProcessStatus, 0, 0, 3)
	ZEND_ARG_INFO(0, Id)
	ZEND_ARG_INFO(0, StatusCode)
	ZEND_ARG_INFO(0, ErrorMsg)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpRemovalManager_OperationFinished, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpRemovalManager_Terminate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpRemovalManager_get_ErrorList, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpRemovalManager_get_ErrorFilenames, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpRemovalManager_get_OnFinish, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpRemovalManager_set_OnFinish, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpRemovalManager_get_OnProgress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpRemovalManager_set_OnProgress, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpRemovalManager_get_OnRemovalRequest, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpRemovalManager_set_OnRemovalRequest, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSftpRemovalManager___construct, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Filenames, TStrings, 1)
	ZEND_ARG_INFO(0, MaxActiveCount)
ZEND_END_ARG_INFO()

static zend_function_entry TElSftpRemovalManager_methods[] = {
	PHP_ME(TElSftpRemovalManager, Run, arginfo_TElSftpRemovalManager_Run, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpRemovalManager, ProcessStatus, arginfo_TElSftpRemovalManager_ProcessStatus, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpRemovalManager, OperationFinished, arginfo_TElSftpRemovalManager_OperationFinished, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpRemovalManager, Terminate, arginfo_TElSftpRemovalManager_Terminate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpRemovalManager, get_ErrorList, arginfo_TElSftpRemovalManager_get_ErrorList, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpRemovalManager, get_ErrorFilenames, arginfo_TElSftpRemovalManager_get_ErrorFilenames, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpRemovalManager, get_OnFinish, arginfo_TElSftpRemovalManager_get_OnFinish, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpRemovalManager, set_OnFinish, arginfo_TElSftpRemovalManager_set_OnFinish, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpRemovalManager, get_OnProgress, arginfo_TElSftpRemovalManager_get_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpRemovalManager, set_OnProgress, arginfo_TElSftpRemovalManager_set_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpRemovalManager, get_OnRemovalRequest, arginfo_TElSftpRemovalManager_get_OnRemovalRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpRemovalManager, set_OnRemovalRequest, arginfo_TElSftpRemovalManager_set_OnRemovalRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElSftpRemovalManager, __construct, arginfo_TElSftpRemovalManager___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSftpRemovalManager(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSftpRemovalManager_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSftpRemovalManager", TElSftpRemovalManager_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSftpRemovalManager_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

SB_PHP_FUNCTION(SBSftpCommon, WriteDefaultAttributes)
{
	TElClassHandle hoAttributes;
	zval *oAttributes;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oAttributes, TElSftpFileAttributes_ce_ptr) == SUCCESS) && SB_ISREF_OBJECT_P(oAttributes))
	{
		hoAttributes = SBGetObjectHandle(oAttributes TSRMLS_CC);
		SBCheckError(SBSftpCommon_WriteDefaultAttributes(&hoAttributes) TSRMLS_CC);
		SBUpdateObjectHandle(oAttributes, hoAttributes TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(&\\TElSftpFileAttributes)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSftpCommon, RealPathControlToByte)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(SBSftpCommon_RealPathControlToByte((TSBSftpRealpathControlRaw)fValue, &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSftpCommon, ByteToRealPathControl)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		TSBSftpRealpathControlRaw fOutResultRaw = 0;
		SBCheckError(SBSftpCommon_ByteToRealPathControl((uint8_t)u1Value, &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSftpCommon, FileOpenAccessToUInt32)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(SBSftpCommon_FileOpenAccessToUInt32((TSBSftpFileOpenAccessRaw)fValue, &u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSftpCommon, UInt32ToFileOpenAccess)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		TSBSftpFileOpenAccessRaw fOutResultRaw = 0;
		SBCheckError(SBSftpCommon_UInt32ToFileOpenAccess((uint32_t)u4Value, &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSftpCommon, UInt32ToRenameFlags)
{
	sb_zend_long u4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Value) == SUCCESS)
	{
		TSBSftpRenameFlagsRaw fOutResultRaw = 0;
		SBCheckError(SBSftpCommon_UInt32ToRenameFlags((uint32_t)u4Value, &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSftpCommon, GetSFTPPacketNameByCode)
{
	sb_zend_long l4Code;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Code) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBSftpCommon_GetSFTPPacketNameByCode((int32_t)l4Code, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1036156094, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

void Register_SBSftpCommon_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ERROR_FACILITY_SFTP, SB_ERROR_FACILITY_SFTP, SB_ERROR_FACILITY_SFTP);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ERROR_SFTP_PROTOCOL_ERROR_FLAG, SB_ERROR_SFTP_PROTOCOL_ERROR_FLAG, SB_ERROR_SFTP_PROTOCOL_ERROR_FLAG);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ERROR_SFTP_CUSTOM_ERROR_FLAG, SB_ERROR_SFTP_CUSTOM_ERROR_FLAG, SB_ERROR_SFTP_CUSTOM_ERROR_FLAG);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_OK, SB_SSH_ERROR_OK, SB_SSH_ERROR_OK);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_BASE, SB_SSH_ERROR_BASE, SB_SSH_ERROR_BASE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_WRONG_MODE, SB_SSH_ERROR_WRONG_MODE, SB_SSH_ERROR_WRONG_MODE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_EOF, SB_SSH_ERROR_EOF, SB_SSH_ERROR_EOF);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_NO_SUCH_FILE, SB_SSH_ERROR_NO_SUCH_FILE, SB_SSH_ERROR_NO_SUCH_FILE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_PERMISSION_DENIED, SB_SSH_ERROR_PERMISSION_DENIED, SB_SSH_ERROR_PERMISSION_DENIED);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_FAILURE, SB_SSH_ERROR_FAILURE, SB_SSH_ERROR_FAILURE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_BAD_MESSAGE, SB_SSH_ERROR_BAD_MESSAGE, SB_SSH_ERROR_BAD_MESSAGE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_NO_CONNECTION, SB_SSH_ERROR_NO_CONNECTION, SB_SSH_ERROR_NO_CONNECTION);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_CONNECTION_LOST, SB_SSH_ERROR_CONNECTION_LOST, SB_SSH_ERROR_CONNECTION_LOST);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_OP_UNSUPPORTED, SB_SSH_ERROR_OP_UNSUPPORTED, SB_SSH_ERROR_OP_UNSUPPORTED);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_INVALID_HANDLE, SB_SSH_ERROR_INVALID_HANDLE, SB_SSH_ERROR_INVALID_HANDLE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_NO_SUCH_PATH, SB_SSH_ERROR_NO_SUCH_PATH, SB_SSH_ERROR_NO_SUCH_PATH);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_FILE_ALREADY_EXISTS, SB_SSH_ERROR_FILE_ALREADY_EXISTS, SB_SSH_ERROR_FILE_ALREADY_EXISTS);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_WRITE_PROTECT, SB_SSH_ERROR_WRITE_PROTECT, SB_SSH_ERROR_WRITE_PROTECT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_NO_MEDIA, SB_SSH_ERROR_NO_MEDIA, SB_SSH_ERROR_NO_MEDIA);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_NO_SPACE_ON_FILESYSTEM, SB_SSH_ERROR_NO_SPACE_ON_FILESYSTEM, SB_SSH_ERROR_NO_SPACE_ON_FILESYSTEM);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_QUOTA_EXCEEDED, SB_SSH_ERROR_QUOTA_EXCEEDED, SB_SSH_ERROR_QUOTA_EXCEEDED);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_UNKNOWN_PRINCIPAL, SB_SSH_ERROR_UNKNOWN_PRINCIPAL, SB_SSH_ERROR_UNKNOWN_PRINCIPAL);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_LOCK_CONFLICT, SB_SSH_ERROR_LOCK_CONFLICT, SB_SSH_ERROR_LOCK_CONFLICT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_DIR_NOT_EMPTY, SB_SSH_ERROR_DIR_NOT_EMPTY, SB_SSH_ERROR_DIR_NOT_EMPTY);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_NOT_A_DIRECTORY, SB_SSH_ERROR_NOT_A_DIRECTORY, SB_SSH_ERROR_NOT_A_DIRECTORY);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_INVALID_FILENAME, SB_SSH_ERROR_INVALID_FILENAME, SB_SSH_ERROR_INVALID_FILENAME);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_LINK_LOOP, SB_SSH_ERROR_LINK_LOOP, SB_SSH_ERROR_LINK_LOOP);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_CANNOT_DELETE, SB_SSH_ERROR_CANNOT_DELETE, SB_SSH_ERROR_CANNOT_DELETE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_INVALID_PARAMETER, SB_SSH_ERROR_INVALID_PARAMETER, SB_SSH_ERROR_INVALID_PARAMETER);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_FILE_IS_A_DIRECTORY, SB_SSH_ERROR_FILE_IS_A_DIRECTORY, SB_SSH_ERROR_FILE_IS_A_DIRECTORY);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_BYTE_RANGE_LOCK_CONFLICT, SB_SSH_ERROR_BYTE_RANGE_LOCK_CONFLICT, SB_SSH_ERROR_BYTE_RANGE_LOCK_CONFLICT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_BYTE_RANGE_LOCK_REFUSED, SB_SSH_ERROR_BYTE_RANGE_LOCK_REFUSED, SB_SSH_ERROR_BYTE_RANGE_LOCK_REFUSED);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_DELETE_PENDING, SB_SSH_ERROR_DELETE_PENDING, SB_SSH_ERROR_DELETE_PENDING);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_FILE_CORRUPT, SB_SSH_ERROR_FILE_CORRUPT, SB_SSH_ERROR_FILE_CORRUPT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_OWNER_INVALID, SB_SSH_ERROR_OWNER_INVALID, SB_SSH_ERROR_OWNER_INVALID);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_GROUP_INVALID, SB_SSH_ERROR_GROUP_INVALID, SB_SSH_ERROR_GROUP_INVALID);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_UNSUPPORTED_VERSION, SB_SSH_ERROR_UNSUPPORTED_VERSION, SB_SSH_ERROR_UNSUPPORTED_VERSION);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_INVALID_PACKET, SB_SSH_ERROR_INVALID_PACKET, SB_SSH_ERROR_INVALID_PACKET);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_TUNNEL_ERROR, SB_SSH_ERROR_TUNNEL_ERROR, SB_SSH_ERROR_TUNNEL_ERROR);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_CONNECTION_CLOSED, SB_SSH_ERROR_CONNECTION_CLOSED, SB_SSH_ERROR_CONNECTION_CLOSED);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_UNSUPPORTED_ACTION, SB_SSH_ERROR_UNSUPPORTED_ACTION, SB_SSH_ERROR_UNSUPPORTED_ACTION);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_NOT_A_TEXT_HANDLE, SB_SSH_ERROR_NOT_A_TEXT_HANDLE, SB_SSH_ERROR_NOT_A_TEXT_HANDLE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ERROR_CANCELLED_BY_USER, SB_SSH_ERROR_CANCELLED_BY_USER, SB_SSH_ERROR_CANCELLED_BY_USER);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SB_SFTP_ERROR_CUSTOM_BASE, SB_SFTP_ERROR_CUSTOM_BASE, SB_SFTP_ERROR_CUSTOM_BASE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SB_SFTP_ERROR_OFFSET_TOO_LARGE, SB_SFTP_ERROR_OFFSET_TOO_LARGE, SB_SFTP_ERROR_OFFSET_TOO_LARGE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SB_SFTP_ERROR_TIMES_NOT_SET, SB_SFTP_ERROR_TIMES_NOT_SET, SB_SFTP_ERROR_TIMES_NOT_SET);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SB_SFTP_ERROR_LOCAL_SOURCE_NOT_FILE, SB_SFTP_ERROR_LOCAL_SOURCE_NOT_FILE, SB_SFTP_ERROR_LOCAL_SOURCE_NOT_FILE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SB_SFTP_ERROR_LOCAL_TARGET_NOT_FILE, SB_SFTP_ERROR_LOCAL_TARGET_NOT_FILE, SB_SFTP_ERROR_LOCAL_TARGET_NOT_FILE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SB_SFTP_ERROR_OPERATION_CRITERIA_NOT_MET, SB_SFTP_ERROR_OPERATION_CRITERIA_NOT_MET, SB_SFTP_ERROR_OPERATION_CRITERIA_NOT_MET);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SB_SFTP_ERROR_INTERRUPTED_BY_USER, SB_SFTP_ERROR_INTERRUPTED_BY_USER, SB_SFTP_ERROR_INTERRUPTED_BY_USER);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SB_SFTP_ERROR_SECONDARY_CHANNEL_ERROR, SB_SFTP_ERROR_SECONDARY_CHANNEL_ERROR, SB_SFTP_ERROR_SECONDARY_CHANNEL_ERROR);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SB_SFTP_ERROR_UNSUPPORTED_ALGORITHM, SB_SFTP_ERROR_UNSUPPORTED_ALGORITHM, SB_SFTP_ERROR_UNSUPPORTED_ALGORITHM);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_ACCESS_ALLOWED_ACE_TYPE, SB_ACE4_ACCESS_ALLOWED_ACE_TYPE, SB_ACE4_ACCESS_ALLOWED_ACE_TYPE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_ACCESS_DENIED_ACE_TYPE, SB_ACE4_ACCESS_DENIED_ACE_TYPE, SB_ACE4_ACCESS_DENIED_ACE_TYPE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_SYSTEM_AUDIT_ACE_TYPE, SB_ACE4_SYSTEM_AUDIT_ACE_TYPE, SB_ACE4_SYSTEM_AUDIT_ACE_TYPE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_SYSTEM_ALARM_ACE_TYPE, SB_ACE4_SYSTEM_ALARM_ACE_TYPE, SB_ACE4_SYSTEM_ALARM_ACE_TYPE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_FILE_INHERIT_ACE, SB_ACE4_FILE_INHERIT_ACE, SB_ACE4_FILE_INHERIT_ACE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_DIRECTORY_INHERIT_ACE, SB_ACE4_DIRECTORY_INHERIT_ACE, SB_ACE4_DIRECTORY_INHERIT_ACE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_NO_PROPAGATE_INHERIT_ACE, SB_ACE4_NO_PROPAGATE_INHERIT_ACE, SB_ACE4_NO_PROPAGATE_INHERIT_ACE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_INHERIT_ONLY_ACE, SB_ACE4_INHERIT_ONLY_ACE, SB_ACE4_INHERIT_ONLY_ACE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_SUCCESSFUL_ACCESS_ACE_FLAG, SB_ACE4_SUCCESSFUL_ACCESS_ACE_FLAG, SB_ACE4_SUCCESSFUL_ACCESS_ACE_FLAG);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_FAILED_ACCESS_ACE_FLAG, SB_ACE4_FAILED_ACCESS_ACE_FLAG, SB_ACE4_FAILED_ACCESS_ACE_FLAG);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_IDENTIFIER_GROUP, SB_ACE4_IDENTIFIER_GROUP, SB_ACE4_IDENTIFIER_GROUP);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_READ_DATA, SB_ACE4_READ_DATA, SB_ACE4_READ_DATA);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_LIST_DIRECTORY, SB_ACE4_LIST_DIRECTORY, SB_ACE4_LIST_DIRECTORY);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_WRITE_DATA, SB_ACE4_WRITE_DATA, SB_ACE4_WRITE_DATA);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_ADD_FILE, SB_ACE4_ADD_FILE, SB_ACE4_ADD_FILE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_APPEND_DATA, SB_ACE4_APPEND_DATA, SB_ACE4_APPEND_DATA);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_ADD_SUBDIRECTORY, SB_ACE4_ADD_SUBDIRECTORY, SB_ACE4_ADD_SUBDIRECTORY);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_READ_NAMED_ATTRS, SB_ACE4_READ_NAMED_ATTRS, SB_ACE4_READ_NAMED_ATTRS);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_WRITE_NAMED_ATTRS, SB_ACE4_WRITE_NAMED_ATTRS, SB_ACE4_WRITE_NAMED_ATTRS);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_EXECUTE, SB_ACE4_EXECUTE, SB_ACE4_EXECUTE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_DELETE_CHILD, SB_ACE4_DELETE_CHILD, SB_ACE4_DELETE_CHILD);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_READ_ATTRIBUTES, SB_ACE4_READ_ATTRIBUTES, SB_ACE4_READ_ATTRIBUTES);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_WRITE_ATTRIBUTES, SB_ACE4_WRITE_ATTRIBUTES, SB_ACE4_WRITE_ATTRIBUTES);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_DELETE, SB_ACE4_DELETE, SB_ACE4_DELETE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_READ_ACL, SB_ACE4_READ_ACL, SB_ACE4_READ_ACL);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_WRITE_ACL, SB_ACE4_WRITE_ACL, SB_ACE4_WRITE_ACL);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_WRITE_OWNER, SB_ACE4_WRITE_OWNER, SB_ACE4_WRITE_OWNER);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, ACE4_SYNCHRONIZE, SB_ACE4_SYNCHRONIZE, SB_ACE4_SYNCHRONIZE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_FLAGS_READONLY, SB_SSH_FILEXFER_ATTR_FLAGS_READONLY, SB_SSH_FILEXFER_ATTR_FLAGS_READONLY);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_FLAGS_SYSTEM, SB_SSH_FILEXFER_ATTR_FLAGS_SYSTEM, SB_SSH_FILEXFER_ATTR_FLAGS_SYSTEM);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_FLAGS_HIDDEN, SB_SSH_FILEXFER_ATTR_FLAGS_HIDDEN, SB_SSH_FILEXFER_ATTR_FLAGS_HIDDEN);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_FLAGS_CASE_INSENSITIVE, SB_SSH_FILEXFER_ATTR_FLAGS_CASE_INSENSITIVE, SB_SSH_FILEXFER_ATTR_FLAGS_CASE_INSENSITIVE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_FLAGS_ARCHIVE, SB_SSH_FILEXFER_ATTR_FLAGS_ARCHIVE, SB_SSH_FILEXFER_ATTR_FLAGS_ARCHIVE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_FLAGS_ENCRYPTED, SB_SSH_FILEXFER_ATTR_FLAGS_ENCRYPTED, SB_SSH_FILEXFER_ATTR_FLAGS_ENCRYPTED);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_FLAGS_COMPRESSED, SB_SSH_FILEXFER_ATTR_FLAGS_COMPRESSED, SB_SSH_FILEXFER_ATTR_FLAGS_COMPRESSED);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_FLAGS_SPARSE, SB_SSH_FILEXFER_ATTR_FLAGS_SPARSE, SB_SSH_FILEXFER_ATTR_FLAGS_SPARSE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_FLAGS_APPEND_ONLY, SB_SSH_FILEXFER_ATTR_FLAGS_APPEND_ONLY, SB_SSH_FILEXFER_ATTR_FLAGS_APPEND_ONLY);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_FLAGS_IMMUTABLE, SB_SSH_FILEXFER_ATTR_FLAGS_IMMUTABLE, SB_SSH_FILEXFER_ATTR_FLAGS_IMMUTABLE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_FLAGS_SYNC, SB_SSH_FILEXFER_ATTR_FLAGS_SYNC, SB_SSH_FILEXFER_ATTR_FLAGS_SYNC);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_FLAGS_TRANSLATION_ERR, SB_SSH_FILEXFER_ATTR_FLAGS_TRANSLATION_ERR, SB_SSH_FILEXFER_ATTR_FLAGS_TRANSLATION_ERR);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, S_IRUSR, SB_S_IRUSR, SB_S_IRUSR);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, S_IWUSR, SB_S_IWUSR, SB_S_IWUSR);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, S_IXUSR, SB_S_IXUSR, SB_S_IXUSR);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, S_IRGRP, SB_S_IRGRP, SB_S_IRGRP);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, S_IWGRP, SB_S_IWGRP, SB_S_IWGRP);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, S_IXGRP, SB_S_IXGRP, SB_S_IXGRP);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, S_IROTH, SB_S_IROTH, SB_S_IROTH);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, S_IWOTH, SB_S_IWOTH, SB_S_IWOTH);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, S_IXOTH, SB_S_IXOTH, SB_S_IXOTH);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, S_ISUID, SB_S_ISUID, SB_S_ISUID);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, S_ISGID, SB_S_ISGID, SB_S_ISGID);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, S_ISVTX, SB_S_ISVTX, SB_S_ISVTX);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, DATA_BUFFER_SIZE, SB_DATA_BUFFER_SIZE, SB_DATA_BUFFER_SIZE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_INIT, SB_SSH_FXP_INIT, SB_SSH_FXP_INIT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_VERSION, SB_SSH_FXP_VERSION, SB_SSH_FXP_VERSION);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_OPEN, SB_SSH_FXP_OPEN, SB_SSH_FXP_OPEN);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_CLOSE, SB_SSH_FXP_CLOSE, SB_SSH_FXP_CLOSE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_READ, SB_SSH_FXP_READ, SB_SSH_FXP_READ);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_WRITE, SB_SSH_FXP_WRITE, SB_SSH_FXP_WRITE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_LSTAT, SB_SSH_FXP_LSTAT, SB_SSH_FXP_LSTAT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_FSTAT, SB_SSH_FXP_FSTAT, SB_SSH_FXP_FSTAT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_SETSTAT, SB_SSH_FXP_SETSTAT, SB_SSH_FXP_SETSTAT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_FSETSTAT, SB_SSH_FXP_FSETSTAT, SB_SSH_FXP_FSETSTAT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_OPENDIR, SB_SSH_FXP_OPENDIR, SB_SSH_FXP_OPENDIR);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_READDIR, SB_SSH_FXP_READDIR, SB_SSH_FXP_READDIR);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_REMOVE, SB_SSH_FXP_REMOVE, SB_SSH_FXP_REMOVE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_MKDIR, SB_SSH_FXP_MKDIR, SB_SSH_FXP_MKDIR);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_RMDIR, SB_SSH_FXP_RMDIR, SB_SSH_FXP_RMDIR);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_REALPATH, SB_SSH_FXP_REALPATH, SB_SSH_FXP_REALPATH);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_STAT, SB_SSH_FXP_STAT, SB_SSH_FXP_STAT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_RENAME, SB_SSH_FXP_RENAME, SB_SSH_FXP_RENAME);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_READLINK, SB_SSH_FXP_READLINK, SB_SSH_FXP_READLINK);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_SYMLINK, SB_SSH_FXP_SYMLINK, SB_SSH_FXP_SYMLINK);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_LINK, SB_SSH_FXP_LINK, SB_SSH_FXP_LINK);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_BLOCK, SB_SSH_FXP_BLOCK, SB_SSH_FXP_BLOCK);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_UNBLOCK, SB_SSH_FXP_UNBLOCK, SB_SSH_FXP_UNBLOCK);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_STATUS, SB_SSH_FXP_STATUS, SB_SSH_FXP_STATUS);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_HANDLE, SB_SSH_FXP_HANDLE, SB_SSH_FXP_HANDLE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_DATA, SB_SSH_FXP_DATA, SB_SSH_FXP_DATA);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_NAME, SB_SSH_FXP_NAME, SB_SSH_FXP_NAME);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_ATTRS, SB_SSH_FXP_ATTRS, SB_SSH_FXP_ATTRS);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_EXTENDED, SB_SSH_FXP_EXTENDED, SB_SSH_FXP_EXTENDED);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_EXTENDED_REPLY, SB_SSH_FXP_EXTENDED_REPLY, SB_SSH_FXP_EXTENDED_REPLY);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_SIZE, SB_SSH_FILEXFER_ATTR_SIZE, SB_SSH_FILEXFER_ATTR_SIZE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_UIDGID, SB_SSH_FILEXFER_ATTR_UIDGID, SB_SSH_FILEXFER_ATTR_UIDGID);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_PERMISSIONS, SB_SSH_FILEXFER_ATTR_PERMISSIONS, SB_SSH_FILEXFER_ATTR_PERMISSIONS);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_ACCESSTIME, SB_SSH_FILEXFER_ATTR_ACCESSTIME, SB_SSH_FILEXFER_ATTR_ACCESSTIME);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_ACMODTIME, SB_SSH_FILEXFER_ATTR_ACMODTIME, SB_SSH_FILEXFER_ATTR_ACMODTIME);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_CREATETIME, SB_SSH_FILEXFER_ATTR_CREATETIME, SB_SSH_FILEXFER_ATTR_CREATETIME);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_MODIFYTIME, SB_SSH_FILEXFER_ATTR_MODIFYTIME, SB_SSH_FILEXFER_ATTR_MODIFYTIME);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_ACL, SB_SSH_FILEXFER_ATTR_ACL, SB_SSH_FILEXFER_ATTR_ACL);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_OWNERGROUP, SB_SSH_FILEXFER_ATTR_OWNERGROUP, SB_SSH_FILEXFER_ATTR_OWNERGROUP);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_SUBSECOND_TIMES, SB_SSH_FILEXFER_ATTR_SUBSECOND_TIMES, SB_SSH_FILEXFER_ATTR_SUBSECOND_TIMES);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_BITS, SB_SSH_FILEXFER_ATTR_BITS, SB_SSH_FILEXFER_ATTR_BITS);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_ALLOCATION_SIZE, SB_SSH_FILEXFER_ATTR_ALLOCATION_SIZE, SB_SSH_FILEXFER_ATTR_ALLOCATION_SIZE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_TEXT_HINT, SB_SSH_FILEXFER_ATTR_TEXT_HINT, SB_SSH_FILEXFER_ATTR_TEXT_HINT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_MIME_TYPE, SB_SSH_FILEXFER_ATTR_MIME_TYPE, SB_SSH_FILEXFER_ATTR_MIME_TYPE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_LINK_COUNT, SB_SSH_FILEXFER_ATTR_LINK_COUNT, SB_SSH_FILEXFER_ATTR_LINK_COUNT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_UNTRANSLATED_NAME, SB_SSH_FILEXFER_ATTR_UNTRANSLATED_NAME, SB_SSH_FILEXFER_ATTR_UNTRANSLATED_NAME);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_CTIME, SB_SSH_FILEXFER_ATTR_CTIME, SB_SSH_FILEXFER_ATTR_CTIME);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_EXTENDED, SB_SSH_FILEXFER_ATTR_EXTENDED, SB_SSH_FILEXFER_ATTR_EXTENDED);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_V3, SB_SSH_FILEXFER_ATTR_V3, SB_SSH_FILEXFER_ATTR_V3);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_V4, SB_SSH_FILEXFER_ATTR_V4, SB_SSH_FILEXFER_ATTR_V4);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_V5, SB_SSH_FILEXFER_ATTR_V5, SB_SSH_FILEXFER_ATTR_V5);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_ATTR_V6, SB_SSH_FILEXFER_ATTR_V6, SB_SSH_FILEXFER_ATTR_V6);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_TYPE_ERRONEOUS, SB_SSH_FILEXFER_TYPE_ERRONEOUS, SB_SSH_FILEXFER_TYPE_ERRONEOUS);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_TYPE_REGULAR, SB_SSH_FILEXFER_TYPE_REGULAR, SB_SSH_FILEXFER_TYPE_REGULAR);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_TYPE_DIRECTORY, SB_SSH_FILEXFER_TYPE_DIRECTORY, SB_SSH_FILEXFER_TYPE_DIRECTORY);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_TYPE_SYMLINK, SB_SSH_FILEXFER_TYPE_SYMLINK, SB_SSH_FILEXFER_TYPE_SYMLINK);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_TYPE_SPECIAL, SB_SSH_FILEXFER_TYPE_SPECIAL, SB_SSH_FILEXFER_TYPE_SPECIAL);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_TYPE_UNKNOWN, SB_SSH_FILEXFER_TYPE_UNKNOWN, SB_SSH_FILEXFER_TYPE_UNKNOWN);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_TYPE_SOCKET, SB_SSH_FILEXFER_TYPE_SOCKET, SB_SSH_FILEXFER_TYPE_SOCKET);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_TYPE_CHAR_DEVICE, SB_SSH_FILEXFER_TYPE_CHAR_DEVICE, SB_SSH_FILEXFER_TYPE_CHAR_DEVICE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_TYPE_BLOCK_DEVICE, SB_SSH_FILEXFER_TYPE_BLOCK_DEVICE, SB_SSH_FILEXFER_TYPE_BLOCK_DEVICE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FILEXFER_TYPE_FIFO, SB_SSH_FILEXFER_TYPE_FIFO, SB_SSH_FILEXFER_TYPE_FIFO);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_READ, SB_SSH_FXF_READ, SB_SSH_FXF_READ);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_WRITE, SB_SSH_FXF_WRITE, SB_SSH_FXF_WRITE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_APPEND, SB_SSH_FXF_APPEND, SB_SSH_FXF_APPEND);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_CREAT, SB_SSH_FXF_CREAT, SB_SSH_FXF_CREAT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_TRUNC, SB_SSH_FXF_TRUNC, SB_SSH_FXF_TRUNC);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_EXCL, SB_SSH_FXF_EXCL, SB_SSH_FXF_EXCL);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_TEXT, SB_SSH_FXF_TEXT, SB_SSH_FXF_TEXT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_ACCESS_DISPOSITION, SB_SSH_FXF_ACCESS_DISPOSITION, SB_SSH_FXF_ACCESS_DISPOSITION);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_CREATE_NEW, SB_SSH_FXF_CREATE_NEW, SB_SSH_FXF_CREATE_NEW);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_CREATE_TRUNCATE, SB_SSH_FXF_CREATE_TRUNCATE, SB_SSH_FXF_CREATE_TRUNCATE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_OPEN_EXISTING, SB_SSH_FXF_OPEN_EXISTING, SB_SSH_FXF_OPEN_EXISTING);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_OPEN_OR_CREATE, SB_SSH_FXF_OPEN_OR_CREATE, SB_SSH_FXF_OPEN_OR_CREATE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_TRUNCATE_EXISTING, SB_SSH_FXF_TRUNCATE_EXISTING, SB_SSH_FXF_TRUNCATE_EXISTING);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_ACCESS_APPEND_DATA, SB_SSH_FXF_ACCESS_APPEND_DATA, SB_SSH_FXF_ACCESS_APPEND_DATA);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_ACCESS_APPEND_DATA_ATOMIC, SB_SSH_FXF_ACCESS_APPEND_DATA_ATOMIC, SB_SSH_FXF_ACCESS_APPEND_DATA_ATOMIC);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_ACCESS_TEXT_MODE, SB_SSH_FXF_ACCESS_TEXT_MODE, SB_SSH_FXF_ACCESS_TEXT_MODE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_ACCESS_READ_LOCK, SB_SSH_FXF_ACCESS_READ_LOCK, SB_SSH_FXF_ACCESS_READ_LOCK);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_ACCESS_WRITE_LOCK, SB_SSH_FXF_ACCESS_WRITE_LOCK, SB_SSH_FXF_ACCESS_WRITE_LOCK);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_ACCESS_DELETE_LOCK, SB_SSH_FXF_ACCESS_DELETE_LOCK, SB_SSH_FXF_ACCESS_DELETE_LOCK);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_ACCESS_BLOCK_READ, SB_SSH_FXF_ACCESS_BLOCK_READ, SB_SSH_FXF_ACCESS_BLOCK_READ);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_ACCESS_BLOCK_WRITE, SB_SSH_FXF_ACCESS_BLOCK_WRITE, SB_SSH_FXF_ACCESS_BLOCK_WRITE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_ACCESS_BLOCK_DELETE, SB_SSH_FXF_ACCESS_BLOCK_DELETE, SB_SSH_FXF_ACCESS_BLOCK_DELETE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_ACCESS_BLOCK_ADVISORY, SB_SSH_FXF_ACCESS_BLOCK_ADVISORY, SB_SSH_FXF_ACCESS_BLOCK_ADVISORY);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_ACCESS_NOFOLLOW, SB_SSH_FXF_ACCESS_NOFOLLOW, SB_SSH_FXF_ACCESS_NOFOLLOW);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXF_ACCESS_DELETE_ON_CLOSE, SB_SSH_FXF_ACCESS_DELETE_ON_CLOSE, SB_SSH_FXF_ACCESS_DELETE_ON_CLOSE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_OK, SB_SSH_FX_OK, SB_SSH_FX_OK);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_EOF, SB_SSH_FX_EOF, SB_SSH_FX_EOF);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_NO_SUCH_FILE, SB_SSH_FX_NO_SUCH_FILE, SB_SSH_FX_NO_SUCH_FILE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_PERMISSION_DENIED, SB_SSH_FX_PERMISSION_DENIED, SB_SSH_FX_PERMISSION_DENIED);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_FAILURE, SB_SSH_FX_FAILURE, SB_SSH_FX_FAILURE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_BAD_MESSAGE, SB_SSH_FX_BAD_MESSAGE, SB_SSH_FX_BAD_MESSAGE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_NO_CONNECTION, SB_SSH_FX_NO_CONNECTION, SB_SSH_FX_NO_CONNECTION);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_CONNECTION_LOST, SB_SSH_FX_CONNECTION_LOST, SB_SSH_FX_CONNECTION_LOST);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_OP_UNSUPPORTED, SB_SSH_FX_OP_UNSUPPORTED, SB_SSH_FX_OP_UNSUPPORTED);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_INVALID_HANDLE, SB_SSH_FX_INVALID_HANDLE, SB_SSH_FX_INVALID_HANDLE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_NO_SUCH_PATH, SB_SSH_FX_NO_SUCH_PATH, SB_SSH_FX_NO_SUCH_PATH);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_FILE_ALREADY_EXISTS, SB_SSH_FX_FILE_ALREADY_EXISTS, SB_SSH_FX_FILE_ALREADY_EXISTS);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_WRITE_PROTECT, SB_SSH_FX_WRITE_PROTECT, SB_SSH_FX_WRITE_PROTECT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_NO_MEDIA, SB_SSH_FX_NO_MEDIA, SB_SSH_FX_NO_MEDIA);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_NO_SPACE_ON_FILESYSTEM, SB_SSH_FX_NO_SPACE_ON_FILESYSTEM, SB_SSH_FX_NO_SPACE_ON_FILESYSTEM);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_QUOTA_EXCEEDED, SB_SSH_FX_QUOTA_EXCEEDED, SB_SSH_FX_QUOTA_EXCEEDED);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_UNKNOWN_PRINCIPLE, SB_SSH_FX_UNKNOWN_PRINCIPLE, SB_SSH_FX_UNKNOWN_PRINCIPLE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_LOCK_CONFlICT, SB_SSH_FX_LOCK_CONFlICT, SB_SSH_FX_LOCK_CONFlICT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_DIR_NOT_EMPTY, SB_SSH_FX_DIR_NOT_EMPTY, SB_SSH_FX_DIR_NOT_EMPTY);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_NOT_A_DIRECTORY, SB_SSH_FX_NOT_A_DIRECTORY, SB_SSH_FX_NOT_A_DIRECTORY);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_INVALID_FILENAME, SB_SSH_FX_INVALID_FILENAME, SB_SSH_FX_INVALID_FILENAME);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_LINK_LOOP, SB_SSH_FX_LINK_LOOP, SB_SSH_FX_LINK_LOOP);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_CANNOT_DELETE, SB_SSH_FX_CANNOT_DELETE, SB_SSH_FX_CANNOT_DELETE);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_INVALID_PARAMETER, SB_SSH_FX_INVALID_PARAMETER, SB_SSH_FX_INVALID_PARAMETER);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_FILE_IS_A_DIRECTORY, SB_SSH_FX_FILE_IS_A_DIRECTORY, SB_SSH_FX_FILE_IS_A_DIRECTORY);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_BYTE_RANGE_LOCK_CONFLICT, SB_SSH_FX_BYTE_RANGE_LOCK_CONFLICT, SB_SSH_FX_BYTE_RANGE_LOCK_CONFLICT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_BYTE_RANGE_LOCK_REFUSED, SB_SSH_FX_BYTE_RANGE_LOCK_REFUSED, SB_SSH_FX_BYTE_RANGE_LOCK_REFUSED);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_DELETE_PENDING, SB_SSH_FX_DELETE_PENDING, SB_SSH_FX_DELETE_PENDING);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_FILE_CORRUPT, SB_SSH_FX_FILE_CORRUPT, SB_SSH_FX_FILE_CORRUPT);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_OWNER_INVALID, SB_SSH_FX_OWNER_INVALID, SB_SSH_FX_OWNER_INVALID);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FX_GROUP_INVALID, SB_SSH_FX_GROUP_INVALID, SB_SSH_FX_GROUP_INVALID);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_FXP_REALPATH_NO_CHECK, SB_SSH_FXP_REALPATH_NO_CHECK, SB_SSH_FXP_REALPATH_NO_CHECK);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ATTR_REQUEST4, SB_SSH_ATTR_REQUEST4, SB_SSH_ATTR_REQUEST4);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ATTR_REQUEST5, SB_SSH_ATTR_REQUEST5, SB_SSH_ATTR_REQUEST5);
	SB_REGISTER_LONG_CONSTANT(SBSftpCommon, SSH_ATTR_REQUEST6, SB_SSH_ATTR_REQUEST6, SB_SSH_ATTR_REQUEST6);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_NEWLINE, SB_SSH_EXT_NEWLINE, SB_SSH_EXT_NEWLINE);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_NEWLINE_VANDYKE, SB_SSH_EXT_NEWLINE_VANDYKE, SB_SSH_EXT_NEWLINE_VANDYKE);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_SUPPORTED, SB_SSH_EXT_SUPPORTED, SB_SSH_EXT_SUPPORTED);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_SUPPORTED2, SB_SSH_EXT_SUPPORTED2, SB_SSH_EXT_SUPPORTED2);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_VERSIONS, SB_SSH_EXT_VERSIONS, SB_SSH_EXT_VERSIONS);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_VERSION_SELECT, SB_SSH_EXT_VERSION_SELECT, SB_SSH_EXT_VERSION_SELECT);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_FILENAME_CHARSET, SB_SSH_EXT_FILENAME_CHARSET, SB_SSH_EXT_FILENAME_CHARSET);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_FILENAME_TRANSLATION_CONTROL, SB_SSH_EXT_FILENAME_TRANSLATION_CONTROL, SB_SSH_EXT_FILENAME_TRANSLATION_CONTROL);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_TEXTSEEK, SB_SSH_EXT_TEXTSEEK, SB_SSH_EXT_TEXTSEEK);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_VENDOR_ID, SB_SSH_EXT_VENDOR_ID, SB_SSH_EXT_VENDOR_ID);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_CHECK_FILE, SB_SSH_EXT_CHECK_FILE, SB_SSH_EXT_CHECK_FILE);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_CHECK_FILE_HANDLE, SB_SSH_EXT_CHECK_FILE_HANDLE, SB_SSH_EXT_CHECK_FILE_HANDLE);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_CHECK_FILE_NAME, SB_SSH_EXT_CHECK_FILE_NAME, SB_SSH_EXT_CHECK_FILE_NAME);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_SPACE_AVAILABLE, SB_SSH_EXT_SPACE_AVAILABLE, SB_SSH_EXT_SPACE_AVAILABLE);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_HOME_DIRECTORY, SB_SSH_EXT_HOME_DIRECTORY, SB_SSH_EXT_HOME_DIRECTORY);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_COPY_FILE, SB_SSH_EXT_COPY_FILE, SB_SSH_EXT_COPY_FILE);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_COPY_DATA, SB_SSH_EXT_COPY_DATA, SB_SSH_EXT_COPY_DATA);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_GET_TEMP_FOLDER, SB_SSH_EXT_GET_TEMP_FOLDER, SB_SSH_EXT_GET_TEMP_FOLDER);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_MAKE_TEMP_FOLDER, SB_SSH_EXT_MAKE_TEMP_FOLDER, SB_SSH_EXT_MAKE_TEMP_FOLDER);
	SB_REGISTER_STRING_CONSTANT(SBSftpCommon, SSH_EXT_STATVFS, SB_SSH_EXT_STATVFS, SB_SSH_EXT_STATVFS);
}

void Register_SBSftpCommon_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBSftpFileOpenMode", NULL);
	TSBSftpFileOpenMode_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSftpFileOpenMode_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenMode_ce_ptr, "fmRead", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenMode_ce_ptr, "fmWrite", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenMode_ce_ptr, "fmAppend", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenMode_ce_ptr, "sfmCreate", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenMode_ce_ptr, "fmTruncate", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenMode_ce_ptr, "fmExcl", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenMode_ce_ptr, "fmText", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenMode_ce_ptr, "fmOpenOrCreate", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenMode_ce_ptr, "fmAppendAtomic", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenMode_ce_ptr, "fmNoFollow", 9)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenMode_ce_ptr, "fmDeleteOnClose", 10)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpFileOpenModes", NULL);
	TSBSftpFileOpenModes_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBSftpFileOpenModes_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenModes_ce_ptr, "fmRead", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenModes_ce_ptr, "fmWrite", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenModes_ce_ptr, "fmAppend", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenModes_ce_ptr, "sfmCreate", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenModes_ce_ptr, "fmTruncate", 16)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenModes_ce_ptr, "fmExcl", 32)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenModes_ce_ptr, "fmText", 64)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenModes_ce_ptr, "fmOpenOrCreate", 128)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenModes_ce_ptr, "fmAppendAtomic", 256)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenModes_ce_ptr, "fmNoFollow", 512)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenModes_ce_ptr, "fmDeleteOnClose", 1024)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpFileOpenAccessItem", NULL);
	TSBSftpFileOpenAccessItem_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSftpFileOpenAccessItem_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenAccessItem_ce_ptr, "faReadLock", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenAccessItem_ce_ptr, "faWriteLock", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenAccessItem_ce_ptr, "faDeleteLock", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenAccessItem_ce_ptr, "faBlockAdvisory", 3)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpFileOpenAccess", NULL);
	TSBSftpFileOpenAccess_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBSftpFileOpenAccess_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenAccess_ce_ptr, "faReadLock", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenAccess_ce_ptr, "faWriteLock", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenAccess_ce_ptr, "faDeleteLock", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOpenAccess_ce_ptr, "faBlockAdvisory", 8)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpVersion", NULL);
	TSBSftpVersion_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSftpVersion_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpVersion_ce_ptr, "sbSFTP0", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpVersion_ce_ptr, "sbSFTP1", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpVersion_ce_ptr, "sbSFTP2", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpVersion_ce_ptr, "sbSFTP3", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpVersion_ce_ptr, "sbSFTP4", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpVersion_ce_ptr, "sbSFTP5", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpVersion_ce_ptr, "sbSFTP6", 6)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpVersions", NULL);
	TSBSftpVersions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBSftpVersions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpVersions_ce_ptr, "sbSFTP0", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpVersions_ce_ptr, "sbSFTP1", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpVersions_ce_ptr, "sbSFTP2", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpVersions_ce_ptr, "sbSFTP3", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpVersions_ce_ptr, "sbSFTP4", 16)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpVersions_ce_ptr, "sbSFTP5", 32)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpVersions_ce_ptr, "sbSFTP6", 64)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpAttribute", NULL);
	TSBSftpAttribute_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSftpAttribute_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saSize", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saOwner", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saGroup", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saUID", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saGID", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saPermissions", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saATime", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saMTime", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saCTime", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saSubSeconds", 9)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saAttribBits", 10)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saACL", 11)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saExtended", 12)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saCATime", 13)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saASize", 14)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saTextHint", 15)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saMimeType", 16)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saLinkCount", 17)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttribute_ce_ptr, "saUName", 18)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpAttributes", NULL);
	TSBSftpAttributes_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBSftpAttributes_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saSize", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saOwner", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saGroup", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saUID", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saGID", 16)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saPermissions", 32)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saATime", 64)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saMTime", 128)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saCTime", 256)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saSubSeconds", 512)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saAttribBits", 1024)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saACL", 2048)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saExtended", 4096)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saCATime", 8192)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saASize", 16384)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saTextHint", 32768)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saMimeType", 65536)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saLinkCount", 131072)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpAttributes_ce_ptr, "saUName", 262144)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpRenameFlag", NULL);
	TSBSftpRenameFlag_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSftpRenameFlag_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpRenameFlag_ce_ptr, "rfOverwrite", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpRenameFlag_ce_ptr, "rfAtomic", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpRenameFlag_ce_ptr, "rfNative", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpRenameFlags", NULL);
	TSBSftpRenameFlags_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBSftpRenameFlags_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpRenameFlags_ce_ptr, "rfOverwrite", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpRenameFlags_ce_ptr, "rfAtomic", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpRenameFlags_ce_ptr, "rfNative", 4)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpTextHint", NULL);
	TSBSftpTextHint_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSftpTextHint_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpTextHint_ce_ptr, "thKnownText", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpTextHint_ce_ptr, "thGuessedText", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpTextHint_ce_ptr, "thKnownBinary", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpTextHint_ce_ptr, "thGuessedBinary", 3)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpRealpathControl", NULL);
	TSBSftpRealpathControl_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSftpRealpathControl_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpRealpathControl_ce_ptr, "rcNoCheck", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpRealpathControl_ce_ptr, "rcStatIf", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpRealpathControl_ce_ptr, "rcStatAlways", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpFileOperation", NULL);
	TSBSftpFileOperation_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSftpFileOperation_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOperation_ce_ptr, "sfoDownloadFile", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOperation_ce_ptr, "sfoUploadFile", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOperation_ce_ptr, "sfoDeleteFile", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileOperation_ce_ptr, "sfoMakeDir", 3)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpFileType", NULL);
	TSBSftpFileType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSftpFileType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileType_ce_ptr, "ftFile", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileType_ce_ptr, "ftDirectory", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileType_ce_ptr, "ftSymblink", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileType_ce_ptr, "ftSpecial", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileType_ce_ptr, "ftUnknown", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileType_ce_ptr, "ftSocket", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileType_ce_ptr, "ftCharDevice", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileType_ce_ptr, "ftBlockDevice", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpFileType_ce_ptr, "ftFIFO", 8)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpTransferDirection", NULL);
	TSBSftpTransferDirection_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSftpTransferDirection_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpTransferDirection_ce_ptr, "tdDownload", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpTransferDirection_ce_ptr, "tdUpload", 1)
	
	INIT_CLASS_ENTRY(ce, "TElSftpOperation", NULL);
	TElSftpOperation_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TElSftpOperation_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soNone", 0)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soCreateFile", 1)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soCreateSymLink", 2)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soMakeDirectory", 3)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soOpenDirectory", 4)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soOpenFile", 5)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soRead", 6)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soReadDirectory", 7)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soReadSymLink", 8)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soRemoveDirectory", 9)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soRemoveFile", 10)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soRenameFile", 11)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soRequestAbsolutePath", 12)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soRequestAttributes", 13)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soSetAttributes", 14)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soWrite", 15)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soCloseHandle", 16)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soVersion", 17)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soExtension", 18)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soCreateHardLink", 19)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soBlock", 20)
	SB_DECLARE_CLASS_LONG_CONST(TElSftpOperation_ce_ptr, "soUnblock", 21)
	
	INIT_CLASS_ENTRY(ce, "TSBSftpTransferBlockState", NULL);
	TSBSftpTransferBlockState_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSftpTransferBlockState_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpTransferBlockState_ce_ptr, "bsRequested", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpTransferBlockState_ce_ptr, "bsPostponed", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSftpTransferBlockState_ce_ptr, "bsFinished", 2)
}

void Register_SBSftpCommon_Aliases(TSRMLS_D)
{
	if (NULL == TElSftpExtendedReply_ce_ptr)
		Register_TElSftpExtendedReply(TSRMLS_C);
	zend_register_class_alias("ElSftpExtendedReply", TElSftpExtendedReply_ce_ptr);
	if (NULL == TElSftpNewlineExtension_ce_ptr)
		Register_TElSftpNewlineExtension(TSRMLS_C);
	zend_register_class_alias("ElSftpNewlineExtension", TElSftpNewlineExtension_ce_ptr);
	if (NULL == TElSftpVersionsExtension_ce_ptr)
		Register_TElSftpVersionsExtension(TSRMLS_C);
	zend_register_class_alias("ElSftpVersionsExtension", TElSftpVersionsExtension_ce_ptr);
	if (NULL == TElSftpFilenameTranslationExtension_ce_ptr)
		Register_TElSftpFilenameTranslationExtension(TSRMLS_C);
	zend_register_class_alias("ElSftpFilenameTranslationExtension", TElSftpFilenameTranslationExtension_ce_ptr);
	if (NULL == TElSftpFilenameCharsetExtension_ce_ptr)
		Register_TElSftpFilenameCharsetExtension(TSRMLS_C);
	zend_register_class_alias("ElSftpFilenameCharsetExtension", TElSftpFilenameCharsetExtension_ce_ptr);
	if (NULL == TElSftpVersionSelectExtension_ce_ptr)
		Register_TElSftpVersionSelectExtension(TSRMLS_C);
	zend_register_class_alias("ElSftpVersionSelectExtension", TElSftpVersionSelectExtension_ce_ptr);
	if (NULL == TElSftpSupportedExtension_ce_ptr)
		Register_TElSftpSupportedExtension(TSRMLS_C);
	zend_register_class_alias("ElSftpSupportedExtension", TElSftpSupportedExtension_ce_ptr);
	if (NULL == TElSftpVendorIDExtension_ce_ptr)
		Register_TElSftpVendorIDExtension(TSRMLS_C);
	zend_register_class_alias("ElSftpVendorIDExtension", TElSftpVendorIDExtension_ce_ptr);
	if (NULL == TElSftpCheckFileExtension_ce_ptr)
		Register_TElSftpCheckFileExtension(TSRMLS_C);
	zend_register_class_alias("ElSftpCheckFileExtension", TElSftpCheckFileExtension_ce_ptr);
	if (NULL == TElSftpStatvfsExtension_ce_ptr)
		Register_TElSftpStatvfsExtension(TSRMLS_C);
	zend_register_class_alias("ElSftpStatvfsExtension", TElSftpStatvfsExtension_ce_ptr);
	if (NULL == TElSftpSpaceAvailableExtension_ce_ptr)
		Register_TElSftpSpaceAvailableExtension(TSRMLS_C);
	zend_register_class_alias("ElSftpSpaceAvailableExtension", TElSftpSpaceAvailableExtension_ce_ptr);
	if (NULL == TElSftpHomeDirectoryExtension_ce_ptr)
		Register_TElSftpHomeDirectoryExtension(TSRMLS_C);
	zend_register_class_alias("ElSftpHomeDirectoryExtension", TElSftpHomeDirectoryExtension_ce_ptr);
	if (NULL == TElSftpCopyFileExtension_ce_ptr)
		Register_TElSftpCopyFileExtension(TSRMLS_C);
	zend_register_class_alias("ElSftpCopyFileExtension", TElSftpCopyFileExtension_ce_ptr);
	if (NULL == TElSftpCopyDataExtension_ce_ptr)
		Register_TElSftpCopyDataExtension(TSRMLS_C);
	zend_register_class_alias("ElSftpCopyDataExtension", TElSftpCopyDataExtension_ce_ptr);
	if (NULL == TElSftpCheckFileReply_ce_ptr)
		Register_TElSftpCheckFileReply(TSRMLS_C);
	zend_register_class_alias("ElSftpCheckFileReply", TElSftpCheckFileReply_ce_ptr);
	if (NULL == TElSftpSpaceAvailableReply_ce_ptr)
		Register_TElSftpSpaceAvailableReply(TSRMLS_C);
	zend_register_class_alias("ElSftpSpaceAvailableReply", TElSftpSpaceAvailableReply_ce_ptr);
	if (NULL == TElSftpStatVFSReply_ce_ptr)
		Register_TElSftpStatVFSReply(TSRMLS_C);
	zend_register_class_alias("ElSftpStatVFSReply", TElSftpStatVFSReply_ce_ptr);
	if (NULL == TElSftpExtendedProperties_ce_ptr)
		Register_TElSftpExtendedProperties(TSRMLS_C);
	zend_register_class_alias("ElSftpExtendedProperties", TElSftpExtendedProperties_ce_ptr);
	if (NULL == TElSftpFileAttributes_ce_ptr)
		Register_TElSftpFileAttributes(TSRMLS_C);
	zend_register_class_alias("ElSftpFileAttributes", TElSftpFileAttributes_ce_ptr);
	if (NULL == TElSftpFileInfo_ce_ptr)
		Register_TElSftpFileInfo(TSRMLS_C);
	zend_register_class_alias("ElSftpFileInfo", TElSftpFileInfo_ce_ptr);
	if (NULL == TElSftpTransferBlock_ce_ptr)
		Register_TElSftpTransferBlock(TSRMLS_C);
	zend_register_class_alias("ElSftpTransferBlock", TElSftpTransferBlock_ce_ptr);
	if (NULL == TElSftpTransferManager_ce_ptr)
		Register_TElSftpTransferManager(TSRMLS_C);
	zend_register_class_alias("ElSftpTransferManager", TElSftpTransferManager_ce_ptr);
	if (NULL == TElSftpOperation_ce_ptr)
		Register_SBSftpCommon_Enum_Flags(TSRMLS_C);
	zend_register_class_alias("ElSftpOperation", TElSftpOperation_ce_ptr);
}
