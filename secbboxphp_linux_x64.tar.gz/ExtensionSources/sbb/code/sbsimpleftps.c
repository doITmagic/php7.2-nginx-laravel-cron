#include "sbsimpleftps.h"

zend_class_entry *TSBFTPSSLState_ce_ptr = NULL;

zend_class_entry *TSBFTPTransferType_ce_ptr = NULL;

zend_class_entry *TSBFTPAuthCmd_ce_ptr = NULL;

zend_class_entry *TSBFTPProxyType_ce_ptr = NULL;

zend_class_entry *TSBFileEntryFormat_ce_ptr = NULL;

zend_class_entry *TSBFileEntryType_ce_ptr = NULL;

zend_class_entry *TSBFTPState_ce_ptr = NULL;

zend_class_entry *TSBFTPCheckMethod_ce_ptr = NULL;

zend_class_entry *TSBFTPOption_ce_ptr = NULL;

zend_class_entry *TSBFTPOptions_ce_ptr = NULL;

zend_class_entry *TSBFtpFileOperation_ce_ptr = NULL;

void SB_CALLBACK TSBFTPSTextDataEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pTextLine[], int32_t szTextLine)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zTextLine;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTextLine, 1);
	SB_ZVAL_STRINGL_DUP(zTextLine, pTextLine, szTextLine);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zTextLine);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBFTPSBinaryDataEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pData[], int32_t szData)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zData;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SB_ZVAL_STRINGL_DUP(zData, pData, szData);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBFTPSInnerClientEventRaw(void * _ObjectData, TObjectHandle Sender, TElSimpleFTPSClientHandle Client)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zClient;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zClient, 1);
	SBInitObject(zClient, TElSimpleFTPSClient_ce_ptr, Client TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zClient);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBFTPSRenegotiationRequestEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t DataChannel, int8_t * Allow)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zDataChannel;
	zval * zAllow;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zDataChannel, 1);
	ZVAL_BOOL(zDataChannel, (zend_bool)DataChannel);
	SB_EVENT_INIT_ZVAL_REF(zAllow, 2);
	ZVAL_BOOL(Z_REFVAL_P(zAllow), (zend_bool)*Allow);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zDataChannel);
	convert_to_boolean(Z_REFVAL_P(zAllow));
	*Allow = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAllow));
	SB_EVENT_CLEAR_ZVAL(zAllow);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElFTPFileOperationEventRaw(void * _ObjectData, TObjectHandle Sender, TSBFtpFileOperationRaw Operation, const char * pcRemotePath, int32_t szRemotePath, const char * pcLocalPath, int32_t szLocalPath, int8_t * Skip, int8_t * Cancel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(6);
	zval * zSender;
	zval * zOperation;
	zval * zRemotePath;
	zval * zLocalPath;
	zval * zSkip;
	zval * zCancel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOperation, 1);
	ZVAL_LONG(zOperation, (sb_zend_long)Operation);
	SB_EVENT_INIT_ZVAL(zRemotePath, 2);
	SB_ZVAL_STRINGL_DUP(zRemotePath, pcRemotePath, szRemotePath);
	SB_EVENT_INIT_ZVAL(zLocalPath, 3);
	SB_ZVAL_STRINGL_DUP(zLocalPath, pcLocalPath, szLocalPath);
	SB_EVENT_INIT_ZVAL_REF(zSkip, 4);
	ZVAL_BOOL(Z_REFVAL_P(zSkip), (zend_bool)*Skip);
	SB_EVENT_INIT_ZVAL_REF(zCancel, 5);
	ZVAL_BOOL(Z_REFVAL_P(zCancel), (zend_bool)*Cancel);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 6, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zOperation);
	SB_EVENT_CLEAR_ZVAL(zRemotePath);
	SB_EVENT_CLEAR_ZVAL(zLocalPath);
	convert_to_boolean(Z_REFVAL_P(zSkip));
	*Skip = (int8_t)SB_BVAL_P(Z_REFVAL_P(zSkip));
	SB_EVENT_CLEAR_ZVAL(zSkip);
	convert_to_boolean(Z_REFVAL_P(zCancel));
	*Cancel = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCancel));
	SB_EVENT_CLEAR_ZVAL(zCancel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TElFTPFileOperationResultEventRaw(void * _ObjectData, TObjectHandle Sender, TSBFtpFileOperationRaw Operation, const char * pcRemotePath, int32_t szRemotePath, const char * pcLocalPath, int32_t szLocalPath, int32_t ErrorCode, const char * pcComment, int32_t szComment, int8_t * Cancel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(7);
	zval * zSender;
	zval * zOperation;
	zval * zRemotePath;
	zval * zLocalPath;
	zval * zErrorCode;
	zval * zComment;
	zval * zCancel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOperation, 1);
	ZVAL_LONG(zOperation, (sb_zend_long)Operation);
	SB_EVENT_INIT_ZVAL(zRemotePath, 2);
	SB_ZVAL_STRINGL_DUP(zRemotePath, pcRemotePath, szRemotePath);
	SB_EVENT_INIT_ZVAL(zLocalPath, 3);
	SB_ZVAL_STRINGL_DUP(zLocalPath, pcLocalPath, szLocalPath);
	SB_EVENT_INIT_ZVAL(zErrorCode, 4);
	ZVAL_LONG(zErrorCode, (sb_zend_long)ErrorCode);
	SB_EVENT_INIT_ZVAL(zComment, 5);
	SB_ZVAL_STRINGL_DUP(zComment, pcComment, szComment);
	SB_EVENT_INIT_ZVAL_REF(zCancel, 6);
	ZVAL_BOOL(Z_REFVAL_P(zCancel), (zend_bool)*Cancel);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 7, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zOperation);
	SB_EVENT_CLEAR_ZVAL(zRemotePath);
	SB_EVENT_CLEAR_ZVAL(zLocalPath);
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	SB_EVENT_CLEAR_ZVAL(zComment);
	convert_to_boolean(Z_REFVAL_P(zCancel));
	*Cancel = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCancel));
	SB_EVENT_CLEAR_ZVAL(zCancel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBFTPSFileNameChangeNeededEventRaw(void * _ObjectData, TObjectHandle Sender, char * pcFileName, int32_t * szFileName, int8_t * Force)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zFileName;
	zval * zForce;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zFileName, 1);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zFileName), pcFileName, *szFileName);
	SB_EVENT_INIT_ZVAL_REF(zForce, 2);
	ZVAL_BOOL(Z_REFVAL_P(zForce), (zend_bool)*Force);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	convert_to_string(Z_REFVAL_P(zFileName));
	SBCheckError(SBSetEventReturnStringA(2, Z_STRVAL_P(Z_REFVAL_P(zFileName)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zFileName))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zFileName);
	convert_to_boolean(Z_REFVAL_P(zForce));
	*Force = (int8_t)SB_BVAL_P(Z_REFVAL_P(zForce));
	SB_EVENT_CLEAR_ZVAL(zForce);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

SB_PHP_METHOD(TSBFTPFileInfo, __construct)
{
	if (ZEND_NUM_ARGS() == 0)
	{
		php_sbb_struct * intern = Z_SBSTRUCT_P(getThis());
		intern->data = emalloc(sizeof(TSBFTPFileInfo));
		intern->len = sizeof(TSBFTPFileInfo);
		memset(intern->data, 0, sizeof(TSBFTPFileInfo));
		intern->ownData = 1;
	}
	else
		ZEND_WRONG_PARAM_COUNT();
}

SB_PHP_METHOD(TSBFTPFileInfo, getSizeOf)
{
	if (ZEND_NUM_ARGS() > 0)
		ZEND_WRONG_PARAM_COUNT();

	RETURN_LONG(sizeof(TSBFTPFileInfo));
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBBaseStruct_GetField, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBBaseStruct_SetField, 0, 0, 1)
	ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

SB_PHP_METHOD(TSBFTPFileInfo, get_FileName)
{
	SBStuctGetFieldStringA(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}

SB_PHP_METHOD(TSBFTPFileInfo, set_FileName)
{
	SBStuctSetFieldStringA(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}

SB_PHP_METHOD(TSBFTPFileInfo, get_FileSize)
{
#ifndef CPU64
	SBStuctGetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 8);
#else
	SBStuctGetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 12);
#endif
}

SB_PHP_METHOD(TSBFTPFileInfo, set_FileSize)
{
#ifndef CPU64
	SBStuctSetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 8);
#else
	SBStuctSetFieldInt64(INTERNAL_FUNCTION_PARAM_PASSTHRU, 12);
#endif
}

SB_PHP_METHOD(TSBFTPFileInfo, get_RawData)
{
#ifndef CPU64
	SBStuctGetFieldStringA(INTERNAL_FUNCTION_PARAM_PASSTHRU, 36);
#else
	SBStuctGetFieldStringA(INTERNAL_FUNCTION_PARAM_PASSTHRU, 40);
#endif
}

SB_PHP_METHOD(TSBFTPFileInfo, set_RawData)
{
#ifndef CPU64
	SBStuctSetFieldStringA(INTERNAL_FUNCTION_PARAM_PASSTHRU, 36);
#else
	SBStuctSetFieldStringA(INTERNAL_FUNCTION_PARAM_PASSTHRU, 40);
#endif
}

zend_class_entry *TSBFTPFileInfo_ce_ptr = NULL;

static zend_function_entry TSBFTPFileInfo_methods[] = {
	PHP_ME(TSBFTPFileInfo, __construct, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(TSBFTPFileInfo, getSizeOf, NULL, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TSBFTPFileInfo, get_FileName, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBFTPFileInfo, set_FileName, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBFTPFileInfo, get_FileSize, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBFTPFileInfo, set_FileSize, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBFTPFileInfo, get_RawData, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSBFTPFileInfo, set_RawData, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TSBFTPFileInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TSBFTPFileInfo_ce_ptr != NULL)
		return;
	INIT_CLASS_ENTRY(ce, "TSBFTPFileInfo", TSBFTPFileInfo_methods);
	TSBFTPFileInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseStruct_ce_ptr);
}

void SB_CALLBACK TSBFTPSBeforeParseFileListEntryRaw(void * _ObjectData, TObjectHandle Sender, const char * pcEntry, int32_t szEntry, TElFTPFileInfoHandle FileInfo, int8_t * Handled)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zEntry;
	zval * zFileInfo;
	zval * zHandled;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zEntry, 1);
	SB_ZVAL_STRINGL_DUP(zEntry, pcEntry, szEntry);
	SB_EVENT_INIT_ZVAL(zFileInfo, 2);
	SBInitObject(zFileInfo, TElFTPFileInfo_ce_ptr, FileInfo TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zHandled, 3);
	ZVAL_BOOL(Z_REFVAL_P(zHandled), (zend_bool)*Handled);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zEntry);
	SB_EVENT_CLEAR_ZVAL(zFileInfo);
	convert_to_boolean(Z_REFVAL_P(zHandled));
	*Handled = (int8_t)SB_BVAL_P(Z_REFVAL_P(zHandled));
	SB_EVENT_CLEAR_ZVAL(zHandled);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBFTPSAfterParseFileListEntryRaw(void * _ObjectData, TObjectHandle Sender, const char * pcEntry, int32_t szEntry, TElFTPFileInfoHandle FileInfo, int8_t * Success)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zEntry;
	zval * zFileInfo;
	zval * zSuccess;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zEntry, 1);
	SB_ZVAL_STRINGL_DUP(zEntry, pcEntry, szEntry);
	SB_EVENT_INIT_ZVAL(zFileInfo, 2);
	SBInitObject(zFileInfo, TElFTPFileInfo_ce_ptr, FileInfo TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zSuccess, 3);
	ZVAL_BOOL(Z_REFVAL_P(zSuccess), (zend_bool)*Success);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zEntry);
	SB_EVENT_CLEAR_ZVAL(zFileInfo);
	convert_to_boolean(Z_REFVAL_P(zSuccess));
	*Success = (int8_t)SB_BVAL_P(Z_REFVAL_P(zSuccess));
	SB_EVENT_CLEAR_ZVAL(zSuccess);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSBFTPSTransferChunkState_ce_ptr = NULL;

zend_class_entry *TElSimpleFTPSClient_ce_ptr = NULL;

SB_PHP_METHOD(TElSimpleFTPSClient, ParseFileListEntry_Inst)
{
	char *sEntry;
	sb_str_size sEntry_len;
	zval *oFileInfo;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO", &sEntry, &sEntry_len, &oFileInfo, TSBFTPFileInfo_ce_ptr) == SUCCESS) && SB_ISREF_STRUCT_P(oFileInfo))
	{
		SBCheckError(TElSimpleFTPSClient_ParseFileListEntry_1(SBGetObjectHandle(getThis() TSRMLS_CC), sEntry, (int32_t)sEntry_len, (TSBFTPFileInfo *)SBGetStructPointer(oFileInfo TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sEntry, &sEntry_len, &oFileInfo, TElFTPFileInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_ParseFileListEntry_2(SBGetObjectHandle(getThis() TSRMLS_CC), sEntry, (int32_t)sEntry_len, SBGetObjectHandle(oFileInfo TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, &\\TSBFTPFileInfo) or (string, \\TElFTPFileInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, ParseFileListEntry)
{
	char *sEntry;
	sb_str_size sEntry_len;
	zval *oFileInfo;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO", &sEntry, &sEntry_len, &oFileInfo, TSBFTPFileInfo_ce_ptr) == SUCCESS) && SB_ISREF_STRUCT_P(oFileInfo))
	{
		SBCheckError(TElSimpleFTPSClient_ParseFileListEntry(sEntry, (int32_t)sEntry_len, (TSBFTPFileInfo *)SBGetStructPointer(oFileInfo TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, &\\TSBFTPFileInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, ParseMLSDEntry_Inst)
{
	char *sEntry;
	sb_str_size sEntry_len;
	zval *oFileInfo;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO", &sEntry, &sEntry_len, &oFileInfo, TSBFTPFileInfo_ce_ptr) == SUCCESS) && SB_ISREF_STRUCT_P(oFileInfo))
	{
		SBCheckError(TElSimpleFTPSClient_ParseMLSDEntry_1(SBGetObjectHandle(getThis() TSRMLS_CC), sEntry, (int32_t)sEntry_len, (TSBFTPFileInfo *)SBGetStructPointer(oFileInfo TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sEntry, &sEntry_len, &oFileInfo, TElFTPFileInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_ParseMLSDEntry_3(SBGetObjectHandle(getThis() TSRMLS_CC), sEntry, (int32_t)sEntry_len, SBGetObjectHandle(oFileInfo TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, &\\TSBFTPFileInfo) or (string, \\TElFTPFileInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, ParseMLSDEntry)
{
	char *sEntry;
	sb_str_size sEntry_len;
	zval *oFileInfo;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO", &sEntry, &sEntry_len, &oFileInfo, TSBFTPFileInfo_ce_ptr) == SUCCESS) && SB_ISREF_STRUCT_P(oFileInfo))
	{
		SBCheckError(TElSimpleFTPSClient_ParseMLSDEntry(sEntry, (int32_t)sEntry_len, (TSBFTPFileInfo *)SBGetStructPointer(oFileInfo TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sEntry, &sEntry_len, &oFileInfo, TElFTPFileInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_ParseMLSDEntry_2(sEntry, (int32_t)sEntry_len, SBGetObjectHandle(oFileInfo TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, &\\TSBFTPFileInfo) or (string, \\TElFTPFileInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, Abort)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Abort(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, Acct)
{
	char *sAcctInfo;
	sb_str_size sAcctInfo_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAcctInfo, &sAcctInfo_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Acct(SBGetObjectHandle(getThis() TSRMLS_CC), sAcctInfo, (int32_t)sAcctInfo_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, Allocate)
{
	sb_zend_long l4Size;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Size) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Allocate(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Size) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, CDUp)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_CDUp(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, ClearCommandChannel)
{
	zend_bool bGracefulSSLClosure;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_ClearCommandChannel(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bGracefulSSLClosure) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_ClearCommandChannel_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bGracefulSSLClosure) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, Interrupt)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Interrupt(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, Close)
{
	zend_bool bSilent;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bSilent) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Close(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bSilent) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, Cwd)
{
	char *sAPath;
	sb_str_size sAPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAPath, &sAPath_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Cwd(SBGetObjectHandle(getThis() TSRMLS_CC), sAPath, (int32_t)sAPath_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, Delete)
{
	char *sAFilename;
	sb_str_size sAFilename_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAFilename, &sAFilename_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Delete(SBGetObjectHandle(getThis() TSRMLS_CC), sAFilename, (int32_t)sAFilename_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, GetCurrentDir)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_GetCurrentDir(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2032383009, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, GetServerSystem)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_GetServerSystem(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1298404546, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, MLSD)
{
	char *sPath;
	sb_str_size sPath_len;
	zval *oResultList;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_MLSD(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oResultList, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_MLSD_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oResultList TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oResultList, TList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_MLSD_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oResultList TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_MLSD_3(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sPath, &sPath_len, &oResultList, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_MLSD_4(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, SBGetObjectHandle(oResultList TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sPath, &sPath_len, &oResultList, TList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_MLSD_5(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, SBGetObjectHandle(oResultList TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (\\TElStringList) or (\\TList) or (string) or (string, \\TElStringList) or (string, \\TList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, MLST)
{
	char *sPath;
	sb_str_size sPath_len;
	zval *oFileInfo;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sPath, &sPath_len, &oFileInfo, TElFTPFileInfo_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_MLST(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, SBGetObjectHandle(oFileInfo TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElFTPFileInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, CreateCompletePath)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_CreateCompletePath(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, NOOP)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_NOOP(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, DirectoryExists)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_DirectoryExists(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, FileExists)
{
	char *sAFilename;
	sb_str_size sAFilename_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAFilename, &sAFilename_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_FileExists(SBGetObjectHandle(getThis() TSRMLS_CC), sAFilename, (int32_t)sAFilename_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, GetFileSize)
{
	char *sAFilename;
	sb_str_size sAFilename_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAFilename, &sAFilename_len) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_GetFileSize(SBGetObjectHandle(getThis() TSRMLS_CC), sAFilename, (int32_t)sAFilename_len, &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, GetFileTime)
{
	char *sAFilename;
	sb_str_size sAFilename_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAFilename, &sAFilename_len) == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_GetFileTime(SBGetObjectHandle(getThis() TSRMLS_CC), sAFilename, (int32_t)sAFilename_len, &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, SetFileTime)
{
	char *sAFilename;
	sb_str_size sAFilename_len;
	zval *dtNewDate;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO", &sAFilename, &sAFilename_len, &dtNewDate, php_date_get_date_ce()) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_SetFileTime(SBGetObjectHandle(getThis() TSRMLS_CC), sAFilename, (int32_t)sAFilename_len, SBGetDateTime(dtNewDate TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, GetRemoteChecksum)
{
	char *sAFileName;
	sb_str_size sAFileName_len;
	sb_zend_long fCheckMethod;
	sb_zend_long l8EndPoint;
	sb_zend_long l8StartPoint;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "slll", &sAFileName, &sAFileName_len, &fCheckMethod, &l8StartPoint, &l8EndPoint) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_GetRemoteChecksum(SBGetObjectHandle(getThis() TSRMLS_CC), sAFileName, (int32_t)sAFileName_len, (TSBFTPCheckMethodRaw)fCheckMethod, (int64_t)l8StartPoint, (int64_t)l8EndPoint, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-247591981, 5, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, GetLocalChecksum)
{
	char *sAFileName;
	sb_str_size sAFileName_len;
	sb_zend_long fCheckMethod;
	sb_zend_long l8EndPoint;
	sb_zend_long l8StartPoint;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "slll", &sAFileName, &sAFileName_len, &fCheckMethod, &l8StartPoint, &l8EndPoint) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_GetLocalChecksum(SBGetObjectHandle(getThis() TSRMLS_CC), sAFileName, (int32_t)sAFileName_len, (TSBFTPCheckMethodRaw)fCheckMethod, (int64_t)l8StartPoint, (int64_t)l8EndPoint, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1747557107, 5, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, GetNameList)
{
	char *sParameters;
	sb_str_size sParameters_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_GetNameList(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sParameters, &sParameters_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_GetNameList_1(SBGetObjectHandle(getThis() TSRMLS_CC), sParameters, (int32_t)sParameters_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, GetFileList)
{
	char *sParameters;
	sb_str_size sParameters_len;
	zval *oResultList;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_GetFileList(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sParameters, &sParameters_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_GetFileList_1(SBGetObjectHandle(getThis() TSRMLS_CC), sParameters, (int32_t)sParameters_len) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sParameters, &sParameters_len, &oResultList, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_GetFileList_2(SBGetObjectHandle(getThis() TSRMLS_CC), sParameters, (int32_t)sParameters_len, SBGetObjectHandle(oResultList TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!", &sParameters, &sParameters_len, &oResultList, TList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_GetFileList_3(SBGetObjectHandle(getThis() TSRMLS_CC), sParameters, (int32_t)sParameters_len, SBGetObjectHandle(oResultList TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (string) or (string, \\TElStringList) or (string, \\TList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, ListDirectory)
{
	char *sMask;
	char *sPath;
	sb_str_size sMask_len;
	sb_str_size sPath_len;
	zend_bool bCaseSensitive;
	zend_bool bIncludeDirectories;
	zend_bool bIncludeFiles;
	zend_bool bRecursive;
	zval *oListing;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!sbbb", &sPath, &sPath_len, &oListing, TList_ce_ptr, &sMask, &sMask_len, &bCaseSensitive, &bIncludeFiles, &bIncludeDirectories) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_ListDirectory(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, SBGetObjectHandle(oListing TSRMLS_CC), sMask, (int32_t)sMask_len, (int8_t)bCaseSensitive, (int8_t)bIncludeFiles, (int8_t)bIncludeDirectories) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!sbbbb", &sPath, &sPath_len, &oListing, TList_ce_ptr, &sMask, &sMask_len, &bCaseSensitive, &bIncludeFiles, &bIncludeDirectories, &bRecursive) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_ListDirectory_1(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, SBGetObjectHandle(oListing TSRMLS_CC), sMask, (int32_t)sMask_len, (int8_t)bCaseSensitive, (int8_t)bIncludeFiles, (int8_t)bIncludeDirectories, (int8_t)bRecursive) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TList, string, bool, bool, bool) or (string, \\TList, string, bool, bool, bool, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, Open)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Open(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, InternalValidate)
{
	TSBCertificateValidityRaw fValidityRaw;
	TSBCertificateValidityReasonRaw fReasonRaw;
	zval *zfReason;
	zval *zfValidity;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zfValidity, &zfReason) == SUCCESS) && Z_ISREF_P(zfValidity) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zfValidity))) && Z_ISREF_P(zfReason) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zfReason))))
	{
		fValidityRaw = (TSBCertificateValidityRaw)Z_LVAL_P(Z_REFVAL_P(zfValidity));
		fReasonRaw = (TSBCertificateValidityReasonRaw)Z_LVAL_P(Z_REFVAL_P(zfReason));
		SBCheckError(TElSimpleFTPSClient_InternalValidate(SBGetObjectHandle(getThis() TSRMLS_CC), &fValidityRaw, &fReasonRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zfValidity), (sb_zend_long)fValidityRaw);
		ZVAL_LONG(Z_REFVAL_P(zfReason), (sb_zend_long)fReasonRaw);
	}
	else
	{
		SBErrorExpectsArguments("(&integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, EstablishSSLSession)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_EstablishSSLSession(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, Login)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_Login(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(255713546, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, MakeDir)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_MakeDir(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, MountStruct)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_MountStruct(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, Receive)
{
	char *sFilename;
	sb_str_size sFilename_len;
	sb_zend_long l8EndPos;
	sb_zend_long l8StartPos;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sll", &sFilename, &sFilename_len, &l8StartPos, &l8EndPos) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Receive(SBGetObjectHandle(getThis() TSRMLS_CC), sFilename, (int32_t)sFilename_len, (int64_t)l8StartPos, (int64_t)l8EndPos) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!ll", &sFilename, &sFilename_len, &oStream, TStream_ce_ptr, &l8StartPos, &l8EndPos) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Receive_1(SBGetObjectHandle(getThis() TSRMLS_CC), sFilename, (int32_t)sFilename_len, SBGetObjectHandle(oStream TSRMLS_CC), (int64_t)l8StartPos, (int64_t)l8EndPos) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer, integer) or (string, \\TStream, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, Reinitialize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Reinitialize(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, RemoveDir)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_RemoveDir(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, Rename)
{
	char *sDestFile;
	char *sSourceFile;
	sb_str_size sDestFile_len;
	sb_str_size sSourceFile_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sSourceFile, &sSourceFile_len, &sDestFile, &sDestFile_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Rename(SBGetObjectHandle(getThis() TSRMLS_CC), sSourceFile, (int32_t)sSourceFile_len, sDestFile, (int32_t)sDestFile_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, RenegotiateCiphers)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_RenegotiateCiphers(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, SendCmd)
{
	char *sCommand;
	sb_str_size sCommand_len;
	SBArrayZValInfo aiAcceptCodes;
	SBArrayZValInfo aiIntermediateAcceptCodes;
	zval *zaAcceptCodes;
	zval *zaIntermediateAcceptCodes;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sz", &sCommand, &sCommand_len, &zaAcceptCodes) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaAcceptCodes) || SB_IS_NULL_TYPE_RP(zaAcceptCodes)))
	{
		int16_t l2OutResultRaw = 0;
		if (!SBGetInt16ArrayFromZVal(zaAcceptCodes, &aiAcceptCodes TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSimpleFTPSClient_SendCmd(SBGetObjectHandle(getThis() TSRMLS_CC), sCommand, (int32_t)sCommand_len, aiAcceptCodes.data, aiAcceptCodes.len, &l2OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAcceptCodes);
		RETURN_LONG((sb_zend_long)l2OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szz", &sCommand, &sCommand_len, &zaAcceptCodes, &zaIntermediateAcceptCodes) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaAcceptCodes) || SB_IS_NULL_TYPE_RP(zaAcceptCodes)) && (SB_IS_ARRAY_TYPE_RP(zaIntermediateAcceptCodes) || SB_IS_NULL_TYPE_RP(zaIntermediateAcceptCodes)))
	{
		int16_t l2OutResultRaw = 0;
		if (!SBGetInt16ArrayFromZVal(zaAcceptCodes, &aiAcceptCodes TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetInt16ArrayFromZVal(zaIntermediateAcceptCodes, &aiIntermediateAcceptCodes TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSimpleFTPSClient_SendCmd_1(SBGetObjectHandle(getThis() TSRMLS_CC), sCommand, (int32_t)sCommand_len, aiAcceptCodes.data, aiAcceptCodes.len, aiIntermediateAcceptCodes.data, aiIntermediateAcceptCodes.len, &l2OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAcceptCodes);
		SBFreeArrayZValInfo(&aiIntermediateAcceptCodes);
		RETURN_LONG((sb_zend_long)l2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, array of int16|NULL) or (string, array of int16|NULL, array of int16|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, Send)
{
	char *sFileName;
	sb_str_size sFileName_len;
	sb_zend_long l8EndPos;
	sb_zend_long l8RestartFrom;
	sb_zend_long l8StartPos;
	zend_bool bAppend;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!sllbl", &oStream, TStream_ce_ptr, &sFileName, &sFileName_len, &l8StartPos, &l8EndPos, &bAppend, &l8RestartFrom) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Send(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), sFileName, (int32_t)sFileName_len, (int64_t)l8StartPos, (int64_t)l8EndPos, (int8_t)bAppend, (int64_t)l8RestartFrom) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!sl", &oStream, TStream_ce_ptr, &sFileName, &sFileName_len, &l8RestartFrom) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Send_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), sFileName, (int32_t)sFileName_len, (int64_t)l8RestartFrom) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!s", &oStream, TStream_ce_ptr, &sFileName, &sFileName_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_Send_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC), sFileName, (int32_t)sFileName_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, string, integer, integer, bool, integer) or (\\TStream, string, integer) or (\\TStream, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, DownloadFile)
{
	char *sLocalFileName;
	char *sRemoteFileName;
	sb_str_size sLocalFileName_len;
	sb_str_size sRemoteFileName_len;
	sb_zend_long fMode;
	sb_zend_long l8RestartFrom;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sRemoteFileName, &sRemoteFileName_len, &sLocalFileName, &sLocalFileName_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_DownloadFile(SBGetObjectHandle(getThis() TSRMLS_CC), sRemoteFileName, (int32_t)sRemoteFileName_len, sLocalFileName, (int32_t)sLocalFileName_len) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssl", &sRemoteFileName, &sRemoteFileName_len, &sLocalFileName, &sLocalFileName_len, &fMode) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_DownloadFile_1(SBGetObjectHandle(getThis() TSRMLS_CC), sRemoteFileName, (int32_t)sRemoteFileName_len, sLocalFileName, (int32_t)sLocalFileName_len, (TSBFileTransferModeRaw)fMode) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssll", &sRemoteFileName, &sRemoteFileName_len, &sLocalFileName, &sLocalFileName_len, &fMode, &l8RestartFrom) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_DownloadFile_2(SBGetObjectHandle(getThis() TSRMLS_CC), sRemoteFileName, (int32_t)sRemoteFileName_len, sLocalFileName, (int32_t)sLocalFileName_len, (TSBFileTransferModeRaw)fMode, (int64_t)l8RestartFrom) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string) or (string, string, integer) or (string, string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, UploadFile)
{
	char *sLocalFileName;
	char *sRemoteFileName;
	sb_str_size sLocalFileName_len;
	sb_str_size sRemoteFileName_len;
	sb_zend_long fMode;
	sb_zend_long l8RestartFrom;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sLocalFileName, &sLocalFileName_len, &sRemoteFileName, &sRemoteFileName_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_UploadFile(SBGetObjectHandle(getThis() TSRMLS_CC), sLocalFileName, (int32_t)sLocalFileName_len, sRemoteFileName, (int32_t)sRemoteFileName_len) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssl", &sLocalFileName, &sLocalFileName_len, &sRemoteFileName, &sRemoteFileName_len, &fMode) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_UploadFile_1(SBGetObjectHandle(getThis() TSRMLS_CC), sLocalFileName, (int32_t)sLocalFileName_len, sRemoteFileName, (int32_t)sRemoteFileName_len, (TSBFileTransferModeRaw)fMode) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssll", &sLocalFileName, &sLocalFileName_len, &sRemoteFileName, &sRemoteFileName_len, &fMode, &l8RestartFrom) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_UploadFile_2(SBGetObjectHandle(getThis() TSRMLS_CC), sLocalFileName, (int32_t)sLocalFileName_len, sRemoteFileName, (int32_t)sRemoteFileName_len, (TSBFileTransferModeRaw)fMode, (int64_t)l8RestartFrom) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string) or (string, string, integer) or (string, string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, DownloadStream)
{
	char *sRemoteFileName;
	sb_str_size sRemoteFileName_len;
	sb_zend_long fMode;
	sb_zend_long l8RestartFrom;
	zval *oLocalStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!ll", &sRemoteFileName, &sRemoteFileName_len, &oLocalStream, TStream_ce_ptr, &fMode, &l8RestartFrom) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_DownloadStream(SBGetObjectHandle(getThis() TSRMLS_CC), sRemoteFileName, (int32_t)sRemoteFileName_len, SBGetObjectHandle(oLocalStream TSRMLS_CC), (TSBFileTransferModeRaw)fMode, (int64_t)l8RestartFrom) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TStream, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, UploadStream)
{
	char *sRemoteFileName;
	sb_str_size sRemoteFileName_len;
	sb_zend_long fMode;
	sb_zend_long l8RestartFrom;
	zval *oLocalStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!sll", &oLocalStream, TStream_ce_ptr, &sRemoteFileName, &sRemoteFileName_len, &fMode, &l8RestartFrom) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_UploadStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oLocalStream TSRMLS_CC), sRemoteFileName, (int32_t)sRemoteFileName_len, (TSBFileTransferModeRaw)fMode, (int64_t)l8RestartFrom) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, DownloadFiles)
{
	char *sLocalPath;
	char *sRemoteMask;
	char *sRemotePath;
	sb_str_size sLocalPath_len;
	sb_str_size sRemoteMask_len;
	sb_str_size sRemotePath_len;
	sb_zend_long fCaseConversion;
	sb_zend_long fCopyMode;
	sb_zend_long fMode;
	zend_bool bCaseSensitive;
	zend_bool bRecursive;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssslblb", &sRemotePath, &sRemotePath_len, &sRemoteMask, &sRemoteMask_len, &sLocalPath, &sLocalPath_len, &fMode, &bCaseSensitive, &fCaseConversion, &bRecursive) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_DownloadFiles(SBGetObjectHandle(getThis() TSRMLS_CC), sRemotePath, (int32_t)sRemotePath_len, sRemoteMask, (int32_t)sRemoteMask_len, sLocalPath, (int32_t)sLocalPath_len, (TSBFileTransferModeRaw)fMode, (int8_t)bCaseSensitive, (TSBCaseConversionRaw)fCaseConversion, (int8_t)bRecursive) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sssllblb", &sRemotePath, &sRemotePath_len, &sRemoteMask, &sRemoteMask_len, &sLocalPath, &sLocalPath_len, &fMode, &fCopyMode, &bCaseSensitive, &fCaseConversion, &bRecursive) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_DownloadFiles_1(SBGetObjectHandle(getThis() TSRMLS_CC), sRemotePath, (int32_t)sRemotePath_len, sRemoteMask, (int32_t)sRemoteMask_len, sLocalPath, (int32_t)sLocalPath_len, (TSBFileTransferModeRaw)fMode, (TSBFileCopyModeRaw)fCopyMode, (int8_t)bCaseSensitive, (TSBCaseConversionRaw)fCaseConversion, (int8_t)bRecursive) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, string, integer, bool, integer, bool) or (string, string, string, integer, integer, bool, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, UploadFiles)
{
	char *sLocalMask;
	char *sLocalPath;
	char *sRemotePath;
	sb_str_size sLocalMask_len;
	sb_str_size sLocalPath_len;
	sb_str_size sRemotePath_len;
	sb_zend_long fCaseConversion;
	sb_zend_long fCopyMode;
	sb_zend_long fMode;
	zend_bool bCaseSensitive;
	zend_bool bRecursive;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssslblb", &sLocalPath, &sLocalPath_len, &sLocalMask, &sLocalMask_len, &sRemotePath, &sRemotePath_len, &fMode, &bCaseSensitive, &fCaseConversion, &bRecursive) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_UploadFiles(SBGetObjectHandle(getThis() TSRMLS_CC), sLocalPath, (int32_t)sLocalPath_len, sLocalMask, (int32_t)sLocalMask_len, sRemotePath, (int32_t)sRemotePath_len, (TSBFileTransferModeRaw)fMode, (int8_t)bCaseSensitive, (TSBCaseConversionRaw)fCaseConversion, (int8_t)bRecursive) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sssllblb", &sLocalPath, &sLocalPath_len, &sLocalMask, &sLocalMask_len, &sRemotePath, &sRemotePath_len, &fMode, &fCopyMode, &bCaseSensitive, &fCaseConversion, &bRecursive) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_UploadFiles_1(SBGetObjectHandle(getThis() TSRMLS_CC), sLocalPath, (int32_t)sLocalPath_len, sLocalMask, (int32_t)sLocalMask_len, sRemotePath, (int32_t)sRemotePath_len, (TSBFileTransferModeRaw)fMode, (TSBFileCopyModeRaw)fCopyMode, (int8_t)bCaseSensitive, (TSBCaseConversionRaw)fCaseConversion, (int8_t)bRecursive) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, string, integer, bool, integer, bool) or (string, string, string, integer, integer, bool, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, RemoveFile)
{
	char *sFilename;
	sb_str_size sFilename_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sFilename, &sFilename_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_RemoveFile(SBGetObjectHandle(getThis() TSRMLS_CC), sFilename, (int32_t)sFilename_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, RemoveFiles)
{
	char *sMask;
	char *sPath;
	sb_str_size sMask_len;
	sb_str_size sPath_len;
	zend_bool bCaseSensitive;
	zend_bool bRecursive;
	zval *oList;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssbb", &sPath, &sPath_len, &sMask, &sMask_len, &bCaseSensitive, &bRecursive) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_RemoveFiles(SBGetObjectHandle(getThis() TSRMLS_CC), sPath, (int32_t)sPath_len, sMask, (int32_t)sMask_len, (int8_t)bCaseSensitive, (int8_t)bRecursive) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oList, TStrings_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_RemoveFiles_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oList TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, bool, bool) or (\\TStrings)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_CipherSuite)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_CipherSuite(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_CompressionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_CompressionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_CipherSuites)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_CipherSuites(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_CipherSuites)
{
	sb_zend_long u1Index;
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &u1Index, &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_CipherSuites(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_CipherSuitePriorities)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_CipherSuitePriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_CipherSuitePriorities)
{
	sb_zend_long l4Value;
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &u1Index, &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_CipherSuitePriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_CompressionAlgorithms)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_CompressionAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_CompressionAlgorithms)
{
	sb_zend_long u1Index;
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &u1Index, &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_CompressionAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_Version)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBVersionRaw fOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_Version(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_Active)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_Active(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_LastReceivedReply)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_LastReceivedReply(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-818627235, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ModeZSupported)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ModeZSupported(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ExtMLSTSupported)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ExtMLSTSupported(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ExtMDTMSupported)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ExtMDTMSupported(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ExtMFMTSupported)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ExtMFMTSupported(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ExtSIZESupported)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ExtSIZESupported(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ExtRESTSupported)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ExtRESTSupported(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ExtXCRCSupported)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ExtXCRCSupported(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ExtXMD5Supported)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ExtXMD5Supported(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ExtXSHA1Supported)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ExtXSHA1Supported(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ExtOPTSUTF8Supported)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ExtOPTSUTF8Supported(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ExtHOSTSupported)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ExtHOSTSupported(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_LocalNewLineConvention)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSimpleFTPSClient_get_LocalNewLineConvention(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(882766964, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_LocalNewLineConvention)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSimpleFTPSClient_set_LocalNewLineConvention(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_UsingIPv6)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_UsingIPv6(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_WebTunnelResult)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_WebTunnelResult(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_RemoteHost)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_RemoteHost(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1015321373, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_RemoteIP)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_RemoteIP(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1242497806, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_TotalBytesSent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_TotalBytesSent(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_TotalBytesReceived)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_TotalBytesReceived(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_TotalDataBytesSent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_TotalDataBytesSent(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_TotalDataBytesReceived)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_TotalDataBytesReceived(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_Socket)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_Socket(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSocket_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_DataSocket)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_DataSocket(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSocket_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_Address)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_Address(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(635392723, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_Address)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_Address(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_AuthCmd)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPAuthCmdRaw fOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_AuthCmd(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_AuthCmd)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_AuthCmd(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBFTPAuthCmdRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_Port)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_Port(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_Port)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_Port(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_Username)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_Username(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1357821921, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_Username)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_Username(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1653409981, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_VirtualHostName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_VirtualHostName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1647604136, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_VirtualHostName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_VirtualHostName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_AccountInfo)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_AccountInfo(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1463264154, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_AccountInfo)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_AccountInfo(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_PassiveMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_PassiveMode(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_PassiveMode)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_PassiveMode(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_SRPUsername)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_SRPUsername(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1763552254, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_SRPUsername)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_SRPUsername(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_SRPPassword)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_SRPPassword(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1534989472, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_SRPPassword)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_SRPPassword(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_TransferType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPTransferTypeRaw fOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_TransferType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_TransferType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_TransferType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBFTPTransferTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_UseIPv6)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_UseIPv6(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_UseIPv6)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_UseIPv6(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_UseSSL)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_UseSSL(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_UseSSL)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_UseSSL(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ModeZ)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ModeZ(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_ModeZ)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_ModeZ(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ModeZLevel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ModeZLevel(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_ModeZLevel)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_ModeZLevel(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_Versions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBVersionsRaw fOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_Versions(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_Versions)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_Versions(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBVersionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_CertStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_CertStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ClientCertStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_ClientCertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_ClientCertStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_ClientCertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_SSLMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSSLModeRaw fOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_SSLMode(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_SSLMode)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_SSLMode(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSSLModeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_EncryptDataChannel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_EncryptDataChannel(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_EncryptDataChannel)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_EncryptDataChannel(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_FTPBufferSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_FTPBufferSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_FTPBufferSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_FTPBufferSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_FTPTextBufferSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_FTPTextBufferSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_FTPTextBufferSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_FTPTextBufferSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_FTPWriteBufferSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_FTPWriteBufferSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_FTPWriteBufferSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_FTPWriteBufferSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ProxySettings)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_ProxySettings(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElFTPProxySettings_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_ProxySettings)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElFTPProxySettings_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_ProxySettings(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElFTPProxySettings)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_SocketSettings)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_SocketSettings(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSocketSettings_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_SocketTimeout)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_SocketTimeout(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_SocketTimeout)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_SocketTimeout(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_TransferTimeout)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_TransferTimeout(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_TransferTimeout)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_TransferTimeout(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_CtlPollInterval)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_CtlPollInterval(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_CtlPollInterval)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_CtlPollInterval(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_Extensions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_Extensions(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElClientSSLExtensions_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_PeerExtensions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_PeerExtensions(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomSSLExtensions_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_CommandSocketBinding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_CommandSocketBinding(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElClientSocketBinding_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_CommandSocketBinding)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElClientSocketBinding_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_CommandSocketBinding(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElClientSocketBinding)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_DataSocketBinding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_DataSocketBinding(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElClientSocketBinding_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_DataSocketBinding)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElClientSocketBinding_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_DataSocketBinding(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElClientSocketBinding)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_FileSystemAdapter)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_FileSystemAdapter(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomFileSystemAdapter_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_FileSystemAdapter)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomFileSystemAdapter_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_FileSystemAdapter(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomFileSystemAdapter)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_PortKnock)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_PortKnock(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPortKnock_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_PortKnock)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPortKnock_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_PortKnock(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPortKnock)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_TransferKeepAliveInterval)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_TransferKeepAliveInterval(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_TransferKeepAliveInterval)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_TransferKeepAliveInterval(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ListenTimeout)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ListenTimeout(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_ListenTimeout)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_ListenTimeout(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_UseSIZECmd)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_UseSIZECmd(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_UseSIZECmd)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_UseSIZECmd(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_UseFEATCmd)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_UseFEATCmd(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_UseFEATCmd)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_UseFEATCmd(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_AdjustPasvAddress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_AdjustPasvAddress(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_AdjustPasvAddress)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_AdjustPasvAddress(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_UseSSLSessionResumption)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_UseSSLSessionResumption(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_UseSSLSessionResumption)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_UseSSLSessionResumption(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_RenegotiationAttackPreventionMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBRenegotiationAttackPreventionModeRaw fOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_RenegotiationAttackPreventionMode(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_RenegotiationAttackPreventionMode)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_RenegotiationAttackPreventionMode(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBRenegotiationAttackPreventionModeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_IncomingSpeedLimit)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_IncomingSpeedLimit(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_IncomingSpeedLimit)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_IncomingSpeedLimit(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OutgoingSpeedLimit)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_OutgoingSpeedLimit(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OutgoingSpeedLimit)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_OutgoingSpeedLimit(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_ConcurrentConnections)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_ConcurrentConnections(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_ConcurrentConnections)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_ConcurrentConnections(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_MinSizeForConcurrentDownload)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_MinSizeForConcurrentDownload(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_MinSizeForConcurrentDownload)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_MinSizeForConcurrentDownload(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_Options)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_Options(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_Options)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_Options(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBFTPOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_SSLOptions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSSLOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_SSLOptions(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_SSLOptions)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_SSLOptions(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSSLOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_QuoteParameters)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBParamQuoteModeRaw fOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_QuoteParameters(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_QuoteParameters)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_QuoteParameters(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBParamQuoteModeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_QuoteParamChar)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char cOutResult = '\0';
		SBCheckError(TElSimpleFTPSClient_get_QuoteParamChar(SBGetObjectHandle(getThis() TSRMLS_CC), &cOutResult) TSRMLS_CC);
		SB_RETURN_STRINGL_DUP(&cOutResult, 1);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_QuoteParamChar)
{
	char *cValue;
	sb_str_size cValue_len;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &cValue, &cValue_len) == SUCCESS) && (1 == cValue_len))
	{
		SBCheckError(TElSimpleFTPSClient_set_QuoteParamChar(SBGetObjectHandle(getThis() TSRMLS_CC), cValue[0]) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(char)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_SocksAuthentication)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElSocksAuthenticationRaw fOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_SocksAuthentication(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_SocksAuthentication)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_SocksAuthentication(SBGetObjectHandle(getThis() TSRMLS_CC), (TElSocksAuthenticationRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_SocksPassword)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_SocksPassword(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1217547012, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_SocksPassword)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_SocksPassword(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_SocksPort)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_SocksPort(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_SocksPort)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_SocksPort(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_SocksResolveAddress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_SocksResolveAddress(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_SocksResolveAddress)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_SocksResolveAddress(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_SocksServer)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_SocksServer(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1000661523, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_SocksServer)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_SocksServer(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_SocksUserCode)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_SocksUserCode(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(202041862, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_SocksUserCode)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_SocksUserCode(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_SocksVersion)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElSocksVersionRaw fOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_SocksVersion(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_SocksVersion)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_SocksVersion(SBGetObjectHandle(getThis() TSRMLS_CC), (TElSocksVersionRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_SocksUseIPv6)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_SocksUseIPv6(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_SocksUseIPv6)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_SocksUseIPv6(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_UseSocks)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_UseSocks(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_UseSocks)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_UseSocks(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_UseWebTunneling)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_UseWebTunneling(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_UseWebTunneling)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_UseWebTunneling(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_WebTunnelAddress)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_WebTunnelAddress(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1569543306, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_WebTunnelAddress)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_WebTunnelAddress(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_WebTunnelAuthentication)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElWebTunnelAuthenticationRaw fOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_WebTunnelAuthentication(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_WebTunnelAuthentication)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_WebTunnelAuthentication(SBGetObjectHandle(getThis() TSRMLS_CC), (TElWebTunnelAuthenticationRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_WebTunnelPassword)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_WebTunnelPassword(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-994643421, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_WebTunnelPassword)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_WebTunnelPassword(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_WebTunnelPort)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_WebTunnelPort(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_WebTunnelPort)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_WebTunnelPort(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_WebTunnelUserId)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_WebTunnelUserId(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1560512067, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_WebTunnelUserId)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_WebTunnelUserId(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_WebTunnelRequestHeaders)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_WebTunnelRequestHeaders(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_WebTunnelResponseHeaders)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_WebTunnelResponseHeaders(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_WebTunnelResponseBody)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_WebTunnelResponseBody(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-352986738, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_UseProxySettingsForDataChannel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_UseProxySettingsForDataChannel(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_UseProxySettingsForDataChannel)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_UseProxySettingsForDataChannel(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_PreserveExistingFileTimes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_PreserveExistingFileTimes(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_PreserveExistingFileTimes)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_PreserveExistingFileTimes(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_CopyEmptyDirs)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_CopyEmptyDirs(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_CopyEmptyDirs)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_CopyEmptyDirs(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_DeleteFailedDownloads)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_DeleteFailedDownloads(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_DeleteFailedDownloads)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_DeleteFailedDownloads(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_RemoteCharset)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_RemoteCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1675107945, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_RemoteCharset)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_RemoteCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_LocalCharset)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSimpleFTPSClient_get_LocalCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1453062872, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_LocalCharset)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_LocalCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_DNS)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_DNS(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElDNSSettings_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_DNS)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElDNSSettings_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_DNS(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElDNSSettings)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OperationErrorHandling)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOperationErrorHandlingRaw fOutResultRaw = 0;
		SBCheckError(TElSimpleFTPSClient_get_OperationErrorHandling(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OperationErrorHandling)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSimpleFTPSClient_set_OperationErrorHandling(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBOperationErrorHandlingRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnTextDataLine)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPSTextDataEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnTextDataLine(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnTextDataLine)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnTextDataLine(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBFTPSTextDataEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBFTPSTextDataEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnBinaryData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPSBinaryDataEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnBinaryData(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnBinaryData)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnBinaryData(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBFTPSBinaryDataEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBFTPSBinaryDataEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnCertificateValidate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCertificateValidateEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnCertificateValidate(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnCertificateValidate)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnCertificateValidate(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCertificateValidateEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCertificateValidateEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnCertificateNeededEx)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCertificateNeededExEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnCertificateNeededEx(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnCertificateNeededEx)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnCertificateNeededEx(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCertificateNeededExEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCertificateNeededExEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnCiphersNegotiated)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnCiphersNegotiated(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnCiphersNegotiated)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnCiphersNegotiated(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnSSLError)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBErrorEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnSSLError(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnSSLError)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnSSLError(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBErrorEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBErrorEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnCertificateStatus)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCertificateStatusEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnCertificateStatus(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnCertificateStatus)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnCertificateStatus(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCertificateStatusEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCertificateStatusEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnExtensionsReceived)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBExtensionsReceivedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnExtensionsReceived(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnExtensionsReceived)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnExtensionsReceived(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBExtensionsReceivedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBExtensionsReceivedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnExtensionsPrepared)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBExtensionsPreparedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnExtensionsPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnExtensionsPrepared)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnExtensionsPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBExtensionsPreparedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBExtensionsPreparedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnKeyNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBClientKeyNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnKeyNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnKeyNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnKeyNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBClientKeyNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBClientKeyNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnRenegotiationRequest)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPSRenegotiationRequestEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnRenegotiationRequest(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnRenegotiationRequest)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnRenegotiationRequest(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBFTPSRenegotiationRequestEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBFTPSRenegotiationRequestEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnProgress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBProgressEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnProgress)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBProgressEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBProgressEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnControlSend)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPSTextDataEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnControlSend(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnControlSend)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnControlSend(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBFTPSTextDataEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBFTPSTextDataEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnControlReceive)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPSTextDataEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnControlReceive(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnControlReceive)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnControlReceive(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBFTPSTextDataEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBFTPSTextDataEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnInnerClientCreated)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPSInnerClientEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnInnerClientCreated(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnInnerClientCreated)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnInnerClientCreated(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBFTPSInnerClientEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBFTPSInnerClientEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnInnerClientLoggedIn)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPSInnerClientEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnInnerClientLoggedIn(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnInnerClientLoggedIn)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnInnerClientLoggedIn(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBFTPSInnerClientEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBFTPSInnerClientEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnInnerClientDestroyed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPSInnerClientEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnInnerClientDestroyed(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnInnerClientDestroyed)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnInnerClientDestroyed(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBFTPSInnerClientEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBFTPSInnerClientEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnDNSKeyNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDNSKeyNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnDNSKeyNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnDNSKeyNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnDNSKeyNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDNSKeyNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDNSKeyNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnDNSKeyValidate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDNSKeyValidateEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnDNSKeyValidate(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnDNSKeyValidate)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnDNSKeyValidate(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDNSKeyValidateEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDNSKeyValidateEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnDNSResolve)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDNSResolveEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnDNSResolve(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnDNSResolve)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnDNSResolve(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDNSResolveEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDNSResolveEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnFileOperation)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElFTPFileOperationEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnFileOperation(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnFileOperation)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnFileOperation(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TElFTPFileOperationEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElFTPFileOperationEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnFileOperationResult)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElFTPFileOperationResultEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnFileOperationResult(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnFileOperationResult)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnFileOperationResult(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TElFTPFileOperationResultEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElFTPFileOperationResultEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnFileNameChangeNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPSFileNameChangeNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnFileNameChangeNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnFileNameChangeNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnFileNameChangeNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBFTPSFileNameChangeNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBFTPSFileNameChangeNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnBeforeParseFileListEntry)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPSBeforeParseFileListEntry pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnBeforeParseFileListEntry(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnBeforeParseFileListEntry)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnBeforeParseFileListEntry(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBFTPSBeforeParseFileListEntryRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBFTPSBeforeParseFileListEntry|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, get_OnAfterParseFileListEntry)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPSAfterParseFileListEntry pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_get_OnAfterParseFileListEntry(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, set_OnAfterParseFileListEntry)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSimpleFTPSClient_set_OnAfterParseFileListEntry(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBFTPSAfterParseFileListEntryRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBFTPSAfterParseFileListEntry|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSimpleFTPSClient, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSimpleFTPSClient_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_ParseFileListEntry_Inst, 0, 0, 2)
	ZEND_ARG_INFO(0, Entry)
	ZEND_ARG_TYPE_INFO(1, FileInfo, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_ParseFileListEntry, 0, 0, 2)
	ZEND_ARG_INFO(0, Entry)
	ZEND_ARG_OBJ_INFO(1, FileInfo, TSBFTPFileInfo, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_ParseMLSDEntry_Inst, 0, 0, 2)
	ZEND_ARG_INFO(0, Entry)
	ZEND_ARG_TYPE_INFO(1, FileInfo, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_ParseMLSDEntry, 0, 0, 2)
	ZEND_ARG_INFO(0, Entry)
	ZEND_ARG_TYPE_INFO(1, FileInfo, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_Abort, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_Acct, 0, 0, 1)
	ZEND_ARG_INFO(0, AcctInfo)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_Allocate, 0, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_CDUp, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_ClearCommandChannel, 0, 0, 0)
	ZEND_ARG_INFO(0, GracefulSSLClosure)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_Interrupt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_Close, 0, 0, 1)
	ZEND_ARG_INFO(0, Silent)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_Cwd, 0, 0, 1)
	ZEND_ARG_INFO(0, APath)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_Delete, 0, 0, 1)
	ZEND_ARG_INFO(0, AFilename)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_GetCurrentDir, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_GetServerSystem, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_MLSD, 0, 0, 0)
	ZEND_ARG_TYPE_INFO(0, ResultList_or_Path, 0, 1)
	ZEND_ARG_TYPE_INFO(0, ResultList, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_MLST, 0, 0, 2)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_OBJ_INFO(0, FileInfo, TElFTPFileInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_CreateCompletePath, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_NOOP, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_DirectoryExists, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_FileExists, 0, 0, 1)
	ZEND_ARG_INFO(0, AFilename)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_GetFileSize, 0, 0, 1)
	ZEND_ARG_INFO(0, AFilename)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_GetFileTime, 0, 0, 1)
	ZEND_ARG_INFO(0, AFilename)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_SetFileTime, 0, 0, 2)
	ZEND_ARG_INFO(0, AFilename)
	ZEND_ARG_OBJ_INFO(0, NewDate, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_GetRemoteChecksum, 0, 0, 4)
	ZEND_ARG_INFO(0, AFileName)
	ZEND_ARG_INFO(0, CheckMethod)
	ZEND_ARG_INFO(0, StartPoint)
	ZEND_ARG_INFO(0, EndPoint)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_GetLocalChecksum, 0, 0, 4)
	ZEND_ARG_INFO(0, AFileName)
	ZEND_ARG_INFO(0, CheckMethod)
	ZEND_ARG_INFO(0, StartPoint)
	ZEND_ARG_INFO(0, EndPoint)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_GetNameList, 0, 0, 0)
	ZEND_ARG_INFO(0, Parameters)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_GetFileList, 0, 0, 0)
	ZEND_ARG_INFO(0, Parameters)
	ZEND_ARG_TYPE_INFO(0, ResultList, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_ListDirectory, 0, 0, 6)
	ZEND_ARG_INFO(0, Path)
	ZEND_ARG_OBJ_INFO(0, Listing, TList, 1)
	ZEND_ARG_INFO(0, Mask)
	ZEND_ARG_INFO(0, CaseSensitive)
	ZEND_ARG_INFO(0, IncludeFiles)
	ZEND_ARG_INFO(0, IncludeDirectories)
	ZEND_ARG_INFO(0, Recursive)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_Open, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_InternalValidate, 0, 0, 2)
	ZEND_ARG_INFO(1, Validity)
	ZEND_ARG_INFO(1, Reason)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_EstablishSSLSession, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_Login, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_MakeDir, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_MountStruct, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_Receive, 0, 0, 3)
	ZEND_ARG_INFO(0, Filename)
	ZEND_ARG_TYPE_INFO(0, StartPos_or_Stream, 0, 1)
	ZEND_ARG_INFO(0, EndPos_or_StartPos)
	ZEND_ARG_INFO(0, EndPos)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_Reinitialize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_RemoveDir, 0, 0, 1)
	ZEND_ARG_INFO(0, Path)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_Rename, 0, 0, 2)
	ZEND_ARG_INFO(0, SourceFile)
	ZEND_ARG_INFO(0, DestFile)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_RenegotiateCiphers, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_SendCmd, 0, 0, 2)
	ZEND_ARG_INFO(0, Command)
	ZEND_ARG_ARRAY_INFO(0, AcceptCodes, 1)
	ZEND_ARG_ARRAY_INFO(0, IntermediateAcceptCodes, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_Send, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, FileName)
	ZEND_ARG_INFO(0, StartPos_or_RestartFrom)
	ZEND_ARG_INFO(0, EndPos)
	ZEND_ARG_INFO(0, Append)
	ZEND_ARG_INFO(0, RestartFrom)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_DownloadFile, 0, 0, 2)
	ZEND_ARG_INFO(0, RemoteFileName)
	ZEND_ARG_INFO(0, LocalFileName)
	ZEND_ARG_INFO(0, Mode)
	ZEND_ARG_INFO(0, RestartFrom)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_UploadFile, 0, 0, 2)
	ZEND_ARG_INFO(0, LocalFileName)
	ZEND_ARG_INFO(0, RemoteFileName)
	ZEND_ARG_INFO(0, Mode)
	ZEND_ARG_INFO(0, RestartFrom)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_DownloadStream, 0, 0, 4)
	ZEND_ARG_INFO(0, RemoteFileName)
	ZEND_ARG_OBJ_INFO(0, LocalStream, TStream, 1)
	ZEND_ARG_INFO(0, Mode)
	ZEND_ARG_INFO(0, RestartFrom)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_UploadStream, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, LocalStream, TStream, 1)
	ZEND_ARG_INFO(0, RemoteFileName)
	ZEND_ARG_INFO(0, Mode)
	ZEND_ARG_INFO(0, RestartFrom)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_DownloadFiles, 0, 0, 7)
	ZEND_ARG_INFO(0, RemotePath)
	ZEND_ARG_INFO(0, RemoteMask)
	ZEND_ARG_INFO(0, LocalPath)
	ZEND_ARG_INFO(0, Mode)
	ZEND_ARG_INFO(0, CaseSensitive_or_CopyMode)
	ZEND_ARG_INFO(0, CaseConversion_or_CaseSensitive)
	ZEND_ARG_INFO(0, Recursive_or_CaseConversion)
	ZEND_ARG_INFO(0, Recursive)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_UploadFiles, 0, 0, 7)
	ZEND_ARG_INFO(0, LocalPath)
	ZEND_ARG_INFO(0, LocalMask)
	ZEND_ARG_INFO(0, RemotePath)
	ZEND_ARG_INFO(0, Mode)
	ZEND_ARG_INFO(0, CaseSensitive_or_CopyMode)
	ZEND_ARG_INFO(0, CaseConversion_or_CaseSensitive)
	ZEND_ARG_INFO(0, Recursive_or_CaseConversion)
	ZEND_ARG_INFO(0, Recursive)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_RemoveFile, 0, 0, 1)
	ZEND_ARG_INFO(0, Filename)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_RemoveFiles, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Path_or_List, 0, 1)
	ZEND_ARG_INFO(0, Mask)
	ZEND_ARG_INFO(0, CaseSensitive)
	ZEND_ARG_INFO(0, Recursive)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_CipherSuite, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_CompressionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_CipherSuites, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_CipherSuites, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_CipherSuitePriorities, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_CipherSuitePriorities, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_CompressionAlgorithms, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_CompressionAlgorithms, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_Version, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_Active, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_LastReceivedReply, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ModeZSupported, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ExtMLSTSupported, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ExtMDTMSupported, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ExtMFMTSupported, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ExtSIZESupported, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ExtRESTSupported, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ExtXCRCSupported, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ExtXMD5Supported, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ExtXSHA1Supported, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ExtOPTSUTF8Supported, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ExtHOSTSupported, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_LocalNewLineConvention, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_LocalNewLineConvention, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_UsingIPv6, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_WebTunnelResult, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_RemoteHost, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_RemoteIP, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_TotalBytesSent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_TotalBytesReceived, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_TotalDataBytesSent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_TotalDataBytesReceived, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_Socket, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_DataSocket, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_Address, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_Address, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_AuthCmd, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_AuthCmd, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_Port, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_Port, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_Username, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_Username, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_VirtualHostName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_VirtualHostName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_AccountInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_AccountInfo, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_PassiveMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_PassiveMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_SRPUsername, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_SRPUsername, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_SRPPassword, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_SRPPassword, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_TransferType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_TransferType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_UseIPv6, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_UseIPv6, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_UseSSL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_UseSSL, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ModeZ, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_ModeZ, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ModeZLevel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_ModeZLevel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_Versions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_Versions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_CertStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_CertStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ClientCertStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_ClientCertStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_SSLMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_SSLMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_EncryptDataChannel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_EncryptDataChannel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_FTPBufferSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_FTPBufferSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_FTPTextBufferSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_FTPTextBufferSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_FTPWriteBufferSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_FTPWriteBufferSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ProxySettings, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_ProxySettings, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElFTPProxySettings, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_SocketSettings, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_SocketTimeout, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_SocketTimeout, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_TransferTimeout, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_TransferTimeout, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_CtlPollInterval, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_CtlPollInterval, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_Extensions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_PeerExtensions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_CommandSocketBinding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_CommandSocketBinding, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElClientSocketBinding, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_DataSocketBinding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_DataSocketBinding, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElClientSocketBinding, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_FileSystemAdapter, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_FileSystemAdapter, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomFileSystemAdapter, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_PortKnock, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_PortKnock, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPortKnock, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_TransferKeepAliveInterval, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_TransferKeepAliveInterval, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ListenTimeout, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_ListenTimeout, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_UseSIZECmd, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_UseSIZECmd, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_UseFEATCmd, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_UseFEATCmd, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_AdjustPasvAddress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_AdjustPasvAddress, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_UseSSLSessionResumption, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_UseSSLSessionResumption, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_RenegotiationAttackPreventionMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_RenegotiationAttackPreventionMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_IncomingSpeedLimit, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_IncomingSpeedLimit, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OutgoingSpeedLimit, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OutgoingSpeedLimit, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_ConcurrentConnections, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_ConcurrentConnections, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_MinSizeForConcurrentDownload, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_MinSizeForConcurrentDownload, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_Options, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_Options, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_SSLOptions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_SSLOptions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_QuoteParameters, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_QuoteParameters, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_QuoteParamChar, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_QuoteParamChar, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_SocksAuthentication, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_SocksAuthentication, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_SocksPassword, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_SocksPassword, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_SocksPort, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_SocksPort, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_SocksResolveAddress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_SocksResolveAddress, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_SocksServer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_SocksServer, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_SocksUserCode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_SocksUserCode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_SocksVersion, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_SocksVersion, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_SocksUseIPv6, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_SocksUseIPv6, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_UseSocks, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_UseSocks, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_UseWebTunneling, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_UseWebTunneling, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_WebTunnelAddress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_WebTunnelAddress, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_WebTunnelAuthentication, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_WebTunnelAuthentication, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_WebTunnelPassword, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_WebTunnelPassword, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_WebTunnelPort, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_WebTunnelPort, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_WebTunnelUserId, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_WebTunnelUserId, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_WebTunnelRequestHeaders, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_WebTunnelResponseHeaders, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_WebTunnelResponseBody, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_UseProxySettingsForDataChannel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_UseProxySettingsForDataChannel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_PreserveExistingFileTimes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_PreserveExistingFileTimes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_CopyEmptyDirs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_CopyEmptyDirs, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_DeleteFailedDownloads, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_DeleteFailedDownloads, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_RemoteCharset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_RemoteCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_LocalCharset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_LocalCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_DNS, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_DNS, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElDNSSettings, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OperationErrorHandling, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OperationErrorHandling, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnTextDataLine, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnTextDataLine, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnBinaryData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnBinaryData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnCertificateValidate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnCertificateValidate, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnCertificateNeededEx, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnCertificateNeededEx, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnCiphersNegotiated, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnCiphersNegotiated, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnSSLError, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnSSLError, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnCertificateStatus, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnCertificateStatus, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnExtensionsReceived, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnExtensionsReceived, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnExtensionsPrepared, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnExtensionsPrepared, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnKeyNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnKeyNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnRenegotiationRequest, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnRenegotiationRequest, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnProgress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnProgress, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnControlSend, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnControlSend, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnControlReceive, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnControlReceive, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnInnerClientCreated, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnInnerClientCreated, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnInnerClientLoggedIn, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnInnerClientLoggedIn, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnInnerClientDestroyed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnInnerClientDestroyed, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnDNSKeyNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnDNSKeyNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnDNSKeyValidate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnDNSKeyValidate, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnDNSResolve, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnDNSResolve, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnFileOperation, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnFileOperation, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnFileOperationResult, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnFileOperationResult, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnFileNameChangeNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnFileNameChangeNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnBeforeParseFileListEntry, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnBeforeParseFileListEntry, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_get_OnAfterParseFileListEntry, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient_set_OnAfterParseFileListEntry, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSimpleFTPSClient___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSimpleFTPSClient_methods[] = {
	PHP_ME(TElSimpleFTPSClient, ParseFileListEntry_Inst, arginfo_TElSimpleFTPSClient_ParseFileListEntry_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, ParseFileListEntry, arginfo_TElSimpleFTPSClient_ParseFileListEntry, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElSimpleFTPSClient, ParseMLSDEntry_Inst, arginfo_TElSimpleFTPSClient_ParseMLSDEntry_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, ParseMLSDEntry, arginfo_TElSimpleFTPSClient_ParseMLSDEntry, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElSimpleFTPSClient, Abort, arginfo_TElSimpleFTPSClient_Abort, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, Acct, arginfo_TElSimpleFTPSClient_Acct, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, Allocate, arginfo_TElSimpleFTPSClient_Allocate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, Assign, arginfo_TElSimpleFTPSClient_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, CDUp, arginfo_TElSimpleFTPSClient_CDUp, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, ClearCommandChannel, arginfo_TElSimpleFTPSClient_ClearCommandChannel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, Interrupt, arginfo_TElSimpleFTPSClient_Interrupt, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, Close, arginfo_TElSimpleFTPSClient_Close, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, Cwd, arginfo_TElSimpleFTPSClient_Cwd, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, Delete, arginfo_TElSimpleFTPSClient_Delete, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, GetCurrentDir, arginfo_TElSimpleFTPSClient_GetCurrentDir, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, GetServerSystem, arginfo_TElSimpleFTPSClient_GetServerSystem, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, MLSD, arginfo_TElSimpleFTPSClient_MLSD, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, MLST, arginfo_TElSimpleFTPSClient_MLST, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, CreateCompletePath, arginfo_TElSimpleFTPSClient_CreateCompletePath, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, NOOP, arginfo_TElSimpleFTPSClient_NOOP, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, DirectoryExists, arginfo_TElSimpleFTPSClient_DirectoryExists, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, FileExists, arginfo_TElSimpleFTPSClient_FileExists, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, GetFileSize, arginfo_TElSimpleFTPSClient_GetFileSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, GetFileTime, arginfo_TElSimpleFTPSClient_GetFileTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, SetFileTime, arginfo_TElSimpleFTPSClient_SetFileTime, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, GetRemoteChecksum, arginfo_TElSimpleFTPSClient_GetRemoteChecksum, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, GetLocalChecksum, arginfo_TElSimpleFTPSClient_GetLocalChecksum, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, GetNameList, arginfo_TElSimpleFTPSClient_GetNameList, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, GetFileList, arginfo_TElSimpleFTPSClient_GetFileList, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, ListDirectory, arginfo_TElSimpleFTPSClient_ListDirectory, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, Open, arginfo_TElSimpleFTPSClient_Open, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, InternalValidate, arginfo_TElSimpleFTPSClient_InternalValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, EstablishSSLSession, arginfo_TElSimpleFTPSClient_EstablishSSLSession, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, Login, arginfo_TElSimpleFTPSClient_Login, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, MakeDir, arginfo_TElSimpleFTPSClient_MakeDir, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, MountStruct, arginfo_TElSimpleFTPSClient_MountStruct, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, Receive, arginfo_TElSimpleFTPSClient_Receive, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, Reinitialize, arginfo_TElSimpleFTPSClient_Reinitialize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, RemoveDir, arginfo_TElSimpleFTPSClient_RemoveDir, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, Rename, arginfo_TElSimpleFTPSClient_Rename, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, RenegotiateCiphers, arginfo_TElSimpleFTPSClient_RenegotiateCiphers, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, SendCmd, arginfo_TElSimpleFTPSClient_SendCmd, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, Send, arginfo_TElSimpleFTPSClient_Send, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, DownloadFile, arginfo_TElSimpleFTPSClient_DownloadFile, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, UploadFile, arginfo_TElSimpleFTPSClient_UploadFile, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, DownloadStream, arginfo_TElSimpleFTPSClient_DownloadStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, UploadStream, arginfo_TElSimpleFTPSClient_UploadStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, DownloadFiles, arginfo_TElSimpleFTPSClient_DownloadFiles, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, UploadFiles, arginfo_TElSimpleFTPSClient_UploadFiles, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, RemoveFile, arginfo_TElSimpleFTPSClient_RemoveFile, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, RemoveFiles, arginfo_TElSimpleFTPSClient_RemoveFiles, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_CipherSuite, arginfo_TElSimpleFTPSClient_get_CipherSuite, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_CompressionAlgorithm, arginfo_TElSimpleFTPSClient_get_CompressionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_CipherSuites, arginfo_TElSimpleFTPSClient_get_CipherSuites, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_CipherSuites, arginfo_TElSimpleFTPSClient_set_CipherSuites, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_CipherSuitePriorities, arginfo_TElSimpleFTPSClient_get_CipherSuitePriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_CipherSuitePriorities, arginfo_TElSimpleFTPSClient_set_CipherSuitePriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_CompressionAlgorithms, arginfo_TElSimpleFTPSClient_get_CompressionAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_CompressionAlgorithms, arginfo_TElSimpleFTPSClient_set_CompressionAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_Version, arginfo_TElSimpleFTPSClient_get_Version, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_Active, arginfo_TElSimpleFTPSClient_get_Active, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_LastReceivedReply, arginfo_TElSimpleFTPSClient_get_LastReceivedReply, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ModeZSupported, arginfo_TElSimpleFTPSClient_get_ModeZSupported, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ExtMLSTSupported, arginfo_TElSimpleFTPSClient_get_ExtMLSTSupported, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ExtMDTMSupported, arginfo_TElSimpleFTPSClient_get_ExtMDTMSupported, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ExtMFMTSupported, arginfo_TElSimpleFTPSClient_get_ExtMFMTSupported, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ExtSIZESupported, arginfo_TElSimpleFTPSClient_get_ExtSIZESupported, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ExtRESTSupported, arginfo_TElSimpleFTPSClient_get_ExtRESTSupported, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ExtXCRCSupported, arginfo_TElSimpleFTPSClient_get_ExtXCRCSupported, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ExtXMD5Supported, arginfo_TElSimpleFTPSClient_get_ExtXMD5Supported, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ExtXSHA1Supported, arginfo_TElSimpleFTPSClient_get_ExtXSHA1Supported, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ExtOPTSUTF8Supported, arginfo_TElSimpleFTPSClient_get_ExtOPTSUTF8Supported, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ExtHOSTSupported, arginfo_TElSimpleFTPSClient_get_ExtHOSTSupported, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_LocalNewLineConvention, arginfo_TElSimpleFTPSClient_get_LocalNewLineConvention, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_LocalNewLineConvention, arginfo_TElSimpleFTPSClient_set_LocalNewLineConvention, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_UsingIPv6, arginfo_TElSimpleFTPSClient_get_UsingIPv6, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_WebTunnelResult, arginfo_TElSimpleFTPSClient_get_WebTunnelResult, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_RemoteHost, arginfo_TElSimpleFTPSClient_get_RemoteHost, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_RemoteIP, arginfo_TElSimpleFTPSClient_get_RemoteIP, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_TotalBytesSent, arginfo_TElSimpleFTPSClient_get_TotalBytesSent, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_TotalBytesReceived, arginfo_TElSimpleFTPSClient_get_TotalBytesReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_TotalDataBytesSent, arginfo_TElSimpleFTPSClient_get_TotalDataBytesSent, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_TotalDataBytesReceived, arginfo_TElSimpleFTPSClient_get_TotalDataBytesReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_Socket, arginfo_TElSimpleFTPSClient_get_Socket, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_DataSocket, arginfo_TElSimpleFTPSClient_get_DataSocket, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_Address, arginfo_TElSimpleFTPSClient_get_Address, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_Address, arginfo_TElSimpleFTPSClient_set_Address, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_AuthCmd, arginfo_TElSimpleFTPSClient_get_AuthCmd, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_AuthCmd, arginfo_TElSimpleFTPSClient_set_AuthCmd, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_Port, arginfo_TElSimpleFTPSClient_get_Port, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_Port, arginfo_TElSimpleFTPSClient_set_Port, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_Username, arginfo_TElSimpleFTPSClient_get_Username, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_Username, arginfo_TElSimpleFTPSClient_set_Username, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_Password, arginfo_TElSimpleFTPSClient_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_Password, arginfo_TElSimpleFTPSClient_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_VirtualHostName, arginfo_TElSimpleFTPSClient_get_VirtualHostName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_VirtualHostName, arginfo_TElSimpleFTPSClient_set_VirtualHostName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_AccountInfo, arginfo_TElSimpleFTPSClient_get_AccountInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_AccountInfo, arginfo_TElSimpleFTPSClient_set_AccountInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_PassiveMode, arginfo_TElSimpleFTPSClient_get_PassiveMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_PassiveMode, arginfo_TElSimpleFTPSClient_set_PassiveMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_SRPUsername, arginfo_TElSimpleFTPSClient_get_SRPUsername, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_SRPUsername, arginfo_TElSimpleFTPSClient_set_SRPUsername, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_SRPPassword, arginfo_TElSimpleFTPSClient_get_SRPPassword, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_SRPPassword, arginfo_TElSimpleFTPSClient_set_SRPPassword, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_TransferType, arginfo_TElSimpleFTPSClient_get_TransferType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_TransferType, arginfo_TElSimpleFTPSClient_set_TransferType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_UseIPv6, arginfo_TElSimpleFTPSClient_get_UseIPv6, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_UseIPv6, arginfo_TElSimpleFTPSClient_set_UseIPv6, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_UseSSL, arginfo_TElSimpleFTPSClient_get_UseSSL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_UseSSL, arginfo_TElSimpleFTPSClient_set_UseSSL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ModeZ, arginfo_TElSimpleFTPSClient_get_ModeZ, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_ModeZ, arginfo_TElSimpleFTPSClient_set_ModeZ, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ModeZLevel, arginfo_TElSimpleFTPSClient_get_ModeZLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_ModeZLevel, arginfo_TElSimpleFTPSClient_set_ModeZLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_Versions, arginfo_TElSimpleFTPSClient_get_Versions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_Versions, arginfo_TElSimpleFTPSClient_set_Versions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_CertStorage, arginfo_TElSimpleFTPSClient_get_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_CertStorage, arginfo_TElSimpleFTPSClient_set_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ClientCertStorage, arginfo_TElSimpleFTPSClient_get_ClientCertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_ClientCertStorage, arginfo_TElSimpleFTPSClient_set_ClientCertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_SSLMode, arginfo_TElSimpleFTPSClient_get_SSLMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_SSLMode, arginfo_TElSimpleFTPSClient_set_SSLMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_EncryptDataChannel, arginfo_TElSimpleFTPSClient_get_EncryptDataChannel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_EncryptDataChannel, arginfo_TElSimpleFTPSClient_set_EncryptDataChannel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_FTPBufferSize, arginfo_TElSimpleFTPSClient_get_FTPBufferSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_FTPBufferSize, arginfo_TElSimpleFTPSClient_set_FTPBufferSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_FTPTextBufferSize, arginfo_TElSimpleFTPSClient_get_FTPTextBufferSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_FTPTextBufferSize, arginfo_TElSimpleFTPSClient_set_FTPTextBufferSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_FTPWriteBufferSize, arginfo_TElSimpleFTPSClient_get_FTPWriteBufferSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_FTPWriteBufferSize, arginfo_TElSimpleFTPSClient_set_FTPWriteBufferSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ProxySettings, arginfo_TElSimpleFTPSClient_get_ProxySettings, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_ProxySettings, arginfo_TElSimpleFTPSClient_set_ProxySettings, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_SocketSettings, arginfo_TElSimpleFTPSClient_get_SocketSettings, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_SocketTimeout, arginfo_TElSimpleFTPSClient_get_SocketTimeout, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_SocketTimeout, arginfo_TElSimpleFTPSClient_set_SocketTimeout, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_TransferTimeout, arginfo_TElSimpleFTPSClient_get_TransferTimeout, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_TransferTimeout, arginfo_TElSimpleFTPSClient_set_TransferTimeout, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_CtlPollInterval, arginfo_TElSimpleFTPSClient_get_CtlPollInterval, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_CtlPollInterval, arginfo_TElSimpleFTPSClient_set_CtlPollInterval, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_Extensions, arginfo_TElSimpleFTPSClient_get_Extensions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_PeerExtensions, arginfo_TElSimpleFTPSClient_get_PeerExtensions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_CommandSocketBinding, arginfo_TElSimpleFTPSClient_get_CommandSocketBinding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_CommandSocketBinding, arginfo_TElSimpleFTPSClient_set_CommandSocketBinding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_DataSocketBinding, arginfo_TElSimpleFTPSClient_get_DataSocketBinding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_DataSocketBinding, arginfo_TElSimpleFTPSClient_set_DataSocketBinding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_FileSystemAdapter, arginfo_TElSimpleFTPSClient_get_FileSystemAdapter, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_FileSystemAdapter, arginfo_TElSimpleFTPSClient_set_FileSystemAdapter, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_PortKnock, arginfo_TElSimpleFTPSClient_get_PortKnock, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_PortKnock, arginfo_TElSimpleFTPSClient_set_PortKnock, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_TransferKeepAliveInterval, arginfo_TElSimpleFTPSClient_get_TransferKeepAliveInterval, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_TransferKeepAliveInterval, arginfo_TElSimpleFTPSClient_set_TransferKeepAliveInterval, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ListenTimeout, arginfo_TElSimpleFTPSClient_get_ListenTimeout, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_ListenTimeout, arginfo_TElSimpleFTPSClient_set_ListenTimeout, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_UseSIZECmd, arginfo_TElSimpleFTPSClient_get_UseSIZECmd, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_UseSIZECmd, arginfo_TElSimpleFTPSClient_set_UseSIZECmd, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_UseFEATCmd, arginfo_TElSimpleFTPSClient_get_UseFEATCmd, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_UseFEATCmd, arginfo_TElSimpleFTPSClient_set_UseFEATCmd, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_AdjustPasvAddress, arginfo_TElSimpleFTPSClient_get_AdjustPasvAddress, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_AdjustPasvAddress, arginfo_TElSimpleFTPSClient_set_AdjustPasvAddress, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_UseSSLSessionResumption, arginfo_TElSimpleFTPSClient_get_UseSSLSessionResumption, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_UseSSLSessionResumption, arginfo_TElSimpleFTPSClient_set_UseSSLSessionResumption, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_RenegotiationAttackPreventionMode, arginfo_TElSimpleFTPSClient_get_RenegotiationAttackPreventionMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_RenegotiationAttackPreventionMode, arginfo_TElSimpleFTPSClient_set_RenegotiationAttackPreventionMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_IncomingSpeedLimit, arginfo_TElSimpleFTPSClient_get_IncomingSpeedLimit, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_IncomingSpeedLimit, arginfo_TElSimpleFTPSClient_set_IncomingSpeedLimit, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OutgoingSpeedLimit, arginfo_TElSimpleFTPSClient_get_OutgoingSpeedLimit, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OutgoingSpeedLimit, arginfo_TElSimpleFTPSClient_set_OutgoingSpeedLimit, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_ConcurrentConnections, arginfo_TElSimpleFTPSClient_get_ConcurrentConnections, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_ConcurrentConnections, arginfo_TElSimpleFTPSClient_set_ConcurrentConnections, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_MinSizeForConcurrentDownload, arginfo_TElSimpleFTPSClient_get_MinSizeForConcurrentDownload, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_MinSizeForConcurrentDownload, arginfo_TElSimpleFTPSClient_set_MinSizeForConcurrentDownload, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_Options, arginfo_TElSimpleFTPSClient_get_Options, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_Options, arginfo_TElSimpleFTPSClient_set_Options, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_SSLOptions, arginfo_TElSimpleFTPSClient_get_SSLOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_SSLOptions, arginfo_TElSimpleFTPSClient_set_SSLOptions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_QuoteParameters, arginfo_TElSimpleFTPSClient_get_QuoteParameters, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_QuoteParameters, arginfo_TElSimpleFTPSClient_set_QuoteParameters, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_QuoteParamChar, arginfo_TElSimpleFTPSClient_get_QuoteParamChar, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_QuoteParamChar, arginfo_TElSimpleFTPSClient_set_QuoteParamChar, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_SocksAuthentication, arginfo_TElSimpleFTPSClient_get_SocksAuthentication, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_SocksAuthentication, arginfo_TElSimpleFTPSClient_set_SocksAuthentication, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_SocksPassword, arginfo_TElSimpleFTPSClient_get_SocksPassword, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_SocksPassword, arginfo_TElSimpleFTPSClient_set_SocksPassword, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_SocksPort, arginfo_TElSimpleFTPSClient_get_SocksPort, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_SocksPort, arginfo_TElSimpleFTPSClient_set_SocksPort, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_SocksResolveAddress, arginfo_TElSimpleFTPSClient_get_SocksResolveAddress, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_SocksResolveAddress, arginfo_TElSimpleFTPSClient_set_SocksResolveAddress, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_SocksServer, arginfo_TElSimpleFTPSClient_get_SocksServer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_SocksServer, arginfo_TElSimpleFTPSClient_set_SocksServer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_SocksUserCode, arginfo_TElSimpleFTPSClient_get_SocksUserCode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_SocksUserCode, arginfo_TElSimpleFTPSClient_set_SocksUserCode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_SocksVersion, arginfo_TElSimpleFTPSClient_get_SocksVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_SocksVersion, arginfo_TElSimpleFTPSClient_set_SocksVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_SocksUseIPv6, arginfo_TElSimpleFTPSClient_get_SocksUseIPv6, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_SocksUseIPv6, arginfo_TElSimpleFTPSClient_set_SocksUseIPv6, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_UseSocks, arginfo_TElSimpleFTPSClient_get_UseSocks, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_UseSocks, arginfo_TElSimpleFTPSClient_set_UseSocks, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_UseWebTunneling, arginfo_TElSimpleFTPSClient_get_UseWebTunneling, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_UseWebTunneling, arginfo_TElSimpleFTPSClient_set_UseWebTunneling, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_WebTunnelAddress, arginfo_TElSimpleFTPSClient_get_WebTunnelAddress, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_WebTunnelAddress, arginfo_TElSimpleFTPSClient_set_WebTunnelAddress, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_WebTunnelAuthentication, arginfo_TElSimpleFTPSClient_get_WebTunnelAuthentication, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_WebTunnelAuthentication, arginfo_TElSimpleFTPSClient_set_WebTunnelAuthentication, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_WebTunnelPassword, arginfo_TElSimpleFTPSClient_get_WebTunnelPassword, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_WebTunnelPassword, arginfo_TElSimpleFTPSClient_set_WebTunnelPassword, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_WebTunnelPort, arginfo_TElSimpleFTPSClient_get_WebTunnelPort, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_WebTunnelPort, arginfo_TElSimpleFTPSClient_set_WebTunnelPort, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_WebTunnelUserId, arginfo_TElSimpleFTPSClient_get_WebTunnelUserId, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_WebTunnelUserId, arginfo_TElSimpleFTPSClient_set_WebTunnelUserId, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_WebTunnelRequestHeaders, arginfo_TElSimpleFTPSClient_get_WebTunnelRequestHeaders, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_WebTunnelResponseHeaders, arginfo_TElSimpleFTPSClient_get_WebTunnelResponseHeaders, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_WebTunnelResponseBody, arginfo_TElSimpleFTPSClient_get_WebTunnelResponseBody, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_UseProxySettingsForDataChannel, arginfo_TElSimpleFTPSClient_get_UseProxySettingsForDataChannel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_UseProxySettingsForDataChannel, arginfo_TElSimpleFTPSClient_set_UseProxySettingsForDataChannel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_PreserveExistingFileTimes, arginfo_TElSimpleFTPSClient_get_PreserveExistingFileTimes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_PreserveExistingFileTimes, arginfo_TElSimpleFTPSClient_set_PreserveExistingFileTimes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_CopyEmptyDirs, arginfo_TElSimpleFTPSClient_get_CopyEmptyDirs, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_CopyEmptyDirs, arginfo_TElSimpleFTPSClient_set_CopyEmptyDirs, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_DeleteFailedDownloads, arginfo_TElSimpleFTPSClient_get_DeleteFailedDownloads, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_DeleteFailedDownloads, arginfo_TElSimpleFTPSClient_set_DeleteFailedDownloads, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_RemoteCharset, arginfo_TElSimpleFTPSClient_get_RemoteCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_RemoteCharset, arginfo_TElSimpleFTPSClient_set_RemoteCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_LocalCharset, arginfo_TElSimpleFTPSClient_get_LocalCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_LocalCharset, arginfo_TElSimpleFTPSClient_set_LocalCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_DNS, arginfo_TElSimpleFTPSClient_get_DNS, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_DNS, arginfo_TElSimpleFTPSClient_set_DNS, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OperationErrorHandling, arginfo_TElSimpleFTPSClient_get_OperationErrorHandling, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OperationErrorHandling, arginfo_TElSimpleFTPSClient_set_OperationErrorHandling, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnTextDataLine, arginfo_TElSimpleFTPSClient_get_OnTextDataLine, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnTextDataLine, arginfo_TElSimpleFTPSClient_set_OnTextDataLine, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnBinaryData, arginfo_TElSimpleFTPSClient_get_OnBinaryData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnBinaryData, arginfo_TElSimpleFTPSClient_set_OnBinaryData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnCertificateValidate, arginfo_TElSimpleFTPSClient_get_OnCertificateValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnCertificateValidate, arginfo_TElSimpleFTPSClient_set_OnCertificateValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnCertificateNeededEx, arginfo_TElSimpleFTPSClient_get_OnCertificateNeededEx, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnCertificateNeededEx, arginfo_TElSimpleFTPSClient_set_OnCertificateNeededEx, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnCiphersNegotiated, arginfo_TElSimpleFTPSClient_get_OnCiphersNegotiated, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnCiphersNegotiated, arginfo_TElSimpleFTPSClient_set_OnCiphersNegotiated, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnSSLError, arginfo_TElSimpleFTPSClient_get_OnSSLError, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnSSLError, arginfo_TElSimpleFTPSClient_set_OnSSLError, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnCertificateStatus, arginfo_TElSimpleFTPSClient_get_OnCertificateStatus, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnCertificateStatus, arginfo_TElSimpleFTPSClient_set_OnCertificateStatus, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnExtensionsReceived, arginfo_TElSimpleFTPSClient_get_OnExtensionsReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnExtensionsReceived, arginfo_TElSimpleFTPSClient_set_OnExtensionsReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnExtensionsPrepared, arginfo_TElSimpleFTPSClient_get_OnExtensionsPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnExtensionsPrepared, arginfo_TElSimpleFTPSClient_set_OnExtensionsPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnKeyNeeded, arginfo_TElSimpleFTPSClient_get_OnKeyNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnKeyNeeded, arginfo_TElSimpleFTPSClient_set_OnKeyNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnRenegotiationRequest, arginfo_TElSimpleFTPSClient_get_OnRenegotiationRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnRenegotiationRequest, arginfo_TElSimpleFTPSClient_set_OnRenegotiationRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnProgress, arginfo_TElSimpleFTPSClient_get_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnProgress, arginfo_TElSimpleFTPSClient_set_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnControlSend, arginfo_TElSimpleFTPSClient_get_OnControlSend, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnControlSend, arginfo_TElSimpleFTPSClient_set_OnControlSend, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnControlReceive, arginfo_TElSimpleFTPSClient_get_OnControlReceive, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnControlReceive, arginfo_TElSimpleFTPSClient_set_OnControlReceive, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnInnerClientCreated, arginfo_TElSimpleFTPSClient_get_OnInnerClientCreated, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnInnerClientCreated, arginfo_TElSimpleFTPSClient_set_OnInnerClientCreated, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnInnerClientLoggedIn, arginfo_TElSimpleFTPSClient_get_OnInnerClientLoggedIn, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnInnerClientLoggedIn, arginfo_TElSimpleFTPSClient_set_OnInnerClientLoggedIn, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnInnerClientDestroyed, arginfo_TElSimpleFTPSClient_get_OnInnerClientDestroyed, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnInnerClientDestroyed, arginfo_TElSimpleFTPSClient_set_OnInnerClientDestroyed, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnDNSKeyNeeded, arginfo_TElSimpleFTPSClient_get_OnDNSKeyNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnDNSKeyNeeded, arginfo_TElSimpleFTPSClient_set_OnDNSKeyNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnDNSKeyValidate, arginfo_TElSimpleFTPSClient_get_OnDNSKeyValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnDNSKeyValidate, arginfo_TElSimpleFTPSClient_set_OnDNSKeyValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnDNSResolve, arginfo_TElSimpleFTPSClient_get_OnDNSResolve, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnDNSResolve, arginfo_TElSimpleFTPSClient_set_OnDNSResolve, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnFileOperation, arginfo_TElSimpleFTPSClient_get_OnFileOperation, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnFileOperation, arginfo_TElSimpleFTPSClient_set_OnFileOperation, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnFileOperationResult, arginfo_TElSimpleFTPSClient_get_OnFileOperationResult, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnFileOperationResult, arginfo_TElSimpleFTPSClient_set_OnFileOperationResult, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnFileNameChangeNeeded, arginfo_TElSimpleFTPSClient_get_OnFileNameChangeNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnFileNameChangeNeeded, arginfo_TElSimpleFTPSClient_set_OnFileNameChangeNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnBeforeParseFileListEntry, arginfo_TElSimpleFTPSClient_get_OnBeforeParseFileListEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnBeforeParseFileListEntry, arginfo_TElSimpleFTPSClient_set_OnBeforeParseFileListEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, get_OnAfterParseFileListEntry, arginfo_TElSimpleFTPSClient_get_OnAfterParseFileListEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, set_OnAfterParseFileListEntry, arginfo_TElSimpleFTPSClient_set_OnAfterParseFileListEntry, ZEND_ACC_PUBLIC)
	PHP_ME(TElSimpleFTPSClient, __construct, arginfo_TElSimpleFTPSClient___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSimpleFTPSClient(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSimpleFTPSClient_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSimpleFTPSClient", TElSimpleFTPSClient_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElSimpleFTPSClient_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElFTPFileInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElFTPFileInfo, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElFTPFileInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElFTPFileInfo_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &oSource, TSBFTPFileInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElFTPFileInfo_Assign_1(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBFTPFileInfo *)SBGetStructPointer(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElFTPFileInfo) or (\\TSBFTPFileInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, get_FileDate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t dtOutResultRaw = 0;
		SBCheckError(TElFTPFileInfo_get_FileDate(SBGetObjectHandle(getThis() TSRMLS_CC), &dtOutResultRaw) TSRMLS_CC);
		object_init_ex(return_value, php_date_get_date_ce());
		SBSetDateTime(return_value, dtOutResultRaw TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, set_FileDate)
{
	zval *dtValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O", &dtValue, php_date_get_date_ce()) == SUCCESS)
	{
		SBCheckError(TElFTPFileInfo_set_FileDate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetDateTime(dtValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, get_FileType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFileEntryTypeRaw fOutResultRaw = 0;
		SBCheckError(TElFTPFileInfo_get_FileType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, set_FileType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElFTPFileInfo_set_FileType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBFileEntryTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, get_Name)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElFTPFileInfo_get_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(435121330, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, set_Name)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElFTPFileInfo_set_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, get_Path)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElFTPFileInfo_get_Path(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1285069243, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, set_Path)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElFTPFileInfo_set_Path(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, get_Size)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElFTPFileInfo_get_Size(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, set_Size)
{
	sb_zend_long l8Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l8Value) == SUCCESS)
	{
		SBCheckError(TElFTPFileInfo_set_Size(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, get_EntryFormat)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFileEntryFormatRaw fOutResultRaw = 0;
		SBCheckError(TElFTPFileInfo_get_EntryFormat(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, set_EntryFormat)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElFTPFileInfo_set_EntryFormat(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBFileEntryFormatRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, get_RawData)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElFTPFileInfo_get_RawData(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1787556660, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, set_RawData)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElFTPFileInfo_set_RawData(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPFileInfo, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElFTPFileInfo_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_get_FileDate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_set_FileDate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, DateTime, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_get_FileType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_set_FileType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_get_Name, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_set_Name, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_get_Path, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_set_Path, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_get_Size, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_set_Size, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_get_EntryFormat, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_set_EntryFormat, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_get_RawData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo_set_RawData, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPFileInfo___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElFTPFileInfo_methods[] = {
	PHP_ME(TElFTPFileInfo, Assign, arginfo_TElFTPFileInfo_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, get_FileDate, arginfo_TElFTPFileInfo_get_FileDate, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, set_FileDate, arginfo_TElFTPFileInfo_set_FileDate, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, get_FileType, arginfo_TElFTPFileInfo_get_FileType, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, set_FileType, arginfo_TElFTPFileInfo_set_FileType, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, get_Name, arginfo_TElFTPFileInfo_get_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, set_Name, arginfo_TElFTPFileInfo_set_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, get_Path, arginfo_TElFTPFileInfo_get_Path, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, set_Path, arginfo_TElFTPFileInfo_set_Path, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, get_Size, arginfo_TElFTPFileInfo_get_Size, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, set_Size, arginfo_TElFTPFileInfo_set_Size, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, get_EntryFormat, arginfo_TElFTPFileInfo_get_EntryFormat, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, set_EntryFormat, arginfo_TElFTPFileInfo_set_EntryFormat, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, get_RawData, arginfo_TElFTPFileInfo_get_RawData, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, set_RawData, arginfo_TElFTPFileInfo_set_RawData, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPFileInfo, __construct, arginfo_TElFTPFileInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElFTPFileInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElFTPFileInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElFTPFileInfo", TElFTPFileInfo_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElFTPFileInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElFTPProxySettings_ce_ptr = NULL;

SB_PHP_METHOD(TElFTPProxySettings, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TPersistent_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElFTPProxySettings_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TPersistent)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPProxySettings, get_Host)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElFTPProxySettings_get_Host(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(87488352, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPProxySettings, set_Host)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElFTPProxySettings_set_Host(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPProxySettings, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElFTPProxySettings_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-584069006, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPProxySettings, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElFTPProxySettings_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPProxySettings, get_Port)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElFTPProxySettings_get_Port(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPProxySettings, set_Port)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElFTPProxySettings_set_Port(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPProxySettings, get_ProxyType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBFTPProxyTypeRaw fOutResultRaw = 0;
		SBCheckError(TElFTPProxySettings_get_ProxyType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPProxySettings, set_ProxyType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElFTPProxySettings_set_ProxyType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBFTPProxyTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPProxySettings, get_Username)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElFTPProxySettings_get_Username(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(280203472, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPProxySettings, set_Username)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElFTPProxySettings_set_Username(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPProxySettings, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElFTPProxySettings_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPProxySettings_Assign, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPProxySettings_get_Host, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPProxySettings_set_Host, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPProxySettings_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPProxySettings_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPProxySettings_get_Port, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPProxySettings_set_Port, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPProxySettings_get_ProxyType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPProxySettings_set_ProxyType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPProxySettings_get_Username, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPProxySettings_set_Username, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPProxySettings___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElFTPProxySettings_methods[] = {
	PHP_ME(TElFTPProxySettings, Assign, arginfo_TElFTPProxySettings_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPProxySettings, get_Host, arginfo_TElFTPProxySettings_get_Host, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPProxySettings, set_Host, arginfo_TElFTPProxySettings_set_Host, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPProxySettings, get_Password, arginfo_TElFTPProxySettings_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPProxySettings, set_Password, arginfo_TElFTPProxySettings_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPProxySettings, get_Port, arginfo_TElFTPProxySettings_get_Port, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPProxySettings, set_Port, arginfo_TElFTPProxySettings_set_Port, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPProxySettings, get_ProxyType, arginfo_TElFTPProxySettings_get_ProxyType, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPProxySettings, set_ProxyType, arginfo_TElFTPProxySettings_set_ProxyType, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPProxySettings, get_Username, arginfo_TElFTPProxySettings_get_Username, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPProxySettings, set_Username, arginfo_TElFTPProxySettings_set_Username, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPProxySettings, __construct, arginfo_TElFTPProxySettings___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElFTPProxySettings(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElFTPProxySettings_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElFTPProxySettings", TElFTPProxySettings_methods);
	if (NULL == TPersistent_ce_ptr)
		Register_TPersistent(TSRMLS_C);
	TElFTPProxySettings_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TPersistent_ce_ptr);
}

zend_class_entry *TElFTPSTransferManager_ce_ptr = NULL;

SB_PHP_METHOD(TElFTPSTransferManager, Execute)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElFTPSTransferManager_Execute(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPSTransferManager, __construct)
{
	char *sDir;
	char *sFilename;
	sb_str_size sDir_len;
	sb_str_size sFilename_len;
	sb_zend_long l8EndPos;
	sb_zend_long l8StartPos;
	zval *oOwner;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!ssO!ll", &oOwner, TElSimpleFTPSClient_ce_ptr, &sFilename, &sFilename_len, &sDir, &sDir_len, &oStream, TStream_ce_ptr, &l8StartPos, &l8EndPos) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElFTPSTransferManager_Create(SBGetObjectHandle(oOwner TSRMLS_CC), sFilename, (int32_t)sFilename_len, sDir, (int32_t)sDir_len, SBGetObjectHandle(oStream TSRMLS_CC), (int64_t)l8StartPos, (int64_t)l8EndPos, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSimpleFTPSClient, string, string, \\TStream, integer, integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPSTransferManager_Execute, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPSTransferManager___construct, 0, 0, 6)
	ZEND_ARG_OBJ_INFO(0, Owner, TElSimpleFTPSClient, 1)
	ZEND_ARG_INFO(0, Filename)
	ZEND_ARG_INFO(0, Dir)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, StartPos)
	ZEND_ARG_INFO(0, EndPos)
ZEND_END_ARG_INFO()

static zend_function_entry TElFTPSTransferManager_methods[] = {
	PHP_ME(TElFTPSTransferManager, Execute, arginfo_TElFTPSTransferManager_Execute, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPSTransferManager, __construct, arginfo_TElFTPSTransferManager___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElFTPSTransferManager(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElFTPSTransferManager_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElFTPSTransferManager", TElFTPSTransferManager_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElFTPSTransferManager_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElMultipartStreamAccess_ce_ptr = NULL;

SB_PHP_METHOD(TElMultipartStreamAccess, AcquirePart)
{
	sb_zend_long l8Size;
	sb_zend_long l8StartPos;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l8StartPos, &l8Size) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMultipartStreamAccess_AcquirePart(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8StartPos, (int64_t)l8Size, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStream_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMultipartStreamAccess, ReleasePart)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMultipartStreamAccess_ReleasePart(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMultipartStreamAccess, __construct)
{
	sb_zend_long l8Size;
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStream, TStream_ce_ptr, &l8Size) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMultipartStreamAccess_Create(SBGetObjectHandle(oStream TSRMLS_CC), (int64_t)l8Size, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream, integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMultipartStreamAccess_AcquirePart, 0, 0, 2)
	ZEND_ARG_INFO(0, StartPos)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMultipartStreamAccess_ReleasePart, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMultipartStreamAccess___construct, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

static zend_function_entry TElMultipartStreamAccess_methods[] = {
	PHP_ME(TElMultipartStreamAccess, AcquirePart, arginfo_TElMultipartStreamAccess_AcquirePart, ZEND_ACC_PUBLIC)
	PHP_ME(TElMultipartStreamAccess, ReleasePart, arginfo_TElMultipartStreamAccess_ReleasePart, ZEND_ACC_PUBLIC)
	PHP_ME(TElMultipartStreamAccess, __construct, arginfo_TElMultipartStreamAccess___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMultipartStreamAccess(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMultipartStreamAccess_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMultipartStreamAccess", TElMultipartStreamAccess_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElMultipartStreamAccess_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElFTPSTransferChunk_ce_ptr = NULL;

SB_PHP_METHOD(TElFTPSTransferChunk, Run)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElFTPSTransferChunk_Run(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElFTPSTransferChunk, __construct)
{
	char *sDir;
	char *sFilename;
	sb_str_size sDir_len;
	sb_str_size sFilename_len;
	sb_zend_long l8EndPos;
	sb_zend_long l8StartPos;
	zend_bool bCreateCopy;
	zval *oClient;
	zval *oStreamAccess;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssllO!bO!", &sFilename, &sFilename_len, &sDir, &sDir_len, &l8StartPos, &l8EndPos, &oClient, TElSimpleFTPSClient_ce_ptr, &bCreateCopy, &oStreamAccess, TElMultipartStreamAccess_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElFTPSTransferChunk_Create(sFilename, (int32_t)sFilename_len, sDir, (int32_t)sDir_len, (int64_t)l8StartPos, (int64_t)l8EndPos, SBGetObjectHandle(oClient TSRMLS_CC), (int8_t)bCreateCopy, SBGetObjectHandle(oStreamAccess TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, integer, integer, \\TElSimpleFTPSClient, bool, \\TElMultipartStreamAccess)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPSTransferChunk_Run, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElFTPSTransferChunk___construct, 0, 0, 7)
	ZEND_ARG_INFO(0, Filename)
	ZEND_ARG_INFO(0, Dir)
	ZEND_ARG_INFO(0, StartPos)
	ZEND_ARG_INFO(0, EndPos)
	ZEND_ARG_OBJ_INFO(0, Client, TElSimpleFTPSClient, 1)
	ZEND_ARG_INFO(0, CreateCopy)
	ZEND_ARG_OBJ_INFO(0, StreamAccess, TElMultipartStreamAccess, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElFTPSTransferChunk_methods[] = {
	PHP_ME(TElFTPSTransferChunk, Run, arginfo_TElFTPSTransferChunk_Run, ZEND_ACC_PUBLIC)
	PHP_ME(TElFTPSTransferChunk, __construct, arginfo_TElFTPSTransferChunk___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElFTPSTransferChunk(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElFTPSTransferChunk_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElFTPSTransferChunk", TElFTPSTransferChunk_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElFTPSTransferChunk_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElMultipartStreamPart_ce_ptr = NULL;

SB_PHP_METHOD(TElMultipartStreamPart, Read)
{
	sb_zend_long l4Count;
	SBPointerZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Count) == SUCCESS) && ((Z_ISREF_P(zpBuffer) && ((Z_TYPE_P(Z_REFVAL_P(zpBuffer)) == IS_STRING) || (Z_TYPE_P(Z_REFVAL_P(zpBuffer)) == IS_ARRAY) || ((Z_TYPE_P(Z_REFVAL_P(zpBuffer)) == IS_OBJECT) && (Z_OBJCE_P(Z_REFVAL_P(zpBuffer)) == TSBPointer_ce_ptr)))) || ((Z_TYPE_P(zpBuffer) == IS_OBJECT) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMultipartStreamPart_Read(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBSetPointerToZVal(&piBuffer, zpBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMultipartStreamPart, Write)
{
	sb_zend_long l4Count;
	SBPointerZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElMultipartStreamPart_Write(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMultipartStreamPart, Seek)
{
	sb_zend_long fOrigin;
	sb_zend_long l4Offset;
	sb_zend_long l8Offset;
	sb_zend_long u2Origin;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4Offset, &u2Origin) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElMultipartStreamPart_Seek(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Offset, (uint16_t)u2Origin, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l8Offset, &fOrigin) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElMultipartStreamPart_Seek_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int64_t)l8Offset, (TSeekOriginRaw)fOrigin, &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer) or (integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMultipartStreamPart, __construct)
{
	sb_zend_long l8BaseSize;
	sb_zend_long l8Size;
	sb_zend_long l8StartPos;
	zval *oBaseStream;
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!lll", &oOwner, TElMultipartStreamAccess_ce_ptr, &oBaseStream, TStream_ce_ptr, &l8BaseSize, &l8StartPos, &l8Size) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMultipartStreamPart_Create(SBGetObjectHandle(oOwner TSRMLS_CC), SBGetObjectHandle(oBaseStream TSRMLS_CC), (int64_t)l8BaseSize, (int64_t)l8StartPos, (int64_t)l8Size, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElMultipartStreamAccess, \\TStream, integer, integer, integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMultipartStreamPart_Read, 0, 0, 2)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMultipartStreamPart_Write, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMultipartStreamPart_Seek, 0, 0, 2)
	ZEND_ARG_INFO(0, Offset)
	ZEND_ARG_INFO(0, Origin)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMultipartStreamPart___construct, 0, 0, 5)
	ZEND_ARG_OBJ_INFO(0, Owner, TElMultipartStreamAccess, 1)
	ZEND_ARG_OBJ_INFO(0, BaseStream, TStream, 1)
	ZEND_ARG_INFO(0, BaseSize)
	ZEND_ARG_INFO(0, StartPos)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

static zend_function_entry TElMultipartStreamPart_methods[] = {
	PHP_ME(TElMultipartStreamPart, Read, arginfo_TElMultipartStreamPart_Read, ZEND_ACC_PUBLIC)
	PHP_ME(TElMultipartStreamPart, Write, arginfo_TElMultipartStreamPart_Write, ZEND_ACC_PUBLIC)
	PHP_ME(TElMultipartStreamPart, Seek, arginfo_TElMultipartStreamPart_Seek, ZEND_ACC_PUBLIC)
	PHP_ME(TElMultipartStreamPart, __construct, arginfo_TElMultipartStreamPart___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMultipartStreamPart(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMultipartStreamPart_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMultipartStreamPart", TElMultipartStreamPart_methods);
	if (NULL == TStream_ce_ptr)
		Register_TStream(TSRMLS_C);
	TElMultipartStreamPart_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TStream_ce_ptr);
}

void Register_SBSimpleFTPS_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBSimpleFTPS, ERROR_FACILITY_FTPS, SB_ERROR_FACILITY_FTPS, SB_ERROR_FACILITY_FTPS);
	SB_REGISTER_LONG_CONSTANT(SBSimpleFTPS, ERROR_COMM_OPERATION_BASE, SB_ERROR_COMM_OPERATION_BASE, SB_ERROR_COMM_OPERATION_BASE);
	SB_REGISTER_LONG_CONSTANT(SBSimpleFTPS, ERROR_FS_OPERATION_BASE, SB_ERROR_FS_OPERATION_BASE, SB_ERROR_FS_OPERATION_BASE);
	SB_REGISTER_LONG_CONSTANT(SBSimpleFTPS, SB_FTPS_ERROR_CONTROL_CHANNEL_HANGUP, SB_FTPS_ERROR_CONTROL_CHANNEL_HANGUP, SB_FTPS_ERROR_CONTROL_CHANNEL_HANGUP);
	SB_REGISTER_LONG_CONSTANT(SBSimpleFTPS, SB_FTPS_ERROR_CONTROL_CHANNEL_NO_DATA, SB_FTPS_ERROR_CONTROL_CHANNEL_NO_DATA, SB_FTPS_ERROR_CONTROL_CHANNEL_NO_DATA);
	SB_REGISTER_LONG_CONSTANT(SBSimpleFTPS, SB_FTPS_ERROR_UNACCEPTED_REPLY_CODE, SB_FTPS_ERROR_UNACCEPTED_REPLY_CODE, SB_FTPS_ERROR_UNACCEPTED_REPLY_CODE);
	SB_REGISTER_LONG_CONSTANT(SBSimpleFTPS, SB_FTPS_ERROR_INVALID_REPLY, SB_FTPS_ERROR_INVALID_REPLY, SB_FTPS_ERROR_INVALID_REPLY);
	SB_REGISTER_LONG_CONSTANT(SBSimpleFTPS, SB_FTPS_ERROR_LOCAL_SOURCE_NOT_FILE, SB_FTPS_ERROR_LOCAL_SOURCE_NOT_FILE, SB_FTPS_ERROR_LOCAL_SOURCE_NOT_FILE);
	SB_REGISTER_LONG_CONSTANT(SBSimpleFTPS, SB_FTPS_ERROR_LOCAL_TARGET_NOT_FILE, SB_FTPS_ERROR_LOCAL_TARGET_NOT_FILE, SB_FTPS_ERROR_LOCAL_TARGET_NOT_FILE);
	SB_REGISTER_LONG_CONSTANT(SBSimpleFTPS, SB_FTPS_ERROR_RESUME_OFFSET_TOO_LARGE, SB_FTPS_ERROR_RESUME_OFFSET_TOO_LARGE, SB_FTPS_ERROR_RESUME_OFFSET_TOO_LARGE);
	SB_REGISTER_LONG_CONSTANT(SBSimpleFTPS, SB_FTPS_ERROR_OPERATION_CRITERIA_NOT_MET, SB_FTPS_ERROR_OPERATION_CRITERIA_NOT_MET, SB_FTPS_ERROR_OPERATION_CRITERIA_NOT_MET);
	SB_REGISTER_LONG_CONSTANT(SBSimpleFTPS, SB_FTPS_ERROR_TIMES_NOT_SET, SB_FTPS_ERROR_TIMES_NOT_SET, SB_FTPS_ERROR_TIMES_NOT_SET);
}

void Register_SBSimpleFTPS_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBFTPSSLState", NULL);
	TSBFTPSSLState_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBFTPSSLState_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPSSLState_ce_ptr, "fsPlain", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPSSLState_ce_ptr, "fsEncrypted", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBFTPTransferType", NULL);
	TSBFTPTransferType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBFTPTransferType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPTransferType_ce_ptr, "ttASCII", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPTransferType_ce_ptr, "ttBinary", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBFTPAuthCmd", NULL);
	TSBFTPAuthCmd_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBFTPAuthCmd_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPAuthCmd_ce_ptr, "acAuto", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPAuthCmd_ce_ptr, "acAuthTLS", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPAuthCmd_ce_ptr, "acAuthSSL", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPAuthCmd_ce_ptr, "acAuthTLSP", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPAuthCmd_ce_ptr, "acAuthTLSC", 4)
	
	INIT_CLASS_ENTRY(ce, "TSBFTPProxyType", NULL);
	TSBFTPProxyType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBFTPProxyType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPProxyType_ce_ptr, "ptNone", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPProxyType_ce_ptr, "ptUserSite", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPProxyType_ce_ptr, "ptSite", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPProxyType_ce_ptr, "ptOpen", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPProxyType_ce_ptr, "ptUserPass", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPProxyType_ce_ptr, "ptTransparent", 5)
	
	INIT_CLASS_ENTRY(ce, "TSBFileEntryFormat", NULL);
	TSBFileEntryFormat_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBFileEntryFormat_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFileEntryFormat_ce_ptr, "fefUnknown", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileEntryFormat_ce_ptr, "fefUnix", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileEntryFormat_ce_ptr, "fefWindows", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileEntryFormat_ce_ptr, "fefMLSD", 3)
	
	INIT_CLASS_ENTRY(ce, "TSBFileEntryType", NULL);
	TSBFileEntryType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBFileEntryType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFileEntryType_ce_ptr, "fetUnknown", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileEntryType_ce_ptr, "fetDirectory", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileEntryType_ce_ptr, "fetFile", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileEntryType_ce_ptr, "fetSymlink", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileEntryType_ce_ptr, "fetSpecial", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileEntryType_ce_ptr, "fetCurrentDirectory", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBFileEntryType_ce_ptr, "fetParentDirectory", 6)
	
	INIT_CLASS_ENTRY(ce, "TSBFTPState", NULL);
	TSBFTPState_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBFTPState_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPState_ce_ptr, "fsDisconnected", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPState_ce_ptr, "fsConnected", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPState_ce_ptr, "fsLoggedIn", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBFTPCheckMethod", NULL);
	TSBFTPCheckMethod_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBFTPCheckMethod_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPCheckMethod_ce_ptr, "cmCRC", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPCheckMethod_ce_ptr, "cmMD5", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPCheckMethod_ce_ptr, "cmSHA1", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBFTPOption", NULL);
	TSBFTPOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBFTPOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPOption_ce_ptr, "foCCCSiteWorkaround", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPOption_ce_ptr, "foSyncDataChannel", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPOption_ce_ptr, "foSmartSSLSetup", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPOption_ce_ptr, "foStreamingASCIIMode", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPOption_ce_ptr, "foPreallocateStorage", 4)
	
	INIT_CLASS_ENTRY(ce, "TSBFTPOptions", NULL);
	TSBFTPOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBFTPOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPOptions_ce_ptr, "foCCCSiteWorkaround", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPOptions_ce_ptr, "foSyncDataChannel", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPOptions_ce_ptr, "foSmartSSLSetup", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPOptions_ce_ptr, "foStreamingASCIIMode", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPOptions_ce_ptr, "foPreallocateStorage", 16)
	
	INIT_CLASS_ENTRY(ce, "TSBFtpFileOperation", NULL);
	TSBFtpFileOperation_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBFtpFileOperation_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFtpFileOperation_ce_ptr, "ffoDownloadFile", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBFtpFileOperation_ce_ptr, "ffoUploadFile", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBFtpFileOperation_ce_ptr, "ffoDeleteFile", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBFtpFileOperation_ce_ptr, "ffoMakeDir", 3)
	
	INIT_CLASS_ENTRY(ce, "TSBFTPSTransferChunkState", NULL);
	TSBFTPSTransferChunkState_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBFTPSTransferChunkState_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPSTransferChunkState_ce_ptr, "tcsPrepared", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPSTransferChunkState_ce_ptr, "tcsActive", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPSTransferChunkState_ce_ptr, "tcsSucceeded", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBFTPSTransferChunkState_ce_ptr, "tcsFailed", 3)
}

void Register_SBSimpleFTPS_Aliases(TSRMLS_D)
{
	if (NULL == TElFTPProxySettings_ce_ptr)
		Register_TElFTPProxySettings(TSRMLS_C);
	zend_register_class_alias("TSBFTPProxySettings", TElFTPProxySettings_ce_ptr);
	if (NULL == TElSimpleFTPSClient_ce_ptr)
		Register_TElSimpleFTPSClient(TSRMLS_C);
	zend_register_class_alias("ElSimpleFTPSClient", TElSimpleFTPSClient_ce_ptr);
}
