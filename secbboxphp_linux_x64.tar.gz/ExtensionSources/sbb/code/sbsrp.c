#include "sbsrp.h"

zend_class_entry *TSBSRPCredentialPrimeLen_ce_ptr = NULL;

zend_class_entry *TElSRPCredential_ce_ptr = NULL;

SB_PHP_METHOD(TElSRPCredential, Generate)
{
	char *sPassword;
	char *sUsername;
	sb_str_size sPassword_len;
	sb_str_size sUsername_len;
	sb_zend_long fPrimeLen;
	SBArrayZValInfo aiGenerator;
	SBArrayZValInfo aiPrime;
	zval *zaGenerator;
	zval *zaPrime;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssl", &sUsername, &sUsername_len, &sPassword, &sPassword_len, &fPrimeLen) == SUCCESS)
	{
		SBCheckError(TElSRPCredential_Generate(SBGetObjectHandle(getThis() TSRMLS_CC), sUsername, (int32_t)sUsername_len, sPassword, (int32_t)sPassword_len, (TSBSRPCredentialPrimeLenRaw)fPrimeLen) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sszz", &sUsername, &sUsername_len, &sPassword, &sPassword_len, &zaPrime, &zaGenerator) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaPrime) || SB_IS_ARRAY_TYPE_RP(zaPrime) || SB_IS_NULL_TYPE_RP(zaPrime)) && (SB_IS_STRING_TYPE_RP(zaGenerator) || SB_IS_ARRAY_TYPE_RP(zaGenerator) || SB_IS_NULL_TYPE_RP(zaGenerator)))
	{
		if (!SBGetByteArrayFromZVal(zaPrime, &aiPrime TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaGenerator, &aiGenerator TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSRPCredential_Generate_1(SBGetObjectHandle(getThis() TSRMLS_CC), sUsername, (int32_t)sUsername_len, sPassword, (int32_t)sPassword_len, aiPrime.data, aiPrime.len, aiGenerator.data, aiGenerator.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiPrime);
		SBFreeArrayZValInfo(&aiGenerator);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, integer) or (string, string, array of byte|string|NULL, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredential, Load)
{
	char *sData;
	char *sUsername;
	sb_str_size sData_len;
	sb_str_size sUsername_len;
	SBArrayZValInfo aiGenerator;
	SBArrayZValInfo aiPrime;
	SBArrayZValInfo aiSalt;
	SBArrayZValInfo aiVerifier;
	zval *zaGenerator;
	zval *zaPrime;
	zval *zaSalt;
	zval *zaVerifier;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sData, &sData_len) == SUCCESS)
	{
		SBCheckError(TElSRPCredential_Load(SBGetObjectHandle(getThis() TSRMLS_CC), sData, (int32_t)sData_len) TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szzzz", &sUsername, &sUsername_len, &zaSalt, &zaPrime, &zaGenerator, &zaVerifier) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSalt) || SB_IS_ARRAY_TYPE_RP(zaSalt) || SB_IS_NULL_TYPE_RP(zaSalt)) && (SB_IS_STRING_TYPE_RP(zaPrime) || SB_IS_ARRAY_TYPE_RP(zaPrime) || SB_IS_NULL_TYPE_RP(zaPrime)) && (SB_IS_STRING_TYPE_RP(zaGenerator) || SB_IS_ARRAY_TYPE_RP(zaGenerator) || SB_IS_NULL_TYPE_RP(zaGenerator)) && (SB_IS_STRING_TYPE_RP(zaVerifier) || SB_IS_ARRAY_TYPE_RP(zaVerifier) || SB_IS_NULL_TYPE_RP(zaVerifier)))
	{
		if (!SBGetByteArrayFromZVal(zaSalt, &aiSalt TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaPrime, &aiPrime TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaGenerator, &aiGenerator TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaVerifier, &aiVerifier TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSRPCredential_Load_1(SBGetObjectHandle(getThis() TSRMLS_CC), sUsername, (int32_t)sUsername_len, aiSalt.data, aiSalt.len, aiPrime.data, aiPrime.len, aiGenerator.data, aiGenerator.len, aiVerifier.data, aiVerifier.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiSalt);
		SBFreeArrayZValInfo(&aiPrime);
		SBFreeArrayZValInfo(&aiGenerator);
		SBFreeArrayZValInfo(&aiVerifier);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string, array of byte|string|NULL, array of byte|string|NULL, array of byte|string|NULL, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredential, Save)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSRPCredential_Save(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-771191387, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredential, get_Username)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSRPCredential_get_Username(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1256693578, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredential, get_Prime)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSRPCredential_get_Prime(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-228639922, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredential, get_Generator)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSRPCredential_get_Generator(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-192798531, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredential, set_Generator)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSRPCredential_set_Generator(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredential, get_Salt)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSRPCredential_get_Salt(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(687009396, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredential, get_Verifier)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSRPCredential_get_Verifier(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1227412343, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredential, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSRPCredential_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredential_Generate, 0, 0, 3)
	ZEND_ARG_INFO(0, Username)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_TYPE_INFO(0, PrimeLen_or_Prime, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Generator, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredential_Load, 0, 0, 1)
	ZEND_ARG_INFO(0, Data_or_Username)
	ZEND_ARG_TYPE_INFO(0, Salt, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Prime, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Generator, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Verifier, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredential_Save, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredential_get_Username, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredential_get_Prime, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredential_get_Generator, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredential_set_Generator, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredential_get_Salt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredential_get_Verifier, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredential___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSRPCredential_methods[] = {
	PHP_ME(TElSRPCredential, Generate, arginfo_TElSRPCredential_Generate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredential, Load, arginfo_TElSRPCredential_Load, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredential, Save, arginfo_TElSRPCredential_Save, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredential, get_Username, arginfo_TElSRPCredential_get_Username, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredential, get_Prime, arginfo_TElSRPCredential_get_Prime, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredential, get_Generator, arginfo_TElSRPCredential_get_Generator, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredential, set_Generator, arginfo_TElSRPCredential_set_Generator, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredential, get_Salt, arginfo_TElSRPCredential_get_Salt, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredential, get_Verifier, arginfo_TElSRPCredential_get_Verifier, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredential, __construct, arginfo_TElSRPCredential___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSRPCredential(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSRPCredential_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSRPCredential", TElSRPCredential_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSRPCredential_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSRPCredentialStore_ce_ptr = NULL;

SB_PHP_METHOD(TElSRPCredentialStore, Add)
{
	char *sPassword;
	char *sUsername;
	sb_str_size sPassword_len;
	sb_str_size sUsername_len;
	sb_zend_long fPrimeLen;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSRPCredentialStore_Add(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssl", &sUsername, &sUsername_len, &sPassword, &sPassword_len, &fPrimeLen) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSRPCredentialStore_Add_1(SBGetObjectHandle(getThis() TSRMLS_CC), sUsername, (int32_t)sUsername_len, sPassword, (int32_t)sPassword_len, (TSBSRPCredentialPrimeLenRaw)fPrimeLen, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("() or (string, string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredentialStore, Remove)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElSRPCredentialStore_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredentialStore, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSRPCredentialStore_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredentialStore, LoadFromStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSRPCredentialStore_LoadFromStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredentialStore, SaveToStream)
{
	zval *oStream;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStream, TStream_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSRPCredentialStore_SaveToStream(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStream TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStream)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredentialStore, get_Credentials)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSRPCredentialStore_get_Credentials(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSRPCredential_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredentialStore, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSRPCredentialStore_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPCredentialStore, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSRPCredentialStore_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredentialStore_Add, 0, 0, 0)
	ZEND_ARG_INFO(0, Username)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_INFO(0, PrimeLen)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredentialStore_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredentialStore_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredentialStore_LoadFromStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredentialStore_SaveToStream, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Stream, TStream, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredentialStore_get_Credentials, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredentialStore_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPCredentialStore___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSRPCredentialStore_methods[] = {
	PHP_ME(TElSRPCredentialStore, Add, arginfo_TElSRPCredentialStore_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredentialStore, Remove, arginfo_TElSRPCredentialStore_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredentialStore, Clear, arginfo_TElSRPCredentialStore_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredentialStore, LoadFromStream, arginfo_TElSRPCredentialStore_LoadFromStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredentialStore, SaveToStream, arginfo_TElSRPCredentialStore_SaveToStream, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredentialStore, get_Credentials, arginfo_TElSRPCredentialStore_get_Credentials, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredentialStore, get_Count, arginfo_TElSRPCredentialStore_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPCredentialStore, __construct, arginfo_TElSRPCredentialStore___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSRPCredentialStore(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSRPCredentialStore_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSRPCredentialStore", TElSRPCredentialStore_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElSRPCredentialStore_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

void Register_SBSRP_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBSRPCredentialPrimeLen", NULL);
	TSBSRPCredentialPrimeLen_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSRPCredentialPrimeLen_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSRPCredentialPrimeLen_ce_ptr, "srppl1024", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSRPCredentialPrimeLen_ce_ptr, "srpp1536", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSRPCredentialPrimeLen_ce_ptr, "srpp2048", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSRPCredentialPrimeLen_ce_ptr, "srpp3072", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBSRPCredentialPrimeLen_ce_ptr, "srpp4096", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSRPCredentialPrimeLen_ce_ptr, "srpp6144", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBSRPCredentialPrimeLen_ce_ptr, "srpp8192", 6)
}

