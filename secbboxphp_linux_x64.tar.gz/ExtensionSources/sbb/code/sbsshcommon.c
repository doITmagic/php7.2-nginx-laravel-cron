#include "sbsshcommon.h"

zend_class_entry *TSSHTunnelType_ce_ptr = NULL;

zend_class_entry *TSSHCloseType_ce_ptr = NULL;

zend_class_entry *TSBSSHAuthOrder_ce_ptr = NULL;

void SB_CALLBACK TSSHSendEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zBuffer;
	zval * zSize;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 1);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSize, 2);
	ZVAL_LONG(zSize, (sb_zend_long)Size);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zSize);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHReceiveEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t MaxSize, int32_t * Written)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zBuffer;
	zval * zMaxSize;
	zval * zWritten;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 1);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zMaxSize, 2);
	ZVAL_LONG(zMaxSize, (sb_zend_long)MaxSize);
	SB_EVENT_INIT_ZVAL_REF(zWritten, 3);
	ZVAL_LONG(Z_REFVAL_P(zWritten), 0);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zMaxSize);
	convert_to_long(Z_REFVAL_P(zWritten));
	*Written = (int32_t)Z_LVAL_P(Z_REFVAL_P(zWritten));
	SB_EVENT_CLEAR_ZVAL(zWritten);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHDataEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zBuffer;
	zval * zSize;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 1);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSize, 2);
	ZVAL_LONG(zSize, (sb_zend_long)Size);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zSize);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHOpenConnectionEventRaw(void * _ObjectData, TObjectHandle Sender)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(1);
	zval * zSender;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 1, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHCloseConnectionEventRaw(void * _ObjectData, TObjectHandle Sender)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(1);
	zval * zSender;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 1, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHChannelCloseEventRaw(void * _ObjectData, TObjectHandle Sender, TSSHCloseTypeRaw CloseType)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zCloseType;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCloseType, 1);
	ZVAL_LONG(zCloseType, (sb_zend_long)CloseType);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zCloseType);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHErrorEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zErrorCode;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zErrorCode, 1);
	ZVAL_LONG(zErrorCode, (sb_zend_long)ErrorCode);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHPrivateKeyNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHKeyHandle Key, int8_t * Skip)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zKey;
	zval * zSkip;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zKey, 1);
	SBInitObject(zKey, TElSSHKey_ce_ptr, Key TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zSkip, 2);
	ZVAL_BOOL(Z_REFVAL_P(zSkip), (zend_bool)*Skip);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zKey);
	convert_to_boolean(Z_REFVAL_P(zSkip));
	*Skip = (int8_t)SB_BVAL_P(Z_REFVAL_P(zSkip));
	SB_EVENT_CLEAR_ZVAL(zSkip);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHKexInitReceivedEventRaw(void * _ObjectData, TObjectHandle Sender, TElStringListHandle KexLines)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zKexLines;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zKexLines, 1);
	SBInitObject(zKexLines, TElStringList_ce_ptr, KexLines TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zKexLines);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TTunnelEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle TunnelConnection)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zTunnelConnection;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTunnelConnection, 1);
	SBInitObject(zTunnelConnection, TElSSHTunnelConnection_ce_ptr, TunnelConnection TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zTunnelConnection);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TTunnelDataEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle TunnelConnection, void * Buffer, int32_t Size)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zTunnelConnection;
	zval * zBuffer;
	zval * zSize;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTunnelConnection, 1);
	SBInitObject(zTunnelConnection, TElSSHTunnelConnection_ce_ptr, TunnelConnection TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 2);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSize, 3);
	ZVAL_LONG(zSize, (sb_zend_long)Size);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zTunnelConnection);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zSize);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TTunnelErrorEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t Error, void * Data)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zError;
	zval * zData;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zError, 1);
	ZVAL_LONG(zError, (sb_zend_long)Error);
	SB_EVENT_INIT_ZVAL(zData, 2);
	SBInitPointerObject(zData, Data TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zError);
	SB_EVENT_CLEAR_ZVAL(zData);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHAuthenticationFailedEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t AuthenticationType)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zAuthenticationType;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zAuthenticationType, 1);
	ZVAL_LONG(zAuthenticationType, (sb_zend_long)AuthenticationType);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zAuthenticationType);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHAuthenticationKeyboardEventRaw(void * _ObjectData, TObjectHandle Sender, TStringListHandle Prompts, TBitsHandle Echo, TStringListHandle Responses)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zPrompts;
	zval * zEcho;
	zval * zResponses;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPrompts, 1);
	SBInitObject(zPrompts, TStringList_ce_ptr, Prompts TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zEcho, 2);
	SBInitObject(zEcho, TBits_ce_ptr, Echo TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zResponses, 3);
	SBInitObject(zResponses, TStringList_ce_ptr, Responses TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPrompts);
	SB_EVENT_CLEAR_ZVAL(zEcho);
	SB_EVENT_CLEAR_ZVAL(zResponses);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHAuthenticationStartEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t SupportedAuths)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zSupportedAuths;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSupportedAuths, 1);
	ZVAL_LONG(zSupportedAuths, (sb_zend_long)SupportedAuths);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSupportedAuths);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHAuthenticationAttemptEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t AuthType, TObjectHandle AuthParam)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zAuthType;
	zval * zAuthParam;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zAuthType, 1);
	ZVAL_LONG(zAuthType, (sb_zend_long)AuthType);
	SB_EVENT_INIT_ZVAL(zAuthParam, 2);
	SBInitObject(zAuthParam, TObject_ce_ptr, AuthParam TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zAuthType);
	SB_EVENT_CLEAR_ZVAL(zAuthParam);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHKeyValidateEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHKeyHandle ServerKey, int8_t * Validate)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zServerKey;
	zval * zValidate;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zServerKey, 1);
	SBInitObject(zServerKey, TElSSHKey_ce_ptr, ServerKey TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zValidate, 2);
	ZVAL_BOOL(Z_REFVAL_P(zValidate), (zend_bool)*Validate);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zServerKey);
	convert_to_boolean(Z_REFVAL_P(zValidate));
	*Validate = (int8_t)SB_BVAL_P(Z_REFVAL_P(zValidate));
	SB_EVENT_CLEAR_ZVAL(zValidate);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHBannerEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pText[], int32_t szText, const uint8_t pLanguage[], int32_t szLanguage)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zText;
	zval * zLanguage;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zText, 1);
	SB_ZVAL_STRINGL_DUP(zText, pText, szText);
	SB_EVENT_INIT_ZVAL(zLanguage, 2);
	SB_ZVAL_STRINGL_DUP(zLanguage, pLanguage, szLanguage);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zText);
	SB_EVENT_CLEAR_ZVAL(zLanguage);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHMessageLoopEventRaw(void * _ObjectData, int8_t * OutResult)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(pzOutResult);
	TSRMLS_FETCH();

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(pzOutResult), 0, NULL TSRMLS_CC);

	if (pzOutResult)
	{
		convert_to_boolean(pzOutResult);
		*OutResult = (int8_t)SB_BVAL_P(pzOutResult);
		SB_EVENT_CLEAR_ZVAL(pzOutResult);
	}
}

void SB_CALLBACK TSSHWindowChangedEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t Cols, int32_t Rows, int32_t Width, int32_t Height)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zCols;
	zval * zRows;
	zval * zWidth;
	zval * zHeight;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCols, 1);
	ZVAL_LONG(zCols, (sb_zend_long)Cols);
	SB_EVENT_INIT_ZVAL(zRows, 2);
	ZVAL_LONG(zRows, (sb_zend_long)Rows);
	SB_EVENT_INIT_ZVAL(zWidth, 3);
	ZVAL_LONG(zWidth, (sb_zend_long)Width);
	SB_EVENT_INIT_ZVAL(zHeight, 4);
	ZVAL_LONG(zHeight, (sb_zend_long)Height);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zCols);
	SB_EVENT_CLEAR_ZVAL(zRows);
	SB_EVENT_CLEAR_ZVAL(zWidth);
	SB_EVENT_CLEAR_ZVAL(zHeight);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHCommandExecutionEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcCommand, int32_t szCommand, int32_t CommandIdx)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zCommand;
	zval * zCommandIdx;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCommand, 1);
	SB_ZVAL_STRINGL_DUP(zCommand, pcCommand, szCommand);
	SB_EVENT_INIT_ZVAL(zCommandIdx, 2);
	ZVAL_LONG(zCommandIdx, (sb_zend_long)CommandIdx);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zCommand);
	SB_EVENT_CLEAR_ZVAL(zCommandIdx);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHPasswordChangeRequestEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPrompt, int32_t szPrompt, char * pcNewPassword, int32_t * szNewPassword, int8_t * Cancel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zPrompt;
	zval * zNewPassword;
	zval * zCancel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zPrompt, 1);
	SB_ZVAL_STRINGL_DUP(zPrompt, pcPrompt, szPrompt);
	SB_EVENT_INIT_ZVAL_REF(zNewPassword, 2);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zNewPassword), pcNewPassword, *szNewPassword);
	SB_EVENT_INIT_ZVAL_REF(zCancel, 3);
	ZVAL_BOOL(Z_REFVAL_P(zCancel), (zend_bool)*Cancel);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zPrompt);
	convert_to_string(Z_REFVAL_P(zNewPassword));
	SBCheckError(SBSetEventReturnStringA(3, Z_STRVAL_P(Z_REFVAL_P(zNewPassword)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zNewPassword))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zNewPassword);
	convert_to_boolean(Z_REFVAL_P(zCancel));
	*Cancel = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCancel));
	SB_EVENT_CLEAR_ZVAL(zCancel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHTunnelRequestEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomSSHTunnelHandle Tunnel, int8_t * Allow)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zTunnel;
	zval * zAllow;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zTunnel, 1);
	SBInitObject(zTunnel, TElCustomSSHTunnel_ce_ptr, Tunnel TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zAllow, 2);
	ZVAL_BOOL(Z_REFVAL_P(zAllow), (zend_bool)*Allow);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zTunnel);
	convert_to_boolean(Z_REFVAL_P(zAllow));
	*Allow = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAllow));
	SB_EVENT_CLEAR_ZVAL(zAllow);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHEOFEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t * CloseChannel)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zCloseChannel;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zCloseChannel, 1);
	ZVAL_BOOL(Z_REFVAL_P(zCloseChannel), (zend_bool)*CloseChannel);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	convert_to_boolean(Z_REFVAL_P(zCloseChannel));
	*CloseChannel = (int8_t)SB_BVAL_P(Z_REFVAL_P(zCloseChannel));
	SB_EVENT_CLEAR_ZVAL(zCloseChannel);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSSHReceiveState_ce_ptr = NULL;

void SB_CALLBACK TSSHCertificateValidateEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomCertStorageHandle CertStorage, TElOCSPResponseStorageHandle OCSPStorage, int8_t * Validate)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zCertStorage;
	zval * zOCSPStorage;
	zval * zValidate;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCertStorage, 1);
	SBInitObject(zCertStorage, TElCustomCertStorage_ce_ptr, CertStorage TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOCSPStorage, 2);
	SBInitObject(zOCSPStorage, TElOCSPResponseStorage_ce_ptr, OCSPStorage TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zValidate, 3);
	ZVAL_BOOL(Z_REFVAL_P(zValidate), (zend_bool)*Validate);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zCertStorage);
	SB_EVENT_CLEAR_ZVAL(zOCSPStorage);
	convert_to_boolean(Z_REFVAL_P(zValidate));
	*Validate = (int8_t)SB_BVAL_P(Z_REFVAL_P(zValidate));
	SB_EVENT_CLEAR_ZVAL(zValidate);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSSHVersion_ce_ptr = NULL;

zend_class_entry *TSSHVersions_ce_ptr = NULL;

zend_class_entry *TSSHStandardAlgorithmPriorityTemplate_ce_ptr = NULL;

zend_class_entry *TSSH1State_ce_ptr = NULL;

SB_PHP_METHOD(TDHParams, __construct)
{
	if (ZEND_NUM_ARGS() == 0)
	{
		php_sbb_struct * intern = Z_SBSTRUCT_P(getThis());
		intern->data = emalloc(sizeof(TDHParams));
		intern->len = sizeof(TDHParams);
		memset(intern->data, 0, sizeof(TDHParams));
		intern->ownData = 1;
	}
	else
		ZEND_WRONG_PARAM_COUNT();
}

SB_PHP_METHOD(TDHParams, getSizeOf)
{
	if (ZEND_NUM_ARGS() > 0)
		ZEND_WRONG_PARAM_COUNT();

	RETURN_LONG(sizeof(TDHParams));
}

zend_class_entry *TDHParams_ce_ptr = NULL;

static zend_function_entry TDHParams_methods[] = {
	PHP_ME(TDHParams, __construct, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(TDHParams, getSizeOf, NULL, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TDHParams(TSRMLS_D)
{
	zend_class_entry ce;
	if (TDHParams_ce_ptr != NULL)
		return;
	INIT_CLASS_ENTRY(ce, "TDHParams", TDHParams_methods);
	TDHParams_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseStruct_ce_ptr);
}

SB_PHP_METHOD(TECDHParams, __construct)
{
	if (ZEND_NUM_ARGS() == 0)
	{
		php_sbb_struct * intern = Z_SBSTRUCT_P(getThis());
		intern->data = emalloc(sizeof(TECDHParams));
		intern->len = sizeof(TECDHParams);
		memset(intern->data, 0, sizeof(TECDHParams));
		intern->ownData = 1;
	}
	else
		ZEND_WRONG_PARAM_COUNT();
}

SB_PHP_METHOD(TECDHParams, getSizeOf)
{
	if (ZEND_NUM_ARGS() > 0)
		ZEND_WRONG_PARAM_COUNT();

	RETURN_LONG(sizeof(TECDHParams));
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBBaseStruct_GetField, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TSBBaseStruct_SetField, 0, 0, 1)
	ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

SB_PHP_METHOD(TECDHParams, get_CurveID)
{
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}

SB_PHP_METHOD(TECDHParams, set_CurveID)
{
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}

zend_class_entry *TECDHParams_ce_ptr = NULL;

static zend_function_entry TECDHParams_methods[] = {
	PHP_ME(TECDHParams, __construct, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(TECDHParams, getSizeOf, NULL, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TECDHParams, get_CurveID, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TECDHParams, set_CurveID, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TECDHParams(TSRMLS_D)
{
	zend_class_entry ce;
	if (TECDHParams_ce_ptr != NULL)
		return;
	INIT_CLASS_ENTRY(ce, "TECDHParams", TECDHParams_methods);
	TECDHParams_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseStruct_ce_ptr);
}

SB_PHP_METHOD(TC25519Params, __construct)
{
	if (ZEND_NUM_ARGS() == 0)
	{
		php_sbb_struct * intern = Z_SBSTRUCT_P(getThis());
		intern->data = emalloc(sizeof(TC25519Params));
		intern->len = sizeof(TC25519Params);
		memset(intern->data, 0, sizeof(TC25519Params));
		intern->ownData = 1;
	}
	else
		ZEND_WRONG_PARAM_COUNT();
}

SB_PHP_METHOD(TC25519Params, getSizeOf)
{
	if (ZEND_NUM_ARGS() > 0)
		ZEND_WRONG_PARAM_COUNT();

	RETURN_LONG(sizeof(TC25519Params));
}

zend_class_entry *TC25519Params_ce_ptr = NULL;

static zend_function_entry TC25519Params_methods[] = {
	PHP_ME(TC25519Params, __construct, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(TC25519Params, getSizeOf, NULL, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TC25519Params(TSRMLS_D)
{
	zend_class_entry ce;
	if (TC25519Params_ce_ptr != NULL)
		return;
	INIT_CLASS_ENTRY(ce, "TC25519Params", TC25519Params_methods);
	TC25519Params_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseStruct_ce_ptr);
}

SB_PHP_METHOD(TC448Params, __construct)
{
	if (ZEND_NUM_ARGS() == 0)
	{
		php_sbb_struct * intern = Z_SBSTRUCT_P(getThis());
		intern->data = emalloc(sizeof(TC448Params));
		intern->len = sizeof(TC448Params);
		memset(intern->data, 0, sizeof(TC448Params));
		intern->ownData = 1;
	}
	else
		ZEND_WRONG_PARAM_COUNT();
}

SB_PHP_METHOD(TC448Params, getSizeOf)
{
	if (ZEND_NUM_ARGS() > 0)
		ZEND_WRONG_PARAM_COUNT();

	RETURN_LONG(sizeof(TC448Params));
}

zend_class_entry *TC448Params_ce_ptr = NULL;

static zend_function_entry TC448Params_methods[] = {
	PHP_ME(TC448Params, __construct, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(TC448Params, getSizeOf, NULL, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TC448Params(TSRMLS_D)
{
	zend_class_entry ce;
	if (TC448Params_ce_ptr != NULL)
		return;
	INIT_CLASS_ENTRY(ce, "TC448Params", TC448Params_methods);
	TC448Params_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseStruct_ce_ptr);
}

SB_PHP_METHOD(TRSAParams, __construct)
{
	if (ZEND_NUM_ARGS() == 0)
	{
		php_sbb_struct * intern = Z_SBSTRUCT_P(getThis());
		intern->data = emalloc(sizeof(TRSAParams));
		intern->len = sizeof(TRSAParams);
		memset(intern->data, 0, sizeof(TRSAParams));
		intern->ownData = 1;
	}
	else
		ZEND_WRONG_PARAM_COUNT();
}

SB_PHP_METHOD(TRSAParams, getSizeOf)
{
	if (ZEND_NUM_ARGS() > 0)
		ZEND_WRONG_PARAM_COUNT();

	RETURN_LONG(sizeof(TRSAParams));
}

zend_class_entry *TRSAParams_ce_ptr = NULL;

static zend_function_entry TRSAParams_methods[] = {
	PHP_ME(TRSAParams, __construct, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(TRSAParams, getSizeOf, NULL, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TRSAParams(TSRMLS_D)
{
	zend_class_entry ce;
	if (TRSAParams_ce_ptr != NULL)
		return;
	INIT_CLASS_ENTRY(ce, "TRSAParams", TRSAParams_methods);
	TRSAParams_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseStruct_ce_ptr);
}

SB_PHP_METHOD(THandshakeParams, __construct)
{
	if (ZEND_NUM_ARGS() == 0)
	{
		php_sbb_struct * intern = Z_SBSTRUCT_P(getThis());
		intern->data = emalloc(sizeof(THandshakeParams));
		intern->len = sizeof(THandshakeParams);
		memset(intern->data, 0, sizeof(THandshakeParams));
		intern->ownData = 1;
	}
	else
		ZEND_WRONG_PARAM_COUNT();
}

SB_PHP_METHOD(THandshakeParams, getSizeOf)
{
	if (ZEND_NUM_ARGS() > 0)
		ZEND_WRONG_PARAM_COUNT();

	RETURN_LONG(sizeof(THandshakeParams));
}

zend_class_entry *THandshakeParams_ce_ptr = NULL;

static zend_function_entry THandshakeParams_methods[] = {
	PHP_ME(THandshakeParams, __construct, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(THandshakeParams, getSizeOf, NULL, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_THandshakeParams(TSRMLS_D)
{
	zend_class_entry ce;
	if (THandshakeParams_ce_ptr != NULL)
		return;
	INIT_CLASS_ENTRY(ce, "THandshakeParams", THandshakeParams_methods);
	THandshakeParams_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseStruct_ce_ptr);
}

SB_PHP_METHOD(TSSH1Params, __construct)
{
	if (ZEND_NUM_ARGS() == 0)
	{
		php_sbb_struct * intern = Z_SBSTRUCT_P(getThis());
		intern->data = emalloc(sizeof(TSSH1Params));
		intern->len = sizeof(TSSH1Params);
		memset(intern->data, 0, sizeof(TSSH1Params));
		intern->ownData = 1;
	}
	else
		ZEND_WRONG_PARAM_COUNT();
}

SB_PHP_METHOD(TSSH1Params, getSizeOf)
{
	if (ZEND_NUM_ARGS() > 0)
		ZEND_WRONG_PARAM_COUNT();

	RETURN_LONG(sizeof(TSSH1Params));
}

SB_PHP_METHOD(TSSH1Params, get_Cipher)
{
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}

SB_PHP_METHOD(TSSH1Params, set_Cipher)
{
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}

SB_PHP_METHOD(TSSH1Params, get_Auth)
{
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 4);
}

SB_PHP_METHOD(TSSH1Params, set_Auth)
{
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 4);
}

zend_class_entry *TSSH1Params_ce_ptr = NULL;

static zend_function_entry TSSH1Params_methods[] = {
	PHP_ME(TSSH1Params, __construct, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH1Params, getSizeOf, NULL, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TSSH1Params, get_Cipher, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH1Params, set_Cipher, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH1Params, get_Auth, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH1Params, set_Auth, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TSSH1Params(TSRMLS_D)
{
	zend_class_entry ce;
	if (TSSH1Params_ce_ptr != NULL)
		return;
	INIT_CLASS_ENTRY(ce, "TSSH1Params", TSSH1Params_methods);
	TSSH1Params_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseStruct_ce_ptr);
}

SB_PHP_METHOD(TSSH2Params, __construct)
{
	if (ZEND_NUM_ARGS() == 0)
	{
		php_sbb_struct * intern = Z_SBSTRUCT_P(getThis());
		intern->data = emalloc(sizeof(TSSH2Params));
		intern->len = sizeof(TSSH2Params);
		memset(intern->data, 0, sizeof(TSSH2Params));
		intern->ownData = 1;
	}
	else
		ZEND_WRONG_PARAM_COUNT();
}

SB_PHP_METHOD(TSSH2Params, getSizeOf)
{
	if (ZEND_NUM_ARGS() > 0)
		ZEND_WRONG_PARAM_COUNT();

	RETURN_LONG(sizeof(TSSH2Params));
}

SB_PHP_METHOD(TSSH2Params, get_KexAlgorithm)
{
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}

SB_PHP_METHOD(TSSH2Params, set_KexAlgorithm)
{
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}

SB_PHP_METHOD(TSSH2Params, get_ServerHostKeyAlgorithm)
{
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 4);
}

SB_PHP_METHOD(TSSH2Params, set_ServerHostKeyAlgorithm)
{
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 4);
}

SB_PHP_METHOD(TSSH2Params, get_EncryptionAlgorithmCS)
{
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 8);
}

SB_PHP_METHOD(TSSH2Params, set_EncryptionAlgorithmCS)
{
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 8);
}

SB_PHP_METHOD(TSSH2Params, get_EncryptionAlgorithmSC)
{
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 12);
}

SB_PHP_METHOD(TSSH2Params, set_EncryptionAlgorithmSC)
{
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 12);
}

SB_PHP_METHOD(TSSH2Params, get_EncCSBlockSize)
{
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 16);
}

SB_PHP_METHOD(TSSH2Params, set_EncCSBlockSize)
{
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 16);
}

SB_PHP_METHOD(TSSH2Params, get_EncSCBlockSize)
{
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 20);
}

SB_PHP_METHOD(TSSH2Params, set_EncSCBlockSize)
{
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 20);
}

SB_PHP_METHOD(TSSH2Params, get_MacAlgorithmCS)
{
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 24);
}

SB_PHP_METHOD(TSSH2Params, set_MacAlgorithmCS)
{
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 24);
}

SB_PHP_METHOD(TSSH2Params, get_MacAlgorithmSC)
{
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 28);
}

SB_PHP_METHOD(TSSH2Params, set_MacAlgorithmSC)
{
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 28);
}

SB_PHP_METHOD(TSSH2Params, get_CompAlgorithmCS)
{
#ifndef CPU64
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 40);
}

#else
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 48);
}
#endif

SB_PHP_METHOD(TSSH2Params, set_CompAlgorithmCS)
{
#ifndef CPU64
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 40);
}

#else
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 48);
}
#endif

SB_PHP_METHOD(TSSH2Params, get_CompAlgorithmSC)
{
#ifndef CPU64
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 44);
}

#else
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 52);
}
#endif

SB_PHP_METHOD(TSSH2Params, set_CompAlgorithmSC)
{
#ifndef CPU64
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 44);
}

#else
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 52);
}
#endif

SB_PHP_METHOD(TSSH2Params, get_LanguageCS)
{
#ifndef CPU64
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 48);
}

#else
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 56);
}
#endif

SB_PHP_METHOD(TSSH2Params, set_LanguageCS)
{
#ifndef CPU64
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 48);
}

#else
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 56);
}
#endif

SB_PHP_METHOD(TSSH2Params, get_LanguageSC)
{
#ifndef CPU64
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 52);
}

#else
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 60);
}
#endif

SB_PHP_METHOD(TSSH2Params, set_LanguageSC)
{
#ifndef CPU64
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 52);
}

#else
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 60);
}
#endif

SB_PHP_METHOD(TSSH2Params, get_HashAlgorithm)
{
#ifndef CPU64
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 56);
}

#else
	SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 64);
}
#endif

SB_PHP_METHOD(TSSH2Params, set_HashAlgorithm)
{
#ifndef CPU64
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 56);
#else
	SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAM_PASSTHRU, 64);
#endif
}

zend_class_entry *TSSH2Params_ce_ptr = NULL;

static zend_function_entry TSSH2Params_methods[] = {
	PHP_ME(TSSH2Params, __construct, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, getSizeOf, NULL, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TSSH2Params, get_KexAlgorithm, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, set_KexAlgorithm, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, get_ServerHostKeyAlgorithm, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, set_ServerHostKeyAlgorithm, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, get_EncryptionAlgorithmCS, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, set_EncryptionAlgorithmCS, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, get_EncryptionAlgorithmSC, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, set_EncryptionAlgorithmSC, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, get_EncCSBlockSize, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, set_EncCSBlockSize, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, get_EncSCBlockSize, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, set_EncSCBlockSize, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, get_MacAlgorithmCS, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, set_MacAlgorithmCS, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, get_MacAlgorithmSC, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, set_MacAlgorithmSC, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, get_CompAlgorithmCS, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, set_CompAlgorithmCS, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, get_CompAlgorithmSC, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, set_CompAlgorithmSC, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, get_LanguageCS, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, set_LanguageCS, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, get_LanguageSC, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, set_LanguageSC, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, get_HashAlgorithm, arginfo_TSBBaseStruct_GetField, ZEND_ACC_PUBLIC)
	PHP_ME(TSSH2Params, set_HashAlgorithm, arginfo_TSBBaseStruct_SetField, ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TSSH2Params(TSRMLS_D)
{
	zend_class_entry ce;
	if (TSSH2Params_ce_ptr != NULL)
		return;
	INIT_CLASS_ENTRY(ce, "TSSH2Params", TSSH2Params_methods);
	TSSH2Params_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseStruct_ce_ptr);
}

zend_class_entry *IElSSHAuthHandlerContainer_ce_ptr = NULL;

zend_class_entry *TElSSHClass_ce_ptr = NULL;

SB_PHP_METHOD(TElSSHClass, Close)
{
	zend_bool bForced;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bForced) == SUCCESS)
	{
		SBCheckError(TElSSHClass_Close(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bForced) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, RenegotiateCiphers)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSSHClass_RenegotiateCiphers(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, AdjustAlgorithmPriorities)
{
	sb_zend_long fPriorities;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fPriorities) == SUCCESS)
	{
		SBCheckError(TElSSHClass_AdjustAlgorithmPriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (TSSHStandardAlgorithmPriorityTemplateRaw)fPriorities) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_Active)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHClass_get_Active(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_EncryptionAlgorithms)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHClass_get_EncryptionAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_EncryptionAlgorithms)
{
	sb_zend_long u1Index;
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &u1Index, &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_EncryptionAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_CompressionAlgorithms)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHClass_get_CompressionAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_CompressionAlgorithms)
{
	sb_zend_long u1Index;
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &u1Index, &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_CompressionAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_MacAlgorithms)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHClass_get_MacAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_MacAlgorithms)
{
	sb_zend_long u1Index;
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &u1Index, &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_MacAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_KexAlgorithms)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHClass_get_KexAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_KexAlgorithms)
{
	sb_zend_long u1Index;
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &u1Index, &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_KexAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_PublicKeyAlgorithms)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHClass_get_PublicKeyAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_PublicKeyAlgorithms)
{
	sb_zend_long u1Index;
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &u1Index, &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_PublicKeyAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_EncryptionAlgorithmPriorities)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_EncryptionAlgorithmPriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_EncryptionAlgorithmPriorities)
{
	sb_zend_long l4Value;
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &u1Index, &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_EncryptionAlgorithmPriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_CompressionAlgorithmPriorities)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_CompressionAlgorithmPriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_CompressionAlgorithmPriorities)
{
	sb_zend_long l4Value;
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &u1Index, &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_CompressionAlgorithmPriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_MacAlgorithmPriorities)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_MacAlgorithmPriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_MacAlgorithmPriorities)
{
	sb_zend_long l4Value;
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &u1Index, &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_MacAlgorithmPriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_KexAlgorithmPriorities)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_KexAlgorithmPriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_KexAlgorithmPriorities)
{
	sb_zend_long l4Value;
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &u1Index, &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_KexAlgorithmPriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_PublicKeyAlgorithmPriorities)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_PublicKeyAlgorithmPriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_PublicKeyAlgorithmPriorities)
{
	sb_zend_long l4Value;
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &u1Index, &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_PublicKeyAlgorithmPriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_EncryptionAlgorithmServerToClient)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_EncryptionAlgorithmServerToClient(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_EncryptionAlgorithmClientToServer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_EncryptionAlgorithmClientToServer(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_CompressionAlgorithmServerToClient)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_CompressionAlgorithmServerToClient(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_CompressionAlgorithmClientToServer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_CompressionAlgorithmClientToServer(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_MacAlgorithmServerToClient)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_MacAlgorithmServerToClient(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_MacAlgorithmClientToServer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_MacAlgorithmClientToServer(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_KexAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_KexAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_PublicKeyAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_PublicKeyAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_TotalBytesSent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_TotalBytesSent(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_TotalBytesReceived)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_TotalBytesReceived(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_SoftwareName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSSHClass_get_SoftwareName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1085508552, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_SoftwareName)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_SoftwareName(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_KeyStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHClass_get_KeyStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSHCustomKeyStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_KeyStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElSSHCustomKeyStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_KeyStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHCustomKeyStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_CertStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHClass_get_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_CertStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_CertStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_OCSPStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHClass_get_OCSPStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElOCSPResponseStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_OCSPStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElOCSPResponseStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_OCSPStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElOCSPResponseStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_ForceCompression)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHClass_get_ForceCompression(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_ForceCompression)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_ForceCompression(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_CompressionLevel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_CompressionLevel)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_CompressionLevel(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_AuthenticationTypes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHClass_get_AuthenticationTypes(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_AuthenticationTypes)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_AuthenticationTypes(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_CloseIfNoActiveTunnels)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHClass_get_CloseIfNoActiveTunnels(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_CloseIfNoActiveTunnels)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_CloseIfNoActiveTunnels(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_UseUTF8)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHClass_get_UseUTF8(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_UseUTF8)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_UseUTF8(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_CryptoProviderManager)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHClass_get_CryptoProviderManager(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoProviderManager_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_CryptoProviderManager)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCryptoProviderManager_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_CryptoProviderManager(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoProviderManager)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_NoCharacterEncoding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHClass_get_NoCharacterEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_NoCharacterEncoding)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_NoCharacterEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_LocalCharset)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSSHClass_get_LocalCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(390671671, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_LocalCharset)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_LocalCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_RemoteCharset)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSSHClass_get_RemoteCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(294764874, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_RemoteCharset)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_RemoteCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_ObfuscateHandshake)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHClass_get_ObfuscateHandshake(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_ObfuscateHandshake)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_ObfuscateHandshake(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_ObfuscationPassword)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSSHClass_get_ObfuscationPassword(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1516084409, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_ObfuscationPassword)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSSHClass_set_ObfuscationPassword(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_OnSend)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHSendEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHClass_get_OnSend(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_OnSend)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHClass_set_OnSend(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHSendEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHSendEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_OnReceive)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHReceiveEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHClass_get_OnReceive(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_OnReceive)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHClass_set_OnReceive(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHReceiveEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHReceiveEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_OnOpenConnection)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHOpenConnectionEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHClass_get_OnOpenConnection(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_OnOpenConnection)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHClass_set_OnOpenConnection(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHOpenConnectionEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHOpenConnectionEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_OnCloseConnection)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHCloseConnectionEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHClass_get_OnCloseConnection(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_OnCloseConnection)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHClass_set_OnCloseConnection(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHCloseConnectionEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHCloseConnectionEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_OnDebugData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHDataEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHClass_get_OnDebugData(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_OnDebugData)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHClass_set_OnDebugData(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHDataEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHDataEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_OnError)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHErrorEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHClass_get_OnError(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_OnError)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHClass_set_OnError(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHErrorEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHErrorEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_OnCiphersNegotiated)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHClass_get_OnCiphersNegotiated(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_OnCiphersNegotiated)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHClass_set_OnCiphersNegotiated(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_OnKexInitReceived)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHKexInitReceivedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHClass_get_OnKexInitReceived(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_OnKexInitReceived)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHClass_set_OnKexInitReceived(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHKexInitReceivedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHKexInitReceivedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, get_OnCertificateValidate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHCertificateValidateEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHClass_get_OnCertificateValidate(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, set_OnCertificateValidate)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHClass_set_OnCertificateValidate(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHCertificateValidateEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHCertificateValidateEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHClass, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHClass_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_Close, 0, 0, 1)
	ZEND_ARG_INFO(0, Forced)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_RenegotiateCiphers, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_AdjustAlgorithmPriorities, 0, 0, 1)
	ZEND_ARG_INFO(0, Priorities)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_Active, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_EncryptionAlgorithms, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_EncryptionAlgorithms, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_CompressionAlgorithms, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_CompressionAlgorithms, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_MacAlgorithms, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_MacAlgorithms, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_KexAlgorithms, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_KexAlgorithms, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_PublicKeyAlgorithms, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_PublicKeyAlgorithms, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_EncryptionAlgorithmPriorities, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_EncryptionAlgorithmPriorities, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_CompressionAlgorithmPriorities, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_CompressionAlgorithmPriorities, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_MacAlgorithmPriorities, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_MacAlgorithmPriorities, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_KexAlgorithmPriorities, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_KexAlgorithmPriorities, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_PublicKeyAlgorithmPriorities, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_PublicKeyAlgorithmPriorities, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_EncryptionAlgorithmServerToClient, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_EncryptionAlgorithmClientToServer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_CompressionAlgorithmServerToClient, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_CompressionAlgorithmClientToServer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_MacAlgorithmServerToClient, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_MacAlgorithmClientToServer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_KexAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_PublicKeyAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_TotalBytesSent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_TotalBytesReceived, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_SoftwareName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_SoftwareName, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_KeyStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_KeyStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElSSHCustomKeyStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_CertStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_CertStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_OCSPStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_OCSPStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElOCSPResponseStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_ForceCompression, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_ForceCompression, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_CompressionLevel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_CompressionLevel, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_AuthenticationTypes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_AuthenticationTypes, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_CloseIfNoActiveTunnels, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_CloseIfNoActiveTunnels, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_UseUTF8, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_UseUTF8, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_CryptoProviderManager, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_CryptoProviderManager, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCryptoProviderManager, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_NoCharacterEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_NoCharacterEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_LocalCharset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_LocalCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_RemoteCharset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_RemoteCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_ObfuscateHandshake, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_ObfuscateHandshake, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_ObfuscationPassword, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_ObfuscationPassword, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_OnSend, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_OnSend, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_OnReceive, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_OnReceive, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_OnOpenConnection, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_OnOpenConnection, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_OnCloseConnection, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_OnCloseConnection, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_OnDebugData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_OnDebugData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_OnError, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_OnError, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_OnCiphersNegotiated, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_OnCiphersNegotiated, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_OnKexInitReceived, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_OnKexInitReceived, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_get_OnCertificateValidate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass_set_OnCertificateValidate, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHClass___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSHClass_methods[] = {
	PHP_ME(TElSSHClass, Close, arginfo_TElSSHClass_Close, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, RenegotiateCiphers, arginfo_TElSSHClass_RenegotiateCiphers, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, AdjustAlgorithmPriorities, arginfo_TElSSHClass_AdjustAlgorithmPriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_Active, arginfo_TElSSHClass_get_Active, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_EncryptionAlgorithms, arginfo_TElSSHClass_get_EncryptionAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_EncryptionAlgorithms, arginfo_TElSSHClass_set_EncryptionAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_CompressionAlgorithms, arginfo_TElSSHClass_get_CompressionAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_CompressionAlgorithms, arginfo_TElSSHClass_set_CompressionAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_MacAlgorithms, arginfo_TElSSHClass_get_MacAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_MacAlgorithms, arginfo_TElSSHClass_set_MacAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_KexAlgorithms, arginfo_TElSSHClass_get_KexAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_KexAlgorithms, arginfo_TElSSHClass_set_KexAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_PublicKeyAlgorithms, arginfo_TElSSHClass_get_PublicKeyAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_PublicKeyAlgorithms, arginfo_TElSSHClass_set_PublicKeyAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_EncryptionAlgorithmPriorities, arginfo_TElSSHClass_get_EncryptionAlgorithmPriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_EncryptionAlgorithmPriorities, arginfo_TElSSHClass_set_EncryptionAlgorithmPriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_CompressionAlgorithmPriorities, arginfo_TElSSHClass_get_CompressionAlgorithmPriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_CompressionAlgorithmPriorities, arginfo_TElSSHClass_set_CompressionAlgorithmPriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_MacAlgorithmPriorities, arginfo_TElSSHClass_get_MacAlgorithmPriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_MacAlgorithmPriorities, arginfo_TElSSHClass_set_MacAlgorithmPriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_KexAlgorithmPriorities, arginfo_TElSSHClass_get_KexAlgorithmPriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_KexAlgorithmPriorities, arginfo_TElSSHClass_set_KexAlgorithmPriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_PublicKeyAlgorithmPriorities, arginfo_TElSSHClass_get_PublicKeyAlgorithmPriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_PublicKeyAlgorithmPriorities, arginfo_TElSSHClass_set_PublicKeyAlgorithmPriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_EncryptionAlgorithmServerToClient, arginfo_TElSSHClass_get_EncryptionAlgorithmServerToClient, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_EncryptionAlgorithmClientToServer, arginfo_TElSSHClass_get_EncryptionAlgorithmClientToServer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_CompressionAlgorithmServerToClient, arginfo_TElSSHClass_get_CompressionAlgorithmServerToClient, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_CompressionAlgorithmClientToServer, arginfo_TElSSHClass_get_CompressionAlgorithmClientToServer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_MacAlgorithmServerToClient, arginfo_TElSSHClass_get_MacAlgorithmServerToClient, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_MacAlgorithmClientToServer, arginfo_TElSSHClass_get_MacAlgorithmClientToServer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_KexAlgorithm, arginfo_TElSSHClass_get_KexAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_PublicKeyAlgorithm, arginfo_TElSSHClass_get_PublicKeyAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_TotalBytesSent, arginfo_TElSSHClass_get_TotalBytesSent, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_TotalBytesReceived, arginfo_TElSSHClass_get_TotalBytesReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_SoftwareName, arginfo_TElSSHClass_get_SoftwareName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_SoftwareName, arginfo_TElSSHClass_set_SoftwareName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_KeyStorage, arginfo_TElSSHClass_get_KeyStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_KeyStorage, arginfo_TElSSHClass_set_KeyStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_CertStorage, arginfo_TElSSHClass_get_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_CertStorage, arginfo_TElSSHClass_set_CertStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_OCSPStorage, arginfo_TElSSHClass_get_OCSPStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_OCSPStorage, arginfo_TElSSHClass_set_OCSPStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_ForceCompression, arginfo_TElSSHClass_get_ForceCompression, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_ForceCompression, arginfo_TElSSHClass_set_ForceCompression, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_CompressionLevel, arginfo_TElSSHClass_get_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_CompressionLevel, arginfo_TElSSHClass_set_CompressionLevel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_AuthenticationTypes, arginfo_TElSSHClass_get_AuthenticationTypes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_AuthenticationTypes, arginfo_TElSSHClass_set_AuthenticationTypes, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_CloseIfNoActiveTunnels, arginfo_TElSSHClass_get_CloseIfNoActiveTunnels, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_CloseIfNoActiveTunnels, arginfo_TElSSHClass_set_CloseIfNoActiveTunnels, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_UseUTF8, arginfo_TElSSHClass_get_UseUTF8, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_UseUTF8, arginfo_TElSSHClass_set_UseUTF8, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_CryptoProviderManager, arginfo_TElSSHClass_get_CryptoProviderManager, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_CryptoProviderManager, arginfo_TElSSHClass_set_CryptoProviderManager, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_NoCharacterEncoding, arginfo_TElSSHClass_get_NoCharacterEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_NoCharacterEncoding, arginfo_TElSSHClass_set_NoCharacterEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_LocalCharset, arginfo_TElSSHClass_get_LocalCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_LocalCharset, arginfo_TElSSHClass_set_LocalCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_RemoteCharset, arginfo_TElSSHClass_get_RemoteCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_RemoteCharset, arginfo_TElSSHClass_set_RemoteCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_ObfuscateHandshake, arginfo_TElSSHClass_get_ObfuscateHandshake, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_ObfuscateHandshake, arginfo_TElSSHClass_set_ObfuscateHandshake, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_ObfuscationPassword, arginfo_TElSSHClass_get_ObfuscationPassword, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_ObfuscationPassword, arginfo_TElSSHClass_set_ObfuscationPassword, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_OnSend, arginfo_TElSSHClass_get_OnSend, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_OnSend, arginfo_TElSSHClass_set_OnSend, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_OnReceive, arginfo_TElSSHClass_get_OnReceive, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_OnReceive, arginfo_TElSSHClass_set_OnReceive, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_OnOpenConnection, arginfo_TElSSHClass_get_OnOpenConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_OnOpenConnection, arginfo_TElSSHClass_set_OnOpenConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_OnCloseConnection, arginfo_TElSSHClass_get_OnCloseConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_OnCloseConnection, arginfo_TElSSHClass_set_OnCloseConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_OnDebugData, arginfo_TElSSHClass_get_OnDebugData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_OnDebugData, arginfo_TElSSHClass_set_OnDebugData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_OnError, arginfo_TElSSHClass_get_OnError, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_OnError, arginfo_TElSSHClass_set_OnError, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_OnCiphersNegotiated, arginfo_TElSSHClass_get_OnCiphersNegotiated, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_OnCiphersNegotiated, arginfo_TElSSHClass_set_OnCiphersNegotiated, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_OnKexInitReceived, arginfo_TElSSHClass_get_OnKexInitReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_OnKexInitReceived, arginfo_TElSSHClass_set_OnKexInitReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, get_OnCertificateValidate, arginfo_TElSSHClass_get_OnCertificateValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, set_OnCertificateValidate, arginfo_TElSSHClass_set_OnCertificateValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHClass, __construct, arginfo_TElSSHClass___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSHClass(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSHClass_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSHClass", TElSSHClass_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElSSHClass_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElSSHTunnelList_ce_ptr = NULL;

SB_PHP_METHOD(TElSSHTunnelList, FindTunnel)
{
	char *sSubSystemName;
	char *sSubSystemType;
	sb_str_size sSubSystemName_len;
	sb_str_size sSubSystemType_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sSubSystemType, &sSubSystemType_len, &sSubSystemName, &sSubSystemName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHTunnelList_FindTunnel(SBGetObjectHandle(getThis() TSRMLS_CC), sSubSystemType, (int32_t)sSubSystemType_len, sSubSystemName, (int32_t)sSubSystemName_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomSSHTunnel_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelList, get_SSHClass)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHTunnelList_get_SSHClass(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSHClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelList, get_Tunnels)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHTunnelList_get_Tunnels(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomSSHTunnel_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelList, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHTunnelList_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelList, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHTunnelList_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelList_FindTunnel, 0, 0, 2)
	ZEND_ARG_INFO(0, SubSystemType)
	ZEND_ARG_INFO(0, SubSystemName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelList_get_SSHClass, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelList_get_Tunnels, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelList_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelList___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSHTunnelList_methods[] = {
	PHP_ME(TElSSHTunnelList, FindTunnel, arginfo_TElSSHTunnelList_FindTunnel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelList, get_SSHClass, arginfo_TElSSHTunnelList_get_SSHClass, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelList, get_Tunnels, arginfo_TElSSHTunnelList_get_Tunnels, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelList, get_Count, arginfo_TElSSHTunnelList_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelList, __construct, arginfo_TElSSHTunnelList___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSHTunnelList(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSHTunnelList_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSHTunnelList", TElSSHTunnelList_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElSSHTunnelList_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElCustomSSHTunnel_ce_ptr = NULL;

SB_PHP_METHOD(TElCustomSSHTunnel, DoOpen)
{
	zval *oConnection;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oConnection, TElSSHTunnelConnection_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomSSHTunnel_DoOpen(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oConnection TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHTunnelConnection)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, DoClose)
{
	zval *oConnection;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oConnection, TElSSHTunnelConnection_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomSSHTunnel_DoClose(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oConnection TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHTunnelConnection)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, DoError)
{
	sb_zend_long l4Error;
	SBArrayZValInfo piData;
	zval *zpData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &l4Error, &zpData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpData) || SB_IS_ARRAY_TYPE_RP(zpData) || SB_IS_NULL_TYPE_RP(zpData) || (SB_IS_OBJECT_TYPE_RP(zpData) && (Z_OBJCE_P(zpData) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpData, &piData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCustomSSHTunnel_DoError(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Error, piData.data) TSRMLS_CC);
		SBFreePointerZValInfo(&piData);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TSBPointer|array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, AddConnection)
{
	zval *oConn;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oConn, TElSSHTunnelConnection_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomSSHTunnel_AddConnection(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oConn TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHTunnelConnection)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, RemoveConnection)
{
	zval *oConn;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oConn, TElSSHTunnelConnection_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomSSHTunnel_RemoveConnection(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oConn TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHTunnelConnection)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, Open)
{
	SBArrayZValInfo piData;
	zval *zpData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zpData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpData) || SB_IS_ARRAY_TYPE_RP(zpData) || SB_IS_NULL_TYPE_RP(zpData) || (SB_IS_OBJECT_TYPE_RP(zpData) && (Z_OBJCE_P(zpData) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpData, &piData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCustomSSHTunnel_Open(SBGetObjectHandle(getThis() TSRMLS_CC), piData.data) TSRMLS_CC);
		SBFreePointerZValInfo(&piData);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, get_Connections)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSHTunnel_get_Connections(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSHTunnelConnection_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, get_ConnectionCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomSSHTunnel_get_ConnectionCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, get_ConnectionsList)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSHTunnel_get_ConnectionsList(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, get_AutoOpen)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomSSHTunnel_get_AutoOpen(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, set_AutoOpen)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCustomSSHTunnel_set_AutoOpen(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, get_TunnelList)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSHTunnel_get_TunnelList(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSHTunnelList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, set_TunnelList)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElSSHTunnelList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomSSHTunnel_set_TunnelList(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHTunnelList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, get_OnOpen)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TTunnelEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCustomSSHTunnel_get_OnOpen(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, set_OnOpen)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCustomSSHTunnel_set_OnOpen(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TTunnelEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TTunnelEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, get_OnClose)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TTunnelEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCustomSSHTunnel_get_OnClose(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, set_OnClose)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCustomSSHTunnel_set_OnClose(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TTunnelEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TTunnelEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, get_OnError)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TTunnelErrorEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCustomSSHTunnel_get_OnError(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, set_OnError)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCustomSSHTunnel_set_OnError(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TTunnelErrorEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TTunnelErrorEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHTunnel, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSHTunnel_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_DoOpen, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Connection, TElSSHTunnelConnection, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_DoClose, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Connection, TElSSHTunnelConnection, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_DoError, 0, 0, 2)
	ZEND_ARG_INFO(0, Error)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_AddConnection, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Conn, TElSSHTunnelConnection, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_RemoveConnection, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Conn, TElSSHTunnelConnection, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_Open, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_get_Connections, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_get_ConnectionCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_get_ConnectionsList, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_get_AutoOpen, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_set_AutoOpen, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_get_TunnelList, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_set_TunnelList, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElSSHTunnelList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_get_OnOpen, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_set_OnOpen, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_get_OnClose, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_set_OnClose, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_get_OnError, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel_set_OnError, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnel___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCustomSSHTunnel_methods[] = {
	PHP_ME(TElCustomSSHTunnel, DoOpen, arginfo_TElCustomSSHTunnel_DoOpen, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, DoClose, arginfo_TElCustomSSHTunnel_DoClose, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, DoError, arginfo_TElCustomSSHTunnel_DoError, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, AddConnection, arginfo_TElCustomSSHTunnel_AddConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, RemoveConnection, arginfo_TElCustomSSHTunnel_RemoveConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, Open, arginfo_TElCustomSSHTunnel_Open, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, get_Connections, arginfo_TElCustomSSHTunnel_get_Connections, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, get_ConnectionCount, arginfo_TElCustomSSHTunnel_get_ConnectionCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, get_ConnectionsList, arginfo_TElCustomSSHTunnel_get_ConnectionsList, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, get_AutoOpen, arginfo_TElCustomSSHTunnel_get_AutoOpen, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, set_AutoOpen, arginfo_TElCustomSSHTunnel_set_AutoOpen, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, get_TunnelList, arginfo_TElCustomSSHTunnel_get_TunnelList, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, set_TunnelList, arginfo_TElCustomSSHTunnel_set_TunnelList, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, get_OnOpen, arginfo_TElCustomSSHTunnel_get_OnOpen, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, set_OnOpen, arginfo_TElCustomSSHTunnel_set_OnOpen, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, get_OnClose, arginfo_TElCustomSSHTunnel_get_OnClose, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, set_OnClose, arginfo_TElCustomSSHTunnel_set_OnClose, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, get_OnError, arginfo_TElCustomSSHTunnel_get_OnError, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, set_OnError, arginfo_TElCustomSSHTunnel_set_OnError, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHTunnel, __construct, arginfo_TElCustomSSHTunnel___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCustomSSHTunnel(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCustomSSHTunnel_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCustomSSHTunnel", TElCustomSSHTunnel_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElCustomSSHTunnel_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElSSHTunnelConnection_ce_ptr = NULL;

SB_PHP_METHOD(TElSSHTunnelConnection, SendData)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHTunnelConnection_SendData(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, SendExtendedData)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHTunnelConnection_SendExtendedData(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, SendSignal)
{
	SBArrayZValInfo aiSignal;
	zval *zaSignal;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaSignal) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSignal) || SB_IS_ARRAY_TYPE_RP(zaSignal) || SB_IS_NULL_TYPE_RP(zaSignal)))
	{
		if (!SBGetByteArrayFromZVal(zaSignal, &aiSignal TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHTunnelConnection_SendSignal(SBGetObjectHandle(getThis() TSRMLS_CC), aiSignal.data, aiSignal.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiSignal);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, SendText)
{
	char *sS;
	sb_str_size sS_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		SBCheckError(TElSSHTunnelConnection_SendText(SBGetObjectHandle(getThis() TSRMLS_CC), sS, (int32_t)sS_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, SendExtendedText)
{
	char *sS;
	sb_str_size sS_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		SBCheckError(TElSSHTunnelConnection_SendExtendedText(SBGetObjectHandle(getThis() TSRMLS_CC), sS, (int32_t)sS_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, Close)
{
	char *sExitMessage;
	char *sExitSignal;
	sb_str_size sExitMessage_len;
	sb_str_size sExitSignal_len;
	sb_zend_long l4ExitStatus;
	zend_bool bFlushCachedData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bFlushCachedData) == SUCCESS)
	{
		SBCheckError(TElSSHTunnelConnection_Close(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bFlushCachedData) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &l4ExitStatus, &bFlushCachedData) == SUCCESS)
	{
		SBCheckError(TElSSHTunnelConnection_Close_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4ExitStatus, (int8_t)bFlushCachedData) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssb", &sExitSignal, &sExitSignal_len, &sExitMessage, &sExitMessage_len, &bFlushCachedData) == SUCCESS)
	{
		SBCheckError(TElSSHTunnelConnection_Close_2(SBGetObjectHandle(getThis() TSRMLS_CC), sExitSignal, (int32_t)sExitSignal_len, sExitMessage, (int32_t)sExitMessage_len, (int8_t)bFlushCachedData) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool) or (integer, bool) or (string, string, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, CloseLocal)
{
	zend_bool bFlushCachedData;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bFlushCachedData) == SUCCESS)
	{
		SBCheckError(TElSSHTunnelConnection_CloseLocal(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bFlushCachedData) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, CanSend)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHTunnelConnection_CanSend(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_Tunnel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHTunnelConnection_get_Tunnel(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomSSHTunnel_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, set_Tunnel)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomSSHTunnel_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSHTunnelConnection_set_Tunnel(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSHTunnel)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_Data)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		void * poOutResult = NULL;
		SBCheckError(TElSSHTunnelConnection_get_Data(SBGetObjectHandle(getThis() TSRMLS_CC), &poOutResult) TSRMLS_CC);
		object_init_ex(return_value, TSBPointer_ce_ptr);
		SBSetPointer(return_value, poOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, set_Data)
{
	SBArrayZValInfo piValue;
	zval *zpValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zpValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpValue) || SB_IS_ARRAY_TYPE_RP(zpValue) || SB_IS_NULL_TYPE_RP(zpValue) || (SB_IS_OBJECT_TYPE_RP(zpValue) && (Z_OBJCE_P(zpValue) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpValue, &piValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHTunnelConnection_set_Data(SBGetObjectHandle(getThis() TSRMLS_CC), piValue.data) TSRMLS_CC);
		SBFreePointerZValInfo(&piValue);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_UseUTF8)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHTunnelConnection_get_UseUTF8(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, set_UseUTF8)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHTunnelConnection_set_UseUTF8(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_HasUnsentData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHTunnelConnection_get_HasUnsentData(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_EOFSent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHTunnelConnection_get_EOFSent(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_ExitStatus)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHTunnelConnection_get_ExitStatus(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_ExitSignal)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSSHTunnelConnection_get_ExitSignal(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-232206233, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_ExitMessage)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSSHTunnelConnection_get_ExitMessage(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2050492895, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_ReturnExitStatus)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHTunnelConnection_get_ReturnExitStatus(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, set_ReturnExitStatus)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHTunnelConnection_set_ReturnExitStatus(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_ReturnExitSignal)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHTunnelConnection_get_ReturnExitSignal(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, set_ReturnExitSignal)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHTunnelConnection_set_ReturnExitSignal(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_OnData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHDataEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHTunnelConnection_get_OnData(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, set_OnData)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHTunnelConnection_set_OnData(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHDataEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHDataEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_OnExtendedData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHDataEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHTunnelConnection_get_OnExtendedData(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, set_OnExtendedData)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHTunnelConnection_set_OnExtendedData(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHDataEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHDataEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_OnError)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHErrorEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHTunnelConnection_get_OnError(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, set_OnError)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHTunnelConnection_set_OnError(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHErrorEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHErrorEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_OnClose)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHChannelCloseEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHTunnelConnection_get_OnClose(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, set_OnClose)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHTunnelConnection_set_OnClose(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHChannelCloseEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHChannelCloseEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_OnWindowChanged)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHWindowChangedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHTunnelConnection_get_OnWindowChanged(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, set_OnWindowChanged)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHTunnelConnection_set_OnWindowChanged(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHWindowChangedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHWindowChangedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, get_OnEOF)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHEOFEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHTunnelConnection_get_OnEOF(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, set_OnEOF)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHTunnelConnection_set_OnEOF(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHEOFEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHEOFEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHTunnelConnection, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHTunnelConnection_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_SendData, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_SendExtendedData, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_SendSignal, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Signal, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_SendText, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_SendExtendedText, 0, 0, 1)
	ZEND_ARG_INFO(0, S)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_Close, 0, 0, 1)
	ZEND_ARG_INFO(0, FlushCachedData_or_ExitStatus_or_ExitSignal)
	ZEND_ARG_INFO(0, FlushCachedData_or_ExitMessage)
	ZEND_ARG_INFO(0, FlushCachedData)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_CloseLocal, 0, 0, 1)
	ZEND_ARG_INFO(0, FlushCachedData)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_CanSend, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_Tunnel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_set_Tunnel, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomSSHTunnel, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_Data, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_set_Data, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_UseUTF8, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_set_UseUTF8, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_HasUnsentData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_EOFSent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_ExitStatus, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_ExitSignal, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_ExitMessage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_ReturnExitStatus, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_set_ReturnExitStatus, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_ReturnExitSignal, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_set_ReturnExitSignal, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_OnData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_set_OnData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_OnExtendedData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_set_OnExtendedData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_OnError, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_set_OnError, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_OnClose, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_set_OnClose, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_OnWindowChanged, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_set_OnWindowChanged, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_get_OnEOF, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection_set_OnEOF, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHTunnelConnection___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSHTunnelConnection_methods[] = {
	PHP_ME(TElSSHTunnelConnection, SendData, arginfo_TElSSHTunnelConnection_SendData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, SendExtendedData, arginfo_TElSSHTunnelConnection_SendExtendedData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, SendSignal, arginfo_TElSSHTunnelConnection_SendSignal, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, SendText, arginfo_TElSSHTunnelConnection_SendText, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, SendExtendedText, arginfo_TElSSHTunnelConnection_SendExtendedText, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, Close, arginfo_TElSSHTunnelConnection_Close, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, CloseLocal, arginfo_TElSSHTunnelConnection_CloseLocal, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, CanSend, arginfo_TElSSHTunnelConnection_CanSend, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_Tunnel, arginfo_TElSSHTunnelConnection_get_Tunnel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, set_Tunnel, arginfo_TElSSHTunnelConnection_set_Tunnel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_Data, arginfo_TElSSHTunnelConnection_get_Data, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, set_Data, arginfo_TElSSHTunnelConnection_set_Data, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_UseUTF8, arginfo_TElSSHTunnelConnection_get_UseUTF8, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, set_UseUTF8, arginfo_TElSSHTunnelConnection_set_UseUTF8, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_HasUnsentData, arginfo_TElSSHTunnelConnection_get_HasUnsentData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_EOFSent, arginfo_TElSSHTunnelConnection_get_EOFSent, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_ExitStatus, arginfo_TElSSHTunnelConnection_get_ExitStatus, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_ExitSignal, arginfo_TElSSHTunnelConnection_get_ExitSignal, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_ExitMessage, arginfo_TElSSHTunnelConnection_get_ExitMessage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_ReturnExitStatus, arginfo_TElSSHTunnelConnection_get_ReturnExitStatus, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, set_ReturnExitStatus, arginfo_TElSSHTunnelConnection_set_ReturnExitStatus, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_ReturnExitSignal, arginfo_TElSSHTunnelConnection_get_ReturnExitSignal, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, set_ReturnExitSignal, arginfo_TElSSHTunnelConnection_set_ReturnExitSignal, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_OnData, arginfo_TElSSHTunnelConnection_get_OnData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, set_OnData, arginfo_TElSSHTunnelConnection_set_OnData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_OnExtendedData, arginfo_TElSSHTunnelConnection_get_OnExtendedData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, set_OnExtendedData, arginfo_TElSSHTunnelConnection_set_OnExtendedData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_OnError, arginfo_TElSSHTunnelConnection_get_OnError, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, set_OnError, arginfo_TElSSHTunnelConnection_set_OnError, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_OnClose, arginfo_TElSSHTunnelConnection_get_OnClose, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, set_OnClose, arginfo_TElSSHTunnelConnection_set_OnClose, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_OnWindowChanged, arginfo_TElSSHTunnelConnection_get_OnWindowChanged, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, set_OnWindowChanged, arginfo_TElSSHTunnelConnection_set_OnWindowChanged, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, get_OnEOF, arginfo_TElSSHTunnelConnection_get_OnEOF, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, set_OnEOF, arginfo_TElSSHTunnelConnection_set_OnEOF, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHTunnelConnection, __construct, arginfo_TElSSHTunnelConnection___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSHTunnelConnection(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSHTunnelConnection_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSHTunnelConnection", TElSSHTunnelConnection_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSSHTunnelConnection_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElCustomSSHTunnelParams_ce_ptr = NULL;

SB_PHP_METHOD(TElCustomSSHTunnelParams, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSHTunnelParams_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHTunnelParams___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElCustomSSHTunnelParams_methods[] = {
	PHP_ME(TElCustomSSHTunnelParams, __construct, arginfo_TElCustomSSHTunnelParams___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCustomSSHTunnelParams(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCustomSSHTunnelParams_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCustomSSHTunnelParams", TElCustomSSHTunnelParams_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElCustomSSHTunnelParams_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElShellSSHTunnel_ce_ptr = NULL;

SB_PHP_METHOD(TElShellSSHTunnel, get_TerminalInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElShellSSHTunnel_get_TerminalInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElTerminalInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHTunnel, set_TerminalInfo)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElTerminalInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElShellSSHTunnel_set_TerminalInfo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElTerminalInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHTunnel, get_Environment)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElShellSSHTunnel_get_Environment(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHTunnel, get_RequestTerminal)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElShellSSHTunnel_get_RequestTerminal(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHTunnel, set_RequestTerminal)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElShellSSHTunnel_set_RequestTerminal(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHTunnel, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElShellSSHTunnel_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHTunnel_get_TerminalInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHTunnel_set_TerminalInfo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElTerminalInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHTunnel_get_Environment, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHTunnel_get_RequestTerminal, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHTunnel_set_RequestTerminal, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHTunnel___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElShellSSHTunnel_methods[] = {
	PHP_ME(TElShellSSHTunnel, get_TerminalInfo, arginfo_TElShellSSHTunnel_get_TerminalInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHTunnel, set_TerminalInfo, arginfo_TElShellSSHTunnel_set_TerminalInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHTunnel, get_Environment, arginfo_TElShellSSHTunnel_get_Environment, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHTunnel, get_RequestTerminal, arginfo_TElShellSSHTunnel_get_RequestTerminal, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHTunnel, set_RequestTerminal, arginfo_TElShellSSHTunnel_set_RequestTerminal, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHTunnel, __construct, arginfo_TElShellSSHTunnel___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElShellSSHTunnel(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElShellSSHTunnel_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElShellSSHTunnel", TElShellSSHTunnel_methods);
	if (NULL == TElCustomSSHTunnel_ce_ptr)
		Register_TElCustomSSHTunnel(TSRMLS_C);
	TElShellSSHTunnel_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSHTunnel_ce_ptr);
}

zend_class_entry *TElCommandSSHTunnel_ce_ptr = NULL;

SB_PHP_METHOD(TElCommandSSHTunnel, get_Command)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElCommandSSHTunnel_get_Command(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(494640216, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSHTunnel, set_Command)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElCommandSSHTunnel_set_Command(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSHTunnel, get_Commands)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCommandSSHTunnel_get_Commands(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSHTunnel, get_ActiveCommand)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCommandSSHTunnel_get_ActiveCommand(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSHTunnel, set_ActiveCommand)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElCommandSSHTunnel_set_ActiveCommand(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSHTunnel, get_Environment)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCommandSSHTunnel_get_Environment(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSHTunnel, get_TerminalInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCommandSSHTunnel_get_TerminalInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElTerminalInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSHTunnel, set_TerminalInfo)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElTerminalInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCommandSSHTunnel_set_TerminalInfo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElTerminalInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSHTunnel, get_RequestTerminal)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCommandSSHTunnel_get_RequestTerminal(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSHTunnel, set_RequestTerminal)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCommandSSHTunnel_set_RequestTerminal(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCommandSSHTunnel, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCommandSSHTunnel_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSHTunnel_get_Command, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSHTunnel_set_Command, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSHTunnel_get_Commands, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSHTunnel_get_ActiveCommand, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSHTunnel_set_ActiveCommand, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSHTunnel_get_Environment, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSHTunnel_get_TerminalInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSHTunnel_set_TerminalInfo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElTerminalInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSHTunnel_get_RequestTerminal, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSHTunnel_set_RequestTerminal, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCommandSSHTunnel___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCommandSSHTunnel_methods[] = {
	PHP_ME(TElCommandSSHTunnel, get_Command, arginfo_TElCommandSSHTunnel_get_Command, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSHTunnel, set_Command, arginfo_TElCommandSSHTunnel_set_Command, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSHTunnel, get_Commands, arginfo_TElCommandSSHTunnel_get_Commands, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSHTunnel, get_ActiveCommand, arginfo_TElCommandSSHTunnel_get_ActiveCommand, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSHTunnel, set_ActiveCommand, arginfo_TElCommandSSHTunnel_set_ActiveCommand, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSHTunnel, get_Environment, arginfo_TElCommandSSHTunnel_get_Environment, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSHTunnel, get_TerminalInfo, arginfo_TElCommandSSHTunnel_get_TerminalInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSHTunnel, set_TerminalInfo, arginfo_TElCommandSSHTunnel_set_TerminalInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSHTunnel, get_RequestTerminal, arginfo_TElCommandSSHTunnel_get_RequestTerminal, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSHTunnel, set_RequestTerminal, arginfo_TElCommandSSHTunnel_set_RequestTerminal, ZEND_ACC_PUBLIC)
	PHP_ME(TElCommandSSHTunnel, __construct, arginfo_TElCommandSSHTunnel___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCommandSSHTunnel(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCommandSSHTunnel_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCommandSSHTunnel", TElCommandSSHTunnel_methods);
	if (NULL == TElCustomSSHTunnel_ce_ptr)
		Register_TElCustomSSHTunnel(TSRMLS_C);
	TElCommandSSHTunnel_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSHTunnel_ce_ptr);
}

zend_class_entry *TElSubsystemSSHTunnel_ce_ptr = NULL;

SB_PHP_METHOD(TElSubsystemSSHTunnel, get_Subsystem)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSubsystemSSHTunnel_get_Subsystem(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2011083617, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSubsystemSSHTunnel, set_Subsystem)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSubsystemSSHTunnel_set_Subsystem(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSubsystemSSHTunnel, get_Environment)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSubsystemSSHTunnel_get_Environment(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSubsystemSSHTunnel, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSubsystemSSHTunnel_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSubsystemSSHTunnel_get_Subsystem, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSubsystemSSHTunnel_set_Subsystem, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSubsystemSSHTunnel_get_Environment, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSubsystemSSHTunnel___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSubsystemSSHTunnel_methods[] = {
	PHP_ME(TElSubsystemSSHTunnel, get_Subsystem, arginfo_TElSubsystemSSHTunnel_get_Subsystem, ZEND_ACC_PUBLIC)
	PHP_ME(TElSubsystemSSHTunnel, set_Subsystem, arginfo_TElSubsystemSSHTunnel_set_Subsystem, ZEND_ACC_PUBLIC)
	PHP_ME(TElSubsystemSSHTunnel, get_Environment, arginfo_TElSubsystemSSHTunnel_get_Environment, ZEND_ACC_PUBLIC)
	PHP_ME(TElSubsystemSSHTunnel, __construct, arginfo_TElSubsystemSSHTunnel___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSubsystemSSHTunnel(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSubsystemSSHTunnel_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSubsystemSSHTunnel", TElSubsystemSSHTunnel_methods);
	if (NULL == TElCustomSSHTunnel_ce_ptr)
		Register_TElCustomSSHTunnel(TSRMLS_C);
	TElSubsystemSSHTunnel_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSHTunnel_ce_ptr);
}

zend_class_entry *TElRemotePortForwardSSHTunnel_ce_ptr = NULL;

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, DoSetupSucceeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElRemotePortForwardSSHTunnel_DoSetupSucceeded(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, DoSetupFailed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElRemotePortForwardSSHTunnel_DoSetupFailed(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, GetToHost)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElRemotePortForwardSSHTunnel_GetToHost(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(87236945, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, SetToHost)
{
	char *sAValue;
	sb_str_size sAValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAValue, &sAValue_len) == SUCCESS)
	{
		SBCheckError(TElRemotePortForwardSSHTunnel_SetToHost(SBGetObjectHandle(getThis() TSRMLS_CC), sAValue, (int32_t)sAValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, Close)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElRemotePortForwardSSHTunnel_Close(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, get_Host)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElRemotePortForwardSSHTunnel_get_Host(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(47362800, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, set_Host)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElRemotePortForwardSSHTunnel_set_Host(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, get_Port)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElRemotePortForwardSSHTunnel_get_Port(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, set_Port)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElRemotePortForwardSSHTunnel_set_Port(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, get_ToHost)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElRemotePortForwardSSHTunnel_get_ToHost(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(568614670, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, set_ToHost)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElRemotePortForwardSSHTunnel_set_ToHost(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, get_ToPort)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElRemotePortForwardSSHTunnel_get_ToPort(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, set_ToPort)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElRemotePortForwardSSHTunnel_set_ToPort(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, get_BoundPort)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElRemotePortForwardSSHTunnel_get_BoundPort(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, set_BoundPort)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElRemotePortForwardSSHTunnel_set_BoundPort(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, get_UseDefaultBindAddress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElRemotePortForwardSSHTunnel_get_UseDefaultBindAddress(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, set_UseDefaultBindAddress)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElRemotePortForwardSSHTunnel_set_UseDefaultBindAddress(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, get_OnSetupSucceeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElRemotePortForwardSSHTunnel_get_OnSetupSucceeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, set_OnSetupSucceeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElRemotePortForwardSSHTunnel_set_OnSetupSucceeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, get_OnSetupFailed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElRemotePortForwardSSHTunnel_get_OnSetupFailed(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, set_OnSetupFailed)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElRemotePortForwardSSHTunnel_set_OnSetupFailed(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRemotePortForwardSSHTunnel, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElRemotePortForwardSSHTunnel_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_DoSetupSucceeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_DoSetupFailed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_GetToHost, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_SetToHost, 0, 0, 1)
	ZEND_ARG_INFO(0, AValue)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_Close, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_get_Host, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_set_Host, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_get_Port, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_set_Port, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_get_ToHost, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_set_ToHost, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_get_ToPort, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_set_ToPort, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_get_BoundPort, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_set_BoundPort, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_get_UseDefaultBindAddress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_set_UseDefaultBindAddress, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_get_OnSetupSucceeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_set_OnSetupSucceeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_get_OnSetupFailed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel_set_OnSetupFailed, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRemotePortForwardSSHTunnel___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElRemotePortForwardSSHTunnel_methods[] = {
	PHP_ME(TElRemotePortForwardSSHTunnel, DoSetupSucceeded, arginfo_TElRemotePortForwardSSHTunnel_DoSetupSucceeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, DoSetupFailed, arginfo_TElRemotePortForwardSSHTunnel_DoSetupFailed, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, GetToHost, arginfo_TElRemotePortForwardSSHTunnel_GetToHost, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, SetToHost, arginfo_TElRemotePortForwardSSHTunnel_SetToHost, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, Close, arginfo_TElRemotePortForwardSSHTunnel_Close, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, get_Host, arginfo_TElRemotePortForwardSSHTunnel_get_Host, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, set_Host, arginfo_TElRemotePortForwardSSHTunnel_set_Host, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, get_Port, arginfo_TElRemotePortForwardSSHTunnel_get_Port, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, set_Port, arginfo_TElRemotePortForwardSSHTunnel_set_Port, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, get_ToHost, arginfo_TElRemotePortForwardSSHTunnel_get_ToHost, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, set_ToHost, arginfo_TElRemotePortForwardSSHTunnel_set_ToHost, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, get_ToPort, arginfo_TElRemotePortForwardSSHTunnel_get_ToPort, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, set_ToPort, arginfo_TElRemotePortForwardSSHTunnel_set_ToPort, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, get_BoundPort, arginfo_TElRemotePortForwardSSHTunnel_get_BoundPort, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, set_BoundPort, arginfo_TElRemotePortForwardSSHTunnel_set_BoundPort, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, get_UseDefaultBindAddress, arginfo_TElRemotePortForwardSSHTunnel_get_UseDefaultBindAddress, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, set_UseDefaultBindAddress, arginfo_TElRemotePortForwardSSHTunnel_set_UseDefaultBindAddress, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, get_OnSetupSucceeded, arginfo_TElRemotePortForwardSSHTunnel_get_OnSetupSucceeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, set_OnSetupSucceeded, arginfo_TElRemotePortForwardSSHTunnel_set_OnSetupSucceeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, get_OnSetupFailed, arginfo_TElRemotePortForwardSSHTunnel_get_OnSetupFailed, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, set_OnSetupFailed, arginfo_TElRemotePortForwardSSHTunnel_set_OnSetupFailed, ZEND_ACC_PUBLIC)
	PHP_ME(TElRemotePortForwardSSHTunnel, __construct, arginfo_TElRemotePortForwardSSHTunnel___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElRemotePortForwardSSHTunnel(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElRemotePortForwardSSHTunnel_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElRemotePortForwardSSHTunnel", TElRemotePortForwardSSHTunnel_methods);
	if (NULL == TElCustomSSHTunnel_ce_ptr)
		Register_TElCustomSSHTunnel(TSRMLS_C);
	TElRemotePortForwardSSHTunnel_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSHTunnel_ce_ptr);
}

zend_class_entry *TElLocalPortForwardSSHTunnel_ce_ptr = NULL;

SB_PHP_METHOD(TElLocalPortForwardSSHTunnel, GetToHost)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElLocalPortForwardSSHTunnel_GetToHost(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(741246062, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElLocalPortForwardSSHTunnel, SetToHost)
{
	char *sAValue;
	sb_str_size sAValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAValue, &sAValue_len) == SUCCESS)
	{
		SBCheckError(TElLocalPortForwardSSHTunnel_SetToHost(SBGetObjectHandle(getThis() TSRMLS_CC), sAValue, (int32_t)sAValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElLocalPortForwardSSHTunnel, Open)
{
	char *sOrigHost;
	sb_str_size sOrigHost_len;
	sb_zend_long l4OrigPort;
	SBArrayZValInfo piData;
	zval *zpData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zsl", &zpData, &sOrigHost, &sOrigHost_len, &l4OrigPort) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpData) || SB_IS_ARRAY_TYPE_RP(zpData) || SB_IS_NULL_TYPE_RP(zpData) || (SB_IS_OBJECT_TYPE_RP(zpData) && (Z_OBJCE_P(zpData) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpData, &piData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElLocalPortForwardSSHTunnel_Open(SBGetObjectHandle(getThis() TSRMLS_CC), piData.data, sOrigHost, (int32_t)sOrigHost_len, (int32_t)l4OrigPort) TSRMLS_CC);
		SBFreePointerZValInfo(&piData);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zpData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpData) || SB_IS_ARRAY_TYPE_RP(zpData) || SB_IS_NULL_TYPE_RP(zpData) || (SB_IS_OBJECT_TYPE_RP(zpData) && (Z_OBJCE_P(zpData) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpData, &piData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElLocalPortForwardSSHTunnel_Open_1(SBGetObjectHandle(getThis() TSRMLS_CC), piData.data) TSRMLS_CC);
		SBFreePointerZValInfo(&piData);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, string, integer) or (\\TSBPointer|array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElLocalPortForwardSSHTunnel, get_Port)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElLocalPortForwardSSHTunnel_get_Port(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElLocalPortForwardSSHTunnel, set_Port)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElLocalPortForwardSSHTunnel_set_Port(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElLocalPortForwardSSHTunnel, get_Host)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElLocalPortForwardSSHTunnel_get_Host(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-871504342, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElLocalPortForwardSSHTunnel, set_Host)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElLocalPortForwardSSHTunnel_set_Host(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElLocalPortForwardSSHTunnel, get_ToHost)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElLocalPortForwardSSHTunnel_get_ToHost(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(909453737, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElLocalPortForwardSSHTunnel, set_ToHost)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElLocalPortForwardSSHTunnel_set_ToHost(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElLocalPortForwardSSHTunnel, get_ToPort)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElLocalPortForwardSSHTunnel_get_ToPort(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElLocalPortForwardSSHTunnel, set_ToPort)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElLocalPortForwardSSHTunnel_set_ToPort(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElLocalPortForwardSSHTunnel, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElLocalPortForwardSSHTunnel_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnel_GetToHost, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnel_SetToHost, 0, 0, 1)
	ZEND_ARG_INFO(0, AValue)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnel_Open, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, OrigHost)
	ZEND_ARG_INFO(0, OrigPort)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnel_get_Port, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnel_set_Port, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnel_get_Host, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnel_set_Host, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnel_get_ToHost, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnel_set_ToHost, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnel_get_ToPort, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnel_set_ToPort, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnel___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElLocalPortForwardSSHTunnel_methods[] = {
	PHP_ME(TElLocalPortForwardSSHTunnel, GetToHost, arginfo_TElLocalPortForwardSSHTunnel_GetToHost, ZEND_ACC_PUBLIC)
	PHP_ME(TElLocalPortForwardSSHTunnel, SetToHost, arginfo_TElLocalPortForwardSSHTunnel_SetToHost, ZEND_ACC_PUBLIC)
	PHP_ME(TElLocalPortForwardSSHTunnel, Open, arginfo_TElLocalPortForwardSSHTunnel_Open, ZEND_ACC_PUBLIC)
	PHP_ME(TElLocalPortForwardSSHTunnel, get_Port, arginfo_TElLocalPortForwardSSHTunnel_get_Port, ZEND_ACC_PUBLIC)
	PHP_ME(TElLocalPortForwardSSHTunnel, set_Port, arginfo_TElLocalPortForwardSSHTunnel_set_Port, ZEND_ACC_PUBLIC)
	PHP_ME(TElLocalPortForwardSSHTunnel, get_Host, arginfo_TElLocalPortForwardSSHTunnel_get_Host, ZEND_ACC_PUBLIC)
	PHP_ME(TElLocalPortForwardSSHTunnel, set_Host, arginfo_TElLocalPortForwardSSHTunnel_set_Host, ZEND_ACC_PUBLIC)
	PHP_ME(TElLocalPortForwardSSHTunnel, get_ToHost, arginfo_TElLocalPortForwardSSHTunnel_get_ToHost, ZEND_ACC_PUBLIC)
	PHP_ME(TElLocalPortForwardSSHTunnel, set_ToHost, arginfo_TElLocalPortForwardSSHTunnel_set_ToHost, ZEND_ACC_PUBLIC)
	PHP_ME(TElLocalPortForwardSSHTunnel, get_ToPort, arginfo_TElLocalPortForwardSSHTunnel_get_ToPort, ZEND_ACC_PUBLIC)
	PHP_ME(TElLocalPortForwardSSHTunnel, set_ToPort, arginfo_TElLocalPortForwardSSHTunnel_set_ToPort, ZEND_ACC_PUBLIC)
	PHP_ME(TElLocalPortForwardSSHTunnel, __construct, arginfo_TElLocalPortForwardSSHTunnel___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElLocalPortForwardSSHTunnel(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElLocalPortForwardSSHTunnel_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElLocalPortForwardSSHTunnel", TElLocalPortForwardSSHTunnel_methods);
	if (NULL == TElCustomSSHTunnel_ce_ptr)
		Register_TElCustomSSHTunnel(TSRMLS_C);
	TElLocalPortForwardSSHTunnel_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSHTunnel_ce_ptr);
}

zend_class_entry *TElLocalPortForwardSSHTunnelParams_ce_ptr = NULL;

SB_PHP_METHOD(TElLocalPortForwardSSHTunnelParams, get_OrigHost)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElLocalPortForwardSSHTunnelParams_get_OrigHost(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-611303324, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElLocalPortForwardSSHTunnelParams, get_OrigPort)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElLocalPortForwardSSHTunnelParams_get_OrigPort(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElLocalPortForwardSSHTunnelParams, __construct)
{
	char *sOrigHost;
	sb_str_size sOrigHost_len;
	sb_zend_long l4OrigPort;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &sOrigHost, &sOrigHost_len, &l4OrigPort) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElLocalPortForwardSSHTunnelParams_Create(sOrigHost, (int32_t)sOrigHost_len, (int32_t)l4OrigPort, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnelParams_get_OrigHost, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnelParams_get_OrigPort, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElLocalPortForwardSSHTunnelParams___construct, 0, 0, 2)
	ZEND_ARG_INFO(0, OrigHost)
	ZEND_ARG_INFO(0, OrigPort)
ZEND_END_ARG_INFO()

static zend_function_entry TElLocalPortForwardSSHTunnelParams_methods[] = {
	PHP_ME(TElLocalPortForwardSSHTunnelParams, get_OrigHost, arginfo_TElLocalPortForwardSSHTunnelParams_get_OrigHost, ZEND_ACC_PUBLIC)
	PHP_ME(TElLocalPortForwardSSHTunnelParams, get_OrigPort, arginfo_TElLocalPortForwardSSHTunnelParams_get_OrigPort, ZEND_ACC_PUBLIC)
	PHP_ME(TElLocalPortForwardSSHTunnelParams, __construct, arginfo_TElLocalPortForwardSSHTunnelParams___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElLocalPortForwardSSHTunnelParams(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElLocalPortForwardSSHTunnelParams_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElLocalPortForwardSSHTunnelParams", TElLocalPortForwardSSHTunnelParams_methods);
	if (NULL == TElCustomSSHTunnelParams_ce_ptr)
		Register_TElCustomSSHTunnelParams(TSRMLS_C);
	TElLocalPortForwardSSHTunnelParams_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSHTunnelParams_ce_ptr);
}

zend_class_entry *TElX11ForwardSSHTunnel_ce_ptr = NULL;

SB_PHP_METHOD(TElX11ForwardSSHTunnel, get_AuthenticationProtocol)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElX11ForwardSSHTunnel_get_AuthenticationProtocol(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1593463661, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElX11ForwardSSHTunnel, set_AuthenticationProtocol)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElX11ForwardSSHTunnel_set_AuthenticationProtocol(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElX11ForwardSSHTunnel, get_Cookie)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElX11ForwardSSHTunnel_get_Cookie(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1381889382, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElX11ForwardSSHTunnel, set_Cookie)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElX11ForwardSSHTunnel_set_Cookie(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElX11ForwardSSHTunnel, get_ScreenNumber)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElX11ForwardSSHTunnel_get_ScreenNumber(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElX11ForwardSSHTunnel, set_ScreenNumber)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElX11ForwardSSHTunnel_set_ScreenNumber(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElX11ForwardSSHTunnel, get_TerminalInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElX11ForwardSSHTunnel_get_TerminalInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElTerminalInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElX11ForwardSSHTunnel, set_TerminalInfo)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElTerminalInfo_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElX11ForwardSSHTunnel_set_TerminalInfo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElTerminalInfo)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElX11ForwardSSHTunnel, get_Environment)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElX11ForwardSSHTunnel_get_Environment(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElX11ForwardSSHTunnel, get_RequestTerminal)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElX11ForwardSSHTunnel_get_RequestTerminal(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElX11ForwardSSHTunnel, set_RequestTerminal)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElX11ForwardSSHTunnel_set_RequestTerminal(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElX11ForwardSSHTunnel, get_Target)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElX11ForwardSSHTunnel_get_Target(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomSSHTunnel_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElX11ForwardSSHTunnel, set_Target)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomSSHTunnel_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElX11ForwardSSHTunnel_set_Target(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSHTunnel)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElX11ForwardSSHTunnel, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElX11ForwardSSHTunnel_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElX11ForwardSSHTunnel_get_AuthenticationProtocol, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElX11ForwardSSHTunnel_set_AuthenticationProtocol, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElX11ForwardSSHTunnel_get_Cookie, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElX11ForwardSSHTunnel_set_Cookie, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElX11ForwardSSHTunnel_get_ScreenNumber, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElX11ForwardSSHTunnel_set_ScreenNumber, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElX11ForwardSSHTunnel_get_TerminalInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElX11ForwardSSHTunnel_set_TerminalInfo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElTerminalInfo, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElX11ForwardSSHTunnel_get_Environment, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElX11ForwardSSHTunnel_get_RequestTerminal, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElX11ForwardSSHTunnel_set_RequestTerminal, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElX11ForwardSSHTunnel_get_Target, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElX11ForwardSSHTunnel_set_Target, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomSSHTunnel, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElX11ForwardSSHTunnel___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElX11ForwardSSHTunnel_methods[] = {
	PHP_ME(TElX11ForwardSSHTunnel, get_AuthenticationProtocol, arginfo_TElX11ForwardSSHTunnel_get_AuthenticationProtocol, ZEND_ACC_PUBLIC)
	PHP_ME(TElX11ForwardSSHTunnel, set_AuthenticationProtocol, arginfo_TElX11ForwardSSHTunnel_set_AuthenticationProtocol, ZEND_ACC_PUBLIC)
	PHP_ME(TElX11ForwardSSHTunnel, get_Cookie, arginfo_TElX11ForwardSSHTunnel_get_Cookie, ZEND_ACC_PUBLIC)
	PHP_ME(TElX11ForwardSSHTunnel, set_Cookie, arginfo_TElX11ForwardSSHTunnel_set_Cookie, ZEND_ACC_PUBLIC)
	PHP_ME(TElX11ForwardSSHTunnel, get_ScreenNumber, arginfo_TElX11ForwardSSHTunnel_get_ScreenNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElX11ForwardSSHTunnel, set_ScreenNumber, arginfo_TElX11ForwardSSHTunnel_set_ScreenNumber, ZEND_ACC_PUBLIC)
	PHP_ME(TElX11ForwardSSHTunnel, get_TerminalInfo, arginfo_TElX11ForwardSSHTunnel_get_TerminalInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElX11ForwardSSHTunnel, set_TerminalInfo, arginfo_TElX11ForwardSSHTunnel_set_TerminalInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElX11ForwardSSHTunnel, get_Environment, arginfo_TElX11ForwardSSHTunnel_get_Environment, ZEND_ACC_PUBLIC)
	PHP_ME(TElX11ForwardSSHTunnel, get_RequestTerminal, arginfo_TElX11ForwardSSHTunnel_get_RequestTerminal, ZEND_ACC_PUBLIC)
	PHP_ME(TElX11ForwardSSHTunnel, set_RequestTerminal, arginfo_TElX11ForwardSSHTunnel_set_RequestTerminal, ZEND_ACC_PUBLIC)
	PHP_ME(TElX11ForwardSSHTunnel, get_Target, arginfo_TElX11ForwardSSHTunnel_get_Target, ZEND_ACC_PUBLIC)
	PHP_ME(TElX11ForwardSSHTunnel, set_Target, arginfo_TElX11ForwardSSHTunnel_set_Target, ZEND_ACC_PUBLIC)
	PHP_ME(TElX11ForwardSSHTunnel, __construct, arginfo_TElX11ForwardSSHTunnel___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElX11ForwardSSHTunnel(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElX11ForwardSSHTunnel_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElX11ForwardSSHTunnel", TElX11ForwardSSHTunnel_methods);
	if (NULL == TElCustomSSHTunnel_ce_ptr)
		Register_TElCustomSSHTunnel(TSRMLS_C);
	TElX11ForwardSSHTunnel_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSHTunnel_ce_ptr);
}

zend_class_entry *TElAuthenticationAgentSSHTunnel_ce_ptr = NULL;

SB_PHP_METHOD(TElAuthenticationAgentSSHTunnel, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElAuthenticationAgentSSHTunnel_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElAuthenticationAgentSSHTunnel___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElAuthenticationAgentSSHTunnel_methods[] = {
	PHP_ME(TElAuthenticationAgentSSHTunnel, __construct, arginfo_TElAuthenticationAgentSSHTunnel___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElAuthenticationAgentSSHTunnel(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElAuthenticationAgentSSHTunnel_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElAuthenticationAgentSSHTunnel", TElAuthenticationAgentSSHTunnel_methods);
	if (NULL == TElCustomSSHTunnel_ce_ptr)
		Register_TElCustomSSHTunnel(TSRMLS_C);
	TElAuthenticationAgentSSHTunnel_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSHTunnel_ce_ptr);
}

zend_class_entry *TElSSHAuthHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElSSHAuthHandler, GetAlgorithmFromClientKexDHReply)
{
	SBArrayZValInfo aiHostAlg;
	zval *zaHostAlg;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaHostAlg) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaHostAlg) || SB_IS_ARRAY_TYPE_RP(zaHostAlg) || SB_IS_NULL_TYPE_RP(zaHostAlg)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaHostAlg, &aiHostAlg TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHAuthHandler_GetAlgorithmFromClientKexDHReply(SBGetObjectHandle(getThis() TSRMLS_CC), aiHostAlg.data, aiHostAlg.len, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiHostAlg);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHAuthHandler, ValidateServerSignature)
{
	char *sErrMessage;
	int32_t l4ErrCodeRaw;
	int32_t sErrMessage_len;
	sb_zend_long l4Algorithm;
	sb_zend_long l4HashAlg;
	SBArrayZValInfo aiHash;
	SBArrayZValInfo aiPubKeyStr;
	SBArrayZValInfo aiSignature;
	uint32_t _err;
	zval *zaHash;
	zval *zaPubKeyStr;
	zval *zaSignature;
	zval *zl4ErrCode;
	zval *zsErrMessage;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzzzlzz", &l4Algorithm, &zaPubKeyStr, &zaSignature, &zaHash, &l4HashAlg, &zl4ErrCode, &zsErrMessage) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaPubKeyStr) || SB_IS_ARRAY_TYPE_RP(zaPubKeyStr) || SB_IS_NULL_TYPE_RP(zaPubKeyStr)) && (SB_IS_STRING_TYPE_RP(zaSignature) || SB_IS_ARRAY_TYPE_RP(zaSignature) || SB_IS_NULL_TYPE_RP(zaSignature)) && (SB_IS_STRING_TYPE_RP(zaHash) || SB_IS_ARRAY_TYPE_RP(zaHash) || SB_IS_NULL_TYPE_RP(zaHash)) && Z_ISREF_P(zl4ErrCode) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4ErrCode))) && Z_ISREF_P(zsErrMessage) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsErrMessage))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaPubKeyStr, &aiPubKeyStr TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaSignature, &aiSignature TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaHash, &aiHash TSRMLS_CC)) RETURN_FALSE;
		l4ErrCodeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4ErrCode));
		sErrMessage = Z_STRVAL_P(Z_REFVAL_P(zsErrMessage));
		sErrMessage_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsErrMessage));
		_err = TElSSHAuthHandler_ValidateServerSignature(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Algorithm, aiPubKeyStr.data, aiPubKeyStr.len, aiSignature.data, aiSignature.len, aiHash.data, aiHash.len, (int32_t)l4HashAlg, &l4ErrCodeRaw, sErrMessage, &sErrMessage_len, &bOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sErrMessage = emalloc(sErrMessage_len + 1);
			SBCheckError(SBGetLastReturnStringA(2114041456, 7, sErrMessage, &sErrMessage_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsErrMessage));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiPubKeyStr);
		SBFreeArrayZValInfo(&aiSignature);
		SBFreeArrayZValInfo(&aiHash);
		ZVAL_LONG(Z_REFVAL_P(zl4ErrCode), (sb_zend_long)l4ErrCodeRaw);
		sErrMessage[sErrMessage_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsErrMessage), sErrMessage, sErrMessage_len);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, array of byte|string|NULL, array of byte|string|NULL, array of byte|string|NULL, integer, &integer, &string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHAuthHandler, FindKeyByAlgorithm)
{
	sb_zend_long l4Algorithm;
	zval *oStorage;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStorage, TElSSHCustomKeyStorage_ce_ptr, &l4Algorithm) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHAuthHandler_FindKeyByAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStorage TSRMLS_CC), (int32_t)l4Algorithm, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHCustomKeyStorage, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHAuthHandler, GetKeyBlob)
{
	uint32_t _err;
	zval *oKey;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oKey, TElSSHKey_ce_ptr) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSSHAuthHandler_GetKeyBlob(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKey TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-925816539, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHKey)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHAuthHandler, KeyBlobToKey)
{
	char *sAlgName;
	sb_str_size sAlgName_len;
	SBArrayZValInfo aiBlob;
	zval *zaBlob;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sz", &sAlgName, &sAlgName_len, &zaBlob) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBlob) || SB_IS_ARRAY_TYPE_RP(zaBlob) || SB_IS_NULL_TYPE_RP(zaBlob)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaBlob, &aiBlob TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHAuthHandler_KeyBlobToKey(SBGetObjectHandle(getThis() TSRMLS_CC), sAlgName, (int32_t)sAlgName_len, aiBlob.data, aiBlob.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBlob);
		SBInitObject(return_value, TElSSHKey_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHAuthHandler, HashAlgFromKey)
{
	zval *oKey;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oKey, TElSSHKey_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHAuthHandler_HashAlgFromKey(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKey TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHKey)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHAuthHandler, CalculateServerSignature)
{
	SBArrayZValInfo aiaHash;
	uint32_t _err;
	zval *oKey;
	zval *zaaHash;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oKey, TElSSHKey_ce_ptr, &zaaHash) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaaHash) || SB_IS_ARRAY_TYPE_RP(zaaHash) || SB_IS_NULL_TYPE_RP(zaaHash)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaaHash, &aiaHash TSRMLS_CC)) RETURN_FALSE;
		_err = TElSSHAuthHandler_CalculateServerSignature(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKey TSRMLS_CC), aiaHash.data, aiaHash.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1969632151, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiaHash);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHKey, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHAuthHandler, ServerValidateClientSignature)
{
	int8_t bValidRaw;
	SBArrayZValInfo aiAlgName;
	SBArrayZValInfo aiHash;
	SBArrayZValInfo aiKeyBlob;
	SBArrayZValInfo aiSignature;
	zval *zaAlgName;
	zval *zaHash;
	zval *zaKeyBlob;
	zval *zaSignature;
	zval *zbValid;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzzzz", &zaAlgName, &zaKeyBlob, &zaSignature, &zaHash, &zbValid) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAlgName) || SB_IS_ARRAY_TYPE_RP(zaAlgName) || SB_IS_NULL_TYPE_RP(zaAlgName)) && (SB_IS_STRING_TYPE_RP(zaKeyBlob) || SB_IS_ARRAY_TYPE_RP(zaKeyBlob) || SB_IS_NULL_TYPE_RP(zaKeyBlob)) && (SB_IS_STRING_TYPE_RP(zaSignature) || SB_IS_ARRAY_TYPE_RP(zaSignature) || SB_IS_NULL_TYPE_RP(zaSignature)) && (SB_IS_STRING_TYPE_RP(zaHash) || SB_IS_ARRAY_TYPE_RP(zaHash) || SB_IS_NULL_TYPE_RP(zaHash)) && Z_ISREF_P(zbValid) && SB_IS_BOOL_TYPE_P(Z_REFVAL_P(zbValid)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaAlgName, &aiAlgName TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaKeyBlob, &aiKeyBlob TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaSignature, &aiSignature TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaHash, &aiHash TSRMLS_CC)) RETURN_FALSE;
		bValidRaw = (int8_t)SB_BVAL_P(Z_REFVAL_P(zbValid));
		SBCheckError(TElSSHAuthHandler_ServerValidateClientSignature(SBGetObjectHandle(getThis() TSRMLS_CC), aiAlgName.data, aiAlgName.len, aiKeyBlob.data, aiKeyBlob.len, aiSignature.data, aiSignature.len, aiHash.data, aiHash.len, &bValidRaw, &bOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAlgName);
		SBFreeArrayZValInfo(&aiKeyBlob);
		SBFreeArrayZValInfo(&aiSignature);
		SBFreeArrayZValInfo(&aiHash);
		ZVAL_BOOL(Z_REFVAL_P(zbValid), (zend_bool)bValidRaw);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, array of byte|string|NULL, array of byte|string|NULL, array of byte|string|NULL, &bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHAuthHandler, get_SSHClass)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHAuthHandler_get_SSHClass(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, IElSSHAuthHandlerContainer_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHAuthHandler, set_SSHClass)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, IElSSHAuthHandlerContainer_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSHAuthHandler_set_SSHClass(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\IElSSHAuthHandlerContainer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHAuthHandler, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHAuthHandler_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHAuthHandler_GetAlgorithmFromClientKexDHReply, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, HostAlg, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHAuthHandler_ValidateServerSignature, 0, 0, 7)
	ZEND_ARG_INFO(0, Algorithm)
	ZEND_ARG_TYPE_INFO(0, PubKeyStr, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Signature, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Hash, 0, 1)
	ZEND_ARG_INFO(0, HashAlg)
	ZEND_ARG_INFO(1, ErrCode)
	ZEND_ARG_INFO(1, ErrMessage)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHAuthHandler_FindKeyByAlgorithm, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Storage, TElSSHCustomKeyStorage, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHAuthHandler_GetKeyBlob, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Key, TElSSHKey, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHAuthHandler_KeyBlobToKey, 0, 0, 2)
	ZEND_ARG_INFO(0, AlgName)
	ZEND_ARG_TYPE_INFO(0, Blob, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHAuthHandler_HashAlgFromKey, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Key, TElSSHKey, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHAuthHandler_CalculateServerSignature, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Key, TElSSHKey, 1)
	ZEND_ARG_TYPE_INFO(0, aHash, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHAuthHandler_ServerValidateClientSignature, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, AlgName, 0, 1)
	ZEND_ARG_TYPE_INFO(0, KeyBlob, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Signature, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Hash, 0, 1)
	ZEND_ARG_INFO(1, Valid)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHAuthHandler_get_SSHClass, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHAuthHandler_set_SSHClass, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, IElSSHAuthHandlerContainer, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHAuthHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSHAuthHandler_methods[] = {
	PHP_ME(TElSSHAuthHandler, GetAlgorithmFromClientKexDHReply, arginfo_TElSSHAuthHandler_GetAlgorithmFromClientKexDHReply, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHAuthHandler, ValidateServerSignature, arginfo_TElSSHAuthHandler_ValidateServerSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHAuthHandler, FindKeyByAlgorithm, arginfo_TElSSHAuthHandler_FindKeyByAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHAuthHandler, GetKeyBlob, arginfo_TElSSHAuthHandler_GetKeyBlob, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHAuthHandler, KeyBlobToKey, arginfo_TElSSHAuthHandler_KeyBlobToKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHAuthHandler, HashAlgFromKey, arginfo_TElSSHAuthHandler_HashAlgFromKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHAuthHandler, CalculateServerSignature, arginfo_TElSSHAuthHandler_CalculateServerSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHAuthHandler, ServerValidateClientSignature, arginfo_TElSSHAuthHandler_ServerValidateClientSignature, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHAuthHandler, get_SSHClass, arginfo_TElSSHAuthHandler_get_SSHClass, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHAuthHandler, set_SSHClass, arginfo_TElSSHAuthHandler_set_SSHClass, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHAuthHandler, __construct, arginfo_TElSSHAuthHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSHAuthHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSHAuthHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSHAuthHandler", TElSSHAuthHandler_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElSSHAuthHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

SB_PHP_FUNCTION(SBSSHCommon, SSHEncodeString)
{
	char *sS;
	sb_str_size sS_len;
	uint32_t _err;
	zend_bool bNoTranslation;
	zend_bool bUseUTF8;
	zval *oConverter;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sbbO!", &sS, &sS_len, &bUseUTF8, &bNoTranslation, &oConverter, TPlConverter_ce_ptr) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBSSHCommon_SSHEncodeString(sS, (int32_t)sS_len, (int8_t)bUseUTF8, (int8_t)bNoTranslation, SBGetObjectHandle(oConverter TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(856102630, 4, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, bool, bool, \\TPlConverter)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSHCommon, SSHDecodeString)
{
	SBArrayZValInfo aiBuf;
	uint32_t _err;
	zend_bool bNoTranslation;
	zend_bool bUseUTF8;
	zval *oConverter;
	zval *zaBuf;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zbbO!", &zaBuf, &bUseUTF8, &bNoTranslation, &oConverter, TPlConverter_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuf) || SB_IS_ARRAY_TYPE_RP(zaBuf) || SB_IS_NULL_TYPE_RP(zaBuf)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaBuf, &aiBuf TSRMLS_CC)) RETURN_FALSE;
		_err = SBSSHCommon_SSHDecodeString(aiBuf.data, aiBuf.len, (int8_t)bUseUTF8, (int8_t)bNoTranslation, SBGetObjectHandle(oConverter TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(686350521, 4, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiBuf);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, bool, bool, \\TPlConverter)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSHCommon, SSHMemoryManager)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(SBSSHCommon_SSHMemoryManager(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElByteArrayManager_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

void Register_SBSSHCommon_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBSSHCommon, OBFUSCATE_MAGIC_VALUE, SB_OBFUSCATE_MAGIC_VALUE, SB_OBFUSCATE_MAGIC_VALUE);
	SB_REGISTER_LONG_CONSTANT(SBSSHCommon, OBFUSCATE_MAX_PADDING, SB_OBFUSCATE_MAX_PADDING, SB_OBFUSCATE_MAX_PADDING);
	SB_REGISTER_LONG_CONSTANT(SBSSHCommon, OBFUSCATE_SEED_LENGTH, SB_OBFUSCATE_SEED_LENGTH, SB_OBFUSCATE_SEED_LENGTH);
	SB_REGISTER_LONG_CONSTANT(SBSSHCommon, OBFUSCATE_HASH_ITERATIONS, SB_OBFUSCATE_HASH_ITERATIONS, SB_OBFUSCATE_HASH_ITERATIONS);
	SB_REGISTER_LONG_CONSTANT(SBSSHCommon, OBFUSCATE_KEY_LENGTH, SB_OBFUSCATE_KEY_LENGTH, SB_OBFUSCATE_KEY_LENGTH);
	SB_REGISTER_LONG_CONSTANT(SBSSHCommon, CURVE25519_SIZE, SB_CURVE25519_SIZE, SB_CURVE25519_SIZE);
	SB_REGISTER_LONG_CONSTANT(SBSSHCommon, CURVE448_SIZE, SB_CURVE448_SIZE, SB_CURVE448_SIZE);
	SB_REGISTER_STRING_CONSTANT(SBSSHCommon, SNewPasswordRequest, SB_SNewPasswordRequest, SB_SNewPasswordRequest);
	SB_REGISTER_STRING_CONSTANT(SBSSHCommon, SSessionRequestintTunnelsAreOnlyAllowed, SB_SSessionRequestintTunnelsAreOnlyAllowed, SB_SSessionRequestintTunnelsAreOnlyAllowed);
}

void Register_SBSSHCommon_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSSHTunnelType", NULL);
	TSSHTunnelType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSSHTunnelType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSSHTunnelType_ce_ptr, "ttLocalPortToRemoteAddress", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSSHTunnelType_ce_ptr, "ttRemotePortToLocalAddress", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSSHTunnelType_ce_ptr, "ttX11", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSSHTunnelType_ce_ptr, "ttAuthenticationAgent", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSSHTunnelType_ce_ptr, "ttSubsystem", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSSHTunnelType_ce_ptr, "ttCommand", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSSHTunnelType_ce_ptr, "ttShell", 6)
	
	INIT_CLASS_ENTRY(ce, "TSSHCloseType", NULL);
	TSSHCloseType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSSHCloseType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSSHCloseType_ce_ptr, "ctReturn", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSSHCloseType_ce_ptr, "ctSignal", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSSHCloseType_ce_ptr, "ctError", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBSSHAuthOrder", NULL);
	TSBSSHAuthOrder_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSSHAuthOrder_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSSHAuthOrder_ce_ptr, "aoDefault", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSHAuthOrder_ce_ptr, "aoKbdIntLast", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSHAuthOrder_ce_ptr, "aoCustom", 2)
	
	INIT_CLASS_ENTRY(ce, "TSSHReceiveState", NULL);
	TSSHReceiveState_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSSHReceiveState_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSSHReceiveState_ce_ptr, "rsRecordHeaderWanted", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSSHReceiveState_ce_ptr, "rsRecordWanted", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSSHReceiveState_ce_ptr, "rsMACWanted", 2)
	
	INIT_CLASS_ENTRY(ce, "TSSHVersion", NULL);
	TSSHVersion_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSSHVersion_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSSHVersion_ce_ptr, "sbSSH1", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSSHVersion_ce_ptr, "sbSSH2", 1)
	
	INIT_CLASS_ENTRY(ce, "TSSHVersions", NULL);
	TSSHVersions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSSHVersions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSSHVersions_ce_ptr, "sbSSH1", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSSHVersions_ce_ptr, "sbSSH2", 2)
	
	INIT_CLASS_ENTRY(ce, "TSSHStandardAlgorithmPriorityTemplate", NULL);
	TSSHStandardAlgorithmPriorityTemplate_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSSHStandardAlgorithmPriorityTemplate_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSSHStandardAlgorithmPriorityTemplate_ce_ptr, "sapDefault", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSSHStandardAlgorithmPriorityTemplate_ce_ptr, "sapDefinite", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSSHStandardAlgorithmPriorityTemplate_ce_ptr, "sapUniform", 2)
	
	INIT_CLASS_ENTRY(ce, "TSSH1State", NULL);
	TSSH1State_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSSH1State_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSSH1State_ce_ptr, "stNotEncrypted", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSSH1State_ce_ptr, "stEncrypted", 1)
}

void Register_SBSSHCommon_Aliases(TSRMLS_D)
{
	if (NULL == TElSSHClass_ce_ptr)
		Register_TElSSHClass(TSRMLS_C);
	zend_register_class_alias("ElSSHClass", TElSSHClass_ce_ptr);
	if (NULL == TElSSHTunnelList_ce_ptr)
		Register_TElSSHTunnelList(TSRMLS_C);
	zend_register_class_alias("ElSSHTunnelList", TElSSHTunnelList_ce_ptr);
	if (NULL == TElCustomSSHTunnel_ce_ptr)
		Register_TElCustomSSHTunnel(TSRMLS_C);
	zend_register_class_alias("ElCustomSSHTunnel", TElCustomSSHTunnel_ce_ptr);
	if (NULL == TElSSHTunnelConnection_ce_ptr)
		Register_TElSSHTunnelConnection(TSRMLS_C);
	zend_register_class_alias("ElSSHTunnelConnection", TElSSHTunnelConnection_ce_ptr);
	if (NULL == TElShellSSHTunnel_ce_ptr)
		Register_TElShellSSHTunnel(TSRMLS_C);
	zend_register_class_alias("ElShellSSHTunnel", TElShellSSHTunnel_ce_ptr);
	if (NULL == TElCommandSSHTunnel_ce_ptr)
		Register_TElCommandSSHTunnel(TSRMLS_C);
	zend_register_class_alias("ElCommandSSHTunnel", TElCommandSSHTunnel_ce_ptr);
	if (NULL == TElSubsystemSSHTunnel_ce_ptr)
		Register_TElSubsystemSSHTunnel(TSRMLS_C);
	zend_register_class_alias("ElSubsystemSSHTunnel", TElSubsystemSSHTunnel_ce_ptr);
	if (NULL == TElRemotePortForwardSSHTunnel_ce_ptr)
		Register_TElRemotePortForwardSSHTunnel(TSRMLS_C);
	zend_register_class_alias("ElRemotePortForwardSSHTunnel", TElRemotePortForwardSSHTunnel_ce_ptr);
	if (NULL == TElLocalPortForwardSSHTunnel_ce_ptr)
		Register_TElLocalPortForwardSSHTunnel(TSRMLS_C);
	zend_register_class_alias("ElLocalPortForwardSSHTunnel", TElLocalPortForwardSSHTunnel_ce_ptr);
	if (NULL == TElX11ForwardSSHTunnel_ce_ptr)
		Register_TElX11ForwardSSHTunnel(TSRMLS_C);
	zend_register_class_alias("ElX11ForwardSSHTunnel", TElX11ForwardSSHTunnel_ce_ptr);
	if (NULL == TElAuthenticationAgentSSHTunnel_ce_ptr)
		Register_TElAuthenticationAgentSSHTunnel(TSRMLS_C);
	zend_register_class_alias("ElAuthenticationAgentSSHTunnel", TElAuthenticationAgentSSHTunnel_ce_ptr);
	IElSSHAuthHandlerContainer_ce_ptr = TObject_ce_ptr;
	zend_register_class_alias("IElSSHAuthHandlerContainer", IElSSHAuthHandlerContainer_ce_ptr);
}
