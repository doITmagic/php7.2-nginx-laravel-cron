#include "sbsshconnectionhandler.h"

zend_class_entry *TElSSHConnectionHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElSSHConnectionHandler, Disconnect)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSSHConnectionHandler_Disconnect(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHConnectionHandler, SendData)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHConnectionHandler_SendData(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHConnectionHandler, SendExtendedData)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHConnectionHandler_SendExtendedData(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHConnectionHandler, ReceiveData)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHConnectionHandler_ReceiveData(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size, &l4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHConnectionHandler, ReceiveLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHConnectionHandler_ReceiveLength(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHConnectionHandler, get_Connected)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHConnectionHandler_get_Connected(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHConnectionHandler, get_Connection)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHConnectionHandler_get_Connection(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSHTunnelConnection_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHConnectionHandler, get_OnDisconnect)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHConnectionHandler_get_OnDisconnect(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHConnectionHandler, set_OnDisconnect)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHConnectionHandler_set_OnDisconnect(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHConnectionHandler, __construct)
{
	zval *oConnection;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oConnection, TElSSHTunnelConnection_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHConnectionHandler_Create(SBGetObjectHandle(oConnection TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHTunnelConnection)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHConnectionHandler_Disconnect, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHConnectionHandler_SendData, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHConnectionHandler_SendExtendedData, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHConnectionHandler_ReceiveData, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHConnectionHandler_ReceiveLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHConnectionHandler_get_Connected, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHConnectionHandler_get_Connection, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHConnectionHandler_get_OnDisconnect, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHConnectionHandler_set_OnDisconnect, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHConnectionHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Connection, TElSSHTunnelConnection, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSHConnectionHandler_methods[] = {
	PHP_ME(TElSSHConnectionHandler, Disconnect, arginfo_TElSSHConnectionHandler_Disconnect, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHConnectionHandler, SendData, arginfo_TElSSHConnectionHandler_SendData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHConnectionHandler, SendExtendedData, arginfo_TElSSHConnectionHandler_SendExtendedData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHConnectionHandler, ReceiveData, arginfo_TElSSHConnectionHandler_ReceiveData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHConnectionHandler, ReceiveLength, arginfo_TElSSHConnectionHandler_ReceiveLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHConnectionHandler, get_Connected, arginfo_TElSSHConnectionHandler_get_Connected, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHConnectionHandler, get_Connection, arginfo_TElSSHConnectionHandler_get_Connection, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHConnectionHandler, get_OnDisconnect, arginfo_TElSSHConnectionHandler_get_OnDisconnect, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHConnectionHandler, set_OnDisconnect, arginfo_TElSSHConnectionHandler_set_OnDisconnect, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHConnectionHandler, __construct, arginfo_TElSSHConnectionHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSHConnectionHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSHConnectionHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSHConnectionHandler", TElSSHConnectionHandler_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSSHConnectionHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

void Register_SBSSHConnectionHandler_Aliases(TSRMLS_D)
{
	if (NULL == TElSSHConnectionHandler_ce_ptr)
		Register_TElSSHConnectionHandler(TSRMLS_C);
	zend_register_class_alias("ElSSHConnectionHandler", TElSSHConnectionHandler_ce_ptr);
}

