#include "sbsshhandlers.h"

zend_class_entry *TSBSSHSubsystemHandlerType_ce_ptr = NULL;

void SB_CALLBACK TSBSSHSubsystemHandlerTerminateRequestRaw(void * _ObjectData, TObjectHandle Sender, int8_t * Terminate)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zTerminate;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zTerminate, 1);
	ZVAL_BOOL(Z_REFVAL_P(zTerminate), (zend_bool)*Terminate);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	convert_to_boolean(Z_REFVAL_P(zTerminate));
	*Terminate = (int8_t)SB_BVAL_P(Z_REFVAL_P(zTerminate));
	SB_EVENT_CLEAR_ZVAL(zTerminate);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElSSHSubsystemHandlerClass_ce_ptr = NULL;

#ifdef SB_WINDOWS
void SB_CALLBACK TSBSSHEncodedStringEventRaw(void * _ObjectData, TObjectHandle Sender, uint8_t pBuf[], int32_t * szBuf)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zBuf;
	SBArrayZValInfo aiBuf;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zBuf, 1);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zBuf), pBuf, *szBuf);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	if (SBGetByteArrayFromZVal(zBuf, &aiBuf TSRMLS_CC))
		SBCheckError(SBSetEventReturnBuffer(2, aiBuf.data, aiBuf.len) TSRMLS_CC);
	SBFreeArrayZValInfo(&aiBuf);
	SB_EVENT_CLEAR_ZVAL(zBuf);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}
#endif

zend_class_entry *TElCustomSSHSubsystemHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, HandlerType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSSHSubsystemHandlerTypeRaw fOutResultRaw = 0;
		SBCheckError(TElCustomSSHSubsystemHandler_HandlerType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, Run)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCustomSSHSubsystemHandler_Run(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, Terminate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCustomSSHSubsystemHandler_Terminate(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, WaitForInputData)
{
	sb_zend_long l4Time;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Time) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomSSHSubsystemHandler_WaitForInputData(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Time, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSHSubsystemHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, get_Connection)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSHSubsystemHandler_get_Connection(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSHTunnelConnection_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, get_FlushCachedData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomSSHSubsystemHandler_get_FlushCachedData(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, set_FlushCachedData)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCustomSSHSubsystemHandler_set_FlushCachedData(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, get_OnTerminateRequest)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSSHSubsystemHandlerTerminateRequest pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCustomSSHSubsystemHandler_get_OnTerminateRequest(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, set_OnTerminateRequest)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCustomSSHSubsystemHandler_set_OnTerminateRequest(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSSHSubsystemHandlerTerminateRequestRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSSHSubsystemHandlerTerminateRequest|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, get_OnDisconnect)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCustomSSHSubsystemHandler_get_OnDisconnect(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, set_OnDisconnect)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCustomSSHSubsystemHandler_set_OnDisconnect(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, get_OnUnsafeOperationStart)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCustomSSHSubsystemHandler_get_OnUnsafeOperationStart(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, set_OnUnsafeOperationStart)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCustomSSHSubsystemHandler_set_OnUnsafeOperationStart(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, get_OnUnsafeOperationEnd)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCustomSSHSubsystemHandler_get_OnUnsafeOperationEnd(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, set_OnUnsafeOperationEnd)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCustomSSHSubsystemHandler_set_OnUnsafeOperationEnd(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, get_OnEOF)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHEOFEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElCustomSSHSubsystemHandler_get_OnEOF(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, set_OnEOF)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElCustomSSHSubsystemHandler_set_OnEOF(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHEOFEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHEOFEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, __construct)
{
	zval *oConnection;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oConnection, TElSSHTunnelConnection_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSHSubsystemHandler_Create(SBGetObjectHandle(oConnection TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHTunnelConnection)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSHSubsystemHandler, CreateDelayed)
{
	zval *oConnection;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oConnection, TElSSHTunnelConnection_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSHSubsystemHandler_CreateDelayed(SBGetObjectHandle(oConnection TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TElCustomSSHSubsystemHandler_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHTunnelConnection)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_HandlerType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_Run, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_Terminate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_WaitForInputData, 0, 0, 1)
	ZEND_ARG_INFO(0, Time)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_get_Connection, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_get_FlushCachedData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_set_FlushCachedData, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_get_OnTerminateRequest, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_set_OnTerminateRequest, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_get_OnDisconnect, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_set_OnDisconnect, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_get_OnUnsafeOperationStart, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_set_OnUnsafeOperationStart, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_get_OnUnsafeOperationEnd, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_set_OnUnsafeOperationEnd, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_get_OnEOF, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_set_OnEOF, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Connection, TElSSHTunnelConnection, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSHSubsystemHandler_CreateDelayed, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Connection, TElSSHTunnelConnection, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCustomSSHSubsystemHandler_methods[] = {
	PHP_ME(TElCustomSSHSubsystemHandler, HandlerType, arginfo_TElCustomSSHSubsystemHandler_HandlerType, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, Run, arginfo_TElCustomSSHSubsystemHandler_Run, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, Terminate, arginfo_TElCustomSSHSubsystemHandler_Terminate, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, WaitForInputData, arginfo_TElCustomSSHSubsystemHandler_WaitForInputData, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, ClassType, arginfo_TElCustomSSHSubsystemHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElCustomSSHSubsystemHandler, get_Connection, arginfo_TElCustomSSHSubsystemHandler_get_Connection, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, get_FlushCachedData, arginfo_TElCustomSSHSubsystemHandler_get_FlushCachedData, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, set_FlushCachedData, arginfo_TElCustomSSHSubsystemHandler_set_FlushCachedData, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, get_OnTerminateRequest, arginfo_TElCustomSSHSubsystemHandler_get_OnTerminateRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, set_OnTerminateRequest, arginfo_TElCustomSSHSubsystemHandler_set_OnTerminateRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, get_OnDisconnect, arginfo_TElCustomSSHSubsystemHandler_get_OnDisconnect, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, set_OnDisconnect, arginfo_TElCustomSSHSubsystemHandler_set_OnDisconnect, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, get_OnUnsafeOperationStart, arginfo_TElCustomSSHSubsystemHandler_get_OnUnsafeOperationStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, set_OnUnsafeOperationStart, arginfo_TElCustomSSHSubsystemHandler_set_OnUnsafeOperationStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, get_OnUnsafeOperationEnd, arginfo_TElCustomSSHSubsystemHandler_get_OnUnsafeOperationEnd, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, set_OnUnsafeOperationEnd, arginfo_TElCustomSSHSubsystemHandler_set_OnUnsafeOperationEnd, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, get_OnEOF, arginfo_TElCustomSSHSubsystemHandler_get_OnEOF, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, set_OnEOF, arginfo_TElCustomSSHSubsystemHandler_set_OnEOF, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, __construct, arginfo_TElCustomSSHSubsystemHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSHSubsystemHandler, CreateDelayed, arginfo_TElCustomSSHSubsystemHandler_CreateDelayed, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TElCustomSSHSubsystemHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCustomSSHSubsystemHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCustomSSHSubsystemHandler", TElCustomSSHSubsystemHandler_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElCustomSSHSubsystemHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

#ifdef SB_WINDOWS
zend_class_entry *TElShellSSHSubsystemHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElShellSSHSubsystemHandler, HandlerType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSSHSubsystemHandlerTypeRaw fOutResultRaw = 0;
		SBCheckError(TElShellSSHSubsystemHandler_HandlerType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElShellSSHSubsystemHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, get_Command)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElShellSSHSubsystemHandler_get_Command(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1248347555, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, set_Command)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElShellSSHSubsystemHandler_set_Command(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, get_RawCommandLine)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElShellSSHSubsystemHandler_get_RawCommandLine(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1734105515, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, set_RawCommandLine)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElShellSSHSubsystemHandler_set_RawCommandLine(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, get_CurrentDirectory)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElShellSSHSubsystemHandler_get_CurrentDirectory(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(576182102, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, set_CurrentDirectory)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElShellSSHSubsystemHandler_set_CurrentDirectory(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, get_NoCharacterEncoding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElShellSSHSubsystemHandler_get_NoCharacterEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, set_NoCharacterEncoding)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElShellSSHSubsystemHandler_set_NoCharacterEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, get_UseUTF8)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElShellSSHSubsystemHandler_get_UseUTF8(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, set_UseUTF8)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElShellSSHSubsystemHandler_set_UseUTF8(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, get_OutputLines)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElShellSSHSubsystemHandler_get_OutputLines(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, set_OutputLines)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElShellSSHSubsystemHandler_set_OutputLines(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, get_SendCharactersBack)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElShellSSHSubsystemHandler_get_SendCharactersBack(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, set_SendCharactersBack)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElShellSSHSubsystemHandler_set_SendCharactersBack(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, get_MaxCacheSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElShellSSHSubsystemHandler_get_MaxCacheSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, set_MaxCacheSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElShellSSHSubsystemHandler_set_MaxCacheSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, get_OnBeforeDecoding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSSHEncodedStringEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElShellSSHSubsystemHandler_get_OnBeforeDecoding(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, set_OnBeforeDecoding)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElShellSSHSubsystemHandler_set_OnBeforeDecoding(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSSHEncodedStringEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSSHEncodedStringEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, get_OnAfterEncoding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSSHEncodedStringEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElShellSSHSubsystemHandler_get_OnAfterEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, set_OnAfterEncoding)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElShellSSHSubsystemHandler_set_OnAfterEncoding(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSSHEncodedStringEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSSHEncodedStringEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, __construct)
{
	zval *oConnection;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oConnection, TElSSHTunnelConnection_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElShellSSHSubsystemHandler_Create(SBGetObjectHandle(oConnection TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHTunnelConnection)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElShellSSHSubsystemHandler, CreateDelayed)
{
	zval *oConnection;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oConnection, TElSSHTunnelConnection_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElShellSSHSubsystemHandler_CreateDelayed(SBGetObjectHandle(oConnection TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TElCustomSSHSubsystemHandler_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHTunnelConnection)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_HandlerType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_get_Command, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_set_Command, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_get_RawCommandLine, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_set_RawCommandLine, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_get_CurrentDirectory, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_set_CurrentDirectory, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_get_NoCharacterEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_set_NoCharacterEncoding, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_get_UseUTF8, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_set_UseUTF8, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_get_OutputLines, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_set_OutputLines, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_get_SendCharactersBack, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_set_SendCharactersBack, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_get_MaxCacheSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_set_MaxCacheSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_get_OnBeforeDecoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_set_OnBeforeDecoding, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_get_OnAfterEncoding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_set_OnAfterEncoding, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Connection, TElSSHTunnelConnection, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElShellSSHSubsystemHandler_CreateDelayed, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Connection, TElSSHTunnelConnection, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElShellSSHSubsystemHandler_methods[] = {
	PHP_ME(TElShellSSHSubsystemHandler, HandlerType, arginfo_TElShellSSHSubsystemHandler_HandlerType, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, ClassType, arginfo_TElShellSSHSubsystemHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElShellSSHSubsystemHandler, get_Command, arginfo_TElShellSSHSubsystemHandler_get_Command, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, set_Command, arginfo_TElShellSSHSubsystemHandler_set_Command, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, get_RawCommandLine, arginfo_TElShellSSHSubsystemHandler_get_RawCommandLine, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, set_RawCommandLine, arginfo_TElShellSSHSubsystemHandler_set_RawCommandLine, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, get_CurrentDirectory, arginfo_TElShellSSHSubsystemHandler_get_CurrentDirectory, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, set_CurrentDirectory, arginfo_TElShellSSHSubsystemHandler_set_CurrentDirectory, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, get_NoCharacterEncoding, arginfo_TElShellSSHSubsystemHandler_get_NoCharacterEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, set_NoCharacterEncoding, arginfo_TElShellSSHSubsystemHandler_set_NoCharacterEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, get_UseUTF8, arginfo_TElShellSSHSubsystemHandler_get_UseUTF8, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, set_UseUTF8, arginfo_TElShellSSHSubsystemHandler_set_UseUTF8, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, get_OutputLines, arginfo_TElShellSSHSubsystemHandler_get_OutputLines, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, set_OutputLines, arginfo_TElShellSSHSubsystemHandler_set_OutputLines, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, get_SendCharactersBack, arginfo_TElShellSSHSubsystemHandler_get_SendCharactersBack, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, set_SendCharactersBack, arginfo_TElShellSSHSubsystemHandler_set_SendCharactersBack, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, get_MaxCacheSize, arginfo_TElShellSSHSubsystemHandler_get_MaxCacheSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, set_MaxCacheSize, arginfo_TElShellSSHSubsystemHandler_set_MaxCacheSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, get_OnBeforeDecoding, arginfo_TElShellSSHSubsystemHandler_get_OnBeforeDecoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, set_OnBeforeDecoding, arginfo_TElShellSSHSubsystemHandler_set_OnBeforeDecoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, get_OnAfterEncoding, arginfo_TElShellSSHSubsystemHandler_get_OnAfterEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, set_OnAfterEncoding, arginfo_TElShellSSHSubsystemHandler_set_OnAfterEncoding, ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, __construct, arginfo_TElShellSSHSubsystemHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TElShellSSHSubsystemHandler, CreateDelayed, arginfo_TElShellSSHSubsystemHandler_CreateDelayed, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TElShellSSHSubsystemHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElShellSSHSubsystemHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElShellSSHSubsystemHandler", TElShellSSHSubsystemHandler_methods);
	if (NULL == TElCustomSSHSubsystemHandler_ce_ptr)
		Register_TElCustomSSHSubsystemHandler(TSRMLS_C);
	TElShellSSHSubsystemHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSHSubsystemHandler_ce_ptr);
}
#endif

zend_class_entry *TElCustomSocketForwardingSSHSubsystemHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElCustomSocketForwardingSSHSubsystemHandler, HandlerType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSSHSubsystemHandlerTypeRaw fOutResultRaw = 0;
		SBCheckError(TElCustomSocketForwardingSSHSubsystemHandler_HandlerType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSocketForwardingSSHSubsystemHandler, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSocketForwardingSSHSubsystemHandler_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSocketForwardingSSHSubsystemHandler, get_Host)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElCustomSocketForwardingSSHSubsystemHandler_get_Host(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-676748603, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSocketForwardingSSHSubsystemHandler, set_Host)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElCustomSocketForwardingSSHSubsystemHandler_set_Host(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSocketForwardingSSHSubsystemHandler, get_Port)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomSocketForwardingSSHSubsystemHandler_get_Port(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSocketForwardingSSHSubsystemHandler, set_Port)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElCustomSocketForwardingSSHSubsystemHandler_set_Port(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSocketForwardingSSHSubsystemHandler, get_Timeout)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomSocketForwardingSSHSubsystemHandler_get_Timeout(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSocketForwardingSSHSubsystemHandler, set_Timeout)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElCustomSocketForwardingSSHSubsystemHandler_set_Timeout(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSocketForwardingSSHSubsystemHandler, __construct)
{
	zval *oConnection;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oConnection, TElSSHTunnelConnection_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSocketForwardingSSHSubsystemHandler_Create(SBGetObjectHandle(oConnection TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHTunnelConnection)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSocketForwardingSSHSubsystemHandler, CreateDelayed)
{
	zval *oConnection;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oConnection, TElSSHTunnelConnection_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSocketForwardingSSHSubsystemHandler_CreateDelayed(SBGetObjectHandle(oConnection TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TElCustomSSHSubsystemHandler_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHTunnelConnection)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSocketForwardingSSHSubsystemHandler_HandlerType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSocketForwardingSSHSubsystemHandler_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSocketForwardingSSHSubsystemHandler_get_Host, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSocketForwardingSSHSubsystemHandler_set_Host, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSocketForwardingSSHSubsystemHandler_get_Port, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSocketForwardingSSHSubsystemHandler_set_Port, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSocketForwardingSSHSubsystemHandler_get_Timeout, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSocketForwardingSSHSubsystemHandler_set_Timeout, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSocketForwardingSSHSubsystemHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Connection, TElSSHTunnelConnection, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSocketForwardingSSHSubsystemHandler_CreateDelayed, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Connection, TElSSHTunnelConnection, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElCustomSocketForwardingSSHSubsystemHandler_methods[] = {
	PHP_ME(TElCustomSocketForwardingSSHSubsystemHandler, HandlerType, arginfo_TElCustomSocketForwardingSSHSubsystemHandler_HandlerType, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSocketForwardingSSHSubsystemHandler, ClassType, arginfo_TElCustomSocketForwardingSSHSubsystemHandler_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElCustomSocketForwardingSSHSubsystemHandler, get_Host, arginfo_TElCustomSocketForwardingSSHSubsystemHandler_get_Host, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSocketForwardingSSHSubsystemHandler, set_Host, arginfo_TElCustomSocketForwardingSSHSubsystemHandler_set_Host, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSocketForwardingSSHSubsystemHandler, get_Port, arginfo_TElCustomSocketForwardingSSHSubsystemHandler_get_Port, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSocketForwardingSSHSubsystemHandler, set_Port, arginfo_TElCustomSocketForwardingSSHSubsystemHandler_set_Port, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSocketForwardingSSHSubsystemHandler, get_Timeout, arginfo_TElCustomSocketForwardingSSHSubsystemHandler_get_Timeout, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSocketForwardingSSHSubsystemHandler, set_Timeout, arginfo_TElCustomSocketForwardingSSHSubsystemHandler_set_Timeout, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSocketForwardingSSHSubsystemHandler, __construct, arginfo_TElCustomSocketForwardingSSHSubsystemHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSocketForwardingSSHSubsystemHandler, CreateDelayed, arginfo_TElCustomSocketForwardingSSHSubsystemHandler_CreateDelayed, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TElCustomSocketForwardingSSHSubsystemHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCustomSocketForwardingSSHSubsystemHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCustomSocketForwardingSSHSubsystemHandler", TElCustomSocketForwardingSSHSubsystemHandler_methods);
	if (NULL == TElCustomSSHSubsystemHandler_ce_ptr)
		Register_TElCustomSSHSubsystemHandler(TSRMLS_C);
	TElCustomSocketForwardingSSHSubsystemHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSHSubsystemHandler_ce_ptr);
}

zend_class_entry *TElSSHSubsystemThread_ce_ptr = NULL;

SB_PHP_METHOD(TElSSHSubsystemThread, get_Handler)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHSubsystemThread_get_Handler(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomSSHSubsystemHandler_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHSubsystemThread, get_OnTerminateSubsystem)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHSubsystemThread_get_OnTerminateSubsystem(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHSubsystemThread, set_OnTerminateSubsystem)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHSubsystemThread_set_OnTerminateSubsystem(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHSubsystemThread, __construct)
{
	zend_bool bCreateSuspended;
	zval *oCls;
	zval *oConnection;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!b", &oCls, TElSSHSubsystemHandlerClass_ce_ptr, &oConnection, TElSSHTunnelConnection_ce_ptr, &bCreateSuspended) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHSubsystemThread_Create(SBGetObjectHandle(oCls TSRMLS_CC), SBGetObjectHandle(oConnection TSRMLS_CC), (int8_t)bCreateSuspended, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHSubsystemHandlerClass, \\TElSSHTunnelConnection, bool)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHSubsystemThread_get_Handler, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHSubsystemThread_get_OnTerminateSubsystem, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHSubsystemThread_set_OnTerminateSubsystem, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHSubsystemThread___construct, 0, 0, 3)
	ZEND_ARG_OBJ_INFO(0, Cls, TElSSHSubsystemHandlerClass, 1)
	ZEND_ARG_OBJ_INFO(0, Connection, TElSSHTunnelConnection, 1)
	ZEND_ARG_INFO(0, CreateSuspended)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSHSubsystemThread_methods[] = {
	PHP_ME(TElSSHSubsystemThread, get_Handler, arginfo_TElSSHSubsystemThread_get_Handler, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHSubsystemThread, get_OnTerminateSubsystem, arginfo_TElSSHSubsystemThread_get_OnTerminateSubsystem, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHSubsystemThread, set_OnTerminateSubsystem, arginfo_TElSSHSubsystemThread_set_OnTerminateSubsystem, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHSubsystemThread, __construct, arginfo_TElSSHSubsystemThread___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSHSubsystemThread(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSHSubsystemThread_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSHSubsystemThread", TElSSHSubsystemThread_methods);
	if (NULL == TThread_ce_ptr)
		Register_TThread(TSRMLS_C);
	TElSSHSubsystemThread_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TThread_ce_ptr);
}

void Register_SBSSHHandlers_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBSSHSubsystemHandlerType", NULL);
	TSBSSHSubsystemHandlerType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSSHSubsystemHandlerType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSSHSubsystemHandlerType_ce_ptr, "shtSynchronous", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSHSubsystemHandlerType_ce_ptr, "shtAsynchronous", 1)
}

void Register_SBSSHHandlers_Aliases(TSRMLS_D)
{
	if (NULL == TElCustomSSHSubsystemHandler_ce_ptr)
		Register_TElCustomSSHSubsystemHandler(TSRMLS_C);
	zend_register_class_alias("ElCustomSSHSubsystemHandler", TElCustomSSHSubsystemHandler_ce_ptr);
#ifdef SB_WINDOWS
	if (NULL == TElShellSSHSubsystemHandler_ce_ptr)
		Register_TElShellSSHSubsystemHandler(TSRMLS_C);
	zend_register_class_alias("ElShellSSHSubsystemHandler", TElShellSSHSubsystemHandler_ce_ptr);
#endif
	if (NULL == TElCustomSocketForwardingSSHSubsystemHandler_ce_ptr)
		Register_TElCustomSocketForwardingSSHSubsystemHandler(TSRMLS_C);
	zend_register_class_alias("ElCustomSocketForwardingSSHSubsystemHandler", TElCustomSocketForwardingSSHSubsystemHandler_ce_ptr);
	if (NULL == TElSSHSubsystemThread_ce_ptr)
		Register_TElSSHSubsystemThread(TSRMLS_C);
	zend_register_class_alias("ElSSHSubsystemThread", TElSSHSubsystemThread_ce_ptr);
	TElSSHSubsystemHandlerClass_ce_ptr = TObject_ce_ptr;
	zend_register_class_alias("TElSSHSubsystemHandlerClass", TElSSHSubsystemHandlerClass_ce_ptr);
	zend_register_class_alias("ElSSHSubsystemHandlerClass", TObject_ce_ptr);
}
