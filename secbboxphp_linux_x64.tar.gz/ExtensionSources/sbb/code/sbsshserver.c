#include "sbsshserver.h"

zend_class_entry *TSSHServerState_ce_ptr = NULL;

zend_class_entry *TSSHServerProtService_ce_ptr = NULL;

void SB_CALLBACK TSSHAuthAttemptEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, int32_t AuthType, int8_t * Accept)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zUsername;
	zval * zAuthType;
	zval * zAccept;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zUsername, 1);
	SB_ZVAL_STRINGL_DUP(zUsername, pcUsername, szUsername);
	SB_EVENT_INIT_ZVAL(zAuthType, 2);
	ZVAL_LONG(zAuthType, (sb_zend_long)AuthType);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 3);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zUsername);
	SB_EVENT_CLEAR_ZVAL(zAuthType);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHAuthPublicKeyEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, TElSSHKeyHandle Key, int8_t * Accept)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zUsername;
	zval * zKey;
	zval * zAccept;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zUsername, 1);
	SB_ZVAL_STRINGL_DUP(zUsername, pcUsername, szUsername);
	SB_EVENT_INIT_ZVAL(zKey, 2);
	SBInitObject(zKey, TElSSHKey_ce_ptr, Key TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 3);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zUsername);
	SB_EVENT_CLEAR_ZVAL(zKey);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHAuthHostbasedEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, const char * pcClientUsername, int32_t szClientUsername, const char * pcClientHostname, int32_t szClientHostname, TElSSHKeyHandle Key, int8_t * Accept)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(6);
	zval * zSender;
	zval * zUsername;
	zval * zClientUsername;
	zval * zClientHostname;
	zval * zKey;
	zval * zAccept;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zUsername, 1);
	SB_ZVAL_STRINGL_DUP(zUsername, pcUsername, szUsername);
	SB_EVENT_INIT_ZVAL(zClientUsername, 2);
	SB_ZVAL_STRINGL_DUP(zClientUsername, pcClientUsername, szClientUsername);
	SB_EVENT_INIT_ZVAL(zClientHostname, 3);
	SB_ZVAL_STRINGL_DUP(zClientHostname, pcClientHostname, szClientHostname);
	SB_EVENT_INIT_ZVAL(zKey, 4);
	SBInitObject(zKey, TElSSHKey_ce_ptr, Key TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 5);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 6, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zUsername);
	SB_EVENT_CLEAR_ZVAL(zClientUsername);
	SB_EVENT_CLEAR_ZVAL(zClientHostname);
	SB_EVENT_CLEAR_ZVAL(zKey);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHAuthBannerEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, int32_t AuthType, char * pcBanner, int32_t * szBanner, uint8_t pLanguageTag[], int32_t * szLanguageTag)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zUsername;
	zval * zAuthType;
	zval * zBanner;
	zval * zLanguageTag;
	SBArrayZValInfo aiLanguageTag;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zUsername, 1);
	SB_ZVAL_STRINGL_DUP(zUsername, pcUsername, szUsername);
	SB_EVENT_INIT_ZVAL(zAuthType, 2);
	ZVAL_LONG(zAuthType, (sb_zend_long)AuthType);
	SB_EVENT_INIT_ZVAL_REF(zBanner, 3);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zBanner), pcBanner, *szBanner);
	SB_EVENT_INIT_ZVAL_REF(zLanguageTag, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zLanguageTag), pLanguageTag, *szLanguageTag);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zUsername);
	SB_EVENT_CLEAR_ZVAL(zAuthType);
	convert_to_string(Z_REFVAL_P(zBanner));
	SBCheckError(SBSetEventReturnStringA(4, Z_STRVAL_P(Z_REFVAL_P(zBanner)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zBanner))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zBanner);
	if (SBGetByteArrayFromZVal(zLanguageTag, &aiLanguageTag TSRMLS_CC))
		SBCheckError(SBSetEventReturnBuffer(5, aiLanguageTag.data, aiLanguageTag.len) TSRMLS_CC);
	SBFreeArrayZValInfo(&aiLanguageTag);
	SB_EVENT_CLEAR_ZVAL(zLanguageTag);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHAuthPasswordEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, const char * pcPassword, int32_t szPassword, int8_t * Accept, int8_t * ForceChangePassword)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zUsername;
	zval * zPassword;
	zval * zAccept;
	zval * zForceChangePassword;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zUsername, 1);
	SB_ZVAL_STRINGL_DUP(zUsername, pcUsername, szUsername);
	SB_EVENT_INIT_ZVAL(zPassword, 2);
	SB_ZVAL_STRINGL_DUP(zPassword, pcPassword, szPassword);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 3);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);
	SB_EVENT_INIT_ZVAL_REF(zForceChangePassword, 4);
	ZVAL_BOOL(Z_REFVAL_P(zForceChangePassword), (zend_bool)*ForceChangePassword);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zUsername);
	SB_EVENT_CLEAR_ZVAL(zPassword);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	convert_to_boolean(Z_REFVAL_P(zForceChangePassword));
	*ForceChangePassword = (int8_t)SB_BVAL_P(Z_REFVAL_P(zForceChangePassword));
	SB_EVENT_CLEAR_ZVAL(zForceChangePassword);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHAuthPasswordChangeEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, const char * pcOldPassword, int32_t szOldPassword, const char * pcNewPassword, int32_t szNewPassword, int8_t * Accept)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zUsername;
	zval * zOldPassword;
	zval * zNewPassword;
	zval * zAccept;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zUsername, 1);
	SB_ZVAL_STRINGL_DUP(zUsername, pcUsername, szUsername);
	SB_EVENT_INIT_ZVAL(zOldPassword, 2);
	SB_ZVAL_STRINGL_DUP(zOldPassword, pcOldPassword, szOldPassword);
	SB_EVENT_INIT_ZVAL(zNewPassword, 3);
	SB_ZVAL_STRINGL_DUP(zNewPassword, pcNewPassword, szNewPassword);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 4);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zUsername);
	SB_EVENT_CLEAR_ZVAL(zOldPassword);
	SB_EVENT_CLEAR_ZVAL(zNewPassword);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHAuthKeyboardEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, TStringListHandle Submethods, char * pcName, int32_t * szName, char * pcInstruction, int32_t * szInstruction, TStringListHandle Requests, TBitsHandle Echoes)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(7);
	zval * zSender;
	zval * zUsername;
	zval * zSubmethods;
	zval * zName;
	zval * zInstruction;
	zval * zRequests;
	zval * zEchoes;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zUsername, 1);
	SB_ZVAL_STRINGL_DUP(zUsername, pcUsername, szUsername);
	SB_EVENT_INIT_ZVAL(zSubmethods, 2);
	SBInitObject(zSubmethods, TStringList_ce_ptr, Submethods TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zName, 3);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zName), pcName, *szName);
	SB_EVENT_INIT_ZVAL_REF(zInstruction, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zInstruction), pcInstruction, *szInstruction);
	SB_EVENT_INIT_ZVAL(zRequests, 5);
	SBInitObject(zRequests, TStringList_ce_ptr, Requests TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zEchoes, 6);
	SBInitObject(zEchoes, TBits_ce_ptr, Echoes TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 7, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zUsername);
	SB_EVENT_CLEAR_ZVAL(zSubmethods);
	convert_to_string(Z_REFVAL_P(zName));
	SBCheckError(SBSetEventReturnStringA(4, Z_STRVAL_P(Z_REFVAL_P(zName)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zName))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zName);
	convert_to_string(Z_REFVAL_P(zInstruction));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zInstruction)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zInstruction))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zInstruction);
	SB_EVENT_CLEAR_ZVAL(zRequests);
	SB_EVENT_CLEAR_ZVAL(zEchoes);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHAuthKeyboardResponseEventRaw(void * _ObjectData, TObjectHandle Sender, TStringListHandle Requests, TStringListHandle Responses, char * pcName, int32_t * szName, char * pcInstruction, int32_t * szInstruction, TStringListHandle NewRequests, TBitsHandle Echoes, int8_t * Accept)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(8);
	zval * zSender;
	zval * zRequests;
	zval * zResponses;
	zval * zName;
	zval * zInstruction;
	zval * zNewRequests;
	zval * zEchoes;
	zval * zAccept;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zRequests, 1);
	SBInitObject(zRequests, TStringList_ce_ptr, Requests TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zResponses, 2);
	SBInitObject(zResponses, TStringList_ce_ptr, Responses TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zName, 3);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zName), pcName, *szName);
	SB_EVENT_INIT_ZVAL_REF(zInstruction, 4);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zInstruction), pcInstruction, *szInstruction);
	SB_EVENT_INIT_ZVAL(zNewRequests, 5);
	SBInitObject(zNewRequests, TStringList_ce_ptr, NewRequests TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zEchoes, 6);
	SBInitObject(zEchoes, TBits_ce_ptr, Echoes TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 7);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 8, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zRequests);
	SB_EVENT_CLEAR_ZVAL(zResponses);
	convert_to_string(Z_REFVAL_P(zName));
	SBCheckError(SBSetEventReturnStringA(4, Z_STRVAL_P(Z_REFVAL_P(zName)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zName))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zName);
	convert_to_string(Z_REFVAL_P(zInstruction));
	SBCheckError(SBSetEventReturnStringA(5, Z_STRVAL_P(Z_REFVAL_P(zInstruction)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zInstruction))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zInstruction);
	SB_EVENT_CLEAR_ZVAL(zNewRequests);
	SB_EVENT_CLEAR_ZVAL(zEchoes);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHFurtherAuthNeededEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, int8_t * Needed)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zUsername;
	zval * zNeeded;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zUsername, 1);
	SB_ZVAL_STRINGL_DUP(zUsername, pcUsername, szUsername);
	SB_EVENT_INIT_ZVAL_REF(zNeeded, 2);
	ZVAL_BOOL(Z_REFVAL_P(zNeeded), (zend_bool)*Needed);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zUsername);
	convert_to_boolean(Z_REFVAL_P(zNeeded));
	*Needed = (int8_t)SB_BVAL_P(Z_REFVAL_P(zNeeded));
	SB_EVENT_CLEAR_ZVAL(zNeeded);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHBeforeOpenSessionEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t * Accept)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zAccept;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 1);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHBeforeOpenShellEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, int8_t * Accept)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zConnection;
	zval * zAccept;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zConnection, 1);
	SBInitObject(zConnection, TElSSHTunnelConnection_ce_ptr, Connection TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 2);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zConnection);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHBeforeOpenCommandEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcCommand, int32_t szCommand, int8_t * Accept)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zConnection;
	zval * zCommand;
	zval * zAccept;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zConnection, 1);
	SBInitObject(zConnection, TElSSHTunnelConnection_ce_ptr, Connection TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCommand, 2);
	SB_ZVAL_STRINGL_DUP(zCommand, pcCommand, szCommand);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 3);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zConnection);
	SB_EVENT_CLEAR_ZVAL(zCommand);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHBeforeOpenSubsystemEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcSubsystem, int32_t szSubsystem, TElSSHTunnelConnectionHandle Connection, int8_t * Accept)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zSubsystem;
	zval * zConnection;
	zval * zAccept;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSubsystem, 1);
	SB_ZVAL_STRINGL_DUP(zSubsystem, pcSubsystem, szSubsystem);
	SB_EVENT_INIT_ZVAL(zConnection, 2);
	SBInitObject(zConnection, TElSSHTunnelConnection_ce_ptr, Connection TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 3);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSubsystem);
	SB_EVENT_CLEAR_ZVAL(zConnection);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHBeforeOpenClientForwardingEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcDestHost, int32_t szDestHost, int32_t DestPort, const char * pcSrcHost, int32_t szSrcHost, int32_t SrcPort, int8_t * Accept)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(6);
	zval * zSender;
	zval * zDestHost;
	zval * zDestPort;
	zval * zSrcHost;
	zval * zSrcPort;
	zval * zAccept;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zDestHost, 1);
	SB_ZVAL_STRINGL_DUP(zDestHost, pcDestHost, szDestHost);
	SB_EVENT_INIT_ZVAL(zDestPort, 2);
	ZVAL_LONG(zDestPort, (sb_zend_long)DestPort);
	SB_EVENT_INIT_ZVAL(zSrcHost, 3);
	SB_ZVAL_STRINGL_DUP(zSrcHost, pcSrcHost, szSrcHost);
	SB_EVENT_INIT_ZVAL(zSrcPort, 4);
	ZVAL_LONG(zSrcPort, (sb_zend_long)SrcPort);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 5);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 6, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zDestHost);
	SB_EVENT_CLEAR_ZVAL(zDestPort);
	SB_EVENT_CLEAR_ZVAL(zSrcHost);
	SB_EVENT_CLEAR_ZVAL(zSrcPort);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHBeforeOpenX11ForwardingEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcOrigIP, int32_t szOrigIP, int32_t OrigPort, int8_t * Accept)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zOrigIP;
	zval * zOrigPort;
	zval * zAccept;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOrigIP, 1);
	SB_ZVAL_STRINGL_DUP(zOrigIP, pcOrigIP, szOrigIP);
	SB_EVENT_INIT_ZVAL(zOrigPort, 2);
	ZVAL_LONG(zOrigPort, (sb_zend_long)OrigPort);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 3);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zOrigIP);
	SB_EVENT_CLEAR_ZVAL(zOrigPort);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHOpenSessionEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zConnection;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zConnection, 1);
	SBInitObject(zConnection, TElSSHTunnelConnection_ce_ptr, Connection TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zConnection);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHOpenShellEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zConnection;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zConnection, 1);
	SBInitObject(zConnection, TElSSHTunnelConnection_ce_ptr, Connection TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zConnection);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHOpenCommandEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcCommand, int32_t szCommand)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zConnection;
	zval * zCommand;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zConnection, 1);
	SBInitObject(zConnection, TElSSHTunnelConnection_ce_ptr, Connection TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCommand, 2);
	SB_ZVAL_STRINGL_DUP(zCommand, pcCommand, szCommand);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zConnection);
	SB_EVENT_CLEAR_ZVAL(zCommand);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHOpenSubsystemEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcSubsystem, int32_t szSubsystem)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zConnection;
	zval * zSubsystem;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zConnection, 1);
	SBInitObject(zConnection, TElSSHTunnelConnection_ce_ptr, Connection TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSubsystem, 2);
	SB_ZVAL_STRINGL_DUP(zSubsystem, pcSubsystem, szSubsystem);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zConnection);
	SB_EVENT_CLEAR_ZVAL(zSubsystem);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHOpenClientForwardingEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcDestHost, int32_t szDestHost, int32_t DestPort, const char * pcSrcHost, int32_t szSrcHost, int32_t SrcPort)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(6);
	zval * zSender;
	zval * zConnection;
	zval * zDestHost;
	zval * zDestPort;
	zval * zSrcHost;
	zval * zSrcPort;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zConnection, 1);
	SBInitObject(zConnection, TElSSHTunnelConnection_ce_ptr, Connection TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zDestHost, 2);
	SB_ZVAL_STRINGL_DUP(zDestHost, pcDestHost, szDestHost);
	SB_EVENT_INIT_ZVAL(zDestPort, 3);
	ZVAL_LONG(zDestPort, (sb_zend_long)DestPort);
	SB_EVENT_INIT_ZVAL(zSrcHost, 4);
	SB_ZVAL_STRINGL_DUP(zSrcHost, pcSrcHost, szSrcHost);
	SB_EVENT_INIT_ZVAL(zSrcPort, 5);
	ZVAL_LONG(zSrcPort, (sb_zend_long)SrcPort);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 6, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zConnection);
	SB_EVENT_CLEAR_ZVAL(zDestHost);
	SB_EVENT_CLEAR_ZVAL(zDestPort);
	SB_EVENT_CLEAR_ZVAL(zSrcHost);
	SB_EVENT_CLEAR_ZVAL(zSrcPort);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHOpenServerForwardingEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zConnection;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zConnection, 1);
	SBInitObject(zConnection, TElSSHTunnelConnection_ce_ptr, Connection TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zConnection);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHOpenX11ForwardingEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcOrigIP, int32_t szOrigIP, int32_t OrigPort)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zConnection;
	zval * zOrigIP;
	zval * zOrigPort;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zConnection, 1);
	SBInitObject(zConnection, TElSSHTunnelConnection_ce_ptr, Connection TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zOrigIP, 2);
	SB_ZVAL_STRINGL_DUP(zOrigIP, pcOrigIP, szOrigIP);
	SB_EVENT_INIT_ZVAL(zOrigPort, 3);
	ZVAL_LONG(zOrigPort, (sb_zend_long)OrigPort);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zConnection);
	SB_EVENT_CLEAR_ZVAL(zOrigIP);
	SB_EVENT_CLEAR_ZVAL(zOrigPort);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHServerForwardingFailedEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zData;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zData, 1);
	SBInitPointerObject(zData, Data TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zData);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHServerForwardingRequestEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcAddress, int32_t szAddress, int32_t Port, int8_t * Accept, int32_t * RealPort)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(5);
	zval * zSender;
	zval * zAddress;
	zval * zPort;
	zval * zAccept;
	zval * zRealPort;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zAddress, 1);
	SB_ZVAL_STRINGL_DUP(zAddress, pcAddress, szAddress);
	SB_EVENT_INIT_ZVAL(zPort, 2);
	ZVAL_LONG(zPort, (sb_zend_long)Port);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 3);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);
	SB_EVENT_INIT_ZVAL_REF(zRealPort, 4);
	ZVAL_LONG(Z_REFVAL_P(zRealPort), (sb_zend_long)*RealPort);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 5, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zAddress);
	SB_EVENT_CLEAR_ZVAL(zPort);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	convert_to_long(Z_REFVAL_P(zRealPort));
	*RealPort = (int32_t)Z_LVAL_P(Z_REFVAL_P(zRealPort));
	SB_EVENT_CLEAR_ZVAL(zRealPort);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHServerForwardingCancelEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcAddress, int32_t szAddress, int32_t Port)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zAddress;
	zval * zPort;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zAddress, 1);
	SB_ZVAL_STRINGL_DUP(zAddress, pcAddress, szAddress);
	SB_EVENT_INIT_ZVAL(zPort, 2);
	ZVAL_LONG(zPort, (sb_zend_long)Port);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zAddress);
	SB_EVENT_CLEAR_ZVAL(zPort);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHX11ForwardingRequestEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t SingleConnection, const char * pcAuthProtocol, int32_t szAuthProtocol, const char * pcAuthCookie, int32_t szAuthCookie, int32_t ScreenNumber, int8_t * Accept)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(6);
	zval * zSender;
	zval * zSingleConnection;
	zval * zAuthProtocol;
	zval * zAuthCookie;
	zval * zScreenNumber;
	zval * zAccept;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSingleConnection, 1);
	ZVAL_BOOL(zSingleConnection, (zend_bool)SingleConnection);
	SB_EVENT_INIT_ZVAL(zAuthProtocol, 2);
	SB_ZVAL_STRINGL_DUP(zAuthProtocol, pcAuthProtocol, szAuthProtocol);
	SB_EVENT_INIT_ZVAL(zAuthCookie, 3);
	SB_ZVAL_STRINGL_DUP(zAuthCookie, pcAuthCookie, szAuthCookie);
	SB_EVENT_INIT_ZVAL(zScreenNumber, 4);
	ZVAL_LONG(zScreenNumber, (sb_zend_long)ScreenNumber);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 5);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 6, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSingleConnection);
	SB_EVENT_CLEAR_ZVAL(zAuthProtocol);
	SB_EVENT_CLEAR_ZVAL(zAuthCookie);
	SB_EVENT_CLEAR_ZVAL(zScreenNumber);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHTerminalRequestEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, TElTerminalInfoHandle Info, int8_t * Accept)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zConnection;
	zval * zInfo;
	zval * zAccept;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zConnection, 1);
	SBInitObject(zConnection, TElSSHTunnelConnection_ce_ptr, Connection TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zInfo, 2);
	SBInitObject(zInfo, TElTerminalInfo_ce_ptr, Info TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zAccept, 3);
	ZVAL_BOOL(Z_REFVAL_P(zAccept), (zend_bool)*Accept);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zConnection);
	SB_EVENT_CLEAR_ZVAL(zInfo);
	convert_to_boolean(Z_REFVAL_P(zAccept));
	*Accept = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAccept));
	SB_EVENT_CLEAR_ZVAL(zAccept);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHEnvironmentVariableReceivedEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcVarName, int32_t szVarName, const char * pcVarValue, int32_t szVarValue)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zConnection;
	zval * zVarName;
	zval * zVarValue;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zConnection, 1);
	SBInitObject(zConnection, TElSSHTunnelConnection_ce_ptr, Connection TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zVarName, 2);
	SB_ZVAL_STRINGL_DUP(zVarName, pcVarName, szVarName);
	SB_EVENT_INIT_ZVAL(zVarValue, 3);
	SB_ZVAL_STRINGL_DUP(zVarValue, pcVarValue, szVarValue);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zConnection);
	SB_EVENT_CLEAR_ZVAL(zVarName);
	SB_EVENT_CLEAR_ZVAL(zVarValue);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSSHSpecialMessageEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t Code, void * Buffer, int32_t Size)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zCode;
	zval * zBuffer;
	zval * zSize;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCode, 1);
	ZVAL_LONG(zCode, (sb_zend_long)Code);
	SB_EVENT_INIT_ZVAL(zBuffer, 2);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSize, 3);
	ZVAL_LONG(zSize, (sb_zend_long)Size);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zCode);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zSize);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSBSSHBannerSendStage_ce_ptr = NULL;

zend_class_entry *TElSSHUser_ce_ptr = NULL;

SB_PHP_METHOD(TElSSHUser, GetData)
{
	int32_t l4SizeRaw;
	SBArrayZValInfo aiBuffer;
	uint32_t _err;
	zval *zaBuffer;
	zval *zl4Size;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaBuffer, &zl4Size) == SUCCESS) && Z_ISREF_P(zaBuffer) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaBuffer))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaBuffer)))) && Z_ISREF_P(zl4Size) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4Size))))
	{
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		l4SizeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4Size));
		_err = TElSSHUser_GetData(SBGetObjectHandle(getThis() TSRMLS_CC), aiBuffer.data, &aiBuffer.len, &l4SizeRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaBuffer, &aiBuffer TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(2044160758, 1, aiBuffer.data, &aiBuffer.len) TSRMLS_CC);
			((char *)aiBuffer.data)[aiBuffer.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiBuffer);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiBuffer, zaBuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4Size), (sb_zend_long)l4SizeRaw);
	}
	else
	{
		SBErrorExpectsArguments("(&array of byte|string, &integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHUser, SetData)
{
	sb_zend_long l4Size;
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaValue, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHUser_SetData(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len, (int32_t)l4Size) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHUser, SetBasePath)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSSHUser_SetBasePath(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHUser, SetSSHKey)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElSSHKey_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSHUser_SetSSHKey(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHKey)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHUser, AddUser_Inst)
{
	char *sBasePath;
	char *sPassword;
	char *sUserName;
	sb_str_size sBasePath_len;
	sb_str_size sPassword_len;
	sb_str_size sUserName_len;
	zval *oKey;
	zval *oUsers;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!ssO!", &oUsers, TElUsers_ce_ptr, &sUserName, &sUserName_len, &sPassword, &sPassword_len, &oKey, TElSSHKey_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSHUser_AddUser_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oUsers TSRMLS_CC), sUserName, (int32_t)sUserName_len, sPassword, (int32_t)sPassword_len, SBGetObjectHandle(oKey TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!ssO!s", &oUsers, TElUsers_ce_ptr, &sUserName, &sUserName_len, &sPassword, &sPassword_len, &oKey, TElSSHKey_ce_ptr, &sBasePath, &sBasePath_len) == SUCCESS)
	{
		SBCheckError(TElSSHUser_AddUser_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oUsers TSRMLS_CC), sUserName, (int32_t)sUserName_len, sPassword, (int32_t)sPassword_len, SBGetObjectHandle(oKey TSRMLS_CC), sBasePath, (int32_t)sBasePath_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElUsers, string, string, \\TElSSHKey) or (\\TElUsers, string, string, \\TElSSHKey, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHUser, AddUser)
{
	char *sBasePath;
	char *sPassword;
	char *sUserName;
	sb_str_size sBasePath_len;
	sb_str_size sPassword_len;
	sb_str_size sUserName_len;
	zval *oKey;
	zval *oUsers;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!ssO!", &oUsers, TElUsers_ce_ptr, &sUserName, &sUserName_len, &sPassword, &sPassword_len, &oKey, TElSSHKey_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSHUser_AddUser(SBGetObjectHandle(oUsers TSRMLS_CC), sUserName, (int32_t)sUserName_len, sPassword, (int32_t)sPassword_len, SBGetObjectHandle(oKey TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!ssO!s", &oUsers, TElUsers_ce_ptr, &sUserName, &sUserName_len, &sPassword, &sPassword_len, &oKey, TElSSHKey_ce_ptr, &sBasePath, &sBasePath_len) == SUCCESS)
	{
		SBCheckError(TElSSHUser_AddUser_2(SBGetObjectHandle(oUsers TSRMLS_CC), sUserName, (int32_t)sUserName_len, sPassword, (int32_t)sPassword_len, SBGetObjectHandle(oKey TSRMLS_CC), sBasePath, (int32_t)sBasePath_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElUsers, string, string, \\TElSSHKey) or (\\TElUsers, string, string, \\TElSSHKey, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHUser, IsValidSSHKey)
{
	zval *oKey;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oKey, TElSSHKey_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHUser_IsValidSSHKey(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oKey TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHKey)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHUser, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHUser_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHUser, get_SSHKey)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHUser_get_SSHKey(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSHKey_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHUser, set_SSHKey)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElSSHKey_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSHUser_set_SSHKey(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHKey)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHUser, get_BasePath)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSSHUser_get_BasePath(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(336649201, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHUser, set_BasePath)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSSHUser_set_BasePath(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHUser, __construct)
{
	char *sUserName;
	sb_str_size sUserName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sUserName, &sUserName_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHUser_Create(sUserName, (int32_t)sUserName_len, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHUser_GetData, 0, 0, 2)
	ZEND_ARG_INFO(1, Buffer)
	ZEND_ARG_INFO(1, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHUser_SetData, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHUser_SetBasePath, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHUser_SetSSHKey, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElSSHKey, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHUser_AddUser_Inst, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Users, TElUsers, 1)
	ZEND_ARG_INFO(0, UserName)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_OBJ_INFO(0, Key, TElSSHKey, 1)
	ZEND_ARG_INFO(0, BasePath)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHUser_AddUser, 0, 0, 4)
	ZEND_ARG_OBJ_INFO(0, Users, TElUsers, 1)
	ZEND_ARG_INFO(0, UserName)
	ZEND_ARG_INFO(0, Password)
	ZEND_ARG_OBJ_INFO(0, Key, TElSSHKey, 1)
	ZEND_ARG_INFO(0, BasePath)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHUser_IsValidSSHKey, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Key, TElSSHKey, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHUser_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHUser_get_SSHKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHUser_set_SSHKey, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElSSHKey, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHUser_get_BasePath, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHUser_set_BasePath, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHUser___construct, 0, 0, 1)
	ZEND_ARG_INFO(0, UserName)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSHUser_methods[] = {
	PHP_ME(TElSSHUser, GetData, arginfo_TElSSHUser_GetData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHUser, SetData, arginfo_TElSSHUser_SetData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHUser, SetBasePath, arginfo_TElSSHUser_SetBasePath, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHUser, SetSSHKey, arginfo_TElSSHUser_SetSSHKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHUser, AddUser_Inst, arginfo_TElSSHUser_AddUser_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHUser, AddUser, arginfo_TElSSHUser_AddUser, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElSSHUser, IsValidSSHKey, arginfo_TElSSHUser_IsValidSSHKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHUser, ClassType, arginfo_TElSSHUser_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElSSHUser, get_SSHKey, arginfo_TElSSHUser_get_SSHKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHUser, set_SSHKey, arginfo_TElSSHUser_set_SSHKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHUser, get_BasePath, arginfo_TElSSHUser_get_BasePath, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHUser, set_BasePath, arginfo_TElSSHUser_set_BasePath, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHUser, __construct, arginfo_TElSSHUser___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSHUser(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSHUser_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSHUser", TElSSHUser_methods);
	if (NULL == TElCustomUser_ce_ptr)
		Register_TElCustomUser(TSRMLS_C);
	TElSSHUser_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomUser_ce_ptr);
}

zend_class_entry *TElSSHServerTunnelConnection_ce_ptr = NULL;

SB_PHP_METHOD(TElSSHServerTunnelConnection, SendData)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHServerTunnelConnection_SendData(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServerTunnelConnection, SendExtendedData)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHServerTunnelConnection_SendExtendedData(SBGetObjectHandle(getThis() TSRMLS_CC), piBuffer.data, (int32_t)l4Size) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServerTunnelConnection, CanSend)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHServerTunnelConnection_CanSend(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServerTunnelConnection, GetWindowBufferLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHServerTunnelConnection_GetWindowBufferLength(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServerTunnelConnection, GetExtWindowBufferLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHServerTunnelConnection_GetExtWindowBufferLength(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServerTunnelConnection, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHServerTunnelConnection_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServerTunnelConnection_SendData, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServerTunnelConnection_SendExtendedData, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Buffer, 0, 1)
	ZEND_ARG_INFO(0, Size)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServerTunnelConnection_CanSend, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServerTunnelConnection_GetWindowBufferLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServerTunnelConnection_GetExtWindowBufferLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServerTunnelConnection___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSHServerTunnelConnection_methods[] = {
	PHP_ME(TElSSHServerTunnelConnection, SendData, arginfo_TElSSHServerTunnelConnection_SendData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServerTunnelConnection, SendExtendedData, arginfo_TElSSHServerTunnelConnection_SendExtendedData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServerTunnelConnection, CanSend, arginfo_TElSSHServerTunnelConnection_CanSend, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServerTunnelConnection, GetWindowBufferLength, arginfo_TElSSHServerTunnelConnection_GetWindowBufferLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServerTunnelConnection, GetExtWindowBufferLength, arginfo_TElSSHServerTunnelConnection_GetExtWindowBufferLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServerTunnelConnection, __construct, arginfo_TElSSHServerTunnelConnection___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSHServerTunnelConnection(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSHServerTunnelConnection_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSHServerTunnelConnection", TElSSHServerTunnelConnection_methods);
	if (NULL == TElSSHTunnelConnection_ce_ptr)
		Register_TElSSHTunnelConnection(TSRMLS_C);
	TElSSHServerTunnelConnection_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSSHTunnelConnection_ce_ptr);
}

zend_class_entry *TElSSHServerAdditionalSettings_ce_ptr = NULL;

SB_PHP_METHOD(TElSSHServerAdditionalSettings, get_OperationStatusCode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHServerAdditionalSettings_get_OperationStatusCode(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServerAdditionalSettings, set_OperationStatusCode)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSHServerAdditionalSettings_set_OperationStatusCode(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServerAdditionalSettings, get_OperationStatusString)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSSHServerAdditionalSettings_get_OperationStatusString(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-174126538, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServerAdditionalSettings, set_OperationStatusString)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSSHServerAdditionalSettings_set_OperationStatusString(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServerAdditionalSettings, get_UseKexHashAlgorithmForInnerHash)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHServerAdditionalSettings_get_UseKexHashAlgorithmForInnerHash(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServerAdditionalSettings, set_UseKexHashAlgorithmForInnerHash)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHServerAdditionalSettings_set_UseKexHashAlgorithmForInnerHash(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServerAdditionalSettings, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHServerAdditionalSettings_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServerAdditionalSettings_get_OperationStatusCode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServerAdditionalSettings_set_OperationStatusCode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServerAdditionalSettings_get_OperationStatusString, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServerAdditionalSettings_set_OperationStatusString, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServerAdditionalSettings_get_UseKexHashAlgorithmForInnerHash, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServerAdditionalSettings_set_UseKexHashAlgorithmForInnerHash, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServerAdditionalSettings___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSHServerAdditionalSettings_methods[] = {
	PHP_ME(TElSSHServerAdditionalSettings, get_OperationStatusCode, arginfo_TElSSHServerAdditionalSettings_get_OperationStatusCode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServerAdditionalSettings, set_OperationStatusCode, arginfo_TElSSHServerAdditionalSettings_set_OperationStatusCode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServerAdditionalSettings, get_OperationStatusString, arginfo_TElSSHServerAdditionalSettings_get_OperationStatusString, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServerAdditionalSettings, set_OperationStatusString, arginfo_TElSSHServerAdditionalSettings_set_OperationStatusString, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServerAdditionalSettings, get_UseKexHashAlgorithmForInnerHash, arginfo_TElSSHServerAdditionalSettings_get_UseKexHashAlgorithmForInnerHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServerAdditionalSettings, set_UseKexHashAlgorithmForInnerHash, arginfo_TElSSHServerAdditionalSettings_set_UseKexHashAlgorithmForInnerHash, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServerAdditionalSettings, __construct, arginfo_TElSSHServerAdditionalSettings___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSHServerAdditionalSettings(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSHServerAdditionalSettings_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSHServerAdditionalSettings", TElSSHServerAdditionalSettings_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSSHServerAdditionalSettings_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSSHServer_ce_ptr = NULL;

SB_PHP_METHOD(TElSSHServer, Open)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSSHServer_Open(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, OpenServerForwarding)
{
	char *sAddress;
	char *sSrcHost;
	sb_str_size sAddress_len;
	sb_str_size sSrcHost_len;
	sb_zend_long l4Port;
	sb_zend_long l4SrcPort;
	SBArrayZValInfo piData;
	zval *zpData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "slslz", &sAddress, &sAddress_len, &l4Port, &sSrcHost, &sSrcHost_len, &l4SrcPort, &zpData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpData) || SB_IS_ARRAY_TYPE_RP(zpData) || SB_IS_NULL_TYPE_RP(zpData) || (SB_IS_OBJECT_TYPE_RP(zpData) && (Z_OBJCE_P(zpData) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpData, &piData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHServer_OpenServerForwarding(SBGetObjectHandle(getThis() TSRMLS_CC), sAddress, (int32_t)sAddress_len, (int32_t)l4Port, sSrcHost, (int32_t)sSrcHost_len, (int32_t)l4SrcPort, piData.data) TSRMLS_CC);
		SBFreePointerZValInfo(&piData);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer, string, integer, \\TSBPointer|array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, OpenX11Forwarding)
{
	char *sOrigHost;
	sb_str_size sOrigHost_len;
	sb_zend_long l4OrigPort;
	SBArrayZValInfo piData;
	zval *zpData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "slz", &sOrigHost, &sOrigHost_len, &l4OrigPort, &zpData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpData) || SB_IS_ARRAY_TYPE_RP(zpData) || SB_IS_NULL_TYPE_RP(zpData) || (SB_IS_OBJECT_TYPE_RP(zpData) && (Z_OBJCE_P(zpData) == TSBPointer_ce_ptr))))
	{
		if (!SBGetPointerFromZVal(zpData, &piData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHServer_OpenX11Forwarding(SBGetObjectHandle(getThis() TSRMLS_CC), sOrigHost, (int32_t)sOrigHost_len, (int32_t)l4OrigPort, piData.data) TSRMLS_CC);
		SBFreePointerZValInfo(&piData);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer, \\TSBPointer|array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, DataAvailable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSSHServer_DataAvailable(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, RenegotiateCiphers)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSSHServer_RenegotiateCiphers(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, Close)
{
	char *sReason;
	sb_str_size sReason_len;
	sb_zend_long l4ErrorCode;
	zend_bool bForced;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bForced) == SUCCESS)
	{
		SBCheckError(TElSSHServer_Close(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bForced) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ls", &l4ErrorCode, &sReason, &sReason_len) == SUCCESS)
	{
		SBCheckError(TElSSHServer_Close_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4ErrorCode, sReason, (int32_t)sReason_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool) or (integer, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_ClientCloseReason)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSSHServer_get_ClientCloseReason(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1195811431, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_Username)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSSHServer_get_Username(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1229872270, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_ChangePwdPrompt)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSSHServer_get_ChangePwdPrompt(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(473760028, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_ChangePwdPrompt)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSHServer_set_ChangePwdPrompt(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_AuthTypePriorities)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHServer_get_AuthTypePriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_AuthTypePriorities)
{
	sb_zend_long l4Index;
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4Index, &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSHServer_set_AuthTypePriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_DefaultWindowSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHServer_get_DefaultWindowSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_DefaultWindowSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSHServer_set_DefaultWindowSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_MinWindowSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSHServer_get_MinWindowSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_MinWindowSize)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSHServer_set_MinWindowSize(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_AdditionalSettings)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHServer_get_AdditionalSettings(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSHServerAdditionalSettings_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_ClientSoftwareName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSSHServer_get_ClientSoftwareName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1938576961, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_AllowedSubsystems)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHServer_get_AllowedSubsystems(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_KexKeyStorage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHServer_get_KexKeyStorage(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSHCustomKeyStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_KexKeyStorage)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElSSHCustomKeyStorage_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSHServer_set_KexKeyStorage(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSHCustomKeyStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_ThreadSafe)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSHServer_get_ThreadSafe(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_ThreadSafe)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElSSHServer_set_ThreadSafe(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_BannerSendStage)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSSHBannerSendStageRaw fOutResultRaw = 0;
		SBCheckError(TElSSHServer_get_BannerSendStage(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_BannerSendStage)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSSHServer_set_BannerSendStage(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSSHBannerSendStageRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_SSHAuthOrder)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSSHAuthOrderRaw fOutResultRaw = 0;
		SBCheckError(TElSSHServer_get_SSHAuthOrder(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_SSHAuthOrder)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSSHServer_set_SSHAuthOrder(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSSHAuthOrderRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnAuthAttempt)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHAuthAttemptEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnAuthAttempt(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnAuthAttempt)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnAuthAttempt(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHAuthAttemptEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHAuthAttemptEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnAuthFailed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHAuthenticationFailedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnAuthFailed(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnAuthFailed)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnAuthFailed(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHAuthenticationFailedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHAuthenticationFailedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnAuthBanner)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHAuthBannerEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnAuthBanner(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnAuthBanner)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnAuthBanner(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHAuthBannerEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHAuthBannerEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnAuthPassword)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHAuthPasswordEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnAuthPassword(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnAuthPassword)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnAuthPassword(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHAuthPasswordEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHAuthPasswordEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnAuthPasswordChange)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHAuthPasswordChangeEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnAuthPasswordChange(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnAuthPasswordChange)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnAuthPasswordChange(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHAuthPasswordChangeEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHAuthPasswordChangeEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnAuthPublicKey)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHAuthPublicKeyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnAuthPublicKey(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnAuthPublicKey)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnAuthPublicKey(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHAuthPublicKeyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHAuthPublicKeyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnAuthHostbased)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHAuthHostbasedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnAuthHostbased(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnAuthHostbased)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnAuthHostbased(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHAuthHostbasedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHAuthHostbasedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnAuthKeyboard)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHAuthKeyboardEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnAuthKeyboard(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnAuthKeyboard)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnAuthKeyboard(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHAuthKeyboardEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHAuthKeyboardEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnAuthKeyboardResponse)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHAuthKeyboardResponseEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnAuthKeyboardResponse(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnAuthKeyboardResponse)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnAuthKeyboardResponse(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHAuthKeyboardResponseEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHAuthKeyboardResponseEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnFurtherAuthNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHFurtherAuthNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnFurtherAuthNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnFurtherAuthNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnFurtherAuthNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHFurtherAuthNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHFurtherAuthNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnBeforeOpenSession)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHBeforeOpenSessionEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnBeforeOpenSession(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnBeforeOpenSession)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnBeforeOpenSession(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHBeforeOpenSessionEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHBeforeOpenSessionEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnBeforeOpenShell)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHBeforeOpenShellEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnBeforeOpenShell(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnBeforeOpenShell)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnBeforeOpenShell(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHBeforeOpenShellEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHBeforeOpenShellEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnBeforeOpenCommand)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHBeforeOpenCommandEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnBeforeOpenCommand(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnBeforeOpenCommand)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnBeforeOpenCommand(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHBeforeOpenCommandEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHBeforeOpenCommandEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnBeforeOpenSubsystem)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHBeforeOpenSubsystemEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnBeforeOpenSubsystem(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnBeforeOpenSubsystem)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnBeforeOpenSubsystem(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHBeforeOpenSubsystemEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHBeforeOpenSubsystemEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnBeforeOpenClientForwarding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHBeforeOpenClientForwardingEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnBeforeOpenClientForwarding(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnBeforeOpenClientForwarding)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnBeforeOpenClientForwarding(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHBeforeOpenClientForwardingEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHBeforeOpenClientForwardingEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnBeforeOpenX11Forwarding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHBeforeOpenX11ForwardingEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnBeforeOpenX11Forwarding(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnBeforeOpenX11Forwarding)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnBeforeOpenX11Forwarding(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHBeforeOpenX11ForwardingEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHBeforeOpenX11ForwardingEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnOpenSession)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHOpenSessionEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnOpenSession(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnOpenSession)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnOpenSession(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHOpenSessionEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHOpenSessionEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnOpenShell)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHOpenShellEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnOpenShell(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnOpenShell)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnOpenShell(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHOpenShellEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHOpenShellEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnOpenCommand)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHOpenCommandEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnOpenCommand(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnOpenCommand)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnOpenCommand(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHOpenCommandEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHOpenCommandEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnOpenSubsystem)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHOpenSubsystemEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnOpenSubsystem(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnOpenSubsystem)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnOpenSubsystem(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHOpenSubsystemEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHOpenSubsystemEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnOpenClientForwarding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHOpenClientForwardingEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnOpenClientForwarding(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnOpenClientForwarding)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnOpenClientForwarding(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHOpenClientForwardingEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHOpenClientForwardingEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnOpenServerForwarding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHOpenServerForwardingEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnOpenServerForwarding(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnOpenServerForwarding)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnOpenServerForwarding(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHOpenServerForwardingEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHOpenServerForwardingEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnOpenX11Forwarding)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHOpenX11ForwardingEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnOpenX11Forwarding(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnOpenX11Forwarding)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnOpenX11Forwarding(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHOpenX11ForwardingEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHOpenX11ForwardingEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnServerForwardingFailed)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHServerForwardingFailedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnServerForwardingFailed(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnServerForwardingFailed)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnServerForwardingFailed(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHServerForwardingFailedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHServerForwardingFailedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnServerForwardingRequest)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHServerForwardingRequestEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnServerForwardingRequest(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnServerForwardingRequest)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnServerForwardingRequest(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHServerForwardingRequestEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHServerForwardingRequestEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnServerForwardingCancel)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHServerForwardingCancelEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnServerForwardingCancel(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnServerForwardingCancel)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnServerForwardingCancel(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHServerForwardingCancelEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHServerForwardingCancelEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnX11ForwardingRequest)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHX11ForwardingRequestEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnX11ForwardingRequest(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnX11ForwardingRequest)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnX11ForwardingRequest(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHX11ForwardingRequestEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHX11ForwardingRequestEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnTerminalRequest)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHTerminalRequestEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnTerminalRequest(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnTerminalRequest)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnTerminalRequest(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHTerminalRequestEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHTerminalRequestEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnSpecialMessageReceived)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHSpecialMessageEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnSpecialMessageReceived(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnSpecialMessageReceived)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnSpecialMessageReceived(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHSpecialMessageEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHSpecialMessageEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, get_OnEnvironmentVariableReceived)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSHEnvironmentVariableReceivedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSHServer_get_OnEnvironmentVariableReceived(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, set_OnEnvironmentVariableReceived)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSHServer_set_OnEnvironmentVariableReceived(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSSHEnvironmentVariableReceivedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSSHEnvironmentVariableReceivedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSHServer, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSHServer_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_Open, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_OpenServerForwarding, 0, 0, 5)
	ZEND_ARG_INFO(0, Address)
	ZEND_ARG_INFO(0, Port)
	ZEND_ARG_INFO(0, SrcHost)
	ZEND_ARG_INFO(0, SrcPort)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_OpenX11Forwarding, 0, 0, 3)
	ZEND_ARG_INFO(0, OrigHost)
	ZEND_ARG_INFO(0, OrigPort)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_DataAvailable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_RenegotiateCiphers, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_Close, 0, 0, 1)
	ZEND_ARG_INFO(0, Forced_or_ErrorCode)
	ZEND_ARG_INFO(0, Reason)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_ClientCloseReason, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_Username, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_ChangePwdPrompt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_ChangePwdPrompt, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_AuthTypePriorities, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_AuthTypePriorities, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_DefaultWindowSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_DefaultWindowSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_MinWindowSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_MinWindowSize, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_AdditionalSettings, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_ClientSoftwareName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_AllowedSubsystems, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_KexKeyStorage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_KexKeyStorage, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElSSHCustomKeyStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_ThreadSafe, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_ThreadSafe, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_BannerSendStage, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_BannerSendStage, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_SSHAuthOrder, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_SSHAuthOrder, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnAuthAttempt, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnAuthAttempt, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnAuthFailed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnAuthFailed, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnAuthBanner, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnAuthBanner, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnAuthPassword, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnAuthPassword, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnAuthPasswordChange, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnAuthPasswordChange, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnAuthPublicKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnAuthPublicKey, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnAuthHostbased, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnAuthHostbased, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnAuthKeyboard, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnAuthKeyboard, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnAuthKeyboardResponse, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnAuthKeyboardResponse, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnFurtherAuthNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnFurtherAuthNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnBeforeOpenSession, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnBeforeOpenSession, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnBeforeOpenShell, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnBeforeOpenShell, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnBeforeOpenCommand, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnBeforeOpenCommand, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnBeforeOpenSubsystem, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnBeforeOpenSubsystem, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnBeforeOpenClientForwarding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnBeforeOpenClientForwarding, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnBeforeOpenX11Forwarding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnBeforeOpenX11Forwarding, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnOpenSession, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnOpenSession, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnOpenShell, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnOpenShell, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnOpenCommand, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnOpenCommand, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnOpenSubsystem, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnOpenSubsystem, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnOpenClientForwarding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnOpenClientForwarding, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnOpenServerForwarding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnOpenServerForwarding, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnOpenX11Forwarding, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnOpenX11Forwarding, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnServerForwardingFailed, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnServerForwardingFailed, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnServerForwardingRequest, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnServerForwardingRequest, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnServerForwardingCancel, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnServerForwardingCancel, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnX11ForwardingRequest, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnX11ForwardingRequest, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnTerminalRequest, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnTerminalRequest, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnSpecialMessageReceived, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnSpecialMessageReceived, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_get_OnEnvironmentVariableReceived, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer_set_OnEnvironmentVariableReceived, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSHServer___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSHServer_methods[] = {
	PHP_ME(TElSSHServer, Open, arginfo_TElSSHServer_Open, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, OpenServerForwarding, arginfo_TElSSHServer_OpenServerForwarding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, OpenX11Forwarding, arginfo_TElSSHServer_OpenX11Forwarding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, DataAvailable, arginfo_TElSSHServer_DataAvailable, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, RenegotiateCiphers, arginfo_TElSSHServer_RenegotiateCiphers, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, Close, arginfo_TElSSHServer_Close, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_ClientCloseReason, arginfo_TElSSHServer_get_ClientCloseReason, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_Username, arginfo_TElSSHServer_get_Username, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_ChangePwdPrompt, arginfo_TElSSHServer_get_ChangePwdPrompt, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_ChangePwdPrompt, arginfo_TElSSHServer_set_ChangePwdPrompt, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_AuthTypePriorities, arginfo_TElSSHServer_get_AuthTypePriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_AuthTypePriorities, arginfo_TElSSHServer_set_AuthTypePriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_DefaultWindowSize, arginfo_TElSSHServer_get_DefaultWindowSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_DefaultWindowSize, arginfo_TElSSHServer_set_DefaultWindowSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_MinWindowSize, arginfo_TElSSHServer_get_MinWindowSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_MinWindowSize, arginfo_TElSSHServer_set_MinWindowSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_AdditionalSettings, arginfo_TElSSHServer_get_AdditionalSettings, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_ClientSoftwareName, arginfo_TElSSHServer_get_ClientSoftwareName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_AllowedSubsystems, arginfo_TElSSHServer_get_AllowedSubsystems, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_KexKeyStorage, arginfo_TElSSHServer_get_KexKeyStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_KexKeyStorage, arginfo_TElSSHServer_set_KexKeyStorage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_ThreadSafe, arginfo_TElSSHServer_get_ThreadSafe, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_ThreadSafe, arginfo_TElSSHServer_set_ThreadSafe, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_BannerSendStage, arginfo_TElSSHServer_get_BannerSendStage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_BannerSendStage, arginfo_TElSSHServer_set_BannerSendStage, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_SSHAuthOrder, arginfo_TElSSHServer_get_SSHAuthOrder, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_SSHAuthOrder, arginfo_TElSSHServer_set_SSHAuthOrder, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnAuthAttempt, arginfo_TElSSHServer_get_OnAuthAttempt, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnAuthAttempt, arginfo_TElSSHServer_set_OnAuthAttempt, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnAuthFailed, arginfo_TElSSHServer_get_OnAuthFailed, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnAuthFailed, arginfo_TElSSHServer_set_OnAuthFailed, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnAuthBanner, arginfo_TElSSHServer_get_OnAuthBanner, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnAuthBanner, arginfo_TElSSHServer_set_OnAuthBanner, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnAuthPassword, arginfo_TElSSHServer_get_OnAuthPassword, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnAuthPassword, arginfo_TElSSHServer_set_OnAuthPassword, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnAuthPasswordChange, arginfo_TElSSHServer_get_OnAuthPasswordChange, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnAuthPasswordChange, arginfo_TElSSHServer_set_OnAuthPasswordChange, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnAuthPublicKey, arginfo_TElSSHServer_get_OnAuthPublicKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnAuthPublicKey, arginfo_TElSSHServer_set_OnAuthPublicKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnAuthHostbased, arginfo_TElSSHServer_get_OnAuthHostbased, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnAuthHostbased, arginfo_TElSSHServer_set_OnAuthHostbased, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnAuthKeyboard, arginfo_TElSSHServer_get_OnAuthKeyboard, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnAuthKeyboard, arginfo_TElSSHServer_set_OnAuthKeyboard, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnAuthKeyboardResponse, arginfo_TElSSHServer_get_OnAuthKeyboardResponse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnAuthKeyboardResponse, arginfo_TElSSHServer_set_OnAuthKeyboardResponse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnFurtherAuthNeeded, arginfo_TElSSHServer_get_OnFurtherAuthNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnFurtherAuthNeeded, arginfo_TElSSHServer_set_OnFurtherAuthNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnBeforeOpenSession, arginfo_TElSSHServer_get_OnBeforeOpenSession, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnBeforeOpenSession, arginfo_TElSSHServer_set_OnBeforeOpenSession, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnBeforeOpenShell, arginfo_TElSSHServer_get_OnBeforeOpenShell, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnBeforeOpenShell, arginfo_TElSSHServer_set_OnBeforeOpenShell, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnBeforeOpenCommand, arginfo_TElSSHServer_get_OnBeforeOpenCommand, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnBeforeOpenCommand, arginfo_TElSSHServer_set_OnBeforeOpenCommand, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnBeforeOpenSubsystem, arginfo_TElSSHServer_get_OnBeforeOpenSubsystem, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnBeforeOpenSubsystem, arginfo_TElSSHServer_set_OnBeforeOpenSubsystem, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnBeforeOpenClientForwarding, arginfo_TElSSHServer_get_OnBeforeOpenClientForwarding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnBeforeOpenClientForwarding, arginfo_TElSSHServer_set_OnBeforeOpenClientForwarding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnBeforeOpenX11Forwarding, arginfo_TElSSHServer_get_OnBeforeOpenX11Forwarding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnBeforeOpenX11Forwarding, arginfo_TElSSHServer_set_OnBeforeOpenX11Forwarding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnOpenSession, arginfo_TElSSHServer_get_OnOpenSession, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnOpenSession, arginfo_TElSSHServer_set_OnOpenSession, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnOpenShell, arginfo_TElSSHServer_get_OnOpenShell, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnOpenShell, arginfo_TElSSHServer_set_OnOpenShell, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnOpenCommand, arginfo_TElSSHServer_get_OnOpenCommand, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnOpenCommand, arginfo_TElSSHServer_set_OnOpenCommand, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnOpenSubsystem, arginfo_TElSSHServer_get_OnOpenSubsystem, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnOpenSubsystem, arginfo_TElSSHServer_set_OnOpenSubsystem, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnOpenClientForwarding, arginfo_TElSSHServer_get_OnOpenClientForwarding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnOpenClientForwarding, arginfo_TElSSHServer_set_OnOpenClientForwarding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnOpenServerForwarding, arginfo_TElSSHServer_get_OnOpenServerForwarding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnOpenServerForwarding, arginfo_TElSSHServer_set_OnOpenServerForwarding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnOpenX11Forwarding, arginfo_TElSSHServer_get_OnOpenX11Forwarding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnOpenX11Forwarding, arginfo_TElSSHServer_set_OnOpenX11Forwarding, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnServerForwardingFailed, arginfo_TElSSHServer_get_OnServerForwardingFailed, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnServerForwardingFailed, arginfo_TElSSHServer_set_OnServerForwardingFailed, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnServerForwardingRequest, arginfo_TElSSHServer_get_OnServerForwardingRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnServerForwardingRequest, arginfo_TElSSHServer_set_OnServerForwardingRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnServerForwardingCancel, arginfo_TElSSHServer_get_OnServerForwardingCancel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnServerForwardingCancel, arginfo_TElSSHServer_set_OnServerForwardingCancel, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnX11ForwardingRequest, arginfo_TElSSHServer_get_OnX11ForwardingRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnX11ForwardingRequest, arginfo_TElSSHServer_set_OnX11ForwardingRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnTerminalRequest, arginfo_TElSSHServer_get_OnTerminalRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnTerminalRequest, arginfo_TElSSHServer_set_OnTerminalRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnSpecialMessageReceived, arginfo_TElSSHServer_get_OnSpecialMessageReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnSpecialMessageReceived, arginfo_TElSSHServer_set_OnSpecialMessageReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, get_OnEnvironmentVariableReceived, arginfo_TElSSHServer_get_OnEnvironmentVariableReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, set_OnEnvironmentVariableReceived, arginfo_TElSSHServer_set_OnEnvironmentVariableReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSHServer, __construct, arginfo_TElSSHServer___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSHServer(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSHServer_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSHServer", TElSSHServer_methods);
	if (NULL == TElSSHClass_ce_ptr)
		Register_TElSSHClass(TSRMLS_C);
	TElSSHServer_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSSHClass_ce_ptr);
}

void Register_SBSSHServer_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSSHServerState", NULL);
	TSSHServerState_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSSHServerState_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSSHServerState_ce_ptr, "ssBefore", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSSHServerState_ce_ptr, "ssIdentificationLineSent", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSSHServerState_ce_ptr, "ssIdentificationLineReceived", 2)
	
	INIT_CLASS_ENTRY(ce, "TSSHServerProtService", NULL);
	TSSHServerProtService_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSSHServerProtService_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSSHServerProtService_ce_ptr, "spsNone", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSSHServerProtService_ce_ptr, "spsAuth", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSSHServerProtService_ce_ptr, "spsConn", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBSSHBannerSendStage", NULL);
	TSBSSHBannerSendStage_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSSHBannerSendStage_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSSHBannerSendStage_ce_ptr, "bssBeforeAuth", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSHBannerSendStage_ce_ptr, "bssAfterSuccess", 1)
}

void Register_SBSSHServer_Aliases(TSRMLS_D)
{
	if (NULL == TElSSHServerTunnelConnection_ce_ptr)
		Register_TElSSHServerTunnelConnection(TSRMLS_C);
	zend_register_class_alias("ElSSHServerTunnelConnection", TElSSHServerTunnelConnection_ce_ptr);
	if (NULL == TElSSHServer_ce_ptr)
		Register_TElSSHServer(TSRMLS_C);
	zend_register_class_alias("ElSSHServer", TElSSHServer_ce_ptr);
}

