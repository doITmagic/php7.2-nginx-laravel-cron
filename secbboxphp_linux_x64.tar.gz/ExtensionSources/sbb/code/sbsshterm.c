#include "sbsshterm.h"

void SB_CALLBACK TSBTerminalChangeNotificationEventRaw(void * _ObjectData, TObjectHandle Sender)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(1);
	zval * zSender;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 1, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

SB_PHP_METHOD(TSBChangeNotification, __construct)
{
	if (ZEND_NUM_ARGS() == 0)
	{
		php_sbb_struct * intern = Z_SBSTRUCT_P(getThis());
		intern->data = emalloc(sizeof(TSBChangeNotification));
		intern->len = sizeof(TSBChangeNotification);
		memset(intern->data, 0, sizeof(TSBChangeNotification));
		intern->ownData = 1;
	}
	else
		ZEND_WRONG_PARAM_COUNT();
}

SB_PHP_METHOD(TSBChangeNotification, getSizeOf)
{
	if (ZEND_NUM_ARGS() > 0)
		ZEND_WRONG_PARAM_COUNT();

	RETURN_LONG(sizeof(TSBChangeNotification));
}

zend_class_entry *TSBChangeNotification_ce_ptr = NULL;

static zend_function_entry TSBChangeNotification_methods[] = {
	PHP_ME(TSBChangeNotification, __construct, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(TSBChangeNotification, getSizeOf, NULL, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TSBChangeNotification(TSRMLS_D)
{
	zend_class_entry ce;
	if (TSBChangeNotification_ce_ptr != NULL)
		return;
	INIT_CLASS_ENTRY(ce, "TSBChangeNotification", TSBChangeNotification_methods);
	TSBChangeNotification_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseStruct_ce_ptr);
}

zend_class_entry *TElTerminalInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElTerminalInfo, GetTerminalType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElTerminalInfo_GetTerminalType(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(659168158, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, SetTerminalType)
{
	char *sAValue;
	sb_str_size sAValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAValue, &sAValue_len) == SUCCESS)
	{
		SBCheckError(TElTerminalInfo_SetTerminalType(SBGetObjectHandle(getThis() TSRMLS_CC), sAValue, (int32_t)sAValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, SetDefaultOpcodes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElTerminalInfo_SetDefaultOpcodes(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, AddChangeNotification)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElTerminalInfo_AddChangeNotification(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBTerminalChangeNotificationEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBTerminalChangeNotificationEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, RemoveChangeNotification)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElTerminalInfo_RemoveChangeNotification(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBTerminalChangeNotificationEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBTerminalChangeNotificationEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, BeginUpdate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElTerminalInfo_BeginUpdate(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, EndUpdate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElTerminalInfo_EndUpdate(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, ClearOpcodes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElTerminalInfo_ClearOpcodes(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, get_Opcodes)
{
	sb_zend_long l1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l1Index) == SUCCESS)
	{
		int16_t l2OutResultRaw = 0;
		SBCheckError(TElTerminalInfo_get_Opcodes(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)l1Index, &l2OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, set_Opcodes)
{
	sb_zend_long l1Index;
	sb_zend_long l2Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l1Index, &l2Value) == SUCCESS)
	{
		SBCheckError(TElTerminalInfo_set_Opcodes(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)l1Index, (int16_t)l2Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, get_TerminalType)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElTerminalInfo_get_TerminalType(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(832209224, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, set_TerminalType)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElTerminalInfo_set_TerminalType(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, get_Cols)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElTerminalInfo_get_Cols(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, set_Cols)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElTerminalInfo_set_Cols(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, get_Width)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElTerminalInfo_get_Width(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, set_Width)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElTerminalInfo_set_Width(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, get_Rows)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElTerminalInfo_get_Rows(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, set_Rows)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElTerminalInfo_set_Rows(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, get_Height)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElTerminalInfo_get_Height(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, set_Height)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElTerminalInfo_set_Height(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTerminalInfo, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElTerminalInfo_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_GetTerminalType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_SetTerminalType, 0, 0, 1)
	ZEND_ARG_INFO(0, AValue)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_SetDefaultOpcodes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_AddChangeNotification, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_RemoveChangeNotification, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_BeginUpdate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_EndUpdate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_ClearOpcodes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_get_Opcodes, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_set_Opcodes, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_get_TerminalType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_set_TerminalType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_get_Cols, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_set_Cols, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_get_Width, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_set_Width, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_get_Rows, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_set_Rows, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_get_Height, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo_set_Height, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTerminalInfo___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElTerminalInfo_methods[] = {
	PHP_ME(TElTerminalInfo, GetTerminalType, arginfo_TElTerminalInfo_GetTerminalType, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, SetTerminalType, arginfo_TElTerminalInfo_SetTerminalType, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, SetDefaultOpcodes, arginfo_TElTerminalInfo_SetDefaultOpcodes, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, AddChangeNotification, arginfo_TElTerminalInfo_AddChangeNotification, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, RemoveChangeNotification, arginfo_TElTerminalInfo_RemoveChangeNotification, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, BeginUpdate, arginfo_TElTerminalInfo_BeginUpdate, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, EndUpdate, arginfo_TElTerminalInfo_EndUpdate, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, ClearOpcodes, arginfo_TElTerminalInfo_ClearOpcodes, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, get_Opcodes, arginfo_TElTerminalInfo_get_Opcodes, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, set_Opcodes, arginfo_TElTerminalInfo_set_Opcodes, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, get_TerminalType, arginfo_TElTerminalInfo_get_TerminalType, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, set_TerminalType, arginfo_TElTerminalInfo_set_TerminalType, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, get_Cols, arginfo_TElTerminalInfo_get_Cols, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, set_Cols, arginfo_TElTerminalInfo_set_Cols, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, get_Width, arginfo_TElTerminalInfo_get_Width, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, set_Width, arginfo_TElTerminalInfo_set_Width, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, get_Rows, arginfo_TElTerminalInfo_get_Rows, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, set_Rows, arginfo_TElTerminalInfo_set_Rows, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, get_Height, arginfo_TElTerminalInfo_get_Height, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, set_Height, arginfo_TElTerminalInfo_set_Height, ZEND_ACC_PUBLIC)
	PHP_ME(TElTerminalInfo, __construct, arginfo_TElTerminalInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElTerminalInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElTerminalInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElTerminalInfo", TElTerminalInfo_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElTerminalInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

void Register_SBSSHTerm_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_FIRST, SB_OPCODE_FIRST, SB_OPCODE_FIRST);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VINTR, SB_OPCODE_VINTR, SB_OPCODE_VINTR);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VQUIT, SB_OPCODE_VQUIT, SB_OPCODE_VQUIT);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VERASE, SB_OPCODE_VERASE, SB_OPCODE_VERASE);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VKILL, SB_OPCODE_VKILL, SB_OPCODE_VKILL);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VEOF, SB_OPCODE_VEOF, SB_OPCODE_VEOF);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VEOL, SB_OPCODE_VEOL, SB_OPCODE_VEOL);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VEOL2, SB_OPCODE_VEOL2, SB_OPCODE_VEOL2);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VSTART, SB_OPCODE_VSTART, SB_OPCODE_VSTART);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VSTOP, SB_OPCODE_VSTOP, SB_OPCODE_VSTOP);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VSUSP, SB_OPCODE_VSUSP, SB_OPCODE_VSUSP);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VDSUSP, SB_OPCODE_VDSUSP, SB_OPCODE_VDSUSP);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VREPRINT, SB_OPCODE_VREPRINT, SB_OPCODE_VREPRINT);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VWERASE, SB_OPCODE_VWERASE, SB_OPCODE_VWERASE);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VLNEXT, SB_OPCODE_VLNEXT, SB_OPCODE_VLNEXT);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VFLUSH, SB_OPCODE_VFLUSH, SB_OPCODE_VFLUSH);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VSWTCH, SB_OPCODE_VSWTCH, SB_OPCODE_VSWTCH);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VSTATUS, SB_OPCODE_VSTATUS, SB_OPCODE_VSTATUS);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_VDISCARD, SB_OPCODE_VDISCARD, SB_OPCODE_VDISCARD);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_IGNPAR, SB_OPCODE_IGNPAR, SB_OPCODE_IGNPAR);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_PARMRK, SB_OPCODE_PARMRK, SB_OPCODE_PARMRK);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_INPCK, SB_OPCODE_INPCK, SB_OPCODE_INPCK);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_ISTRIP, SB_OPCODE_ISTRIP, SB_OPCODE_ISTRIP);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_INLCR, SB_OPCODE_INLCR, SB_OPCODE_INLCR);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_IGNCR, SB_OPCODE_IGNCR, SB_OPCODE_IGNCR);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_CRNL, SB_OPCODE_CRNL, SB_OPCODE_CRNL);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_IUCLC, SB_OPCODE_IUCLC, SB_OPCODE_IUCLC);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_IXON, SB_OPCODE_IXON, SB_OPCODE_IXON);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_IXANY, SB_OPCODE_IXANY, SB_OPCODE_IXANY);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_IXOFF, SB_OPCODE_IXOFF, SB_OPCODE_IXOFF);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_IMAXBEL, SB_OPCODE_IMAXBEL, SB_OPCODE_IMAXBEL);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_ISIG, SB_OPCODE_ISIG, SB_OPCODE_ISIG);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_ICANON, SB_OPCODE_ICANON, SB_OPCODE_ICANON);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_XCASE, SB_OPCODE_XCASE, SB_OPCODE_XCASE);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_ECHO, SB_OPCODE_ECHO, SB_OPCODE_ECHO);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_ECHOE, SB_OPCODE_ECHOE, SB_OPCODE_ECHOE);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_ECHOK, SB_OPCODE_ECHOK, SB_OPCODE_ECHOK);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_ECHONL, SB_OPCODE_ECHONL, SB_OPCODE_ECHONL);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_NOFLSH, SB_OPCODE_NOFLSH, SB_OPCODE_NOFLSH);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_TOSTOP, SB_OPCODE_TOSTOP, SB_OPCODE_TOSTOP);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_IEXTEN, SB_OPCODE_IEXTEN, SB_OPCODE_IEXTEN);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_ECHOCTL, SB_OPCODE_ECHOCTL, SB_OPCODE_ECHOCTL);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_ECHOKE, SB_OPCODE_ECHOKE, SB_OPCODE_ECHOKE);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_PENDIN, SB_OPCODE_PENDIN, SB_OPCODE_PENDIN);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_OPOST, SB_OPCODE_OPOST, SB_OPCODE_OPOST);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_OLCUC, SB_OPCODE_OLCUC, SB_OPCODE_OLCUC);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_ONLCR, SB_OPCODE_ONLCR, SB_OPCODE_ONLCR);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_OCRNL, SB_OPCODE_OCRNL, SB_OPCODE_OCRNL);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_ONOCR, SB_OPCODE_ONOCR, SB_OPCODE_ONOCR);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_ONLRET, SB_OPCODE_ONLRET, SB_OPCODE_ONLRET);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_CS7, SB_OPCODE_CS7, SB_OPCODE_CS7);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_CS8, SB_OPCODE_CS8, SB_OPCODE_CS8);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_PARENB, SB_OPCODE_PARENB, SB_OPCODE_PARENB);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_PARODD, SB_OPCODE_PARODD, SB_OPCODE_PARODD);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_LAST_DEFINED, SB_OPCODE_LAST_DEFINED, SB_OPCODE_LAST_DEFINED);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_LAST, SB_OPCODE_LAST, SB_OPCODE_LAST);
	SB_REGISTER_LONG_CONSTANT(SBSSHTerm, OPCODE_NOT_SPECIFIED, SB_OPCODE_NOT_SPECIFIED, SB_OPCODE_NOT_SPECIFIED);
}

void Register_SBSSHTerm_Aliases(TSRMLS_D)
{
	if (NULL == TElTerminalInfo_ce_ptr)
		Register_TElTerminalInfo(TSRMLS_C);
	zend_register_class_alias("ElTerminalInfo", TElTerminalInfo_ce_ptr);
}

