#include "sbsshutils.h"

SB_PHP_FUNCTION(SBSSHUtils, WriteString)
{
	SBArrayZValInfo aiS;
	uint32_t _err;
	zend_bool bAddZero;
	zval *zaS;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zb", &zaS, &bAddZero) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaS) || SB_IS_ARRAY_TYPE_RP(zaS) || SB_IS_NULL_TYPE_RP(zaS)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaS, &aiS TSRMLS_CC)) RETURN_FALSE;
		_err = SBSSHUtils_WriteString(aiS.data, aiS.len, (int8_t)bAddZero, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(113192368, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiS);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSHUtils, WriteBitCount)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piP;
	uint32_t _err;
	zval *zpP;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpP, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpP) || SB_IS_ARRAY_TYPE_RP(zpP) || SB_IS_NULL_TYPE_RP(zpP) || (SB_IS_OBJECT_TYPE_RP(zpP) && (Z_OBJCE_P(zpP) == TSBPointer_ce_ptr))))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetPointerFromZVal(zpP, &piP TSRMLS_CC)) RETURN_FALSE;
		_err = SBSSHUtils_WriteBitCount(piP.data, (int32_t)l4Size, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(810882978, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piP);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSHUtils, ReadSSH2MPInt)
{
	int32_t l4HeaderSzRaw;
	sb_zend_long l4Size;
	SBArrayZValInfo piP;
	uint32_t _err;
	zval *zl4HeaderSz;
	zval *zpP;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlz", &zpP, &l4Size, &zl4HeaderSz) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpP) || SB_IS_ARRAY_TYPE_RP(zpP) || SB_IS_NULL_TYPE_RP(zpP) || (SB_IS_OBJECT_TYPE_RP(zpP) && (Z_OBJCE_P(zpP) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4HeaderSz) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4HeaderSz))))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetPointerFromZVal(zpP, &piP TSRMLS_CC)) RETURN_FALSE;
		l4HeaderSzRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4HeaderSz));
		_err = SBSSHUtils_ReadSSH2MPInt(piP.data, (int32_t)l4Size, &l4HeaderSzRaw, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(318034406, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piP);
		ZVAL_LONG(Z_REFVAL_P(zl4HeaderSz), (sb_zend_long)l4HeaderSzRaw);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSHUtils, ReadBoolean)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piP;
	zval *zpP;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpP, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpP) || SB_IS_ARRAY_TYPE_RP(zpP) || SB_IS_NULL_TYPE_RP(zpP) || (SB_IS_OBJECT_TYPE_RP(zpP) && (Z_OBJCE_P(zpP) == TSBPointer_ce_ptr))))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpP, &piP TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBSSHUtils_ReadBoolean(piP.data, (int32_t)l4Size, &bOutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piP);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSHUtils, ReadString)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	uint32_t _err;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = SBSSHUtils_ReadString(piBuffer.data, (int32_t)l4Size, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(180783279, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piBuffer);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSHUtils, ReadBuffer)
{
	sb_zend_long l4AIndex;
	sb_zend_long l4Size;
	SBArrayZValInfo aiBuffer;
	SBArrayZValInfo piBuffer;
	uint32_t _err;
	zval *zaBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = SBSSHUtils_ReadBuffer(piBuffer.data, (int32_t)l4Size, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(780676395, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piBuffer);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4AIndex, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = SBSSHUtils_ReadBuffer_1(aiBuffer.data, aiBuffer.len, (int32_t)l4AIndex, (int32_t)l4Size, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1382962299, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiBuffer);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer) or (array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSHUtils, ReadSSH1MPInt)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	uint32_t _err;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		_err = SBSSHUtils_ReadSSH1MPInt(piBuffer.data, (int32_t)l4Size, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1406979880, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piBuffer);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSHUtils, ReadLength)
{
	sb_zend_long l4AIndex;
	sb_zend_long l4Size;
	SBArrayZValInfo aiBuffer;
	SBArrayZValInfo piBuffer;
	zval *zaBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBSSHUtils_ReadLength(piBuffer.data, (int32_t)l4Size, &u4OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaBuffer, &l4AIndex, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuffer) || SB_IS_ARRAY_TYPE_RP(zaBuffer) || SB_IS_NULL_TYPE_RP(zaBuffer)))
	{
		uint32_t u4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaBuffer, &aiBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBSSHUtils_ReadLength_1(aiBuffer.data, aiBuffer.len, (int32_t)l4AIndex, (int32_t)l4Size, &u4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiBuffer);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer) or (array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSHUtils, ReadUINT16)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		uint16_t u2OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBSSHUtils_ReadUINT16(piBuffer.data, (int32_t)l4Size, &u2OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)u2OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSHUtils, ReadUINT64)
{
	sb_zend_long l4Size;
	SBArrayZValInfo piBuffer;
	zval *zpBuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuffer, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuffer) || SB_IS_ARRAY_TYPE_RP(zpBuffer) || SB_IS_NULL_TYPE_RP(zpBuffer) || (SB_IS_OBJECT_TYPE_RP(zpBuffer) && (Z_OBJCE_P(zpBuffer) == TSBPointer_ce_ptr))))
	{
		int64_t l8OutResultRaw = 0;
		if (!SBGetPointerFromZVal(zpBuffer, &piBuffer TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBSSHUtils_ReadUINT64(piBuffer.data, (int32_t)l4Size, &l8OutResultRaw) TSRMLS_CC);
		SBFreePointerZValInfo(&piBuffer);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSHUtils, WriteSSH2MPInt)
{
	sb_zend_long l4Size;
	SBArrayZValInfo aiP;
	uint32_t _err;
	zval *zaP;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaP, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaP) || SB_IS_ARRAY_TYPE_RP(zaP) || SB_IS_NULL_TYPE_RP(zaP)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaP, &aiP TSRMLS_CC)) RETURN_FALSE;
		_err = SBSSHUtils_WriteSSH2MPInt(aiP.data, aiP.len, (int32_t)l4Size, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-748098752, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiP);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSHUtils, WriteBoolean)
{
	uint32_t _err;
	zend_bool bB;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bB) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBSSHUtils_WriteBoolean((int8_t)bB, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-315512702, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

