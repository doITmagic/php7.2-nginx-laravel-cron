#include "sbsslcommon.h"

zend_class_entry *TSBReceiveState_ce_ptr = NULL;

zend_class_entry *IElSSLCertificateHandlerContainer_ce_ptr = NULL;

zend_class_entry *TSBSSLMode_ce_ptr = NULL;

zend_class_entry *TSBCloseReason_ce_ptr = NULL;

void SB_CALLBACK TSBDataEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zBuffer;
	zval * zSize;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 1);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSize, 2);
	ZVAL_LONG(zSize, (sb_zend_long)Size);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zSize);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBReceiveEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t MaxSize, int32_t * Written)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zBuffer;
	zval * zMaxSize;
	zval * zWritten;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 1);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zMaxSize, 2);
	ZVAL_LONG(zMaxSize, (sb_zend_long)MaxSize);
	SB_EVENT_INIT_ZVAL_REF(zWritten, 3);
	ZVAL_LONG(Z_REFVAL_P(zWritten), 0);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zMaxSize);
	convert_to_long(Z_REFVAL_P(zWritten));
	*Written = (int32_t)Z_LVAL_P(Z_REFVAL_P(zWritten));
	SB_EVENT_CLEAR_ZVAL(zWritten);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBSendEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zBuffer;
	zval * zSize;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zBuffer, 1);
	SBInitPointerObject(zBuffer, Buffer TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSize, 2);
	ZVAL_LONG(zSize, (sb_zend_long)Size);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zBuffer);
	SB_EVENT_CLEAR_ZVAL(zSize);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBOpenConnectionEventRaw(void * _ObjectData, TObjectHandle Sender)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(1);
	zval * zSender;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 1, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBCloseConnectionEventRaw(void * _ObjectData, TObjectHandle Sender, TSBCloseReasonRaw CloseReason)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zCloseReason;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zCloseReason, 1);
	ZVAL_LONG(zCloseReason, (sb_zend_long)CloseReason);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zCloseReason);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBRenegotiationStartEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t Safe, int8_t * Allow)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zSafe;
	zval * zAllow;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zSafe, 1);
	ZVAL_BOOL(zSafe, (zend_bool)Safe);
	SB_EVENT_INIT_ZVAL_REF(zAllow, 2);
	ZVAL_BOOL(Z_REFVAL_P(zAllow), (zend_bool)*Allow);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zSafe);
	convert_to_boolean(Z_REFVAL_P(zAllow));
	*Allow = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAllow));
	SB_EVENT_CLEAR_ZVAL(zAllow);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBRenegotiationRequestEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t * Allow)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zAllow;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zAllow, 1);
	ZVAL_BOOL(Z_REFVAL_P(zAllow), (zend_bool)*Allow);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	convert_to_boolean(Z_REFVAL_P(zAllow));
	*Allow = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAllow));
	SB_EVENT_CLEAR_ZVAL(zAllow);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBErrorEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode, int8_t Fatal, int8_t Remote)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(4);
	zval * zSender;
	zval * zErrorCode;
	zval * zFatal;
	zval * zRemote;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zErrorCode, 1);
	ZVAL_LONG(zErrorCode, (sb_zend_long)ErrorCode);
	SB_EVENT_INIT_ZVAL(zFatal, 2);
	ZVAL_BOOL(zFatal, (zend_bool)Fatal);
	SB_EVENT_INIT_ZVAL(zRemote, 3);
	ZVAL_BOOL(zRemote, (zend_bool)Remote);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 4, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zErrorCode);
	SB_EVENT_CLEAR_ZVAL(zFatal);
	SB_EVENT_CLEAR_ZVAL(zRemote);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSBAlertLevel_ce_ptr = NULL;

zend_class_entry *TSBAlertDescription_ce_ptr = NULL;

zend_class_entry *TSBSSLOption_ce_ptr = NULL;

zend_class_entry *TSBSSLOptions_ce_ptr = NULL;

zend_class_entry *TSBKeyExchangeAlgorithm_ce_ptr = NULL;

zend_class_entry *TSBDigestAlgorithm_ce_ptr = NULL;

zend_class_entry *TSBEncryptAlgorithm_ce_ptr = NULL;

zend_class_entry *TSBSignatureAlgorithm_ce_ptr = NULL;

zend_class_entry *TSBRenegotiationAttackPreventionMode_ce_ptr = NULL;

zend_class_entry *TSBSSLServerNameType_ce_ptr = NULL;

zend_class_entry *TSBSSLFragmentLength_ce_ptr = NULL;

zend_class_entry *TSBCertChainType_ce_ptr = NULL;

zend_class_entry *TSBCAIdentifierType_ce_ptr = NULL;

zend_class_entry *TSBCertificateStatusType_ce_ptr = NULL;

void SB_CALLBACK TSBExtensionsReceivedEventRaw(void * _ObjectData, TObjectHandle Sender)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(1);
	zval * zSender;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 1, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBExtensionsPreparedEventRaw(void * _ObjectData, TObjectHandle Sender)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(1);
	zval * zSender;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 1, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TSSL3ContentType_ce_ptr = NULL;

zend_class_entry *TSSL3HandshakeType_ce_ptr = NULL;

zend_class_entry *TElSSLCertificateTypeHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElSSLCertificateTypeHandler, GetCertificateType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElSSLCertificateTypeRaw fOutResultRaw = 0;
		SBCheckError(TElSSLCertificateTypeHandler_GetCertificateType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertificateTypeHandler, GetDataForRemote)
{
	sb_zend_long fKeyExchange;
	sb_zend_long l4CipherSuite;
	sb_zend_long l4Optional;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llzl", &l4CipherSuite, &fKeyExchange, &zaData, &l4Optional) == SUCCESS) && Z_ISREF_P(zaData) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaData))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaData)))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = TElSSLCertificateTypeHandler_GetDataForRemote(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4CipherSuite, (TSBKeyExchangeAlgorithmRaw)fKeyExchange, aiData.data, &aiData.len, (int32_t)l4Optional, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaData, &aiData TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(1961643592, 3, aiData.data, &aiData.len) TSRMLS_CC);
			((char *)aiData.data)[aiData.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiData);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiData, zaData);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, &array of byte|string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertificateTypeHandler, ValidateRemoteCert)
{
	sb_zend_long l4Optional;
	SBArrayZValInfo aiData;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaData, &l4Optional) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSLCertificateTypeHandler_ValidateRemoteCert(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, (int32_t)l4Optional, &bOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertificateTypeHandler, GetRemoteKeyMaterial)
{
	int32_t l4KeyAlgorithmRaw;
	int32_t l4PKTypeRaw;
	sb_zend_long l4KeyType;
	SBArrayZValInfo aiData;
	TElClassHandle hoKeyMaterial;
	zval *oKeyMaterial;
	zval *zaData;
	zval *zl4KeyAlgorithm;
	zval *zl4PKType;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzO", &zaData, &l4KeyType, &zl4PKType, &zl4KeyAlgorithm, &oKeyMaterial, TElKeyMaterial_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)) && Z_ISREF_P(zl4PKType) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4PKType))) && Z_ISREF_P(zl4KeyAlgorithm) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4KeyAlgorithm))) && SB_ISREF_OBJECT_P(oKeyMaterial))
	{
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		l4PKTypeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4PKType));
		l4KeyAlgorithmRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4KeyAlgorithm));
		hoKeyMaterial = SBGetObjectHandle(oKeyMaterial TSRMLS_CC);
		SBCheckError(TElSSLCertificateTypeHandler_GetRemoteKeyMaterial(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, (int32_t)l4KeyType, &l4PKTypeRaw, &l4KeyAlgorithmRaw, &hoKeyMaterial) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		ZVAL_LONG(Z_REFVAL_P(zl4PKType), (sb_zend_long)l4PKTypeRaw);
		ZVAL_LONG(Z_REFVAL_P(zl4KeyAlgorithm), (sb_zend_long)l4KeyAlgorithmRaw);
		SBUpdateObjectHandle(oKeyMaterial, hoKeyMaterial TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer, &integer, &\\TElKeyMaterial)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertificateTypeHandler, GetKeyMaterial)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLCertificateTypeHandler_GetKeyMaterial(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElKeyMaterial_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertificateTypeHandler, GetPublicKeySize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLCertificateTypeHandler_GetPublicKeySize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertificateTypeHandler, GetPublicKeyAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLCertificateTypeHandler_GetPublicKeyAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertificateTypeHandler, get_KeyIndex)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLCertificateTypeHandler_get_KeyIndex(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertificateTypeHandler, set_KeyIndex)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSLCertificateTypeHandler_set_KeyIndex(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertificateTypeHandler, get_KeyCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLCertificateTypeHandler_get_KeyCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertificateTypeHandler, get_SSLClass)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLCertificateTypeHandler_get_SSLClass(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, IElSSLCertificateHandlerContainer_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertificateTypeHandler, set_SSLClass)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, IElSSLCertificateHandlerContainer_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSLCertificateTypeHandler_set_SSLClass(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\IElSSLCertificateHandlerContainer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertificateTypeHandler, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLCertificateTypeHandler_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertificateTypeHandler_GetCertificateType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertificateTypeHandler_GetDataForRemote, 0, 0, 4)
	ZEND_ARG_INFO(0, CipherSuite)
	ZEND_ARG_INFO(0, KeyExchange)
	ZEND_ARG_INFO(1, Data)
	ZEND_ARG_INFO(0, Optional)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertificateTypeHandler_ValidateRemoteCert, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, Optional)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertificateTypeHandler_GetRemoteKeyMaterial, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, KeyType)
	ZEND_ARG_INFO(1, PKType)
	ZEND_ARG_INFO(1, KeyAlgorithm)
	ZEND_ARG_OBJ_INFO(1, KeyMaterial, TElKeyMaterial, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertificateTypeHandler_GetKeyMaterial, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertificateTypeHandler_GetPublicKeySize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertificateTypeHandler_GetPublicKeyAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertificateTypeHandler_get_KeyIndex, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertificateTypeHandler_set_KeyIndex, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertificateTypeHandler_get_KeyCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertificateTypeHandler_get_SSLClass, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertificateTypeHandler_set_SSLClass, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, IElSSLCertificateHandlerContainer, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertificateTypeHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSLCertificateTypeHandler_methods[] = {
	PHP_ME(TElSSLCertificateTypeHandler, GetCertificateType, arginfo_TElSSLCertificateTypeHandler_GetCertificateType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertificateTypeHandler, GetDataForRemote, arginfo_TElSSLCertificateTypeHandler_GetDataForRemote, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertificateTypeHandler, ValidateRemoteCert, arginfo_TElSSLCertificateTypeHandler_ValidateRemoteCert, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertificateTypeHandler, GetRemoteKeyMaterial, arginfo_TElSSLCertificateTypeHandler_GetRemoteKeyMaterial, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertificateTypeHandler, GetKeyMaterial, arginfo_TElSSLCertificateTypeHandler_GetKeyMaterial, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertificateTypeHandler, GetPublicKeySize, arginfo_TElSSLCertificateTypeHandler_GetPublicKeySize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertificateTypeHandler, GetPublicKeyAlgorithm, arginfo_TElSSLCertificateTypeHandler_GetPublicKeyAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertificateTypeHandler, get_KeyIndex, arginfo_TElSSLCertificateTypeHandler_get_KeyIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertificateTypeHandler, set_KeyIndex, arginfo_TElSSLCertificateTypeHandler_set_KeyIndex, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertificateTypeHandler, get_KeyCount, arginfo_TElSSLCertificateTypeHandler_get_KeyCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertificateTypeHandler, get_SSLClass, arginfo_TElSSLCertificateTypeHandler_get_SSLClass, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertificateTypeHandler, set_SSLClass, arginfo_TElSSLCertificateTypeHandler_set_SSLClass, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertificateTypeHandler, __construct, arginfo_TElSSLCertificateTypeHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSLCertificateTypeHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSLCertificateTypeHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSLCertificateTypeHandler", TElSSLCertificateTypeHandler_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElSSLCertificateTypeHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElCustomSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElCustomSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtension, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCustomSSLExtension_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtension, get_ExtensionType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomSSLExtension_get_ExtensionType(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtension, set_ExtensionType)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElCustomSSLExtension_set_ExtensionType(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtension, get_ExtensionData)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElCustomSSLExtension_get_ExtensionData(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-709854037, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtension, set_ExtensionData)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCustomSSLExtension_set_ExtensionData(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtension, get_Enabled)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomSSLExtension_get_Enabled(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtension, set_Enabled)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCustomSSLExtension_set_Enabled(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtension, get_Server)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomSSLExtension_get_Server(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtension, set_Server)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCustomSSLExtension_set_Server(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtension_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtension_get_ExtensionType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtension_set_ExtensionType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtension_get_ExtensionData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtension_set_ExtensionData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtension_get_Enabled, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtension_set_Enabled, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtension_get_Server, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtension_set_Server, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElCustomSSLExtension_methods[] = {
	PHP_ME(TElCustomSSLExtension, Assign, arginfo_TElCustomSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtension, Clear, arginfo_TElCustomSSLExtension_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtension, get_ExtensionType, arginfo_TElCustomSSLExtension_get_ExtensionType, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtension, set_ExtensionType, arginfo_TElCustomSSLExtension_set_ExtensionType, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtension, get_ExtensionData, arginfo_TElCustomSSLExtension_get_ExtensionData, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtension, set_ExtensionData, arginfo_TElCustomSSLExtension_set_ExtensionData, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtension, get_Enabled, arginfo_TElCustomSSLExtension_get_Enabled, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtension, set_Enabled, arginfo_TElCustomSSLExtension_set_Enabled, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtension, get_Server, arginfo_TElCustomSSLExtension_get_Server, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtension, set_Server, arginfo_TElCustomSSLExtension_set_Server, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtension, __construct, arginfo_TElCustomSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCustomSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCustomSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCustomSSLExtension", TElCustomSSLExtension_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElCustomSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSSLClass_ce_ptr = NULL;

SB_PHP_METHOD(TElSSLClass, AddCertTypeHandler)
{
	zval *oHandler;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oHandler, TElSSLCertificateTypeHandler_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSLClass_AddCertTypeHandler(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oHandler TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSLCertificateTypeHandler)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, RemoveCertTypeHandler)
{
	zval *oHandler;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oHandler, TElSSLCertificateTypeHandler_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSLClass_RemoveCertTypeHandler(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oHandler TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSLCertificateTypeHandler)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, EnterCS)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSSLClass_EnterCS(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, LeaveCS)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSSLClass_LeaveCS(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, AssignFromTemplate)
{
	zval *oTpl;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oTpl, TElSSLClass_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSLClass_AssignFromTemplate(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTpl TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSLClass)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSSLClass_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_CipherSuites)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSLClass_get_CipherSuites(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_CipherSuites)
{
	sb_zend_long u1Index;
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &u1Index, &bValue) == SUCCESS)
	{
		SBCheckError(TElSSLClass_set_CipherSuites(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_CipherSuitePriorities)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLClass_get_CipherSuitePriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_CipherSuitePriorities)
{
	sb_zend_long l4Value;
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &u1Index, &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSLClass_set_CipherSuitePriorities(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_CompressionAlgorithms)
{
	sb_zend_long u1Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Index) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSLClass_get_CompressionAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_CompressionAlgorithms)
{
	sb_zend_long u1Index;
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &u1Index, &bValue) == SUCCESS)
	{
		SBCheckError(TElSSLClass_set_CompressionAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Index, (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_Active)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSLClass_get_Active(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_CurrentVersion)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBVersionRaw fOutResultRaw = 0;
		SBCheckError(TElSSLClass_get_CurrentVersion(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_CompressionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElSSLClass_get_CompressionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_TotalBytesSent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSSLClass_get_TotalBytesSent(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_TotalBytesReceived)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(TElSSLClass_get_TotalBytesReceived(SBGetObjectHandle(getThis() TSRMLS_CC), &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_ConnectionInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLClass_get_ConnectionInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSLConnectionInfo_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_Versions)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBVersionsRaw fOutResultRaw = 0;
		SBCheckError(TElSSLClass_get_Versions(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_Versions)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSSLClass_set_Versions(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBVersionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_Options)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSSLOptionsRaw fOutResultRaw = 0;
		SBCheckError(TElSSLClass_get_Options(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_Options)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSSLClass_set_Options(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSSLOptionsRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_RenegotiationAttackPreventionMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBRenegotiationAttackPreventionModeRaw fOutResultRaw = 0;
		SBCheckError(TElSSLClass_get_RenegotiationAttackPreventionMode(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_RenegotiationAttackPreventionMode)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSSLClass_set_RenegotiationAttackPreventionMode(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBRenegotiationAttackPreventionModeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_OnSend)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSendEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSLClass_get_OnSend(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_OnSend)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSLClass_set_OnSend(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBSendEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBSendEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_OnReceive)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBReceiveEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSLClass_get_OnReceive(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_OnReceive)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSLClass_set_OnReceive(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBReceiveEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBReceiveEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_OnData)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDataEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSLClass_get_OnData(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_OnData)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSLClass_set_OnData(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBDataEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBDataEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_OnOpenConnection)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBOpenConnectionEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSLClass_get_OnOpenConnection(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_OnOpenConnection)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSLClass_set_OnOpenConnection(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBOpenConnectionEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBOpenConnectionEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_OnCertificateValidate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCertificateValidateEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSLClass_get_OnCertificateValidate(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_OnCertificateValidate)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSLClass_set_OnCertificateValidate(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBCertificateValidateEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBCertificateValidateEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_OnRawPublicKeyValidate)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBRawPublicKeyValidateEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSLClass_get_OnRawPublicKeyValidate(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_OnRawPublicKeyValidate)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSLClass_set_OnRawPublicKeyValidate(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBRawPublicKeyValidateEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBRawPublicKeyValidateEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_OnCiphersNegotiated)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSLClass_get_OnCiphersNegotiated(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_OnCiphersNegotiated)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSLClass_set_OnCiphersNegotiated(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_OnError)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBErrorEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSLClass_get_OnError(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_OnError)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSLClass_set_OnError(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBErrorEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBErrorEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_OnExtensionsReceived)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBExtensionsReceivedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSLClass_get_OnExtensionsReceived(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_OnExtensionsReceived)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSLClass_set_OnExtensionsReceived(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBExtensionsReceivedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBExtensionsReceivedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_OnExtensionsPrepared)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBExtensionsPreparedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSLClass_get_OnExtensionsPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_OnExtensionsPrepared)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSLClass_set_OnExtensionsPrepared(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBExtensionsPreparedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBExtensionsPreparedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, get_OnKeepAliveResponse)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSLClass_get_OnKeepAliveResponse(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, set_OnKeepAliveResponse)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSLClass_set_OnKeepAliveResponse(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLClass, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLClass_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_AddCertTypeHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElSSLCertificateTypeHandler, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_RemoveCertTypeHandler, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Handler, TElSSLCertificateTypeHandler, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_EnterCS, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_LeaveCS, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_AssignFromTemplate, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Tpl, TElSSLClass, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_CipherSuites, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_CipherSuites, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_CipherSuitePriorities, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_CipherSuitePriorities, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_CompressionAlgorithms, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_CompressionAlgorithms, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_Active, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_CurrentVersion, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_CompressionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_TotalBytesSent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_TotalBytesReceived, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_ConnectionInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_Versions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_Versions, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_Options, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_Options, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_RenegotiationAttackPreventionMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_RenegotiationAttackPreventionMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_OnSend, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_OnSend, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_OnReceive, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_OnReceive, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_OnData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_OnData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_OnOpenConnection, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_OnOpenConnection, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_OnCertificateValidate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_OnCertificateValidate, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_OnRawPublicKeyValidate, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_OnRawPublicKeyValidate, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_OnCiphersNegotiated, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_OnCiphersNegotiated, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_OnError, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_OnError, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_OnExtensionsReceived, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_OnExtensionsReceived, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_OnExtensionsPrepared, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_OnExtensionsPrepared, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_get_OnKeepAliveResponse, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass_set_OnKeepAliveResponse, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLClass___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSLClass_methods[] = {
	PHP_ME(TElSSLClass, AddCertTypeHandler, arginfo_TElSSLClass_AddCertTypeHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, RemoveCertTypeHandler, arginfo_TElSSLClass_RemoveCertTypeHandler, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, EnterCS, arginfo_TElSSLClass_EnterCS, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, LeaveCS, arginfo_TElSSLClass_LeaveCS, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, AssignFromTemplate, arginfo_TElSSLClass_AssignFromTemplate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, Reset, arginfo_TElSSLClass_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_CipherSuites, arginfo_TElSSLClass_get_CipherSuites, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_CipherSuites, arginfo_TElSSLClass_set_CipherSuites, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_CipherSuitePriorities, arginfo_TElSSLClass_get_CipherSuitePriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_CipherSuitePriorities, arginfo_TElSSLClass_set_CipherSuitePriorities, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_CompressionAlgorithms, arginfo_TElSSLClass_get_CompressionAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_CompressionAlgorithms, arginfo_TElSSLClass_set_CompressionAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_Active, arginfo_TElSSLClass_get_Active, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_CurrentVersion, arginfo_TElSSLClass_get_CurrentVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_CompressionAlgorithm, arginfo_TElSSLClass_get_CompressionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_TotalBytesSent, arginfo_TElSSLClass_get_TotalBytesSent, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_TotalBytesReceived, arginfo_TElSSLClass_get_TotalBytesReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_ConnectionInfo, arginfo_TElSSLClass_get_ConnectionInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_Versions, arginfo_TElSSLClass_get_Versions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_Versions, arginfo_TElSSLClass_set_Versions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_Options, arginfo_TElSSLClass_get_Options, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_Options, arginfo_TElSSLClass_set_Options, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_RenegotiationAttackPreventionMode, arginfo_TElSSLClass_get_RenegotiationAttackPreventionMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_RenegotiationAttackPreventionMode, arginfo_TElSSLClass_set_RenegotiationAttackPreventionMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_OnSend, arginfo_TElSSLClass_get_OnSend, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_OnSend, arginfo_TElSSLClass_set_OnSend, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_OnReceive, arginfo_TElSSLClass_get_OnReceive, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_OnReceive, arginfo_TElSSLClass_set_OnReceive, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_OnData, arginfo_TElSSLClass_get_OnData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_OnData, arginfo_TElSSLClass_set_OnData, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_OnOpenConnection, arginfo_TElSSLClass_get_OnOpenConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_OnOpenConnection, arginfo_TElSSLClass_set_OnOpenConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_OnCertificateValidate, arginfo_TElSSLClass_get_OnCertificateValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_OnCertificateValidate, arginfo_TElSSLClass_set_OnCertificateValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_OnRawPublicKeyValidate, arginfo_TElSSLClass_get_OnRawPublicKeyValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_OnRawPublicKeyValidate, arginfo_TElSSLClass_set_OnRawPublicKeyValidate, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_OnCiphersNegotiated, arginfo_TElSSLClass_get_OnCiphersNegotiated, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_OnCiphersNegotiated, arginfo_TElSSLClass_set_OnCiphersNegotiated, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_OnError, arginfo_TElSSLClass_get_OnError, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_OnError, arginfo_TElSSLClass_set_OnError, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_OnExtensionsReceived, arginfo_TElSSLClass_get_OnExtensionsReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_OnExtensionsReceived, arginfo_TElSSLClass_set_OnExtensionsReceived, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_OnExtensionsPrepared, arginfo_TElSSLClass_get_OnExtensionsPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_OnExtensionsPrepared, arginfo_TElSSLClass_set_OnExtensionsPrepared, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, get_OnKeepAliveResponse, arginfo_TElSSLClass_get_OnKeepAliveResponse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, set_OnKeepAliveResponse, arginfo_TElSSLClass_set_OnKeepAliveResponse, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLClass, __construct, arginfo_TElSSLClass___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSLClass(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSLClass_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSLClass", TElSSLClass_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElSSLClass_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

zend_class_entry *TElSSLConnectionInfo_ce_ptr = NULL;

SB_PHP_METHOD(TElSSLConnectionInfo, InitializeNonSecure)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSSLConnectionInfo_InitializeNonSecure(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, Initialize)
{
	sb_zend_long fVersion;
	sb_zend_long u1Ciphersuite;
	SBArrayZValInfo aiSessionID;
	zend_bool bResumedSession;
	zval *oClientChain;
	zval *oServerChain;
	zval *zaSessionID;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llO!O!zb", &fVersion, &u1Ciphersuite, &oServerChain, TElCustomCertStorage_ce_ptr, &oClientChain, TElCustomCertStorage_ce_ptr, &zaSessionID, &bResumedSession) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSessionID) || SB_IS_ARRAY_TYPE_RP(zaSessionID) || SB_IS_NULL_TYPE_RP(zaSessionID)))
	{
		if (!SBGetByteArrayFromZVal(zaSessionID, &aiSessionID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSLConnectionInfo_Initialize(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBVersionRaw)fVersion, (uint8_t)u1Ciphersuite, SBGetObjectHandle(oServerChain TSRMLS_CC), SBGetObjectHandle(oClientChain TSRMLS_CC), aiSessionID.data, aiSessionID.len, (int8_t)bResumedSession) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiSessionID);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, \\TElCustomCertStorage, \\TElCustomCertStorage, array of byte|string|NULL, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, Reset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSSLConnectionInfo_Reset(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_Ciphersuite)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_Ciphersuite(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_CiphersuiteName)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSSLConnectionInfo_get_CiphersuiteName(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1714360999, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_EncryptionAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBEncryptAlgorithmRaw fOutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_EncryptionAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_KeyExchangeAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBKeyExchangeAlgorithmRaw fOutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_KeyExchangeAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_SignatureAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSignatureAlgorithmRaw fOutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_SignatureAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_DigestAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBDigestAlgorithmRaw fOutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_DigestAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_Version)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBVersionRaw fOutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_Version(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_Exportable)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_Exportable(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_SymmetricKeyBits)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_SymmetricKeyBits(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_PublicKeyBits)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_PublicKeyBits(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_KeyExchangeKeyBits)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_KeyExchangeKeyBits(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_SymmetricBlockSize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_SymmetricBlockSize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_AEADCipher)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_AEADCipher(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_ClientChain)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLConnectionInfo_get_ClientChain(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_ServerChain)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLConnectionInfo_get_ServerChain(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCertStorage_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_SessionID)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSSLConnectionInfo_get_SessionID(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1074069997, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_ResumedSession)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_ResumedSession(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_ConnectionEstablished)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_ConnectionEstablished(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_PFSCipher)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_PFSCipher(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_ClientAuthenticated)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_ClientAuthenticated(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_ServerAuthenticated)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_ServerAuthenticated(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_SecureConnection)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_SecureConnection(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, get_NamedECCurve)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLConnectionInfo_get_NamedECCurve(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLConnectionInfo, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TElSSLClass_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLConnectionInfo_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElSSLClass)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_InitializeNonSecure, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_Initialize, 0, 0, 6)
	ZEND_ARG_INFO(0, Version)
	ZEND_ARG_INFO(0, Ciphersuite)
	ZEND_ARG_OBJ_INFO(0, ServerChain, TElCustomCertStorage, 1)
	ZEND_ARG_OBJ_INFO(0, ClientChain, TElCustomCertStorage, 1)
	ZEND_ARG_TYPE_INFO(0, SessionID, 0, 1)
	ZEND_ARG_INFO(0, ResumedSession)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_Reset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_Ciphersuite, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_CiphersuiteName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_EncryptionAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_KeyExchangeAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_SignatureAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_DigestAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_Version, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_Exportable, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_SymmetricKeyBits, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_PublicKeyBits, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_KeyExchangeKeyBits, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_SymmetricBlockSize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_AEADCipher, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_ClientChain, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_ServerChain, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_SessionID, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_ResumedSession, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_ConnectionEstablished, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_PFSCipher, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_ClientAuthenticated, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_ServerAuthenticated, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_SecureConnection, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo_get_NamedECCurve, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLConnectionInfo___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TElSSLClass, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSLConnectionInfo_methods[] = {
	PHP_ME(TElSSLConnectionInfo, InitializeNonSecure, arginfo_TElSSLConnectionInfo_InitializeNonSecure, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, Initialize, arginfo_TElSSLConnectionInfo_Initialize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, Reset, arginfo_TElSSLConnectionInfo_Reset, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_Ciphersuite, arginfo_TElSSLConnectionInfo_get_Ciphersuite, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_CiphersuiteName, arginfo_TElSSLConnectionInfo_get_CiphersuiteName, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_EncryptionAlgorithm, arginfo_TElSSLConnectionInfo_get_EncryptionAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_KeyExchangeAlgorithm, arginfo_TElSSLConnectionInfo_get_KeyExchangeAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_SignatureAlgorithm, arginfo_TElSSLConnectionInfo_get_SignatureAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_DigestAlgorithm, arginfo_TElSSLConnectionInfo_get_DigestAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_Version, arginfo_TElSSLConnectionInfo_get_Version, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_Exportable, arginfo_TElSSLConnectionInfo_get_Exportable, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_SymmetricKeyBits, arginfo_TElSSLConnectionInfo_get_SymmetricKeyBits, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_PublicKeyBits, arginfo_TElSSLConnectionInfo_get_PublicKeyBits, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_KeyExchangeKeyBits, arginfo_TElSSLConnectionInfo_get_KeyExchangeKeyBits, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_SymmetricBlockSize, arginfo_TElSSLConnectionInfo_get_SymmetricBlockSize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_AEADCipher, arginfo_TElSSLConnectionInfo_get_AEADCipher, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_ClientChain, arginfo_TElSSLConnectionInfo_get_ClientChain, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_ServerChain, arginfo_TElSSLConnectionInfo_get_ServerChain, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_SessionID, arginfo_TElSSLConnectionInfo_get_SessionID, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_ResumedSession, arginfo_TElSSLConnectionInfo_get_ResumedSession, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_ConnectionEstablished, arginfo_TElSSLConnectionInfo_get_ConnectionEstablished, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_PFSCipher, arginfo_TElSSLConnectionInfo_get_PFSCipher, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_ClientAuthenticated, arginfo_TElSSLConnectionInfo_get_ClientAuthenticated, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_ServerAuthenticated, arginfo_TElSSLConnectionInfo_get_ServerAuthenticated, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_SecureConnection, arginfo_TElSSLConnectionInfo_get_SecureConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, get_NamedECCurve, arginfo_TElSSLConnectionInfo_get_NamedECCurve, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLConnectionInfo, __construct, arginfo_TElSSLConnectionInfo___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSLConnectionInfo(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSLConnectionInfo_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSLConnectionInfo", TElSSLConnectionInfo_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSSLConnectionInfo_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSSLServerName_ce_ptr = NULL;

SB_PHP_METHOD(TElSSLServerName, get_NameType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSSLServerNameTypeRaw fOutResultRaw = 0;
		SBCheckError(TElSSLServerName_get_NameType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLServerName, set_NameType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSSLServerName_set_NameType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSSLServerNameTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLServerName, get_Name)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSSLServerName_get_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-828282214, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLServerName, set_Name)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSSLServerName_set_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLServerName, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLServerName_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLServerName_get_NameType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLServerName_set_NameType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLServerName_get_Name, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLServerName_set_Name, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLServerName___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSLServerName_methods[] = {
	PHP_ME(TElSSLServerName, get_NameType, arginfo_TElSSLServerName_get_NameType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLServerName, set_NameType, arginfo_TElSSLServerName_set_NameType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLServerName, get_Name, arginfo_TElSSLServerName_get_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLServerName, set_Name, arginfo_TElSSLServerName_set_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLServerName, __construct, arginfo_TElSSLServerName___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSLServerName(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSLServerName_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSLServerName", TElSSLServerName_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSSLServerName_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElHeartbeatHelloSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElHeartbeatHelloSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElHeartbeatHelloSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHeartbeatHelloSSLExtension, get_Mode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElHeartbeatHelloSSLExtension_get_Mode(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHeartbeatHelloSSLExtension, set_Mode)
{
	sb_zend_long u1Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Value) == SUCCESS)
	{
		SBCheckError(TElHeartbeatHelloSSLExtension_set_Mode(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElHeartbeatHelloSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElHeartbeatHelloSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHeartbeatHelloSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHeartbeatHelloSSLExtension_get_Mode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHeartbeatHelloSSLExtension_set_Mode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElHeartbeatHelloSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElHeartbeatHelloSSLExtension_methods[] = {
	PHP_ME(TElHeartbeatHelloSSLExtension, Assign, arginfo_TElHeartbeatHelloSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElHeartbeatHelloSSLExtension, get_Mode, arginfo_TElHeartbeatHelloSSLExtension_get_Mode, ZEND_ACC_PUBLIC)
	PHP_ME(TElHeartbeatHelloSSLExtension, set_Mode, arginfo_TElHeartbeatHelloSSLExtension_set_Mode, ZEND_ACC_PUBLIC)
	PHP_ME(TElHeartbeatHelloSSLExtension, __construct, arginfo_TElHeartbeatHelloSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElHeartbeatHelloSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElHeartbeatHelloSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElHeartbeatHelloSSLExtension", TElHeartbeatHelloSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElHeartbeatHelloSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElServerNameSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElServerNameSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElServerNameSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerNameSSLExtension, Add)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElServerNameSSLExtension_Add(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerNameSSLExtension, Remove)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElServerNameSSLExtension_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerNameSSLExtension, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElServerNameSSLExtension_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerNameSSLExtension, get_Names)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElServerNameSSLExtension_get_Names(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSLServerName_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerNameSSLExtension, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElServerNameSSLExtension_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerNameSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElServerNameSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerNameSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerNameSSLExtension_Add, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerNameSSLExtension_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerNameSSLExtension_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerNameSSLExtension_get_Names, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerNameSSLExtension_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerNameSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElServerNameSSLExtension_methods[] = {
	PHP_ME(TElServerNameSSLExtension, Assign, arginfo_TElServerNameSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerNameSSLExtension, Add, arginfo_TElServerNameSSLExtension_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerNameSSLExtension, Remove, arginfo_TElServerNameSSLExtension_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerNameSSLExtension, Clear, arginfo_TElServerNameSSLExtension_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerNameSSLExtension, get_Names, arginfo_TElServerNameSSLExtension_get_Names, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerNameSSLExtension, get_Count, arginfo_TElServerNameSSLExtension_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerNameSSLExtension, __construct, arginfo_TElServerNameSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElServerNameSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElServerNameSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElServerNameSSLExtension", TElServerNameSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElServerNameSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElUserNameSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElUserNameSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElUserNameSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElUserNameSSLExtension, get_Name)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElUserNameSSLExtension_get_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2106159337, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElUserNameSSLExtension, set_Name)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElUserNameSSLExtension_set_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElUserNameSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElUserNameSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUserNameSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUserNameSSLExtension_get_Name, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUserNameSSLExtension_set_Name, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUserNameSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElUserNameSSLExtension_methods[] = {
	PHP_ME(TElUserNameSSLExtension, Assign, arginfo_TElUserNameSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElUserNameSSLExtension, get_Name, arginfo_TElUserNameSSLExtension_get_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElUserNameSSLExtension, set_Name, arginfo_TElUserNameSSLExtension_set_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElUserNameSSLExtension, __construct, arginfo_TElUserNameSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElUserNameSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElUserNameSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElUserNameSSLExtension", TElUserNameSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElUserNameSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElECCurveSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElECCurveSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElECCurveSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECCurveSSLExtension, SetCurves)
{
	sb_zend_long l4Curve;
	zend_bool bEnabled;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &l4Curve, &bEnabled) == SUCCESS)
	{
		SBCheckError(TElECCurveSSLExtension_SetCurves(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Curve, (int8_t)bEnabled) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECCurveSSLExtension, IsCurveEnabled)
{
	sb_zend_long l4Curve;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Curve) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElECCurveSSLExtension_IsCurveEnabled(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Curve, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECCurveSSLExtension, GetCurve)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElECCurveSSLExtension_GetCurve(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECCurveSSLExtension, GetCurveCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElECCurveSSLExtension_GetCurveCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECCurveSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElECCurveSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECCurveSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECCurveSSLExtension_SetCurves, 0, 0, 2)
	ZEND_ARG_INFO(0, Curve)
	ZEND_ARG_INFO(0, Enabled)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECCurveSSLExtension_IsCurveEnabled, 0, 0, 1)
	ZEND_ARG_INFO(0, Curve)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECCurveSSLExtension_GetCurve, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECCurveSSLExtension_GetCurveCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECCurveSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElECCurveSSLExtension_methods[] = {
	PHP_ME(TElECCurveSSLExtension, Assign, arginfo_TElECCurveSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElECCurveSSLExtension, SetCurves, arginfo_TElECCurveSSLExtension_SetCurves, ZEND_ACC_PUBLIC)
	PHP_ME(TElECCurveSSLExtension, IsCurveEnabled, arginfo_TElECCurveSSLExtension_IsCurveEnabled, ZEND_ACC_PUBLIC)
	PHP_ME(TElECCurveSSLExtension, GetCurve, arginfo_TElECCurveSSLExtension_GetCurve, ZEND_ACC_PUBLIC)
	PHP_ME(TElECCurveSSLExtension, GetCurveCount, arginfo_TElECCurveSSLExtension_GetCurveCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElECCurveSSLExtension, __construct, arginfo_TElECCurveSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElECCurveSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElECCurveSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElECCurveSSLExtension", TElECCurveSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElECCurveSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElECPointSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElECPointSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElECPointSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECPointSSLExtension, SetPointType)
{
	sb_zend_long u1Point;
	zend_bool bEnabled;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lb", &u1Point, &bEnabled) == SUCCESS)
	{
		SBCheckError(TElECPointSSLExtension_SetPointType(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Point, (int8_t)bEnabled) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECPointSSLExtension, GetPointType)
{
	sb_zend_long u1Point;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1Point) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElECPointSSLExtension_GetPointType(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Point, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElECPointSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElECPointSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECPointSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECPointSSLExtension_SetPointType, 0, 0, 2)
	ZEND_ARG_INFO(0, Point)
	ZEND_ARG_INFO(0, Enabled)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECPointSSLExtension_GetPointType, 0, 0, 1)
	ZEND_ARG_INFO(0, Point)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElECPointSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElECPointSSLExtension_methods[] = {
	PHP_ME(TElECPointSSLExtension, Assign, arginfo_TElECPointSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElECPointSSLExtension, SetPointType, arginfo_TElECPointSSLExtension_SetPointType, ZEND_ACC_PUBLIC)
	PHP_ME(TElECPointSSLExtension, GetPointType, arginfo_TElECPointSSLExtension_GetPointType, ZEND_ACC_PUBLIC)
	PHP_ME(TElECPointSSLExtension, __construct, arginfo_TElECPointSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElECPointSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElECPointSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElECPointSSLExtension", TElECPointSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElECPointSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElCertificateTypeResponse_ce_ptr = NULL;

SB_PHP_METHOD(TElCertificateTypeResponse, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCertificateTypeResponse_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateTypeResponse, get_CertType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElSSLCertificateTypeRaw fOutResultRaw = 0;
		SBCheckError(TElCertificateTypeResponse_get_CertType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateTypeResponse, set_CertType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElCertificateTypeResponse_set_CertType(SBGetObjectHandle(getThis() TSRMLS_CC), (TElSSLCertificateTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateTypeResponse, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCertificateTypeResponse_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateTypeResponse_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateTypeResponse_get_CertType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateTypeResponse_set_CertType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateTypeResponse___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElCertificateTypeResponse_methods[] = {
	PHP_ME(TElCertificateTypeResponse, Assign, arginfo_TElCertificateTypeResponse_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateTypeResponse, get_CertType, arginfo_TElCertificateTypeResponse_get_CertType, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateTypeResponse, set_CertType, arginfo_TElCertificateTypeResponse_set_CertType, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateTypeResponse, __construct, arginfo_TElCertificateTypeResponse___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCertificateTypeResponse(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCertificateTypeResponse_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCertificateTypeResponse", TElCertificateTypeResponse_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElCertificateTypeResponse_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElCertificateTypeRequest_ce_ptr = NULL;

SB_PHP_METHOD(TElCertificateTypeRequest, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCertificateTypeRequest_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateTypeRequest, AddCertType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElCertificateTypeRequest_AddCertType(SBGetObjectHandle(getThis() TSRMLS_CC), (TElSSLCertificateTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateTypeRequest, DelCertType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElCertificateTypeRequest_DelCertType(SBGetObjectHandle(getThis() TSRMLS_CC), (TElSSLCertificateTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateTypeRequest, GetCertTypesCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCertificateTypeRequest_GetCertTypesCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateTypeRequest, ClearCertTypes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCertificateTypeRequest_ClearCertTypes(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateTypeRequest, CheckCertType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCertificateTypeRequest_CheckCertType(SBGetObjectHandle(getThis() TSRMLS_CC), (TElSSLCertificateTypeRaw)fValue, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateTypeRequest, GetBaseCertType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElSSLCertificateTypeRaw fOutResultRaw = 0;
		SBCheckError(TElCertificateTypeRequest_GetBaseCertType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateTypeRequest, get_CertTypes)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElSSLCertificateTypeRaw fOutResultRaw = 0;
		SBCheckError(TElCertificateTypeRequest_get_CertTypes(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateTypeRequest, set_CertTypes)
{
	sb_zend_long fValue;
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4Index, &fValue) == SUCCESS)
	{
		SBCheckError(TElCertificateTypeRequest_set_CertTypes(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (TElSSLCertificateTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateTypeRequest, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCertificateTypeRequest_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateTypeRequest_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateTypeRequest_AddCertType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateTypeRequest_DelCertType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateTypeRequest_GetCertTypesCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateTypeRequest_ClearCertTypes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateTypeRequest_CheckCertType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateTypeRequest_GetBaseCertType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateTypeRequest_get_CertTypes, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateTypeRequest_set_CertTypes, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateTypeRequest___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElCertificateTypeRequest_methods[] = {
	PHP_ME(TElCertificateTypeRequest, Assign, arginfo_TElCertificateTypeRequest_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateTypeRequest, AddCertType, arginfo_TElCertificateTypeRequest_AddCertType, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateTypeRequest, DelCertType, arginfo_TElCertificateTypeRequest_DelCertType, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateTypeRequest, GetCertTypesCount, arginfo_TElCertificateTypeRequest_GetCertTypesCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateTypeRequest, ClearCertTypes, arginfo_TElCertificateTypeRequest_ClearCertTypes, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateTypeRequest, CheckCertType, arginfo_TElCertificateTypeRequest_CheckCertType, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateTypeRequest, GetBaseCertType, arginfo_TElCertificateTypeRequest_GetBaseCertType, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateTypeRequest, get_CertTypes, arginfo_TElCertificateTypeRequest_get_CertTypes, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateTypeRequest, set_CertTypes, arginfo_TElCertificateTypeRequest_set_CertTypes, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateTypeRequest, __construct, arginfo_TElCertificateTypeRequest___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCertificateTypeRequest(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCertificateTypeRequest_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCertificateTypeRequest", TElCertificateTypeRequest_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElCertificateTypeRequest_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElExtendedMasterSecretExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElExtendedMasterSecretExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElExtendedMasterSecretExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElExtendedMasterSecretExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElExtendedMasterSecretExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElExtendedMasterSecretExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElExtendedMasterSecretExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElExtendedMasterSecretExtension_methods[] = {
	PHP_ME(TElExtendedMasterSecretExtension, Assign, arginfo_TElExtendedMasterSecretExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElExtendedMasterSecretExtension, __construct, arginfo_TElExtendedMasterSecretExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElExtendedMasterSecretExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElExtendedMasterSecretExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElExtendedMasterSecretExtension", TElExtendedMasterSecretExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElExtendedMasterSecretExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElMaxFragmentLengthSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElMaxFragmentLengthSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElMaxFragmentLengthSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMaxFragmentLengthSSLExtension, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElMaxFragmentLengthSSLExtension_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMaxFragmentLengthSSLExtension, get_MaxLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBSSLFragmentLengthRaw fOutResultRaw = 0;
		SBCheckError(TElMaxFragmentLengthSSLExtension_get_MaxLength(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMaxFragmentLengthSSLExtension, set_MaxLength)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElMaxFragmentLengthSSLExtension_set_MaxLength(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBSSLFragmentLengthRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElMaxFragmentLengthSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElMaxFragmentLengthSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMaxFragmentLengthSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMaxFragmentLengthSSLExtension_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMaxFragmentLengthSSLExtension_get_MaxLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMaxFragmentLengthSSLExtension_set_MaxLength, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElMaxFragmentLengthSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElMaxFragmentLengthSSLExtension_methods[] = {
	PHP_ME(TElMaxFragmentLengthSSLExtension, Assign, arginfo_TElMaxFragmentLengthSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElMaxFragmentLengthSSLExtension, Clear, arginfo_TElMaxFragmentLengthSSLExtension_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElMaxFragmentLengthSSLExtension, get_MaxLength, arginfo_TElMaxFragmentLengthSSLExtension_get_MaxLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElMaxFragmentLengthSSLExtension, set_MaxLength, arginfo_TElMaxFragmentLengthSSLExtension_set_MaxLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElMaxFragmentLengthSSLExtension, __construct, arginfo_TElMaxFragmentLengthSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElMaxFragmentLengthSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElMaxFragmentLengthSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElMaxFragmentLengthSSLExtension", TElMaxFragmentLengthSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElMaxFragmentLengthSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElSSLCertURL_ce_ptr = NULL;

SB_PHP_METHOD(TElSSLCertURL, get_URL)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSSLCertURL_get_URL(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1706500207, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertURL, set_URL)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSSLCertURL_set_URL(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertURL, get_Hash)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSSLCertURL_get_Hash(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(410778832, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertURL, set_Hash)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSLCertURL_set_Hash(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertURL, get_PrivateKey)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLCertURL_get_PrivateKey(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElPublicKeyMaterial_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertURL, set_PrivateKey)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElPublicKeyMaterial_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSLCertURL_set_PrivateKey(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElPublicKeyMaterial)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLCertURL, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLCertURL_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertURL_get_URL, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertURL_set_URL, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertURL_get_Hash, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertURL_set_Hash, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertURL_get_PrivateKey, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertURL_set_PrivateKey, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElPublicKeyMaterial, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLCertURL___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSLCertURL_methods[] = {
	PHP_ME(TElSSLCertURL, get_URL, arginfo_TElSSLCertURL_get_URL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertURL, set_URL, arginfo_TElSSLCertURL_set_URL, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertURL, get_Hash, arginfo_TElSSLCertURL_get_Hash, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertURL, set_Hash, arginfo_TElSSLCertURL_set_Hash, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertURL, get_PrivateKey, arginfo_TElSSLCertURL_get_PrivateKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertURL, set_PrivateKey, arginfo_TElSSLCertURL_set_PrivateKey, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLCertURL, __construct, arginfo_TElSSLCertURL___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSLCertURL(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSLCertURL_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSLCertURL", TElSSLCertURL_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSSLCertURL_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElClientCertURLsSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElClientCertURLsSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElClientCertURLsSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientCertURLsSSLExtension, Add)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElClientCertURLsSSLExtension_Add(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientCertURLsSSLExtension, Remove)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElClientCertURLsSSLExtension_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientCertURLsSSLExtension, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElClientCertURLsSSLExtension_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientCertURLsSSLExtension, get_ChainType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCertChainTypeRaw fOutResultRaw = 0;
		SBCheckError(TElClientCertURLsSSLExtension_get_ChainType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientCertURLsSSLExtension, set_ChainType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElClientCertURLsSSLExtension_set_ChainType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBCertChainTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientCertURLsSSLExtension, get_URLs)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElClientCertURLsSSLExtension_get_URLs(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSLCertURL_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientCertURLsSSLExtension, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElClientCertURLsSSLExtension_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientCertURLsSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElClientCertURLsSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientCertURLsSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientCertURLsSSLExtension_Add, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientCertURLsSSLExtension_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientCertURLsSSLExtension_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientCertURLsSSLExtension_get_ChainType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientCertURLsSSLExtension_set_ChainType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientCertURLsSSLExtension_get_URLs, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientCertURLsSSLExtension_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientCertURLsSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElClientCertURLsSSLExtension_methods[] = {
	PHP_ME(TElClientCertURLsSSLExtension, Assign, arginfo_TElClientCertURLsSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientCertURLsSSLExtension, Add, arginfo_TElClientCertURLsSSLExtension_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientCertURLsSSLExtension, Remove, arginfo_TElClientCertURLsSSLExtension_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientCertURLsSSLExtension, Clear, arginfo_TElClientCertURLsSSLExtension_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientCertURLsSSLExtension, get_ChainType, arginfo_TElClientCertURLsSSLExtension_get_ChainType, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientCertURLsSSLExtension, set_ChainType, arginfo_TElClientCertURLsSSLExtension_set_ChainType, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientCertURLsSSLExtension, get_URLs, arginfo_TElClientCertURLsSSLExtension_get_URLs, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientCertURLsSSLExtension, get_Count, arginfo_TElClientCertURLsSSLExtension_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientCertURLsSSLExtension, __construct, arginfo_TElClientCertURLsSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElClientCertURLsSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElClientCertURLsSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElClientCertURLsSSLExtension", TElClientCertURLsSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElClientCertURLsSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElSSLTrustedCA_ce_ptr = NULL;

SB_PHP_METHOD(TElSSLTrustedCA, Import)
{
	zval *oCert;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCert, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSSLTrustedCA_Import(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLTrustedCA, get_IdentifierType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCAIdentifierTypeRaw fOutResultRaw = 0;
		SBCheckError(TElSSLTrustedCA_get_IdentifierType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLTrustedCA, set_IdentifierType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElSSLTrustedCA_set_IdentifierType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBCAIdentifierTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLTrustedCA, get_Value)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSSLTrustedCA_get_Value(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1684255819, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLTrustedCA, set_Value)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSLTrustedCA_set_Value(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLTrustedCA, get_RDN)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLTrustedCA_get_RDN(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElRelativeDistinguishedName_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLTrustedCA, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLTrustedCA_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLTrustedCA_Import, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLTrustedCA_get_IdentifierType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLTrustedCA_set_IdentifierType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLTrustedCA_get_Value, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLTrustedCA_set_Value, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLTrustedCA_get_RDN, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLTrustedCA___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSLTrustedCA_methods[] = {
	PHP_ME(TElSSLTrustedCA, Import, arginfo_TElSSLTrustedCA_Import, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLTrustedCA, get_IdentifierType, arginfo_TElSSLTrustedCA_get_IdentifierType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLTrustedCA, set_IdentifierType, arginfo_TElSSLTrustedCA_set_IdentifierType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLTrustedCA, get_Value, arginfo_TElSSLTrustedCA_get_Value, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLTrustedCA, set_Value, arginfo_TElSSLTrustedCA_set_Value, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLTrustedCA, get_RDN, arginfo_TElSSLTrustedCA_get_RDN, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLTrustedCA, __construct, arginfo_TElSSLTrustedCA___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSLTrustedCA(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSLTrustedCA_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSLTrustedCA", TElSSLTrustedCA_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSSLTrustedCA_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElTrustedCAsSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElTrustedCAsSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElTrustedCAsSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTrustedCAsSSLExtension, Add)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElTrustedCAsSSLExtension_Add(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTrustedCAsSSLExtension, Remove)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElTrustedCAsSSLExtension_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTrustedCAsSSLExtension, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElTrustedCAsSSLExtension_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTrustedCAsSSLExtension, get_TrustedCAs)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElTrustedCAsSSLExtension_get_TrustedCAs(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSLTrustedCA_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTrustedCAsSSLExtension, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElTrustedCAsSSLExtension_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTrustedCAsSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElTrustedCAsSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTrustedCAsSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTrustedCAsSSLExtension_Add, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTrustedCAsSSLExtension_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTrustedCAsSSLExtension_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTrustedCAsSSLExtension_get_TrustedCAs, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTrustedCAsSSLExtension_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTrustedCAsSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElTrustedCAsSSLExtension_methods[] = {
	PHP_ME(TElTrustedCAsSSLExtension, Assign, arginfo_TElTrustedCAsSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElTrustedCAsSSLExtension, Add, arginfo_TElTrustedCAsSSLExtension_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElTrustedCAsSSLExtension, Remove, arginfo_TElTrustedCAsSSLExtension_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElTrustedCAsSSLExtension, Clear, arginfo_TElTrustedCAsSSLExtension_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElTrustedCAsSSLExtension, get_TrustedCAs, arginfo_TElTrustedCAsSSLExtension_get_TrustedCAs, ZEND_ACC_PUBLIC)
	PHP_ME(TElTrustedCAsSSLExtension, get_Count, arginfo_TElTrustedCAsSSLExtension_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElTrustedCAsSSLExtension, __construct, arginfo_TElTrustedCAsSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElTrustedCAsSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElTrustedCAsSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElTrustedCAsSSLExtension", TElTrustedCAsSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElTrustedCAsSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElTruncatedHMACSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElTruncatedHMACSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElTruncatedHMACSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElTruncatedHMACSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElTruncatedHMACSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTruncatedHMACSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElTruncatedHMACSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElTruncatedHMACSSLExtension_methods[] = {
	PHP_ME(TElTruncatedHMACSSLExtension, Assign, arginfo_TElTruncatedHMACSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElTruncatedHMACSSLExtension, __construct, arginfo_TElTruncatedHMACSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElTruncatedHMACSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElTruncatedHMACSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElTruncatedHMACSSLExtension", TElTruncatedHMACSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElTruncatedHMACSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElSSLOCSPStatusRequest_ce_ptr = NULL;

SB_PHP_METHOD(TElSSLOCSPStatusRequest, get_ResponderIDs)
{
	sb_zend_long l4Index;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSSLOCSPStatusRequest_get_ResponderIDs(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1476514730, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLOCSPStatusRequest, set_ResponderIDs)
{
	sb_zend_long l4Index;
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &l4Index, &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSLOCSPStatusRequest_set_ResponderIDs(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(integer, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLOCSPStatusRequest, get_ResponderIDCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLOCSPStatusRequest_get_ResponderIDCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLOCSPStatusRequest, set_ResponderIDCount)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSLOCSPStatusRequest_set_ResponderIDCount(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLOCSPStatusRequest, get_Extensions)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSSLOCSPStatusRequest_get_Extensions(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-2034806002, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLOCSPStatusRequest, set_Extensions)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSLOCSPStatusRequest_set_Extensions(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLOCSPStatusRequest, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLOCSPStatusRequest_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLOCSPStatusRequest_get_ResponderIDs, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLOCSPStatusRequest_set_ResponderIDs, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLOCSPStatusRequest_get_ResponderIDCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLOCSPStatusRequest_set_ResponderIDCount, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLOCSPStatusRequest_get_Extensions, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLOCSPStatusRequest_set_Extensions, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLOCSPStatusRequest___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSLOCSPStatusRequest_methods[] = {
	PHP_ME(TElSSLOCSPStatusRequest, get_ResponderIDs, arginfo_TElSSLOCSPStatusRequest_get_ResponderIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLOCSPStatusRequest, set_ResponderIDs, arginfo_TElSSLOCSPStatusRequest_set_ResponderIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLOCSPStatusRequest, get_ResponderIDCount, arginfo_TElSSLOCSPStatusRequest_get_ResponderIDCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLOCSPStatusRequest, set_ResponderIDCount, arginfo_TElSSLOCSPStatusRequest_set_ResponderIDCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLOCSPStatusRequest, get_Extensions, arginfo_TElSSLOCSPStatusRequest_get_Extensions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLOCSPStatusRequest, set_Extensions, arginfo_TElSSLOCSPStatusRequest_set_Extensions, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLOCSPStatusRequest, __construct, arginfo_TElSSLOCSPStatusRequest___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSLOCSPStatusRequest(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSLOCSPStatusRequest_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSLOCSPStatusRequest", TElSSLOCSPStatusRequest_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSSLOCSPStatusRequest_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElCertificateStatusSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElCertificateStatusSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCertificateStatusSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCertificateStatusSSLExtension_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, AddOCSPStatusRequest)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCertificateStatusSSLExtension_AddOCSPStatusRequest(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, RemoveOCSPStatusRequest)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElCertificateStatusSSLExtension_RemoveOCSPStatusRequest(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, get_StatusType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBCertificateStatusTypeRaw fOutResultRaw = 0;
		SBCheckError(TElCertificateStatusSSLExtension_get_StatusType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, set_StatusType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElCertificateStatusSSLExtension_set_StatusType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBCertificateStatusTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, get_OCSPStatusRequest)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCertificateStatusSSLExtension_get_OCSPStatusRequest(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSLOCSPStatusRequest_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, get_OCSPStatusRequests)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCertificateStatusSSLExtension_get_OCSPStatusRequests(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSSLOCSPStatusRequest_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, get_OCSPStatusRequestCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCertificateStatusSSLExtension_get_OCSPStatusRequestCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, get_OCSPResponse)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElCertificateStatusSSLExtension_get_OCSPResponse(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(108182410, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, set_OCSPResponse)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCertificateStatusSSLExtension_set_OCSPResponse(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, get_OCSPResponses)
{
	sb_zend_long l4Index;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElCertificateStatusSSLExtension_get_OCSPResponses(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(2105687926, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, set_OCSPResponses)
{
	sb_zend_long l4Index;
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &l4Index, &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElCertificateStatusSSLExtension_set_OCSPResponses(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(integer, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, get_OCSPResponseCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCertificateStatusSSLExtension_get_OCSPResponseCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, set_OCSPResponseCount)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElCertificateStatusSSLExtension_set_OCSPResponseCount(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertificateStatusSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCertificateStatusSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_AddOCSPStatusRequest, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_RemoveOCSPStatusRequest, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_get_StatusType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_set_StatusType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_get_OCSPStatusRequest, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_get_OCSPStatusRequests, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_get_OCSPStatusRequestCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_get_OCSPResponse, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_set_OCSPResponse, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_get_OCSPResponses, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_set_OCSPResponses, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_get_OCSPResponseCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension_set_OCSPResponseCount, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertificateStatusSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElCertificateStatusSSLExtension_methods[] = {
	PHP_ME(TElCertificateStatusSSLExtension, Assign, arginfo_TElCertificateStatusSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, Clear, arginfo_TElCertificateStatusSSLExtension_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, AddOCSPStatusRequest, arginfo_TElCertificateStatusSSLExtension_AddOCSPStatusRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, RemoveOCSPStatusRequest, arginfo_TElCertificateStatusSSLExtension_RemoveOCSPStatusRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, get_StatusType, arginfo_TElCertificateStatusSSLExtension_get_StatusType, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, set_StatusType, arginfo_TElCertificateStatusSSLExtension_set_StatusType, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, get_OCSPStatusRequest, arginfo_TElCertificateStatusSSLExtension_get_OCSPStatusRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, get_OCSPStatusRequests, arginfo_TElCertificateStatusSSLExtension_get_OCSPStatusRequests, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, get_OCSPStatusRequestCount, arginfo_TElCertificateStatusSSLExtension_get_OCSPStatusRequestCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, get_OCSPResponse, arginfo_TElCertificateStatusSSLExtension_get_OCSPResponse, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, set_OCSPResponse, arginfo_TElCertificateStatusSSLExtension_set_OCSPResponse, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, get_OCSPResponses, arginfo_TElCertificateStatusSSLExtension_get_OCSPResponses, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, set_OCSPResponses, arginfo_TElCertificateStatusSSLExtension_set_OCSPResponses, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, get_OCSPResponseCount, arginfo_TElCertificateStatusSSLExtension_get_OCSPResponseCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, set_OCSPResponseCount, arginfo_TElCertificateStatusSSLExtension_set_OCSPResponseCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertificateStatusSSLExtension, __construct, arginfo_TElCertificateStatusSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCertificateStatusSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCertificateStatusSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCertificateStatusSSLExtension", TElCertificateStatusSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElCertificateStatusSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElSessionTicketSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSessionTicketSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSessionTicketSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSessionTicketSSLExtension, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSessionTicketSSLExtension_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSessionTicketSSLExtension, get_Ticket)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElSessionTicketSSLExtension_get_Ticket(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1062732076, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSessionTicketSSLExtension, set_Ticket)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSessionTicketSSLExtension_set_Ticket(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSessionTicketSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSessionTicketSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSessionTicketSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSessionTicketSSLExtension_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSessionTicketSSLExtension_get_Ticket, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSessionTicketSSLExtension_set_Ticket, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSessionTicketSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSessionTicketSSLExtension_methods[] = {
	PHP_ME(TElSessionTicketSSLExtension, Assign, arginfo_TElSessionTicketSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSessionTicketSSLExtension, Clear, arginfo_TElSessionTicketSSLExtension_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElSessionTicketSSLExtension, get_Ticket, arginfo_TElSessionTicketSSLExtension_get_Ticket, ZEND_ACC_PUBLIC)
	PHP_ME(TElSessionTicketSSLExtension, set_Ticket, arginfo_TElSessionTicketSSLExtension_set_Ticket, ZEND_ACC_PUBLIC)
	PHP_ME(TElSessionTicketSSLExtension, __construct, arginfo_TElSessionTicketSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSessionTicketSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSessionTicketSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSessionTicketSSLExtension", TElSessionTicketSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElSessionTicketSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElCertHashTypesSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElCertHashTypesSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCertHashTypesSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertHashTypesSSLExtension, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCertHashTypesSSLExtension_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertHashTypesSSLExtension, SwitchAll)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCertHashTypesSSLExtension_SwitchAll(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertHashTypesSSLExtension, get_MD5)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCertHashTypesSSLExtension_get_MD5(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertHashTypesSSLExtension, set_MD5)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCertHashTypesSSLExtension_set_MD5(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertHashTypesSSLExtension, get_SHA1)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCertHashTypesSSLExtension_get_SHA1(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertHashTypesSSLExtension, set_SHA1)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCertHashTypesSSLExtension_set_SHA1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertHashTypesSSLExtension, get_SHA256)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCertHashTypesSSLExtension_get_SHA256(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertHashTypesSSLExtension, set_SHA256)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCertHashTypesSSLExtension_set_SHA256(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertHashTypesSSLExtension, get_SHA384)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCertHashTypesSSLExtension_get_SHA384(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertHashTypesSSLExtension, set_SHA384)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCertHashTypesSSLExtension_set_SHA384(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertHashTypesSSLExtension, get_SHA512)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCertHashTypesSSLExtension_get_SHA512(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertHashTypesSSLExtension, set_SHA512)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCertHashTypesSSLExtension_set_SHA512(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCertHashTypesSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCertHashTypesSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertHashTypesSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertHashTypesSSLExtension_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertHashTypesSSLExtension_SwitchAll, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertHashTypesSSLExtension_get_MD5, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertHashTypesSSLExtension_set_MD5, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertHashTypesSSLExtension_get_SHA1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertHashTypesSSLExtension_set_SHA1, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertHashTypesSSLExtension_get_SHA256, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertHashTypesSSLExtension_set_SHA256, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertHashTypesSSLExtension_get_SHA384, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertHashTypesSSLExtension_set_SHA384, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertHashTypesSSLExtension_get_SHA512, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertHashTypesSSLExtension_set_SHA512, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCertHashTypesSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElCertHashTypesSSLExtension_methods[] = {
	PHP_ME(TElCertHashTypesSSLExtension, Assign, arginfo_TElCertHashTypesSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertHashTypesSSLExtension, Clear, arginfo_TElCertHashTypesSSLExtension_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertHashTypesSSLExtension, SwitchAll, arginfo_TElCertHashTypesSSLExtension_SwitchAll, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertHashTypesSSLExtension, get_MD5, arginfo_TElCertHashTypesSSLExtension_get_MD5, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertHashTypesSSLExtension, set_MD5, arginfo_TElCertHashTypesSSLExtension_set_MD5, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertHashTypesSSLExtension, get_SHA1, arginfo_TElCertHashTypesSSLExtension_get_SHA1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertHashTypesSSLExtension, set_SHA1, arginfo_TElCertHashTypesSSLExtension_set_SHA1, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertHashTypesSSLExtension, get_SHA256, arginfo_TElCertHashTypesSSLExtension_get_SHA256, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertHashTypesSSLExtension, set_SHA256, arginfo_TElCertHashTypesSSLExtension_set_SHA256, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertHashTypesSSLExtension, get_SHA384, arginfo_TElCertHashTypesSSLExtension_get_SHA384, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertHashTypesSSLExtension, set_SHA384, arginfo_TElCertHashTypesSSLExtension_set_SHA384, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertHashTypesSSLExtension, get_SHA512, arginfo_TElCertHashTypesSSLExtension_get_SHA512, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertHashTypesSSLExtension, set_SHA512, arginfo_TElCertHashTypesSSLExtension_set_SHA512, ZEND_ACC_PUBLIC)
	PHP_ME(TElCertHashTypesSSLExtension, __construct, arginfo_TElCertHashTypesSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCertHashTypesSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCertHashTypesSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCertHashTypesSSLExtension", TElCertHashTypesSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElCertHashTypesSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElRenegotiationInfoSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElRenegotiationInfoSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElRenegotiationInfoSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRenegotiationInfoSSLExtension, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElRenegotiationInfoSSLExtension_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRenegotiationInfoSSLExtension, get_Info)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElRenegotiationInfoSSLExtension_get_Info(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1989620118, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRenegotiationInfoSSLExtension, set_Info)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElRenegotiationInfoSSLExtension_set_Info(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRenegotiationInfoSSLExtension, get_UseSignalingCipherSuite)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElRenegotiationInfoSSLExtension_get_UseSignalingCipherSuite(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRenegotiationInfoSSLExtension, set_UseSignalingCipherSuite)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElRenegotiationInfoSSLExtension_set_UseSignalingCipherSuite(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElRenegotiationInfoSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElRenegotiationInfoSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRenegotiationInfoSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRenegotiationInfoSSLExtension_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRenegotiationInfoSSLExtension_get_Info, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRenegotiationInfoSSLExtension_set_Info, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRenegotiationInfoSSLExtension_get_UseSignalingCipherSuite, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRenegotiationInfoSSLExtension_set_UseSignalingCipherSuite, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElRenegotiationInfoSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElRenegotiationInfoSSLExtension_methods[] = {
	PHP_ME(TElRenegotiationInfoSSLExtension, Assign, arginfo_TElRenegotiationInfoSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElRenegotiationInfoSSLExtension, Clear, arginfo_TElRenegotiationInfoSSLExtension_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElRenegotiationInfoSSLExtension, get_Info, arginfo_TElRenegotiationInfoSSLExtension_get_Info, ZEND_ACC_PUBLIC)
	PHP_ME(TElRenegotiationInfoSSLExtension, set_Info, arginfo_TElRenegotiationInfoSSLExtension_set_Info, ZEND_ACC_PUBLIC)
	PHP_ME(TElRenegotiationInfoSSLExtension, get_UseSignalingCipherSuite, arginfo_TElRenegotiationInfoSSLExtension_get_UseSignalingCipherSuite, ZEND_ACC_PUBLIC)
	PHP_ME(TElRenegotiationInfoSSLExtension, set_UseSignalingCipherSuite, arginfo_TElRenegotiationInfoSSLExtension_set_UseSignalingCipherSuite, ZEND_ACC_PUBLIC)
	PHP_ME(TElRenegotiationInfoSSLExtension, __construct, arginfo_TElRenegotiationInfoSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElRenegotiationInfoSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElRenegotiationInfoSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElRenegotiationInfoSSLExtension", TElRenegotiationInfoSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElRenegotiationInfoSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElSignatureAlgorithmsSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSignatureAlgorithmsSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSignatureAlgorithmsSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSignatureAlgorithmsSSLExtension, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSignatureAlgorithmsSSLExtension_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSignatureAlgorithmsSSLExtension, EnableAllSupported)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSignatureAlgorithmsSSLExtension_EnableAllSupported(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSignatureAlgorithmsSSLExtension, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSignatureAlgorithmsSSLExtension_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSignatureAlgorithmsSSLExtension, set_Count)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSignatureAlgorithmsSSLExtension_set_Count(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSignatureAlgorithmsSSLExtension, get_HashAlgorithms)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSignatureAlgorithmsSSLExtension_get_HashAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSignatureAlgorithmsSSLExtension, set_HashAlgorithms)
{
	sb_zend_long l4Index;
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4Index, &l4Value) == SUCCESS)
	{
		SBCheckError(TElSignatureAlgorithmsSSLExtension_set_HashAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSignatureAlgorithmsSSLExtension, get_SignatureAlgorithms)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSignatureAlgorithmsSSLExtension_get_SignatureAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSignatureAlgorithmsSSLExtension, set_SignatureAlgorithms)
{
	sb_zend_long l4Index;
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ll", &l4Index, &l4Value) == SUCCESS)
	{
		SBCheckError(TElSignatureAlgorithmsSSLExtension_set_SignatureAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSignatureAlgorithmsSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSignatureAlgorithmsSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSignatureAlgorithmsSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSignatureAlgorithmsSSLExtension_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSignatureAlgorithmsSSLExtension_EnableAllSupported, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSignatureAlgorithmsSSLExtension_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSignatureAlgorithmsSSLExtension_set_Count, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSignatureAlgorithmsSSLExtension_get_HashAlgorithms, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSignatureAlgorithmsSSLExtension_set_HashAlgorithms, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSignatureAlgorithmsSSLExtension_get_SignatureAlgorithms, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSignatureAlgorithmsSSLExtension_set_SignatureAlgorithms, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSignatureAlgorithmsSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSignatureAlgorithmsSSLExtension_methods[] = {
	PHP_ME(TElSignatureAlgorithmsSSLExtension, Assign, arginfo_TElSignatureAlgorithmsSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSignatureAlgorithmsSSLExtension, Clear, arginfo_TElSignatureAlgorithmsSSLExtension_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElSignatureAlgorithmsSSLExtension, EnableAllSupported, arginfo_TElSignatureAlgorithmsSSLExtension_EnableAllSupported, ZEND_ACC_PUBLIC)
	PHP_ME(TElSignatureAlgorithmsSSLExtension, get_Count, arginfo_TElSignatureAlgorithmsSSLExtension_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElSignatureAlgorithmsSSLExtension, set_Count, arginfo_TElSignatureAlgorithmsSSLExtension_set_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElSignatureAlgorithmsSSLExtension, get_HashAlgorithms, arginfo_TElSignatureAlgorithmsSSLExtension_get_HashAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSignatureAlgorithmsSSLExtension, set_HashAlgorithms, arginfo_TElSignatureAlgorithmsSSLExtension_set_HashAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSignatureAlgorithmsSSLExtension, get_SignatureAlgorithms, arginfo_TElSignatureAlgorithmsSSLExtension_get_SignatureAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSignatureAlgorithmsSSLExtension, set_SignatureAlgorithms, arginfo_TElSignatureAlgorithmsSSLExtension_set_SignatureAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElSignatureAlgorithmsSSLExtension, __construct, arginfo_TElSignatureAlgorithmsSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSignatureAlgorithmsSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSignatureAlgorithmsSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSignatureAlgorithmsSSLExtension", TElSignatureAlgorithmsSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElSignatureAlgorithmsSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElSRPSSLExtension_ce_ptr = NULL;

SB_PHP_METHOD(TElSRPSSLExtension, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElSRPSSLExtension_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPSSLExtension, get_Name)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElSRPSSLExtension_get_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(9968603, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPSSLExtension, set_Name)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElSRPSSLExtension_set_Name(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSRPSSLExtension, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSRPSSLExtension_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPSSLExtension_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPSSLExtension_get_Name, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPSSLExtension_set_Name, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSRPSSLExtension___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSRPSSLExtension_methods[] = {
	PHP_ME(TElSRPSSLExtension, Assign, arginfo_TElSRPSSLExtension_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPSSLExtension, get_Name, arginfo_TElSRPSSLExtension_get_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPSSLExtension, set_Name, arginfo_TElSRPSSLExtension_set_Name, ZEND_ACC_PUBLIC)
	PHP_ME(TElSRPSSLExtension, __construct, arginfo_TElSRPSSLExtension___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSRPSSLExtension(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSRPSSLExtension_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSRPSSLExtension", TElSRPSSLExtension_methods);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	TElSRPSSLExtension_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtension_ce_ptr);
}

zend_class_entry *TElCustomSSLExtensions_ce_ptr = NULL;

SB_PHP_METHOD(TElCustomSSLExtensions, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtensions_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomSSLExtensions_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtensions)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCustomSSLExtensions_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, DisableAll)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElCustomSSLExtensions_DisableAll(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_CertificateStatus)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_CertificateStatus(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCertificateStatusSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_ClientCertURLs)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_ClientCertURLs(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElClientCertURLsSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_MaxFragmentLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_MaxFragmentLength(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElMaxFragmentLengthSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_OtherCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElCustomSSLExtensions_get_OtherCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, set_OtherCount)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElCustomSSLExtensions_set_OtherCount(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_OtherExtensions)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_OtherExtensions(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_ServerName)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_ServerName(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElServerNameSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_TruncatedHMAC)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_TruncatedHMAC(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElTruncatedHMACSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_TrustedCAs)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_TrustedCAs(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElTrustedCAsSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_UserName)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_UserName(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElUserNameSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_ECCurves)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_ECCurves(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElECCurveSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_ECPoints)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_ECPoints(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElECPointSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_StatelessTLS)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElCustomSSLExtensions_get_StatelessTLS(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, set_StatelessTLS)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElCustomSSLExtensions_set_StatelessTLS(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_CertHashTypes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_CertHashTypes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCertHashTypesSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_RenegotiationInfo)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_RenegotiationInfo(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElRenegotiationInfoSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, set_RenegotiationInfo)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElRenegotiationInfoSSLExtension_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElCustomSSLExtensions_set_RenegotiationInfo(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElRenegotiationInfoSSLExtension)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_Heartbeat)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_Heartbeat(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElHeartbeatHelloSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_SignatureAlgorithms)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_SignatureAlgorithms(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSignatureAlgorithmsSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_SRP)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_SRP(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElSRPSSLExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, get_ExtendedMasterSecret)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_get_ExtendedMasterSecret(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElExtendedMasterSecretExtension_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElCustomSSLExtensions, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElCustomSSLExtensions_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtensions, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_DisableAll, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_CertificateStatus, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_ClientCertURLs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_MaxFragmentLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_OtherCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_set_OtherCount, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_OtherExtensions, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_ServerName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_TruncatedHMAC, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_TrustedCAs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_UserName, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_ECCurves, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_ECPoints, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_StatelessTLS, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_set_StatelessTLS, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_CertHashTypes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_RenegotiationInfo, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_set_RenegotiationInfo, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElRenegotiationInfoSSLExtension, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_Heartbeat, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_SignatureAlgorithms, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_SRP, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions_get_ExtendedMasterSecret, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElCustomSSLExtensions___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElCustomSSLExtensions_methods[] = {
	PHP_ME(TElCustomSSLExtensions, Assign, arginfo_TElCustomSSLExtensions_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, Clear, arginfo_TElCustomSSLExtensions_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, DisableAll, arginfo_TElCustomSSLExtensions_DisableAll, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_CertificateStatus, arginfo_TElCustomSSLExtensions_get_CertificateStatus, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_ClientCertURLs, arginfo_TElCustomSSLExtensions_get_ClientCertURLs, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_MaxFragmentLength, arginfo_TElCustomSSLExtensions_get_MaxFragmentLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_OtherCount, arginfo_TElCustomSSLExtensions_get_OtherCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, set_OtherCount, arginfo_TElCustomSSLExtensions_set_OtherCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_OtherExtensions, arginfo_TElCustomSSLExtensions_get_OtherExtensions, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_ServerName, arginfo_TElCustomSSLExtensions_get_ServerName, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_TruncatedHMAC, arginfo_TElCustomSSLExtensions_get_TruncatedHMAC, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_TrustedCAs, arginfo_TElCustomSSLExtensions_get_TrustedCAs, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_UserName, arginfo_TElCustomSSLExtensions_get_UserName, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_ECCurves, arginfo_TElCustomSSLExtensions_get_ECCurves, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_ECPoints, arginfo_TElCustomSSLExtensions_get_ECPoints, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_StatelessTLS, arginfo_TElCustomSSLExtensions_get_StatelessTLS, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, set_StatelessTLS, arginfo_TElCustomSSLExtensions_set_StatelessTLS, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_CertHashTypes, arginfo_TElCustomSSLExtensions_get_CertHashTypes, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_RenegotiationInfo, arginfo_TElCustomSSLExtensions_get_RenegotiationInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, set_RenegotiationInfo, arginfo_TElCustomSSLExtensions_set_RenegotiationInfo, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_Heartbeat, arginfo_TElCustomSSLExtensions_get_Heartbeat, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_SignatureAlgorithms, arginfo_TElCustomSSLExtensions_get_SignatureAlgorithms, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_SRP, arginfo_TElCustomSSLExtensions_get_SRP, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, get_ExtendedMasterSecret, arginfo_TElCustomSSLExtensions_get_ExtendedMasterSecret, ZEND_ACC_PUBLIC)
	PHP_ME(TElCustomSSLExtensions, __construct, arginfo_TElCustomSSLExtensions___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElCustomSSLExtensions(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElCustomSSLExtensions_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElCustomSSLExtensions", TElCustomSSLExtensions_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElCustomSSLExtensions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElClientSSLExtensions_ce_ptr = NULL;

SB_PHP_METHOD(TElClientSSLExtensions, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtensions_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElClientSSLExtensions_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtensions)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientSSLExtensions, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElClientSSLExtensions_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientSSLExtensions, DisableAll)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElClientSSLExtensions_DisableAll(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientSSLExtensions, ClearAcceptableCAs)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElClientSSLExtensions_ClearAcceptableCAs(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientSSLExtensions, AddAcceptableCAs)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElClientSSLExtensions_AddAcceptableCAs(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientSSLExtensions, get_AcceptableCAs)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElClientSSLExtensions_get_AcceptableCAs(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElRelativeDistinguishedName_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientSSLExtensions, get_AcceptableCACount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElClientSSLExtensions_get_AcceptableCACount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientSSLExtensions, get_FallbackConnection)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElClientSSLExtensions_get_FallbackConnection(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientSSLExtensions, set_FallbackConnection)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElClientSSLExtensions_set_FallbackConnection(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientSSLExtensions, get_ServerCertificateType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElClientSSLExtensions_get_ServerCertificateType(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCertificateTypeRequest_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientSSLExtensions, get_ClientCertificateType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElClientSSLExtensions_get_ClientCertificateType(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCertificateTypeRequest_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElClientSSLExtensions, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElClientSSLExtensions_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientSSLExtensions_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtensions, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientSSLExtensions_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientSSLExtensions_DisableAll, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientSSLExtensions_ClearAcceptableCAs, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientSSLExtensions_AddAcceptableCAs, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElRelativeDistinguishedName, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientSSLExtensions_get_AcceptableCAs, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientSSLExtensions_get_AcceptableCACount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientSSLExtensions_get_FallbackConnection, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientSSLExtensions_set_FallbackConnection, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientSSLExtensions_get_ServerCertificateType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientSSLExtensions_get_ClientCertificateType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElClientSSLExtensions___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElClientSSLExtensions_methods[] = {
	PHP_ME(TElClientSSLExtensions, Assign, arginfo_TElClientSSLExtensions_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientSSLExtensions, Clear, arginfo_TElClientSSLExtensions_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientSSLExtensions, DisableAll, arginfo_TElClientSSLExtensions_DisableAll, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientSSLExtensions, ClearAcceptableCAs, arginfo_TElClientSSLExtensions_ClearAcceptableCAs, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientSSLExtensions, AddAcceptableCAs, arginfo_TElClientSSLExtensions_AddAcceptableCAs, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientSSLExtensions, get_AcceptableCAs, arginfo_TElClientSSLExtensions_get_AcceptableCAs, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientSSLExtensions, get_AcceptableCACount, arginfo_TElClientSSLExtensions_get_AcceptableCACount, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientSSLExtensions, get_FallbackConnection, arginfo_TElClientSSLExtensions_get_FallbackConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientSSLExtensions, set_FallbackConnection, arginfo_TElClientSSLExtensions_set_FallbackConnection, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientSSLExtensions, get_ServerCertificateType, arginfo_TElClientSSLExtensions_get_ServerCertificateType, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientSSLExtensions, get_ClientCertificateType, arginfo_TElClientSSLExtensions_get_ClientCertificateType, ZEND_ACC_PUBLIC)
	PHP_ME(TElClientSSLExtensions, __construct, arginfo_TElClientSSLExtensions___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElClientSSLExtensions(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElClientSSLExtensions_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElClientSSLExtensions", TElClientSSLExtensions_methods);
	if (NULL == TElCustomSSLExtensions_ce_ptr)
		Register_TElCustomSSLExtensions(TSRMLS_C);
	TElClientSSLExtensions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtensions_ce_ptr);
}

zend_class_entry *TElServerSSLExtensions_ce_ptr = NULL;

SB_PHP_METHOD(TElServerSSLExtensions, Assign)
{
	zval *oSource;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSource, TElCustomSSLExtensions_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElServerSSLExtensions_Assign(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSource TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomSSLExtensions)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerSSLExtensions, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElServerSSLExtensions_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerSSLExtensions, DisableAll)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElServerSSLExtensions_DisableAll(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerSSLExtensions, get_StrictCertRequest)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElServerSSLExtensions_get_StrictCertRequest(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerSSLExtensions, set_StrictCertRequest)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElServerSSLExtensions_set_StrictCertRequest(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerSSLExtensions, get_PSKIdentityHint)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElServerSSLExtensions_get_PSKIdentityHint(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1183442600, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerSSLExtensions, set_PSKIdentityHint)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElServerSSLExtensions_set_PSKIdentityHint(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerSSLExtensions, get_ServerCertificateType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElServerSSLExtensions_get_ServerCertificateType(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCertificateTypeResponse_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerSSLExtensions, get_ClientCertificateType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElServerSSLExtensions_get_ClientCertificateType(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCertificateTypeResponse_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElServerSSLExtensions, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElServerSSLExtensions_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerSSLExtensions_Assign, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Source, TElCustomSSLExtensions, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerSSLExtensions_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerSSLExtensions_DisableAll, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerSSLExtensions_get_StrictCertRequest, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerSSLExtensions_set_StrictCertRequest, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerSSLExtensions_get_PSKIdentityHint, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerSSLExtensions_set_PSKIdentityHint, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerSSLExtensions_get_ServerCertificateType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerSSLExtensions_get_ClientCertificateType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElServerSSLExtensions___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElServerSSLExtensions_methods[] = {
	PHP_ME(TElServerSSLExtensions, Assign, arginfo_TElServerSSLExtensions_Assign, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerSSLExtensions, Clear, arginfo_TElServerSSLExtensions_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerSSLExtensions, DisableAll, arginfo_TElServerSSLExtensions_DisableAll, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerSSLExtensions, get_StrictCertRequest, arginfo_TElServerSSLExtensions_get_StrictCertRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerSSLExtensions, set_StrictCertRequest, arginfo_TElServerSSLExtensions_set_StrictCertRequest, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerSSLExtensions, get_PSKIdentityHint, arginfo_TElServerSSLExtensions_get_PSKIdentityHint, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerSSLExtensions, set_PSKIdentityHint, arginfo_TElServerSSLExtensions_set_PSKIdentityHint, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerSSLExtensions, get_ServerCertificateType, arginfo_TElServerSSLExtensions_get_ServerCertificateType, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerSSLExtensions, get_ClientCertificateType, arginfo_TElServerSSLExtensions_get_ClientCertificateType, ZEND_ACC_PUBLIC)
	PHP_ME(TElServerSSLExtensions, __construct, arginfo_TElServerSSLExtensions___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElServerSSLExtensions(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElServerSSLExtensions_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElServerSSLExtensions", TElServerSSLExtensions_methods);
	if (NULL == TElCustomSSLExtensions_ce_ptr)
		Register_TElCustomSSLExtensions(TSRMLS_C);
	TElServerSSLExtensions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomSSLExtensions_ce_ptr);
}

zend_class_entry *TElSSLRetransmissionTimer_ce_ptr = NULL;

SB_PHP_METHOD(TElSSLRetransmissionTimer, Start)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSSLRetransmissionTimer_Start(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLRetransmissionTimer, Stop)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElSSLRetransmissionTimer_Stop(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLRetransmissionTimer, get_Interval)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLRetransmissionTimer_get_Interval(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLRetransmissionTimer, set_Interval)
{
	sb_zend_long l4Value;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Value) == SUCCESS)
	{
		SBCheckError(TElSSLRetransmissionTimer_set_Interval(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Value) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLRetransmissionTimer, get_Enabled)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElSSLRetransmissionTimer_get_Enabled(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLRetransmissionTimer, get_OnTimer)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElSSLRetransmissionTimer_get_OnTimer(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLRetransmissionTimer, set_OnTimer)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElSSLRetransmissionTimer_set_OnTimer(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLRetransmissionTimer, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLRetransmissionTimer_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRetransmissionTimer_Start, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRetransmissionTimer_Stop, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRetransmissionTimer_get_Interval, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRetransmissionTimer_set_Interval, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRetransmissionTimer_get_Enabled, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRetransmissionTimer_get_OnTimer, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRetransmissionTimer_set_OnTimer, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRetransmissionTimer___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSLRetransmissionTimer_methods[] = {
	PHP_ME(TElSSLRetransmissionTimer, Start, arginfo_TElSSLRetransmissionTimer_Start, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLRetransmissionTimer, Stop, arginfo_TElSSLRetransmissionTimer_Stop, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLRetransmissionTimer, get_Interval, arginfo_TElSSLRetransmissionTimer_get_Interval, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLRetransmissionTimer, set_Interval, arginfo_TElSSLRetransmissionTimer_set_Interval, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLRetransmissionTimer, get_Enabled, arginfo_TElSSLRetransmissionTimer_get_Enabled, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLRetransmissionTimer, get_OnTimer, arginfo_TElSSLRetransmissionTimer_get_OnTimer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLRetransmissionTimer, set_OnTimer, arginfo_TElSSLRetransmissionTimer_set_OnTimer, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLRetransmissionTimer, __construct, arginfo_TElSSLRetransmissionTimer___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSLRetransmissionTimer(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSLRetransmissionTimer_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSLRetransmissionTimer", TElSSLRetransmissionTimer_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElSSLRetransmissionTimer_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElSSLX509CertificateTypeHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElSSLX509CertificateTypeHandler, GetCertificateType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElSSLCertificateTypeRaw fOutResultRaw = 0;
		SBCheckError(TElSSLX509CertificateTypeHandler_GetCertificateType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLX509CertificateTypeHandler, GetDataForRemote)
{
	sb_zend_long fKeyExchange;
	sb_zend_long l4CipherSuite;
	sb_zend_long l4Optional;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llzl", &l4CipherSuite, &fKeyExchange, &zaData, &l4Optional) == SUCCESS) && Z_ISREF_P(zaData) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaData))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaData)))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = TElSSLX509CertificateTypeHandler_GetDataForRemote(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4CipherSuite, (TSBKeyExchangeAlgorithmRaw)fKeyExchange, aiData.data, &aiData.len, (int32_t)l4Optional, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaData, &aiData TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-2099965513, 3, aiData.data, &aiData.len) TSRMLS_CC);
			((char *)aiData.data)[aiData.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiData);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiData, zaData);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, &array of byte|string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLX509CertificateTypeHandler, ValidateRemoteCert)
{
	sb_zend_long l4Optional;
	SBArrayZValInfo aiData;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaData, &l4Optional) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSLX509CertificateTypeHandler_ValidateRemoteCert(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, (int32_t)l4Optional, &bOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLX509CertificateTypeHandler, GetRemoteKeyMaterial)
{
	int32_t l4KeyAlgorithmRaw;
	int32_t l4PKTypeRaw;
	sb_zend_long l4KeyType;
	SBArrayZValInfo aiData;
	TElClassHandle hoKeyMaterial;
	zval *oKeyMaterial;
	zval *zaData;
	zval *zl4KeyAlgorithm;
	zval *zl4PKType;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzO", &zaData, &l4KeyType, &zl4PKType, &zl4KeyAlgorithm, &oKeyMaterial, TElKeyMaterial_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)) && Z_ISREF_P(zl4PKType) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4PKType))) && Z_ISREF_P(zl4KeyAlgorithm) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4KeyAlgorithm))) && SB_ISREF_OBJECT_P(oKeyMaterial))
	{
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		l4PKTypeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4PKType));
		l4KeyAlgorithmRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4KeyAlgorithm));
		hoKeyMaterial = SBGetObjectHandle(oKeyMaterial TSRMLS_CC);
		SBCheckError(TElSSLX509CertificateTypeHandler_GetRemoteKeyMaterial(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, (int32_t)l4KeyType, &l4PKTypeRaw, &l4KeyAlgorithmRaw, &hoKeyMaterial) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		ZVAL_LONG(Z_REFVAL_P(zl4PKType), (sb_zend_long)l4PKTypeRaw);
		ZVAL_LONG(Z_REFVAL_P(zl4KeyAlgorithm), (sb_zend_long)l4KeyAlgorithmRaw);
		SBUpdateObjectHandle(oKeyMaterial, hoKeyMaterial TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer, &integer, &\\TElKeyMaterial)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLX509CertificateTypeHandler, GetKeyMaterial)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLX509CertificateTypeHandler_GetKeyMaterial(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElKeyMaterial_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLX509CertificateTypeHandler, GetPublicKeySize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLX509CertificateTypeHandler_GetPublicKeySize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLX509CertificateTypeHandler, GetPublicKeyAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLX509CertificateTypeHandler_GetPublicKeyAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLX509CertificateTypeHandler, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLX509CertificateTypeHandler_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLX509CertificateTypeHandler_GetCertificateType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLX509CertificateTypeHandler_GetDataForRemote, 0, 0, 4)
	ZEND_ARG_INFO(0, CipherSuite)
	ZEND_ARG_INFO(0, KeyExchange)
	ZEND_ARG_INFO(1, Data)
	ZEND_ARG_INFO(0, Optional)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLX509CertificateTypeHandler_ValidateRemoteCert, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, Optional)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLX509CertificateTypeHandler_GetRemoteKeyMaterial, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, KeyType)
	ZEND_ARG_INFO(1, PKType)
	ZEND_ARG_INFO(1, KeyAlgorithm)
	ZEND_ARG_OBJ_INFO(1, KeyMaterial, TElKeyMaterial, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLX509CertificateTypeHandler_GetKeyMaterial, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLX509CertificateTypeHandler_GetPublicKeySize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLX509CertificateTypeHandler_GetPublicKeyAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLX509CertificateTypeHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSLX509CertificateTypeHandler_methods[] = {
	PHP_ME(TElSSLX509CertificateTypeHandler, GetCertificateType, arginfo_TElSSLX509CertificateTypeHandler_GetCertificateType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLX509CertificateTypeHandler, GetDataForRemote, arginfo_TElSSLX509CertificateTypeHandler_GetDataForRemote, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLX509CertificateTypeHandler, ValidateRemoteCert, arginfo_TElSSLX509CertificateTypeHandler_ValidateRemoteCert, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLX509CertificateTypeHandler, GetRemoteKeyMaterial, arginfo_TElSSLX509CertificateTypeHandler_GetRemoteKeyMaterial, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLX509CertificateTypeHandler, GetKeyMaterial, arginfo_TElSSLX509CertificateTypeHandler_GetKeyMaterial, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLX509CertificateTypeHandler, GetPublicKeySize, arginfo_TElSSLX509CertificateTypeHandler_GetPublicKeySize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLX509CertificateTypeHandler, GetPublicKeyAlgorithm, arginfo_TElSSLX509CertificateTypeHandler_GetPublicKeyAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLX509CertificateTypeHandler, __construct, arginfo_TElSSLX509CertificateTypeHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSLX509CertificateTypeHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSLX509CertificateTypeHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSLX509CertificateTypeHandler", TElSSLX509CertificateTypeHandler_methods);
	if (NULL == TElSSLCertificateTypeHandler_ce_ptr)
		Register_TElSSLCertificateTypeHandler(TSRMLS_C);
	TElSSLX509CertificateTypeHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSSLCertificateTypeHandler_ce_ptr);
}

zend_class_entry *TElSSLRawKeyCertificateTypeHandler_ce_ptr = NULL;

SB_PHP_METHOD(TElSSLRawKeyCertificateTypeHandler, GetCertificateType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElSSLCertificateTypeRaw fOutResultRaw = 0;
		SBCheckError(TElSSLRawKeyCertificateTypeHandler_GetCertificateType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLRawKeyCertificateTypeHandler, GetDataForRemote)
{
	sb_zend_long fKeyExchange;
	sb_zend_long l4CipherSuite;
	sb_zend_long l4Optional;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "llzl", &l4CipherSuite, &fKeyExchange, &zaData, &l4Optional) == SUCCESS) && Z_ISREF_P(zaData) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaData))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaData)))))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = TElSSLRawKeyCertificateTypeHandler_GetDataForRemote(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4CipherSuite, (TSBKeyExchangeAlgorithmRaw)fKeyExchange, aiData.data, &aiData.len, (int32_t)l4Optional, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaData, &aiData TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(1903518791, 3, aiData.data, &aiData.len) TSRMLS_CC);
			((char *)aiData.data)[aiData.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiData);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiData, zaData);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, &array of byte|string, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLRawKeyCertificateTypeHandler, ValidateRemoteCert)
{
	sb_zend_long l4Optional;
	SBArrayZValInfo aiData;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaData, &l4Optional) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElSSLRawKeyCertificateTypeHandler_ValidateRemoteCert(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, (int32_t)l4Optional, &bOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLRawKeyCertificateTypeHandler, GetRemoteKeyMaterial)
{
	int32_t l4KeyAlgorithmRaw;
	int32_t l4PKTypeRaw;
	sb_zend_long l4KeyType;
	SBArrayZValInfo aiData;
	TElClassHandle hoKeyMaterial;
	zval *oKeyMaterial;
	zval *zaData;
	zval *zl4KeyAlgorithm;
	zval *zl4PKType;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zlzzO", &zaData, &l4KeyType, &zl4PKType, &zl4KeyAlgorithm, &oKeyMaterial, TElKeyMaterial_ce_ptr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)) && Z_ISREF_P(zl4PKType) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4PKType))) && Z_ISREF_P(zl4KeyAlgorithm) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4KeyAlgorithm))) && SB_ISREF_OBJECT_P(oKeyMaterial))
	{
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		l4PKTypeRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4PKType));
		l4KeyAlgorithmRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4KeyAlgorithm));
		hoKeyMaterial = SBGetObjectHandle(oKeyMaterial TSRMLS_CC);
		SBCheckError(TElSSLRawKeyCertificateTypeHandler_GetRemoteKeyMaterial(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, (int32_t)l4KeyType, &l4PKTypeRaw, &l4KeyAlgorithmRaw, &hoKeyMaterial) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		ZVAL_LONG(Z_REFVAL_P(zl4PKType), (sb_zend_long)l4PKTypeRaw);
		ZVAL_LONG(Z_REFVAL_P(zl4KeyAlgorithm), (sb_zend_long)l4KeyAlgorithmRaw);
		SBUpdateObjectHandle(oKeyMaterial, hoKeyMaterial TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, &integer, &integer, &\\TElKeyMaterial)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLRawKeyCertificateTypeHandler, GetKeyMaterial)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLRawKeyCertificateTypeHandler_GetKeyMaterial(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElKeyMaterial_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLRawKeyCertificateTypeHandler, GetPublicKeySize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLRawKeyCertificateTypeHandler_GetPublicKeySize(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLRawKeyCertificateTypeHandler, GetPublicKeyAlgorithm)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElSSLRawKeyCertificateTypeHandler_GetPublicKeyAlgorithm(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElSSLRawKeyCertificateTypeHandler, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElSSLRawKeyCertificateTypeHandler_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRawKeyCertificateTypeHandler_GetCertificateType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRawKeyCertificateTypeHandler_GetDataForRemote, 0, 0, 4)
	ZEND_ARG_INFO(0, CipherSuite)
	ZEND_ARG_INFO(0, KeyExchange)
	ZEND_ARG_INFO(1, Data)
	ZEND_ARG_INFO(0, Optional)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRawKeyCertificateTypeHandler_ValidateRemoteCert, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, Optional)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRawKeyCertificateTypeHandler_GetRemoteKeyMaterial, 0, 0, 5)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, KeyType)
	ZEND_ARG_INFO(1, PKType)
	ZEND_ARG_INFO(1, KeyAlgorithm)
	ZEND_ARG_OBJ_INFO(1, KeyMaterial, TElKeyMaterial, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRawKeyCertificateTypeHandler_GetKeyMaterial, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRawKeyCertificateTypeHandler_GetPublicKeySize, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRawKeyCertificateTypeHandler_GetPublicKeyAlgorithm, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElSSLRawKeyCertificateTypeHandler___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElSSLRawKeyCertificateTypeHandler_methods[] = {
	PHP_ME(TElSSLRawKeyCertificateTypeHandler, GetCertificateType, arginfo_TElSSLRawKeyCertificateTypeHandler_GetCertificateType, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLRawKeyCertificateTypeHandler, GetDataForRemote, arginfo_TElSSLRawKeyCertificateTypeHandler_GetDataForRemote, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLRawKeyCertificateTypeHandler, ValidateRemoteCert, arginfo_TElSSLRawKeyCertificateTypeHandler_ValidateRemoteCert, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLRawKeyCertificateTypeHandler, GetRemoteKeyMaterial, arginfo_TElSSLRawKeyCertificateTypeHandler_GetRemoteKeyMaterial, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLRawKeyCertificateTypeHandler, GetKeyMaterial, arginfo_TElSSLRawKeyCertificateTypeHandler_GetKeyMaterial, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLRawKeyCertificateTypeHandler, GetPublicKeySize, arginfo_TElSSLRawKeyCertificateTypeHandler_GetPublicKeySize, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLRawKeyCertificateTypeHandler, GetPublicKeyAlgorithm, arginfo_TElSSLRawKeyCertificateTypeHandler_GetPublicKeyAlgorithm, ZEND_ACC_PUBLIC)
	PHP_ME(TElSSLRawKeyCertificateTypeHandler, __construct, arginfo_TElSSLRawKeyCertificateTypeHandler___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElSSLRawKeyCertificateTypeHandler(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElSSLRawKeyCertificateTypeHandler_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElSSLRawKeyCertificateTypeHandler", TElSSLRawKeyCertificateTypeHandler_methods);
	if (NULL == TElSSLCertificateTypeHandler_ce_ptr)
		Register_TElSSLCertificateTypeHandler(TSRMLS_C);
	TElSSLRawKeyCertificateTypeHandler_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElSSLCertificateTypeHandler_ce_ptr);
}

zend_class_entry *TElDTLSFlightItem_ce_ptr = NULL;

SB_PHP_METHOD(TElDTLSFlightItem, get_Epoch)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDTLSFlightItem_get_Epoch(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSFlightItem, get_ContentType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSSL3ContentTypeRaw fOutResultRaw = 0;
		SBCheckError(TElDTLSFlightItem_get_ContentType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSFlightItem, get_Data)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElDTLSFlightItem_get_Data(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-2027356289, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSFlightItem, get_Length)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDTLSFlightItem_get_Length(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSFlightItem, get_MessageSeq)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDTLSFlightItem_get_MessageSeq(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSFlightItem, get_FragmentOffset)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDTLSFlightItem_get_FragmentOffset(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSFlightItem, get_FragmentLength)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDTLSFlightItem_get_FragmentLength(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSFlightItem, get_HandshakeType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElDTLSFlightItem_get_HandshakeType(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSFlightItem, __construct)
{
	sb_zend_long fContentType;
	sb_zend_long l4DataLen;
	sb_zend_long l4Epoch;
	sb_zend_long l4FragmentLength;
	sb_zend_long l4FragmentOffset;
	sb_zend_long l4HandshakeType;
	sb_zend_long l4HeaderLen;
	sb_zend_long l4Len;
	sb_zend_long l4MessageSeq;
	SBArrayZValInfo piData;
	SBArrayZValInfo piFragment;
	SBArrayZValInfo piHeader;
	zval *zpData;
	zval *zpFragment;
	zval *zpHeader;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzlzll", &fContentType, &zpHeader, &l4HeaderLen, &zpData, &l4DataLen, &l4Epoch) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpHeader) || SB_IS_ARRAY_TYPE_RP(zpHeader) || SB_IS_NULL_TYPE_RP(zpHeader) || (SB_IS_OBJECT_TYPE_RP(zpHeader) && (Z_OBJCE_P(zpHeader) == TSBPointer_ce_ptr))) && (SB_IS_STRING_TYPE_RP(zpData) || SB_IS_ARRAY_TYPE_RP(zpData) || SB_IS_NULL_TYPE_RP(zpData) || (SB_IS_OBJECT_TYPE_RP(zpData) && (Z_OBJCE_P(zpData) == TSBPointer_ce_ptr))))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetPointerFromZVal(zpHeader, &piHeader TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetPointerFromZVal(zpData, &piData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDTLSFlightItem_Create((TSSL3ContentTypeRaw)fContentType, piHeader.data, (int32_t)l4HeaderLen, piData.data, (int32_t)l4DataLen, (int32_t)l4Epoch, &hoOutResult) TSRMLS_CC);
		SBFreePointerZValInfo(&piHeader);
		SBFreePointerZValInfo(&piData);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lllllz", &l4HandshakeType, &l4Len, &l4MessageSeq, &l4FragmentOffset, &l4FragmentLength, &zpFragment) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpFragment) || SB_IS_ARRAY_TYPE_RP(zpFragment) || SB_IS_NULL_TYPE_RP(zpFragment) || (SB_IS_OBJECT_TYPE_RP(zpFragment) && (Z_OBJCE_P(zpFragment) == TSBPointer_ce_ptr))))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetPointerFromZVal(zpFragment, &piFragment TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElDTLSFlightItem_Create_1((int32_t)l4HandshakeType, (int32_t)l4Len, (int32_t)l4MessageSeq, (int32_t)l4FragmentOffset, (int32_t)l4FragmentLength, piFragment.data, &hoOutResult) TSRMLS_CC);
		SBFreePointerZValInfo(&piFragment);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TSBPointer|array of byte|string|NULL, integer, \\TSBPointer|array of byte|string|NULL, integer, integer) or (integer, integer, integer, integer, integer, \\TSBPointer|array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElDTLSFlightItem, CreateChangeCipherSpec)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElDTLSFlightItem_CreateChangeCipherSpec(&hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TElDTLSFlightItem_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSFlightItem_get_Epoch, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSFlightItem_get_ContentType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSFlightItem_get_Data, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSFlightItem_get_Length, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSFlightItem_get_MessageSeq, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSFlightItem_get_FragmentOffset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSFlightItem_get_FragmentLength, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSFlightItem_get_HandshakeType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSFlightItem___construct, 0, 0, 6)
	ZEND_ARG_INFO(0, ContentType_or_HandshakeType)
	ZEND_ARG_TYPE_INFO(0, Header_or_Len, 0, 1)
	ZEND_ARG_INFO(0, HeaderLen_or_MessageSeq)
	ZEND_ARG_TYPE_INFO(0, Data_or_FragmentOffset, 0, 1)
	ZEND_ARG_INFO(0, DataLen_or_FragmentLength)
	ZEND_ARG_TYPE_INFO(0, Epoch_or_Fragment, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElDTLSFlightItem_CreateChangeCipherSpec, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElDTLSFlightItem_methods[] = {
	PHP_ME(TElDTLSFlightItem, get_Epoch, arginfo_TElDTLSFlightItem_get_Epoch, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSFlightItem, get_ContentType, arginfo_TElDTLSFlightItem_get_ContentType, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSFlightItem, get_Data, arginfo_TElDTLSFlightItem_get_Data, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSFlightItem, get_Length, arginfo_TElDTLSFlightItem_get_Length, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSFlightItem, get_MessageSeq, arginfo_TElDTLSFlightItem_get_MessageSeq, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSFlightItem, get_FragmentOffset, arginfo_TElDTLSFlightItem_get_FragmentOffset, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSFlightItem, get_FragmentLength, arginfo_TElDTLSFlightItem_get_FragmentLength, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSFlightItem, get_HandshakeType, arginfo_TElDTLSFlightItem_get_HandshakeType, ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSFlightItem, __construct, arginfo_TElDTLSFlightItem___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_ME(TElDTLSFlightItem, CreateChangeCipherSpec, arginfo_TElDTLSFlightItem_CreateChangeCipherSpec, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_FE_END
};

void Register_TElDTLSFlightItem(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElDTLSFlightItem_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElDTLSFlightItem", TElDTLSFlightItem_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElDTLSFlightItem_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

SB_PHP_FUNCTION(SBSSLCommon, ConvertAlertDescriptionToErrorCode)
{
	sb_zend_long fDesc;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fDesc) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBSSLCommon_ConvertAlertDescriptionToErrorCode((TSBAlertDescriptionRaw)fDesc, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSLCommon, ConvertSSLError)
{
	sb_zend_long u1AD;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u1AD) == SUCCESS)
	{
		TSBAlertDescriptionRaw fOutResultRaw = 0;
		SBCheckError(SBSSLCommon_ConvertSSLError((uint8_t)u1AD, &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSLCommon, GetAlertDescriptionFromValidityReason)
{
	sb_zend_long fReason;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fReason) == SUCCESS)
	{
		TSBAlertDescriptionRaw fOutResultRaw = 0;
		SBCheckError(SBSSLCommon_GetAlertDescriptionFromValidityReason((TSBCertificateValidityReasonRaw)fReason, &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSLCommon, GetSecondsCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint32_t u4OutResultRaw = 0;
		SBCheckError(SBSSLCommon_GetSecondsCount(&u4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSLCommon, GetCurveByTlsCurve)
{
	sb_zend_long l4Curve;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Curve) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBSSLCommon_GetCurveByTlsCurve((int32_t)l4Curve, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSLCommon, GetTlsCurveByCurve)
{
	sb_zend_long l4Curve;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Curve) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBSSLCommon_GetTlsCurveByCurve((int32_t)l4Curve, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSLCommon, ReadLengthPrefixedArray)
{
	int32_t l4BytesReadRaw;
	sb_zend_long l4ALenBytes;
	sb_zend_long l4ASize;
	SBArrayZValInfo piABuffer;
	uint32_t _err;
	zval *zl4BytesRead;
	zval *zpABuffer;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zllz", &zpABuffer, &l4ASize, &l4ALenBytes, &zl4BytesRead) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpABuffer) || SB_IS_ARRAY_TYPE_RP(zpABuffer) || SB_IS_NULL_TYPE_RP(zpABuffer) || (SB_IS_OBJECT_TYPE_RP(zpABuffer) && (Z_OBJCE_P(zpABuffer) == TSBPointer_ce_ptr))) && Z_ISREF_P(zl4BytesRead) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zl4BytesRead))))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetPointerFromZVal(zpABuffer, &piABuffer TSRMLS_CC)) RETURN_FALSE;
		l4BytesReadRaw = (int32_t)Z_LVAL_P(Z_REFVAL_P(zl4BytesRead));
		_err = SBSSLCommon_ReadLengthPrefixedArray(piABuffer.data, (int32_t)l4ASize, (int32_t)l4ALenBytes, &l4BytesReadRaw, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1475631838, 4, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piABuffer);
		ZVAL_LONG(Z_REFVAL_P(zl4BytesRead), (sb_zend_long)l4BytesReadRaw);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBPointer|array of byte|string|NULL, integer, integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBSSLCommon, SSLMemoryManager)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(SBSSLCommon_SSLMemoryManager(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElByteArrayManager_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

void Register_SBSSLCommon_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBSSLCommon, DTLS_WINDOW_SIZE, SB_DTLS_WINDOW_SIZE, SB_DTLS_WINDOW_SIZE);
}

void Register_SBSSLCommon_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBReceiveState", NULL);
	TSBReceiveState_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBReceiveState_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBReceiveState_ce_ptr, "rsRecordHeaderWanted", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBReceiveState_ce_ptr, "rsRecordWanted", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBReceiveState_ce_ptr, "rsOneByteWanted", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBSSLMode", NULL);
	TSBSSLMode_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSSLMode_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLMode_ce_ptr, "smImplicit", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLMode_ce_ptr, "smExplicit", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLMode_ce_ptr, "smExplicitManual", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBCloseReason", NULL);
	TSBCloseReason_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBCloseReason_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBCloseReason_ce_ptr, "crError", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBCloseReason_ce_ptr, "crClose", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBAlertLevel", NULL);
	TSBAlertLevel_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBAlertLevel_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertLevel_ce_ptr, "alWarning", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertLevel_ce_ptr, "alFatal", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBAlertDescription", NULL);
	TSBAlertDescription_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBAlertDescription_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adCloseNotify", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adUnexpectedMessage", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adBadRecordMac", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adDecryptionFailed", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adRecordOverflow", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adDecompressionFailure", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adHandshakeFailure", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adNoCertificate", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adBadCertificate", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adUnsupportedCertificate", 9)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adCertificateRevoked", 10)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adCertificateExpired", 11)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adCertificateUnknown", 12)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adIllegalParameter", 13)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adUnknownCa", 14)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adAccessDenied", 15)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adDecodeError", 16)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adDecryptError", 17)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adExportRestriction", 18)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adProtocolVersion", 19)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adInsufficientSecurity", 20)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adInternalError", 21)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adUserCanceled", 22)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adNoRenegotiation", 23)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adUnsupportedExtension", 24)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adNoSharedCipher", 25)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adInappropriateFallback", 26)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adUnknownPSKIdentity", 27)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adCertificateUnobtainable", 28)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adUnrecognizedName", 29)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adBadCertificateStatusResponse", 30)
	SB_DECLARE_CLASS_LONG_CONST(TSBAlertDescription_ce_ptr, "adBadCertificateHashValue", 31)
	
	INIT_CLASS_ENTRY(ce, "TSBSSLOption", NULL);
	TSBSSLOption_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSSLOption_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOption_ce_ptr, "ssloExpectShutdownMessage", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOption_ce_ptr, "ssloOpenSSLDTLSWorkaround", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOption_ce_ptr, "ssloDisableKexLengthAlignment", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOption_ce_ptr, "ssloForceUseOfClientCertHashAlg", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOption_ce_ptr, "ssloAutoAddServerNameExtension", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOption_ce_ptr, "ssloAcceptTrustedSRPPrimesOnly", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOption_ce_ptr, "ssloDisableSignatureAlgorithmsExtension", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOption_ce_ptr, "ssloIntolerateHigherProtocolVersions", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOption_ce_ptr, "ssloStickToPrefCertHashAlg", 8)
	
	INIT_CLASS_ENTRY(ce, "TSBSSLOptions", NULL);
	TSBSSLOptions_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBSSLOptions_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOptions_ce_ptr, "ssloExpectShutdownMessage", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOptions_ce_ptr, "ssloOpenSSLDTLSWorkaround", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOptions_ce_ptr, "ssloDisableKexLengthAlignment", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOptions_ce_ptr, "ssloForceUseOfClientCertHashAlg", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOptions_ce_ptr, "ssloAutoAddServerNameExtension", 16)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOptions_ce_ptr, "ssloAcceptTrustedSRPPrimesOnly", 32)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOptions_ce_ptr, "ssloDisableSignatureAlgorithmsExtension", 64)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOptions_ce_ptr, "ssloIntolerateHigherProtocolVersions", 128)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLOptions_ce_ptr, "ssloStickToPrefCertHashAlg", 256)
	
	INIT_CLASS_ENTRY(ce, "TSBKeyExchangeAlgorithm", NULL);
	TSBKeyExchangeAlgorithm_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBKeyExchangeAlgorithm_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaNULL", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaRSA", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaDH", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaDHE", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaDHanon", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaPSK", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaDHEPSK", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaRSAPSK", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaSRP", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaECDH_ECDSA", 9)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaECDHE_ECDSA", 10)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaECDH_RSA", 11)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaECDHE_RSA", 12)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaECDH_anon", 13)
	SB_DECLARE_CLASS_LONG_CONST(TSBKeyExchangeAlgorithm_ce_ptr, "kaECDHE_PSK", 14)
	
	INIT_CLASS_ENTRY(ce, "TSBDigestAlgorithm", NULL);
	TSBDigestAlgorithm_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBDigestAlgorithm_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBDigestAlgorithm_ce_ptr, "daNULL", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBDigestAlgorithm_ce_ptr, "daMD5", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBDigestAlgorithm_ce_ptr, "daSHA", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBDigestAlgorithm_ce_ptr, "daSHA256", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBDigestAlgorithm_ce_ptr, "daSHA384", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBDigestAlgorithm_ce_ptr, "daSHA512", 5)
	
	INIT_CLASS_ENTRY(ce, "TSBEncryptAlgorithm", NULL);
	TSBEncryptAlgorithm_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBEncryptAlgorithm_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaNULL", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaRC4", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaRC2", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaDES", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "ea3DES", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaIDEA", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaAES128", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaAES256", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaCamellia128", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaCamellia256", 9)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaSeed", 10)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaAES128GCM", 11)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaAES256GCM", 12)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaCamellia128GCM", 13)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaCamellia256GCM", 14)
	SB_DECLARE_CLASS_LONG_CONST(TSBEncryptAlgorithm_ce_ptr, "eaChaCha20Poly1305", 15)
	
	INIT_CLASS_ENTRY(ce, "TSBSignatureAlgorithm", NULL);
	TSBSignatureAlgorithm_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSignatureAlgorithm_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSignatureAlgorithm_ce_ptr, "saAnonymous", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSignatureAlgorithm_ce_ptr, "saRSA", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSignatureAlgorithm_ce_ptr, "saDSA", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSignatureAlgorithm_ce_ptr, "saECDSA", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBSignatureAlgorithm_ce_ptr, "saNull", 4)
	
	INIT_CLASS_ENTRY(ce, "TSBRenegotiationAttackPreventionMode", NULL);
	TSBRenegotiationAttackPreventionMode_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBRenegotiationAttackPreventionMode_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBRenegotiationAttackPreventionMode_ce_ptr, "rapmCompatible", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBRenegotiationAttackPreventionMode_ce_ptr, "rapmStrict", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBRenegotiationAttackPreventionMode_ce_ptr, "rapmAuto", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBSSLServerNameType", NULL);
	TSBSSLServerNameType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSSLServerNameType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLServerNameType_ce_ptr, "ntHostName", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLServerNameType_ce_ptr, "ntUnknown", 1)
	
	INIT_CLASS_ENTRY(ce, "TSBSSLFragmentLength", NULL);
	TSBSSLFragmentLength_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBSSLFragmentLength_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLFragmentLength_ce_ptr, "fl512", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLFragmentLength_ce_ptr, "fl1024", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLFragmentLength_ce_ptr, "fl2048", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLFragmentLength_ce_ptr, "fl4096", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBSSLFragmentLength_ce_ptr, "flUnknown", 4)
	
	INIT_CLASS_ENTRY(ce, "TSBCertChainType", NULL);
	TSBCertChainType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBCertChainType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBCertChainType_ce_ptr, "cctIndividualCerts", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBCertChainType_ce_ptr, "cctPKIPath", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBCertChainType_ce_ptr, "cctUnknown", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBCAIdentifierType", NULL);
	TSBCAIdentifierType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBCAIdentifierType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBCAIdentifierType_ce_ptr, "itPreAgreed", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAIdentifierType_ce_ptr, "itKeyHash", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAIdentifierType_ce_ptr, "itRDN", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAIdentifierType_ce_ptr, "itCertHash", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBCAIdentifierType_ce_ptr, "itUnknown", 4)
	
	INIT_CLASS_ENTRY(ce, "TSBCertificateStatusType", NULL);
	TSBCertificateStatusType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBCertificateStatusType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBCertificateStatusType_ce_ptr, "cstOCSP", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBCertificateStatusType_ce_ptr, "cstMultiOCSP", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBCertificateStatusType_ce_ptr, "cstUnknown", 2)
	
	INIT_CLASS_ENTRY(ce, "TSSL3ContentType", NULL);
	TSSL3ContentType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSSL3ContentType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSSL3ContentType_ce_ptr, "ctChangeCipherSpec", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3ContentType_ce_ptr, "ctAlert", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3ContentType_ce_ptr, "ctHandshake", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3ContentType_ce_ptr, "ctApplicationData", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3ContentType_ce_ptr, "ctHeartbeat", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3ContentType_ce_ptr, "ctUnknown", 5)
	
	INIT_CLASS_ENTRY(ce, "TSSL3HandshakeType", NULL);
	TSSL3HandshakeType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSSL3HandshakeType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSSL3HandshakeType_ce_ptr, "htHelloRequest", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3HandshakeType_ce_ptr, "htClientHello", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3HandshakeType_ce_ptr, "htServerHello", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3HandshakeType_ce_ptr, "htCertificate", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3HandshakeType_ce_ptr, "htServerKeyExchange", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3HandshakeType_ce_ptr, "htCertificateRequest", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3HandshakeType_ce_ptr, "htServerHelloDone", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3HandshakeType_ce_ptr, "htCertificateVerify", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3HandshakeType_ce_ptr, "htClientKeyExchange", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3HandshakeType_ce_ptr, "htFinished", 9)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3HandshakeType_ce_ptr, "htCertificateURL", 10)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3HandshakeType_ce_ptr, "htCertificateStatus", 11)
	SB_DECLARE_CLASS_LONG_CONST(TSSL3HandshakeType_ce_ptr, "htNewSessionTicket", 12)
}

void Register_SBSSLCommon_Aliases(TSRMLS_D)
{
	if (NULL == TElSSLCertificateTypeHandler_ce_ptr)
		Register_TElSSLCertificateTypeHandler(TSRMLS_C);
	zend_register_class_alias("ElSSLCertificateTypeHandler", TElSSLCertificateTypeHandler_ce_ptr);
	if (NULL == TElCustomSSLExtension_ce_ptr)
		Register_TElCustomSSLExtension(TSRMLS_C);
	zend_register_class_alias("ElCustomSSLExtension", TElCustomSSLExtension_ce_ptr);
	if (NULL == TElSSLClass_ce_ptr)
		Register_TElSSLClass(TSRMLS_C);
	zend_register_class_alias("ElSSLClass", TElSSLClass_ce_ptr);
	if (NULL == TElSSLServerName_ce_ptr)
		Register_TElSSLServerName(TSRMLS_C);
	zend_register_class_alias("ElSSLServerName", TElSSLServerName_ce_ptr);
	if (NULL == TElHeartbeatHelloSSLExtension_ce_ptr)
		Register_TElHeartbeatHelloSSLExtension(TSRMLS_C);
	zend_register_class_alias("ElHeartbeatHelloSSLExtension", TElHeartbeatHelloSSLExtension_ce_ptr);
	if (NULL == TElServerNameSSLExtension_ce_ptr)
		Register_TElServerNameSSLExtension(TSRMLS_C);
	zend_register_class_alias("ElServerNameSSLExtension", TElServerNameSSLExtension_ce_ptr);
	if (NULL == TElUserNameSSLExtension_ce_ptr)
		Register_TElUserNameSSLExtension(TSRMLS_C);
	zend_register_class_alias("ElUserNameSSLExtension", TElUserNameSSLExtension_ce_ptr);
	if (NULL == TElExtendedMasterSecretExtension_ce_ptr)
		Register_TElExtendedMasterSecretExtension(TSRMLS_C);
	zend_register_class_alias("ElExtendedMasterSecretExtension", TElExtendedMasterSecretExtension_ce_ptr);
	if (NULL == TElMaxFragmentLengthSSLExtension_ce_ptr)
		Register_TElMaxFragmentLengthSSLExtension(TSRMLS_C);
	zend_register_class_alias("ElMaxFragmentLengthSSLExtension", TElMaxFragmentLengthSSLExtension_ce_ptr);
	if (NULL == TElSSLCertURL_ce_ptr)
		Register_TElSSLCertURL(TSRMLS_C);
	zend_register_class_alias("ElSSLCertURL", TElSSLCertURL_ce_ptr);
	if (NULL == TElClientCertURLsSSLExtension_ce_ptr)
		Register_TElClientCertURLsSSLExtension(TSRMLS_C);
	zend_register_class_alias("ElClientCertURLsSSLExtension", TElClientCertURLsSSLExtension_ce_ptr);
	if (NULL == TElSSLTrustedCA_ce_ptr)
		Register_TElSSLTrustedCA(TSRMLS_C);
	zend_register_class_alias("ElSSLTrustedCA", TElSSLTrustedCA_ce_ptr);
	if (NULL == TElTrustedCAsSSLExtension_ce_ptr)
		Register_TElTrustedCAsSSLExtension(TSRMLS_C);
	zend_register_class_alias("ElTrustedCAsSSLExtension", TElTrustedCAsSSLExtension_ce_ptr);
	if (NULL == TElTruncatedHMACSSLExtension_ce_ptr)
		Register_TElTruncatedHMACSSLExtension(TSRMLS_C);
	zend_register_class_alias("ElTruncatedHMACSSLExtension", TElTruncatedHMACSSLExtension_ce_ptr);
	if (NULL == TElSSLOCSPStatusRequest_ce_ptr)
		Register_TElSSLOCSPStatusRequest(TSRMLS_C);
	zend_register_class_alias("ElSSLOCSPStatusRequest", TElSSLOCSPStatusRequest_ce_ptr);
	if (NULL == TElCertificateStatusSSLExtension_ce_ptr)
		Register_TElCertificateStatusSSLExtension(TSRMLS_C);
	zend_register_class_alias("ElCertificateStatusSSLExtension", TElCertificateStatusSSLExtension_ce_ptr);
	if (NULL == TElCustomSSLExtensions_ce_ptr)
		Register_TElCustomSSLExtensions(TSRMLS_C);
	zend_register_class_alias("ElCustomSSLExtensions", TElCustomSSLExtensions_ce_ptr);
	if (NULL == TElClientSSLExtensions_ce_ptr)
		Register_TElClientSSLExtensions(TSRMLS_C);
	zend_register_class_alias("ElClientSSLExtensions", TElClientSSLExtensions_ce_ptr);
	if (NULL == TElServerSSLExtensions_ce_ptr)
		Register_TElServerSSLExtensions(TSRMLS_C);
	zend_register_class_alias("ElServerSSLExtensions", TElServerSSLExtensions_ce_ptr);
	if (NULL == TElSSLX509CertificateTypeHandler_ce_ptr)
		Register_TElSSLX509CertificateTypeHandler(TSRMLS_C);
	zend_register_class_alias("ElSSLX509CertificateTypeHandler", TElSSLX509CertificateTypeHandler_ce_ptr);
	if (NULL == TElSSLRawKeyCertificateTypeHandler_ce_ptr)
		Register_TElSSLRawKeyCertificateTypeHandler(TSRMLS_C);
	zend_register_class_alias("ElSSLRawKeyCertificateTypeHandler", TElSSLRawKeyCertificateTypeHandler_ce_ptr);
	IElSSLCertificateHandlerContainer_ce_ptr = TObject_ce_ptr;
	zend_register_class_alias("IElSSLCertificateHandlerContainer", IElSSLCertificateHandlerContainer_ce_ptr);
}

