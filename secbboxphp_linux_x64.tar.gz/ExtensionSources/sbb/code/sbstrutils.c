#include "sbstrutils.h"

zend_class_entry *TElStringConverter_ce_ptr = NULL;

SB_PHP_METHOD(TElStringConverter, StrToUtf8)
{
	char *sSource;
	sb_str_size sSource_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sSource, &sSource_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElStringConverter_StrToUtf8(SBGetObjectHandle(getThis() TSRMLS_CC), sSource, (int32_t)sSource_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(533972093, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElStringConverter, Utf8ToStr)
{
	SBArrayZValInfo aiSource;
	uint32_t _err;
	zval *zaSource;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaSource) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSource) || SB_IS_ARRAY_TYPE_RP(zaSource) || SB_IS_NULL_TYPE_RP(zaSource)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaSource, &aiSource TSRMLS_CC)) RETURN_FALSE;
		_err = TElStringConverter_Utf8ToStr(SBGetObjectHandle(getThis() TSRMLS_CC), aiSource.data, aiSource.len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(519888027, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiSource);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElStringConverter, StrToWideStr)
{
	char *sSource;
	sb_str_size sSource_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sSource, &sSource_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElStringConverter_StrToWideStr(SBGetObjectHandle(getThis() TSRMLS_CC), sSource, (int32_t)sSource_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1144506905, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElStringConverter, WideStrToStr)
{
	SBArrayZValInfo aiSource;
	uint32_t _err;
	zval *zaSource;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaSource) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSource) || SB_IS_ARRAY_TYPE_RP(zaSource) || SB_IS_NULL_TYPE_RP(zaSource)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaSource, &aiSource TSRMLS_CC)) RETURN_FALSE;
		_err = TElStringConverter_WideStrToStr(SBGetObjectHandle(getThis() TSRMLS_CC), aiSource.data, aiSource.len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2009635031, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiSource);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElStringConverter, get_DefCharset)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElStringConverter_get_DefCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-122214887, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElStringConverter, set_DefCharset)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElStringConverter_set_DefCharset(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElStringConverter, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElStringConverter_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElStringConverter_StrToUtf8, 0, 0, 1)
	ZEND_ARG_INFO(0, Source)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElStringConverter_Utf8ToStr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElStringConverter_StrToWideStr, 0, 0, 1)
	ZEND_ARG_INFO(0, Source)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElStringConverter_WideStrToStr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElStringConverter_get_DefCharset, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElStringConverter_set_DefCharset, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElStringConverter___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElStringConverter_methods[] = {
	PHP_ME(TElStringConverter, StrToUtf8, arginfo_TElStringConverter_StrToUtf8, ZEND_ACC_PUBLIC)
	PHP_ME(TElStringConverter, Utf8ToStr, arginfo_TElStringConverter_Utf8ToStr, ZEND_ACC_PUBLIC)
	PHP_ME(TElStringConverter, StrToWideStr, arginfo_TElStringConverter_StrToWideStr, ZEND_ACC_PUBLIC)
	PHP_ME(TElStringConverter, WideStrToStr, arginfo_TElStringConverter_WideStrToStr, ZEND_ACC_PUBLIC)
	PHP_ME(TElStringConverter, get_DefCharset, arginfo_TElStringConverter_get_DefCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElStringConverter, set_DefCharset, arginfo_TElStringConverter_set_DefCharset, ZEND_ACC_PUBLIC)
	PHP_ME(TElStringConverter, __construct, arginfo_TElStringConverter___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElStringConverter(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElStringConverter_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElStringConverter", TElStringConverter_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElStringConverter_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

#ifdef SB_WINDOWS
zend_class_entry *TElPlatformStringConverter_ce_ptr = NULL;

SB_PHP_METHOD(TElPlatformStringConverter, StrToUtf8)
{
	char *sSource;
	sb_str_size sSource_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sSource, &sSource_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPlatformStringConverter_StrToUtf8(SBGetObjectHandle(getThis() TSRMLS_CC), sSource, (int32_t)sSource_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-498992272, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPlatformStringConverter, Utf8ToStr)
{
	SBArrayZValInfo aiSource;
	uint32_t _err;
	zval *zaSource;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaSource) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSource) || SB_IS_ARRAY_TYPE_RP(zaSource) || SB_IS_NULL_TYPE_RP(zaSource)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaSource, &aiSource TSRMLS_CC)) RETURN_FALSE;
		_err = TElPlatformStringConverter_Utf8ToStr(SBGetObjectHandle(getThis() TSRMLS_CC), aiSource.data, aiSource.len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1619287258, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiSource);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPlatformStringConverter, StrToWideStr)
{
	char *sSource;
	sb_str_size sSource_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sSource, &sSource_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPlatformStringConverter_StrToWideStr(SBGetObjectHandle(getThis() TSRMLS_CC), sSource, (int32_t)sSource_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1028237718, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPlatformStringConverter, WideStrToStr)
{
	SBArrayZValInfo aiSource;
	uint32_t _err;
	zval *zaSource;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaSource) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSource) || SB_IS_ARRAY_TYPE_RP(zaSource) || SB_IS_NULL_TYPE_RP(zaSource)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaSource, &aiSource TSRMLS_CC)) RETURN_FALSE;
		_err = TElPlatformStringConverter_WideStrToStr(SBGetObjectHandle(getThis() TSRMLS_CC), aiSource.data, aiSource.len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1128551901, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiSource);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPlatformStringConverter, EncodeStr)
{
	char *sEncoding;
	char *sSource;
	sb_str_size sEncoding_len;
	sb_str_size sSource_len;
	sb_zend_long l4Encoding;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &sSource, &sSource_len, &l4Encoding) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPlatformStringConverter_EncodeStr(SBGetObjectHandle(getThis() TSRMLS_CC), sSource, (int32_t)sSource_len, (int32_t)l4Encoding, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1204784620, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sSource, &sSource_len, &sEncoding, &sEncoding_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElPlatformStringConverter_EncodeStr_1(SBGetObjectHandle(getThis() TSRMLS_CC), sSource, (int32_t)sSource_len, sEncoding, (int32_t)sEncoding_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1814045922, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer) or (string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPlatformStringConverter, DecodeStr)
{
	char *sEncoding;
	sb_str_size sEncoding_len;
	sb_zend_long l4Encoding;
	SBArrayZValInfo aiSource;
	uint32_t _err;
	zval *zaSource;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaSource, &l4Encoding) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSource) || SB_IS_ARRAY_TYPE_RP(zaSource) || SB_IS_NULL_TYPE_RP(zaSource)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaSource, &aiSource TSRMLS_CC)) RETURN_FALSE;
		_err = TElPlatformStringConverter_DecodeStr(SBGetObjectHandle(getThis() TSRMLS_CC), aiSource.data, aiSource.len, (int32_t)l4Encoding, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1214949559, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiSource);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zs", &zaSource, &sEncoding, &sEncoding_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSource) || SB_IS_ARRAY_TYPE_RP(zaSource) || SB_IS_NULL_TYPE_RP(zaSource)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaSource, &aiSource TSRMLS_CC)) RETURN_FALSE;
		_err = TElPlatformStringConverter_DecodeStr_1(SBGetObjectHandle(getThis() TSRMLS_CC), aiSource.data, aiSource.len, sEncoding, (int32_t)sEncoding_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-46684779, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiSource);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer) or (array of byte|string|NULL, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElPlatformStringConverter, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElPlatformStringConverter_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPlatformStringConverter_StrToUtf8, 0, 0, 1)
	ZEND_ARG_INFO(0, Source)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPlatformStringConverter_Utf8ToStr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPlatformStringConverter_StrToWideStr, 0, 0, 1)
	ZEND_ARG_INFO(0, Source)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPlatformStringConverter_WideStrToStr, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPlatformStringConverter_EncodeStr, 0, 0, 2)
	ZEND_ARG_INFO(0, Source)
	ZEND_ARG_INFO(0, Encoding)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPlatformStringConverter_DecodeStr, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Source, 0, 1)
	ZEND_ARG_INFO(0, Encoding)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElPlatformStringConverter___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElPlatformStringConverter_methods[] = {
	PHP_ME(TElPlatformStringConverter, StrToUtf8, arginfo_TElPlatformStringConverter_StrToUtf8, ZEND_ACC_PUBLIC)
	PHP_ME(TElPlatformStringConverter, Utf8ToStr, arginfo_TElPlatformStringConverter_Utf8ToStr, ZEND_ACC_PUBLIC)
	PHP_ME(TElPlatformStringConverter, StrToWideStr, arginfo_TElPlatformStringConverter_StrToWideStr, ZEND_ACC_PUBLIC)
	PHP_ME(TElPlatformStringConverter, WideStrToStr, arginfo_TElPlatformStringConverter_WideStrToStr, ZEND_ACC_PUBLIC)
	PHP_ME(TElPlatformStringConverter, EncodeStr, arginfo_TElPlatformStringConverter_EncodeStr, ZEND_ACC_PUBLIC)
	PHP_ME(TElPlatformStringConverter, DecodeStr, arginfo_TElPlatformStringConverter_DecodeStr, ZEND_ACC_PUBLIC)
	PHP_ME(TElPlatformStringConverter, __construct, arginfo_TElPlatformStringConverter___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElPlatformStringConverter(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElPlatformStringConverter_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElPlatformStringConverter", TElPlatformStringConverter_methods);
	if (NULL == TElStringConverter_ce_ptr)
		Register_TElStringConverter(TSRMLS_C);
	TElPlatformStringConverter_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElStringConverter_ce_ptr);
}
#endif

SB_PHP_FUNCTION(SBStrUtils, StringEndsWith)
{
	char *sS;
	char *sSubS;
	sb_str_size sS_len;
	sb_str_size sSubS_len;
	zend_bool bIgnoreCase;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sS, &sS_len, &sSubS, &sSubS_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_StringEndsWith(sS, (int32_t)sS_len, sSubS, (int32_t)sSubS_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssb", &sS, &sS_len, &sSubS, &sSubS_len, &bIgnoreCase) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_StringEndsWith_1(sS, (int32_t)sS_len, sSubS, (int32_t)sSubS_len, (int8_t)bIgnoreCase, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string) or (string, string, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringEquals)
{
	char *sS1;
	char *sS2;
	sb_str_size sS1_len;
	sb_str_size sS2_len;
	sb_zend_long l4Index1;
	sb_zend_long l4Index2;
	sb_zend_long l4MaxLength;
	zend_bool bIgnoreCase;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sS1, &sS1_len, &sS2, &sS2_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_StringEquals(sS1, (int32_t)sS1_len, sS2, (int32_t)sS2_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssb", &sS1, &sS1_len, &sS2, &sS2_len, &bIgnoreCase) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_StringEquals_1(sS1, (int32_t)sS1_len, sS2, (int32_t)sS2_len, (int8_t)bIgnoreCase, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssl", &sS1, &sS1_len, &sS2, &sS2_len, &l4MaxLength) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_StringEquals_2(sS1, (int32_t)sS1_len, sS2, (int32_t)sS2_len, (int32_t)l4MaxLength, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sslb", &sS1, &sS1_len, &sS2, &sS2_len, &l4MaxLength, &bIgnoreCase) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_StringEquals_3(sS1, (int32_t)sS1_len, sS2, (int32_t)sS2_len, (int32_t)l4MaxLength, (int8_t)bIgnoreCase, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "slsll", &sS1, &sS1_len, &l4Index1, &sS2, &sS2_len, &l4Index2, &l4MaxLength) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_StringEquals_4(sS1, (int32_t)sS1_len, (int32_t)l4Index1, sS2, (int32_t)sS2_len, (int32_t)l4Index2, (int32_t)l4MaxLength, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "slsllb", &sS1, &sS1_len, &l4Index1, &sS2, &sS2_len, &l4Index2, &l4MaxLength, &bIgnoreCase) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_StringEquals_5(sS1, (int32_t)sS1_len, (int32_t)l4Index1, sS2, (int32_t)sS2_len, (int32_t)l4Index2, (int32_t)l4MaxLength, (int8_t)bIgnoreCase, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string) or (string, string, bool) or (string, string, integer) or (string, string, integer, bool) or (string, integer, string, integer, integer) or (string, integer, string, integer, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringIndexOf)
{
	char *cC;
	char *sS;
	char *sSubS;
	sb_str_size cC_len;
	sb_str_size sS_len;
	sb_str_size sSubS_len;
	sb_zend_long l4StartIndex;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sS, &sS_len, &cC, &cC_len) == SUCCESS) && (1 == cC_len))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_StringIndexOf(sS, (int32_t)sS_len, cC[0], &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssl", &sS, &sS_len, &cC, &cC_len, &l4StartIndex) == SUCCESS) && (1 == cC_len))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_StringIndexOf_1(sS, (int32_t)sS_len, cC[0], (int32_t)l4StartIndex, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sS, &sS_len, &sSubS, &sSubS_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_StringIndexOf_2(sS, (int32_t)sS_len, sSubS, (int32_t)sSubS_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssl", &sS, &sS_len, &sSubS, &sSubS_len, &l4StartIndex) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_StringIndexOf_3(sS, (int32_t)sS_len, sSubS, (int32_t)sSubS_len, (int32_t)l4StartIndex, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, char) or (string, char, integer) or (string, string) or (string, string, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringIndexOfU)
{
	char *sC;
	char *sS;
	sb_str_size sC_len;
	sb_str_size sS_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sS, &sS_len, &sC, &sC_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_StringIndexOfU(sS, (int32_t)sS_len, sC, (int32_t)sC_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringInsert)
{
	char *cC;
	char *sC;
	char *sS;
	char *sSubS;
	sb_str_size cC_len;
	sb_str_size sC_len;
	sb_str_size sS_len;
	sb_str_size sSubS_len;
	sb_zend_long l4Index;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sls", &sS, &sS_len, &l4Index, &sC, &sC_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringInsert(sS, (int32_t)sS_len, (int32_t)l4Index, sC, (int32_t)sC_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1645161156, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sls", &sS, &sS_len, &l4Index, &sSubS, &sSubS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringInsert_1(sS, (int32_t)sS_len, (int32_t)l4Index, sSubS, (int32_t)sSubS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(102205309, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sls", &sS, &sS_len, &l4Index, &cC, &cC_len) == SUCCESS) && (1 == cC_len))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringInsert_2(sS, (int32_t)sS_len, (int32_t)l4Index, cC[0], sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1033412616, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sls", &sS, &sS_len, &l4Index, &sSubS, &sSubS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringInsert_3(sS, (int32_t)sS_len, (int32_t)l4Index, sSubS, (int32_t)sSubS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1649382111, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer, string) or (string, integer, string) or (string, integer, char) or (string, integer, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringIsEmpty)
{
	char *sS;
	sb_str_size sS_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_StringIsEmpty(sS, (int32_t)sS_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringLastIndexOf)
{
	char *cC;
	char *sC;
	char *sS;
	sb_str_size cC_len;
	sb_str_size sC_len;
	sb_str_size sS_len;
	sb_zend_long l4StartIndex;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sS, &sS_len, &sC, &sC_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_StringLastIndexOf(sS, (int32_t)sS_len, sC, (int32_t)sC_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssl", &sS, &sS_len, &sC, &sC_len, &l4StartIndex) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_StringLastIndexOf_1(sS, (int32_t)sS_len, sC, (int32_t)sC_len, (int32_t)l4StartIndex, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sS, &sS_len, &cC, &cC_len) == SUCCESS) && (1 == cC_len))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_StringLastIndexOf_2(sS, (int32_t)sS_len, cC[0], &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssl", &sS, &sS_len, &cC, &cC_len, &l4StartIndex) == SUCCESS) && (1 == cC_len))
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_StringLastIndexOf_3(sS, (int32_t)sS_len, cC[0], (int32_t)l4StartIndex, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string) or (string, string, integer) or (string, char) or (string, char, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringRemove)
{
	char *sS;
	sb_str_size sS_len;
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &sS, &sS_len, &l4StartIndex) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringRemove(sS, (int32_t)sS_len, (int32_t)l4StartIndex, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(973886018, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sll", &sS, &sS_len, &l4StartIndex, &l4Count) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringRemove_1(sS, (int32_t)sS_len, (int32_t)l4StartIndex, (int32_t)l4Count, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-972792946, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer) or (string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, WideStringRemove)
{
	char *sS;
	sb_str_size sS_len;
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &sS, &sS_len, &l4StartIndex) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_WideStringRemove(sS, (int32_t)sS_len, (int32_t)l4StartIndex, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1251133819, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sll", &sS, &sS_len, &l4StartIndex, &l4Count) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_WideStringRemove_1(sS, (int32_t)sS_len, (int32_t)l4StartIndex, (int32_t)l4Count, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(964724458, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer) or (string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, AnsiStringRemove)
{
	char *sS;
	sb_str_size sS_len;
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &sS, &sS_len, &l4StartIndex) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_AnsiStringRemove(sS, (int32_t)sS_len, (int32_t)l4StartIndex, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1212321831, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sll", &sS, &sS_len, &l4StartIndex, &l4Count) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_AnsiStringRemove_1(sS, (int32_t)sS_len, (int32_t)l4StartIndex, (int32_t)l4Count, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1154727601, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer) or (string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringToLower)
{
	char *sS;
	sb_str_size sS_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringToLower(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(279017803, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringToLower_1(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-155791463, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringToLowerInvariant)
{
	char *sS;
	sb_str_size sS_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringToLowerInvariant(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(565969332, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringToLowerInvariant_1(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-945047706, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringStartsWith)
{
	char *sS;
	char *sSubS;
	sb_str_size sS_len;
	sb_str_size sSubS_len;
	zend_bool bIgnoreCase;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sS, &sS_len, &sSubS, &sSubS_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_StringStartsWith(sS, (int32_t)sS_len, sSubS, (int32_t)sSubS_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssb", &sS, &sS_len, &sSubS, &sSubS_len, &bIgnoreCase) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_StringStartsWith_1(sS, (int32_t)sS_len, sSubS, (int32_t)sSubS_len, (int8_t)bIgnoreCase, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string) or (string, string, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringSubstring)
{
	char *sS;
	sb_str_size sS_len;
	sb_zend_long l4Length;
	sb_zend_long l4StartIndex;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &sS, &sS_len, &l4StartIndex) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringSubstring(sS, (int32_t)sS_len, (int32_t)l4StartIndex, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2143324377, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sll", &sS, &sS_len, &l4StartIndex, &l4Length) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringSubstring_1(sS, (int32_t)sS_len, (int32_t)l4StartIndex, (int32_t)l4Length, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-334652627, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sl", &sS, &sS_len, &l4StartIndex) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringSubstring_2(sS, (int32_t)sS_len, (int32_t)l4StartIndex, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1618198151, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sll", &sS, &sS_len, &l4StartIndex, &l4Length) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringSubstring_3(sS, (int32_t)sS_len, (int32_t)l4StartIndex, (int32_t)l4Length, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1198147904, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer) or (string, integer, integer) or (string, integer) or (string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringCopy)
{
	char *sS;
	sb_str_size sS_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringCopy(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1570615492, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringTrim)
{
	char *sS;
	sb_str_size sS_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringTrim(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-676069323, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringTrim_1(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(832812775, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringTrimEnd)
{
	char *sS;
	sb_str_size sS_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringTrimEnd(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1180104044, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringTrimEnd_1(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1606335558, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringTrimStart)
{
	char *sS;
	sb_str_size sS_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringTrimStart(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1041626105, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringTrimStart_1(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-670939861, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringToUpper)
{
	char *sS;
	sb_str_size sS_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringToUpper(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(187952799, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringToUpper_1(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-316385203, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringToUpperInvariant)
{
	char *sS;
	sb_str_size sS_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringToUpperInvariant(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1549023524, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringToUpperInvariant_1(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1169977354, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringSplit)
{
	char *cSeparator;
	char *sS;
	sb_str_size cSeparator_len;
	sb_str_size sS_len;
	zend_bool bRemoveEmptyEntries;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sS, &sS_len, &cSeparator, &cSeparator_len) == SUCCESS) && (1 == cSeparator_len))
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TStringList_Create(&hoOutResult) TSRMLS_CC);
		SBCheckError(SBStrUtils_StringSplit(sS, (int32_t)sS_len, cSeparator[0], hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TStringList_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssb", &sS, &sS_len, &cSeparator, &cSeparator_len, &bRemoveEmptyEntries) == SUCCESS) && (1 == cSeparator_len))
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TStringList_Create(&hoOutResult) TSRMLS_CC);
		SBCheckError(SBStrUtils_StringSplit_1(sS, (int32_t)sS_len, cSeparator[0], (int8_t)bRemoveEmptyEntries, hoOutResult) TSRMLS_CC);
		object_init_ex(return_value, TStringList_ce_ptr);
		SBSetObjectHandle(return_value, hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, char) or (string, char, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringSplitPV)
{
	char *cSeparator;
	char *sName = NULL;
	char *sS;
	char *sSeparator;
	char *sValue = NULL;
	int32_t sName_len = 0;
	int32_t sValue_len = 0;
	sb_str_size cSeparator_len;
	sb_str_size sS_len;
	sb_str_size sSeparator_len;
	uint32_t _err;
	zval *zsName;
	zval *zsValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szz", &sS, &sS_len, &zsName, &zsValue) == SUCCESS) && Z_ISREF_P(zsName) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsName))) && Z_ISREF_P(zsValue) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsValue))))
	{
		int8_t bOutResultRaw = 0;
		_err = SBStrUtils_StringSplitPV(sS, (int32_t)sS_len, sName, &sName_len, sValue, &sValue_len, &bOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sName = emalloc(sName_len + 1);
			SBCheckError(SBGetLastReturnStringA(94425039, 1, sName, &sName_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsName));
			sValue = emalloc(sValue_len + 1);
			SBCheckError(SBGetLastReturnStringA(94425039, 2, sValue, &sValue_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsValue));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sName[sName_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsName), sName, sName_len);
		sValue[sValue_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsValue), sValue, sValue_len);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szzs", &sS, &sS_len, &zsName, &zsValue, &cSeparator, &cSeparator_len) == SUCCESS) && Z_ISREF_P(zsName) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsName))) && Z_ISREF_P(zsValue) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsValue))) && (1 == cSeparator_len))
	{
		int8_t bOutResultRaw = 0;
		_err = SBStrUtils_StringSplitPV_1(sS, (int32_t)sS_len, sName, &sName_len, sValue, &sValue_len, cSeparator[0], &bOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sName = emalloc(sName_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2077982141, 1, sName, &sName_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsName));
			sValue = emalloc(sValue_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2077982141, 2, sValue, &sValue_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsValue));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sName[sName_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsName), sName, sName_len);
		sValue[sValue_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsValue), sValue, sValue_len);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szz", &sS, &sS_len, &zsName, &zsValue) == SUCCESS) && Z_ISREF_P(zsName) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsName))) && Z_ISREF_P(zsValue) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsValue))))
	{
		int8_t bOutResultRaw = 0;
		_err = SBStrUtils_StringSplitPV_2(sS, (int32_t)sS_len, sName, &sName_len, sValue, &sValue_len, &bOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sName = emalloc(sName_len + 1);
			SBCheckError(SBGetLastReturnStringA(959801112, 1, sName, &sName_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsName));
			sValue = emalloc(sValue_len + 1);
			SBCheckError(SBGetLastReturnStringA(959801112, 2, sValue, &sValue_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsValue));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sName[sName_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsName), sName, sName_len);
		sValue[sValue_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsValue), sValue, sValue_len);
		RETURN_BOOL(bOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szzs", &sS, &sS_len, &zsName, &zsValue, &sSeparator, &sSeparator_len) == SUCCESS) && Z_ISREF_P(zsName) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsName))) && Z_ISREF_P(zsValue) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsValue))))
	{
		int8_t bOutResultRaw = 0;
		_err = SBStrUtils_StringSplitPV_3(sS, (int32_t)sS_len, sName, &sName_len, sValue, &sValue_len, sSeparator, (int32_t)sSeparator_len, &bOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sName = emalloc(sName_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1466796613, 1, sName, &sName_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsName));
			sValue = emalloc(sValue_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1466796613, 2, sValue, &sValue_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsValue));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sName[sName_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsName), sName, sName_len);
		sValue[sValue_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsValue), sValue, sValue_len);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, &string, &string) or (string, &string, &string, char) or (string, &string, &string) or (string, &string, &string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringPadLeft)
{
	char *cC;
	char *sS;
	sb_str_size cC_len;
	sb_str_size sS_len;
	sb_zend_long l4Len;
	uint32_t _err;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssl", &sS, &sS_len, &cC, &cC_len, &l4Len) == SUCCESS) && (1 == cC_len))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringPadLeft(sS, (int32_t)sS_len, cC[0], (int32_t)l4Len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1912659774, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, char, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringPadRight)
{
	char *cC;
	char *sS;
	sb_str_size cC_len;
	sb_str_size sS_len;
	sb_zend_long l4Len;
	uint32_t _err;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssl", &sS, &sS_len, &cC, &cC_len, &l4Len) == SUCCESS) && (1 == cC_len))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringPadRight(sS, (int32_t)sS_len, cC[0], (int32_t)l4Len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1231532893, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, char, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StrToDefEncoding)
{
	char *sAStr;
	sb_str_size sAStr_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAStr, &sAStr_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBStrUtils_StrToDefEncoding(sAStr, (int32_t)sAStr_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(592651665, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, DefEncodingToStr)
{
	SBArrayZValInfo aiASrc;
	uint32_t _err;
	zval *zaASrc;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaASrc) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaASrc) || SB_IS_ARRAY_TYPE_RP(zaASrc) || SB_IS_NULL_TYPE_RP(zaASrc)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaASrc, &aiASrc TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_DefEncodingToStr(aiASrc.data, aiASrc.len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-424341366, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiASrc);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StrToStdEncoding)
{
	char *sAStr;
	sb_str_size sAStr_len;
	uint32_t _err;
	zend_bool bUseUTF8;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sb", &sAStr, &sAStr_len, &bUseUTF8) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBStrUtils_StrToStdEncoding(sAStr, (int32_t)sAStr_len, (int8_t)bUseUTF8, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1400787785, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StdEncodingToStr)
{
	SBArrayZValInfo aiASrc;
	uint32_t _err;
	zend_bool bUseUTF8;
	zval *zaASrc;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zb", &zaASrc, &bUseUTF8) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaASrc) || SB_IS_ARRAY_TYPE_RP(zaASrc) || SB_IS_NULL_TYPE_RP(zaASrc)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaASrc, &aiASrc TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_StdEncodingToStr(aiASrc.data, aiASrc.len, (int8_t)bUseUTF8, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1378435676, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiASrc);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SBExtractFilePath)
{
	char *sFileName;
	sb_str_size sFileName_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sFileName, &sFileName_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_SBExtractFilePath(sFileName, (int32_t)sFileName_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1257492946, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SBExtractFileName)
{
	char *sFileName;
	sb_str_size sFileName_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sFileName, &sFileName_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_SBExtractFileName(sFileName, (int32_t)sFileName_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1032016994, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SBExtractFileExt)
{
	char *sFileName;
	sb_str_size sFileName_len;
	uint32_t _err;
	zend_bool bIncludeDot;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sFileName, &sFileName_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_SBExtractFileExt(sFileName, (int32_t)sFileName_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1078876967, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sb", &sFileName, &sFileName_len, &bIncludeDot) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_SBExtractFileExt_1(sFileName, (int32_t)sFileName_len, (int8_t)bIncludeDot, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2113609023, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (string, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ReplaceExt)
{
	char *sFileName;
	char *sNewExtension;
	sb_str_size sFileName_len;
	sb_str_size sNewExtension_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sFileName, &sFileName_len, &sNewExtension, &sNewExtension_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ReplaceExt(sFileName, (int32_t)sFileName_len, sNewExtension, (int32_t)sNewExtension_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(733186404, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, FilenameMatchesMask)
{
	char *sMask;
	char *sName;
	sb_str_size sMask_len;
	sb_str_size sName_len;
	zend_bool bCaseSensitive;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssb", &sName, &sName_len, &sMask, &sMask_len, &bCaseSensitive) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_FilenameMatchesMask(sName, (int32_t)sName_len, sMask, (int32_t)sMask_len, (int8_t)bCaseSensitive, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, DomainNameMatchesCertSN)
{
	char *sDomainName;
	char *sMatch;
	sb_str_size sDomainName_len;
	sb_str_size sMatch_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sDomainName, &sDomainName_len, &sMatch, &sMatch_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_DomainNameMatchesCertSN(sDomainName, (int32_t)sDomainName_len, sMatch, (int32_t)sMatch_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, CountFoldersInPath)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_CountFoldersInPath(sPath, (int32_t)sPath_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ParseURL)
{
	char *sanchor;
	char *sDefaultProtocol;
	char *sHost;
	char *sParameters;
	char *sPassword;
	char *sPath;
	char *sProtocol;
	char *sURL;
	char *sUsername;
	int32_t sanchor_len;
	int32_t sHost_len;
	int32_t sParameters_len;
	int32_t sPassword_len;
	int32_t sPath_len;
	int32_t sProtocol_len;
	int32_t sUsername_len;
	sb_str_size sDefaultProtocol_len;
	sb_str_size sURL_len;
	uint16_t u2PortRaw;
	uint32_t _err;
	zend_bool bSingleNameIsPage;
	zval *zsanchor;
	zval *zsHost;
	zval *zsParameters;
	zval *zsPassword;
	zval *zsPath;
	zval *zsProtocol;
	zval *zsUsername;
	zval *zu2Port;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sbzzzzzzzz", &sURL, &sURL_len, &bSingleNameIsPage, &zsProtocol, &zsUsername, &zsPassword, &zsHost, &zu2Port, &zsPath, &zsanchor, &zsParameters) == SUCCESS) && Z_ISREF_P(zsProtocol) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsProtocol))) && Z_ISREF_P(zsUsername) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsUsername))) && Z_ISREF_P(zsPassword) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsPassword))) && Z_ISREF_P(zsHost) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsHost))) && Z_ISREF_P(zu2Port) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2Port))) && Z_ISREF_P(zsPath) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsPath))) && Z_ISREF_P(zsanchor) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsanchor))) && Z_ISREF_P(zsParameters) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsParameters))))
	{
		sProtocol = Z_STRVAL_P(Z_REFVAL_P(zsProtocol));
		sProtocol_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsProtocol));
		sUsername = Z_STRVAL_P(Z_REFVAL_P(zsUsername));
		sUsername_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsUsername));
		sPassword = Z_STRVAL_P(Z_REFVAL_P(zsPassword));
		sPassword_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsPassword));
		sHost = Z_STRVAL_P(Z_REFVAL_P(zsHost));
		sHost_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsHost));
		u2PortRaw = (uint16_t)Z_LVAL_P(Z_REFVAL_P(zu2Port));
		sPath = Z_STRVAL_P(Z_REFVAL_P(zsPath));
		sPath_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsPath));
		sanchor = Z_STRVAL_P(Z_REFVAL_P(zsanchor));
		sanchor_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsanchor));
		sParameters = Z_STRVAL_P(Z_REFVAL_P(zsParameters));
		sParameters_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsParameters));
		_err = SBStrUtils_ParseURL(sURL, (int32_t)sURL_len, (int8_t)bSingleNameIsPage, sProtocol, &sProtocol_len, sUsername, &sUsername_len, sPassword, &sPassword_len, sHost, &sHost_len, &u2PortRaw, sPath, &sPath_len, sanchor, &sanchor_len, sParameters, &sParameters_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sProtocol = emalloc(sProtocol_len + 1);
			SBCheckError(SBGetLastReturnStringA(543693857, 2, sProtocol, &sProtocol_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsProtocol));
			sUsername = emalloc(sUsername_len + 1);
			SBCheckError(SBGetLastReturnStringA(543693857, 3, sUsername, &sUsername_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsUsername));
			sPassword = emalloc(sPassword_len + 1);
			SBCheckError(SBGetLastReturnStringA(543693857, 4, sPassword, &sPassword_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsPassword));
			sHost = emalloc(sHost_len + 1);
			SBCheckError(SBGetLastReturnStringA(543693857, 5, sHost, &sHost_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsHost));
			sPath = emalloc(sPath_len + 1);
			SBCheckError(SBGetLastReturnStringA(543693857, 7, sPath, &sPath_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsPath));
			sanchor = emalloc(sanchor_len + 1);
			SBCheckError(SBGetLastReturnStringA(543693857, 8, sanchor, &sanchor_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsanchor));
			sParameters = emalloc(sParameters_len + 1);
			SBCheckError(SBGetLastReturnStringA(543693857, 9, sParameters, &sParameters_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsParameters));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sProtocol[sProtocol_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsProtocol), sProtocol, sProtocol_len);
		sUsername[sUsername_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsUsername), sUsername, sUsername_len);
		sPassword[sPassword_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsPassword), sPassword, sPassword_len);
		sHost[sHost_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsHost), sHost, sHost_len);
		ZVAL_LONG(Z_REFVAL_P(zu2Port), (sb_zend_long)u2PortRaw);
		sPath[sPath_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsPath), sPath, sPath_len);
		sanchor[sanchor_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsanchor), sanchor, sanchor_len);
		sParameters[sParameters_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsParameters), sParameters, sParameters_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sbzzzzzzzzs", &sURL, &sURL_len, &bSingleNameIsPage, &zsProtocol, &zsUsername, &zsPassword, &zsHost, &zu2Port, &zsPath, &zsanchor, &zsParameters, &sDefaultProtocol, &sDefaultProtocol_len) == SUCCESS) && Z_ISREF_P(zsProtocol) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsProtocol))) && Z_ISREF_P(zsUsername) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsUsername))) && Z_ISREF_P(zsPassword) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsPassword))) && Z_ISREF_P(zsHost) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsHost))) && Z_ISREF_P(zu2Port) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2Port))) && Z_ISREF_P(zsPath) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsPath))) && Z_ISREF_P(zsanchor) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsanchor))) && Z_ISREF_P(zsParameters) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsParameters))))
	{
		sProtocol = Z_STRVAL_P(Z_REFVAL_P(zsProtocol));
		sProtocol_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsProtocol));
		sUsername = Z_STRVAL_P(Z_REFVAL_P(zsUsername));
		sUsername_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsUsername));
		sPassword = Z_STRVAL_P(Z_REFVAL_P(zsPassword));
		sPassword_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsPassword));
		sHost = Z_STRVAL_P(Z_REFVAL_P(zsHost));
		sHost_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsHost));
		u2PortRaw = (uint16_t)Z_LVAL_P(Z_REFVAL_P(zu2Port));
		sPath = Z_STRVAL_P(Z_REFVAL_P(zsPath));
		sPath_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsPath));
		sanchor = Z_STRVAL_P(Z_REFVAL_P(zsanchor));
		sanchor_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsanchor));
		sParameters = Z_STRVAL_P(Z_REFVAL_P(zsParameters));
		sParameters_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsParameters));
		_err = SBStrUtils_ParseURL_1(sURL, (int32_t)sURL_len, (int8_t)bSingleNameIsPage, sProtocol, &sProtocol_len, sUsername, &sUsername_len, sPassword, &sPassword_len, sHost, &sHost_len, &u2PortRaw, sPath, &sPath_len, sanchor, &sanchor_len, sParameters, &sParameters_len, sDefaultProtocol, (int32_t)sDefaultProtocol_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sProtocol = emalloc(sProtocol_len + 1);
			SBCheckError(SBGetLastReturnStringA(422826586, 2, sProtocol, &sProtocol_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsProtocol));
			sUsername = emalloc(sUsername_len + 1);
			SBCheckError(SBGetLastReturnStringA(422826586, 3, sUsername, &sUsername_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsUsername));
			sPassword = emalloc(sPassword_len + 1);
			SBCheckError(SBGetLastReturnStringA(422826586, 4, sPassword, &sPassword_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsPassword));
			sHost = emalloc(sHost_len + 1);
			SBCheckError(SBGetLastReturnStringA(422826586, 5, sHost, &sHost_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsHost));
			sPath = emalloc(sPath_len + 1);
			SBCheckError(SBGetLastReturnStringA(422826586, 7, sPath, &sPath_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsPath));
			sanchor = emalloc(sanchor_len + 1);
			SBCheckError(SBGetLastReturnStringA(422826586, 8, sanchor, &sanchor_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsanchor));
			sParameters = emalloc(sParameters_len + 1);
			SBCheckError(SBGetLastReturnStringA(422826586, 9, sParameters, &sParameters_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsParameters));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sProtocol[sProtocol_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsProtocol), sProtocol, sProtocol_len);
		sUsername[sUsername_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsUsername), sUsername, sUsername_len);
		sPassword[sPassword_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsPassword), sPassword, sPassword_len);
		sHost[sHost_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsHost), sHost, sHost_len);
		ZVAL_LONG(Z_REFVAL_P(zu2Port), (sb_zend_long)u2PortRaw);
		sPath[sPath_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsPath), sPath, sPath_len);
		sanchor[sanchor_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsanchor), sanchor, sanchor_len);
		sParameters[sParameters_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsParameters), sParameters, sParameters_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, bool, &string, &string, &string, &string, &integer, &string, &string, &string) or (string, bool, &string, &string, &string, &string, &integer, &string, &string, &string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ComposeURL)
{
	char *sAnchor;
	char *sHost;
	char *sParameters;
	char *sPassword;
	char *sPath;
	char *sProtocol;
	char *sUserName;
	sb_str_size sAnchor_len;
	sb_str_size sHost_len;
	sb_str_size sParameters_len;
	sb_str_size sPassword_len;
	sb_str_size sPath_len;
	sb_str_size sProtocol_len;
	sb_str_size sUserName_len;
	sb_zend_long u2Port;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sssslsss", &sProtocol, &sProtocol_len, &sUserName, &sUserName_len, &sPassword, &sPassword_len, &sHost, &sHost_len, &u2Port, &sPath, &sPath_len, &sAnchor, &sAnchor_len, &sParameters, &sParameters_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ComposeURL(sProtocol, (int32_t)sProtocol_len, sUserName, (int32_t)sUserName_len, sPassword, (int32_t)sPassword_len, sHost, (int32_t)sHost_len, (uint16_t)u2Port, sPath, (int32_t)sPath_len, sAnchor, (int32_t)sAnchor_len, sParameters, (int32_t)sParameters_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1399166752, 8, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, string, string, integer, string, string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SBRightPos)
{
	char *sStr;
	char *sSubstr;
	sb_str_size sStr_len;
	sb_str_size sSubstr_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sSubstr, &sSubstr_len, &sStr, &sStr_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_SBRightPos(sSubstr, (int32_t)sSubstr_len, sStr, (int32_t)sStr_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SBPos)
{
	char *sstr;
	char *sSubP;
	char *ssubstr;
	sb_str_size sstr_len;
	sb_str_size sSubP_len;
	sb_str_size ssubstr_len;
	sb_zend_long l4StartPos;
	sb_zend_long u1SubP;
	SBArrayZValInfo aiP;
	SBArrayZValInfo aiSubP;
	zval *zaP;
	zval *zaSubP;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &ssubstr, &ssubstr_len, &sstr, &sstr_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_SBPos(ssubstr, (int32_t)ssubstr_len, sstr, (int32_t)sstr_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzl", &zaSubP, &zaP, &l4StartPos) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSubP) || SB_IS_ARRAY_TYPE_RP(zaSubP) || SB_IS_NULL_TYPE_RP(zaSubP)) && (SB_IS_STRING_TYPE_RP(zaP) || SB_IS_ARRAY_TYPE_RP(zaP) || SB_IS_NULL_TYPE_RP(zaP)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaSubP, &aiSubP TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaP, &aiP TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBStrUtils_SBPos_1(aiSubP.data, aiSubP.len, aiP.data, aiP.len, (int32_t)l4StartPos, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiSubP);
		SBFreeArrayZValInfo(&aiP);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szl", &sSubP, &sSubP_len, &zaP, &l4StartPos) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaP) || SB_IS_ARRAY_TYPE_RP(zaP) || SB_IS_NULL_TYPE_RP(zaP)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaP, &aiP TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBStrUtils_SBPos_2(sSubP, (int32_t)sSubP_len, aiP.data, aiP.len, (int32_t)l4StartPos, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiP);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lz", &u1SubP, &zaP) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaP) || SB_IS_ARRAY_TYPE_RP(zaP) || SB_IS_NULL_TYPE_RP(zaP)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaP, &aiP TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBStrUtils_SBPos_3((uint8_t)u1SubP, aiP.data, aiP.len, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiP);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string) or (array of byte|string|NULL, array of byte|string|NULL, integer) or (string, array of byte|string|NULL, integer) or (integer, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SBCopy)
{
	sb_zend_long l4Offset;
	sb_zend_long l4Size;
	SBArrayZValInfo aistr;
	uint32_t _err;
	zval *zastr;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zastr, &l4Offset, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zastr) || SB_IS_ARRAY_TYPE_RP(zastr) || SB_IS_NULL_TYPE_RP(zastr)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zastr, &aistr TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_SBCopy(aistr.data, aistr.len, (int32_t)l4Offset, (int32_t)l4Size, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1028653569, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aistr);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zastr) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zastr) || SB_IS_ARRAY_TYPE_RP(zastr) || SB_IS_NULL_TYPE_RP(zastr)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zastr, &aistr TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_SBCopy_1(aistr.data, aistr.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1553847931, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aistr);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, integer) or (array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SBConcatAnsiStrings)
{
	char *cStr2;
	char *sStr1;
	char *sStr2;
	sb_str_size cStr2_len;
	sb_str_size sStr1_len;
	sb_str_size sStr2_len;
	uint32_t _err;
	zval *oStrs;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sStr1, &sStr1_len, &cStr2, &cStr2_len) == SUCCESS) && (1 == cStr2_len))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_SBConcatAnsiStrings(sStr1, (int32_t)sStr1_len, cStr2[0], sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1300119611, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sStr1, &sStr1_len, &sStr2, &sStr2_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_SBConcatAnsiStrings_1(sStr1, (int32_t)sStr1_len, sStr2, (int32_t)sStr2_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1871730359, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oStrs, TStringList_ce_ptr) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_SBConcatAnsiStrings_2(SBGetObjectHandle(oStrs TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(473211872, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, char) or (string, string) or (\\TStringList)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, OIDToStr)
{
	SBArrayZValInfo aiOID;
	uint32_t _err;
	zval *zaOID;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaOID) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaOID) || SB_IS_ARRAY_TYPE_RP(zaOID) || SB_IS_NULL_TYPE_RP(zaOID)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaOID, &aiOID TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_OIDToStr(aiOID.data, aiOID.len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1176363489, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiOID);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StrToOID)
{
	char *sStr;
	sb_str_size sStr_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sStr, &sStr_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBStrUtils_StrToOID(sStr, (int32_t)sStr_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1715747177, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StrToUTF8)
{
	char *sAStr;
	sb_str_size sAStr_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAStr, &sAStr_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBStrUtils_StrToUTF8(sAStr, (int32_t)sAStr_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(739672873, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, UTF8ToStr)
{
	SBArrayZValInfo aiASrc;
	uint32_t _err;
	zval *zaASrc;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaASrc) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaASrc) || SB_IS_ARRAY_TYPE_RP(zaASrc) || SB_IS_NULL_TYPE_RP(zaASrc)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaASrc, &aiASrc TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_UTF8ToStr(aiASrc.data, aiASrc.len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1731110236, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiASrc);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StrToWideStr)
{
	char *sAStr;
	sb_str_size sAStr_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAStr, &sAStr_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBStrUtils_StrToWideStr(sAStr, (int32_t)sAStr_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-249466642, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, WideStrToStr)
{
	SBArrayZValInfo aiASrc;
	uint32_t _err;
	zval *zaASrc;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaASrc) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaASrc) || SB_IS_ARRAY_TYPE_RP(zaASrc) || SB_IS_NULL_TYPE_RP(zaASrc)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaASrc, &aiASrc TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_WideStrToStr(aiASrc.data, aiASrc.len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-869117504, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiASrc);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, EncodeString)
{
	char *sAStr;
	char *sEncoding;
	sb_str_size sAStr_len;
	sb_str_size sEncoding_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sAStr, &sAStr_len, &sEncoding, &sEncoding_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBStrUtils_EncodeString(sAStr, (int32_t)sAStr_len, sEncoding, (int32_t)sEncoding_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1442745325, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, DecodeString)
{
	char *sEncoding;
	sb_str_size sEncoding_len;
	SBArrayZValInfo aiASrc;
	uint32_t _err;
	zval *zaASrc;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zs", &zaASrc, &sEncoding, &sEncoding_len) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaASrc) || SB_IS_ARRAY_TYPE_RP(zaASrc) || SB_IS_NULL_TYPE_RP(zaASrc)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaASrc, &aiASrc TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_DecodeString(aiASrc.data, aiASrc.len, sEncoding, (int32_t)sEncoding_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(362933983, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiASrc);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, UnicodeChangeEndianness)
{
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_UnicodeChangeEndianness(aiData.data, aiData.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1047858921, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, WideStrToUTF8)
{
	char *sAStr;
	sb_str_size sAStr_len;
	sb_zend_long l4Size;
	SBPointerZValInfo piASrc;
	uint32_t _err;
	zval *zpASrc;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAStr, &sAStr_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBStrUtils_WideStrToUTF8(sAStr, (int32_t)sAStr_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(362357425, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpASrc, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpASrc) || SB_IS_ARRAY_TYPE_RP(zpASrc) || SB_IS_NULL_TYPE_RP(zpASrc) || (SB_IS_OBJECT_TYPE_RP(zpASrc) && (Z_OBJCE_P(zpASrc) == TSBPointer_ce_ptr))))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetPointerFromZVal(zpASrc, &piASrc TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_WideStrToUTF8_1(piASrc.data, (int32_t)l4Size, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1800960671, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piASrc);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string) or (\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, UTF8ToWideStr)
{
	sb_zend_long l4Size;
	SBArrayZValInfo aiBuf;
	SBPointerZValInfo piBuf;
	uint32_t _err;
	zval *zaBuf;
	zval *zpBuf;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaBuf) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBuf) || SB_IS_ARRAY_TYPE_RP(zaBuf) || SB_IS_NULL_TYPE_RP(zaBuf)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaBuf, &aiBuf TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_UTF8ToWideStr(aiBuf.data, aiBuf.len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2072274432, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiBuf);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zpBuf, &l4Size) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zpBuf) || SB_IS_ARRAY_TYPE_RP(zpBuf) || SB_IS_NULL_TYPE_RP(zpBuf) || (SB_IS_OBJECT_TYPE_RP(zpBuf) && (Z_OBJCE_P(zpBuf) == TSBPointer_ce_ptr))))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetPointerFromZVal(zpBuf, &piBuf TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_UTF8ToWideStr_1(piBuf.data, (int32_t)l4Size, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1616583319, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreePointerZValInfo(&piBuf);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL) or (\\TSBPointer|array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ConvertUTF16toUTF8)
{
	char *ssource;
	sb_str_size ssource_len;
	sb_zend_long fflags;
	SBArrayZValInfo aitarget;
	uint32_t _err;
	zend_bool bBOM;
	zval *zatarget;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "szlb", &ssource, &ssource_len, &zatarget, &fflags, &bBOM) == SUCCESS) && Z_ISREF_P(zatarget) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zatarget))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zatarget)))))
	{
		ConversionResultRaw fOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zatarget, &aitarget TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_ConvertUTF16toUTF8(ssource, (int32_t)ssource_len, aitarget.data, &aitarget.len, (ConversionFlagsRaw)fflags, (int8_t)bBOM, &fOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zatarget, &aitarget TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(1483428958, 1, aitarget.data, &aitarget.len) TSRMLS_CC);
			((char *)aitarget.data)[aitarget.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aitarget);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aitarget, zatarget);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, &array of byte|string, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, isLegalUTF8)
{
	sb_zend_long u4sourcelen;
	SBArrayZValInfo aisource;
	zval *zasource;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zasource, &u4sourcelen) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zasource) || SB_IS_ARRAY_TYPE_RP(zasource) || SB_IS_NULL_TYPE_RP(zasource)))
	{
		int8_t bOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zasource, &aisource TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBStrUtils_isLegalUTF8(aisource.data, aisource.len, (uint32_t)u4sourcelen, &bOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aisource);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ConvertUTF8toUTF16)
{
	char *starget;
	int32_t starget_len;
	sb_zend_long fflags;
	SBArrayZValInfo aisource;
	uint32_t _err;
	zend_bool bBOM;
	zval *zasource;
	zval *zstarget;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzlb", &zasource, &zstarget, &fflags, &bBOM) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zasource) || SB_IS_ARRAY_TYPE_RP(zasource) || SB_IS_NULL_TYPE_RP(zasource)) && Z_ISREF_P(zstarget) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zstarget))))
	{
		ConversionResultRaw fOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zasource, &aisource TSRMLS_CC)) RETURN_FALSE;
		starget = Z_STRVAL_P(Z_REFVAL_P(zstarget));
		starget_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zstarget));
		_err = SBStrUtils_ConvertUTF8toUTF16(aisource.data, aisource.len, starget, &starget_len, (ConversionFlagsRaw)fflags, (int8_t)bBOM, &fOutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			starget = emalloc(starget_len + 1);
			SBCheckError(SBGetLastReturnStringA(1241701494, 1, starget, &starget_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zstarget));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aisource);
		starget[starget_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zstarget), starget, starget_len);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &string, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ConvertFromUTF8String)
{
	SBArrayZValInfo aiSource;
	uint32_t _err;
	zend_bool bCheckBOM;
	zval *zaSource;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zb", &zaSource, &bCheckBOM) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSource) || SB_IS_ARRAY_TYPE_RP(zaSource) || SB_IS_NULL_TYPE_RP(zaSource)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaSource, &aiSource TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_ConvertFromUTF8String(aiSource.data, aiSource.len, (int8_t)bCheckBOM, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1001076423, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiSource);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ConvertToUTF8String)
{
	char *sSource;
	sb_str_size sSource_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sSource, &sSource_len) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = SBStrUtils_ConvertToUTF8String(sSource, (int32_t)sSource_len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(640382488, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ConvertFromUTF32String)
{
	SBArrayZValInfo aiSource;
	uint32_t _err;
	zend_bool bCheckBOM;
	zval *zaSource;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zb", &zaSource, &bCheckBOM) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaSource) || SB_IS_ARRAY_TYPE_RP(zaSource) || SB_IS_NULL_TYPE_RP(zaSource)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaSource, &aiSource TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_ConvertFromUTF32String(aiSource.data, aiSource.len, (int8_t)bCheckBOM, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1113134406, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiSource);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SetGlobalStringConverter)
{
	zval *oConverter;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oConverter, TElStringConverter_ce_ptr) == SUCCESS)
	{
		SBCheckError(SBStrUtils_SetGlobalStringConverter(SBGetObjectHandle(oConverter TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringConverter)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SetDefaultCharset)
{
	char *sCharset;
	sb_str_size sCharset_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sCharset, &sCharset_len) == SUCCESS)
	{
		SBCheckError(SBStrUtils_SetDefaultCharset(sCharset, (int32_t)sCharset_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StrMixToInt64)
{
	char *sS;
	sb_str_size sS_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		int64_t l8OutResultRaw = 0;
		SBCheckError(SBStrUtils_StrMixToInt64(sS, (int32_t)sS_len, &l8OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l8OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SBTrim)
{
	SBArrayZValInfo aiS;
	uint32_t _err;
	zval *zaS;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaS) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaS) || SB_IS_ARRAY_TYPE_RP(zaS) || SB_IS_NULL_TYPE_RP(zaS)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaS, &aiS TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_SBTrim(aiS.data, aiS.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(695529780, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiS);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SBUppercase)
{
	SBArrayZValInfo aiS;
	uint32_t _err;
	zval *zaS;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaS) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaS) || SB_IS_ARRAY_TYPE_RP(zaS) || SB_IS_NULL_TYPE_RP(zaS)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaS, &aiS TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_SBUppercase(aiS.data, aiS.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-2048791828, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiS);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, StringReplace)
{
	char *sEntry;
	char *sReplaceWith;
	char *sSource;
	sb_str_size sEntry_len;
	sb_str_size sReplaceWith_len;
	sb_str_size sSource_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sss", &sSource, &sSource_len, &sEntry, &sEntry_len, &sReplaceWith, &sReplaceWith_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringReplace(sSource, (int32_t)sSource_len, sEntry, (int32_t)sEntry_len, sReplaceWith, (int32_t)sReplaceWith_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1638498632, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sss", &sSource, &sSource_len, &sEntry, &sEntry_len, &sReplaceWith, &sReplaceWith_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_StringReplace_1(sSource, (int32_t)sSource_len, sEntry, (int32_t)sEntry_len, sReplaceWith, (int32_t)sReplaceWith_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(254067259, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, string) or (string, string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, PrefixString)
{
	char *cValue;
	char *sS;
	sb_str_size cValue_len;
	sb_str_size sS_len;
	sb_zend_long l4Count;
	uint32_t _err;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sls", &sS, &sS_len, &l4Count, &cValue, &cValue_len) == SUCCESS) && (1 == cValue_len))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_PrefixString(sS, (int32_t)sS_len, (int32_t)l4Count, cValue[0], sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1584308007, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer, char)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SuffixString)
{
	char *cValue;
	char *sS;
	sb_str_size cValue_len;
	sb_str_size sS_len;
	sb_zend_long l4Count;
	uint32_t _err;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sls", &sS, &sS_len, &l4Count, &cValue, &cValue_len) == SUCCESS) && (1 == cValue_len))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_SuffixString(sS, (int32_t)sS_len, (int32_t)l4Count, cValue[0], sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2116237477, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer, char)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, PathFirstComponent)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_PathFirstComponent(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(845708353, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, PathLastComponent)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_PathLastComponent(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1571233744, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, PathCutFirstComponent)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_PathCutFirstComponent(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1859081865, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, PathCutLastComponent)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_PathCutLastComponent(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1239929717, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, PathIsDirectory)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_PathIsDirectory(sPath, (int32_t)sPath_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, PathTrim)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_PathTrim(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(235212813, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, PathConcatenate)
{
	char *sPath1;
	char *sPath2;
	sb_str_size sPath1_len;
	sb_str_size sPath2_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sPath1, &sPath1_len, &sPath2, &sPath2_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_PathConcatenate(sPath1, (int32_t)sPath1_len, sPath2, (int32_t)sPath2_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(924707176, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, PathNormalizeSlashes)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_PathNormalizeSlashes(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(211776927, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, PathReverseSlashes)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_PathReverseSlashes(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(156045233, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, PathMatchesMask)
{
	char *sMask;
	char *sPath;
	sb_str_size sMask_len;
	sb_str_size sPath_len;
	zend_bool bCaseSensitive;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sPath, &sPath_len, &sMask, &sMask_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_PathMatchesMask(sPath, (int32_t)sPath_len, sMask, (int32_t)sMask_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssb", &sPath, &sPath_len, &sMask, &sMask_len, &bCaseSensitive) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_PathMatchesMask_1(sPath, (int32_t)sPath_len, sMask, (int32_t)sMask_len, (int8_t)bCaseSensitive, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string) or (string, string, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, IsFileMask)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_IsFileMask(sPath, (int32_t)sPath_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ExtractPathFromMask)
{
	char *sMask;
	sb_str_size sMask_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sMask, &sMask_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ExtractPathFromMask(sMask, (int32_t)sMask_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(898834100, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SftpNormalizePath)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_SftpNormalizePath(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1995022207, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ZipPathFirstComponent)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ZipPathFirstComponent(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1311314807, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ZipPathLastComponent)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ZipPathLastComponent(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-816976089, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ZipPathCutFirstComponent)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ZipPathCutFirstComponent(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1393851037, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ZipPathCutLastComponent)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ZipPathCutLastComponent(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1161060663, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ZipPathIsDirectory)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_ZipPathIsDirectory(sPath, (int32_t)sPath_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ZipPathTrim)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ZipPathTrim(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(29693647, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ZipPathConcatenate)
{
	char *sPath1;
	char *sPath2;
	sb_str_size sPath1_len;
	sb_str_size sPath2_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sPath1, &sPath1_len, &sPath2, &sPath2_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ZipPathConcatenate(sPath1, (int32_t)sPath1_len, sPath2, (int32_t)sPath2_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1492092015, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ZipPathNormalizeSlashes)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ZipPathNormalizeSlashes(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-5031901, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ZipPathReverseSlashes)
{
	char *sPath;
	sb_str_size sPath_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ZipPathReverseSlashes(sPath, (int32_t)sPath_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1963745415, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ZipPathMatchesMask)
{
	char *sMask;
	char *sPath;
	sb_str_size sMask_len;
	sb_str_size sPath_len;
	zend_bool bCaseSensitive;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sPath, &sPath_len, &sMask, &sMask_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_ZipPathMatchesMask(sPath, (int32_t)sPath_len, sMask, (int32_t)sMask_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssb", &sPath, &sPath_len, &sMask, &sMask_len, &bCaseSensitive) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_ZipPathMatchesMask_1(sPath, (int32_t)sPath_len, sMask, (int32_t)sMask_len, (int8_t)bCaseSensitive, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string) or (string, string, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ZipIsFileMask)
{
	char *sPath;
	sb_str_size sPath_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sPath, &sPath_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(SBStrUtils_ZipIsFileMask(sPath, (int32_t)sPath_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ZipExtractPathFromMask)
{
	char *sMask;
	sb_str_size sMask_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sMask, &sMask_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ZipExtractPathFromMask(sMask, (int32_t)sMask_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1599083866, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, PosExSafe)
{
	char *sS;
	char *sSubStr;
	sb_str_size sS_len;
	sb_str_size sSubStr_len;
	sb_zend_long l4Count;
	sb_zend_long l4Offset;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssll", &sSubStr, &sSubStr_len, &sS, &sS_len, &l4Offset, &l4Count) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_PosExSafe(sSubStr, (int32_t)sSubStr_len, sS, (int32_t)sS_len, (int32_t)l4Offset, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, PosLast)
{
	char *sS;
	char *sSubStr;
	sb_str_size sS_len;
	sb_str_size sSubStr_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sSubStr, &sSubStr_len, &sS, &sS_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_PosLast(sSubStr, (int32_t)sSubStr_len, sS, (int32_t)sS_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, WidePosEx)
{
	char *sS;
	char *sSubStr;
	sb_str_size sS_len;
	sb_str_size sSubStr_len;
	sb_zend_long l4Count;
	sb_zend_long l4Offset;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ssll", &sSubStr, &sSubStr_len, &sS, &sS_len, &l4Offset, &l4Count) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_WidePosEx(sSubStr, (int32_t)sSubStr_len, sS, (int32_t)sS_len, (int32_t)l4Offset, (int32_t)l4Count, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, WidePosLast)
{
	char *sS;
	char *sSubStr;
	sb_str_size sS_len;
	sb_str_size sSubStr_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "ss", &sSubStr, &sSubStr_len, &sS, &sS_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_WidePosLast(sSubStr, (int32_t)sSubStr_len, sS, (int32_t)sS_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, WideStringToByteString)
{
	char *sWS;
	sb_str_size sWS_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sWS, &sWS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_WideStringToByteString(sWS, (int32_t)sWS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(391137432, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, AnsiStringToByteWideString)
{
	char *sS;
	sb_str_size sS_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_AnsiStringToByteWideString(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1302548839, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, IntToStrPadLeft)
{
	char *schTemplate;
	sb_str_size schTemplate_len;
	sb_zend_long l4iWidth;
	sb_zend_long l4Val;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lls", &l4Val, &l4iWidth, &schTemplate, &schTemplate_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_IntToStrPadLeft((int32_t)l4Val, (int32_t)l4iWidth, schTemplate, (int32_t)schTemplate_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1500854115, 3, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer, integer, string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, GetWideBytesOf)
{
	char *sValue;
	sb_str_size sValue_len;
	SBArrayZValInfo aiB;
	uint32_t _err;
	zval *zaB;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sz", &sValue, &sValue_len, &zaB) == SUCCESS) && Z_ISREF_P(zaB) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaB))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaB)))))
	{
		if (!SBGetByteArrayFromZVal(zaB, &aiB TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_GetWideBytesOf(sValue, (int32_t)sValue_len, aiB.data, &aiB.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			SBDetachDataFromZValAndResize(zaB, &aiB TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(930524820, 1, aiB.data, &aiB.len) TSRMLS_CC);
			((char *)aiB.data)[aiB.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiB);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetByteArrayToZVal(&aiB, zaB);
	}
	else
	{
		SBErrorExpectsArguments("(string, &array of byte|string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, GetStringOf)
{
	char *sS;
	int32_t sS_len;
	SBArrayZValInfo aiBytes;
	uint32_t _err;
	zval *zaBytes;
	zval *zsS;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaBytes, &zsS) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBytes) || SB_IS_ARRAY_TYPE_RP(zaBytes) || SB_IS_NULL_TYPE_RP(zaBytes)) && Z_ISREF_P(zsS) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsS))))
	{
		if (!SBGetByteArrayFromZVal(zaBytes, &aiBytes TSRMLS_CC)) RETURN_FALSE;
		sS = Z_STRVAL_P(Z_REFVAL_P(zsS));
		sS_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsS));
		_err = SBStrUtils_GetStringOf(aiBytes.data, aiBytes.len, sS, &sS_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sS = emalloc(sS_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1266397000, 1, sS, &sS_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsS));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiBytes);
		sS[sS_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsS), sS, sS_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, GetStringOfEx)
{
	char *sS;
	int32_t sS_len;
	sb_zend_long l8LPos;
	sb_zend_long l8RPos;
	SBArrayZValInfo aiBytes;
	uint32_t _err;
	zval *zaBytes;
	zval *zsS;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzll", &zaBytes, &zsS, &l8LPos, &l8RPos) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBytes) || SB_IS_ARRAY_TYPE_RP(zaBytes) || SB_IS_NULL_TYPE_RP(zaBytes)) && Z_ISREF_P(zsS) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsS))))
	{
		if (!SBGetByteArrayFromZVal(zaBytes, &aiBytes TSRMLS_CC)) RETURN_FALSE;
		sS = Z_STRVAL_P(Z_REFVAL_P(zsS));
		sS_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsS));
		_err = SBStrUtils_GetStringOfEx(aiBytes.data, aiBytes.len, sS, &sS_len, (int64_t)l8LPos, (int64_t)l8RPos);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sS = emalloc(sS_len + 1);
			SBCheckError(SBGetLastReturnStringA(840842597, 1, sS, &sS_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsS));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiBytes);
		sS[sS_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsS), sS, sS_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &string, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, GetWideStringOf)
{
	char *sWS;
	int32_t sWS_len;
	SBArrayZValInfo aiBytes;
	uint32_t _err;
	zval *zaBytes;
	zval *zsWS;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zz", &zaBytes, &zsWS) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaBytes) || SB_IS_ARRAY_TYPE_RP(zaBytes) || SB_IS_NULL_TYPE_RP(zaBytes)) && Z_ISREF_P(zsWS) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsWS))))
	{
		if (!SBGetByteArrayFromZVal(zaBytes, &aiBytes TSRMLS_CC)) RETURN_FALSE;
		sWS = Z_STRVAL_P(Z_REFVAL_P(zsWS));
		sWS_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsWS));
		_err = SBStrUtils_GetWideStringOf(aiBytes.data, aiBytes.len, sWS, &sWS_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sWS = emalloc(sWS_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2012488584, 1, sWS, &sWS_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsWS));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiBytes);
		sWS[sWS_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsWS), sWS, sWS_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, &string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, TrimEx)
{
	char *sS;
	int32_t sS_len;
	uint32_t _err;
	zend_bool bbTrimLeft;
	zend_bool bbTrimRight;
	zval *zsS;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zbb", &zsS, &bbTrimLeft, &bbTrimRight) == SUCCESS) && Z_ISREF_P(zsS) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsS))))
	{
		sS = Z_STRVAL_P(Z_REFVAL_P(zsS));
		sS_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsS));
		_err = SBStrUtils_TrimEx(sS, &sS_len, (int8_t)bbTrimLeft, (int8_t)bbTrimRight);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sS = emalloc(sS_len + 1);
			SBCheckError(SBGetLastReturnStringA(519703551, 0, sS, &sS_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsS));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sS[sS_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsS), sS, sS_len);
	}
	else
	{
		SBErrorExpectsArguments("(&string, bool, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, TrimSemicolon)
{
	char *sS;
	int32_t sS_len;
	uint32_t _err;
	zval *zsS;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zsS) == SUCCESS) && Z_ISREF_P(zsS) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsS))))
	{
		sS = Z_STRVAL_P(Z_REFVAL_P(zsS));
		sS_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsS));
		_err = SBStrUtils_TrimSemicolon(sS, &sS_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sS = emalloc(sS_len + 1);
			SBCheckError(SBGetLastReturnStringA(-916319805, 0, sS, &sS_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsS));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sS[sS_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsS), sS, sS_len);
	}
	else
	{
		SBErrorExpectsArguments("(&string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ExtractWideFileName)
{
	char *sFileName;
	sb_str_size sFileName_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sFileName, &sFileName_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ExtractWideFileName(sFileName, (int32_t)sFileName_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1355793112, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ExtractFileExtension)
{
	char *sFileName;
	sb_str_size sFileName_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sFileName, &sFileName_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ExtractFileExtension(sFileName, (int32_t)sFileName_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2146827891, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, ExtractWideFileExtension)
{
	char *sFileName;
	sb_str_size sFileName_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sFileName, &sFileName_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_ExtractWideFileExtension(sFileName, (int32_t)sFileName_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(200869886, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, WideTrimRight)
{
	char *sS;
	sb_str_size sS_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sS, &sS_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = SBStrUtils_WideTrimRight(sS, (int32_t)sS_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-2005827768, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, DecodeDateTime)
{
	uint16_t u2ADayRaw = 0;
	uint16_t u2AHourRaw = 0;
	uint16_t u2AMilliSecondRaw = 0;
	uint16_t u2AMinuteRaw = 0;
	uint16_t u2AMonthRaw = 0;
	uint16_t u2ASecondRaw = 0;
	uint16_t u2AYearRaw = 0;
	zval *dtAValue;
	zval *zu2ADay;
	zval *zu2AHour;
	zval *zu2AMilliSecond;
	zval *zu2AMinute;
	zval *zu2AMonth;
	zval *zu2ASecond;
	zval *zu2AYear;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "Ozzzzzzz", &dtAValue, php_date_get_date_ce(), &zu2AYear, &zu2AMonth, &zu2ADay, &zu2AHour, &zu2AMinute, &zu2ASecond, &zu2AMilliSecond) == SUCCESS) && Z_ISREF_P(zu2AYear) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2AYear))) && Z_ISREF_P(zu2AMonth) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2AMonth))) && Z_ISREF_P(zu2ADay) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2ADay))) && Z_ISREF_P(zu2AHour) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2AHour))) && Z_ISREF_P(zu2AMinute) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2AMinute))) && Z_ISREF_P(zu2ASecond) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2ASecond))) && Z_ISREF_P(zu2AMilliSecond) && (IS_LONG == Z_TYPE_P(Z_REFVAL_P(zu2AMilliSecond))))
	{
		SBCheckError(SBStrUtils_DecodeDateTime(SBGetDateTime(dtAValue TSRMLS_CC), &u2AYearRaw, &u2AMonthRaw, &u2ADayRaw, &u2AHourRaw, &u2AMinuteRaw, &u2ASecondRaw, &u2AMilliSecondRaw) TSRMLS_CC);
		ZVAL_LONG(Z_REFVAL_P(zu2AYear), (sb_zend_long)u2AYearRaw);
		ZVAL_LONG(Z_REFVAL_P(zu2AMonth), (sb_zend_long)u2AMonthRaw);
		ZVAL_LONG(Z_REFVAL_P(zu2ADay), (sb_zend_long)u2ADayRaw);
		ZVAL_LONG(Z_REFVAL_P(zu2AHour), (sb_zend_long)u2AHourRaw);
		ZVAL_LONG(Z_REFVAL_P(zu2AMinute), (sb_zend_long)u2AMinuteRaw);
		ZVAL_LONG(Z_REFVAL_P(zu2ASecond), (sb_zend_long)u2ASecondRaw);
		ZVAL_LONG(Z_REFVAL_P(zu2AMilliSecond), (sb_zend_long)u2AMilliSecondRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\DateTime, &integer, &integer, &integer, &integer, &integer, &integer, &integer)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SBDecStr2ToIntDef)
{
	char *sSourceString;
	sb_str_size sSourceString_len;
	sb_zend_long l4DefaultValue;
	sb_zend_long l4StartOffset;
	zend_bool bSkipLengthCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sllb", &sSourceString, &sSourceString_len, &l4StartOffset, &l4DefaultValue, &bSkipLengthCheck) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_SBDecStr2ToIntDef(sSourceString, (int32_t)sSourceString_len, (int32_t)l4StartOffset, (int32_t)l4DefaultValue, (int8_t)bSkipLengthCheck, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SBDecStr3ToIntDef)
{
	char *sSourceString;
	sb_str_size sSourceString_len;
	sb_zend_long l4DefaultValue;
	sb_zend_long l4StartOffset;
	zend_bool bSkipLengthCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sllb", &sSourceString, &sSourceString_len, &l4StartOffset, &l4DefaultValue, &bSkipLengthCheck) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_SBDecStr3ToIntDef(sSourceString, (int32_t)sSourceString_len, (int32_t)l4StartOffset, (int32_t)l4DefaultValue, (int8_t)bSkipLengthCheck, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SBDecStr4ToIntDef)
{
	char *sSourceString;
	sb_str_size sSourceString_len;
	sb_zend_long l4DefaultValue;
	sb_zend_long l4StartOffset;
	zend_bool bSkipLengthCheck;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sllb", &sSourceString, &sSourceString_len, &l4StartOffset, &l4DefaultValue, &bSkipLengthCheck) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_SBDecStr4ToIntDef(sSourceString, (int32_t)sSourceString_len, (int32_t)l4StartOffset, (int32_t)l4DefaultValue, (int8_t)bSkipLengthCheck, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, integer, integer, bool)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SBLength)
{
	char *sStr;
	sb_str_size sStr_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sStr, &sStr_len) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(SBStrUtils_SBLength(sStr, (int32_t)sStr_len, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBStrUtils, SBStringZToString)
{
	SBArrayZValInfo aiCS;
	uint32_t _err;
	zval *zaCS;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaCS) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaCS) || SB_IS_ARRAY_TYPE_RP(zaCS) || SB_IS_NULL_TYPE_RP(zaCS)))
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaCS, &aiCS TSRMLS_CC)) RETURN_FALSE;
		_err = SBStrUtils_SBStringZToString(aiCS.data, aiCS.len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-736136683, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiCS);
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

void Register_SBStrUtils_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBStrUtils, CP_UTF8, SB_CP_UTF8, SB_CP_UTF8);
}
