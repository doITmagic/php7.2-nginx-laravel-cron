#include "sbu2fclient.h"

zend_class_entry *TElU2FDevice_ce_ptr = NULL;

SB_PHP_METHOD(TElU2FDevice, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElU2FDevice_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FDevice___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElU2FDevice_methods[] = {
	PHP_ME(TElU2FDevice, __construct, arginfo_TElU2FDevice___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElU2FDevice(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElU2FDevice_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElU2FDevice", TElU2FDevice_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElU2FDevice_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElU2FHIDDevice_ce_ptr = NULL;

SB_PHP_METHOD(TElU2FHIDDevice, Lock)
{
	sb_zend_long l4TimePeriod;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4TimePeriod) == SUCCESS)
	{
		SBCheckError(TElU2FHIDDevice_Lock(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4TimePeriod) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, Unlock)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElU2FHIDDevice_Unlock(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, Ping)
{
	SBArrayZValInfo aiData;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElU2FHIDDevice_Ping(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, Sync)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElU2FHIDDevice_Sync(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, Wink)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElU2FHIDDevice_Wink(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, SendMessage)
{
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zll", &zaData, &l4StartIndex, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = TElU2FHIDDevice_SendMessage(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, (int32_t)l4StartIndex, (int32_t)l4Count, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1228806298, 4, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, SendVendorCommand)
{
	sb_zend_long l4Count;
	sb_zend_long l4StartIndex;
	sb_zend_long u1Command;
	SBArrayZValInfo aiData;
	uint32_t _err;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzll", &u1Command, &zaData, &l4StartIndex, &l4Count) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = TElU2FHIDDevice_SendVendorCommand(SBGetObjectHandle(getThis() TSRMLS_CC), (uint8_t)u1Command, aiData.data, aiData.len, (int32_t)l4StartIndex, (int32_t)l4Count, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(568085069, 5, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer, array of byte|string|NULL, integer, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, get_AutoWink)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElU2FHIDDevice_get_AutoWink(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, set_AutoWink)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElU2FHIDDevice_set_AutoWink(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, get_CapabilitiesFlags)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElU2FHIDDevice_get_CapabilitiesFlags(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, get_VersionInterface)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElU2FHIDDevice_get_VersionInterface(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, get_VersionMajor)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElU2FHIDDevice_get_VersionMajor(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, get_VersionMinor)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElU2FHIDDevice_get_VersionMinor(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, get_VersionBuild)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t u1OutResultRaw = 0;
		SBCheckError(TElU2FHIDDevice_get_VersionBuild(SBGetObjectHandle(getThis() TSRMLS_CC), &u1OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)u1OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, get_U2FVersion)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElU2FHIDDevice_get_U2FVersion(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1562110111, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, get_HIDDevice)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElU2FHIDDevice_get_HIDDevice(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElHIDDevice_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FHIDDevice, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElU2FHIDDevice_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_Lock, 0, 0, 1)
	ZEND_ARG_INFO(0, TimePeriod)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_Unlock, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_Ping, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_Sync, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_Wink, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_SendMessage, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_SendVendorCommand, 0, 0, 4)
	ZEND_ARG_INFO(0, Command)
	ZEND_ARG_TYPE_INFO(0, Data, 0, 1)
	ZEND_ARG_INFO(0, StartIndex)
	ZEND_ARG_INFO(0, Count)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_get_AutoWink, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_set_AutoWink, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_get_CapabilitiesFlags, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_get_VersionInterface, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_get_VersionMajor, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_get_VersionMinor, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_get_VersionBuild, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_get_U2FVersion, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice_get_HIDDevice, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FHIDDevice___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElU2FHIDDevice_methods[] = {
	PHP_ME(TElU2FHIDDevice, Lock, arginfo_TElU2FHIDDevice_Lock, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, Unlock, arginfo_TElU2FHIDDevice_Unlock, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, Ping, arginfo_TElU2FHIDDevice_Ping, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, Sync, arginfo_TElU2FHIDDevice_Sync, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, Wink, arginfo_TElU2FHIDDevice_Wink, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, SendMessage, arginfo_TElU2FHIDDevice_SendMessage, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, SendVendorCommand, arginfo_TElU2FHIDDevice_SendVendorCommand, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, get_AutoWink, arginfo_TElU2FHIDDevice_get_AutoWink, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, set_AutoWink, arginfo_TElU2FHIDDevice_set_AutoWink, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, get_CapabilitiesFlags, arginfo_TElU2FHIDDevice_get_CapabilitiesFlags, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, get_VersionInterface, arginfo_TElU2FHIDDevice_get_VersionInterface, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, get_VersionMajor, arginfo_TElU2FHIDDevice_get_VersionMajor, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, get_VersionMinor, arginfo_TElU2FHIDDevice_get_VersionMinor, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, get_VersionBuild, arginfo_TElU2FHIDDevice_get_VersionBuild, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, get_U2FVersion, arginfo_TElU2FHIDDevice_get_U2FVersion, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, get_HIDDevice, arginfo_TElU2FHIDDevice_get_HIDDevice, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FHIDDevice, __construct, arginfo_TElU2FHIDDevice___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElU2FHIDDevice(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElU2FHIDDevice_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElU2FHIDDevice", TElU2FHIDDevice_methods);
	if (NULL == TElU2FDevice_ce_ptr)
		Register_TElU2FDevice(TSRMLS_C);
	TElU2FHIDDevice_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElU2FDevice_ce_ptr);
}

zend_class_entry *TElU2FClient_ce_ptr = NULL;

SB_PHP_METHOD(TElU2FClient, RegisterUser)
{
	char *sJSONClientData;
	char *sJSONRegistrationChallenge;
	char *sU2FRegisterRequest;
	char *sU2FRegisterResponse;
	int32_t sJSONClientData_len;
	int32_t sU2FRegisterResponse_len;
	sb_str_size sJSONRegistrationChallenge_len;
	sb_str_size sU2FRegisterRequest_len;
	SBArrayZValInfo aiRegistrationData;
	uint32_t _err;
	zval *oDevice;
	zval *zaRegistrationData;
	zval *zsJSONClientData;
	zval *zsU2FRegisterResponse;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!szz", &oDevice, TElU2FDevice_ce_ptr, &sJSONRegistrationChallenge, &sJSONRegistrationChallenge_len, &zsJSONClientData, &zaRegistrationData) == SUCCESS) && Z_ISREF_P(zsJSONClientData) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsJSONClientData))) && Z_ISREF_P(zaRegistrationData) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaRegistrationData))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaRegistrationData)))))
	{
		sJSONClientData = Z_STRVAL_P(Z_REFVAL_P(zsJSONClientData));
		sJSONClientData_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsJSONClientData));
		if (!SBGetByteArrayFromZVal(zaRegistrationData, &aiRegistrationData TSRMLS_CC)) RETURN_FALSE;
		_err = TElU2FClient_RegisterUser(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDevice TSRMLS_CC), sJSONRegistrationChallenge, (int32_t)sJSONRegistrationChallenge_len, sJSONClientData, &sJSONClientData_len, aiRegistrationData.data, &aiRegistrationData.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sJSONClientData = emalloc(sJSONClientData_len + 1);
			SBCheckError(SBGetLastReturnStringA(-561067981, 3, sJSONClientData, &sJSONClientData_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsJSONClientData));
			SBDetachDataFromZValAndResize(zaRegistrationData, &aiRegistrationData TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-561067981, 4, aiRegistrationData.data, &aiRegistrationData.len) TSRMLS_CC);
			((char *)aiRegistrationData.data)[aiRegistrationData.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiRegistrationData);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sJSONClientData[sJSONClientData_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsJSONClientData), sJSONClientData, sJSONClientData_len);
		SBSetByteArrayToZVal(&aiRegistrationData, zaRegistrationData);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sz", &sU2FRegisterRequest, &sU2FRegisterRequest_len, &zsU2FRegisterResponse) == SUCCESS) && Z_ISREF_P(zsU2FRegisterResponse) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsU2FRegisterResponse))))
	{
		int32_t l4OutResultRaw = 0;
		sU2FRegisterResponse = Z_STRVAL_P(Z_REFVAL_P(zsU2FRegisterResponse));
		sU2FRegisterResponse_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsU2FRegisterResponse));
		_err = TElU2FClient_RegisterUser_1(SBGetObjectHandle(getThis() TSRMLS_CC), sU2FRegisterRequest, (int32_t)sU2FRegisterRequest_len, sU2FRegisterResponse, &sU2FRegisterResponse_len, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sU2FRegisterResponse = emalloc(sU2FRegisterResponse_len + 1);
			SBCheckError(SBGetLastReturnStringA(1981981944, 2, sU2FRegisterResponse, &sU2FRegisterResponse_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsU2FRegisterResponse));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sU2FRegisterResponse[sU2FRegisterResponse_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsU2FRegisterResponse), sU2FRegisterResponse, sU2FRegisterResponse_len);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElU2FDevice, string, &string, &array of byte|string) or (string, &string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FClient, AuthenticateUser)
{
	char *sJSONAuthenticationChallenge;
	char *sJSONClientData;
	char *sU2FSignRequest;
	char *sU2FSignResponse;
	int32_t sJSONClientData_len;
	int32_t sU2FSignResponse_len;
	sb_str_size sJSONAuthenticationChallenge_len;
	sb_str_size sU2FSignRequest_len;
	SBArrayZValInfo aiAuthData;
	uint32_t _err;
	zval *oUserKeys;
	zval *zaAuthData;
	zval *zsJSONClientData;
	zval *zsU2FSignResponse;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!zz", &sJSONAuthenticationChallenge, &sJSONAuthenticationChallenge_len, &oUserKeys, TElU2FUserKeys_ce_ptr, &zsJSONClientData, &zaAuthData) == SUCCESS) && Z_ISREF_P(zsJSONClientData) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsJSONClientData))) && Z_ISREF_P(zaAuthData) && ((IS_STRING == Z_TYPE_P(Z_REFVAL_P(zaAuthData))) || (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(zaAuthData)))))
	{
		sJSONClientData = Z_STRVAL_P(Z_REFVAL_P(zsJSONClientData));
		sJSONClientData_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsJSONClientData));
		if (!SBGetByteArrayFromZVal(zaAuthData, &aiAuthData TSRMLS_CC)) RETURN_FALSE;
		_err = TElU2FClient_AuthenticateUser(SBGetObjectHandle(getThis() TSRMLS_CC), sJSONAuthenticationChallenge, (int32_t)sJSONAuthenticationChallenge_len, SBGetObjectHandle(oUserKeys TSRMLS_CC), sJSONClientData, &sJSONClientData_len, aiAuthData.data, &aiAuthData.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sJSONClientData = emalloc(sJSONClientData_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1792658130, 3, sJSONClientData, &sJSONClientData_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsJSONClientData));
			SBDetachDataFromZValAndResize(zaAuthData, &aiAuthData TSRMLS_CC);
			SBCheckError(SBGetLastReturnBuffer(-1792658130, 4, aiAuthData.data, &aiAuthData.len) TSRMLS_CC);
			((char *)aiAuthData.data)[aiAuthData.len] = 0;
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiAuthData);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sJSONClientData[sJSONClientData_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsJSONClientData), sJSONClientData, sJSONClientData_len);
		SBSetByteArrayToZVal(&aiAuthData, zaAuthData);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sz", &sU2FSignRequest, &sU2FSignRequest_len, &zsU2FSignResponse) == SUCCESS) && Z_ISREF_P(zsU2FSignResponse) && (IS_STRING == Z_TYPE_P(Z_REFVAL_P(zsU2FSignResponse))))
	{
		int32_t l4OutResultRaw = 0;
		sU2FSignResponse = Z_STRVAL_P(Z_REFVAL_P(zsU2FSignResponse));
		sU2FSignResponse_len = (int32_t)Z_STRLEN_P(Z_REFVAL_P(zsU2FSignResponse));
		_err = TElU2FClient_AuthenticateUser_1(SBGetObjectHandle(getThis() TSRMLS_CC), sU2FSignRequest, (int32_t)sU2FSignRequest_len, sU2FSignResponse, &sU2FSignResponse_len, &l4OutResultRaw);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sU2FSignResponse = emalloc(sU2FSignResponse_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1903940562, 2, sU2FSignResponse, &sU2FSignResponse_len) TSRMLS_CC);
			zval_dtor(Z_REFVAL_P(zsU2FSignResponse));
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		sU2FSignResponse[sU2FSignResponse_len] = 0;
		SB_ZVAL_STRINGL_UPDATE(Z_REFVAL_P(zsU2FSignResponse), sU2FSignResponse, sU2FSignResponse_len);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TElU2FUserKeys, &string, &array of byte|string) or (string, &string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FClient, AddDevice)
{
	zval *oDevice;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDevice, TElU2FDevice_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElU2FClient_AddDevice(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDevice TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElU2FDevice)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FClient, EnumerateDevices)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElU2FClient_EnumerateDevices(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FClient, get_RetryIterations)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElU2FClient_get_RetryIterations(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FClient, get_RetryInterval)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElU2FClient_get_RetryInterval(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FClient, get_U2FDeviceCount)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElU2FClient_get_U2FDeviceCount(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FClient, get_U2FDevices)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElU2FClient_get_U2FDevices(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElU2FDevice_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElU2FClient, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElU2FClient_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FClient_RegisterUser, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Device_or_U2FRegisterRequest, 0, 1)
	ZEND_ARG_INFO(1, JSONRegistrationChallenge_or_U2FRegisterResponse)
	ZEND_ARG_INFO(1, JSONClientData)
	ZEND_ARG_INFO(1, RegistrationData)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FClient_AuthenticateUser, 0, 0, 2)
	ZEND_ARG_INFO(0, JSONAuthenticationChallenge_or_U2FSignRequest)
	ZEND_ARG_TYPE_INFO(1, UserKeys_or_U2FSignResponse, 0, 1)
	ZEND_ARG_INFO(1, JSONClientData)
	ZEND_ARG_INFO(1, AuthData)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FClient_AddDevice, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Device, TElU2FDevice, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FClient_EnumerateDevices, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FClient_get_RetryIterations, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FClient_get_RetryInterval, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FClient_get_U2FDeviceCount, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FClient_get_U2FDevices, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElU2FClient___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElU2FClient_methods[] = {
	PHP_ME(TElU2FClient, RegisterUser, arginfo_TElU2FClient_RegisterUser, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FClient, AuthenticateUser, arginfo_TElU2FClient_AuthenticateUser, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FClient, AddDevice, arginfo_TElU2FClient_AddDevice, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FClient, EnumerateDevices, arginfo_TElU2FClient_EnumerateDevices, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FClient, get_RetryIterations, arginfo_TElU2FClient_get_RetryIterations, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FClient, get_RetryInterval, arginfo_TElU2FClient_get_RetryInterval, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FClient, get_U2FDeviceCount, arginfo_TElU2FClient_get_U2FDeviceCount, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FClient, get_U2FDevices, arginfo_TElU2FClient_get_U2FDevices, ZEND_ACC_PUBLIC)
	PHP_ME(TElU2FClient, __construct, arginfo_TElU2FClient___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElU2FClient(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElU2FClient_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElU2FClient", TElU2FClient_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElU2FClient_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

