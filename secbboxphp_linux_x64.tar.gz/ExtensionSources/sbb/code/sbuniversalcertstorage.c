#include "sbuniversalcertstorage.h"

zend_class_entry *TElUniversalCertStorage_ce_ptr = NULL;

SB_PHP_METHOD(TElUniversalCertStorage, Add)
{
	SBArrayZValInfo aiKeyID;
	zend_bool bCopyPrivateKey;
	zval *oCert;
	zval *zaKeyID;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oCert, TElX509Certificate_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElUniversalCertStorage_Add(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oCert, TElX509Certificate_ce_ptr, &bCopyPrivateKey) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElUniversalCertStorage_Add_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), (int8_t)bCopyPrivateKey, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!bz", &oCert, TElX509Certificate_ce_ptr, &bCopyPrivateKey, &zaKeyID) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaKeyID) || SB_IS_ARRAY_TYPE_RP(zaKeyID) || SB_IS_NULL_TYPE_RP(zaKeyID)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaKeyID, &aiKeyID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElUniversalCertStorage_Add_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCert TSRMLS_CC), (int8_t)bCopyPrivateKey, aiKeyID.data, aiKeyID.len, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiKeyID);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate) or (\\TElX509Certificate, bool) or (\\TElX509Certificate, bool, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElUniversalCertStorage, Remove)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElUniversalCertStorage_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElUniversalCertStorage, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElUniversalCertStorage_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElUniversalCertStorage, Find)
{
	sb_zend_long l4StartFrom;
	SBArrayZValInfo aiKeyID;
	zval *oSubject;
	zval *zaKeyID;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaKeyID, &l4StartFrom) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaKeyID) || SB_IS_ARRAY_TYPE_RP(zaKeyID) || SB_IS_NULL_TYPE_RP(zaKeyID)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaKeyID, &aiKeyID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElUniversalCertStorage_Find(SBGetObjectHandle(getThis() TSRMLS_CC), aiKeyID.data, aiKeyID.len, (int32_t)l4StartFrom, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiKeyID);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaKeyID) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaKeyID) || SB_IS_ARRAY_TYPE_RP(zaKeyID) || SB_IS_NULL_TYPE_RP(zaKeyID)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaKeyID, &aiKeyID TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElUniversalCertStorage_Find_1(SBGetObjectHandle(getThis() TSRMLS_CC), aiKeyID.data, aiKeyID.len, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiKeyID);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oSubject, TElRelativeDistinguishedName_ce_ptr, &l4StartFrom) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElUniversalCertStorage_Find_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSubject TSRMLS_CC), (int32_t)l4StartFrom, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oSubject, TElRelativeDistinguishedName_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElUniversalCertStorage_Find_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oSubject TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer) or (array of byte|string|NULL) or (\\TElRelativeDistinguishedName, integer) or (\\TElRelativeDistinguishedName)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElUniversalCertStorage, FindCertByAttribute)
{
	sb_zend_long l4StartFrom;
	SBArrayZValInfo aiAttrID;
	SBArrayZValInfo aiAttrValue;
	zval *zaAttrID;
	zval *zaAttrValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zzl", &zaAttrID, &zaAttrValue, &l4StartFrom) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAttrID) || SB_IS_ARRAY_TYPE_RP(zaAttrID) || SB_IS_NULL_TYPE_RP(zaAttrID)) && (SB_IS_STRING_TYPE_RP(zaAttrValue) || SB_IS_ARRAY_TYPE_RP(zaAttrValue) || SB_IS_NULL_TYPE_RP(zaAttrValue)))
	{
		int32_t l4OutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaAttrID, &aiAttrID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaAttrValue, &aiAttrValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElUniversalCertStorage_FindCertByAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), aiAttrID.data, aiAttrID.len, aiAttrValue.data, aiAttrValue.len, (int32_t)l4StartFrom, &l4OutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAttrID);
		SBFreeArrayZValInfo(&aiAttrValue);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, array of byte|string|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElUniversalCertStorage, GetCertAttribute)
{
	int8_t bProtectedRaw;
	sb_zend_long l4Index;
	SBArrayZValInfo aiAttrID;
	SBArrayZValInfo aiDefault;
	uint32_t _err;
	zval *zaAttrID;
	zval *zaDefault;
	zval *zbProtected;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzzz", &l4Index, &zaAttrID, &zbProtected, &zaDefault) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAttrID) || SB_IS_ARRAY_TYPE_RP(zaAttrID) || SB_IS_NULL_TYPE_RP(zaAttrID)) && Z_ISREF_P(zbProtected) && SB_IS_BOOL_TYPE_P(Z_REFVAL_P(zbProtected)) && (SB_IS_STRING_TYPE_RP(zaDefault) || SB_IS_ARRAY_TYPE_RP(zaDefault) || SB_IS_NULL_TYPE_RP(zaDefault)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaAttrID, &aiAttrID TSRMLS_CC)) RETURN_FALSE;
		bProtectedRaw = (int8_t)SB_BVAL_P(Z_REFVAL_P(zbProtected));
		if (!SBGetByteArrayFromZVal(zaDefault, &aiDefault TSRMLS_CC)) RETURN_FALSE;
		_err = TElUniversalCertStorage_GetCertAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, aiAttrID.data, aiAttrID.len, &bProtectedRaw, aiDefault.data, aiDefault.len, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(853888977, 5, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiAttrID);
		ZVAL_BOOL(Z_REFVAL_P(zbProtected), (zend_bool)bProtectedRaw);
		SBFreeArrayZValInfo(&aiDefault);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer, array of byte|string|NULL, &bool, array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElUniversalCertStorage, SetCertAttribute)
{
	sb_zend_long l4Index;
	SBArrayZValInfo aiAttrID;
	SBArrayZValInfo aiAttrValue;
	zend_bool bProtected;
	zval *zaAttrID;
	zval *zaAttrValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lzzb", &l4Index, &zaAttrID, &zaAttrValue, &bProtected) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaAttrID) || SB_IS_ARRAY_TYPE_RP(zaAttrID) || SB_IS_NULL_TYPE_RP(zaAttrID)) && (SB_IS_STRING_TYPE_RP(zaAttrValue) || SB_IS_ARRAY_TYPE_RP(zaAttrValue) || SB_IS_NULL_TYPE_RP(zaAttrValue)))
	{
		if (!SBGetByteArrayFromZVal(zaAttrID, &aiAttrID TSRMLS_CC)) RETURN_FALSE;
		if (!SBGetByteArrayFromZVal(zaAttrValue, &aiAttrValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElUniversalCertStorage_SetCertAttribute(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, aiAttrID.data, aiAttrID.len, aiAttrValue.data, aiAttrValue.len, (int8_t)bProtected) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiAttrID);
		SBFreeArrayZValInfo(&aiAttrValue);
	}
	else
	{
		SBErrorExpectsArguments("(integer, array of byte|string|NULL, array of byte|string|NULL, bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElUniversalCertStorage, get_Certificates)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElUniversalCertStorage_get_Certificates(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElUniversalCertStorage, get_CertificateIDs)
{
	sb_zend_long l4Index;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElUniversalCertStorage_get_CertificateIDs(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-513844377, 2, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElUniversalCertStorage, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElUniversalCertStorage_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElUniversalCertStorage, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElUniversalCertStorage_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUniversalCertStorage_Add, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Cert, TElX509Certificate, 1)
	ZEND_ARG_INFO(0, CopyPrivateKey)
	ZEND_ARG_TYPE_INFO(0, KeyID, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUniversalCertStorage_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUniversalCertStorage_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUniversalCertStorage_Find, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, KeyID_or_Subject, 0, 1)
	ZEND_ARG_INFO(0, StartFrom)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUniversalCertStorage_FindCertByAttribute, 0, 0, 3)
	ZEND_ARG_TYPE_INFO(0, AttrID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AttrValue, 0, 1)
	ZEND_ARG_INFO(0, StartFrom)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUniversalCertStorage_GetCertAttribute, 0, 0, 4)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_TYPE_INFO(0, AttrID, 0, 1)
	ZEND_ARG_INFO(1, Protected)
	ZEND_ARG_TYPE_INFO(0, Default, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUniversalCertStorage_SetCertAttribute, 0, 0, 4)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_TYPE_INFO(0, AttrID, 0, 1)
	ZEND_ARG_TYPE_INFO(0, AttrValue, 0, 1)
	ZEND_ARG_INFO(0, Protected)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUniversalCertStorage_get_Certificates, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUniversalCertStorage_get_CertificateIDs, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUniversalCertStorage_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElUniversalCertStorage___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElUniversalCertStorage_methods[] = {
	PHP_ME(TElUniversalCertStorage, Add, arginfo_TElUniversalCertStorage_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElUniversalCertStorage, Remove, arginfo_TElUniversalCertStorage_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElUniversalCertStorage, Clear, arginfo_TElUniversalCertStorage_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElUniversalCertStorage, Find, arginfo_TElUniversalCertStorage_Find, ZEND_ACC_PUBLIC)
	PHP_ME(TElUniversalCertStorage, FindCertByAttribute, arginfo_TElUniversalCertStorage_FindCertByAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElUniversalCertStorage, GetCertAttribute, arginfo_TElUniversalCertStorage_GetCertAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElUniversalCertStorage, SetCertAttribute, arginfo_TElUniversalCertStorage_SetCertAttribute, ZEND_ACC_PUBLIC)
	PHP_ME(TElUniversalCertStorage, get_Certificates, arginfo_TElUniversalCertStorage_get_Certificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElUniversalCertStorage, get_CertificateIDs, arginfo_TElUniversalCertStorage_get_CertificateIDs, ZEND_ACC_PUBLIC)
	PHP_ME(TElUniversalCertStorage, get_Count, arginfo_TElUniversalCertStorage_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElUniversalCertStorage, __construct, arginfo_TElUniversalCertStorage___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElUniversalCertStorage(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElUniversalCertStorage_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElUniversalCertStorage", TElUniversalCertStorage_methods);
	if (NULL == TElUniversalKeyStorage_ce_ptr)
		Register_TElUniversalKeyStorage(TSRMLS_C);
	TElUniversalCertStorage_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElUniversalKeyStorage_ce_ptr);
}

void Register_SBUniversalCertStorage_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBUniversalCertStorage, ERROR_KS_MOD_CERTSTORAGE, SB_ERROR_KS_MOD_CERTSTORAGE, SB_ERROR_KS_MOD_CERTSTORAGE);
	SB_REGISTER_LONG_CONSTANT(SBUniversalCertStorage, ERROR_KS_CERT_NOT_FOUND, SB_ERROR_KS_CERT_NOT_FOUND, SB_ERROR_KS_CERT_NOT_FOUND);
	SB_REGISTER_LONG_CONSTANT(SBUniversalCertStorage, ERROR_KS_OBJECT_NOT_A_CERT, SB_ERROR_KS_OBJECT_NOT_A_CERT, SB_ERROR_KS_OBJECT_NOT_A_CERT);
	SB_REGISTER_LONG_CONSTANT(SBUniversalCertStorage, ERROR_KS_FAILED_TO_ADD_KEY, SB_ERROR_KS_FAILED_TO_ADD_KEY, SB_ERROR_KS_FAILED_TO_ADD_KEY);
	SB_REGISTER_LONG_CONSTANT(SBUniversalCertStorage, ERROR_KS_FAILED_TO_ADD_CERT, SB_ERROR_KS_FAILED_TO_ADD_CERT, SB_ERROR_KS_FAILED_TO_ADD_CERT);
	SB_REGISTER_LONG_CONSTANT(SBUniversalCertStorage, ERROR_KS_UNSUPPORTED_CERT_ALGORITHM, SB_ERROR_KS_UNSUPPORTED_CERT_ALGORITHM, SB_ERROR_KS_UNSUPPORTED_CERT_ALGORITHM);
	SB_REGISTER_STRING_CONSTANT(SBUniversalCertStorage, SCertNotFound, SB_SCertNotFound, SB_SCertNotFound);
	SB_REGISTER_STRING_CONSTANT(SBUniversalCertStorage, SObjectNotACert, SB_SObjectNotACert, SB_SObjectNotACert);
	SB_REGISTER_STRING_CONSTANT(SBUniversalCertStorage, SFailedToAddKey, SB_SFailedToAddKey, SB_SFailedToAddKey);
	SB_REGISTER_STRING_CONSTANT(SBUniversalCertStorage, SFailedToAddCert, SB_SFailedToAddCert, SB_SFailedToAddCert);
}

