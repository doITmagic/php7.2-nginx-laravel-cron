#include "sbdefs.h"
#ifdef SB_WINDOWS
#include "sbwincertstorage.h"

zend_class_entry *TSBStorageType_ce_ptr = NULL;

zend_class_entry *TSBStorageAccessType_ce_ptr = NULL;

zend_class_entry *TSBStorageProviderType_ce_ptr = NULL;

zend_class_entry *TElWinCertStorage_ce_ptr = NULL;

SB_PHP_METHOD(TElWinCertStorage, GetAvailableStores_Inst)
{
	sb_zend_long fAccessType;
	zval *oStores;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStores, TStrings_ce_ptr, &fAccessType) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_GetAvailableStores_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oStores TSRMLS_CC), (TSBStorageAccessTypeRaw)fAccessType) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStrings, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, GetAvailableStores)
{
	sb_zend_long fAccessType;
	zval *oStores;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oStores, TStrings_ce_ptr, &fAccessType) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_GetAvailableStores(SBGetObjectHandle(oStores TSRMLS_CC), (TSBStorageAccessTypeRaw)fAccessType) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStrings, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, GetAvailablePhysicalStores_Inst)
{
	char *sSystemStore;
	sb_str_size sSystemStore_len;
	sb_zend_long fAccessType;
	zval *oStores;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!l", &sSystemStore, &sSystemStore_len, &oStores, TStrings_ce_ptr, &fAccessType) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_GetAvailablePhysicalStores_1(SBGetObjectHandle(getThis() TSRMLS_CC), sSystemStore, (int32_t)sSystemStore_len, SBGetObjectHandle(oStores TSRMLS_CC), (TSBStorageAccessTypeRaw)fAccessType) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TStrings, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, GetAvailablePhysicalStores)
{
	char *sSystemStore;
	sb_str_size sSystemStore_len;
	sb_zend_long fAccessType;
	zval *oStores;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "sO!l", &sSystemStore, &sSystemStore_len, &oStores, TStrings_ce_ptr, &fAccessType) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_GetAvailablePhysicalStores(sSystemStore, (int32_t)sSystemStore_len, SBGetObjectHandle(oStores TSRMLS_CC), (TSBStorageAccessTypeRaw)fAccessType) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string, \\TStrings, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, GetStoreFriendlyName_Inst)
{
	char *sStoreName;
	sb_str_size sStoreName_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sStoreName, &sStoreName_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElWinCertStorage_GetStoreFriendlyName_1(SBGetObjectHandle(getThis() TSRMLS_CC), sStoreName, (int32_t)sStoreName_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(53182698, 2, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, GetStoreFriendlyName)
{
	char *sStoreName;
	sb_str_size sStoreName_len;
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sStoreName, &sStoreName_len) == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElWinCertStorage_GetStoreFriendlyName(sStoreName, (int32_t)sStoreName_len, sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(53182698, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, Add)
{
	char *sPrivateKeyContainerName;
	char *sStoreName;
	sb_str_size sPrivateKeyContainerName_len;
	sb_str_size sStoreName_len;
	zend_bool bBindToExistingPrivateKey;
	zend_bool bCopyPrivateKey;
	zend_bool bExportable;
	zend_bool bProtected;
	zval *oCertificate;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!b", &oCertificate, TElX509Certificate_ce_ptr, &bCopyPrivateKey) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_Add(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (int8_t)bCopyPrivateKey) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!sbbb", &oCertificate, TElX509Certificate_ce_ptr, &sStoreName, &sStoreName_len, &bCopyPrivateKey, &bExportable, &bProtected) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_Add_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), sStoreName, (int32_t)sStoreName_len, (int8_t)bCopyPrivateKey, (int8_t)bExportable, (int8_t)bProtected) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!bss", &oCertificate, TElX509Certificate_ce_ptr, &bBindToExistingPrivateKey, &sStoreName, &sStoreName_len, &sPrivateKeyContainerName, &sPrivateKeyContainerName_len) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_Add_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oCertificate TSRMLS_CC), (int8_t)bBindToExistingPrivateKey, sStoreName, (int32_t)sStoreName_len, sPrivateKeyContainerName, (int32_t)sPrivateKeyContainerName_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElX509Certificate, bool) or (\\TElX509Certificate, string, bool, bool, bool) or (\\TElX509Certificate, bool, string, string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, Remove)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_Remove(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, Refresh)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_Refresh(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, PreloadCertificates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_PreloadCertificates(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, CreateStore)
{
	char *sStoreName;
	sb_str_size sStoreName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sStoreName, &sStoreName_len) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_CreateStore(SBGetObjectHandle(getThis() TSRMLS_CC), sStoreName, (int32_t)sStoreName_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, DeleteStore)
{
	char *sStoreName;
	sb_str_size sStoreName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sStoreName, &sStoreName_len) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_DeleteStore(SBGetObjectHandle(getThis() TSRMLS_CC), sStoreName, (int32_t)sStoreName_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, ListKeyContainers)
{
	sb_zend_long fProvType;
	zval *oList;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oList, TElStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_ListKeyContainers(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oList TSRMLS_CC)) TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oList, TElStringList_ce_ptr, &fProvType) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_ListKeyContainers_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oList TSRMLS_CC), (TSBStorageProviderTypeRaw)fProvType) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElStringList) or (\\TElStringList, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, DeleteKeyContainer)
{
	char *sContainerName;
	sb_str_size sContainerName_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sContainerName, &sContainerName_len) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_DeleteKeyContainer(SBGetObjectHandle(getThis() TSRMLS_CC), sContainerName, (int32_t)sContainerName_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, Select)
{
	sb_zend_long u4Owner;
	zval *oSelectedList;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &u4Owner, &oSelectedList, TElCustomCertStorage_ce_ptr) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElWinCertStorage_Select(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Owner, SBGetObjectHandle(oSelectedList TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElCustomCertStorage)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, ImportWizard_Inst)
{
	sb_zend_long u4Owner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Owner) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElWinCertStorage_ImportWizard_1(SBGetObjectHandle(getThis() TSRMLS_CC), (uint32_t)u4Owner, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, ImportWizard)
{
	sb_zend_long u4Owner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &u4Owner) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElWinCertStorage_ImportWizard((uint32_t)u4Owner, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElWinCertStorage_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, get_Certificates)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElWinCertStorage_get_Certificates(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElX509Certificate_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, get_TryCurrentUser)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElWinCertStorage_get_TryCurrentUser(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, set_TryCurrentUser)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_set_TryCurrentUser(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, get_SystemStores)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElWinCertStorage_get_SystemStores(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, set_SystemStores)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_set_SystemStores(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, get_PhysicalStores)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElWinCertStorage_get_PhysicalStores(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TStringList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, set_PhysicalStores)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TStringList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_set_PhysicalStores(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TStringList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, get_StorageType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBStorageTypeRaw fOutResultRaw = 0;
		SBCheckError(TElWinCertStorage_get_StorageType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, set_StorageType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_set_StorageType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBStorageTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, get_AccessType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBStorageAccessTypeRaw fOutResultRaw = 0;
		SBCheckError(TElWinCertStorage_get_AccessType(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, set_AccessType)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_set_AccessType(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBStorageAccessTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, get_Provider)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBStorageProviderTypeRaw fOutResultRaw = 0;
		SBCheckError(TElWinCertStorage_get_Provider(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, set_Provider)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_set_Provider(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBStorageProviderTypeRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, get_ReadOnly)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElWinCertStorage_get_ReadOnly(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, set_ReadOnly)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_set_ReadOnly(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, get_CryptoProvider)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElWinCertStorage_get_CryptoProvider(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElCustomCryptoProvider_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, set_CryptoProvider)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElCustomCryptoProvider_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_set_CryptoProvider(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElCustomCryptoProvider)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, get_AllowDuplicates)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElWinCertStorage_get_AllowDuplicates(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, set_AllowDuplicates)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElWinCertStorage_set_AllowDuplicates(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElWinCertStorage, __construct)
{
	zval *oOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElWinCertStorage_Create(SBGetObjectHandle(oOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_GetAvailableStores_Inst, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stores, TStrings, 1)
	ZEND_ARG_INFO(0, AccessType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_GetAvailableStores, 0, 0, 2)
	ZEND_ARG_OBJ_INFO(0, Stores, TStrings, 1)
	ZEND_ARG_INFO(0, AccessType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_GetAvailablePhysicalStores_Inst, 0, 0, 3)
	ZEND_ARG_INFO(0, SystemStore)
	ZEND_ARG_OBJ_INFO(0, Stores, TStrings, 1)
	ZEND_ARG_INFO(0, AccessType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_GetAvailablePhysicalStores, 0, 0, 3)
	ZEND_ARG_INFO(0, SystemStore)
	ZEND_ARG_OBJ_INFO(0, Stores, TStrings, 1)
	ZEND_ARG_INFO(0, AccessType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_GetStoreFriendlyName_Inst, 0, 0, 1)
	ZEND_ARG_INFO(0, StoreName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_GetStoreFriendlyName, 0, 0, 1)
	ZEND_ARG_INFO(0, StoreName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_Add, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Certificate, 0, 1)
	ZEND_ARG_INFO(0, CopyPrivateKey_or_StoreName_or_BindToExistingPrivateKey)
	ZEND_ARG_INFO(0, CopyPrivateKey_or_StoreName)
	ZEND_ARG_INFO(0, Exportable_or_PrivateKeyContainerName)
	ZEND_ARG_INFO(0, Protected)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_Remove, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_Refresh, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_PreloadCertificates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_CreateStore, 0, 0, 1)
	ZEND_ARG_INFO(0, StoreName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_DeleteStore, 0, 0, 1)
	ZEND_ARG_INFO(0, StoreName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_ListKeyContainers, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, List, TElStringList, 1)
	ZEND_ARG_INFO(0, ProvType)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_DeleteKeyContainer, 0, 0, 1)
	ZEND_ARG_INFO(0, ContainerName)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_Select, 0, 0, 2)
	ZEND_ARG_INFO(0, Owner)
	ZEND_ARG_OBJ_INFO(0, SelectedList, TElCustomCertStorage, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_ImportWizard_Inst, 0, 0, 1)
	ZEND_ARG_INFO(0, Owner)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_ImportWizard, 0, 0, 1)
	ZEND_ARG_INFO(0, Owner)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_get_Certificates, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_get_TryCurrentUser, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_set_TryCurrentUser, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_get_SystemStores, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_set_SystemStores, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_get_PhysicalStores, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_set_PhysicalStores, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TStringList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_get_StorageType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_set_StorageType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_get_AccessType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_set_AccessType, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_get_Provider, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_set_Provider, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_get_ReadOnly, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_set_ReadOnly, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_get_CryptoProvider, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_set_CryptoProvider, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElCustomCryptoProvider, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_get_AllowDuplicates, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage_set_AllowDuplicates, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElWinCertStorage___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Owner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElWinCertStorage_methods[] = {
	PHP_ME(TElWinCertStorage, GetAvailableStores_Inst, arginfo_TElWinCertStorage_GetAvailableStores_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, GetAvailableStores, arginfo_TElWinCertStorage_GetAvailableStores, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElWinCertStorage, GetAvailablePhysicalStores_Inst, arginfo_TElWinCertStorage_GetAvailablePhysicalStores_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, GetAvailablePhysicalStores, arginfo_TElWinCertStorage_GetAvailablePhysicalStores, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElWinCertStorage, GetStoreFriendlyName_Inst, arginfo_TElWinCertStorage_GetStoreFriendlyName_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, GetStoreFriendlyName, arginfo_TElWinCertStorage_GetStoreFriendlyName, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElWinCertStorage, Add, arginfo_TElWinCertStorage_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, Remove, arginfo_TElWinCertStorage_Remove, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, Refresh, arginfo_TElWinCertStorage_Refresh, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, PreloadCertificates, arginfo_TElWinCertStorage_PreloadCertificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, CreateStore, arginfo_TElWinCertStorage_CreateStore, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, DeleteStore, arginfo_TElWinCertStorage_DeleteStore, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, ListKeyContainers, arginfo_TElWinCertStorage_ListKeyContainers, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, DeleteKeyContainer, arginfo_TElWinCertStorage_DeleteKeyContainer, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, Select, arginfo_TElWinCertStorage_Select, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, ImportWizard_Inst, arginfo_TElWinCertStorage_ImportWizard_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, ImportWizard, arginfo_TElWinCertStorage_ImportWizard, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElWinCertStorage, get_Count, arginfo_TElWinCertStorage_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, get_Certificates, arginfo_TElWinCertStorage_get_Certificates, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, get_TryCurrentUser, arginfo_TElWinCertStorage_get_TryCurrentUser, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, set_TryCurrentUser, arginfo_TElWinCertStorage_set_TryCurrentUser, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, get_SystemStores, arginfo_TElWinCertStorage_get_SystemStores, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, set_SystemStores, arginfo_TElWinCertStorage_set_SystemStores, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, get_PhysicalStores, arginfo_TElWinCertStorage_get_PhysicalStores, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, set_PhysicalStores, arginfo_TElWinCertStorage_set_PhysicalStores, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, get_StorageType, arginfo_TElWinCertStorage_get_StorageType, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, set_StorageType, arginfo_TElWinCertStorage_set_StorageType, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, get_AccessType, arginfo_TElWinCertStorage_get_AccessType, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, set_AccessType, arginfo_TElWinCertStorage_set_AccessType, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, get_Provider, arginfo_TElWinCertStorage_get_Provider, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, set_Provider, arginfo_TElWinCertStorage_set_Provider, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, get_ReadOnly, arginfo_TElWinCertStorage_get_ReadOnly, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, set_ReadOnly, arginfo_TElWinCertStorage_set_ReadOnly, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, get_CryptoProvider, arginfo_TElWinCertStorage_get_CryptoProvider, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, set_CryptoProvider, arginfo_TElWinCertStorage_set_CryptoProvider, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, get_AllowDuplicates, arginfo_TElWinCertStorage_get_AllowDuplicates, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, set_AllowDuplicates, arginfo_TElWinCertStorage_set_AllowDuplicates, ZEND_ACC_PUBLIC)
	PHP_ME(TElWinCertStorage, __construct, arginfo_TElWinCertStorage___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElWinCertStorage(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElWinCertStorage_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElWinCertStorage", TElWinCertStorage_methods);
	if (NULL == TElCustomCertStorage_ce_ptr)
		Register_TElCustomCertStorage(TSRMLS_C);
	TElWinCertStorage_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElCustomCertStorage_ce_ptr);
}

void Register_SBWinCertStorage_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBStorageType", NULL);
	TSBStorageType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBStorageType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageType_ce_ptr, "stSystem", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageType_ce_ptr, "stRegistry", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageType_ce_ptr, "stLDAP", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageType_ce_ptr, "stMemory", 3)
	
	INIT_CLASS_ENTRY(ce, "TSBStorageAccessType", NULL);
	TSBStorageAccessType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBStorageAccessType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageAccessType_ce_ptr, "atCurrentService", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageAccessType_ce_ptr, "atCurrentUser", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageAccessType_ce_ptr, "atCurrentUserGroupPolicy", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageAccessType_ce_ptr, "atLocalMachine", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageAccessType_ce_ptr, "atLocalMachineEnterprise", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageAccessType_ce_ptr, "atLocalMachineGroupPolicy", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageAccessType_ce_ptr, "atServices", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageAccessType_ce_ptr, "atUsers", 7)
	
	INIT_CLASS_ENTRY(ce, "TSBStorageProviderType", NULL);
	TSBStorageProviderType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBStorageProviderType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageProviderType_ce_ptr, "ptDefault", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageProviderType_ce_ptr, "ptBaseDSSDH", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageProviderType_ce_ptr, "ptBaseDSS", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageProviderType_ce_ptr, "ptBase", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageProviderType_ce_ptr, "ptRSASchannel", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageProviderType_ce_ptr, "ptRSASignature", 5)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageProviderType_ce_ptr, "ptEnhancedDSSDH", 6)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageProviderType_ce_ptr, "ptEnhancedRSAAES", 7)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageProviderType_ce_ptr, "ptEnhanced", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageProviderType_ce_ptr, "ptBaseSmartCard", 9)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageProviderType_ce_ptr, "ptStrong", 10)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageProviderType_ce_ptr, "ptCryptoProGOST94", 11)
	SB_DECLARE_CLASS_LONG_CONST(TSBStorageProviderType_ce_ptr, "ptCryptoProGOST2001", 12)
}

void Register_SBWinCertStorage_Aliases(TSRMLS_D)
{
	if (NULL == TElWinCertStorage_ce_ptr)
		Register_TElWinCertStorage(TSRMLS_C);
	zend_register_class_alias("ElWinCertStorage", TElWinCertStorage_ce_ptr);
}
#endif
