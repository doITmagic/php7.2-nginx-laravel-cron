#include "sbxmltransform.h"

zend_class_entry *TSBTransformProperties_ce_ptr = NULL;

zend_class_entry *TSBTransformedDataType_ce_ptr = NULL;

zend_class_entry *TElXMLTransformClass_ce_ptr = NULL;

zend_class_entry *TSBXPathFilterOperation_ce_ptr = NULL;

zend_class_entry *TElXMLTransform_ce_ptr = NULL;

SB_PHP_METHOD(TElXMLTransform, GetDefaultTransformAlgorithmURI_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLTransform_GetDefaultTransformAlgorithmURI_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1192175142, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, GetDefaultTransformAlgorithmURI)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLTransform_GetDefaultTransformAlgorithmURI(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1192175142, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, IsTransformAlgorithmSupported_Inst)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLTransform_IsTransformAlgorithmSupported_1(SBGetObjectHandle(getThis() TSRMLS_CC), sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, IsTransformAlgorithmSupported)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLTransform_IsTransformAlgorithmSupported(sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElXMLTransform_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, LoadFromXML)
{
	zval *oElement;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oElement, TElXMLDOMElement_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElXMLTransform_LoadFromXML(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oElement TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMElement)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, SaveToXML)
{
	zval *oDocument;
	zval *oFormatter;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oDocument, TElXMLDOMDocument_ce_ptr, &oFormatter, TElXMLCustomFormatter_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLTransform_SaveToXML(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDocument TSRMLS_CC), SBGetObjectHandle(oFormatter TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDocument, TElXMLDOMDocument_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLTransform_SaveToXML_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDocument TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMDocument, \\TElXMLCustomFormatter) or (\\TElXMLDOMDocument)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, TransformData)
{
	SBArrayZValInfo aiData;
	SBArrayZValInfo aiReference;
	zval *oNode;
	zval *oNodes;
	zval *oReference;
	zval *zaData;
	zval *zaReference;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLTransform_TransformData(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oNode, TElXMLDOMNode_ce_ptr, &oReference, TElXMLDOMNode_ce_ptr) == SUCCESS)
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		SBCheckError(TElXMLTransform_TransformData_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNode TSRMLS_CC), SBGetObjectHandle(oReference TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oNodes, TElXMLDOMNodeList_ce_ptr, &zaReference, TElXMLDOMNode_ce_ptr) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaReference) || SB_IS_NULL_TYPE_RP(zaReference)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetObjectArrayFromZVal(zaReference, TElXMLDOMNode_ce_ptr, &aiReference TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLTransform_TransformData_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNodes TSRMLS_CC), aiReference.data, aiReference.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiReference);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL) or (\\TElXMLDOMNode, \\TElXMLDOMNode) or (\\TElXMLDOMNodeList, &array of TElXMLDOMNode|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLTransform_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, get_TransformAlgorithmURI)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLTransform_get_TransformAlgorithmURI(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1913676402, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, set_TransformAlgorithmURI)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElXMLTransform_set_TransformAlgorithmURI(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, get_TransformedData)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElXMLTransform_get_TransformedData(SBGetObjectHandle(getThis() TSRMLS_CC), u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1318213218, 1, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, set_TransformedData)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaValue) || SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetByteArrayFromZVal(zaValue, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLTransform_set_TransformedData(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, get_TransformedNode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLTransform_get_TransformedNode(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMNode_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, set_TransformedNode)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElXMLDOMNode_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElXMLTransform_set_TransformedNode(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMNode)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, get_TransformedNodes)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLTransform_get_TransformedNodes(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMNodeList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, set_TransformedNodes)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElXMLDOMNodeList_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElXMLTransform_set_TransformedNodes(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMNodeList)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, get_ReferenceNode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLTransform_get_ReferenceNode(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMNode_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, set_ReferenceNode)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElXMLDOMNode_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElXMLTransform_set_ReferenceNode(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMNode)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, get_ReferenceNodes)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBArrayZValInfo aiOutResult;
		SBInitArrayZValInfo(&aiOutResult);
		_err = TElXMLTransform_get_ReferenceNodes(SBGetObjectHandle(getThis() TSRMLS_CC), aiOutResult.data, &aiOutResult.len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			aiOutResult.data = emalloc(aiOutResult.len);
			aiOutResult.ownData = 1;
			SBCheckError(SBGetLastReturnBuffer(-1811549564, 1, aiOutResult.data, &aiOutResult.len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBFreeArrayZValInfo(&aiOutResult);
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBSetObjectArrayToZVal(&aiOutResult, TElXMLDOMNode_ce_ptr, return_value TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, set_ReferenceNodes)
{
	SBArrayZValInfo aiValue;
	zval *zaValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaValue, TElXMLDOMNode_ce_ptr) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaValue) || SB_IS_NULL_TYPE_RP(zaValue)))
	{
		if (!SBGetObjectArrayFromZVal(zaValue, TElXMLDOMNode_ce_ptr, &aiValue TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLTransform_set_ReferenceNodes(SBGetObjectHandle(getThis() TSRMLS_CC), aiValue.data, aiValue.len) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiValue);
	}
	else
	{
		SBErrorExpectsArguments("(&array of TElXMLDOMNode|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransform, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLTransform_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_GetDefaultTransformAlgorithmURI_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_GetDefaultTransformAlgorithmURI, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_IsTransformAlgorithmSupported_Inst, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_IsTransformAlgorithmSupported, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_LoadFromXML, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_SaveToXML, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Document, TElXMLDOMDocument, 1)
	ZEND_ARG_OBJ_INFO(0, Formatter, TElXMLCustomFormatter, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_TransformData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data_or_Node_or_Nodes, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Reference, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_get_TransformAlgorithmURI, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_set_TransformAlgorithmURI, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_get_TransformedData, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_set_TransformedData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_get_TransformedNode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_set_TransformedNode, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElXMLDOMNode, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_get_TransformedNodes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_set_TransformedNodes, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElXMLDOMNodeList, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_get_ReferenceNode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_set_ReferenceNode, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElXMLDOMNode, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_get_ReferenceNodes, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform_set_ReferenceNodes, 0, 0, 1)
	ZEND_ARG_ARRAY_INFO(0, Value, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransform___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElXMLTransform_methods[] = {
	PHP_ME(TElXMLTransform, GetDefaultTransformAlgorithmURI_Inst, arginfo_TElXMLTransform_GetDefaultTransformAlgorithmURI_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, GetDefaultTransformAlgorithmURI, arginfo_TElXMLTransform_GetDefaultTransformAlgorithmURI, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLTransform, IsTransformAlgorithmSupported_Inst, arginfo_TElXMLTransform_IsTransformAlgorithmSupported_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, IsTransformAlgorithmSupported, arginfo_TElXMLTransform_IsTransformAlgorithmSupported, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLTransform, Clear, arginfo_TElXMLTransform_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, LoadFromXML, arginfo_TElXMLTransform_LoadFromXML, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, SaveToXML, arginfo_TElXMLTransform_SaveToXML, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, TransformData, arginfo_TElXMLTransform_TransformData, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, ClassType, arginfo_TElXMLTransform_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLTransform, get_TransformAlgorithmURI, arginfo_TElXMLTransform_get_TransformAlgorithmURI, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, set_TransformAlgorithmURI, arginfo_TElXMLTransform_set_TransformAlgorithmURI, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, get_TransformedData, arginfo_TElXMLTransform_get_TransformedData, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, set_TransformedData, arginfo_TElXMLTransform_set_TransformedData, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, get_TransformedNode, arginfo_TElXMLTransform_get_TransformedNode, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, set_TransformedNode, arginfo_TElXMLTransform_set_TransformedNode, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, get_TransformedNodes, arginfo_TElXMLTransform_get_TransformedNodes, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, set_TransformedNodes, arginfo_TElXMLTransform_set_TransformedNodes, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, get_ReferenceNode, arginfo_TElXMLTransform_get_ReferenceNode, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, set_ReferenceNode, arginfo_TElXMLTransform_set_ReferenceNode, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, get_ReferenceNodes, arginfo_TElXMLTransform_get_ReferenceNodes, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, set_ReferenceNodes, arginfo_TElXMLTransform_set_ReferenceNodes, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransform, __construct, arginfo_TElXMLTransform___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElXMLTransform(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElXMLTransform_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElXMLTransform", TElXMLTransform_methods);
	if (NULL == TElXMLCustomElement_ce_ptr)
		Register_TElXMLCustomElement(TSRMLS_C);
	TElXMLTransform_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElXMLCustomElement_ce_ptr);
}

zend_class_entry *TElXMLNullTransform_ce_ptr = NULL;

SB_PHP_METHOD(TElXMLNullTransform, GetDefaultTransformAlgorithmURI_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLNullTransform_GetDefaultTransformAlgorithmURI_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(713229815, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLNullTransform, GetDefaultTransformAlgorithmURI)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLNullTransform_GetDefaultTransformAlgorithmURI(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(713229815, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLNullTransform, IsTransformAlgorithmSupported_Inst)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLNullTransform_IsTransformAlgorithmSupported_1(SBGetObjectHandle(getThis() TSRMLS_CC), sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLNullTransform, IsTransformAlgorithmSupported)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLNullTransform_IsTransformAlgorithmSupported(sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLNullTransform, TransformData)
{
	SBArrayZValInfo aiData;
	SBArrayZValInfo aiReference;
	zval *oNode;
	zval *oNodes;
	zval *oReference;
	zval *zaData;
	zval *zaReference;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLNullTransform_TransformData(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oNode, TElXMLDOMNode_ce_ptr, &oReference, TElXMLDOMNode_ce_ptr) == SUCCESS)
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		SBCheckError(TElXMLNullTransform_TransformData_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNode TSRMLS_CC), SBGetObjectHandle(oReference TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oNodes, TElXMLDOMNodeList_ce_ptr, &zaReference, TElXMLDOMNode_ce_ptr) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaReference) || SB_IS_NULL_TYPE_RP(zaReference)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetObjectArrayFromZVal(zaReference, TElXMLDOMNode_ce_ptr, &aiReference TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLNullTransform_TransformData_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNodes TSRMLS_CC), aiReference.data, aiReference.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiReference);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL) or (\\TElXMLDOMNode, \\TElXMLDOMNode) or (\\TElXMLDOMNodeList, &array of TElXMLDOMNode|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLNullTransform, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLNullTransform_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLNullTransform, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLNullTransform_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLNullTransform_GetDefaultTransformAlgorithmURI_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLNullTransform_GetDefaultTransformAlgorithmURI, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLNullTransform_IsTransformAlgorithmSupported_Inst, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLNullTransform_IsTransformAlgorithmSupported, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLNullTransform_TransformData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data_or_Node_or_Nodes, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Reference, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLNullTransform_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLNullTransform___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElXMLNullTransform_methods[] = {
	PHP_ME(TElXMLNullTransform, GetDefaultTransformAlgorithmURI_Inst, arginfo_TElXMLNullTransform_GetDefaultTransformAlgorithmURI_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLNullTransform, GetDefaultTransformAlgorithmURI, arginfo_TElXMLNullTransform_GetDefaultTransformAlgorithmURI, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLNullTransform, IsTransformAlgorithmSupported_Inst, arginfo_TElXMLNullTransform_IsTransformAlgorithmSupported_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLNullTransform, IsTransformAlgorithmSupported, arginfo_TElXMLNullTransform_IsTransformAlgorithmSupported, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLNullTransform, TransformData, arginfo_TElXMLNullTransform_TransformData, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLNullTransform, ClassType, arginfo_TElXMLNullTransform_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLNullTransform, __construct, arginfo_TElXMLNullTransform___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElXMLNullTransform(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElXMLNullTransform_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElXMLNullTransform", TElXMLNullTransform_methods);
	if (NULL == TElXMLTransform_ce_ptr)
		Register_TElXMLTransform(TSRMLS_C);
	TElXMLNullTransform_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElXMLTransform_ce_ptr);
}

zend_class_entry *TElXMLBase64Transform_ce_ptr = NULL;

SB_PHP_METHOD(TElXMLBase64Transform, GetDefaultTransformAlgorithmURI_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLBase64Transform_GetDefaultTransformAlgorithmURI_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-128899505, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLBase64Transform, GetDefaultTransformAlgorithmURI)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLBase64Transform_GetDefaultTransformAlgorithmURI(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-128899505, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLBase64Transform, IsTransformAlgorithmSupported_Inst)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLBase64Transform_IsTransformAlgorithmSupported_1(SBGetObjectHandle(getThis() TSRMLS_CC), sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLBase64Transform, IsTransformAlgorithmSupported)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLBase64Transform_IsTransformAlgorithmSupported(sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLBase64Transform, TransformData)
{
	SBArrayZValInfo aiData;
	SBArrayZValInfo aiReference;
	zval *oNode;
	zval *oNodes;
	zval *oReference;
	zval *zaData;
	zval *zaReference;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLBase64Transform_TransformData(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oNode, TElXMLDOMNode_ce_ptr, &oReference, TElXMLDOMNode_ce_ptr) == SUCCESS)
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		SBCheckError(TElXMLBase64Transform_TransformData_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNode TSRMLS_CC), SBGetObjectHandle(oReference TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oNodes, TElXMLDOMNodeList_ce_ptr, &zaReference, TElXMLDOMNode_ce_ptr) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaReference) || SB_IS_NULL_TYPE_RP(zaReference)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetObjectArrayFromZVal(zaReference, TElXMLDOMNode_ce_ptr, &aiReference TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLBase64Transform_TransformData_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNodes TSRMLS_CC), aiReference.data, aiReference.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiReference);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL) or (\\TElXMLDOMNode, \\TElXMLDOMNode) or (\\TElXMLDOMNodeList, &array of TElXMLDOMNode|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLBase64Transform, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLBase64Transform_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLBase64Transform, get_OldMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLBase64Transform_get_OldMode(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLBase64Transform, set_OldMode)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElXMLBase64Transform_set_OldMode(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLBase64Transform, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLBase64Transform_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLBase64Transform_GetDefaultTransformAlgorithmURI_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLBase64Transform_GetDefaultTransformAlgorithmURI, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLBase64Transform_IsTransformAlgorithmSupported_Inst, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLBase64Transform_IsTransformAlgorithmSupported, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLBase64Transform_TransformData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data_or_Node_or_Nodes, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Reference, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLBase64Transform_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLBase64Transform_get_OldMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLBase64Transform_set_OldMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLBase64Transform___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElXMLBase64Transform_methods[] = {
	PHP_ME(TElXMLBase64Transform, GetDefaultTransformAlgorithmURI_Inst, arginfo_TElXMLBase64Transform_GetDefaultTransformAlgorithmURI_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLBase64Transform, GetDefaultTransformAlgorithmURI, arginfo_TElXMLBase64Transform_GetDefaultTransformAlgorithmURI, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLBase64Transform, IsTransformAlgorithmSupported_Inst, arginfo_TElXMLBase64Transform_IsTransformAlgorithmSupported_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLBase64Transform, IsTransformAlgorithmSupported, arginfo_TElXMLBase64Transform_IsTransformAlgorithmSupported, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLBase64Transform, TransformData, arginfo_TElXMLBase64Transform_TransformData, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLBase64Transform, ClassType, arginfo_TElXMLBase64Transform_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLBase64Transform, get_OldMode, arginfo_TElXMLBase64Transform_get_OldMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLBase64Transform, set_OldMode, arginfo_TElXMLBase64Transform_set_OldMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLBase64Transform, __construct, arginfo_TElXMLBase64Transform___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElXMLBase64Transform(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElXMLBase64Transform_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElXMLBase64Transform", TElXMLBase64Transform_methods);
	if (NULL == TElXMLTransform_ce_ptr)
		Register_TElXMLTransform(TSRMLS_C);
	TElXMLBase64Transform_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElXMLTransform_ce_ptr);
}

zend_class_entry *TElXMLC14NTransform_ce_ptr = NULL;

SB_PHP_METHOD(TElXMLC14NTransform, GetDefaultTransformAlgorithmURI_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLC14NTransform_GetDefaultTransformAlgorithmURI_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1209301160, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, GetDefaultTransformAlgorithmURI)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLC14NTransform_GetDefaultTransformAlgorithmURI(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1209301160, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, IsTransformAlgorithmSupported_Inst)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLC14NTransform_IsTransformAlgorithmSupported_1(SBGetObjectHandle(getThis() TSRMLS_CC), sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, IsTransformAlgorithmSupported)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLC14NTransform_IsTransformAlgorithmSupported(sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElXMLC14NTransform_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, LoadFromXML)
{
	zval *oElement;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oElement, TElXMLDOMElement_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElXMLC14NTransform_LoadFromXML(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oElement TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMElement)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, SaveToXML)
{
	zval *oDocument;
	zval *oFormatter;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oDocument, TElXMLDOMDocument_ce_ptr, &oFormatter, TElXMLCustomFormatter_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLC14NTransform_SaveToXML(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDocument TSRMLS_CC), SBGetObjectHandle(oFormatter TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDocument, TElXMLDOMDocument_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLC14NTransform_SaveToXML_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDocument TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMDocument, \\TElXMLCustomFormatter) or (\\TElXMLDOMDocument)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, TransformData)
{
	SBArrayZValInfo aiData;
	SBArrayZValInfo aiReference;
	zval *oNode;
	zval *oNodes;
	zval *oReference;
	zval *zaData;
	zval *zaReference;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLC14NTransform_TransformData(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oNode, TElXMLDOMNode_ce_ptr, &oReference, TElXMLDOMNode_ce_ptr) == SUCCESS)
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		SBCheckError(TElXMLC14NTransform_TransformData_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNode TSRMLS_CC), SBGetObjectHandle(oReference TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oNodes, TElXMLDOMNodeList_ce_ptr, &zaReference, TElXMLDOMNode_ce_ptr) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaReference) || SB_IS_NULL_TYPE_RP(zaReference)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetObjectArrayFromZVal(zaReference, TElXMLDOMNode_ce_ptr, &aiReference TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLC14NTransform_TransformData_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNodes TSRMLS_CC), aiReference.data, aiReference.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiReference);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL) or (\\TElXMLDOMNode, \\TElXMLDOMNode) or (\\TElXMLDOMNodeList, &array of TElXMLDOMNode|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLC14NTransform_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, get_CanonicalizationMethod)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElXMLCanonicalizationMethodRaw fOutResultRaw = 0;
		SBCheckError(TElXMLC14NTransform_get_CanonicalizationMethod(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, set_CanonicalizationMethod)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElXMLC14NTransform_set_CanonicalizationMethod(SBGetObjectHandle(getThis() TSRMLS_CC), (TElXMLCanonicalizationMethodRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, get_ExclusiveCanonicalizationPrefix)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLC14NTransform_get_ExclusiveCanonicalizationPrefix(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-96234817, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, set_ExclusiveCanonicalizationPrefix)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElXMLC14NTransform_set_ExclusiveCanonicalizationPrefix(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, get_InclusiveNamespacesPrefixList)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLC14NTransform_get_InclusiveNamespacesPrefixList(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1781126645, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, set_InclusiveNamespacesPrefixList)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElXMLC14NTransform_set_InclusiveNamespacesPrefixList(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLC14NTransform, __construct)
{
	sb_zend_long fAMethod;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLC14NTransform_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fAMethod) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLC14NTransform_Create_1((TElXMLCanonicalizationMethodRaw)fAMethod, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("() or (integer)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_GetDefaultTransformAlgorithmURI_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_GetDefaultTransformAlgorithmURI, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_IsTransformAlgorithmSupported_Inst, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_IsTransformAlgorithmSupported, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_LoadFromXML, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_SaveToXML, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Document, TElXMLDOMDocument, 1)
	ZEND_ARG_OBJ_INFO(0, Formatter, TElXMLCustomFormatter, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_TransformData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data_or_Node_or_Nodes, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Reference, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_get_CanonicalizationMethod, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_set_CanonicalizationMethod, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_get_ExclusiveCanonicalizationPrefix, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_set_ExclusiveCanonicalizationPrefix, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_get_InclusiveNamespacesPrefixList, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform_set_InclusiveNamespacesPrefixList, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLC14NTransform___construct, 0, 0, 0)
	ZEND_ARG_INFO(0, AMethod)
ZEND_END_ARG_INFO()

static zend_function_entry TElXMLC14NTransform_methods[] = {
	PHP_ME(TElXMLC14NTransform, GetDefaultTransformAlgorithmURI_Inst, arginfo_TElXMLC14NTransform_GetDefaultTransformAlgorithmURI_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLC14NTransform, GetDefaultTransformAlgorithmURI, arginfo_TElXMLC14NTransform_GetDefaultTransformAlgorithmURI, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLC14NTransform, IsTransformAlgorithmSupported_Inst, arginfo_TElXMLC14NTransform_IsTransformAlgorithmSupported_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLC14NTransform, IsTransformAlgorithmSupported, arginfo_TElXMLC14NTransform_IsTransformAlgorithmSupported, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLC14NTransform, Clear, arginfo_TElXMLC14NTransform_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLC14NTransform, LoadFromXML, arginfo_TElXMLC14NTransform_LoadFromXML, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLC14NTransform, SaveToXML, arginfo_TElXMLC14NTransform_SaveToXML, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLC14NTransform, TransformData, arginfo_TElXMLC14NTransform_TransformData, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLC14NTransform, ClassType, arginfo_TElXMLC14NTransform_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLC14NTransform, get_CanonicalizationMethod, arginfo_TElXMLC14NTransform_get_CanonicalizationMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLC14NTransform, set_CanonicalizationMethod, arginfo_TElXMLC14NTransform_set_CanonicalizationMethod, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLC14NTransform, get_ExclusiveCanonicalizationPrefix, arginfo_TElXMLC14NTransform_get_ExclusiveCanonicalizationPrefix, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLC14NTransform, set_ExclusiveCanonicalizationPrefix, arginfo_TElXMLC14NTransform_set_ExclusiveCanonicalizationPrefix, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLC14NTransform, get_InclusiveNamespacesPrefixList, arginfo_TElXMLC14NTransform_get_InclusiveNamespacesPrefixList, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLC14NTransform, set_InclusiveNamespacesPrefixList, arginfo_TElXMLC14NTransform_set_InclusiveNamespacesPrefixList, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLC14NTransform, __construct, arginfo_TElXMLC14NTransform___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElXMLC14NTransform(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElXMLC14NTransform_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElXMLC14NTransform", TElXMLC14NTransform_methods);
	if (NULL == TElXMLTransform_ce_ptr)
		Register_TElXMLTransform(TSRMLS_C);
	TElXMLC14NTransform_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElXMLTransform_ce_ptr);
}

zend_class_entry *TElXMLEnvelopedSignatureTransform_ce_ptr = NULL;

SB_PHP_METHOD(TElXMLEnvelopedSignatureTransform, GetDefaultTransformAlgorithmURI_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLEnvelopedSignatureTransform_GetDefaultTransformAlgorithmURI_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-228595407, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLEnvelopedSignatureTransform, GetDefaultTransformAlgorithmURI)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLEnvelopedSignatureTransform_GetDefaultTransformAlgorithmURI(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-228595407, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLEnvelopedSignatureTransform, IsTransformAlgorithmSupported_Inst)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLEnvelopedSignatureTransform_IsTransformAlgorithmSupported_1(SBGetObjectHandle(getThis() TSRMLS_CC), sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLEnvelopedSignatureTransform, IsTransformAlgorithmSupported)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLEnvelopedSignatureTransform_IsTransformAlgorithmSupported(sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLEnvelopedSignatureTransform, GetDefaultStrictMode_Inst)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLEnvelopedSignatureTransform_GetDefaultStrictMode_1(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLEnvelopedSignatureTransform, GetDefaultStrictMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLEnvelopedSignatureTransform_GetDefaultStrictMode(&bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLEnvelopedSignatureTransform, SetDefaultStrictMode_Inst)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElXMLEnvelopedSignatureTransform_SetDefaultStrictMode_1(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLEnvelopedSignatureTransform, SetDefaultStrictMode)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElXMLEnvelopedSignatureTransform_SetDefaultStrictMode((int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLEnvelopedSignatureTransform, TransformData)
{
	SBArrayZValInfo aiData;
	SBArrayZValInfo aiReference;
	zval *oNode;
	zval *oNodes;
	zval *oReference;
	zval *zaData;
	zval *zaReference;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLEnvelopedSignatureTransform_TransformData(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oNode, TElXMLDOMNode_ce_ptr, &oReference, TElXMLDOMNode_ce_ptr) == SUCCESS)
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		SBCheckError(TElXMLEnvelopedSignatureTransform_TransformData_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNode TSRMLS_CC), SBGetObjectHandle(oReference TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oNodes, TElXMLDOMNodeList_ce_ptr, &zaReference, TElXMLDOMNode_ce_ptr) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaReference) || SB_IS_NULL_TYPE_RP(zaReference)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetObjectArrayFromZVal(zaReference, TElXMLDOMNode_ce_ptr, &aiReference TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLEnvelopedSignatureTransform_TransformData_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNodes TSRMLS_CC), aiReference.data, aiReference.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiReference);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL) or (\\TElXMLDOMNode, \\TElXMLDOMNode) or (\\TElXMLDOMNodeList, &array of TElXMLDOMNode|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLEnvelopedSignatureTransform, TransformNode)
{
	zval *oNode;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oNode, TElXMLDOMNode_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLEnvelopedSignatureTransform_TransformNode(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNode TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMNode_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMNode)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLEnvelopedSignatureTransform, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLEnvelopedSignatureTransform_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLEnvelopedSignatureTransform, get_StrictMode)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLEnvelopedSignatureTransform_get_StrictMode(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLEnvelopedSignatureTransform, set_StrictMode)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElXMLEnvelopedSignatureTransform_set_StrictMode(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLEnvelopedSignatureTransform, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLEnvelopedSignatureTransform_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLEnvelopedSignatureTransform_GetDefaultTransformAlgorithmURI_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLEnvelopedSignatureTransform_GetDefaultTransformAlgorithmURI, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLEnvelopedSignatureTransform_IsTransformAlgorithmSupported_Inst, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLEnvelopedSignatureTransform_IsTransformAlgorithmSupported, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLEnvelopedSignatureTransform_GetDefaultStrictMode_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLEnvelopedSignatureTransform_GetDefaultStrictMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLEnvelopedSignatureTransform_SetDefaultStrictMode_Inst, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLEnvelopedSignatureTransform_SetDefaultStrictMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLEnvelopedSignatureTransform_TransformData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data_or_Node_or_Nodes, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Reference, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLEnvelopedSignatureTransform_TransformNode, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Node, TElXMLDOMNode, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLEnvelopedSignatureTransform_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLEnvelopedSignatureTransform_get_StrictMode, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLEnvelopedSignatureTransform_set_StrictMode, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLEnvelopedSignatureTransform___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElXMLEnvelopedSignatureTransform_methods[] = {
	PHP_ME(TElXMLEnvelopedSignatureTransform, GetDefaultTransformAlgorithmURI_Inst, arginfo_TElXMLEnvelopedSignatureTransform_GetDefaultTransformAlgorithmURI_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLEnvelopedSignatureTransform, GetDefaultTransformAlgorithmURI, arginfo_TElXMLEnvelopedSignatureTransform_GetDefaultTransformAlgorithmURI, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLEnvelopedSignatureTransform, IsTransformAlgorithmSupported_Inst, arginfo_TElXMLEnvelopedSignatureTransform_IsTransformAlgorithmSupported_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLEnvelopedSignatureTransform, IsTransformAlgorithmSupported, arginfo_TElXMLEnvelopedSignatureTransform_IsTransformAlgorithmSupported, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLEnvelopedSignatureTransform, GetDefaultStrictMode_Inst, arginfo_TElXMLEnvelopedSignatureTransform_GetDefaultStrictMode_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLEnvelopedSignatureTransform, GetDefaultStrictMode, arginfo_TElXMLEnvelopedSignatureTransform_GetDefaultStrictMode, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLEnvelopedSignatureTransform, SetDefaultStrictMode_Inst, arginfo_TElXMLEnvelopedSignatureTransform_SetDefaultStrictMode_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLEnvelopedSignatureTransform, SetDefaultStrictMode, arginfo_TElXMLEnvelopedSignatureTransform_SetDefaultStrictMode, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLEnvelopedSignatureTransform, TransformData, arginfo_TElXMLEnvelopedSignatureTransform_TransformData, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLEnvelopedSignatureTransform, TransformNode, arginfo_TElXMLEnvelopedSignatureTransform_TransformNode, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLEnvelopedSignatureTransform, ClassType, arginfo_TElXMLEnvelopedSignatureTransform_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLEnvelopedSignatureTransform, get_StrictMode, arginfo_TElXMLEnvelopedSignatureTransform_get_StrictMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLEnvelopedSignatureTransform, set_StrictMode, arginfo_TElXMLEnvelopedSignatureTransform_set_StrictMode, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLEnvelopedSignatureTransform, __construct, arginfo_TElXMLEnvelopedSignatureTransform___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElXMLEnvelopedSignatureTransform(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElXMLEnvelopedSignatureTransform_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElXMLEnvelopedSignatureTransform", TElXMLEnvelopedSignatureTransform_methods);
	if (NULL == TElXMLTransform_ce_ptr)
		Register_TElXMLTransform(TSRMLS_C);
	TElXMLEnvelopedSignatureTransform_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElXMLTransform_ce_ptr);
}

zend_class_entry *TElXMLXPathTransform_ce_ptr = NULL;

SB_PHP_METHOD(TElXMLXPathTransform, GetDefaultTransformAlgorithmURI_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLXPathTransform_GetDefaultTransformAlgorithmURI_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2069546845, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathTransform, GetDefaultTransformAlgorithmURI)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLXPathTransform_GetDefaultTransformAlgorithmURI(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(2069546845, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathTransform, IsTransformAlgorithmSupported_Inst)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLXPathTransform_IsTransformAlgorithmSupported_1(SBGetObjectHandle(getThis() TSRMLS_CC), sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathTransform, IsTransformAlgorithmSupported)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLXPathTransform_IsTransformAlgorithmSupported(sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathTransform, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElXMLXPathTransform_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathTransform, LoadFromXML)
{
	zval *oElement;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oElement, TElXMLDOMElement_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElXMLXPathTransform_LoadFromXML(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oElement TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMElement)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathTransform, SaveToXML)
{
	zval *oDocument;
	zval *oFormatter;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oDocument, TElXMLDOMDocument_ce_ptr, &oFormatter, TElXMLCustomFormatter_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLXPathTransform_SaveToXML(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDocument TSRMLS_CC), SBGetObjectHandle(oFormatter TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDocument, TElXMLDOMDocument_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLXPathTransform_SaveToXML_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDocument TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMDocument, \\TElXMLCustomFormatter) or (\\TElXMLDOMDocument)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathTransform, TransformData)
{
	SBArrayZValInfo aiData;
	SBArrayZValInfo aiReference;
	zval *oNode;
	zval *oNodes;
	zval *oReference;
	zval *zaData;
	zval *zaReference;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLXPathTransform_TransformData(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oNode, TElXMLDOMNode_ce_ptr, &oReference, TElXMLDOMNode_ce_ptr) == SUCCESS)
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		SBCheckError(TElXMLXPathTransform_TransformData_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNode TSRMLS_CC), SBGetObjectHandle(oReference TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oNodes, TElXMLDOMNodeList_ce_ptr, &zaReference, TElXMLDOMNode_ce_ptr) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaReference) || SB_IS_NULL_TYPE_RP(zaReference)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetObjectArrayFromZVal(zaReference, TElXMLDOMNode_ce_ptr, &aiReference TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLXPathTransform_TransformData_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNodes TSRMLS_CC), aiReference.data, aiReference.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiReference);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL) or (\\TElXMLDOMNode, \\TElXMLDOMNode) or (\\TElXMLDOMNodeList, &array of TElXMLDOMNode|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathTransform, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLXPathTransform_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathTransform, get_NamespaceMap)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLXPathTransform_get_NamespaceMap(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLNamespaceMap_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathTransform, get_XPath)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLXPathTransform_get_XPath(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1058009468, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathTransform, set_XPath)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElXMLXPathTransform_set_XPath(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathTransform, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLXPathTransform_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathTransform_GetDefaultTransformAlgorithmURI_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathTransform_GetDefaultTransformAlgorithmURI, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathTransform_IsTransformAlgorithmSupported_Inst, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathTransform_IsTransformAlgorithmSupported, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathTransform_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathTransform_LoadFromXML, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathTransform_SaveToXML, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Document, TElXMLDOMDocument, 1)
	ZEND_ARG_OBJ_INFO(0, Formatter, TElXMLCustomFormatter, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathTransform_TransformData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data_or_Node_or_Nodes, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Reference, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathTransform_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathTransform_get_NamespaceMap, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathTransform_get_XPath, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathTransform_set_XPath, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathTransform___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElXMLXPathTransform_methods[] = {
	PHP_ME(TElXMLXPathTransform, GetDefaultTransformAlgorithmURI_Inst, arginfo_TElXMLXPathTransform_GetDefaultTransformAlgorithmURI_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathTransform, GetDefaultTransformAlgorithmURI, arginfo_TElXMLXPathTransform_GetDefaultTransformAlgorithmURI, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLXPathTransform, IsTransformAlgorithmSupported_Inst, arginfo_TElXMLXPathTransform_IsTransformAlgorithmSupported_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathTransform, IsTransformAlgorithmSupported, arginfo_TElXMLXPathTransform_IsTransformAlgorithmSupported, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLXPathTransform, Clear, arginfo_TElXMLXPathTransform_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathTransform, LoadFromXML, arginfo_TElXMLXPathTransform_LoadFromXML, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathTransform, SaveToXML, arginfo_TElXMLXPathTransform_SaveToXML, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathTransform, TransformData, arginfo_TElXMLXPathTransform_TransformData, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathTransform, ClassType, arginfo_TElXMLXPathTransform_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLXPathTransform, get_NamespaceMap, arginfo_TElXMLXPathTransform_get_NamespaceMap, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathTransform, get_XPath, arginfo_TElXMLXPathTransform_get_XPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathTransform, set_XPath, arginfo_TElXMLXPathTransform_set_XPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathTransform, __construct, arginfo_TElXMLXPathTransform___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElXMLXPathTransform(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElXMLXPathTransform_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElXMLXPathTransform", TElXMLXPathTransform_methods);
	if (NULL == TElXMLTransform_ce_ptr)
		Register_TElXMLTransform(TSRMLS_C);
	TElXMLXPathTransform_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElXMLTransform_ce_ptr);
}

zend_class_entry *TElXMLXPathFilterItem_ce_ptr = NULL;

SB_PHP_METHOD(TElXMLXPathFilterItem, get_Filter)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBXPathFilterOperationRaw fOutResultRaw = 0;
		SBCheckError(TElXMLXPathFilterItem_get_Filter(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilterItem, set_Filter)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElXMLXPathFilterItem_set_Filter(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBXPathFilterOperationRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilterItem, get_NamespaceMap)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLXPathFilterItem_get_NamespaceMap(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLNamespaceMap_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilterItem, get_XPath)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLXPathFilterItem_get_XPath(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-472882516, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilterItem, set_XPath)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElXMLXPathFilterItem_set_XPath(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilterItem, get_XMLElement)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLXPathFilterItem_get_XMLElement(SBGetObjectHandle(getThis() TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilterItem, set_XMLElement)
{
	zval *oValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oValue, TElXMLDOMElement_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElXMLXPathFilterItem_set_XMLElement(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oValue TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMElement)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilterItem, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLXPathFilterItem_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilterItem_get_Filter, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilterItem_set_Filter, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilterItem_get_NamespaceMap, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilterItem_get_XPath, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilterItem_set_XPath, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilterItem_get_XMLElement, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilterItem_set_XMLElement, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Value, TElXMLDOMElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilterItem___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElXMLXPathFilterItem_methods[] = {
	PHP_ME(TElXMLXPathFilterItem, get_Filter, arginfo_TElXMLXPathFilterItem_get_Filter, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilterItem, set_Filter, arginfo_TElXMLXPathFilterItem_set_Filter, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilterItem, get_NamespaceMap, arginfo_TElXMLXPathFilterItem_get_NamespaceMap, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilterItem, get_XPath, arginfo_TElXMLXPathFilterItem_get_XPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilterItem, set_XPath, arginfo_TElXMLXPathFilterItem_set_XPath, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilterItem, get_XMLElement, arginfo_TElXMLXPathFilterItem_get_XMLElement, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilterItem, set_XMLElement, arginfo_TElXMLXPathFilterItem_set_XMLElement, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilterItem, __construct, arginfo_TElXMLXPathFilterItem___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElXMLXPathFilterItem(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElXMLXPathFilterItem_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElXMLXPathFilterItem", TElXMLXPathFilterItem_methods);
	if (NULL == TObject_ce_ptr)
		Register_TObject(TSRMLS_C);
	TElXMLXPathFilterItem_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TObject_ce_ptr);
}

zend_class_entry *TElXMLXPathFilter2Transform_ce_ptr = NULL;

SB_PHP_METHOD(TElXMLXPathFilter2Transform, GetDefaultTransformAlgorithmURI_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLXPathFilter2Transform_GetDefaultTransformAlgorithmURI_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(922357719, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilter2Transform, GetDefaultTransformAlgorithmURI)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLXPathFilter2Transform_GetDefaultTransformAlgorithmURI(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(922357719, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilter2Transform, IsTransformAlgorithmSupported_Inst)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLXPathFilter2Transform_IsTransformAlgorithmSupported_1(SBGetObjectHandle(getThis() TSRMLS_CC), sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilter2Transform, IsTransformAlgorithmSupported)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLXPathFilter2Transform_IsTransformAlgorithmSupported(sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilter2Transform, Add)
{
	zval *oAFilter;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAFilter, TElXMLXPathFilterItem_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElXMLXPathFilter2Transform_Add(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oAFilter TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLXPathFilterItem)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilter2Transform, Delete)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElXMLXPathFilter2Transform_Delete(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilter2Transform, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElXMLXPathFilter2Transform_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilter2Transform, LoadFromXML)
{
	zval *oElement;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oElement, TElXMLDOMElement_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElXMLXPathFilter2Transform_LoadFromXML(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oElement TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMElement)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilter2Transform, SaveToXML)
{
	zval *oDocument;
	zval *oFormatter;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oDocument, TElXMLDOMDocument_ce_ptr, &oFormatter, TElXMLCustomFormatter_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLXPathFilter2Transform_SaveToXML(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDocument TSRMLS_CC), SBGetObjectHandle(oFormatter TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDocument, TElXMLDOMDocument_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLXPathFilter2Transform_SaveToXML_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDocument TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMDocument, \\TElXMLCustomFormatter) or (\\TElXMLDOMDocument)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilter2Transform, TransformData)
{
	SBArrayZValInfo aiData;
	SBArrayZValInfo aiReference;
	zval *oNode;
	zval *oNodes;
	zval *oReference;
	zval *zaData;
	zval *zaReference;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLXPathFilter2Transform_TransformData(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oNode, TElXMLDOMNode_ce_ptr, &oReference, TElXMLDOMNode_ce_ptr) == SUCCESS)
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		SBCheckError(TElXMLXPathFilter2Transform_TransformData_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNode TSRMLS_CC), SBGetObjectHandle(oReference TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oNodes, TElXMLDOMNodeList_ce_ptr, &zaReference, TElXMLDOMNode_ce_ptr) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaReference) || SB_IS_NULL_TYPE_RP(zaReference)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetObjectArrayFromZVal(zaReference, TElXMLDOMNode_ce_ptr, &aiReference TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLXPathFilter2Transform_TransformData_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNodes TSRMLS_CC), aiReference.data, aiReference.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiReference);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL) or (\\TElXMLDOMNode, \\TElXMLDOMNode) or (\\TElXMLDOMNodeList, &array of TElXMLDOMNode|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilter2Transform, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLXPathFilter2Transform_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilter2Transform, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElXMLXPathFilter2Transform_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilter2Transform, get_Filter)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLXPathFilter2Transform_get_Filter(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLXPathFilterItem_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLXPathFilter2Transform, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLXPathFilter2Transform_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilter2Transform_GetDefaultTransformAlgorithmURI_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilter2Transform_GetDefaultTransformAlgorithmURI, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilter2Transform_IsTransformAlgorithmSupported_Inst, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilter2Transform_IsTransformAlgorithmSupported, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilter2Transform_Add, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AFilter, TElXMLXPathFilterItem, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilter2Transform_Delete, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilter2Transform_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilter2Transform_LoadFromXML, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilter2Transform_SaveToXML, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Document, TElXMLDOMDocument, 1)
	ZEND_ARG_OBJ_INFO(0, Formatter, TElXMLCustomFormatter, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilter2Transform_TransformData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data_or_Node_or_Nodes, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Reference, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilter2Transform_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilter2Transform_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilter2Transform_get_Filter, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLXPathFilter2Transform___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElXMLXPathFilter2Transform_methods[] = {
	PHP_ME(TElXMLXPathFilter2Transform, GetDefaultTransformAlgorithmURI_Inst, arginfo_TElXMLXPathFilter2Transform_GetDefaultTransformAlgorithmURI_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilter2Transform, GetDefaultTransformAlgorithmURI, arginfo_TElXMLXPathFilter2Transform_GetDefaultTransformAlgorithmURI, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLXPathFilter2Transform, IsTransformAlgorithmSupported_Inst, arginfo_TElXMLXPathFilter2Transform_IsTransformAlgorithmSupported_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilter2Transform, IsTransformAlgorithmSupported, arginfo_TElXMLXPathFilter2Transform_IsTransformAlgorithmSupported, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLXPathFilter2Transform, Add, arginfo_TElXMLXPathFilter2Transform_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilter2Transform, Delete, arginfo_TElXMLXPathFilter2Transform_Delete, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilter2Transform, Clear, arginfo_TElXMLXPathFilter2Transform_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilter2Transform, LoadFromXML, arginfo_TElXMLXPathFilter2Transform_LoadFromXML, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilter2Transform, SaveToXML, arginfo_TElXMLXPathFilter2Transform_SaveToXML, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilter2Transform, TransformData, arginfo_TElXMLXPathFilter2Transform_TransformData, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilter2Transform, ClassType, arginfo_TElXMLXPathFilter2Transform_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLXPathFilter2Transform, get_Count, arginfo_TElXMLXPathFilter2Transform_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilter2Transform, get_Filter, arginfo_TElXMLXPathFilter2Transform_get_Filter, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLXPathFilter2Transform, __construct, arginfo_TElXMLXPathFilter2Transform___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElXMLXPathFilter2Transform(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElXMLXPathFilter2Transform_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElXMLXPathFilter2Transform", TElXMLXPathFilter2Transform_methods);
	if (NULL == TElXMLTransform_ce_ptr)
		Register_TElXMLTransform(TSRMLS_C);
	TElXMLXPathFilter2Transform_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElXMLTransform_ce_ptr);
}

zend_class_entry *TElXMLTransformChain_ce_ptr = NULL;

SB_PHP_METHOD(TElXMLTransformChain, TransformData)
{
	sb_zend_long fCanonicalizationMethod;
	SBArrayZValInfo aiData;
	SBArrayZValInfo aiReferenceNodes;
	uint32_t _err;
	zval *oNode;
	zval *oNodes;
	zval *oReferenceNode;
	zval *zaData;
	zval *zaReferenceNodes;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "zl", &zaData, &fCanonicalizationMethod) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		_err = TElXMLTransformChain_TransformData(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, (TElXMLCanonicalizationMethodRaw)fCanonicalizationMethod, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1565441212, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiData);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oNode, TElXMLDOMNode_ce_ptr, &fCanonicalizationMethod) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElXMLTransformChain_TransformData_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNode TSRMLS_CC), (TElXMLCanonicalizationMethodRaw)fCanonicalizationMethod, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1037545286, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!l", &oNode, TElXMLDOMNode_ce_ptr, &oReferenceNode, TElXMLDOMNode_ce_ptr, &fCanonicalizationMethod) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElXMLTransformChain_TransformData_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNode TSRMLS_CC), SBGetObjectHandle(oReferenceNode TSRMLS_CC), (TElXMLCanonicalizationMethodRaw)fCanonicalizationMethod, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-749036313, 4, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!l", &oNodes, TElXMLDOMNodeList_ce_ptr, &fCanonicalizationMethod) == SUCCESS)
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		_err = TElXMLTransformChain_TransformData_3(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNodes TSRMLS_CC), (TElXMLCanonicalizationMethodRaw)fCanonicalizationMethod, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(1148432593, 3, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!zl", &oNodes, TElXMLDOMNodeList_ce_ptr, &zaReferenceNodes, TElXMLDOMNode_ce_ptr, &fCanonicalizationMethod) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaReferenceNodes) || SB_IS_NULL_TYPE_RP(zaReferenceNodes)))
	{
		uint8_t *u8OutResult = NULL;
		int32_t u8OutResult_len = 0;
		if (!SBGetObjectArrayFromZVal(zaReferenceNodes, TElXMLDOMNode_ce_ptr, &aiReferenceNodes TSRMLS_CC)) RETURN_FALSE;
		_err = TElXMLTransformChain_TransformData_4(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNodes TSRMLS_CC), aiReferenceNodes.data, aiReferenceNodes.len, (TElXMLCanonicalizationMethodRaw)fCanonicalizationMethod, u8OutResult, &u8OutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			u8OutResult = emalloc(u8OutResult_len + 1);
			SBCheckError(SBGetLastReturnBuffer(-1020133852, 4, u8OutResult, &u8OutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		SBFreeArrayZValInfo(&aiReferenceNodes);
		if (NULL == u8OutResult) u8OutResult = emalloc(1);
		u8OutResult[u8OutResult_len] = 0;
		SB_RETURN_STRINGL(u8OutResult, u8OutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL, integer) or (\\TElXMLDOMNode, integer) or (\\TElXMLDOMNode, \\TElXMLDOMNode, integer) or (\\TElXMLDOMNodeList, integer) or (\\TElXMLDOMNodeList, &array of TElXMLDOMNode|NULL, integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransformChain, CloneTransforms)
{
	char *sANamespaceURI;
	sb_str_size sANamespaceURI_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sANamespaceURI, &sANamespaceURI_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLTransformChain_CloneTransforms(SBGetObjectHandle(getThis() TSRMLS_CC), sANamespaceURI, (int32_t)sANamespaceURI_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLTransformChain_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransformChain, Add)
{
	zval *oTransform;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oTransform, TElXMLTransform_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElXMLTransformChain_Add(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTransform TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLTransform)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransformChain, AddCanonicalizationTransform)
{
	sb_zend_long fAMethod;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fAMethod) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElXMLTransformChain_AddCanonicalizationTransform(SBGetObjectHandle(getThis() TSRMLS_CC), (TElXMLCanonicalizationMethodRaw)fAMethod, &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransformChain, AddEnvelopedSignatureTransform)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElXMLTransformChain_AddEnvelopedSignatureTransform(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransformChain, Insert)
{
	sb_zend_long l4Index;
	zval *oTransform;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "lO!", &l4Index, &oTransform, TElXMLTransform_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElXMLTransformChain_Insert(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, SBGetObjectHandle(oTransform TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer, \\TElXMLTransform)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransformChain, Delete)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		SBCheckError(TElXMLTransformChain_Delete(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransformChain, Clear)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(TElXMLTransformChain_Clear(SBGetObjectHandle(getThis() TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransformChain, IndexOf)
{
	zval *oTransform;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oTransform, TElXMLTransform_ce_ptr) == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElXMLTransformChain_IndexOf(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oTransform TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLTransform)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransformChain, IsEmpty)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLTransformChain_IsEmpty(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransformChain, LoadFromXML)
{
	zval *oElement;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oElement, TElXMLDOMElement_ce_ptr) == SUCCESS)
	{
		SBCheckError(TElXMLTransformChain_LoadFromXML(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oElement TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMElement)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransformChain, SaveToXML)
{
	zval *oDocument;
	zval *oFormatter;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oDocument, TElXMLDOMDocument_ce_ptr, &oFormatter, TElXMLCustomFormatter_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLTransformChain_SaveToXML(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDocument TSRMLS_CC), SBGetObjectHandle(oFormatter TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDocument, TElXMLDOMDocument_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLTransformChain_SaveToXML_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDocument TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMDocument, \\TElXMLCustomFormatter) or (\\TElXMLDOMDocument)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransformChain, get_Count)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElXMLTransformChain_get_Count(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransformChain, get_Transforms)
{
	sb_zend_long l4Index;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &l4Index) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLTransformChain_get_Transforms(SBGetObjectHandle(getThis() TSRMLS_CC), (int32_t)l4Index, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLTransform_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLTransformChain, __construct)
{
	char *sANamespaceURI;
	sb_str_size sANamespaceURI_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sANamespaceURI, &sANamespaceURI_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLTransformChain_Create(sANamespaceURI, (int32_t)sANamespaceURI_len, &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain_TransformData, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, Data_or_Node_or_Nodes, 0, 1)
	ZEND_ARG_TYPE_INFO(0, CanonicalizationMethod_or_ReferenceNode_or_ReferenceNodes, 0, 1)
	ZEND_ARG_INFO(0, CanonicalizationMethod)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain_CloneTransforms, 0, 0, 1)
	ZEND_ARG_INFO(0, ANamespaceURI)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain_Add, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Transform, TElXMLTransform, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain_AddCanonicalizationTransform, 0, 0, 1)
	ZEND_ARG_INFO(0, AMethod)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain_AddEnvelopedSignatureTransform, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain_Insert, 0, 0, 2)
	ZEND_ARG_INFO(0, Index)
	ZEND_ARG_OBJ_INFO(0, Transform, TElXMLTransform, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain_Delete, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain_Clear, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain_IndexOf, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Transform, TElXMLTransform, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain_IsEmpty, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain_LoadFromXML, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Element, TElXMLDOMElement, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain_SaveToXML, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Document, TElXMLDOMDocument, 1)
	ZEND_ARG_OBJ_INFO(0, Formatter, TElXMLCustomFormatter, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain_get_Count, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain_get_Transforms, 0, 0, 1)
	ZEND_ARG_INFO(0, Index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLTransformChain___construct, 0, 0, 1)
	ZEND_ARG_INFO(0, ANamespaceURI)
ZEND_END_ARG_INFO()

static zend_function_entry TElXMLTransformChain_methods[] = {
	PHP_ME(TElXMLTransformChain, TransformData, arginfo_TElXMLTransformChain_TransformData, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransformChain, CloneTransforms, arginfo_TElXMLTransformChain_CloneTransforms, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransformChain, Add, arginfo_TElXMLTransformChain_Add, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransformChain, AddCanonicalizationTransform, arginfo_TElXMLTransformChain_AddCanonicalizationTransform, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransformChain, AddEnvelopedSignatureTransform, arginfo_TElXMLTransformChain_AddEnvelopedSignatureTransform, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransformChain, Insert, arginfo_TElXMLTransformChain_Insert, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransformChain, Delete, arginfo_TElXMLTransformChain_Delete, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransformChain, Clear, arginfo_TElXMLTransformChain_Clear, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransformChain, IndexOf, arginfo_TElXMLTransformChain_IndexOf, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransformChain, IsEmpty, arginfo_TElXMLTransformChain_IsEmpty, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransformChain, LoadFromXML, arginfo_TElXMLTransformChain_LoadFromXML, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransformChain, SaveToXML, arginfo_TElXMLTransformChain_SaveToXML, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransformChain, get_Count, arginfo_TElXMLTransformChain_get_Count, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransformChain, get_Transforms, arginfo_TElXMLTransformChain_get_Transforms, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLTransformChain, __construct, arginfo_TElXMLTransformChain___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElXMLTransformChain(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElXMLTransformChain_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElXMLTransformChain", TElXMLTransformChain_methods);
	if (NULL == TElXMLCustomElement_ce_ptr)
		Register_TElXMLCustomElement(TSRMLS_C);
	TElXMLTransformChain_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElXMLCustomElement_ce_ptr);
}

zend_class_entry *TElXMLUnsupportedTransform_ce_ptr = NULL;

SB_PHP_METHOD(TElXMLUnsupportedTransform, GetDefaultTransformAlgorithmURI_Inst)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLUnsupportedTransform_GetDefaultTransformAlgorithmURI_1(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1070751535, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLUnsupportedTransform, GetDefaultTransformAlgorithmURI)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElXMLUnsupportedTransform_GetDefaultTransformAlgorithmURI(sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1070751535, 0, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLUnsupportedTransform, IsTransformAlgorithmSupported_Inst)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLUnsupportedTransform_IsTransformAlgorithmSupported_1(SBGetObjectHandle(getThis() TSRMLS_CC), sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLUnsupportedTransform, IsTransformAlgorithmSupported)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElXMLUnsupportedTransform_IsTransformAlgorithmSupported(sAlgorithm, (int32_t)sAlgorithm_len, &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLUnsupportedTransform, SaveToXML)
{
	zval *oDocument;
	zval *oFormatter;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oDocument, TElXMLDOMDocument_ce_ptr, &oFormatter, TElXMLCustomFormatter_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLUnsupportedTransform_SaveToXML(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDocument TSRMLS_CC), SBGetObjectHandle(oFormatter TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oDocument, TElXMLDOMDocument_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLUnsupportedTransform_SaveToXML_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oDocument TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMElement_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMDocument, \\TElXMLCustomFormatter) or (\\TElXMLDOMDocument)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLUnsupportedTransform, TransformData)
{
	SBArrayZValInfo aiData;
	SBArrayZValInfo aiReference;
	zval *oNode;
	zval *oNodes;
	zval *oReference;
	zval *zaData;
	zval *zaReference;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLUnsupportedTransform_TransformData(SBGetObjectHandle(getThis() TSRMLS_CC), aiData.data, aiData.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!O!", &oNode, TElXMLDOMNode_ce_ptr, &oReference, TElXMLDOMNode_ce_ptr) == SUCCESS)
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		SBCheckError(TElXMLUnsupportedTransform_TransformData_1(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNode TSRMLS_CC), SBGetObjectHandle(oReference TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!z", &oNodes, TElXMLDOMNodeList_ce_ptr, &zaReference, TElXMLDOMNode_ce_ptr) == SUCCESS) && (SB_IS_ARRAY_TYPE_RP(zaReference) || SB_IS_NULL_TYPE_RP(zaReference)))
	{
		TSBTransformedDataTypeRaw fOutResultRaw = 0;
		if (!SBGetObjectArrayFromZVal(zaReference, TElXMLDOMNode_ce_ptr, &aiReference TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(TElXMLUnsupportedTransform_TransformData_2(SBGetObjectHandle(getThis() TSRMLS_CC), SBGetObjectHandle(oNodes TSRMLS_CC), aiReference.data, aiReference.len, &fOutResultRaw) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiReference);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL) or (\\TElXMLDOMNode, \\TElXMLDOMNode) or (\\TElXMLDOMNodeList, &array of TElXMLDOMNode|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLUnsupportedTransform, ClassType)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLUnsupportedTransform_ClassType(&hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElXMLUnsupportedTransform, __construct)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElXMLUnsupportedTransform_Create(&hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLUnsupportedTransform_GetDefaultTransformAlgorithmURI_Inst, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLUnsupportedTransform_GetDefaultTransformAlgorithmURI, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLUnsupportedTransform_IsTransformAlgorithmSupported_Inst, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLUnsupportedTransform_IsTransformAlgorithmSupported, 0, 0, 1)
	ZEND_ARG_INFO(0, Algorithm)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLUnsupportedTransform_SaveToXML, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, Document, TElXMLDOMDocument, 1)
	ZEND_ARG_OBJ_INFO(0, Formatter, TElXMLCustomFormatter, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLUnsupportedTransform_TransformData, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Data_or_Node_or_Nodes, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Reference, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLUnsupportedTransform_ClassType, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElXMLUnsupportedTransform___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

static zend_function_entry TElXMLUnsupportedTransform_methods[] = {
	PHP_ME(TElXMLUnsupportedTransform, GetDefaultTransformAlgorithmURI_Inst, arginfo_TElXMLUnsupportedTransform_GetDefaultTransformAlgorithmURI_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLUnsupportedTransform, GetDefaultTransformAlgorithmURI, arginfo_TElXMLUnsupportedTransform_GetDefaultTransformAlgorithmURI, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLUnsupportedTransform, IsTransformAlgorithmSupported_Inst, arginfo_TElXMLUnsupportedTransform_IsTransformAlgorithmSupported_Inst, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLUnsupportedTransform, IsTransformAlgorithmSupported, arginfo_TElXMLUnsupportedTransform_IsTransformAlgorithmSupported, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLUnsupportedTransform, SaveToXML, arginfo_TElXMLUnsupportedTransform_SaveToXML, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLUnsupportedTransform, TransformData, arginfo_TElXMLUnsupportedTransform_TransformData, ZEND_ACC_PUBLIC)
	PHP_ME(TElXMLUnsupportedTransform, ClassType, arginfo_TElXMLUnsupportedTransform_ClassType, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
	PHP_ME(TElXMLUnsupportedTransform, __construct, arginfo_TElXMLUnsupportedTransform___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElXMLUnsupportedTransform(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElXMLUnsupportedTransform_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElXMLUnsupportedTransform", TElXMLUnsupportedTransform_methods);
	if (NULL == TElXMLTransform_ce_ptr)
		Register_TElXMLTransform(TSRMLS_C);
	TElXMLUnsupportedTransform_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TElXMLTransform_ce_ptr);
}

SB_PHP_FUNCTION(SBXMLTransform, Initialize)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		SBCheckError(SBXMLTransform_Initialize() TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBXMLTransform, LoadDocumentFromData)
{
	SBArrayZValInfo aiData;
	zval *zaData;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zaData) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zaData) || SB_IS_ARRAY_TYPE_RP(zaData) || SB_IS_NULL_TYPE_RP(zaData)))
	{
		TElClassHandle hoOutResult = NULL;
		if (!SBGetByteArrayFromZVal(zaData, &aiData TSRMLS_CC)) RETURN_FALSE;
		SBCheckError(SBXMLTransform_LoadDocumentFromData(aiData.data, aiData.len, &hoOutResult) TSRMLS_CC);
		SBFreeArrayZValInfo(&aiData);
		SBInitObject(return_value, TElXMLDOMDocument_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(array of byte|string|NULL)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBXMLTransform, NodeToNodeList)
{
	zval *oNode;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oNode, TElXMLDOMNode_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(SBXMLTransform_NodeToNodeList(SBGetObjectHandle(oNode TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLDOMNodeList_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLDOMNode)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBXMLTransform, RegisterTransformClass)
{
	zval *oTransformClass;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oTransformClass, TElXMLTransformClass_ce_ptr) == SUCCESS)
	{
		SBCheckError(SBXMLTransform_RegisterTransformClass(SBGetObjectHandle(oTransformClass TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLTransformClass)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBXMLTransform, UnregisterTransformClass)
{
	zval *oTransformClass;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oTransformClass, TElXMLTransformClass_ce_ptr) == SUCCESS)
	{
		SBCheckError(SBXMLTransform_UnregisterTransformClass(SBGetObjectHandle(oTransformClass TSRMLS_CC)) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TElXMLTransformClass)" TSRMLS_CC);
	}
}

SB_PHP_FUNCTION(SBXMLTransform, FindTransformClass)
{
	char *sAlgorithm;
	sb_str_size sAlgorithm_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sAlgorithm, &sAlgorithm_len) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(SBXMLTransform_FindTransformClass(sAlgorithm, (int32_t)sAlgorithm_len, &hoOutResult) TSRMLS_CC);
		SBInitObject(return_value, TElXMLTransformClass_ce_ptr, hoOutResult TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

void Register_SBXMLTransform_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_STRING_CONSTANT(SBXMLTransform, SFXMLCantApplyTransformToBinary, SB_SFXMLCantApplyTransformToBinary, SB_SFXMLCantApplyTransformToBinary);
}

void Register_SBXMLTransform_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBTransformProperties", NULL);
	TSBTransformProperties_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBTransformProperties_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBTransformProperties_ce_ptr, "tpConcatenate", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBTransformProperties_ce_ptr, "tpC14NCommutative", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBTransformedDataType", NULL);
	TSBTransformedDataType_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBTransformedDataType_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBTransformedDataType_ce_ptr, "tdtBinary", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBTransformedDataType_ce_ptr, "tdtNode", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBTransformedDataType_ce_ptr, "tdtNodes", 2)
	
	INIT_CLASS_ENTRY(ce, "TSBXPathFilterOperation", NULL);
	TSBXPathFilterOperation_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBXPathFilterOperation_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBXPathFilterOperation_ce_ptr, "xfIntersect", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBXPathFilterOperation_ce_ptr, "xfSubtract", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBXPathFilterOperation_ce_ptr, "xfUnion", 2)
}

void Register_SBXMLTransform_Aliases(TSRMLS_D)
{
	if (NULL == TElXMLTransform_ce_ptr)
		Register_TElXMLTransform(TSRMLS_C);
	zend_register_class_alias("ElXMLTransform", TElXMLTransform_ce_ptr);
	if (NULL == TElXMLNullTransform_ce_ptr)
		Register_TElXMLNullTransform(TSRMLS_C);
	zend_register_class_alias("ElXMLNullTransform", TElXMLNullTransform_ce_ptr);
	if (NULL == TElXMLBase64Transform_ce_ptr)
		Register_TElXMLBase64Transform(TSRMLS_C);
	zend_register_class_alias("ElXMLBase64Transform", TElXMLBase64Transform_ce_ptr);
	if (NULL == TElXMLC14NTransform_ce_ptr)
		Register_TElXMLC14NTransform(TSRMLS_C);
	zend_register_class_alias("ElXMLC14NTransform", TElXMLC14NTransform_ce_ptr);
	if (NULL == TElXMLEnvelopedSignatureTransform_ce_ptr)
		Register_TElXMLEnvelopedSignatureTransform(TSRMLS_C);
	zend_register_class_alias("ElXMLEnvelopedSignatureTransform", TElXMLEnvelopedSignatureTransform_ce_ptr);
	if (NULL == TElXMLXPathTransform_ce_ptr)
		Register_TElXMLXPathTransform(TSRMLS_C);
	zend_register_class_alias("ElXMLXPathTransform", TElXMLXPathTransform_ce_ptr);
	if (NULL == TElXMLTransformChain_ce_ptr)
		Register_TElXMLTransformChain(TSRMLS_C);
	zend_register_class_alias("ElXMLTransformChain", TElXMLTransformChain_ce_ptr);
	TElXMLTransformClass_ce_ptr = TObject_ce_ptr;
	zend_register_class_alias("TElXMLTransformClass", TElXMLTransformClass_ce_ptr);
	zend_register_class_alias("ElXMLTransformClass", TObject_ce_ptr);
}

