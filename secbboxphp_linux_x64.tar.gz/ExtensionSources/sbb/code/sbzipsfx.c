#include "sbdefs.h"
#ifdef SB_WINDOWS
#include "sbzipsfx.h"

zend_class_entry *TSBZIPSFXCommandLineSwitch_ce_ptr = NULL;

zend_class_entry *TSBZIPSFXCommandLineSwitches_ce_ptr = NULL;

void SB_CALLBACK TSBZIPSFXExtractingEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcFolder, int32_t szFolder, const char * pcFileName, int32_t szFileName)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zFolder;
	zval * zFileName;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zFolder, 1);
	SB_ZVAL_STRINGL_DUP(zFolder, pcFolder, szFolder);
	SB_EVENT_INIT_ZVAL(zFileName, 2);
	SB_ZVAL_STRINGL_DUP(zFileName, pcFileName, szFileName);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zFolder);
	SB_EVENT_CLEAR_ZVAL(zFileName);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBZIPSFXErrorEventRaw(void * _ObjectData, TObjectHandle Sender, TElClassHandle Error)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(2);
	zval * zSender;
	zval * zError;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zError, 1);
	SBInitObject(zError, TObject_ce_ptr, Error TSRMLS_CC);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 2, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zError);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBZIPSFXStartEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t HelpRequested, int8_t * Abort)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zHelpRequested;
	zval * zAbort;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL(zHelpRequested, 1);
	ZVAL_BOOL(zHelpRequested, (zend_bool)HelpRequested);
	SB_EVENT_INIT_ZVAL_REF(zAbort, 2);
	ZVAL_BOOL(Z_REFVAL_P(zAbort), (zend_bool)*Abort);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	SB_EVENT_CLEAR_ZVAL(zHelpRequested);
	convert_to_boolean(Z_REFVAL_P(zAbort));
	*Abort = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAbort));
	SB_EVENT_CLEAR_ZVAL(zAbort);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

void SB_CALLBACK TSBZIPSFXTargetFolderEventRaw(void * _ObjectData, TObjectHandle Sender, char * pcFolder, int32_t * szFolder, int8_t * Abort)
{
	SB_EVENT_DECL_RETVAL
	SB_EVENT_DECL_RETVAL_PTR(retval_ptr);
	SB_EVENT_INIT_PARAMS(3);
	zval * zSender;
	zval * zFolder;
	zval * zAbort;
	TSRMLS_FETCH();
	SB_EVENT_INIT_ZVAL(zSender, 0);
	SBInitObject(zSender, TObject_ce_ptr, Sender TSRMLS_CC);
	SB_EVENT_INIT_ZVAL_REF(zFolder, 1);
	SB_ZVAL_STRINGL_DUP(Z_REFVAL_P(zFolder), pcFolder, *szFolder);
	SB_EVENT_INIT_ZVAL_REF(zAbort, 2);
	ZVAL_BOOL(Z_REFVAL_P(zAbort), (zend_bool)*Abort);

	SBCallEvent((zval *)_ObjectData, SB_EVENT_GET_RETVAL(retval_ptr), 3, params TSRMLS_CC);

	SB_EVENT_CLEAR_ZVAL(zSender);
	convert_to_string(Z_REFVAL_P(zFolder));
	SBCheckError(SBSetEventReturnStringA(2, Z_STRVAL_P(Z_REFVAL_P(zFolder)), (int32_t)Z_STRLEN_P(Z_REFVAL_P(zFolder))) TSRMLS_CC);
	SB_EVENT_CLEAR_ZVAL(zFolder);
	convert_to_boolean(Z_REFVAL_P(zAbort));
	*Abort = (int8_t)SB_BVAL_P(Z_REFVAL_P(zAbort));
	SB_EVENT_CLEAR_ZVAL(zAbort);
	if (retval_ptr) SB_EVENT_CLEAR_ZVAL(retval_ptr);
}

zend_class_entry *TElZIPSFXStub_ce_ptr = NULL;

SB_PHP_METHOD(TElZIPSFXStub, Execute)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int32_t l4OutResultRaw = 0;
		SBCheckError(TElZIPSFXStub_Execute(SBGetObjectHandle(getThis() TSRMLS_CC), &l4OutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)l4OutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_Copyright)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZIPSFXStub_get_Copyright(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1890020117, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_Evaluation)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZIPSFXStub_get_Evaluation(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_Title)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZIPSFXStub_get_Title(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1833463158, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_UsedSwitches)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZIPSFXCommandLineSwitchesRaw fOutResultRaw = 0;
		SBCheckError(TElZIPSFXStub_get_UsedSwitches(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_Extract)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZIPSFXStub_get_Extract(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-315429464, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_Extract)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZIPSFXStub_set_Extract(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_Password)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZIPSFXStub_get_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(1584731533, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_Password)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZIPSFXStub_set_Password(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_CertFile)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZIPSFXStub_get_CertFile(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-835787556, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_CertFile)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZIPSFXStub_set_CertFile(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_CertPassword)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZIPSFXStub_get_CertPassword(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-1021536660, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_CertPassword)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZIPSFXStub_set_CertPassword(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_Silent)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZIPSFXStub_get_Silent(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_Silent)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZIPSFXStub_set_Silent(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_SupportedSwitches)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZIPSFXCommandLineSwitchesRaw fOutResultRaw = 0;
		SBCheckError(TElZIPSFXStub_get_SupportedSwitches(SBGetObjectHandle(getThis() TSRMLS_CC), &fOutResultRaw) TSRMLS_CC);
		RETURN_LONG((sb_zend_long)fOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_SupportedSwitches)
{
	sb_zend_long fValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "l", &fValue) == SUCCESS)
	{
		SBCheckError(TElZIPSFXStub_set_SupportedSwitches(SBGetObjectHandle(getThis() TSRMLS_CC), (TSBZIPSFXCommandLineSwitchesRaw)fValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(integer)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_Target)
{
	uint32_t _err;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		char *sOutResult = NULL;
		int32_t sOutResult_len = 0;
		_err = TElZIPSFXStub_get_Target(SBGetObjectHandle(getThis() TSRMLS_CC), sOutResult, &sOutResult_len);
		if (SB_ERROR_INSUFFICIENT_BUFFER_SIZE == _err)
		{
			sOutResult = emalloc(sOutResult_len + 1);
			SBCheckError(SBGetLastReturnStringA(-147991875, 1, sOutResult, &sOutResult_len) TSRMLS_CC);
		}
		else
		if (_err != SB_ERROR_OK)
		{
			SBThrowException(_err TSRMLS_CC);
			RETURN_FALSE;
		}
	
		if (NULL == sOutResult) sOutResult = emalloc(1);
		sOutResult[sOutResult_len] = 0;
		SB_RETURN_STRINGL(sOutResult, sOutResult_len);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_Target)
{
	char *sValue;
	sb_str_size sValue_len;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "s", &sValue, &sValue_len) == SUCCESS)
	{
		SBCheckError(TElZIPSFXStub_set_Target(SBGetObjectHandle(getThis() TSRMLS_CC), sValue, (int32_t)sValue_len) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(string)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_UseCommandLine)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		int8_t bOutResultRaw = 0;
		SBCheckError(TElZIPSFXStub_get_UseCommandLine(SBGetObjectHandle(getThis() TSRMLS_CC), &bOutResultRaw) TSRMLS_CC);
		RETURN_BOOL(bOutResultRaw);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_UseCommandLine)
{
	zend_bool bValue;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "b", &bValue) == SUCCESS)
	{
		SBCheckError(TElZIPSFXStub_set_UseCommandLine(SBGetObjectHandle(getThis() TSRMLS_CC), (int8_t)bValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(bool)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_OnAbort)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZIPSFXStub_get_OnAbort(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_OnAbort)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZIPSFXStub_set_OnAbort(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_OnCommandLine)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZIPSFXStub_get_OnCommandLine(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_OnCommandLine)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZIPSFXStub_set_OnCommandLine(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_OnError)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZIPSFXErrorEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZIPSFXStub_get_OnError(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_OnError)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZIPSFXStub_set_OnError(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZIPSFXErrorEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZIPSFXErrorEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_OnExtracting)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZIPSFXExtractingEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZIPSFXStub_get_OnExtracting(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_OnExtracting)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZIPSFXStub_set_OnExtracting(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZIPSFXExtractingEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZIPSFXExtractingEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_OnFinish)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TNotifyEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZIPSFXStub_get_OnFinish(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_OnFinish)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZIPSFXStub_set_OnFinish(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TNotifyEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TNotifyEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_OnPasswordNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipPasswordNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZIPSFXStub_get_OnPasswordNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_OnPasswordNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZIPSFXStub_set_OnPasswordNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipPasswordNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipPasswordNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_OnProgress)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipProgressEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZIPSFXStub_get_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_OnProgress)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZIPSFXStub_set_OnProgress(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipProgressEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipProgressEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_OnFileStart)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipExtractionStartEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZIPSFXStub_get_OnFileStart(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_OnFileStart)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZIPSFXStub_set_OnFileStart(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipExtractionStartEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipExtractionStartEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_OnFileFinish)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipExtractionFinishedEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZIPSFXStub_get_OnFileFinish(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_OnFileFinish)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZIPSFXStub_set_OnFileFinish(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipExtractionFinishedEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipExtractionFinishedEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_OnUserActionNeeded)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZipUserActionNeededEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZIPSFXStub_get_OnUserActionNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_OnUserActionNeeded)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZIPSFXStub_set_OnUserActionNeeded(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZipUserActionNeededEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZipUserActionNeededEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_OnStart)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZIPSFXStartEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZIPSFXStub_get_OnStart(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_OnStart)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZIPSFXStub_set_OnStart(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZIPSFXStartEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZIPSFXStartEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, get_OnTargetFolder)
{
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "") == SUCCESS)
	{
		TSBZIPSFXTargetFolderEvent pMethodOutResult = NULL;
		void * pDataOutResult = NULL;
		SBCheckError(TElZIPSFXStub_get_OnTargetFolder(SBGetObjectHandle(getThis() TSRMLS_CC), &pMethodOutResult, &pDataOutResult) TSRMLS_CC);
		if (NULL != pDataOutResult)
		{
			zval *zpDataOutResult = (zval *)pDataOutResult;
			RETVAL_ZVAL(zpDataOutResult, 1, 0);
		}
		else
			ZVAL_NULL(return_value);
	}
	else
	{
		SBErrorExpectsArguments("()" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, set_OnTargetFolder)
{
	void *pzValue;
	zval *zValue;
	if ((zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "z", &zValue) == SUCCESS) && (SB_IS_STRING_TYPE_RP(zValue) || SB_IS_ARRAY_TYPE_RP(zValue) || SB_IS_CALLABLE_TYPE_RP(zValue) || SB_IS_NULL_TYPE_RP(zValue)))
	{
		pzValue = SBSetEventData(zValue TSRMLS_CC);
		SBCheckError(TElZIPSFXStub_set_OnTargetFolder(SBGetObjectHandle(getThis() TSRMLS_CC), pzValue ? &TSBZIPSFXTargetFolderEventRaw : NULL, pzValue) TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TSBZIPSFXTargetFolderEvent|callable|NULL)" TSRMLS_CC);
	}
}

SB_PHP_METHOD(TElZIPSFXStub, __construct)
{
	zval *oAOwner;
	if (zend_parse_parameters_ex(ZEND_PARSE_PARAMS_QUIET, ZEND_NUM_ARGS() TSRMLS_CC, "O!", &oAOwner, TComponent_ce_ptr) == SUCCESS)
	{
		TElClassHandle hoOutResult = NULL;
		SBCheckError(TElZIPSFXStub_Create(SBGetObjectHandle(oAOwner TSRMLS_CC), &hoOutResult) TSRMLS_CC);
		SBSetObjectHandle(getThis(), hoOutResult, ohTrue TSRMLS_CC);
	}
	else
	{
		SBErrorExpectsArguments("(\\TComponent)" TSRMLS_CC);
	}
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_Execute, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_Copyright, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_Evaluation, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_Title, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_UsedSwitches, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_Extract, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_Extract, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_Password, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_Password, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_CertFile, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_CertFile, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_CertPassword, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_CertPassword, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_Silent, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_Silent, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_SupportedSwitches, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_SupportedSwitches, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_Target, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_Target, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_UseCommandLine, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_UseCommandLine, 0, 0, 1)
	ZEND_ARG_INFO(0, Value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_OnAbort, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_OnAbort, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_OnCommandLine, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_OnCommandLine, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_OnError, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_OnError, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_OnExtracting, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_OnExtracting, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_OnFinish, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_OnFinish, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_OnPasswordNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_OnPasswordNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_OnProgress, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_OnProgress, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_OnFileStart, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_OnFileStart, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_OnFileFinish, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_OnFileFinish, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_OnUserActionNeeded, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_OnUserActionNeeded, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_OnStart, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_OnStart, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_get_OnTargetFolder, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub_set_OnTargetFolder, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, Value, 0, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_TElZIPSFXStub___construct, 0, 0, 1)
	ZEND_ARG_OBJ_INFO(0, AOwner, TComponent, 1)
ZEND_END_ARG_INFO()

static zend_function_entry TElZIPSFXStub_methods[] = {
	PHP_ME(TElZIPSFXStub, Execute, arginfo_TElZIPSFXStub_Execute, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_Copyright, arginfo_TElZIPSFXStub_get_Copyright, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_Evaluation, arginfo_TElZIPSFXStub_get_Evaluation, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_Title, arginfo_TElZIPSFXStub_get_Title, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_UsedSwitches, arginfo_TElZIPSFXStub_get_UsedSwitches, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_Extract, arginfo_TElZIPSFXStub_get_Extract, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_Extract, arginfo_TElZIPSFXStub_set_Extract, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_Password, arginfo_TElZIPSFXStub_get_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_Password, arginfo_TElZIPSFXStub_set_Password, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_CertFile, arginfo_TElZIPSFXStub_get_CertFile, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_CertFile, arginfo_TElZIPSFXStub_set_CertFile, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_CertPassword, arginfo_TElZIPSFXStub_get_CertPassword, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_CertPassword, arginfo_TElZIPSFXStub_set_CertPassword, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_Silent, arginfo_TElZIPSFXStub_get_Silent, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_Silent, arginfo_TElZIPSFXStub_set_Silent, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_SupportedSwitches, arginfo_TElZIPSFXStub_get_SupportedSwitches, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_SupportedSwitches, arginfo_TElZIPSFXStub_set_SupportedSwitches, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_Target, arginfo_TElZIPSFXStub_get_Target, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_Target, arginfo_TElZIPSFXStub_set_Target, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_UseCommandLine, arginfo_TElZIPSFXStub_get_UseCommandLine, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_UseCommandLine, arginfo_TElZIPSFXStub_set_UseCommandLine, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_OnAbort, arginfo_TElZIPSFXStub_get_OnAbort, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_OnAbort, arginfo_TElZIPSFXStub_set_OnAbort, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_OnCommandLine, arginfo_TElZIPSFXStub_get_OnCommandLine, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_OnCommandLine, arginfo_TElZIPSFXStub_set_OnCommandLine, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_OnError, arginfo_TElZIPSFXStub_get_OnError, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_OnError, arginfo_TElZIPSFXStub_set_OnError, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_OnExtracting, arginfo_TElZIPSFXStub_get_OnExtracting, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_OnExtracting, arginfo_TElZIPSFXStub_set_OnExtracting, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_OnFinish, arginfo_TElZIPSFXStub_get_OnFinish, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_OnFinish, arginfo_TElZIPSFXStub_set_OnFinish, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_OnPasswordNeeded, arginfo_TElZIPSFXStub_get_OnPasswordNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_OnPasswordNeeded, arginfo_TElZIPSFXStub_set_OnPasswordNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_OnProgress, arginfo_TElZIPSFXStub_get_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_OnProgress, arginfo_TElZIPSFXStub_set_OnProgress, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_OnFileStart, arginfo_TElZIPSFXStub_get_OnFileStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_OnFileStart, arginfo_TElZIPSFXStub_set_OnFileStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_OnFileFinish, arginfo_TElZIPSFXStub_get_OnFileFinish, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_OnFileFinish, arginfo_TElZIPSFXStub_set_OnFileFinish, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_OnUserActionNeeded, arginfo_TElZIPSFXStub_get_OnUserActionNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_OnUserActionNeeded, arginfo_TElZIPSFXStub_set_OnUserActionNeeded, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_OnStart, arginfo_TElZIPSFXStub_get_OnStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_OnStart, arginfo_TElZIPSFXStub_set_OnStart, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, get_OnTargetFolder, arginfo_TElZIPSFXStub_get_OnTargetFolder, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, set_OnTargetFolder, arginfo_TElZIPSFXStub_set_OnTargetFolder, ZEND_ACC_PUBLIC)
	PHP_ME(TElZIPSFXStub, __construct, arginfo_TElZIPSFXStub___construct, ZEND_ACC_CTOR | ZEND_ACC_PUBLIC)
	PHP_FE_END
};

void Register_TElZIPSFXStub(TSRMLS_D)
{
	zend_class_entry ce;
	if (TElZIPSFXStub_ce_ptr != NULL)
		return;

	INIT_CLASS_ENTRY(ce, "TElZIPSFXStub", TElZIPSFXStub_methods);
	if (NULL == TComponent_ce_ptr)
		Register_TComponent(TSRMLS_C);
	TElZIPSFXStub_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TComponent_ce_ptr);
}

void Register_SBZIPSFX_Constants(int module_number TSRMLS_DC)
{
	SB_REGISTER_LONG_CONSTANT(SBZIPSFX, ZIPSFXStubAllSwitches, SB_ZIPSFXStubAllSwitches, 63);
	SB_REGISTER_STRING_CONSTANT(SBZIPSFX, SErrUserAbort, SB_SErrUserAbort, SB_SErrUserAbort);
	SB_REGISTER_STRING_CONSTANT(SBZIPSFX, SErrInternalError, SB_SErrInternalError, SB_SErrInternalError);
	SB_REGISTER_STRING_CONSTANT(SBZIPSFX, SErrInvalidParamTarget, SB_SErrInvalidParamTarget, SB_SErrInvalidParamTarget);
	SB_REGISTER_STRING_CONSTANT(SBZIPSFX, SErrInvalidParamPublic, SB_SErrInvalidParamPublic, SB_SErrInvalidParamPublic);
	SB_REGISTER_STRING_CONSTANT(SBZIPSFX, SErrInvalidParamKeyPass, SB_SErrInvalidParamKeyPass, SB_SErrInvalidParamKeyPass);
	SB_REGISTER_STRING_CONSTANT(SBZIPSFX, SErrInvalidParamPass, SB_SErrInvalidParamPass, SB_SErrInvalidParamPass);
	SB_REGISTER_STRING_CONSTANT(SBZIPSFX, SErrInvalidParamTemp, SB_SErrInvalidParamTemp, SB_SErrInvalidParamTemp);
	SB_REGISTER_STRING_CONSTANT(SBZIPSFX, SErrTargetFolderFailure, SB_SErrTargetFolderFailure, SB_SErrTargetFolderFailure);
	SB_REGISTER_STRING_CONSTANT(SBZIPSFX, SErrInputStreamFailure, SB_SErrInputStreamFailure, SB_SErrInputStreamFailure);
	SB_REGISTER_STRING_CONSTANT(SBZIPSFX, SErrNoZIPData, SB_SErrNoZIPData, SB_SErrNoZIPData);
	SB_REGISTER_STRING_CONSTANT(SBZIPSFX, SErrNoSFXData, SB_SErrNoSFXData, SB_SErrNoSFXData);
	SB_REGISTER_STRING_CONSTANT(SBZIPSFX, SErrPacketFileAlreadyExists, SB_SErrPacketFileAlreadyExists, SB_SErrPacketFileAlreadyExists);
	SB_REGISTER_STRING_CONSTANT(SBZIPSFX, SErrPacketFileFailure, SB_SErrPacketFileFailure, SB_SErrPacketFileFailure);
}

void Register_SBZIPSFX_Enum_Flags(TSRMLS_D)
{
	zend_class_entry ce;
	INIT_CLASS_ENTRY(ce, "TSBZIPSFXCommandLineSwitch", NULL);
	TSBZIPSFXCommandLineSwitch_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseEnum_ce_ptr);
	TSBZIPSFXCommandLineSwitch_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPSFXCommandLineSwitch_ce_ptr, "clsHelp", 0)
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPSFXCommandLineSwitch_ce_ptr, "clsSilent", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPSFXCommandLineSwitch_ce_ptr, "clsTarget", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPSFXCommandLineSwitch_ce_ptr, "clsPass", 3)
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPSFXCommandLineSwitch_ce_ptr, "clsExtract", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPSFXCommandLineSwitch_ce_ptr, "clsTempFile", 5)
	
	INIT_CLASS_ENTRY(ce, "TSBZIPSFXCommandLineSwitches", NULL);
	TSBZIPSFXCommandLineSwitches_ce_ptr = SB_REGISTER_INTERNAL_CLASS_EX(&ce, TSBBaseFlags_ce_ptr);
	TSBZIPSFXCommandLineSwitches_ce_ptr->ce_flags |= SB_ACC_FINAL_CLASS;
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPSFXCommandLineSwitches_ce_ptr, "clsHelp", 1)
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPSFXCommandLineSwitches_ce_ptr, "clsSilent", 2)
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPSFXCommandLineSwitches_ce_ptr, "clsTarget", 4)
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPSFXCommandLineSwitches_ce_ptr, "clsPass", 8)
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPSFXCommandLineSwitches_ce_ptr, "clsExtract", 16)
	SB_DECLARE_CLASS_LONG_CONST(TSBZIPSFXCommandLineSwitches_ce_ptr, "clsTempFile", 32)
}
#endif
