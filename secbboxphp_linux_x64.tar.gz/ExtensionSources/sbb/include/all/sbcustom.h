#ifndef __INC_SBCUSTOM
#define __INC_SBCUSTOM

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#define SB_USE_ALL_UNITS

#endif  /* __INC_SBCUSTOM */

