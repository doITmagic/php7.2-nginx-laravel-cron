#ifndef __INC_CSMACICELANDIC
#define __INC_CSMACICELANDIC

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbchsconvbase.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TPlMacIcelandicHandle;

#ifdef SB_USE_CLASS_TPLMACICELANDIC
SB_IMPORT uint32_t SB_APIENTRY TPlMacIcelandic_GetCategory(TPlMacIcelandicHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlMacIcelandic_GetDescription(TPlMacIcelandicHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlMacIcelandic_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlMacIcelandic_Create(TPlTableCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlMacIcelandic_CreateForFinalize(TPlTableCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLMACICELANDIC */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TPlMacIcelandic_ce_ptr;

void Register_TPlMacIcelandic(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_CSMACICELANDIC */

