#ifndef __INC_CSNEXTSTEP
#define __INC_CSNEXTSTEP

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbchsconvbase.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TPlNextStepHandle;

#ifdef SB_USE_CLASS_TPLNEXTSTEP
SB_IMPORT uint32_t SB_APIENTRY TPlNextStep_GetCategory(TPlNextStepHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlNextStep_GetDescription(TPlNextStepHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlNextStep_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlNextStep_Create(TPlTableCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlNextStep_CreateForFinalize(TPlTableCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLNEXTSTEP */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TPlNextStep_ce_ptr;

void Register_TPlNextStep(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_CSNEXTSTEP */

