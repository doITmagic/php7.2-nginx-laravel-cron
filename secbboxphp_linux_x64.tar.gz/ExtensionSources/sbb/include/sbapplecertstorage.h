#ifndef __INC_SBAPPLECERTSTORAGE
#define __INC_SBAPPLECERTSTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#ifdef MACOS
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbapplecommon.h"
#include "sbx509.h"
#include "sbcustomcertstorage.h"
#include "sbcryptoprov.h"
#include "sbcryptoprovbuiltin.h"
#endif

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef MACOS
typedef TElClassHandle TElAppleCertStorageHandle;

typedef TElAppleCertStorageHandle ElAppleCertStorageHandle;

typedef void (SB_CALLBACK *TElEvaluationResultEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcres, int32_t szres, const SB_SecTrustResultTypeRaw resType);

#ifdef SB_USE_CLASS_TELAPPLECERTSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_GetOpenedKeychains(TStringsHandle Keychains);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_GetOpenedKeychains_1(TElAppleCertStorageHandle _Handle, TStringsHandle Keychains);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_AddToSearchList(const char * pcKeychainPath, int32_t szKeychainPath);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_AddToSearchList_1(TElAppleCertStorageHandle _Handle, const char * pcKeychainPath, int32_t szKeychainPath);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_AddToSearchList_2(TStringListHandle KeychainsPath);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_AddToSearchList_3(TElAppleCertStorageHandle _Handle, TStringListHandle KeychainsPath);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_RemoveFromSearchList(const char * pcKeychainPath, int32_t szKeychainPath);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_RemoveFromSearchList_1(TElAppleCertStorageHandle _Handle, const char * pcKeychainPath, int32_t szKeychainPath);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_RemoveFromSearchList_2(TStringListHandle KeychainsPath);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_RemoveFromSearchList_3(TElAppleCertStorageHandle _Handle, TStringListHandle KeychainsPath);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_CreateKeychain(const char * pckeychainPath, int32_t szkeychainPath);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_CreateKeychain_1(TElAppleCertStorageHandle _Handle, const char * pckeychainPath, int32_t szkeychainPath);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_CreateKeychain_2(const char * pckeychainPath, int32_t szkeychainPath, const char * pcpassword, int32_t szpassword);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_CreateKeychain_3(TElAppleCertStorageHandle _Handle, const char * pckeychainPath, int32_t szkeychainPath, const char * pcpassword, int32_t szpassword);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_DeleteKeychain(const char * pckeychainPath, int32_t szkeychainPath);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_DeleteKeychain_1(TElAppleCertStorageHandle _Handle, const char * pckeychainPath, int32_t szkeychainPath);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_DeleteKeychain_2(const char * pckeychainPath, int32_t szkeychainPath, const char * pcpassword, int32_t szpassword);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_DeleteKeychain_3(TElAppleCertStorageHandle _Handle, const char * pckeychainPath, int32_t szkeychainPath, const char * pcpassword, int32_t szpassword);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_Add(TElAppleCertStorageHandle _Handle, TElX509CertificateHandle Certificate, int8_t CopyPrivateKey);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_Add_1(TElAppleCertStorageHandle _Handle, TElX509CertificateHandle Certificate, int8_t CopyPrivateKey, int8_t SetTrusted);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_Add_2(TElAppleCertStorageHandle _Handle, TElX509CertificateHandle Certificate, const char * pckeychainPath, int32_t szkeychainPath, int8_t CopyPrivateKey, int8_t setTrusted);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_Add_3(TElAppleCertStorageHandle _Handle, TElX509CertificateHandle Certificate, int8_t BindToExistingPrivateKey, const char * pckeychainPath, int32_t szkeychainPath, int8_t setTrusted);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_ClearAll(TElAppleCertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_Remove(TElAppleCertStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_Refresh(TElAppleCertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_PreloadCertificates(TElAppleCertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_EvaluateTrust(TElAppleCertStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_ExportWithPrivateKey(TElAppleCertStorageHandle _Handle, int32_t Index, const char * pcpassword, int32_t szpassword, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_OpenKeychainByIndex(TElAppleCertStorageHandle _Handle, int32_t index);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_get_Count(TElAppleCertStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_get_Certificates(TElAppleCertStorageHandle _Handle, int32_t Index, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_get_Keychains(TElAppleCertStorageHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_set_Keychains(TElAppleCertStorageHandle _Handle, TStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_get_ReadOnly(TElAppleCertStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_set_ReadOnly(TElAppleCertStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_get_CryptoProvider(TElAppleCertStorageHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_set_CryptoProvider(TElAppleCertStorageHandle _Handle, TElCustomCryptoProviderHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_get_LastPassword(TElAppleCertStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_set_LastPassword(TElAppleCertStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_get_OnEvaluationResult(TElAppleCertStorageHandle _Handle, TElEvaluationResultEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_set_OnEvaluationResult(TElAppleCertStorageHandle _Handle, TElEvaluationResultEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElAppleCertStorage_Create(TComponentHandle Owner, TElAppleCertStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELAPPLECERTSTORAGE */
#endif

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef MACOS
extern zend_class_entry *TElAppleCertStorage_ce_ptr;

void SB_CALLBACK TElEvaluationResultEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcres, int32_t szres, const SB_SecTrustResultTypeRaw resType);
void Register_TElAppleCertStorage(TSRMLS_D);
void Register_SBAppleCertStorage_Aliases(TSRMLS_D);
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBAPPLECERTSTORAGE */
