#ifndef __INC_SBAPPLECOMMON
#define __INC_SBAPPLECOMMON

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#ifdef MACOS
#include "sbtypes.h"
#include "sbconstants.h"
#include "sbutils.h"
#include "sbstrutils.h"
#endif

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef MACOS
#define SB_kAuthorizationEmptyEnvironment 	NULL

typedef PChar SB_MarshaledString;

typedef Pointer SB_CFTypeRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} __SB_CFError, * SB_CFErrorRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} __SB_CFNull, * SB_CFNullRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} __SB_CFArray, * SB_CFArrayRef, * SB_CFMutableArrayRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} __SB_CFDictionary, * SB_CFDictionaryRef, * SB_CFMutableDictionaryRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} __SB_CFBoolean, * SB_CFBooleanRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} __SB_CFAllocator, * SB_CFAllocatorRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} __SB_CFString, * SB_CFStringRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} __SB_CFData, * SB_CFDataRef, * SB_CFMutableDataRef;

#pragma pack(8)
typedef struct 
{
	int32_t location;
	int32_t length;
} SB_CFRange;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} __SB_CFNumberRef, * SB_CFNumberRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} __SB_CFSetRef, * SB_CFSetRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} __SB_CFRunLoopRef, * SB_CFRunLoopRef;

typedef uint8_t SB_CFComparisionResultRaw;

typedef enum
{
	SB_SB_kCFCompareLessThan = -1,
	SB_SB_kCFCompareEqualTo = 0,
	SB_SB_kCFCompareGreaterThan = 1
} SB_CFComparisionResult;

typedef uint16_t SB_CFStringCompareFlagsRaw;

typedef enum
{
	SB_SB_kCFCompareCaseInsensitive = 1,
	SB_SB_kCFCompareBackwards = 4,
	SB_SB_kCFCompareAnchored = 8,
	SB_SB_kCFCompareNonliteral = 16,
	SB_SB_kCFCompareLocalized = 32,
	SB_SB_kCFCompareNumerically = 64,
	SB_SB_kCFCompareDiacriticInsensitive = 128,
	SB_SB_kCFCompareWidthInsensitive = 256,
	SB_SB_kCFCompareForcedOrdering = 512
} SB_CFStringCompareFlags;

typedef uint32_t SB_CFStringEncodingRaw;

typedef enum
{
	SB_SB_kCFStringEncodingMacRoman = 0,
	SB_SB_kCFStringEncodingWindowsLatin1 = 1280,
	SB_SB_kCFStringEncodingUTF16 = 256,
	SB_SB_kCFStringEncodingUnicode = 256,
	SB_SB_kCFStringEncodingISOLatin1 = 513,
	SB_SB_kCFStringEncodingNextStepLatin = 2817,
	SB_SB_kCFStringEncodingASCII = 1536,
	SB_SB_kCFStringEncodingUTF8 = 134217984,
	SB_SB_kCFStringEncodingNonLossyASCII = 3071,
	SB_SB_kCFStringEncodingUTF16BE = 268435712,
	SB_SB_kCFStringEncodingUTF32 = 201326848,
	SB_SB_kCFStringEncodingUTF16LE = 335544576,
	SB_SB_kCFStringEncodingUTF32BE = 402653440,
	SB_SB_kCFStringEncodingUTF32LE = 469762304
} SB_CFStringEncoding;

typedef void (SB_CALLBACK *SB_CFDictionaryRetainCallBack)(SB_CFAllocatorRef allocator, void * value, void * (* OutResult));

typedef void (SB_CALLBACK *SB_CFDictionaryReleaseCallBack)(SB_CFAllocatorRef allocator, void * value);

typedef void (SB_CALLBACK *SB_CFDictionaryCopyDescriptionCallBack)(void * value, SB_CFStringRef (* OutResult));

typedef void (SB_CALLBACK *SB_CFDictionaryEqualCallBack)(void * value1, void * value2, int8_t * OutResult);

typedef void (SB_CALLBACK *SB_CFDictionaryHashCallBack)(void * value, uint32_t * OutResult);

#pragma pack(8)
typedef struct 
{
	int32_t version;
	void * retain;
	void * release;
	void * copyDescription;
	void * equal;
	void * hash;
} SB_CFDictionaryKeyCallBacks, * SB_PCFDictionaryKeyCallBacks;

#pragma pack(8)
typedef struct 
{
	int32_t version;
	void * retain;
	void * release;
	void * copyDescription;
	void * equal;
} SB_CFDictionaryValueCallBacks, * SB_PCFDictionaryValueCallBacks;

typedef void (SB_CALLBACK *SB_CFArrayRetainCallBack)(SB_CFAllocatorRef allocator, void * value, void * (* OutResult));

typedef void (SB_CALLBACK *SB_CFArrayReleaseCallBack)(SB_CFAllocatorRef allocator, void * value);

typedef void (SB_CALLBACK *SB_CFArrayCopyDescriptionCallBack)(void * value, SB_CFStringRef (* OutResult));

typedef void (SB_CALLBACK *SB_CFArrayEqualCallBack)(void * value1, void * value2, int8_t * OutResult);

#pragma pack(8)
typedef struct 
{
	int32_t version;
	void * retain;
	void * release;
	void * copyDescription;
	void * equal;
} SB_CFArrayCallBacks, * SB_PCFArrayCallBacks;

typedef uint8_t SB_SecKeychainStatusRaw;

typedef enum
{
	SB_SB_kSecUnlockStateStatus = 1,
	SB_SB_kSecReadPermStatus = 2,
	SB_SB_UnlockReadPermStatus = 3,
	SB_SB_kSecWritePermStatus = 4,
	SB_SB_UnlockWritePermStatus = 5,
	SB_SB_ReadWritePermStatus = 6,
	SB_SB_UnlockReadWritePermStatus = 7
} SB_SecKeychainStatus;

typedef SB_SecKeychainStatusRaw * SB_PSecKeychainStatus;

typedef uint8_t SB_SecExternalFormatRaw;

typedef enum
{
	SB_SB_kSecFormatUnknown = 0,
	SB_SB_kSecFormatOpenSSL = 1,
	SB_SB_kSecFormatSSH = 2,
	SB_SB_kSecFormatBSAFE = 3,
	SB_SB_kSecFormatRawKey = 4,
	SB_SB_kSecFormatWrappedPKCS8 = 5,
	SB_SB_kSecFormatWrappedOpenSSL = 6,
	SB_SB_kSecFormatWrappedSSH = 7,
	SB_SB_kSecFormatWrappedLSH = 8,
	SB_SB_kSecFormatX509Cert = 9,
	SB_SB_kSecFormatPEMSequence = 10,
	SB_SB_kSecFormatPKCS7 = 11,
	SB_SB_kSecFormatPKCS12 = 12,
	SB_SB_kSecFormatNetscapeCertSequence = 13,
	SB_SB_kSecFormatSSHv2 = 14
} SB_SecExternalFormat;

typedef SB_SecExternalFormatRaw * SB_PSecExternalFormat;

typedef uint8_t SB_SecExternalItemTypeRaw;

typedef enum
{
	SB_SB_kSecItemTypeUnknown = 0,
	SB_SB_kSecItemTypePrivateKey = 1,
	SB_SB_kSecItemTypePublicKey = 2,
	SB_SB_kSecItemTypeSessionKey = 3,
	SB_SB_kSecItemTypeCertificate = 4,
	SB_SB_kSecItemTypeAggregate = 5
} SB_SecExternalItemType;

typedef SB_SecExternalItemTypeRaw * SB_PSecExternalItemType;

typedef uint8_t SB_SecItemImportExportFlagsRaw;

typedef enum
{
	SB_SB_kSecItemPemArmour = 1
} SB_SecItemImportExportFlags;

typedef uint8_t SB_SecKeyImportExportFlagsRaw;

typedef enum
{
	SB_SB_kSecKeyImportOnlyOne = 1,
	SB_SB_kSecKeySecurePassphrase = 2,
	SB_SB_kSecKeyNoAccessControl = 4
} SB_SecKeyImportExportFlags;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} SB_OpaqueSecKeychainRef, * SB_SecKeychainRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} SB_OpaqueSecAccessRef, * SB_SecAccessRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} SB_OpaqueSecKeychainItemRef, * SB_SecKeychainItemRef;

#pragma pack(8)
typedef struct 
{
	uint32_t version;
	uint32_t flags;
	void * passphrase;
	SB_CFStringRef alertTitle;
	SB_CFStringRef alertPrompt;
	SB_SecAccessRef accessRef;
	SB_CFArrayRef keyUsage;
	SB_CFArrayRef keyAttrs;
} SB_SecItemImportExportKeyParameters, * SB_PSecItemImportExportKeyParameters;

typedef uint32_t SB_SecItemClassRaw;

typedef enum
{
	SB_SB_kSecCertificateItemClass = -2147479552,
	SB_SB_kSecPublicKeyItemClass = 15,
	SB_SB_kSecPrivateKeyItemClass = 16,
	SB_SB_kSecSymmetricKeyItemClass = 17,
	SB_SB_kSecInternetPasswordItemClass = 1768842612,
	SB_SB_kSecGenericPasswordItemClass = 1734700656
} SB_SecItemClass;

typedef uint32_t SB_SecItemAttrRaw;

typedef enum
{
	SB_SB_kSecAccountItemAttr = 1633903476,
	SB_SB_kSecCreationDateItemAttr = 1667522932,
	SB_SB_kSecAlias = 1634494835,
	SB_SB_kSecAddressItemAttr = 1633969266,
	SB_SB_kSecAuthenticationTypeItemAttr = 1635023216,
	SB_SB_kSecModDateItemAttr = 1835295092,
	SB_SB_kSecCrlEncoding = 1668443747,
	SB_SB_kSecCrlType = 1668445296,
	SB_SB_kSecCertificateEncoding = 1667591779,
	SB_SB_kSecCertificateType = 1668577648,
	SB_SB_kSecGenericItemAttr = 1734700641,
	SB_SB_kSecCustomIconItemAttr = 1668641641,
	SB_SB_kSecInvisibleItemAttr = 1768846953,
	SB_SB_kSecLabelItemAttr = 1818321516,
	SB_SB_kSecCreatorItemAttr = 1668445298,
	SB_SB_kSecCommentItemAttr = 1768123764,
	SB_SB_kSecDescriptionItemAttr = 1684370275,
	SB_SB_kSecTypeItemAttr = 1954115685,
	SB_SB_kSecProtocolItemAttr = 1886675820,
	SB_SB_kSecSignatureItemAttr = 1936943463,
	SB_SB_kSecPathItemAttr = 1885434984,
	SB_SB_kSecPortItemAttr = 1886351988,
	SB_SB_kSecServerItemAttr = 1936881266,
	SB_SB_kSecSecurityDomainItemAttr = 1935961454,
	SB_SB_kSecServiceItemAttr = 1937138533,
	SB_SB_kSecNegativeItemAttr = 1852139361,
	SB_SB_kSecScriptCodeItemAttr = 1935897200,
	SB_SB_kSecVolumeItemAttr = 1986817381
} SB_SecItemAttr;

#pragma pack(8)
typedef struct 
{
	SB_SecItemAttrRaw tag;
	uint32_t length;
	void * data;
} SB_SecKeychainAttribute, * SB_PSecKeychainAttribute;

#pragma pack(8)
typedef struct 
{
	uint32_t count;
#ifdef CPU64
	int32_t _dummy0;
#endif
	SB_SecKeychainAttribute * (* attrs);
} SB_SecKeychainAttributeList, * SB_PSecKeychainAttributeList;

typedef uint32_t SB_AuthorizationFlagsRaw;

typedef enum
{
	SB_SB_kAuthorizationFlagDefaults = 0,
	SB_SB_kAuthorizationFlagInteractionAllowed = 1,
	SB_SB_kAuthorizationFlagExtendRights = 2,
	SB_SB_kAuthorizationFlagPartialRights = 4,
	SB_SB_kAuthorizationFlagDestroyRights = 8,
	SB_SB_kAuthorizationFlagPreAuthorize = 16,
	SB_SB_kAuthorizationFlagNoData = 1048576
} SB_AuthorizationFlags;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} SB_AuthorizationOpaqueRef, * SB_AuthorizationRef;

#pragma pack(8)
typedef struct 
{
	char * name;
	uint32_t valueLength;
#ifdef CPU64
	int32_t _dummy0;
#endif
	void * value;
	uint32_t flags;
} SB_AuthorizationItem, * SB_PAuthorizationItem;

#pragma pack(8)
typedef struct 
{
	uint32_t count;
#ifdef CPU64
	int32_t _dummy0;
#endif
	SB_AuthorizationItem * (* items);
} SB_AuthorizationItemSet, * SB_PAuthorizationItemSet;

typedef uint8_t SB_SecTrustSettingsDomainRaw;

typedef enum
{
	SB_SB_kSecTrustSettingsDomainUser = 0,
	SB_SB_kSecTrustSettingsDomainAdmin = 1,
	SB_SB_kSecTrustSettingsDomainSystem = 2
} SB_SecTrustSettingsDomain;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} __SB_SecTrust, * SB_SecTrustRef;

typedef uint8_t SB_SecTrustResultTypeRaw;

typedef enum
{
	SB_SB_kSecTrustResultInvalid = 0,
	SB_SB_kSecTrustResultProceed = 1,
	SB_SB_kSecTrustResultDeny = 3,
	SB_SB_kSecTrustResultUnspecified = 4,
	SB_SB_kSecTrustResultRecoverableTrustFailure = 5,
	SB_SB_kSecTrustResultFatalTrustFailure = 6,
	SB_SB_kSecTrustResultOtherError = 7
} SB_SecTrustResultType;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} SB_OpaqueSecCertificateRef, * SB_SecCertificateRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} SB_OpaqueSecIdentityRef, * SB_SecIdentityRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} SB_OpaqueSecKeyRef, * SB_SecKeyRef;

#pragma pack(8)
typedef struct 
{
	int8_t _dummy0;
} SB_OpaqueSecPolicyRef, * SB_SecPolicyRef;
#endif

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef MACOS
extern zend_class_entry *__SB_CFError_ce_ptr;
extern zend_class_entry *__SB_CFNull_ce_ptr;
extern zend_class_entry *__SB_CFArray_ce_ptr;
extern zend_class_entry *__SB_CFDictionary_ce_ptr;
extern zend_class_entry *__SB_CFBoolean_ce_ptr;
extern zend_class_entry *__SB_CFAllocator_ce_ptr;
extern zend_class_entry *__SB_CFString_ce_ptr;
extern zend_class_entry *__SB_CFData_ce_ptr;
extern zend_class_entry *SB_CFRange_ce_ptr;
extern zend_class_entry *__SB_CFNumberRef_ce_ptr;
extern zend_class_entry *__SB_CFSetRef_ce_ptr;
extern zend_class_entry *__SB_CFRunLoopRef_ce_ptr;
extern zend_class_entry *SB_CFDictionaryKeyCallBacks_ce_ptr;
extern zend_class_entry *SB_CFDictionaryValueCallBacks_ce_ptr;
extern zend_class_entry *SB_CFArrayCallBacks_ce_ptr;
extern zend_class_entry *SB_OpaqueSecKeychainRef_ce_ptr;
extern zend_class_entry *SB_OpaqueSecAccessRef_ce_ptr;
extern zend_class_entry *SB_OpaqueSecKeychainItemRef_ce_ptr;
extern zend_class_entry *SB_SecItemImportExportKeyParameters_ce_ptr;
extern zend_class_entry *SB_SecKeychainAttribute_ce_ptr;
extern zend_class_entry *SB_SecKeychainAttributeList_ce_ptr;
extern zend_class_entry *SB_AuthorizationOpaqueRef_ce_ptr;
extern zend_class_entry *SB_AuthorizationItem_ce_ptr;
extern zend_class_entry *SB_AuthorizationItemSet_ce_ptr;
extern zend_class_entry *__SB_SecTrust_ce_ptr;
extern zend_class_entry *SB_OpaqueSecCertificateRef_ce_ptr;
extern zend_class_entry *SB_OpaqueSecIdentityRef_ce_ptr;
extern zend_class_entry *SB_OpaqueSecKeyRef_ce_ptr;
extern zend_class_entry *SB_OpaqueSecPolicyRef_ce_ptr;

void Register___SB_CFError(TSRMLS_D);
void Register___SB_CFNull(TSRMLS_D);
void Register___SB_CFArray(TSRMLS_D);
void Register___SB_CFDictionary(TSRMLS_D);
void Register___SB_CFBoolean(TSRMLS_D);
void Register___SB_CFAllocator(TSRMLS_D);
void Register___SB_CFString(TSRMLS_D);
void Register___SB_CFData(TSRMLS_D);
void Register_SB_CFRange(TSRMLS_D);
void Register___SB_CFNumberRef(TSRMLS_D);
void Register___SB_CFSetRef(TSRMLS_D);
void Register___SB_CFRunLoopRef(TSRMLS_D);
void Register_SB_CFDictionaryKeyCallBacks(TSRMLS_D);
void Register_SB_CFDictionaryValueCallBacks(TSRMLS_D);
void Register_SB_CFArrayCallBacks(TSRMLS_D);
void Register_SB_OpaqueSecKeychainRef(TSRMLS_D);
void Register_SB_OpaqueSecAccessRef(TSRMLS_D);
void Register_SB_OpaqueSecKeychainItemRef(TSRMLS_D);
void Register_SB_SecItemImportExportKeyParameters(TSRMLS_D);
void Register_SB_SecKeychainAttribute(TSRMLS_D);
void Register_SB_SecKeychainAttributeList(TSRMLS_D);
void Register_SB_AuthorizationOpaqueRef(TSRMLS_D);
void Register_SB_AuthorizationItem(TSRMLS_D);
void Register_SB_AuthorizationItemSet(TSRMLS_D);
void Register___SB_SecTrust(TSRMLS_D);
void Register_SB_OpaqueSecCertificateRef(TSRMLS_D);
void Register_SB_OpaqueSecIdentityRef(TSRMLS_D);
void Register_SB_OpaqueSecKeyRef(TSRMLS_D);
void Register_SB_OpaqueSecPolicyRef(TSRMLS_D);
void Register_SBAppleCommon_Constants(int module_number TSRMLS_DC);
void Register_SBAppleCommon_Enum_Flags(TSRMLS_D);
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBAPPLECOMMON */
