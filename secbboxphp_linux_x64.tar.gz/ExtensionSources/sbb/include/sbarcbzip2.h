#ifndef __INC_SBARCBZIP2
#define __INC_SBARCBZIP2

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbcustomfsadapter.h"
#include "sbdiskfsadapter.h"
#include "sbstrutils.h"
#include "sbarcbase.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_BZIP2_BUFFER_SIZE 	65536
#define SB_BZIP_EVENT_EXTRACTION_FAILED 	4097
#define SB_BZIP_EVENT_FILE_ALREADY_EXISTS 	4098
#define SB_BZIP_EVENT_CANNOT_CREATE_FILE 	4099
#define SB_BZIP_EVENT_DIR_ALREADY_EXISTS 	4100
#define SB_BZIP_EVENT_FILE_ALREADY_ADDED 	4101
#define SB_BZIP_EVENT_CRC_MISMATCH 	4102
#define SB_BZIP_ACTION_IGNORE 	4097
#define SB_BZIP_ACTION_ABORT 	4098
#define SB_BZIP_ACTION_RETRY 	4099
#define SB_BZIP_ACTION_SKIP 	4100
#define SB_SFileAlreadyExists 	"File already exists"
#define SB_SInvalidPath 	"Invalid path"
#define SB_SNotExtractNewArchive 	"Can\'t extract from new archive"
#define SB_SCannotCreateFile 	"Cannot create file"
#define SB_SInvalidActionRequested 	"Invalid action requested"
#define SB_SInvalidOutputFile 	"Not correctly set output file"
#define SB_SNoOutputStream 	"No output stream"
#define SB_SInvalidCompressionLevel 	"Invalid compression level"
#define SB_SInvalidWorkFactor 	"Invalid work factor"
#define SB_SArchiveAlreadyHaveFile 	"Archive already contain a file"
#define SB_SNoInputForCompression 	"No input for compression"
#define SB_SArchiveNotOpened 	"Archive is not opened"
#define SB_SArchiveNotAssign 	"For the new archive must be specified file or stream"

typedef TElClassHandle TElBZip2DecompressingUnitHandle;

typedef TElBZip2DecompressingUnitHandle ElBZip2DecompressingUnitHandle;

typedef TElClassHandle TElBZip2CompressingUnitHandle;

typedef TElBZip2CompressingUnitHandle ElBZip2CompressingUnitHandle;

typedef TElClassHandle TElBZip2ReaderHandle;

typedef TElBZip2ReaderHandle ElBZip2ReaderHandle;

typedef TElClassHandle TElBZip2WriterHandle;

typedef TElBZip2WriterHandle ElBZip2WriterHandle;

typedef void (SB_CALLBACK *TSBBzip2ProgressEvent)(void * _ObjectData, TObjectHandle Sender, uint64_t Processed, uint64_t Total, int8_t * Cancel);

typedef void (SB_CALLBACK *TSBBzip2UserActionNeededEvent)(void * _ObjectData, TObjectHandle Sender, int32_t ForEvent, const char * pcDescription, int32_t szDescription, int32_t * UserAction);

typedef void (SB_CALLBACK *TSBBZip2ExtractionStreamNeededEvent)(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream);

typedef void (SB_CALLBACK *TSBBZip2CompressionStreamNeededEvent)(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream);

typedef void (SB_CALLBACK *TSBBZip2ArchiveErrorEvent)(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode, const char * pcErrorMessage, int32_t szErrorMessage, int8_t * TryContinue);

#ifdef SB_USE_CLASS_TELBZIP2DECOMPRESSINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElBZip2DecompressingUnit_InitializeProcessing(TElBZip2DecompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2DecompressingUnit_ProcessBlock(TElBZip2DecompressingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2DecompressingUnit_FinalizeProcessing(TElBZip2DecompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2DecompressingUnit_get_Verbosity(TElBZip2DecompressingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2DecompressingUnit_set_Verbosity(TElBZip2DecompressingUnitHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2DecompressingUnit_get_Small(TElBZip2DecompressingUnitHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2DecompressingUnit_set_Small(TElBZip2DecompressingUnitHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2DecompressingUnit_Create(TElBZip2DecompressingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELBZIP2DECOMPRESSINGUNIT */

#ifdef SB_USE_CLASS_TELBZIP2COMPRESSINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElBZip2CompressingUnit_InitializeProcessing(TElBZip2CompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2CompressingUnit_ProcessBlock(TElBZip2CompressingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2CompressingUnit_FinalizeProcessing(TElBZip2CompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2CompressingUnit_get_CompressionLevel(TElBZip2CompressingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2CompressingUnit_set_CompressionLevel(TElBZip2CompressingUnitHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2CompressingUnit_get_Verbosity(TElBZip2CompressingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2CompressingUnit_set_Verbosity(TElBZip2CompressingUnitHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2CompressingUnit_get_WorkFactor(TElBZip2CompressingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2CompressingUnit_set_WorkFactor(TElBZip2CompressingUnitHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2CompressingUnit_Create(TElBZip2CompressingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELBZIP2COMPRESSINGUNIT */

#ifdef SB_USE_CLASS_TELBZIP2READER
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_Open(TElBZip2ReaderHandle _Handle, const char * pcFileName, int32_t szFileName, int8_t ReadOnly);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_Open_1(TElBZip2ReaderHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_Close(TElBZip2ReaderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_Extract(TElBZip2ReaderHandle _Handle, const char * pcOutputFile, int32_t szOutputFile);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_Extract_1(TElBZip2ReaderHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_get_CompressedSize(TElBZip2ReaderHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_get_Small(TElBZip2ReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_set_Small(TElBZip2ReaderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_get_IgnoreArchiveErrors(TElBZip2ReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_set_IgnoreArchiveErrors(TElBZip2ReaderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_get_FileSystemAdapter(TElBZip2ReaderHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_set_FileSystemAdapter(TElBZip2ReaderHandle _Handle, TElCustomFileSystemAdapterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_get_OnExtractionStreamNeeded(TElBZip2ReaderHandle _Handle, TSBBZip2ExtractionStreamNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_set_OnExtractionStreamNeeded(TElBZip2ReaderHandle _Handle, TSBBZip2ExtractionStreamNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_get_OnProgress(TElBZip2ReaderHandle _Handle, TSBBzip2ProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_set_OnProgress(TElBZip2ReaderHandle _Handle, TSBBzip2ProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_get_OnUserActionNeeded(TElBZip2ReaderHandle _Handle, TSBBzip2UserActionNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_set_OnUserActionNeeded(TElBZip2ReaderHandle _Handle, TSBBzip2UserActionNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_get_OnArchiveError(TElBZip2ReaderHandle _Handle, TSBBZip2ArchiveErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_set_OnArchiveError(TElBZip2ReaderHandle _Handle, TSBBZip2ArchiveErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Reader_Create(TComponentHandle AOwner, TElBZip2ReaderHandle * OutResult);
#endif /* SB_USE_CLASS_TELBZIP2READER */

#ifdef SB_USE_CLASS_TELBZIP2WRITER
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_CreateArchive(TElBZip2WriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_Open(TElBZip2WriterHandle _Handle, const char * pcFileName, int32_t szFileName, int8_t ReadOnly);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_Open_1(TElBZip2WriterHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_Add(TElBZip2WriterHandle _Handle, const char * pcFileName, int32_t szFileName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_Add_1(TElBZip2WriterHandle _Handle, TStreamHandle Stream, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_Compress(TElBZip2WriterHandle _Handle, TStreamHandle Destination);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_Compress_1(TElBZip2WriterHandle _Handle, const char * pcDestination, int32_t szDestination);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_Compress_2(TElBZip2WriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_Close(TElBZip2WriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_get_NewArchive(TElBZip2WriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_get_FileSize(TElBZip2WriterHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_get_CompressionLevel(TElBZip2WriterHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_set_CompressionLevel(TElBZip2WriterHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_get_WorkFactor(TElBZip2WriterHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_set_WorkFactor(TElBZip2WriterHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_get_OnCompressionStreamNeeded(TElBZip2WriterHandle _Handle, TSBBZip2CompressionStreamNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_set_OnCompressionStreamNeeded(TElBZip2WriterHandle _Handle, TSBBZip2CompressionStreamNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElBZip2Writer_Create(TComponentHandle AOwner, TElBZip2WriterHandle * OutResult);
#endif /* SB_USE_CLASS_TELBZIP2WRITER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElBZip2DecompressingUnit_ce_ptr;
extern zend_class_entry *TElBZip2CompressingUnit_ce_ptr;
extern zend_class_entry *TElBZip2Reader_ce_ptr;
extern zend_class_entry *TElBZip2Writer_ce_ptr;

void SB_CALLBACK TSBBzip2ProgressEventRaw(void * _ObjectData, TObjectHandle Sender, uint64_t Processed, uint64_t Total, int8_t * Cancel);
void SB_CALLBACK TSBBzip2UserActionNeededEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ForEvent, const char * pcDescription, int32_t szDescription, int32_t * UserAction);
void SB_CALLBACK TSBBZip2ExtractionStreamNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream);
void SB_CALLBACK TSBBZip2CompressionStreamNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream);
void SB_CALLBACK TSBBZip2ArchiveErrorEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode, const char * pcErrorMessage, int32_t szErrorMessage, int8_t * TryContinue);
void Register_TElBZip2DecompressingUnit(TSRMLS_D);
void Register_TElBZip2CompressingUnit(TSRMLS_D);
void Register_TElBZip2Reader(TSRMLS_D);
void Register_TElBZip2Writer(TSRMLS_D);
void Register_SBArcBZip2_Constants(int module_number TSRMLS_DC);
void Register_SBArcBZip2_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBARCBZIP2 */

