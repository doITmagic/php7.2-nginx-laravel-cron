#ifndef __INC_SBARCGZIP
#define __INC_SBARCGZIP

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbchsconv.h"
#include "sbchsconvcharsets.h"
#include "sbchscjk.h"
#include "sbcustomfsadapter.h"
#include "sbdiskfsadapter.h"
#include "sbstrutils.h"
#include "sbcrc.h"
#include "sbarcbase.h"
#include "sbziputils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_GZIP_BUFFER_SIZE 	65536
#define SB_GZIP_EVENT_EXTRACTION_FAILED 	4097
#define SB_GZIP_EVENT_FILE_ALREADY_EXISTS 	4098
#define SB_GZIP_EVENT_CANNOT_CREATE_FILE 	4099
#define SB_GZIP_EVENT_DIR_ALREADY_EXISTS 	4100
#define SB_GZIP_EVENT_FILE_ALREADY_ADDED 	4101
#define SB_GZIP_EVENT_CRC_MISMATCH 	4102
#define SB_GZIP_ACTION_IGNORE 	4097
#define SB_GZIP_ACTION_ABORT 	4098
#define SB_GZIP_ACTION_RETRY 	4099
#define SB_GZIP_ACTION_SKIP 	4100
#define SB_SErrorCorrupted 	"Corrupted data"
#define SB_SInvalidPath 	"Invalid path"
#ifndef SB_SInvalidHeader
#define SB_SInvalidHeader 	"Invalid gzip header"
#endif
#define SB_SFileAlreadyExists 	"File already exists"
#define SB_SCannotCreateFile 	"Cannot create file"
#define SB_SCRCMismatch 	"CRC mismatch"
#define SB_SNotExtractNewArchive 	"Can\'t extract from new archive"
#define SB_SInvalidActionRequested 	"Invalid action requested"
#define SB_SInvalidOutputFile 	"Not correctly set output file"
#define SB_SNoOutputStream 	"No output stream"
#define SB_SInvalidCompressionLevel 	"Invalid compression level"
#define SB_SInvalidWorkFactor 	"Invalid work factor"
#define SB_SArchiveAlreadyHaveFile 	"Archive already contain a file"
#define SB_SNoInputForCompression 	"No input for compression"
#define SB_SArchiveNotOpened 	"Archive is not opened"
#define SB_SArchiveNotAssign 	"For the new archive must be specified file or stream"

typedef TElClassHandle TElGZipDecompressingUnitHandle;

typedef TElGZipDecompressingUnitHandle ElGZipDecompressingUnitHandle;

typedef TElClassHandle TElGZipCompressingUnitHandle;

typedef TElGZipCompressingUnitHandle ElGZipCompressingUnitHandle;

typedef TElClassHandle TElGZipFileAttributesHandle;

typedef TElClassHandle TElGZipReaderHandle;

typedef TElGZipReaderHandle ElGZipReaderHandle;

typedef TElClassHandle TElGZipWriterHandle;

typedef TElGZipWriterHandle ElGZipWriterHandle;

typedef void (SB_CALLBACK *TSBGZipProgressEvent)(void * _ObjectData, TObjectHandle Sender, uint64_t Processed, uint64_t Total, int8_t * Cancel);

typedef void (SB_CALLBACK *TSBGZipUserActionNeededEvent)(void * _ObjectData, TObjectHandle Sender, int32_t ForEvent, const char * pcDescription, int32_t szDescription, int32_t * UserAction);

typedef void (SB_CALLBACK *TSBGZipExtractionStreamNeededEvent)(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream);

typedef void (SB_CALLBACK *TSBGZipCompressionStreamNeededEvent)(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream);

typedef void (SB_CALLBACK *TSBGZipArchiveErrorEvent)(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode, const char * pcErrorMessage, int32_t szErrorMessage, int8_t * TryContinue);

typedef uint8_t TSBGZipFileSystemRaw;

typedef enum
{
	fsFAT = 0,
	fsAmiga = 1,
	fsVMS = 2,
	fsUnix = 3,
	fmVMCMS = 4,
	fsAtariTOS = 5,
	fsHPFS = 6,
	fsMacintosh = 7,
	fdZSystem = 8,
	fsCPM = 9,
	fsTOPS20 = 10,
	fsNTFS = 11,
	fsQDOS = 12,
	fsAcornRISCOS = 13,
	fsUnknown = 14
} TSBGZipFileSystem;

#ifdef SB_USE_CLASS_TELGZIPDECOMPRESSINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElGZipDecompressingUnit_InitializeProcessing(TElGZipDecompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGZipDecompressingUnit_ProcessBlock(TElGZipDecompressingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElGZipDecompressingUnit_FinalizeProcessing(TElGZipDecompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGZipDecompressingUnit_get_CRC32(TElGZipDecompressingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipDecompressingUnit_Create(TElGZipDecompressingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELGZIPDECOMPRESSINGUNIT */

#ifdef SB_USE_CLASS_TELGZIPCOMPRESSINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElGZipCompressingUnit_InitializeProcessing(TElGZipCompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGZipCompressingUnit_ProcessBlock(TElGZipCompressingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElGZipCompressingUnit_FinalizeProcessing(TElGZipCompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGZipCompressingUnit_get_CompressionLevel(TElGZipCompressingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipCompressingUnit_set_CompressionLevel(TElGZipCompressingUnitHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipCompressingUnit_get_CRC32(TElGZipCompressingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipCompressingUnit_Create(TElGZipCompressingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELGZIPCOMPRESSINGUNIT */

#ifdef SB_USE_CLASS_TELGZIPFILEATTRIBUTES
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_Assign(TElGZipFileAttributesHandle _Handle, TElGZipFileAttributesHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_AssignTo(TElGZipFileAttributesHandle _Handle, TElGZipFileAttributesHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_FileName(TElGZipFileAttributesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_FileName(TElGZipFileAttributesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_ModifyTime(TElGZipFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_ModifyTime(TElGZipFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_FileSize(TElGZipFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_FileSize(TElGZipFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_Flag(TElGZipFileAttributesHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_Flag(TElGZipFileAttributesHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_ExtraFlag(TElGZipFileAttributesHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_ExtraFlag(TElGZipFileAttributesHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_CRC16(TElGZipFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_CRC16(TElGZipFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_CRC32(TElGZipFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_CRC32(TElGZipFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_ExtraField(TElGZipFileAttributesHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_ExtraField(TElGZipFileAttributesHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_Comment(TElGZipFileAttributesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_Comment(TElGZipFileAttributesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_FileSystem(TElGZipFileAttributesHandle _Handle, TSBGZipFileSystemRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_FileSystem(TElGZipFileAttributesHandle _Handle, TSBGZipFileSystemRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_FileSystemCode(TElGZipFileAttributesHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_FileSystemCode(TElGZipFileAttributesHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_HasText(TElGZipFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_HasText(TElGZipFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_HasCRC(TElGZipFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_HasCRC(TElGZipFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_HasExtra(TElGZipFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_HasExtra(TElGZipFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_HasName(TElGZipFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_HasName(TElGZipFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_get_HasComment(TElGZipFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_set_HasComment(TElGZipFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipFileAttributes_Create(TElGZipFileAttributesHandle * OutResult);
#endif /* SB_USE_CLASS_TELGZIPFILEATTRIBUTES */

#ifdef SB_USE_CLASS_TELGZIPREADER
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_Open(TElGZipReaderHandle _Handle, const char * pcFileName, int32_t szFileName, int8_t ReadOnly);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_Open_1(TElGZipReaderHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_Close(TElGZipReaderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_Extract(TElGZipReaderHandle _Handle, const char * pcOutputPath, int32_t szOutputPath, const char * pcOutputFile, int32_t szOutputFile);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_Extract_1(TElGZipReaderHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_CheckArchive(TElGZipReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_get_CompressedSize(TElGZipReaderHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_get_Attributes(TElGZipReaderHandle _Handle, TElGZipFileAttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_get_IgnoreArchiveErrors(TElGZipReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_set_IgnoreArchiveErrors(TElGZipReaderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_get_FilenamesCharset(TElGZipReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_set_FilenamesCharset(TElGZipReaderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_get_FileSystemAdapter(TElGZipReaderHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_set_FileSystemAdapter(TElGZipReaderHandle _Handle, TElCustomFileSystemAdapterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_get_OnExtractionStreamNeeded(TElGZipReaderHandle _Handle, TSBGZipExtractionStreamNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_set_OnExtractionStreamNeeded(TElGZipReaderHandle _Handle, TSBGZipExtractionStreamNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_get_OnProgress(TElGZipReaderHandle _Handle, TSBGZipProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_set_OnProgress(TElGZipReaderHandle _Handle, TSBGZipProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_get_OnUserActionNeeded(TElGZipReaderHandle _Handle, TSBGZipUserActionNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_set_OnUserActionNeeded(TElGZipReaderHandle _Handle, TSBGZipUserActionNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_get_OnArchiveError(TElGZipReaderHandle _Handle, TSBGZipArchiveErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_set_OnArchiveError(TElGZipReaderHandle _Handle, TSBGZipArchiveErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElGZipReader_Create(TComponentHandle AOwner, TElGZipReaderHandle * OutResult);
#endif /* SB_USE_CLASS_TELGZIPREADER */

#ifdef SB_USE_CLASS_TELGZIPWRITER
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_CreateArchive(TElGZipWriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_Open(TElGZipWriterHandle _Handle, const char * pcFileName, int32_t szFileName, int8_t ReadOnly);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_Open_1(TElGZipWriterHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_Add(TElGZipWriterHandle _Handle, const char * pcFileName, int32_t szFileName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_Add_1(TElGZipWriterHandle _Handle, TStreamHandle Stream, const char * pcFileName, int32_t szFileName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_Compress(TElGZipWriterHandle _Handle, TStreamHandle Destination);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_Compress_1(TElGZipWriterHandle _Handle, const char * pcDestination, int32_t szDestination);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_Compress_2(TElGZipWriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_Close(TElGZipWriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_get_NewArchive(TElGZipWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_get_FileSize(TElGZipWriterHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_get_CompressionLevel(TElGZipWriterHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_set_CompressionLevel(TElGZipWriterHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_get_WorkFactor(TElGZipWriterHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_set_WorkFactor(TElGZipWriterHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_get_OnCompressionStreamNeeded(TElGZipWriterHandle _Handle, TSBGZipCompressionStreamNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_set_OnCompressionStreamNeeded(TElGZipWriterHandle _Handle, TSBGZipCompressionStreamNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElGZipWriter_Create(TComponentHandle AOwner, TElGZipWriterHandle * OutResult);
#endif /* SB_USE_CLASS_TELGZIPWRITER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElGZipDecompressingUnit_ce_ptr;
extern zend_class_entry *TElGZipCompressingUnit_ce_ptr;
extern zend_class_entry *TElGZipFileAttributes_ce_ptr;
extern zend_class_entry *TElGZipReader_ce_ptr;
extern zend_class_entry *TElGZipWriter_ce_ptr;

void SB_CALLBACK TSBGZipProgressEventRaw(void * _ObjectData, TObjectHandle Sender, uint64_t Processed, uint64_t Total, int8_t * Cancel);
void SB_CALLBACK TSBGZipUserActionNeededEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ForEvent, const char * pcDescription, int32_t szDescription, int32_t * UserAction);
void SB_CALLBACK TSBGZipExtractionStreamNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream);
void SB_CALLBACK TSBGZipCompressionStreamNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream);
void SB_CALLBACK TSBGZipArchiveErrorEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode, const char * pcErrorMessage, int32_t szErrorMessage, int8_t * TryContinue);
void Register_TElGZipDecompressingUnit(TSRMLS_D);
void Register_TElGZipCompressingUnit(TSRMLS_D);
void Register_TElGZipFileAttributes(TSRMLS_D);
void Register_TElGZipReader(TSRMLS_D);
void Register_TElGZipWriter(TSRMLS_D);
void Register_SBArcGZip_Constants(int module_number TSRMLS_DC);
void Register_SBArcGZip_Enum_Flags(TSRMLS_D);
void Register_SBArcGZip_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBARCGZIP */

