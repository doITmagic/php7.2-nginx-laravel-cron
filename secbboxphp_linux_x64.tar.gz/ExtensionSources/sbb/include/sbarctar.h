#ifndef __INC_SBARCTAR
#define __INC_SBARCTAR

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbdictionary.h"
#include "sbchsconv.h"
#include "sbchsconvcharsets.h"
#include "sbchscjk.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbarcbase.h"
#include "sbtarentities.h"
#include "sbcustomfsadapter.h"
#include "sbdiskfsadapter.h"
#include "sbconstants.h"
#include "sbarcgzip.h"
#include "sbziputils.h"
#include "sbarcbzip2.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_TAR_EVENT_EXTRACTION_FAILED 	4097
#define SB_TAR_EVENT_FILE_ALREADY_EXISTS 	4098
#define SB_TAR_EVENT_CANNOT_CREATE_FILE 	4099
#define SB_TAR_EVENT_DIR_ALREADY_EXISTS 	4100
#define SB_TAR_EVENT_FILE_ALREADY_ADDED 	4101
#define SB_TAR_EVENT_CRC_MISMATCH 	4102
#define SB_TAR_ACTION_IGNORE 	4097
#define SB_TAR_ACTION_ABORT 	4098
#define SB_TAR_ACTION_RETRY 	4099
#define SB_TAR_ACTION_SKIP 	4100

typedef TElClassHandle TElTarArchiveDirectoryEntryHandle;

typedef TElClassHandle TElTarFileAttributesHandle;

typedef TElTarArchiveDirectoryEntryHandle ElTarArchiveDirectoryEntryHandle;

typedef TElClassHandle TElTarProcessingUnitHandle;

typedef TElTarProcessingUnitHandle ElTarProcessingUnitHandle;

typedef TElClassHandle TElTarReaderHandle;

typedef TElTarReaderHandle ElTarReaderHandle;

typedef TElClassHandle TElTarWriterHandle;

typedef TElTarWriterHandle ElTarWriterHandle;

typedef void (SB_CALLBACK *TSBTarExtractionFinishedEvent)(void * _ObjectData, TObjectHandle Sender, TElTarArchiveDirectoryEntryHandle Entry);

typedef void (SB_CALLBACK *TSBTarExtractionMakeDirectoryEvent)(void * _ObjectData, TObjectHandle Sender, TElTarArchiveDirectoryEntryHandle Entry);

typedef void (SB_CALLBACK *TSBTarProgressEvent)(void * _ObjectData, TObjectHandle Sender, uint64_t Processed, uint64_t Total, uint64_t OverallProcessed, uint64_t OverallTotal, int8_t * Cancel);

typedef void (SB_CALLBACK *TSBTarExtractionStartEvent)(void * _ObjectData, TObjectHandle Sender, TElTarArchiveDirectoryEntryHandle Entry, int8_t * Extract);

typedef void (SB_CALLBACK *TSBTarUserActionNeededEvent)(void * _ObjectData, TObjectHandle Sender, int32_t ForEvent, const char * pcDescription, int32_t szDescription, void * Param, int32_t * UserAction);

typedef void (SB_CALLBACK *TSBTarExtractionStreamNeededEvent)(void * _ObjectData, TObjectHandle Sender, TElTarArchiveDirectoryEntryHandle Entry, TStreamHandle * Stream);

typedef void (SB_CALLBACK *TSBTarCompressionStartEvent)(void * _ObjectData, TObjectHandle Sender, TElTarArchiveDirectoryEntryHandle Entry, int8_t * Compress);

typedef void (SB_CALLBACK *TSBTarCompressionTarToGZipStartEvent)(void * _ObjectData, TObjectHandle Sender, int8_t * Compress);

typedef void (SB_CALLBACK *TSBTarCompressionTarToBZip2StartEvent)(void * _ObjectData, TObjectHandle Sender, int8_t * Compress);

typedef void (SB_CALLBACK *TSBTarUnCompressionTarFromGZipStartEvent)(void * _ObjectData, TObjectHandle Sender, int8_t * Compress);

typedef void (SB_CALLBACK *TSBTarUnCompressionTarFromBZip2StartEvent)(void * _ObjectData, TObjectHandle Sender, int8_t * Compress);

typedef void (SB_CALLBACK *TSBTarCompressionStreamNeededEvent)(void * _ObjectData, TObjectHandle Sender, TElTarArchiveDirectoryEntryHandle Entry, TStreamHandle * Stream);

typedef void (SB_CALLBACK *TSBTarCompressionFinishedEvent)(void * _ObjectData, TObjectHandle Sender, TElTarArchiveDirectoryEntryHandle Entry);

typedef void (SB_CALLBACK *TSBTarCompressionTarToGZipFinishedEvent)(void * _ObjectData, TObjectHandle Sender);

typedef void (SB_CALLBACK *TSBTarCompressionTarToBZip2FinishedEvent)(void * _ObjectData, TObjectHandle Sender);

typedef void (SB_CALLBACK *TSBTarUnCompressionTarFromGZipFinishedEvent)(void * _ObjectData, TObjectHandle Sender);

typedef void (SB_CALLBACK *TSBTarUnCompressionTarFromBZip2FinishedEvent)(void * _ObjectData, TObjectHandle Sender);

typedef uint8_t TSBTarFileTypeRaw;

typedef enum
{
	uftFIFOSpecial = 0,
	_uftCharacterSpecial = 1,
	_uftDirectory = 2,
	_uftBlockSpecial = 3,
	_uftRegularFile = 4,
	_uftSymbolicLink = 5
} TSBTarFileType;

typedef uint8_t TSBTarCompressMethodRaw;

typedef enum
{
	cmNone = 0,
	cmGZip = 1,
	cmBZip2 = 2
} TSBTarCompressMethod;

#ifdef SB_USE_CLASS_TELTARARCHIVEDIRECTORYENTRY
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_Clear(TElTarArchiveDirectoryEntryHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_AddEntry(TElTarArchiveDirectoryEntryHandle _Handle, const char * pcAPath, int32_t szAPath, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_AddNewEntry(TElTarArchiveDirectoryEntryHandle _Handle, const char * pcAPath, int32_t szAPath, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_RemoveEntry(TElTarArchiveDirectoryEntryHandle _Handle, TElTarArchiveDirectoryEntryHandle Entry, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_RemoveEntry_1(TElTarArchiveDirectoryEntryHandle _Handle, const char * pcAPath, int32_t szAPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_RemoveEntry_2(TElTarArchiveDirectoryEntryHandle _Handle, const char * pcAPath, int32_t szAPath, int8_t CaseSensitive, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_ClearEntries(TElTarArchiveDirectoryEntryHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_EntryWithName(TElTarArchiveDirectoryEntryHandle _Handle, const char * pcAName, int32_t szAName, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_EntryWithName_1(TElTarArchiveDirectoryEntryHandle _Handle, const char * pcAName, int32_t szAName, int8_t CaseSensitive, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_EntryWithPath(TElTarArchiveDirectoryEntryHandle _Handle, const char * pcAPath, int32_t szAPath, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_EntryWithPath_1(TElTarArchiveDirectoryEntryHandle _Handle, const char * pcAPath, int32_t szAPath, int8_t CaseSensitive, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_get_Parent(TElTarArchiveDirectoryEntryHandle _Handle, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_get_Entries(TElTarArchiveDirectoryEntryHandle _Handle, int32_t Index, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_get_Path(TElTarArchiveDirectoryEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_get_LocalHeaderOffset(TElTarArchiveDirectoryEntryHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_set_LocalHeaderOffset(TElTarArchiveDirectoryEntryHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_get_Attributes(TElTarArchiveDirectoryEntryHandle _Handle, TElTarFileAttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_get_CheckSum(TElTarArchiveDirectoryEntryHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_get_Process(TElTarArchiveDirectoryEntryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_set_Process(TElTarArchiveDirectoryEntryHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_get_ExtractionPath(TElTarArchiveDirectoryEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_set_ExtractionPath(TElTarArchiveDirectoryEntryHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_get_ExtractionStream(TElTarArchiveDirectoryEntryHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_set_ExtractionStream(TElTarArchiveDirectoryEntryHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_get_InputStream(TElTarArchiveDirectoryEntryHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_set_InputStream(TElTarArchiveDirectoryEntryHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_Create(TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarArchiveDirectoryEntry_Create_1(TElBaseArchiveHandle Owner, TElTarArchiveDirectoryEntryHandle * OutResult);
#endif /* SB_USE_CLASS_TELTARARCHIVEDIRECTORYENTRY */

#ifdef SB_USE_CLASS_TELTARFILEATTRIBUTES
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_Assign(TElTarFileAttributesHandle _Handle, TElTarFileAttributesHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_AssignTo(TElTarFileAttributesHandle _Handle, TElTarFileAttributesHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_Mode(TElTarFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_Mode(TElTarFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_FileSize(TElTarFileAttributesHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_FileSize(TElTarFileAttributesHandle _Handle, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_FileType(TElTarFileAttributesHandle _Handle, TSBTarFileTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_FileType(TElTarFileAttributesHandle _Handle, TSBTarFileTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_FileTypeCode(TElTarFileAttributesHandle _Handle, char * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_FileTypeCode(TElTarFileAttributesHandle _Handle, char Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_ModifyTimeAvailable(TElTarFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_ModifyTimeAvailable(TElTarFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_ModifyTime(TElTarFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_ModifyTime(TElTarFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_LinkName(TElTarFileAttributesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_LinkName(TElTarFileAttributesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_SUID(TElTarFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_SUID(TElTarFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_SGID(TElTarFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_SGID(TElTarFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_OwnerRead(TElTarFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_OwnerRead(TElTarFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_OwnerWrite(TElTarFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_OwnerWrite(TElTarFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_OwnerExecute(TElTarFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_OwnerExecute(TElTarFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_GroupRead(TElTarFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_GroupRead(TElTarFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_GroupWrite(TElTarFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_GroupWrite(TElTarFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_GroupExecute(TElTarFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_GroupExecute(TElTarFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_OtherRead(TElTarFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_OtherRead(TElTarFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_OtherWrite(TElTarFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_OtherWrite(TElTarFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_OtherExecute(TElTarFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_OtherExecute(TElTarFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_UIDAndGIDAvailable(TElTarFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_UIDAndGIDAvailable(TElTarFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_UID(TElTarFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_UID(TElTarFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_GID(TElTarFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_GID(TElTarFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_HasUStar(TElTarFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_HasUStar(TElTarFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_UName(TElTarFileAttributesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_UName(TElTarFileAttributesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_GName(TElTarFileAttributesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_GName(TElTarFileAttributesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_DevMajor(TElTarFileAttributesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_DevMajor(TElTarFileAttributesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_DevMinor(TElTarFileAttributesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_DevMinor(TElTarFileAttributesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_get_Prefix(TElTarFileAttributesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_set_Prefix(TElTarFileAttributesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarFileAttributes_Create(TElTarFileAttributesHandle * OutResult);
#endif /* SB_USE_CLASS_TELTARFILEATTRIBUTES */

#ifdef SB_USE_CLASS_TELTARPROCESSINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElTarProcessingUnit_InitializeProcessing(TElTarProcessingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElTarProcessingUnit_ProcessBlock(TElTarProcessingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElTarProcessingUnit_FinalizeProcessing(TElTarProcessingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElTarProcessingUnit_get_ProcessingEntry(TElTarProcessingUnitHandle _Handle, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarProcessingUnit_set_ProcessingEntry(TElTarProcessingUnitHandle _Handle, TElTarArchiveDirectoryEntryHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarProcessingUnit_Create(TElTarProcessingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELTARPROCESSINGUNIT */

#ifdef SB_USE_CLASS_TELTARREADER
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_Open(TElTarReaderHandle _Handle, const char * pcFileName, int32_t szFileName, int8_t ReadOnly);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_Open_1(TElTarReaderHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_Close(TElTarReaderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_Extract(TElTarReaderHandle _Handle, TElTarArchiveDirectoryEntryHandle Entry, const char * pcOutputPath, int32_t szOutputPath);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_Extract_1(TElTarReaderHandle _Handle, TListHandle Entries, const char * pcOutputPath, int32_t szOutputPath);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_Extract_2(TElTarReaderHandle _Handle, const char * pcMask, int32_t szMask, const char * pcOutputPath, int32_t szOutputPath);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_ExtractContents(TElTarReaderHandle _Handle, TElTarArchiveDirectoryEntryHandle Entry, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_Directory(TElTarReaderHandle _Handle, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_IgnoreArchiveErrors(TElTarReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_IgnoreArchiveErrors(TElTarReaderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_CaseSensitiveFilenames(TElTarReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_CaseSensitiveFilenames(TElTarReaderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_FilenamesCharset(TElTarReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_FilenamesCharset(TElTarReaderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_FileSystemAdapter(TElTarReaderHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_FileSystemAdapter(TElTarReaderHandle _Handle, TElCustomFileSystemAdapterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_CompressionMethod(TElTarReaderHandle _Handle, TSBTarCompressMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_CompressionMethod(TElTarReaderHandle _Handle, TSBTarCompressMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_OnExtractionStreamNeeded(TElTarReaderHandle _Handle, TSBTarExtractionStreamNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_OnExtractionStreamNeeded(TElTarReaderHandle _Handle, TSBTarExtractionStreamNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_OnExtractionMakeDirectory(TElTarReaderHandle _Handle, TSBTarExtractionMakeDirectoryEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_OnExtractionMakeDirectory(TElTarReaderHandle _Handle, TSBTarExtractionMakeDirectoryEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_OnProgress(TElTarReaderHandle _Handle, TSBTarProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_OnProgress(TElTarReaderHandle _Handle, TSBTarProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_OnExtractionStart(TElTarReaderHandle _Handle, TSBTarExtractionStartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_OnExtractionStart(TElTarReaderHandle _Handle, TSBTarExtractionStartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_OnExtractionFinished(TElTarReaderHandle _Handle, TSBTarExtractionFinishedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_OnExtractionFinished(TElTarReaderHandle _Handle, TSBTarExtractionFinishedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_OnUserActionNeeded(TElTarReaderHandle _Handle, TSBTarUserActionNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_OnUserActionNeeded(TElTarReaderHandle _Handle, TSBTarUserActionNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_OnArchiveError(TElTarReaderHandle _Handle, TSBTarArchiveErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_OnArchiveError(TElTarReaderHandle _Handle, TSBTarArchiveErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_OnUnCompressionTarFromGZipStart(TElTarReaderHandle _Handle, TSBTarUnCompressionTarFromGZipStartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_OnUnCompressionTarFromGZipStart(TElTarReaderHandle _Handle, TSBTarUnCompressionTarFromGZipStartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_OnUnCompressionTarFromGZipFinished(TElTarReaderHandle _Handle, TSBTarUnCompressionTarFromGZipFinishedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_OnUnCompressionTarFromGZipFinished(TElTarReaderHandle _Handle, TSBTarUnCompressionTarFromGZipFinishedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_OnUnCompressionTarFromBZip2Start(TElTarReaderHandle _Handle, TSBTarUnCompressionTarFromBZip2StartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_OnUnCompressionTarFromBZip2Start(TElTarReaderHandle _Handle, TSBTarUnCompressionTarFromBZip2StartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_get_OnUnCompressionTarFromBZip2Finished(TElTarReaderHandle _Handle, TSBTarUnCompressionTarFromBZip2FinishedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_set_OnUnCompressionTarFromBZip2Finished(TElTarReaderHandle _Handle, TSBTarUnCompressionTarFromBZip2FinishedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarReader_Create(TComponentHandle AOwner, TElTarReaderHandle * OutResult);
#endif /* SB_USE_CLASS_TELTARREADER */

#ifdef SB_USE_CLASS_TELTARWRITER
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_CreateArchive(TElTarWriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_Add(TElTarWriterHandle _Handle, TElTarArchiveDirectoryEntryHandle Parent, const char * pcPath, int32_t szPath, int32_t Mode, TElUStarTarHeaderHandle USTAR, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_Add_1(TElTarWriterHandle _Handle, const char * pcPath, int32_t szPath, int32_t Mode, TElUStarTarHeaderHandle USTAR, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_Add_2(TElTarWriterHandle _Handle, TElTarArchiveDirectoryEntryHandle Parent, TStreamHandle Stream, const char * pcFileName, int32_t szFileName, int32_t Mode, TElUStarTarHeaderHandle USTAR, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_Add_3(TElTarWriterHandle _Handle, TElTarArchiveDirectoryEntryHandle Parent, TStreamHandle Stream, int32_t Mode, TElUStarTarHeaderHandle USTAR, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_Add_4(TElTarWriterHandle _Handle, TStreamHandle Stream, int32_t Mode, TElUStarTarHeaderHandle USTAR, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_Add_5(TElTarWriterHandle _Handle, TStreamHandle Stream, const char * pcFileName, int32_t szFileName, int32_t Mode, TElUStarTarHeaderHandle USTAR, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_Add_6(TElTarWriterHandle _Handle, TElTarArchiveDirectoryEntryHandle Parent, const uint8_t pBuf[], int32_t szBuf, int32_t StartIndex, int32_t Count, const char * pcFileName, int32_t szFileName, int32_t Mode, TElUStarTarHeaderHandle USTAR, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_Add_7(TElTarWriterHandle _Handle, const uint8_t pBuf[], int32_t szBuf, int32_t StartIndex, int32_t Count, const char * pcFileName, int32_t szFileName, int32_t Mode, TElUStarTarHeaderHandle USTAR, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_AddDirContents(TElTarWriterHandle _Handle, TElTarArchiveDirectoryEntryHandle Parent, const char * pcPath, int32_t szPath, int32_t Mode, TElUStarTarHeaderHandle USTAR);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_AddDirContents_1(TElTarWriterHandle _Handle, const char * pcPath, int32_t szPath, int32_t Mode, TElUStarTarHeaderHandle USTAR);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_AddDirContents_2(TElTarWriterHandle _Handle, TElTarArchiveDirectoryEntryHandle Parent, const char * pcPath, int32_t szPath, const char * pcMask, int32_t szMask, int32_t Mode, TElUStarTarHeaderHandle USTAR);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_AddDirContents_3(TElTarWriterHandle _Handle, const char * pcPath, int32_t szPath, const char * pcMask, int32_t szMask, int32_t Mode, TElUStarTarHeaderHandle USTAR);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_MakeDir(TElTarWriterHandle _Handle, const char * pcPath, int32_t szPath, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_MakeDir_1(TElTarWriterHandle _Handle, TElTarArchiveDirectoryEntryHandle Parent, const char * pcPath, int32_t szPath, TElTarArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_Remove(TElTarWriterHandle _Handle, const char * pcMask, int32_t szMask);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_BeginCompression(TElTarWriterHandle _Handle, TStreamHandle Destination);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_BeginCompression_1(TElTarWriterHandle _Handle, const char * pcDestination, int32_t szDestination);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_UpdateCompression(TElTarWriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_EndCompression(TElTarWriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_Compress(TElTarWriterHandle _Handle, TStreamHandle Destination);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_Compress_1(TElTarWriterHandle _Handle, const char * pcDestination, int32_t szDestination);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_Compress_2(TElTarWriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_Close(TElTarWriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_get_UID(TElTarWriterHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_set_UID(TElTarWriterHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_get_GID(TElTarWriterHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_set_GID(TElTarWriterHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_get_ReplaceMode(TElTarWriterHandle _Handle, TSBArcReplaceModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_set_ReplaceMode(TElTarWriterHandle _Handle, TSBArcReplaceModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_get_NewArchive(TElTarWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_get_CompressionLevel(TElTarWriterHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_set_CompressionLevel(TElTarWriterHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_get_OnCompressionStreamNeeded(TElTarWriterHandle _Handle, TSBTarCompressionStreamNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_set_OnCompressionStreamNeeded(TElTarWriterHandle _Handle, TSBTarCompressionStreamNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_get_OnCompressionStart(TElTarWriterHandle _Handle, TSBTarCompressionStartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_set_OnCompressionStart(TElTarWriterHandle _Handle, TSBTarCompressionStartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_get_OnCompressionFinished(TElTarWriterHandle _Handle, TSBTarCompressionFinishedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_set_OnCompressionFinished(TElTarWriterHandle _Handle, TSBTarCompressionFinishedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_get_OnCompressionTarToGZipStart(TElTarWriterHandle _Handle, TSBTarCompressionTarToGZipStartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_set_OnCompressionTarToGZipStart(TElTarWriterHandle _Handle, TSBTarCompressionTarToGZipStartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_get_OnCompressionTarToGZipFinished(TElTarWriterHandle _Handle, TSBTarCompressionTarToGZipFinishedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_set_OnCompressionTarToGZipFinished(TElTarWriterHandle _Handle, TSBTarCompressionTarToGZipFinishedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_get_OnCompressionTarToBZip2Start(TElTarWriterHandle _Handle, TSBTarCompressionTarToBZip2StartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_set_OnCompressionTarToBZip2Start(TElTarWriterHandle _Handle, TSBTarCompressionTarToBZip2StartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_get_OnCompressionTarToBZip2Finished(TElTarWriterHandle _Handle, TSBTarCompressionTarToBZip2FinishedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_set_OnCompressionTarToBZip2Finished(TElTarWriterHandle _Handle, TSBTarCompressionTarToBZip2FinishedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTarWriter_Create(TComponentHandle AOwner, TElTarWriterHandle * OutResult);
#endif /* SB_USE_CLASS_TELTARWRITER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElTarArchiveDirectoryEntry_ce_ptr;
extern zend_class_entry *TElTarFileAttributes_ce_ptr;
extern zend_class_entry *TElTarProcessingUnit_ce_ptr;
extern zend_class_entry *TElTarReader_ce_ptr;
extern zend_class_entry *TElTarWriter_ce_ptr;

void SB_CALLBACK TSBTarExtractionFinishedEventRaw(void * _ObjectData, TObjectHandle Sender, TElTarArchiveDirectoryEntryHandle Entry);
void SB_CALLBACK TSBTarExtractionMakeDirectoryEventRaw(void * _ObjectData, TObjectHandle Sender, TElTarArchiveDirectoryEntryHandle Entry);
void SB_CALLBACK TSBTarProgressEventRaw(void * _ObjectData, TObjectHandle Sender, uint64_t Processed, uint64_t Total, uint64_t OverallProcessed, uint64_t OverallTotal, int8_t * Cancel);
void SB_CALLBACK TSBTarExtractionStartEventRaw(void * _ObjectData, TObjectHandle Sender, TElTarArchiveDirectoryEntryHandle Entry, int8_t * Extract);
void SB_CALLBACK TSBTarUserActionNeededEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ForEvent, const char * pcDescription, int32_t szDescription, void * Param, int32_t * UserAction);
void SB_CALLBACK TSBTarExtractionStreamNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElTarArchiveDirectoryEntryHandle Entry, TStreamHandle * Stream);
void SB_CALLBACK TSBTarCompressionStartEventRaw(void * _ObjectData, TObjectHandle Sender, TElTarArchiveDirectoryEntryHandle Entry, int8_t * Compress);
void SB_CALLBACK TSBTarCompressionTarToGZipStartEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t * Compress);
void SB_CALLBACK TSBTarCompressionTarToBZip2StartEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t * Compress);
void SB_CALLBACK TSBTarUnCompressionTarFromGZipStartEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t * Compress);
void SB_CALLBACK TSBTarUnCompressionTarFromBZip2StartEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t * Compress);
void SB_CALLBACK TSBTarCompressionStreamNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElTarArchiveDirectoryEntryHandle Entry, TStreamHandle * Stream);
void SB_CALLBACK TSBTarCompressionFinishedEventRaw(void * _ObjectData, TObjectHandle Sender, TElTarArchiveDirectoryEntryHandle Entry);
void SB_CALLBACK TSBTarCompressionTarToGZipFinishedEventRaw(void * _ObjectData, TObjectHandle Sender);
void SB_CALLBACK TSBTarCompressionTarToBZip2FinishedEventRaw(void * _ObjectData, TObjectHandle Sender);
void SB_CALLBACK TSBTarUnCompressionTarFromGZipFinishedEventRaw(void * _ObjectData, TObjectHandle Sender);
void SB_CALLBACK TSBTarUnCompressionTarFromBZip2FinishedEventRaw(void * _ObjectData, TObjectHandle Sender);
void Register_TElTarArchiveDirectoryEntry(TSRMLS_D);
void Register_TElTarFileAttributes(TSRMLS_D);
void Register_TElTarProcessingUnit(TSRMLS_D);
void Register_TElTarReader(TSRMLS_D);
void Register_TElTarWriter(TSRMLS_D);
void Register_SBArcTar_Constants(int module_number TSRMLS_DC);
void Register_SBArcTar_Enum_Flags(TSRMLS_D);
void Register_SBArcTar_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBARCTAR */

