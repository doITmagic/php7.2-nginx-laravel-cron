#ifndef __INC_SBARCZIP
#define __INC_SBARCZIP

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbdictionary.h"
#include "sbstrutils.h"
#include "sbchsconv.h"
#include "sbstreams.h"
#include "sbarcbase.h"
#ifdef SB_WINDOWS
#include "sblzma.h"
#endif
#include "sbasn1tree.h"
#include "sbrdn.h"
#include "sbx509.h"
#include "sbcustomcertstorage.h"
#include "sbpublickeycrypto.h"
#include "sbcryptoprov.h"
#include "sbcryptoprovmanager.h"
#include "sbcrc.h"
#include "sbhashfunction.h"
#include "sbsymmetriccrypto.h"
#include "sbzipentities.h"
#include "sbziputils.h"
#include "sbalgorithmidentifier.h"
#include "sbcustomfsadapter.h"
#include "sbdiskfsadapter.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_ZIP 	122880
#define SB_ERROR_ZIP_ERROR_FLAG 	2048
#define SB_ZIP_ERROR_BASE 	124928
#define SB_ZIP_ERROR_INTERNAL_ERROR 	124929
#define SB_ZIP_ERROR_NO_OUTPUT_STREAM 	124930
#define SB_ZIP_ERROR_INVALID_PROPERTY_VALUE 	124931
#define SB_ZIP_ERROR_ENC_METHOD_NOT_SUPPORTED 	124932
#define SB_ZIP_ERROR_COMP_ALG_NOT_SUPPORTED 	124933
#define SB_ZIP_ERROR_INVALID_STRUCTURE 	124934
#define SB_ZIP_ERROR_NO_INPUT 	124935
#define SB_ZIP_ERROR_INVALID_PATH 	124936
#define SB_ZIP_ERROR_INVALID_PASSWORD 	124937
#define SB_ZIP_ERROR_INVALID_RECIPIENT_KEY 	124938
#define SB_ZIP_ERROR_NO_ENC_INFO 	124939
#define SB_ZIP_ERROR_NO_DEC_PASSWORD 	124940
#define SB_ZIP_ERROR_NO_DEC_CERT 	124941
#define SB_ZIP_ERROR_INV_KEY_SIZE 	124942
#define SB_ZIP_ERROR_DEC_FAILED 	124943
#define SB_ZIP_ERROR_INVALID_PARAMS 	124944
#define SB_ZIP_ERROR_INVALID_ACTION 	124945
#define SB_ZIP_ERROR_FILE_EXISTS 	124946
#define SB_ZIP_ERROR_CANT_CREATE_FILE 	124947
#define SB_ZIP_ERROR_INVALID_MAC 	124948
#define SB_ZIP_ERROR_NO_SIGNER_CERT 	124949
#define SB_ZIP_ERROR_INVALID_INDEX 	124950
#define SB_ZIP_ERROR_DIRECTORY_EXISTS 	124951
#define SB_ZIP_ERROR_ARCHIVE_NOT_OPENED 	124952
#define SB_ZIP_ERROR_FILE_ALREADY_IN_ARCHIVE 	124953
#define SB_ZIP_ERROR_PARENT_NOT_DIRECTORY 	124954
#define SB_ZIP_ERROR_INVALID_METHOD_SEQUENCE 	124955
#define SB_ZIP_ERROR_NO_OLD_ENC_IN_FIPS 	124956
#define SB_ZIP_ERROR_INVALID_PARAMETER 	124957
#define SB_ZIP_ERROR_CANT_ADD_MIME_ENTRY 	124958
#define SB_ZIP_ERROR_INVALID_SIGNATURE_DATA 	124959
#define SB_ZIP_ERROR_INVALID_ENCRYPTED_DATA 	124960
#define SB_ZIP_ERROR_OPERATION_CANCELLED 	124968
#define SB_ZIP_EVENT_EXTRACTION_FAILED 	4097
#define SB_ZIP_EVENT_CRC_MISMATCH 	4098
#define SB_ZIP_EVENT_INVALID_PASSWORD 	4099
#define SB_ZIP_EVENT_FILE_ALREADY_EXISTS 	4100
#define SB_ZIP_EVENT_CANNOT_CREATE_FILE 	4101
#define SB_ZIP_EVENT_DIR_ALREADY_EXISTS 	4102
#define SB_ZIP_EVENT_FILE_ALREADY_ADDED 	4103
#define SB_ZIP_ACTION_IGNORE 	4097
#define SB_ZIP_ACTION_ABORT 	4098
#define SB_ZIP_ACTION_RETRY 	4099
#define SB_ZIP_ACTION_SKIP 	4100

typedef TElClassHandle TElZipArchiveDirectoryEntryHandle;

typedef TElClassHandle TElZipDosFileAttributesHandle;

typedef TElZipDosFileAttributesHandle ElZipDosFileAttributesHandle;

typedef TElClassHandle TElZipUnixFileAttributesHandle;

typedef TElClassHandle TElZipStrongEncryptionInfoHandle;

typedef TElZipStrongEncryptionInfoHandle ElZipStrongEncryptionInfoHandle;

typedef TElClassHandle TElZipStrongEncryptionSignatureInfoHandle;

typedef TElZipStrongEncryptionSignatureInfoHandle ElZipStrongEncryptionSignatureInfoHandle;

typedef TElZipArchiveDirectoryEntryHandle ElZipArchiveDirectoryEntryHandle;

typedef TElClassHandle TElZipProcessingUnitHandle;

typedef TElZipProcessingUnitHandle ElZipProcessingUnitHandle;

typedef TElClassHandle TElZipStoredProcessingUnitHandle;

typedef TElZipStoredProcessingUnitHandle ElZipStoredProcessingUnitHandle;

typedef TElClassHandle TElZipDeflateDecompressingUnitHandle;

typedef TElZipDeflateDecompressingUnitHandle ElZipDeflateDecompressingUnitHandle;

typedef TElClassHandle TElZipDeflateCompressingUnitHandle;

typedef TElZipDeflateCompressingUnitHandle ElZipDeflateCompressingUnitHandle;

#ifdef SB_WINDOWS
typedef TElClassHandle TElZipLzmaDecompressingUnitHandle;

typedef TElZipLzmaDecompressingUnitHandle ElZipLzmaDecompressingUnitHandle;

typedef TElClassHandle TElZipLzmaCompressingUnitHandle;

typedef TElZipLzmaCompressingUnitHandle ElZipLzmaCompressingUnitHandle;
#endif

typedef TElClassHandle TElZipBZip2DecompressingUnitHandle;

typedef TElZipBZip2DecompressingUnitHandle ElZipBZip2DecompressingUnitHandle;

typedef TElClassHandle TElZipBZip2CompressingUnitHandle;

typedef TElZipBZip2CompressingUnitHandle ElZipBZip2CompressingUnitHandle;

typedef TElClassHandle TElZipOldStyleEncryptingUnitHandle;

typedef TElZipOldStyleEncryptingUnitHandle ElZipOldStyleEncryptingUnitHandle;

typedef TElClassHandle TElZipOldStyleDecryptingUnitHandle;

typedef TElZipOldStyleDecryptingUnitHandle ElZipOldStyleDecryptingUnitHandle;

typedef TElClassHandle TElZipStrongEncryptionBaseUnitHandle;

typedef TElZipStrongEncryptionBaseUnitHandle ElZipStrongEncryptionBaseUnitHandle;

typedef TElClassHandle TElZipStrongEncryptionEncryptingUnitHandle;

typedef TElZipStrongEncryptionEncryptingUnitHandle ElZipStrongEncryptionEncryptingUnitHandle;

typedef TElClassHandle TElZipStrongEncryptionDecryptingUnitHandle;

typedef TElZipStrongEncryptionDecryptingUnitHandle ElZipStrongEncryptionDecryptingUnitHandle;

typedef TElClassHandle TElZipStrongEncryptionHashingUnitHandle;

typedef TElZipStrongEncryptionHashingUnitHandle ElZipStrongEncryptionHashingUnitHandle;

typedef TElClassHandle TElZipWinZipAesBaseUnitHandle;

typedef TElZipWinZipAesBaseUnitHandle ElZipWinZipAesBaseUnitHandle;

typedef TElClassHandle TElZipWinZipAesDecryptingUnitHandle;

typedef TElZipWinZipAesDecryptingUnitHandle ElZipWinZipAesDecryptingUnitHandle;

typedef TElClassHandle TElZipWinZipAesEncryptingUnitHandle;

typedef TElZipWinZipAesEncryptingUnitHandle ElZipWinZipAesEncryptingUnitHandle;

typedef TElClassHandle TElZipReaderHandle;

typedef TElZipReaderHandle ElZipReaderHandle;

typedef TElClassHandle TElZipWriterHandle;

typedef TElZipWriterHandle ElZipWriterHandle;

#ifdef SB_WINDOWS
typedef uint8_t TSBZIPStubSourceRaw;

typedef enum
{
	_ssStream = 0,
	_ssFile = 1,
	_ssResource = 2
} TSBZIPStubSource;

typedef void (SB_CALLBACK *TSBZIPGetStubStreamEvent)(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream, int8_t * FreeStub);
#endif

typedef uint8_t TSBZipAddEntryResultRaw;

typedef enum
{
	aerAdded = 0,
	aerReplaced = 1,
	aerUpdated = 2,
	aerSkipped = 3
} TSBZipAddEntryResult;

typedef void (SB_CALLBACK *TSBZipExtractionFinishedEvent)(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry);

typedef void (SB_CALLBACK *TSBZipExtractionMakeDirectoryEvent)(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry);

typedef void (SB_CALLBACK *TSBZipPrivateKeyNeededEvent)(void * _ObjectData, TObjectHandle Sender, void * Param, TElX509CertificateHandle Certificate);

typedef void (SB_CALLBACK *TSBZipPasswordNeededEvent)(void * _ObjectData, TObjectHandle Sender, void * Param, char * pcPassword, int32_t * szPassword, int8_t * Cancel);

typedef void (SB_CALLBACK *TSBZipProgressEvent)(void * _ObjectData, TObjectHandle Sender, uint64_t Processed, uint64_t Total, uint64_t OverallProcessed, uint64_t OverallTotal, int8_t * Cancel);

typedef void (SB_CALLBACK *TSBZipExtractionStartEvent)(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry, int8_t * Extract);

typedef void (SB_CALLBACK *TSBZipUserActionNeededEvent)(void * _ObjectData, TObjectHandle Sender, int32_t ForEvent, const char * pcDescription, int32_t szDescription, TElZipArchiveDirectoryEntryHandle Param, int32_t * UserAction);

typedef void (SB_CALLBACK *TSBZipExtractionStreamNeededEvent)(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry, TStreamHandle * Stream);

typedef void (SB_CALLBACK *TSBZipCompressionStartEvent)(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry, int8_t * Compress);

typedef void (SB_CALLBACK *TSBZipCompressionStreamNeededEvent)(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry, TStreamHandle * Stream);

typedef void (SB_CALLBACK *TSBZipCompressionFinishedEvent)(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry);

typedef uint8_t TSBZipUnixFileTypeRaw;

typedef enum
{
	uftNamedPipe = 0,
	uftCharacterSpecial = 1,
	uftDirectory = 2,
	uftBlockSpecial = 3,
	uftRegularFile = 4,
	uftSymbolicLink = 5,
	uftSocket = 6
} TSBZipUnixFileType;

#ifdef SB_WINDOWS
typedef void (SB_CALLBACK *TSBLzmaOnProgressFunc)(void * _ObjectData, uint64_t Processed, uint64_t Total, int8_t * Cancel);
#endif

typedef uint8_t TSBZipFilenameOriginPreferenceRaw;

typedef enum
{
	fopHeader = 0,
	fopExtension = 1,
	fopAuto = 2
} TSBZipFilenameOriginPreference;

#ifdef SB_USE_CLASS_TELZIPARCHIVEDIRECTORYENTRY
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_Clear(TElZipArchiveDirectoryEntryHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_AddEntry(TElZipArchiveDirectoryEntryHandle _Handle, const char * pcAPath, int32_t szAPath, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_AddUnparsedEntry(TElZipArchiveDirectoryEntryHandle _Handle, const char * pcAPath, int32_t szAPath, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_AddNewEntry(TElZipArchiveDirectoryEntryHandle _Handle, const char * pcAPath, int32_t szAPath, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_RemoveEntry(TElZipArchiveDirectoryEntryHandle _Handle, TElZipArchiveDirectoryEntryHandle Entry, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_RemoveEntry_1(TElZipArchiveDirectoryEntryHandle _Handle, const char * pcAPath, int32_t szAPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_RemoveEntry_2(TElZipArchiveDirectoryEntryHandle _Handle, const char * pcAPath, int32_t szAPath, int8_t CaseSensitive, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_ClearEntries(TElZipArchiveDirectoryEntryHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_RemoveEntries(TElZipArchiveDirectoryEntryHandle _Handle, const char * pcFilter, int32_t szFilter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_EntryWithName(TElZipArchiveDirectoryEntryHandle _Handle, const char * pcAName, int32_t szAName, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_EntryWithName_1(TElZipArchiveDirectoryEntryHandle _Handle, const char * pcAName, int32_t szAName, int8_t CaseSensitive, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_EntryWithPath(TElZipArchiveDirectoryEntryHandle _Handle, const char * pcAPath, int32_t szAPath, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_EntryWithPath_1(TElZipArchiveDirectoryEntryHandle _Handle, const char * pcAPath, int32_t szAPath, int8_t CaseSensitive, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_LocalHeaderLoaded(TElZipArchiveDirectoryEntryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_CentralHeaderLoaded(TElZipArchiveDirectoryEntryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_StrongEncryptionInfoLoaded(TElZipArchiveDirectoryEntryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_StrongEncryptionInfoLoaded(TElZipArchiveDirectoryEntryHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_Parent(TElZipArchiveDirectoryEntryHandle _Handle, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_Entries(TElZipArchiveDirectoryEntryHandle _Handle, int32_t Index, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_Path(TElZipArchiveDirectoryEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_Flags(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_Flags(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_CompressionMethod(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_CompressionMethod(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_CompressionLevel(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_CompressionLevel(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_CRC32(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_CRC32(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_VersionToExtract(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_VersionToExtract(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_VersionMadeBy(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_VersionMadeBy(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_FileAttributesCompatibility(TElZipArchiveDirectoryEntryHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_FileAttributesCompatibility(TElZipArchiveDirectoryEntryHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_Encrypted(TElZipArchiveDirectoryEntryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_Encrypted(TElZipArchiveDirectoryEntryHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_Signed(TElZipArchiveDirectoryEntryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_StrongEncryption(TElZipArchiveDirectoryEntryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_StrongEncryption(TElZipArchiveDirectoryEntryHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_WinZipEncryption(TElZipArchiveDirectoryEntryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_WinZipEncryption(TElZipArchiveDirectoryEntryHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_WinZipEncryptionVersion(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_WinZipEncryptionVersion(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_WinZipAesKeySize(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_WinZipAesKeySize(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_LocalHeaderMasked(TElZipArchiveDirectoryEntryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_LocalHeaderMasked(TElZipArchiveDirectoryEntryHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_LocalHeaderOffset(TElZipArchiveDirectoryEntryHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_LocalHeaderOffset(TElZipArchiveDirectoryEntryHandle _Handle, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_DataOffset(TElZipArchiveDirectoryEntryHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_DiskNumberStart(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_DiskNumberStart(TElZipArchiveDirectoryEntryHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_StrongEncryptionInfo(TElZipArchiveDirectoryEntryHandle _Handle, TElZipStrongEncryptionInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_SignatureCount(TElZipArchiveDirectoryEntryHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_Signatures(TElZipArchiveDirectoryEntryHandle _Handle, int32_t Index, TElZipStrongEncryptionSignatureInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_Process(TElZipArchiveDirectoryEntryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_Process(TElZipArchiveDirectoryEntryHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_Attributes(TElZipArchiveDirectoryEntryHandle _Handle, TElZipDosFileAttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_UnixAttributes(TElZipArchiveDirectoryEntryHandle _Handle, TElZipUnixFileAttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_Comment(TElZipArchiveDirectoryEntryHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_Comment(TElZipArchiveDirectoryEntryHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_ExtractionPath(TElZipArchiveDirectoryEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_ExtractionPath(TElZipArchiveDirectoryEntryHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_ExtractionStream(TElZipArchiveDirectoryEntryHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_ExtractionStream(TElZipArchiveDirectoryEntryHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_InputPath(TElZipArchiveDirectoryEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_InputPath(TElZipArchiveDirectoryEntryHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_InputStream(TElZipArchiveDirectoryEntryHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_InputStream(TElZipArchiveDirectoryEntryHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_InputData(TElZipArchiveDirectoryEntryHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_InputData(TElZipArchiveDirectoryEntryHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_get_FreeInputStream(TElZipArchiveDirectoryEntryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_set_FreeInputStream(TElZipArchiveDirectoryEntryHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_Create(TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipArchiveDirectoryEntry_Create_1(TElBaseArchiveHandle Owner, TElZipArchiveDirectoryEntryHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPARCHIVEDIRECTORYENTRY */

#ifdef SB_USE_CLASS_TELZIPDOSFILEATTRIBUTES
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_RawAttributes(TElZipDosFileAttributesHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_set_RawAttributes(TElZipDosFileAttributesHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_RawLastModTime(TElZipDosFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_set_RawLastModTime(TElZipDosFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_RawLastModDate(TElZipDosFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_set_RawLastModDate(TElZipDosFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_ReadOnly(TElZipDosFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_set_ReadOnly(TElZipDosFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_Hidden(TElZipDosFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_set_Hidden(TElZipDosFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_System(TElZipDosFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_set_System(TElZipDosFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_VolumeLabel(TElZipDosFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_set_VolumeLabel(TElZipDosFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_Directory(TElZipDosFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_set_Directory(TElZipDosFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_Archive(TElZipDosFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_set_Archive(TElZipDosFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_ModTime(TElZipDosFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_set_ModTime(TElZipDosFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_ModifyTimeAvailable(TElZipDosFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_CreateTimeAvailable(TElZipDosFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_AccessTimeAvailable(TElZipDosFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_CreateTime(TElZipDosFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_set_CreateTime(TElZipDosFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_get_AccessTime(TElZipDosFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_set_AccessTime(TElZipDosFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDosFileAttributes_Create(TElZipDosFileAttributesHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPDOSFILEATTRIBUTES */

#ifdef SB_USE_CLASS_TELZIPUNIXFILEATTRIBUTES
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_RawAttributes(TElZipUnixFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_RawAttributes(TElZipUnixFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_FileType(TElZipUnixFileAttributesHandle _Handle, TSBZipUnixFileTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_FileType(TElZipUnixFileAttributesHandle _Handle, TSBZipUnixFileTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_SUID(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_SUID(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_SGID(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_SGID(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_StickyBit(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_StickyBit(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_OwnerRead(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_OwnerRead(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_OwnerWrite(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_OwnerWrite(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_OwnerExecute(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_OwnerExecute(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_GroupRead(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_GroupRead(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_GroupWrite(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_GroupWrite(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_GroupExecute(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_GroupExecute(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_OtherRead(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_OtherRead(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_OtherWrite(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_OtherWrite(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_OtherExecute(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_OtherExecute(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_Permissions(TElZipUnixFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_Permissions(TElZipUnixFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_DOSAttributes(TElZipUnixFileAttributesHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_DOSAttributes(TElZipUnixFileAttributesHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_UIDAndGIDAvailable(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_UIDAndGIDAvailable(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_UID(TElZipUnixFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_UID(TElZipUnixFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_GID(TElZipUnixFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_GID(TElZipUnixFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_ModifyTimeAvailable(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_ModifyTimeAvailable(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_CreateTimeAvailable(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_CreateTimeAvailable(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_AccessTimeAvailable(TElZipUnixFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_AccessTimeAvailable(TElZipUnixFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_ModifyTime(TElZipUnixFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_ModifyTime(TElZipUnixFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_CreateTime(TElZipUnixFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_CreateTime(TElZipUnixFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_get_AccessTime(TElZipUnixFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_set_AccessTime(TElZipUnixFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipUnixFileAttributes_Create(TElZipUnixFileAttributesHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPUNIXFILEATTRIBUTES */

#ifdef SB_USE_CLASS_TELZIPSTRONGENCRYPTIONINFO
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionInfo_Assign(TElZipStrongEncryptionInfoHandle _Handle, TElZipStrongEncryptionInfoHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionInfo_get_EncryptionAlgorithm(TElZipStrongEncryptionInfoHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionInfo_set_EncryptionAlgorithm(TElZipStrongEncryptionInfoHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionInfo_get_KeyLength(TElZipStrongEncryptionInfoHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionInfo_set_KeyLength(TElZipStrongEncryptionInfoHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionInfo_get_UsePassword(TElZipStrongEncryptionInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionInfo_set_UsePassword(TElZipStrongEncryptionInfoHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionInfo_get_UseCertificates(TElZipStrongEncryptionInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionInfo_set_UseCertificates(TElZipStrongEncryptionInfoHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionInfo_get_UseOAEP(TElZipStrongEncryptionInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionInfo_set_UseOAEP(TElZipStrongEncryptionInfoHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionInfo_get_Use3DES(TElZipStrongEncryptionInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionInfo_set_Use3DES(TElZipStrongEncryptionInfoHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionInfo_Create(TElZipStrongEncryptionInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPSTRONGENCRYPTIONINFO */

#ifdef SB_USE_CLASS_TELZIPSTRONGENCRYPTIONSIGNATUREINFO
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionSignatureInfo_get_Issuer(TElZipStrongEncryptionSignatureInfoHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionSignatureInfo_get_SerialNumber(TElZipStrongEncryptionSignatureInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionSignatureInfo_get_SignatureData(TElZipStrongEncryptionSignatureInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionSignatureInfo_get_HashAlgorithm(TElZipStrongEncryptionSignatureInfoHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionSignatureInfo_get_ContentHash(TElZipStrongEncryptionSignatureInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionSignatureInfo_set_ContentHash(TElZipStrongEncryptionSignatureInfoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionSignatureInfo_get_SigningCertificate(TElZipStrongEncryptionSignatureInfoHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionSignatureInfo_set_SigningCertificate(TElZipStrongEncryptionSignatureInfoHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionSignatureInfo_Create(TElZipStrongEncryptionSignatureInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPSTRONGENCRYPTIONSIGNATUREINFO */

#ifdef SB_USE_CLASS_TELZIPPROCESSINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipProcessingUnit_InitializeProcessing(TElZipProcessingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipProcessingUnit_FinalizeProcessing(TElZipProcessingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipProcessingUnit_get_CryptoProviderManager(TElZipProcessingUnitHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipProcessingUnit_set_CryptoProviderManager(TElZipProcessingUnitHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipProcessingUnit_get_ProcessingEntry(TElZipProcessingUnitHandle _Handle, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipProcessingUnit_set_ProcessingEntry(TElZipProcessingUnitHandle _Handle, TElZipArchiveDirectoryEntryHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipProcessingUnit_get_CRC32(TElZipProcessingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipProcessingUnit_Create(TElZipProcessingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPPROCESSINGUNIT */

#ifdef SB_USE_CLASS_TELZIPSTOREDPROCESSINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipStoredProcessingUnit_InitializeProcessing(TElZipStoredProcessingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipStoredProcessingUnit_ProcessBlock(TElZipStoredProcessingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElZipStoredProcessingUnit_FinalizeProcessing(TElZipStoredProcessingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipStoredProcessingUnit_Create(TElZipStoredProcessingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPSTOREDPROCESSINGUNIT */

#ifdef SB_USE_CLASS_TELZIPDEFLATEDECOMPRESSINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipDeflateDecompressingUnit_InitializeProcessing(TElZipDeflateDecompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipDeflateDecompressingUnit_ProcessBlock(TElZipDeflateDecompressingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElZipDeflateDecompressingUnit_FinalizeProcessing(TElZipDeflateDecompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipDeflateDecompressingUnit_get_Deflate64(TElZipDeflateDecompressingUnitHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDeflateDecompressingUnit_set_Deflate64(TElZipDeflateDecompressingUnitHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDeflateDecompressingUnit_Create(TElZipDeflateDecompressingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPDEFLATEDECOMPRESSINGUNIT */

#ifdef SB_USE_CLASS_TELZIPDEFLATECOMPRESSINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipDeflateCompressingUnit_InitializeProcessing(TElZipDeflateCompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipDeflateCompressingUnit_ProcessBlock(TElZipDeflateCompressingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElZipDeflateCompressingUnit_FinalizeProcessing(TElZipDeflateCompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipDeflateCompressingUnit_get_CompressionLevel(TElZipDeflateCompressingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDeflateCompressingUnit_set_CompressionLevel(TElZipDeflateCompressingUnitHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDeflateCompressingUnit_get_Deflate64(TElZipDeflateCompressingUnitHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipDeflateCompressingUnit_set_Deflate64(TElZipDeflateCompressingUnitHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipDeflateCompressingUnit_Create(TElZipDeflateCompressingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPDEFLATECOMPRESSINGUNIT */

#ifdef SB_WINDOWS
#ifdef SB_USE_CLASS_TELZIPLZMADECOMPRESSINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaDecompressingUnit_InitializeProcessing(TElZipLzmaDecompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaDecompressingUnit_ProcessBlock(TElZipLzmaDecompressingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaDecompressingUnit_FinalizeProcessing(TElZipLzmaDecompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaDecompressingUnit_Create(TElZipLzmaDecompressingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPLZMADECOMPRESSINGUNIT */

#ifdef SB_USE_CLASS_TELZIPLZMACOMPRESSINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_InitializeProcessing(TElZipLzmaCompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_ProcessBlock(TElZipLzmaCompressingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_FinalizeProcessing(TElZipLzmaCompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_DoInputData(TElZipLzmaCompressingUnitHandle _Handle, void * Buffer, int32_t index, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_get_CompressionLevel(TElZipLzmaCompressingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_set_CompressionLevel(TElZipLzmaCompressingUnitHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_get_InputStream(TElZipLzmaCompressingUnitHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_set_InputStream(TElZipLzmaCompressingUnitHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_get_DoProgress(TElZipLzmaCompressingUnitHandle _Handle, TSBLzmaOnProgressFunc * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_set_DoProgress(TElZipLzmaCompressingUnitHandle _Handle, TSBLzmaOnProgressFunc pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_get_DoInput(TElZipLzmaCompressingUnitHandle _Handle, TSBLzmaInputFunc * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_set_DoInput(TElZipLzmaCompressingUnitHandle _Handle, TSBLzmaInputFunc pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_get_DoOutput(TElZipLzmaCompressingUnitHandle _Handle, TSBLzmaOutputFunc * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_set_DoOutput(TElZipLzmaCompressingUnitHandle _Handle, TSBLzmaOutputFunc pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipLzmaCompressingUnit_Create(TElZipLzmaCompressingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPLZMACOMPRESSINGUNIT */
#endif

#ifdef SB_USE_CLASS_TELZIPBZIP2DECOMPRESSINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipBZip2DecompressingUnit_InitializeProcessing(TElZipBZip2DecompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipBZip2DecompressingUnit_ProcessBlock(TElZipBZip2DecompressingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElZipBZip2DecompressingUnit_FinalizeProcessing(TElZipBZip2DecompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipBZip2DecompressingUnit_Create(TElZipBZip2DecompressingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPBZIP2DECOMPRESSINGUNIT */

#ifdef SB_USE_CLASS_TELZIPBZIP2COMPRESSINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipBZip2CompressingUnit_InitializeProcessing(TElZipBZip2CompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipBZip2CompressingUnit_ProcessBlock(TElZipBZip2CompressingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElZipBZip2CompressingUnit_FinalizeProcessing(TElZipBZip2CompressingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipBZip2CompressingUnit_get_CompressionLevel(TElZipBZip2CompressingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipBZip2CompressingUnit_set_CompressionLevel(TElZipBZip2CompressingUnitHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipBZip2CompressingUnit_Create(TElZipBZip2CompressingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPBZIP2COMPRESSINGUNIT */

#ifdef SB_USE_CLASS_TELZIPOLDSTYLEENCRYPTINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleEncryptingUnit_InitializeProcessing(TElZipOldStyleEncryptingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleEncryptingUnit_ProcessBlock(TElZipOldStyleEncryptingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleEncryptingUnit_FinalizeProcessing(TElZipOldStyleEncryptingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleEncryptingUnit_get_Password(TElZipOldStyleEncryptingUnitHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleEncryptingUnit_set_Password(TElZipOldStyleEncryptingUnitHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleEncryptingUnit_get_OnPasswordNeeded(TElZipOldStyleEncryptingUnitHandle _Handle, TSBZipPasswordNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleEncryptingUnit_set_OnPasswordNeeded(TElZipOldStyleEncryptingUnitHandle _Handle, TSBZipPasswordNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleEncryptingUnit_Create(TElZipOldStyleEncryptingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPOLDSTYLEENCRYPTINGUNIT */

#ifdef SB_USE_CLASS_TELZIPOLDSTYLEDECRYPTINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleDecryptingUnit_InitializeProcessing(TElZipOldStyleDecryptingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleDecryptingUnit_ProcessBlock(TElZipOldStyleDecryptingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleDecryptingUnit_FinalizeProcessing(TElZipOldStyleDecryptingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleDecryptingUnit_get_Password(TElZipOldStyleDecryptingUnitHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleDecryptingUnit_set_Password(TElZipOldStyleDecryptingUnitHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleDecryptingUnit_get_HeaderRead(TElZipOldStyleDecryptingUnitHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleDecryptingUnit_get_IgnorePasswordCheck(TElZipOldStyleDecryptingUnitHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleDecryptingUnit_set_IgnorePasswordCheck(TElZipOldStyleDecryptingUnitHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleDecryptingUnit_get_OnPasswordNeeded(TElZipOldStyleDecryptingUnitHandle _Handle, TSBZipPasswordNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleDecryptingUnit_set_OnPasswordNeeded(TElZipOldStyleDecryptingUnitHandle _Handle, TSBZipPasswordNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipOldStyleDecryptingUnit_Create(TElZipOldStyleDecryptingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPOLDSTYLEDECRYPTINGUNIT */

#ifdef SB_USE_CLASS_TELZIPSTRONGENCRYPTIONBASEUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionBaseUnit_get_OnPasswordNeeded(TElZipStrongEncryptionBaseUnitHandle _Handle, TSBZipPasswordNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionBaseUnit_set_OnPasswordNeeded(TElZipStrongEncryptionBaseUnitHandle _Handle, TSBZipPasswordNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionBaseUnit_Create(TElZipProcessingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPSTRONGENCRYPTIONBASEUNIT */

#ifdef SB_USE_CLASS_TELZIPSTRONGENCRYPTIONENCRYPTINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionEncryptingUnit_InitializeProcessing(TElZipStrongEncryptionEncryptingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionEncryptingUnit_ProcessBlock(TElZipStrongEncryptionEncryptingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionEncryptingUnit_FinalizeProcessing(TElZipStrongEncryptionEncryptingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionEncryptingUnit_get_EncryptionAlgorithm(TElZipStrongEncryptionEncryptingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionEncryptingUnit_set_EncryptionAlgorithm(TElZipStrongEncryptionEncryptingUnitHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionEncryptingUnit_get_EncryptionKeySize(TElZipStrongEncryptionEncryptingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionEncryptingUnit_set_EncryptionKeySize(TElZipStrongEncryptionEncryptingUnitHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionEncryptingUnit_get_Password(TElZipStrongEncryptionEncryptingUnitHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionEncryptingUnit_set_Password(TElZipStrongEncryptionEncryptingUnitHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionEncryptingUnit_get_UseTripleDES(TElZipStrongEncryptionEncryptingUnitHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionEncryptingUnit_set_UseTripleDES(TElZipStrongEncryptionEncryptingUnitHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionEncryptingUnit_Create(TElZipStrongEncryptionEncryptingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPSTRONGENCRYPTIONENCRYPTINGUNIT */

#ifdef SB_USE_CLASS_TELZIPSTRONGENCRYPTIONDECRYPTINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_InitializeProcessing(TElZipStrongEncryptionDecryptingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_ProcessBlock(TElZipStrongEncryptionDecryptingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_FinalizeProcessing(TElZipStrongEncryptionDecryptingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_get_FileCRC32(TElZipStrongEncryptionDecryptingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_set_FileCRC32(TElZipStrongEncryptionDecryptingUnitHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_get_FileSize(TElZipStrongEncryptionDecryptingUnitHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_set_FileSize(TElZipStrongEncryptionDecryptingUnitHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_get_Password(TElZipStrongEncryptionDecryptingUnitHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_set_Password(TElZipStrongEncryptionDecryptingUnitHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_get_OAEPUsed(TElZipStrongEncryptionDecryptingUnitHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_get_TripleDESUsed(TElZipStrongEncryptionDecryptingUnitHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_get_PasswordUsed(TElZipStrongEncryptionDecryptingUnitHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_get_PublicKeyUsed(TElZipStrongEncryptionDecryptingUnitHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_get_Recipient(TElZipStrongEncryptionDecryptingUnitHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_set_Recipient(TElZipStrongEncryptionDecryptingUnitHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_get_OnPrivateKeyNeeded(TElZipStrongEncryptionDecryptingUnitHandle _Handle, TSBZipPrivateKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_set_OnPrivateKeyNeeded(TElZipStrongEncryptionDecryptingUnitHandle _Handle, TSBZipPrivateKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionDecryptingUnit_Create(TElZipStrongEncryptionDecryptingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPSTRONGENCRYPTIONDECRYPTINGUNIT */

#ifdef SB_USE_CLASS_TELZIPSTRONGENCRYPTIONHASHINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionHashingUnit_ClearHashFunctions(TElZipStrongEncryptionHashingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionHashingUnit_InitializeProcessing(TElZipStrongEncryptionHashingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionHashingUnit_ProcessBlock(TElZipStrongEncryptionHashingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionHashingUnit_FinalizeProcessing(TElZipStrongEncryptionHashingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionHashingUnit_get_HashAlgorithm(TElZipStrongEncryptionHashingUnitHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionHashingUnit_set_HashAlgorithm(TElZipStrongEncryptionHashingUnitHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionHashingUnit_get_Hash(TElZipStrongEncryptionHashingUnitHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipStrongEncryptionHashingUnit_Create(TElZipStrongEncryptionHashingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPSTRONGENCRYPTIONHASHINGUNIT */

#ifdef SB_USE_CLASS_TELZIPWINZIPAESBASEUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipWinZipAesBaseUnit_InitializeProcessing(TElZipWinZipAesBaseUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipWinZipAesBaseUnit_get_Password(TElZipWinZipAesBaseUnitHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWinZipAesBaseUnit_set_Password(TElZipWinZipAesBaseUnitHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipWinZipAesBaseUnit_get_OnPasswordNeeded(TElZipWinZipAesBaseUnitHandle _Handle, TSBZipPasswordNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWinZipAesBaseUnit_set_OnPasswordNeeded(TElZipWinZipAesBaseUnitHandle _Handle, TSBZipPasswordNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipWinZipAesBaseUnit_Create(TElZipWinZipAesBaseUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPWINZIPAESBASEUNIT */

#ifdef SB_USE_CLASS_TELZIPWINZIPAESDECRYPTINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipWinZipAesDecryptingUnit_InitializeProcessing(TElZipWinZipAesDecryptingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipWinZipAesDecryptingUnit_ProcessBlock(TElZipWinZipAesDecryptingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElZipWinZipAesDecryptingUnit_FinalizeProcessing(TElZipWinZipAesDecryptingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipWinZipAesDecryptingUnit_Create(TElZipWinZipAesDecryptingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPWINZIPAESDECRYPTINGUNIT */

#ifdef SB_USE_CLASS_TELZIPWINZIPAESENCRYPTINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElZipWinZipAesEncryptingUnit_InitializeProcessing(TElZipWinZipAesEncryptingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipWinZipAesEncryptingUnit_ProcessBlock(TElZipWinZipAesEncryptingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElZipWinZipAesEncryptingUnit_FinalizeProcessing(TElZipWinZipAesEncryptingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipWinZipAesEncryptingUnit_Create(TElZipWinZipAesEncryptingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPWINZIPAESENCRYPTINGUNIT */

#ifdef SB_USE_CLASS_TELZIPREADER
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_Open(TElZipReaderHandle _Handle, const char * pcFileName, int32_t szFileName, int8_t ReadOnly);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_Open_1(TElZipReaderHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_Close(TElZipReaderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_Extract(TElZipReaderHandle _Handle, TElZipArchiveDirectoryEntryHandle Entry, const char * pcOutputPath, int32_t szOutputPath);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_Extract_1(TElZipReaderHandle _Handle, TListHandle Entries, const char * pcOutputPath, int32_t szOutputPath);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_Extract_2(TElZipReaderHandle _Handle, const char * pcMask, int32_t szMask, const char * pcOutputPath, int32_t szOutputPath);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_ExtractContents(TElZipReaderHandle _Handle, TElZipArchiveDirectoryEntryHandle Entry, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_ValidateSignature(TElZipReaderHandle _Handle, TElZipArchiveDirectoryEntryHandle Entry, int32_t SignatureIndex, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_ValidateDirectorySignature(TElZipReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_CheckEntry(TElZipReaderHandle _Handle, TElZipArchiveDirectoryEntryHandle Entry, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_CheckArchive(TElZipReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_DirectoryCompressed(TElZipReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_DirectoryCompressed(TElZipReaderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_DirectoryEncrypted(TElZipReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_DirectoryEncrypted(TElZipReaderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_Directory(TElZipReaderHandle _Handle, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_Password(TElZipReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_Password(TElZipReaderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_ArchiveComment(TElZipReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_ArchiveComment(TElZipReaderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_SigningCertificates(TElZipReaderHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_EncryptingCertificates(TElZipReaderHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_IgnorePasswordCheck(TElZipReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_IgnorePasswordCheck(TElZipReaderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_RestoreAttributes(TElZipReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_RestoreAttributes(TElZipReaderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_FilenamesCharset(TElZipReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_FilenamesCharset(TElZipReaderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_IgnoreArchiveErrors(TElZipReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_IgnoreArchiveErrors(TElZipReaderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_CaseSensitiveFilenames(TElZipReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_CaseSensitiveFilenames(TElZipReaderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_MimeType(TElZipReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_SFXCopyright(TElZipReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_SFXCopyright(TElZipReaderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_SFXEnabled(TElZipReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_SFXEnabled(TElZipReaderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_SFXTitle(TElZipReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_SFXTitle(TElZipReaderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_StubName(TElZipReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_StubName(TElZipReaderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_StubSource(TElZipReaderHandle _Handle, TSBZIPStubSourceRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_StubSource(TElZipReaderHandle _Handle, TSBZIPStubSourceRaw Value);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_FilenameOriginPreference(TElZipReaderHandle _Handle, TSBZipFilenameOriginPreferenceRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_FilenameOriginPreference(TElZipReaderHandle _Handle, TSBZipFilenameOriginPreferenceRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_FileSystemAdapter(TElZipReaderHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_FileSystemAdapter(TElZipReaderHandle _Handle, TElCustomFileSystemAdapterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_CryptoProviderManager(TElZipReaderHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_CryptoProviderManager(TElZipReaderHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_OnExtractionStreamNeeded(TElZipReaderHandle _Handle, TSBZipExtractionStreamNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_OnExtractionStreamNeeded(TElZipReaderHandle _Handle, TSBZipExtractionStreamNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_OnExtractionMakeDirectory(TElZipReaderHandle _Handle, TSBZipExtractionMakeDirectoryEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_OnExtractionMakeDirectory(TElZipReaderHandle _Handle, TSBZipExtractionMakeDirectoryEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_OnProgress(TElZipReaderHandle _Handle, TSBZipProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_OnProgress(TElZipReaderHandle _Handle, TSBZipProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_OnExtractionStart(TElZipReaderHandle _Handle, TSBZipExtractionStartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_OnExtractionStart(TElZipReaderHandle _Handle, TSBZipExtractionStartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_OnExtractionFinished(TElZipReaderHandle _Handle, TSBZipExtractionFinishedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_OnExtractionFinished(TElZipReaderHandle _Handle, TSBZipExtractionFinishedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_OnUserActionNeeded(TElZipReaderHandle _Handle, TSBZipUserActionNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_OnUserActionNeeded(TElZipReaderHandle _Handle, TSBZipUserActionNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_OnPasswordNeeded(TElZipReaderHandle _Handle, TSBZipPasswordNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_OnPasswordNeeded(TElZipReaderHandle _Handle, TSBZipPasswordNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_OnPrivateKeyNeeded(TElZipReaderHandle _Handle, TSBZipPrivateKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_OnPrivateKeyNeeded(TElZipReaderHandle _Handle, TSBZipPrivateKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_get_OnArchiveError(TElZipReaderHandle _Handle, TSBZipArchiveErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_set_OnArchiveError(TElZipReaderHandle _Handle, TSBZipArchiveErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipReader_Create(TComponentHandle AOwner, TElZipReaderHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPREADER */

#ifdef SB_USE_CLASS_TELZIPWRITER
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_CreateArchive(TElZipWriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Add(TElZipWriterHandle _Handle, TElZipArchiveDirectoryEntryHandle Parent, const char * pcPath, int32_t szPath, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Add_1(TElZipWriterHandle _Handle, TElZipArchiveDirectoryEntryHandle Parent, const char * pcPath, int32_t szPath, TSBZipAddEntryResultRaw * AddResult, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Add_2(TElZipWriterHandle _Handle, const char * pcPath, int32_t szPath, TSBZipAddEntryResultRaw * AddResult, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Add_3(TElZipWriterHandle _Handle, const char * pcPath, int32_t szPath, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Add_4(TElZipWriterHandle _Handle, TElZipArchiveDirectoryEntryHandle Parent, TStreamHandle Stream, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Add_5(TElZipWriterHandle _Handle, TStreamHandle Stream, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Add_6(TElZipWriterHandle _Handle, TElZipArchiveDirectoryEntryHandle Parent, TStreamHandle Stream, const char * pcFileName, int32_t szFileName, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Add_7(TElZipWriterHandle _Handle, TStreamHandle Stream, const char * pcFileName, int32_t szFileName, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Add_8(TElZipWriterHandle _Handle, TElZipArchiveDirectoryEntryHandle Parent, const uint8_t pBuf[], int32_t szBuf, int32_t StartIndex, int32_t Count, const char * pcFileName, int32_t szFileName, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Add_9(TElZipWriterHandle _Handle, const uint8_t pBuf[], int32_t szBuf, int32_t StartIndex, int32_t Count, const char * pcFileName, int32_t szFileName, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_AddDirContents(TElZipWriterHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_AddDirContents_1(TElZipWriterHandle _Handle, TElZipArchiveDirectoryEntryHandle Parent, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_AddDirContents_2(TElZipWriterHandle _Handle, const char * pcPath, int32_t szPath, const char * pcMask, int32_t szMask);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_AddDirContents_3(TElZipWriterHandle _Handle, TElZipArchiveDirectoryEntryHandle Parent, const char * pcPath, int32_t szPath, const char * pcMask, int32_t szMask);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_MakeDir(TElZipWriterHandle _Handle, const char * pcPath, int32_t szPath, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_MakeDir_1(TElZipWriterHandle _Handle, TElZipArchiveDirectoryEntryHandle Parent, const char * pcPath, int32_t szPath, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Remove(TElZipWriterHandle _Handle, const char * pcMask, int32_t szMask);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_BeginCompression(TElZipWriterHandle _Handle, TStreamHandle Destination);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_BeginCompression_1(TElZipWriterHandle _Handle, const char * pcDestination, int32_t szDestination);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_UpdateCompression(TElZipWriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_EndCompression(TElZipWriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Compress(TElZipWriterHandle _Handle, TStreamHandle Destination);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Compress_1(TElZipWriterHandle _Handle, const char * pcDestination, int32_t szDestination);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Compress_2(TElZipWriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Close(TElZipWriterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_ReplaceMode(TElZipWriterHandle _Handle, TSBArcReplaceModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_set_ReplaceMode(TElZipWriterHandle _Handle, TSBArcReplaceModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_NewArchive(TElZipWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_CompressionAlgorithm(TElZipWriterHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_set_CompressionAlgorithm(TElZipWriterHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_CompressionLevel(TElZipWriterHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_set_CompressionLevel(TElZipWriterHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_Encrypt(TElZipWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_set_Encrypt(TElZipWriterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_StrongEncryption(TElZipWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_set_StrongEncryption(TElZipWriterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_WinZipEncryption(TElZipWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_set_WinZipEncryption(TElZipWriterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_WinZipAesKeySize(TElZipWriterHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_set_WinZipAesKeySize(TElZipWriterHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_StrongEncryptionInfo(TElZipWriterHandle _Handle, TElZipStrongEncryptionInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_UseUTF8Filenames(TElZipWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_set_UseUTF8Filenames(TElZipWriterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_MimeType(TElZipWriterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_set_MimeType(TElZipWriterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_OnCompressionStreamNeeded(TElZipWriterHandle _Handle, TSBZipCompressionStreamNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_set_OnCompressionStreamNeeded(TElZipWriterHandle _Handle, TSBZipCompressionStreamNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_OnCompressionStart(TElZipWriterHandle _Handle, TSBZipCompressionStartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_set_OnCompressionStart(TElZipWriterHandle _Handle, TSBZipCompressionStartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_OnCompressionFinished(TElZipWriterHandle _Handle, TSBZipCompressionFinishedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_set_OnCompressionFinished(TElZipWriterHandle _Handle, TSBZipCompressionFinishedEvent pMethodValue, void * pDataValue);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_get_OnGetStubStream(TElZipWriterHandle _Handle, TSBZIPGetStubStreamEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_set_OnGetStubStream(TElZipWriterHandle _Handle, TSBZIPGetStubStreamEvent pMethodValue, void * pDataValue);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElZipWriter_Create(TComponentHandle AOwner, TElZipWriterHandle * OutResult);
#endif /* SB_USE_CLASS_TELZIPWRITER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElZipArchiveDirectoryEntry_ce_ptr;
extern zend_class_entry *TElZipDosFileAttributes_ce_ptr;
extern zend_class_entry *TElZipUnixFileAttributes_ce_ptr;
extern zend_class_entry *TElZipStrongEncryptionInfo_ce_ptr;
extern zend_class_entry *TElZipStrongEncryptionSignatureInfo_ce_ptr;
extern zend_class_entry *TElZipProcessingUnit_ce_ptr;
extern zend_class_entry *TElZipStoredProcessingUnit_ce_ptr;
extern zend_class_entry *TElZipDeflateDecompressingUnit_ce_ptr;
extern zend_class_entry *TElZipDeflateCompressingUnit_ce_ptr;
#ifdef SB_WINDOWS
extern zend_class_entry *TElZipLzmaDecompressingUnit_ce_ptr;
extern zend_class_entry *TElZipLzmaCompressingUnit_ce_ptr;
#endif
extern zend_class_entry *TElZipBZip2DecompressingUnit_ce_ptr;
extern zend_class_entry *TElZipBZip2CompressingUnit_ce_ptr;
extern zend_class_entry *TElZipOldStyleEncryptingUnit_ce_ptr;
extern zend_class_entry *TElZipOldStyleDecryptingUnit_ce_ptr;
extern zend_class_entry *TElZipStrongEncryptionBaseUnit_ce_ptr;
extern zend_class_entry *TElZipStrongEncryptionEncryptingUnit_ce_ptr;
extern zend_class_entry *TElZipStrongEncryptionDecryptingUnit_ce_ptr;
extern zend_class_entry *TElZipStrongEncryptionHashingUnit_ce_ptr;
extern zend_class_entry *TElZipWinZipAesBaseUnit_ce_ptr;
extern zend_class_entry *TElZipWinZipAesDecryptingUnit_ce_ptr;
extern zend_class_entry *TElZipWinZipAesEncryptingUnit_ce_ptr;
extern zend_class_entry *TElZipReader_ce_ptr;
extern zend_class_entry *TElZipWriter_ce_ptr;

#ifdef SB_WINDOWS
void SB_CALLBACK TSBZIPGetStubStreamEventRaw(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream, int8_t * FreeStub);
#endif
void SB_CALLBACK TSBZipExtractionFinishedEventRaw(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry);
void SB_CALLBACK TSBZipExtractionMakeDirectoryEventRaw(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry);
void SB_CALLBACK TSBZipPrivateKeyNeededEventRaw(void * _ObjectData, TObjectHandle Sender, void * Param, TElX509CertificateHandle Certificate);
void SB_CALLBACK TSBZipPasswordNeededEventRaw(void * _ObjectData, TObjectHandle Sender, void * Param, char * pcPassword, int32_t * szPassword, int8_t * Cancel);
void SB_CALLBACK TSBZipProgressEventRaw(void * _ObjectData, TObjectHandle Sender, uint64_t Processed, uint64_t Total, uint64_t OverallProcessed, uint64_t OverallTotal, int8_t * Cancel);
void SB_CALLBACK TSBZipExtractionStartEventRaw(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry, int8_t * Extract);
void SB_CALLBACK TSBZipUserActionNeededEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ForEvent, const char * pcDescription, int32_t szDescription, TElZipArchiveDirectoryEntryHandle Param, int32_t * UserAction);
void SB_CALLBACK TSBZipExtractionStreamNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry, TStreamHandle * Stream);
void SB_CALLBACK TSBZipCompressionStartEventRaw(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry, int8_t * Compress);
void SB_CALLBACK TSBZipCompressionStreamNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry, TStreamHandle * Stream);
void SB_CALLBACK TSBZipCompressionFinishedEventRaw(void * _ObjectData, TObjectHandle Sender, TElZipArchiveDirectoryEntryHandle Entry);
#ifdef SB_WINDOWS
void SB_CALLBACK TSBLzmaOnProgressFuncRaw(void * _ObjectData, uint64_t Processed, uint64_t Total, int8_t * Cancel);
#endif
void Register_TElZipArchiveDirectoryEntry(TSRMLS_D);
void Register_TElZipDosFileAttributes(TSRMLS_D);
void Register_TElZipUnixFileAttributes(TSRMLS_D);
void Register_TElZipStrongEncryptionInfo(TSRMLS_D);
void Register_TElZipStrongEncryptionSignatureInfo(TSRMLS_D);
void Register_TElZipProcessingUnit(TSRMLS_D);
void Register_TElZipStoredProcessingUnit(TSRMLS_D);
void Register_TElZipDeflateDecompressingUnit(TSRMLS_D);
void Register_TElZipDeflateCompressingUnit(TSRMLS_D);
#ifdef SB_WINDOWS
void Register_TElZipLzmaDecompressingUnit(TSRMLS_D);
void Register_TElZipLzmaCompressingUnit(TSRMLS_D);
#endif
void Register_TElZipBZip2DecompressingUnit(TSRMLS_D);
void Register_TElZipBZip2CompressingUnit(TSRMLS_D);
void Register_TElZipOldStyleEncryptingUnit(TSRMLS_D);
void Register_TElZipOldStyleDecryptingUnit(TSRMLS_D);
void Register_TElZipStrongEncryptionBaseUnit(TSRMLS_D);
void Register_TElZipStrongEncryptionEncryptingUnit(TSRMLS_D);
void Register_TElZipStrongEncryptionDecryptingUnit(TSRMLS_D);
void Register_TElZipStrongEncryptionHashingUnit(TSRMLS_D);
void Register_TElZipWinZipAesBaseUnit(TSRMLS_D);
void Register_TElZipWinZipAesDecryptingUnit(TSRMLS_D);
void Register_TElZipWinZipAesEncryptingUnit(TSRMLS_D);
void Register_TElZipReader(TSRMLS_D);
void Register_TElZipWriter(TSRMLS_D);
void Register_SBArcZip_Constants(int module_number TSRMLS_DC);
void Register_SBArcZip_Enum_Flags(TSRMLS_D);
void Register_SBArcZip_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBARCZIP */
