#ifndef __INC_SBASICCONTAINER
#define __INC_SBASICCONTAINER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbutils.h"
#include "sbtypes.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbziputils.h"
#include "sbtspclient.h"
#include "sbpkicommon.h"
#include "sbhashfunction.h"
#include "sbcms.h"
#include "sbx509.h"
#include "sbcustomcertstorage.h"
#include "sbarczip.h"
#include "sbxmlutils.h"
#include "sbxmlcore.h"
#include "sbxmlsec.h"
#include "sbxmlsig.h"
#include "sbxmldefs.h"
#include "sbxmladesintf.h"
#include "sbxmlades.h"
#include "sbmath.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_ASIC 	737280
#define SB_ASIC_ERROR_BASE 	737280
#define SB_ASIC_ERROR_INVALID_XML_ELEMENT 	737281
#define SB_ASIC_ERROR_NO_XML_ELEMENT_PARAMETER 	737282
#define SB_ASIC_ERROR_NO_XML_DOCUMENT_PARAMETER 	737283
#define SB_ASIC_ERROR_INDEX_OUT_OF_BOUNDS 	737284
#define SB_ASiCSTimestampName 	"timestamp.tst"
#define SB_ASiCSCAdESSignature 	"signature.p7s"
#define SB_ASiCSXAdESSignature 	"signatures.xml"
#define SB_ASiCPKCS7SignatureMimeType 	"application/x-pkcs7-signature"
#define SB_ASiCTimestampTokenMimeType 	"application/vnd.etsi.timestamp-token"
#define SB_ASiCXAdESSignatureMimeType 	"text/xml"
#define SB_ASiCSignaturesNamespace 	"http://uri.etsi.org/02918/v1.2.1#"
#define SB_ASiCXMLDSigNamespace 	"http://www.w3.org/2000/09/xmldsig#"
#define SB_odfManifestNamespace 	"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0"
#define SB_odfManifestPrefix 	"manifest"

typedef TElClassHandle TElASiCSignatureHandle;

typedef TElClassHandle TElASiCContainerHandle;

typedef TElClassHandle TElASiCEntryHashInfoHandle;

typedef TElClassHandle TElASiCDataObjectReferenceHandle;

typedef TElClassHandle TElASiCManifestHandle;

typedef TElClassHandle TElASiCTimestampHandle;

typedef TElClassHandle TElASiCCAdESSignatureEntryHandle;

typedef TElClassHandle TElASiCCAdESSignatureHandle;

typedef TElClassHandle TElASiCXAdESSignatureEntryHandle;

typedef TElClassHandle TElASiCXAdESSignatureHandle;

typedef TElClassHandle TElOpenDocumentXMLElementHandle;

typedef TElClassHandle TElOpenDocumentXMLManifestFileEntryHandle;

typedef TElClassHandle TElOpenDocumentXMLManifestHandle;

typedef TElClassHandle TElASiCHashingUnitHandle;

typedef TElASiCHashingUnitHandle ElASiCHashingUnitHandle;

typedef uint8_t TSBASiCSignatureFormRaw;

typedef enum
{
	asfUnknown = 0,
	asfSimple = 1,
	asfExtended = 2
} TSBASiCSignatureForm;

typedef uint8_t TSBASiCSignatureTypeRaw;

typedef enum
{
	astTimestamp = 0,
	astCAdES = 1,
	astXAdES = 2
} TSBASiCSignatureType;

typedef uint8_t TSBASiCSignatureValidityRaw;

typedef enum
{
	asvUnknown = 0,
	asvInvalidSignature = 1,
	asvInvalidHash = 2,
	asvValidSignature = 3,
	asvValidSignatureAndHash = 4
} TSBASiCSignatureValidity;

typedef void (SB_CALLBACK *TSBASiCXAdESSignatureEvent)(void * _ObjectData, TObjectHandle Sender, TElXMLSignerHandle Signer, TElXAdESSignerHandle XAdESSigner);

typedef void (SB_CALLBACK *TSBASiCCAdESExternalSignEvent)(void * _ObjectData, TObjectHandle Sender, TElCMSSignatureHandle Signature, TElX509CertificateHandle SigningCertificate, TElCustomCertStorageHandle Chain);

#ifdef SB_USE_CLASS_TELASICSIGNATURE
SB_IMPORT uint32_t SB_APIENTRY TElASiCSignature_get_IsCalculated(TElASiCSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCSignature_get_Contents(TElASiCSignatureHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCSignature_set_Contents(TElASiCSignatureHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElASiCSignature_get_SignatureType(TElASiCSignatureHandle _Handle, TSBASiCSignatureTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCSignature_get_FileName(TElASiCSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCSignature_set_FileName(TElASiCSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElASiCSignature_get_FileEntry(TElASiCSignatureHandle _Handle, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCSignature_set_FileEntry(TElASiCSignatureHandle _Handle, TElZipArchiveDirectoryEntryHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCSignature_get_Validity(TElASiCSignatureHandle _Handle, TSBASiCSignatureValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCSignature_set_Validity(TElASiCSignatureHandle _Handle, TSBASiCSignatureValidityRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCSignature_get_Manifest(TElASiCSignatureHandle _Handle, TElASiCManifestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCSignature_set_Manifest(TElASiCSignatureHandle _Handle, TElASiCManifestHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCSignature_Create(TElASiCSignatureHandle * OutResult);
#endif /* SB_USE_CLASS_TELASICSIGNATURE */

#ifdef SB_USE_CLASS_TELASICCONTAINER
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_CreateArchive(TElASiCContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_CreateContainer(TElASiCContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_Open(TElASiCContainerHandle _Handle, const char * pcFileName, int32_t szFileName, int8_t ReadOnly);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_Open_1(TElASiCContainerHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_Close(TElASiCContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_IsServiceEntry(TElASiCContainerHandle _Handle, TElZipArchiveDirectoryEntryHandle Entry, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_ASiCSSignedEntry(TElASiCContainerHandle _Handle, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_Validate(TElASiCContainerHandle _Handle, TElASiCSignatureHandle Signature, TSBASiCSignatureValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_Validate_1(TElASiCContainerHandle _Handle, TElASiCSignatureHandle Signature, int8_t CheckHashes, TSBASiCSignatureValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_ValidateAllSignatures(TElASiCContainerHandle _Handle, int8_t CheckHashes);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_AddTimestamp(TElASiCContainerHandle _Handle, TElCustomTSPClientHandle TSPClient, TElASiCTimestampHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_AddCAdESSignature(TElASiCContainerHandle _Handle, TElASiCCAdESSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_AddXAdESSignature(TElASiCContainerHandle _Handle, TElX509CertificateHandle Certificate, TElASiCXAdESSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_AddManifest(TElASiCContainerHandle _Handle, TElASiCManifestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_AddManifest_1(TElASiCContainerHandle _Handle, TSBASiCSignatureTypeRaw SignatureType, TElASiCManifestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_DeleteSignature(TElASiCContainerHandle _Handle, TElASiCSignatureHandle Signature);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_DeleteManifest(TElASiCContainerHandle _Handle, TElASiCManifestHandle Manifest, int8_t DeleteSignature);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_DeleteAllSignatures(TElASiCContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_SignatureForm(TElASiCContainerHandle _Handle, TSBASiCSignatureFormRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_set_SignatureForm(TElASiCContainerHandle _Handle, TSBASiCSignatureFormRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_TimestampCount(TElASiCContainerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_Timestamps(TElASiCContainerHandle _Handle, int32_t Index, TElASiCTimestampHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_CAdESSignatureCount(TElASiCContainerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_CAdESSignatures(TElASiCContainerHandle _Handle, int32_t Index, TElASiCCAdESSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_XAdESSignatureCount(TElASiCContainerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_XAdESSignatures(TElASiCContainerHandle _Handle, int32_t Index, TElASiCXAdESSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_ASiCSignatures(TElASiCContainerHandle _Handle, int32_t Index, TElASiCSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_ASiCSignatureCount(TElASiCContainerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_Manifests(TElASiCContainerHandle _Handle, int32_t Index, TElASiCManifestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_ManifestCount(TElASiCContainerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_GenerateMetaInfEntry(TElASiCContainerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_set_GenerateMetaInfEntry(TElASiCContainerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_OnPrepareXAdESSignature(TElASiCContainerHandle _Handle, TSBASiCXAdESSignatureEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_set_OnPrepareXAdESSignature(TElASiCContainerHandle _Handle, TSBASiCXAdESSignatureEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_OnBeforeXAdESSign(TElASiCContainerHandle _Handle, TSBASiCXAdESSignatureEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_set_OnBeforeXAdESSign(TElASiCContainerHandle _Handle, TSBASiCXAdESSignatureEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_OnAfterXAdESSign(TElASiCContainerHandle _Handle, TSBASiCXAdESSignatureEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_set_OnAfterXAdESSign(TElASiCContainerHandle _Handle, TSBASiCXAdESSignatureEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_get_OnExternalCAdESSign(TElASiCContainerHandle _Handle, TSBASiCCAdESExternalSignEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_set_OnExternalCAdESSign(TElASiCContainerHandle _Handle, TSBASiCCAdESExternalSignEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASiCContainer_Create(TComponentHandle AOwner, TElASiCContainerHandle * OutResult);
#endif /* SB_USE_CLASS_TELASICCONTAINER */

#ifdef SB_USE_CLASS_TELASICENTRYHASHINFO
SB_IMPORT uint32_t SB_APIENTRY TElASiCEntryHashInfo_get_Entry(TElASiCEntryHashInfoHandle _Handle, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCEntryHashInfo_set_Entry(TElASiCEntryHashInfoHandle _Handle, TElZipArchiveDirectoryEntryHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCEntryHashInfo_get_Hash(TElASiCEntryHashInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCEntryHashInfo_set_Hash(TElASiCEntryHashInfoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElASiCEntryHashInfo_get_HashAlgorithm(TElASiCEntryHashInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCEntryHashInfo_set_HashAlgorithm(TElASiCEntryHashInfoHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCEntryHashInfo_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELASICENTRYHASHINFO */

#ifdef SB_USE_CLASS_TELASICDATAOBJECTREFERENCE
SB_IMPORT uint32_t SB_APIENTRY TElASiCDataObjectReference_get_Entry(TElASiCDataObjectReferenceHandle _Handle, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCDataObjectReference_set_Entry(TElASiCDataObjectReferenceHandle _Handle, TElZipArchiveDirectoryEntryHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCDataObjectReference_get_HashAlgorithm(TElASiCDataObjectReferenceHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCDataObjectReference_set_HashAlgorithm(TElASiCDataObjectReferenceHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCDataObjectReference_get_Hash(TElASiCDataObjectReferenceHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCDataObjectReference_set_Hash(TElASiCDataObjectReferenceHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElASiCDataObjectReference_get_HashValid(TElASiCDataObjectReferenceHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCDataObjectReference_get_MediaType(TElASiCDataObjectReferenceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCDataObjectReference_set_MediaType(TElASiCDataObjectReferenceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElASiCDataObjectReference_Create(TElASiCDataObjectReferenceHandle * OutResult);
#endif /* SB_USE_CLASS_TELASICDATAOBJECTREFERENCE */

#ifdef SB_USE_CLASS_TELASICMANIFEST
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_AddReference(TElASiCManifestHandle _Handle, TElZipArchiveDirectoryEntryHandle Entry, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_AddReference_1(TElASiCManifestHandle _Handle, TElZipArchiveDirectoryEntryHandle Entry, const char * pcMediaType, int32_t szMediaType, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_get_FileName(TElASiCManifestHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_set_FileName(TElASiCManifestHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_get_FileEntry(TElASiCManifestHandle _Handle, TElZipArchiveDirectoryEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_set_FileEntry(TElASiCManifestHandle _Handle, TElZipArchiveDirectoryEntryHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_get_Contents(TElASiCManifestHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_set_Contents(TElASiCManifestHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_get_ReferenceCount(TElASiCManifestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_get_References(TElASiCManifestHandle _Handle, int32_t Index, TElASiCDataObjectReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_get_Signature(TElASiCManifestHandle _Handle, TElASiCSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_set_Signature(TElASiCManifestHandle _Handle, TElASiCSignatureHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_get_HashAlgorithm(TElASiCManifestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_set_HashAlgorithm(TElASiCManifestHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCManifest_Create(TElASiCManifestHandle * OutResult);
#endif /* SB_USE_CLASS_TELASICMANIFEST */

#ifdef SB_USE_CLASS_TELASICTIMESTAMP
SB_IMPORT uint32_t SB_APIENTRY TElASiCTimestamp_get_TSPClient(TElASiCTimestampHandle _Handle, TElCustomTSPClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCTimestamp_get_TSPInfo(TElASiCTimestampHandle _Handle, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCTimestamp_set_TSPInfo(TElASiCTimestampHandle _Handle, TElClientTSPInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCTimestamp_Create(TElASiCTimestampHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCTimestamp_Create_1(TElCustomTSPClientHandle Client, TElASiCTimestampHandle * OutResult);
#endif /* SB_USE_CLASS_TELASICTIMESTAMP */

#ifdef SB_USE_CLASS_TELASICCADESSIGNATUREENTRY
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignatureEntry_get_SigningCertificate(TElASiCCAdESSignatureEntryHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignatureEntry_set_SigningCertificate(TElASiCCAdESSignatureEntryHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignatureEntry_get_SigningCertificateChain(TElASiCCAdESSignatureEntryHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignatureEntry_set_SigningCertificateChain(TElASiCCAdESSignatureEntryHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignatureEntry_get_RemoteSignParam(TElASiCCAdESSignatureEntryHandle _Handle, void * * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignatureEntry_set_RemoteSignParam(TElASiCCAdESSignatureEntryHandle _Handle, void * Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignatureEntry_get_RemoteSign(TElASiCCAdESSignatureEntryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignatureEntry_set_RemoteSign(TElASiCCAdESSignatureEntryHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignatureEntry_get_Signature(TElASiCCAdESSignatureEntryHandle _Handle, TElCMSSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignatureEntry_set_Signature(TElASiCCAdESSignatureEntryHandle _Handle, TElCMSSignatureHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignatureEntry_get_Validity(TElASiCCAdESSignatureEntryHandle _Handle, TSBASiCSignatureValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignatureEntry_get_RemoteSignCallback(TElASiCCAdESSignatureEntryHandle _Handle, TSBCMSRemoteSignCallback * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignatureEntry_set_RemoteSignCallback(TElASiCCAdESSignatureEntryHandle _Handle, TSBCMSRemoteSignCallback pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignatureEntry_Create(TElASiCCAdESSignatureEntryHandle * OutResult);
#endif /* SB_USE_CLASS_TELASICCADESSIGNATUREENTRY */

#ifdef SB_USE_CLASS_TELASICCADESSIGNATURE
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignature_AddSignatureEntry(TElASiCCAdESSignatureHandle _Handle, TElX509CertificateHandle Certificate, TElCustomCertStorageHandle Chain, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignature_AddSignatureEntry_1(TElASiCCAdESSignatureHandle _Handle, TElX509CertificateHandle Certificate, TSBCMSRemoteSignCallback pMethodSignCallback, void * pDataSignCallback, void * Param, TElCustomCertStorageHandle Chain, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignature_get_CMSMessage(TElASiCCAdESSignatureHandle _Handle, TElSignedCMSMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignature_get_SignatureEntryCount(TElASiCCAdESSignatureHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignature_get_SignatureEntries(TElASiCCAdESSignatureHandle _Handle, int32_t Index, TElASiCCAdESSignatureEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCCAdESSignature_Create(TElASiCCAdESSignatureHandle * OutResult);
#endif /* SB_USE_CLASS_TELASICCADESSIGNATURE */

#ifdef SB_USE_CLASS_TELASICXADESSIGNATUREENTRY
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignatureEntry_AddReference(TElASiCXAdESSignatureEntryHandle _Handle, TElZipArchiveDirectoryEntryHandle Entry, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignatureEntry_get_Verifier(TElASiCXAdESSignatureEntryHandle _Handle, TElXMLVerifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignatureEntry_get_XAdESProcessor(TElASiCXAdESSignatureEntryHandle _Handle, TElXAdESProcessorHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignatureEntry_get_ReferenceCount(TElASiCXAdESSignatureEntryHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignatureEntry_get_References(TElASiCXAdESSignatureEntryHandle _Handle, int32_t Index, TElASiCDataObjectReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignatureEntry_get_SigningCertificate(TElASiCXAdESSignatureEntryHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignatureEntry_set_SigningCertificate(TElASiCXAdESSignatureEntryHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignatureEntry_get_SignatureMethod(TElASiCXAdESSignatureEntryHandle _Handle, TElXMLSignatureMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignatureEntry_set_SignatureMethod(TElASiCXAdESSignatureEntryHandle _Handle, TElXMLSignatureMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignatureEntry_get_Validity(TElASiCXAdESSignatureEntryHandle _Handle, TSBASiCSignatureValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignatureEntry_set_Validity(TElASiCXAdESSignatureEntryHandle _Handle, TSBASiCSignatureValidityRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignatureEntry_Create(TElASiCXAdESSignatureEntryHandle * OutResult);
#endif /* SB_USE_CLASS_TELASICXADESSIGNATUREENTRY */

#ifdef SB_USE_CLASS_TELASICXADESSIGNATURE
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignature_AddSignatureEntry(TElASiCXAdESSignatureHandle _Handle, TElX509CertificateHandle Certificate, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignature_get_SignatureEntryCount(TElASiCXAdESSignatureHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignature_get_SignatureEntries(TElASiCXAdESSignatureHandle _Handle, int32_t Index, TElASiCXAdESSignatureEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignature_get_XMLDocument(TElASiCXAdESSignatureHandle _Handle, TElXMLDOMDocumentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCXAdESSignature_Create(TElASiCXAdESSignatureHandle * OutResult);
#endif /* SB_USE_CLASS_TELASICXADESSIGNATURE */

#ifdef SB_USE_CLASS_TELOPENDOCUMENTXMLELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLElement_Clear(TElOpenDocumentXMLElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLElement_get_IsModified(TElOpenDocumentXMLElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLElement_set_IsModified(TElOpenDocumentXMLElementHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELOPENDOCUMENTXMLELEMENT */

#ifdef SB_USE_CLASS_TELOPENDOCUMENTXMLMANIFESTFILEENTRY
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_Clear(TElOpenDocumentXMLManifestFileEntryHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_LoadFromXML(TElOpenDocumentXMLManifestFileEntryHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_SaveToXML(TElOpenDocumentXMLManifestFileEntryHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_get_FullPath(TElOpenDocumentXMLManifestFileEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_set_FullPath(TElOpenDocumentXMLManifestFileEntryHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_get_MediaType(TElOpenDocumentXMLManifestFileEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_set_MediaType(TElOpenDocumentXMLManifestFileEntryHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_get_PreferredViewMode(TElOpenDocumentXMLManifestFileEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_set_PreferredViewMode(TElOpenDocumentXMLManifestFileEntryHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_get_Size(TElOpenDocumentXMLManifestFileEntryHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_set_Size(TElOpenDocumentXMLManifestFileEntryHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_get_Version(TElOpenDocumentXMLManifestFileEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_set_Version(TElOpenDocumentXMLManifestFileEntryHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifestFileEntry_Create(TElOpenDocumentXMLManifestFileEntryHandle * OutResult);
#endif /* SB_USE_CLASS_TELOPENDOCUMENTXMLMANIFESTFILEENTRY */

#ifdef SB_USE_CLASS_TELOPENDOCUMENTXMLMANIFEST
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifest_Add(TElOpenDocumentXMLManifestHandle _Handle, TElOpenDocumentXMLManifestFileEntryHandle AFileEntry, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifest_Add_1(TElOpenDocumentXMLManifestHandle _Handle, const char * pcFullPath, int32_t szFullPath, const char * pcMediaType, int32_t szMediaType, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifest_Insert(TElOpenDocumentXMLManifestHandle _Handle, int32_t Index, TElOpenDocumentXMLManifestFileEntryHandle AFileEntry);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifest_Delete(TElOpenDocumentXMLManifestHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifest_Clear(TElOpenDocumentXMLManifestHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifest_GetFileEntryByFullPath(TElOpenDocumentXMLManifestHandle _Handle, const char * pcFullPath, int32_t szFullPath, TElOpenDocumentXMLManifestFileEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifest_LoadFromXML(TElOpenDocumentXMLManifestHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifest_SaveToXML(TElOpenDocumentXMLManifestHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifest_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifest_get_Count(TElOpenDocumentXMLManifestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifest_get_FileEntries(TElOpenDocumentXMLManifestHandle _Handle, int32_t Index, TElOpenDocumentXMLManifestFileEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenDocumentXMLManifest_Create(TElOpenDocumentXMLManifestHandle * OutResult);
#endif /* SB_USE_CLASS_TELOPENDOCUMENTXMLMANIFEST */

#ifdef SB_USE_CLASS_TELASICHASHINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElASiCHashingUnit_InitializeProcessing(TElASiCHashingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASiCHashingUnit_ProcessBlock(TElASiCHashingUnitHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElASiCHashingUnit_FinalizeProcessing(TElASiCHashingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASiCHashingUnit_get_HashInfo(TElASiCHashingUnitHandle _Handle, TElASiCEntryHashInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASiCHashingUnit_set_HashInfo(TElASiCHashingUnitHandle _Handle, TElASiCEntryHashInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElASiCHashingUnit_Create(TElASiCHashingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELASICHASHINGUNIT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElASiCSignature_ce_ptr;
extern zend_class_entry *TElASiCContainer_ce_ptr;
extern zend_class_entry *TElASiCEntryHashInfo_ce_ptr;
extern zend_class_entry *TElASiCDataObjectReference_ce_ptr;
extern zend_class_entry *TElASiCManifest_ce_ptr;
extern zend_class_entry *TElASiCTimestamp_ce_ptr;
extern zend_class_entry *TElASiCCAdESSignatureEntry_ce_ptr;
extern zend_class_entry *TElASiCCAdESSignature_ce_ptr;
extern zend_class_entry *TElASiCXAdESSignatureEntry_ce_ptr;
extern zend_class_entry *TElASiCXAdESSignature_ce_ptr;
extern zend_class_entry *TElOpenDocumentXMLElement_ce_ptr;
extern zend_class_entry *TElOpenDocumentXMLManifestFileEntry_ce_ptr;
extern zend_class_entry *TElOpenDocumentXMLManifest_ce_ptr;
extern zend_class_entry *TElASiCHashingUnit_ce_ptr;

void SB_CALLBACK TSBASiCXAdESSignatureEventRaw(void * _ObjectData, TObjectHandle Sender, TElXMLSignerHandle Signer, TElXAdESSignerHandle XAdESSigner);
void SB_CALLBACK TSBASiCCAdESExternalSignEventRaw(void * _ObjectData, TObjectHandle Sender, TElCMSSignatureHandle Signature, TElX509CertificateHandle SigningCertificate, TElCustomCertStorageHandle Chain);
void Register_TElASiCSignature(TSRMLS_D);
void Register_TElASiCContainer(TSRMLS_D);
void Register_TElASiCEntryHashInfo(TSRMLS_D);
void Register_TElASiCDataObjectReference(TSRMLS_D);
void Register_TElASiCManifest(TSRMLS_D);
void Register_TElASiCTimestamp(TSRMLS_D);
void Register_TElASiCCAdESSignatureEntry(TSRMLS_D);
void Register_TElASiCCAdESSignature(TSRMLS_D);
void Register_TElASiCXAdESSignatureEntry(TSRMLS_D);
void Register_TElASiCXAdESSignature(TSRMLS_D);
void Register_TElOpenDocumentXMLElement(TSRMLS_D);
void Register_TElOpenDocumentXMLManifestFileEntry(TSRMLS_D);
void Register_TElOpenDocumentXMLManifest(TSRMLS_D);
void Register_TElASiCHashingUnit(TSRMLS_D);
void Register_SBASiCContainer_Constants(int module_number TSRMLS_DC);
void Register_SBASiCContainer_Enum_Flags(TSRMLS_D);
void Register_SBASiCContainer_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBASICCONTAINER */

