#ifndef __INC_SBASN1
#define __INC_SBASN1

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbsharedresource.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_asn1Boolean 	1
#define SB_asn1Integer 	2
#define SB_asn1BitStr 	3
#define SB_asn1OctetStr 	4
#define SB_asn1NULL 	5
#define SB_asn1Object 	6
#define SB_asn1Real 	9
#define SB_asn1Enumerated 	10
#define SB_asn1UTF8String 	12
#define SB_asn1Sequence 	16
#define SB_asn1Set 	17
#define SB_asn1NumericStr 	18
#define SB_asn1PrintableStr 	19
#define SB_asn1T61String 	20
#define SB_asn1TeletexStr 	20
#define SB_asn1IA5String 	22
#define SB_asn1UTCTime 	23
#define SB_asn1GeneralizedTime 	24
#define SB_asn1VisibleStr 	26
#define SB_asn1GeneralStr 	27
#define SB_asn1A0 	0
#define SB_asn1A1 	1
#define SB_asn1A2 	2
#define SB_asn1A3 	3
#define SB_asn1A4 	4
#define SB_asn1A5 	5
#define SB_asn1A6 	6
#define SB_asn1A7 	7
#define SB_asn1A8 	8
#define SB_ERROR_FACILITY_ASN1 	512
#define SB_ERROR_ASN1_INVALID_STRUCTURE 	513
#define SB_ERROR_ASN1_INVALID_LENGTH_VALUE 	514
#define SB_ERROR_ASN1_TAG_DEPTH_OVER_LIMIT 	515
#define SB_ERROR_ASN1_INVALID_STREAM_DATA 	516
#define SB_ERROR_ASN1_UNEXPECTED_STREAM_END 	517
#define SB_ERROR_ASN1_BUFFER_LENGTH_OVER_LIMIT 	518
#define SB_ERROR_ASN1_INTERNAL_ERROR 	519
#define SB_ERROR_ASN1_OBJECT_NOT_FOUND_IN_POOL 	520
#define SB_ERROR_ASN1_STACK_EMPTY 	521
#define SB_ERROR_ASN1_UNKNOWN_PATH 	522
#define SB_ERROR_ASN1_TERMINATED 	523
#define SB_ERROR_ASN1_UNSUPPORTED_PATH_FORMAT 	524
#define SB_ERROR_ASN1_TAG_READONLY 	525
#define SB_SMaxDepthExceeded 	"Maximal ASN.1 tag depth exceeded"
#define SB_SObjectNotFoundInPool 	"Object not found in the pool"

typedef TElClassHandle TElASN1ParserHandle;

typedef TElClassHandle TElASN1ParserFactoryHandle;

typedef uint8_t * SBASN1_PByte;

typedef uint8_t asn1TagTypeRaw;

typedef enum
{
	asn1tUniversal = 0,
	asn1tApplication = 1,
	asn1tSpecific = 2,
	asn1tPrivate = 3,
	asn1tEOC = 4
} asn1TagType;

typedef void (SB_CALLBACK *asn1tReadFunc)(void * Stream, void * Data, int32_t Size, int32_t * OutResult);

typedef void (SB_CALLBACK *asn1tWriteFunc)(void * Stream, void * Data, int32_t Size);

typedef void (SB_CALLBACK *asn1tCallBackFunc)(void * _ObjectData, void * Stream, asn1TagTypeRaw TagType, int8_t TagConstrained, void * Tag, int32_t TagSize, int32_t Size, void * Data, int32_t BitRest, int8_t * OutResult);

typedef void (SB_CALLBACK *TSBASN1ReadEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t * Size);

typedef void (SB_CALLBACK *TSBASN1TagEvent)(void * _ObjectData, TObjectHandle Sender, asn1TagTypeRaw TagType, int8_t TagConstrained, uint32_t Tag, int64_t Size, void * Data, int32_t BitRest, int8_t * Valid);

typedef void (SB_CALLBACK *TSBASN1TagHeaderEvent)(void * _ObjectData, TObjectHandle Sender, uint8_t TagID, int64_t TagLen, int32_t HeaderLen, int8_t UndefLen);

typedef void (SB_CALLBACK *TSBASN1DataAvailableEvent)(void * _ObjectData, TObjectHandle Sender, uint8_t TagID, int64_t DataLen, int8_t * ReturnData, TObjectHandle * UserData);

typedef void (SB_CALLBACK *TSBASN1DataEvent)(void * _ObjectData, TObjectHandle Sender, TObjectHandle UserData, void * Buffer, int32_t Count, int8_t * SkipRest);

typedef void (SB_CALLBACK *TSBASN1DataCompletedEvent)(void * _ObjectData, TObjectHandle Sender, TObjectHandle UserData);

typedef void (SB_CALLBACK *TSBASN1SkipEvent)(void * _ObjectData, TObjectHandle Sender, int64_t * Count);

typedef TElClassHandle TElASN1ParserClassHandle;

#ifdef SB_USE_CLASS_TELASN1PARSER
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_Reset(TElASN1ParserHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_Parse(TElASN1ParserHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_get_RaiseOnEOC(TElASN1ParserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_set_RaiseOnEOC(TElASN1ParserHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_get_MaxDataLength(TElASN1ParserHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_set_MaxDataLength(TElASN1ParserHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_get_MaxSimpleTagLength(TElASN1ParserHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_set_MaxSimpleTagLength(TElASN1ParserHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_get_AsyncDataMode(TElASN1ParserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_set_AsyncDataMode(TElASN1ParserHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_get_CurrDepth(TElASN1ParserHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_get_DataBlockSize(TElASN1ParserHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_set_DataBlockSize(TElASN1ParserHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_get_SingleLoad(TElASN1ParserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_set_SingleLoad(TElASN1ParserHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_get_OnRead(TElASN1ParserHandle _Handle, TSBASN1ReadEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_set_OnRead(TElASN1ParserHandle _Handle, TSBASN1ReadEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_get_OnTag(TElASN1ParserHandle _Handle, TSBASN1TagEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_set_OnTag(TElASN1ParserHandle _Handle, TSBASN1TagEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_get_OnTagHeader(TElASN1ParserHandle _Handle, TSBASN1TagHeaderEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_set_OnTagHeader(TElASN1ParserHandle _Handle, TSBASN1TagHeaderEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_get_OnSkip(TElASN1ParserHandle _Handle, TSBASN1SkipEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_set_OnSkip(TElASN1ParserHandle _Handle, TSBASN1SkipEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_get_OnDataAvailable(TElASN1ParserHandle _Handle, TSBASN1DataAvailableEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_set_OnDataAvailable(TElASN1ParserHandle _Handle, TSBASN1DataAvailableEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_get_OnData(TElASN1ParserHandle _Handle, TSBASN1DataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_set_OnData(TElASN1ParserHandle _Handle, TSBASN1DataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_get_OnDataCompleted(TElASN1ParserHandle _Handle, TSBASN1DataCompletedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_set_OnDataCompleted(TElASN1ParserHandle _Handle, TSBASN1DataCompletedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1Parser_Create(TElASN1ParserHandle * OutResult);
#endif /* SB_USE_CLASS_TELASN1PARSER */

#ifdef SB_USE_CLASS_TELASN1PARSERFACTORY
SB_IMPORT uint32_t SB_APIENTRY TElASN1ParserFactory_GetASN1Parser(TElASN1ParserFactoryHandle _Handle, TElASN1ParserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ParserFactory_ReleaseASN1Parser(TElASN1ParserFactoryHandle _Handle, TElASN1ParserHandle * Parser);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ParserFactory_Clear(TElASN1ParserFactoryHandle _Handle, int8_t ForceDestruction);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ParserFactory_Create(TElASN1ParserFactoryHandle * OutResult);
#endif /* SB_USE_CLASS_TELASN1PARSERFACTORY */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElASN1ParserClass_ce_ptr;
extern zend_class_entry *TElASN1Parser_ce_ptr;
extern zend_class_entry *TElASN1ParserFactory_ce_ptr;

void SB_CALLBACK asn1tCallBackFuncRaw(void * _ObjectData, void * Stream, asn1TagTypeRaw TagType, int8_t TagConstrained, void * Tag, int32_t TagSize, int32_t Size, void * Data, int32_t BitRest, int8_t * OutResult);
void SB_CALLBACK TSBASN1ReadEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t * Size);
void SB_CALLBACK TSBASN1TagEventRaw(void * _ObjectData, TObjectHandle Sender, asn1TagTypeRaw TagType, int8_t TagConstrained, uint32_t Tag, int64_t Size, void * Data, int32_t BitRest, int8_t * Valid);
void SB_CALLBACK TSBASN1TagHeaderEventRaw(void * _ObjectData, TObjectHandle Sender, uint8_t TagID, int64_t TagLen, int32_t HeaderLen, int8_t UndefLen);
void SB_CALLBACK TSBASN1DataAvailableEventRaw(void * _ObjectData, TObjectHandle Sender, uint8_t TagID, int64_t DataLen, int8_t * ReturnData, TObjectHandle * UserData);
void SB_CALLBACK TSBASN1DataEventRaw(void * _ObjectData, TObjectHandle Sender, TObjectHandle UserData, void * Buffer, int32_t Count, int8_t * SkipRest);
void SB_CALLBACK TSBASN1DataCompletedEventRaw(void * _ObjectData, TObjectHandle Sender, TObjectHandle UserData);
void SB_CALLBACK TSBASN1SkipEventRaw(void * _ObjectData, TObjectHandle Sender, int64_t * Count);
void Register_TElASN1Parser(TSRMLS_D);
void Register_TElASN1ParserFactory(TSRMLS_D);
SB_PHP_FUNCTION(SBASN1, asn1ParseStream);
SB_PHP_FUNCTION(SBASN1, asn1AddTypeEqu);
SB_PHP_FUNCTION(SBASN1, WriteListSequence);
SB_PHP_FUNCTION(SBASN1, WritePrimitiveListSeq);
SB_PHP_FUNCTION(SBASN1, WriteExplicit);
SB_PHP_FUNCTION(SBASN1, WriteInteger);
SB_PHP_FUNCTION(SBASN1, WriteOID);
SB_PHP_FUNCTION(SBASN1, WritePrintableString);
SB_PHP_FUNCTION(SBASN1, WriteUTF8String);
SB_PHP_FUNCTION(SBASN1, WriteIA5String);
SB_PHP_FUNCTION(SBASN1, WriteUTCTime);
SB_PHP_FUNCTION(SBASN1, WriteGeneralizedTime);
SB_PHP_FUNCTION(SBASN1, WriteSize);
SB_PHP_FUNCTION(SBASN1, WriteBitString);
SB_PHP_FUNCTION(SBASN1, WriteOctetString);
SB_PHP_FUNCTION(SBASN1, WriteVisibleString);
SB_PHP_FUNCTION(SBASN1, WriteBoolean);
SB_PHP_FUNCTION(SBASN1, WriteNULL);
SB_PHP_FUNCTION(SBASN1, WritePrimitive);
SB_PHP_FUNCTION(SBASN1, WriteStringPrimitive);
SB_PHP_FUNCTION(SBASN1, ASN1ParserFactory);
void Register_SBASN1_Constants(int module_number TSRMLS_DC);
void Register_SBASN1_Enum_Flags(TSRMLS_D);
void Register_SBASN1_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_ASN1
SB_IMPORT uint32_t SB_APIENTRY SBASN1_asn1ParseStream(void * Stream, asn1tCallBackFunc pMethodCallBack, void * pDataCallBack);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_asn1AddTypeEqu(asn1TagTypeRaw TagType1, void * Tag1, int32_t TagSize1, asn1TagTypeRaw TagType2, void * Tag2, int32_t TagSize2);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_asn1AddTypeEqu_1(asn1TagTypeRaw TagType1, void * Tag1, int32_t TagSize1, uint8_t Tag2);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteListSequence(const TElByteArrayListHandle Strings, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WritePrimitiveListSeq(uint8_t Tag, TElByteArrayListHandle Strings, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteExplicit(const uint8_t pData[], int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteInteger(const uint8_t pData[], int32_t szData, uint8_t TagID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteInteger_1(int32_t Number, uint8_t TagID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteOID(const uint8_t pData[], int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WritePrintableString(const char * pcData, int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WritePrintableString_1(const uint8_t pData[], int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteUTF8String(const char * pcData, int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteUTF8String_1(const uint8_t pData[], int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteIA5String(const char * pcData, int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteIA5String_1(const uint8_t pData[], int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteUTCTime(const char * pcData, int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteGeneralizedTime(int64_t T, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteSize(uint32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteBitString(const uint8_t pData[], int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteOctetString(const char * pcData, int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteOctetString_1(const uint8_t pData[], int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteVisibleString(const char * pcData, int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteBoolean(int8_t Data, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteNULL(uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WritePrimitive(uint8_t Tag, const uint8_t pData[], int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteStringPrimitive(uint8_t Tag, const char * pcData, int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_WriteStringPrimitive_1(uint8_t Tag, const uint8_t pData[], int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1_ASN1ParserFactory(TElASN1ParserFactoryHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_ASN1 */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBASN1 */

