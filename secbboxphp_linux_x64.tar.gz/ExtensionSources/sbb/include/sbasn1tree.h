#ifndef __INC_SBASN1TREE
#define __INC_SBASN1TREE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstreams.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbasn1.h"
#include "sbsharedresource.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ASN1_BOOLEAN 	1
#define SB_ASN1_INTEGER 	2
#define SB_ASN1_BITSTRING 	3
#define SB_ASN1_OCTETSTRING 	4
#define SB_ASN1_NULL 	5
#define SB_ASN1_OBJECT 	6
#define SB_ASN1_REAL 	9
#define SB_ASN1_ENUMERATED 	10
#define SB_ASN1_UTF8STRING 	12
#define SB_ASN1_NUMERICSTR 	18
#define SB_ASN1_PRINTABLESTRING 	19
#define SB_ASN1_T61STRING 	20
#define SB_ASN1_TELETEXSTRING 	20
#define SB_ASN1_VIDEOTEXSTRING 	21
#define SB_ASN1_IA5STRING 	22
#define SB_ASN1_UTCTIME 	23
#define SB_ASN1_GENERALIZEDTIME 	24
#define SB_ASN1_GRAPHICSTRING 	25
#define SB_ASN1_VISIBLESTRING 	26
#define SB_ASN1_GENERALSTRING 	27
#define SB_ASN1_UNIVERSALSTRING 	28
#define SB_ASN1_BMPSTRING 	30
#define SB_ASN1_SEQUENCE 	48
#define SB_ASN1_SET 	49
#define SB_ASN1_A0_PRIMITIVE 	128
#define SB_ASN1_A0 	160
#define SB_ASN1_A1_PRIMITIVE 	129
#define SB_ASN1_A1 	161
#define SB_ASN1_A2_PRIMITIVE 	130
#define SB_ASN1_A2 	162
#define SB_ASN1_A3_PRIMITIVE 	131
#define SB_ASN1_A3 	163
#define SB_ASN1_A4_PRIMITIVE 	132
#define SB_ASN1_A4 	164
#define SB_ASN1_A5_PRIMITIVE 	133
#define SB_ASN1_A5 	165
#define SB_ASN1_A6_PRIMITIVE 	134
#define SB_ASN1_A6 	166
#define SB_ASN1_A7_PRIMITIVE 	135
#define SB_ASN1_A7 	167
#define SB_ASN1_A8_PRIMITIVE 	136
#define SB_ASN1_A8 	168
#define SB_ASN1_A9_PRIMITIVE 	137
#define SB_ASN1_A9 	169
#define SB_ASN1_CONSTRAINED_FLAG 	32

typedef TElClassHandle TElASN1CustomTagHandle;

typedef TElClassHandle TElASN1ConstrainedTagHandle;

typedef TElClassHandle TElASN1DataSourceHandle;

typedef TElClassHandle TElASN1SimpleTagHandle;

typedef TElClassHandle TElASN1TagInfoHandle;

typedef TElClassHandle TElASN1StreamProcessorHandle;

typedef TElClassHandle TElASN1TagInfoFactoryHandle;

typedef TElClassHandle TElASN1TagPathHandle;

typedef TElClassHandle TElASN1TagPathElementHandle;

typedef TElClassHandle TElASN1SmartStreamProcessorHandle;

typedef uint8_t TSBASN1DisplayFormatRaw;

typedef enum
{
	adfDefault = 0
} TSBASN1DisplayFormat;

typedef uint8_t TSBASN1DataSourceTypeRaw;

typedef enum
{
	dstBuffer = 0,
	dstStream = 1,
	dstVirtual = 2,
	dstReference = 3
} TSBASN1DataSourceType;

typedef void (SB_CALLBACK *TSBASN1VirtualDataNeededEvent)(void * _ObjectData, TObjectHandle Sender, int64_t StartIndex, void * Buffer, int32_t MaxSize, int32_t * Read);

typedef uint8_t TSBASN1StreamAccessRaw;

typedef enum
{
	saStoreStream = 0
} TSBASN1StreamAccess;

typedef void (SB_CALLBACK *TSBASN1StreamProcessorTagBeginEvent)(void * _ObjectData, TObjectHandle Sender, TElASN1TagInfoHandle TagInfo, int8_t * Skip);

typedef void (SB_CALLBACK *TSBASN1StreamProcessorTagEndEvent)(void * _ObjectData, TObjectHandle Sender, TElASN1TagInfoHandle TagInfo);

typedef void (SB_CALLBACK *TSBASN1StreamProcessorTagDataEvent)(void * _ObjectData, TObjectHandle Sender, TElASN1TagInfoHandle TagInfo, void * Buffer, int32_t Count, int8_t * SkipRest);

typedef uint8_t TSBASN1TagPathActionRaw;

typedef enum
{
	tpaContinue = 0,
	tpaSkip = 1,
	tpaTerminate = 2
} TSBASN1TagPathAction;

typedef void (SB_CALLBACK *TSBASN1TagPathHandler)(void * _ObjectData, TObjectHandle Sender, TElASN1TagPathHandle Path, TElASN1TagInfoHandle TagInfo, TSBASN1TagPathActionRaw * Action);

#ifdef SB_USE_CLASS_TELASN1CUSTOMTAG
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_LoadFromBuffer(TElASN1CustomTagHandle _Handle, void * Buffer, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_LoadFromBuffer_1(TElASN1CustomTagHandle _Handle, void * Buffer, int32_t Size, int8_t ReadOnly, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_SaveToBuffer(TElASN1CustomTagHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_CheckType(TElASN1CustomTagHandle _Handle, uint8_t TagId, int8_t Constrained, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_LoadFromStream(TElASN1CustomTagHandle _Handle, TStreamHandle Stream, int64_t Count, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_LoadFromStream_1(TElASN1CustomTagHandle _Handle, TStreamHandle Stream, int8_t ReadOnly, int64_t Count, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_SaveToStream(TElASN1CustomTagHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_get_TagId(TElASN1CustomTagHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_set_TagId(TElASN1CustomTagHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_get_UndefSize(TElASN1CustomTagHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_set_UndefSize(TElASN1CustomTagHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_get_WriteHeader(TElASN1CustomTagHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_set_WriteHeader(TElASN1CustomTagHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_get_IsConstrained(TElASN1CustomTagHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_get_TagNum(TElASN1CustomTagHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_get_TagOffset(TElASN1CustomTagHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_get_TagSize(TElASN1CustomTagHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_get_TagHeaderSize(TElASN1CustomTagHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_get_TagContentSize(TElASN1CustomTagHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_get_Depth(TElASN1CustomTagHandle _Handle, int16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_get_ReadOnly(TElASN1CustomTagHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1CustomTag_Create(TElASN1CustomTagHandle * OutResult);
#endif /* SB_USE_CLASS_TELASN1CUSTOMTAG */

#ifdef SB_USE_CLASS_TELASN1CONSTRAINEDTAG
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_CreateInstance(TElASN1ConstrainedTagHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_CreateInstance_1(TElASN1ConstrainedTagHandle _Handle, TElASN1ConstrainedTagHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_LoadFromBuffer(TElASN1ConstrainedTagHandle _Handle, void * Buffer, int32_t Size, int8_t ReadOnly, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_LoadFromBuffer_1(TElASN1CustomTagHandle _Handle, void * Buffer, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_LoadFromBufferSingle(TElASN1ConstrainedTagHandle _Handle, void * Buffer, int32_t Size, int8_t ReadOnly, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_LoadFromBufferSingle_1(TElASN1ConstrainedTagHandle _Handle, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_SaveToBuffer(TElASN1ConstrainedTagHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_SaveContentToBuffer(TElASN1ConstrainedTagHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_LoadFromStream(TElASN1ConstrainedTagHandle _Handle, TStreamHandle Stream, int8_t ReadOnly, int64_t Count, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_LoadFromStream_1(TElASN1CustomTagHandle _Handle, TStreamHandle Stream, int64_t Count, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_LoadFromStreamSingle(TElASN1ConstrainedTagHandle _Handle, TStreamHandle Stream, int8_t ReadOnly, int64_t Count, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_LoadFromStreamSingle_1(TElASN1ConstrainedTagHandle _Handle, TStreamHandle Stream, int64_t Count, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_SaveToStream(TElASN1ConstrainedTagHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_AddField(TElASN1ConstrainedTagHandle _Handle, int8_t Constrained, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_AddSimpleField(TElASN1ConstrainedTagHandle _Handle, int32_t TagID, const uint8_t pValue[], int32_t szValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_AddSimpleField_1(TElASN1ConstrainedTagHandle _Handle, int32_t TagID, const uint8_t pValue[], int32_t szValue, int32_t StartIndex, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_RemoveField(TElASN1ConstrainedTagHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_GetField(TElASN1ConstrainedTagHandle _Handle, int32_t Index, TElASN1CustomTagHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_Clear(TElASN1ConstrainedTagHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_SaveToString(TElASN1ConstrainedTagHandle _Handle, TSBASN1DisplayFormatRaw DisplayFormat, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_get_Count(TElASN1ConstrainedTagHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_get_MaxSimpleTagLength(TElASN1ConstrainedTagHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_set_MaxSimpleTagLength(TElASN1ConstrainedTagHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_get_StreamAccess(TElASN1ConstrainedTagHandle _Handle, TSBASN1StreamAccessRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_set_StreamAccess(TElASN1ConstrainedTagHandle _Handle, TSBASN1StreamAccessRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1ConstrainedTag_Create(TElASN1ConstrainedTagHandle * OutResult);
#endif /* SB_USE_CLASS_TELASN1CONSTRAINEDTAG */

#ifdef SB_USE_CLASS_TELASN1DATASOURCE
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_Init(TElASN1DataSourceHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_Init_1(TElASN1DataSourceHandle _Handle, TStreamHandle Stream, int64_t Offset, int64_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_Init_2(TElASN1DataSourceHandle _Handle, TStreamHandle Stream, int8_t UnknownSize);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_Init_3(TElASN1DataSourceHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_Init_4(TElASN1DataSourceHandle _Handle, TElASN1ConstrainedTagHandle RootTag, int64_t Offset, int64_t Length);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_InitNoCopy(TElASN1DataSourceHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_InitVirtual(TElASN1DataSourceHandle _Handle, int64_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_Read(TElASN1DataSourceHandle _Handle, void * Buffer, int32_t Size, int64_t Offset, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_Clone(TElASN1DataSourceHandle _Handle, TElASN1DataSourceHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_CloneVirtual(TElASN1DataSourceHandle _Handle, TElASN1DataSourceHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_ToBuffer(TElASN1DataSourceHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_get_Size(TElASN1DataSourceHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_get_UnknownSize(TElASN1DataSourceHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_get_SkipVirtualData(TElASN1DataSourceHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_set_SkipVirtualData(TElASN1DataSourceHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_get_SourceType(TElASN1DataSourceHandle _Handle, TSBASN1DataSourceTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_get_OnVirtualDataNeeded(TElASN1DataSourceHandle _Handle, TSBASN1VirtualDataNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_set_OnVirtualDataNeeded(TElASN1DataSourceHandle _Handle, TSBASN1VirtualDataNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1DataSource_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELASN1DATASOURCE */

#ifdef SB_USE_CLASS_TELASN1SIMPLETAG
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_CreateInstance(TElASN1SimpleTagHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_CreateInstance_1(TElASN1SimpleTagHandle _Handle, TElASN1SimpleTagHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_LoadFromBuffer(TElASN1SimpleTagHandle _Handle, void * Buffer, int32_t Size, int8_t ReadOnly, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_LoadFromBuffer_1(TElASN1CustomTagHandle _Handle, void * Buffer, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_SaveToBuffer(TElASN1SimpleTagHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_LoadFromStream(TElASN1SimpleTagHandle _Handle, TStreamHandle Stream, int8_t ReadOnly, int64_t Count, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_LoadFromStream_1(TElASN1CustomTagHandle _Handle, TStreamHandle Stream, int64_t Count, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_SaveToStream(TElASN1SimpleTagHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_get_Content(TElASN1SimpleTagHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_set_Content(TElASN1SimpleTagHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_get_DataSource(TElASN1SimpleTagHandle _Handle, TElASN1DataSourceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_get_FragmentSize(TElASN1SimpleTagHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_set_FragmentSize(TElASN1SimpleTagHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_get_OnContentWriteBegin(TElASN1SimpleTagHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_set_OnContentWriteBegin(TElASN1SimpleTagHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_get_OnContentWriteEnd(TElASN1SimpleTagHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_set_OnContentWriteEnd(TElASN1SimpleTagHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SimpleTag_Create(TElASN1SimpleTagHandle * OutResult);
#endif /* SB_USE_CLASS_TELASN1SIMPLETAG */

#ifdef SB_USE_CLASS_TELASN1TAGINFO
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_Reset(TElASN1TagInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_SaveToString(TElASN1TagInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_SaveToStringFullPath(TElASN1TagInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_get_TagID(TElASN1TagInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_get_Constrained(TElASN1TagInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_get_Offset(TElASN1TagInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_get_Size(TElASN1TagInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_get_UndefSize(TElASN1TagInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_get_HeaderSize(TElASN1TagInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_get_ContentOffset(TElASN1TagInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_get_ContentSize(TElASN1TagInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_get_Parent(TElASN1TagInfoHandle _Handle, TElASN1TagInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_get_Depth(TElASN1TagInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_get_Index(TElASN1TagInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_get_Data(TElASN1TagInfoHandle _Handle, void * * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_set_Data(TElASN1TagInfoHandle _Handle, void * Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfo_Create(TElASN1TagInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELASN1TAGINFO */

#ifdef SB_USE_CLASS_TELASN1STREAMPROCESSOR
SB_IMPORT uint32_t SB_APIENTRY TElASN1StreamProcessor_Reset(TElASN1StreamProcessorHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASN1StreamProcessor_ProcessBuffer(TElASN1StreamProcessorHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1StreamProcessor_ProcessBuffer_1(TElASN1StreamProcessorHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int8_t SingleTag, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1StreamProcessor_ProcessBuffer_2(TElASN1StreamProcessorHandle _Handle, void * Buffer, int32_t Size, int8_t SingleTag, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1StreamProcessor_ProcessStream(TElASN1StreamProcessorHandle _Handle, TStreamHandle Stream, int64_t Count, int8_t OnePass, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1StreamProcessor_ProcessStream_1(TElASN1StreamProcessorHandle _Handle, TStreamHandle Stream, int64_t Count, int8_t OnePass, int8_t SingleTag, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1StreamProcessor_get_OnTagBegin(TElASN1StreamProcessorHandle _Handle, TSBASN1StreamProcessorTagBeginEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1StreamProcessor_set_OnTagBegin(TElASN1StreamProcessorHandle _Handle, TSBASN1StreamProcessorTagBeginEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1StreamProcessor_get_OnTagEnd(TElASN1StreamProcessorHandle _Handle, TSBASN1StreamProcessorTagEndEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1StreamProcessor_set_OnTagEnd(TElASN1StreamProcessorHandle _Handle, TSBASN1StreamProcessorTagEndEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1StreamProcessor_get_OnTagData(TElASN1StreamProcessorHandle _Handle, TSBASN1StreamProcessorTagDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1StreamProcessor_set_OnTagData(TElASN1StreamProcessorHandle _Handle, TSBASN1StreamProcessorTagDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1StreamProcessor_Create(TElASN1StreamProcessorHandle * OutResult);
#endif /* SB_USE_CLASS_TELASN1STREAMPROCESSOR */

#ifdef SB_USE_CLASS_TELASN1TAGINFOFACTORY
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfoFactory_GetTagInfo(TElASN1TagInfoFactoryHandle _Handle, TElASN1TagInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfoFactory_ReleaseTagInfo(TElASN1TagInfoFactoryHandle _Handle, TElASN1TagInfoHandle * TagInfo);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfoFactory_Clear(TElASN1TagInfoFactoryHandle _Handle, int8_t ForceDestruction);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagInfoFactory_Create(TElASN1TagInfoFactoryHandle * OutResult);
#endif /* SB_USE_CLASS_TELASN1TAGINFOFACTORY */

#ifdef SB_USE_CLASS_TELASN1TAGPATH
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPath_InitFromString(TElASN1TagPathHandle _Handle, const char * pcS, int32_t szS);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPath_Reset(TElASN1TagPathHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPath_Assign(TElASN1TagPathHandle _Handle, TElASN1TagPathHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPath_AddElement(TElASN1TagPathHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPath_AddElement_1(TElASN1TagPathHandle _Handle, int32_t TagID, int8_t Constrained, int32_t MinIndex, int32_t MaxIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPath_RemoveElement(TElASN1TagPathHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPath_Clear(TElASN1TagPathHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPath_SaveToString(TElASN1TagPathHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPath_TagMatches(TElASN1TagPathHandle _Handle, TElASN1TagInfoHandle Tag, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPath_get_Elements(TElASN1TagPathHandle _Handle, int32_t Index, TElASN1TagPathElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPath_get_ElementCount(TElASN1TagPathHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPath_Create(TElASN1TagPathHandle * OutResult);
#endif /* SB_USE_CLASS_TELASN1TAGPATH */

#ifdef SB_USE_CLASS_TELASN1TAGPATHELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPathElement_Reset(TElASN1TagPathElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPathElement_InitFromString(TElASN1TagPathElementHandle _Handle, const char * pcS, int32_t szS);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPathElement_Assign(TElASN1TagPathElementHandle _Handle, TElASN1TagPathElementHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPathElement_SaveToString(TElASN1TagPathElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPathElement_TagMatches(TElASN1TagPathElementHandle _Handle, TElASN1TagInfoHandle Tag, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPathElement_Equals(TElASN1TagPathElementHandle _Handle, int32_t TagID, int8_t Constrained, int32_t MinIndex, int32_t MaxIndex, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPathElement_get_TagID(TElASN1TagPathElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPathElement_get_TagConstrained(TElASN1TagPathElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPathElement_get_MinIndex(TElASN1TagPathElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPathElement_set_MinIndex(TElASN1TagPathElementHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPathElement_get_MaxIndex(TElASN1TagPathElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPathElement_set_MaxIndex(TElASN1TagPathElementHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1TagPathElement_Create(TElASN1TagPathElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELASN1TAGPATHELEMENT */

#ifdef SB_USE_CLASS_TELASN1SMARTSTREAMPROCESSOR
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_Reset(TElASN1SmartStreamProcessorHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_ProcessBuffer(TElASN1SmartStreamProcessorHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_ProcessBuffer_1(TElASN1SmartStreamProcessorHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int8_t SingleTag, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_ProcessBuffer_2(TElASN1SmartStreamProcessorHandle _Handle, void * Buffer, int32_t Size, int8_t SingleTag, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_ProcessStream(TElASN1SmartStreamProcessorHandle _Handle, TStreamHandle Stream, int64_t Count, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_ProcessStream_1(TElASN1SmartStreamProcessorHandle _Handle, TStreamHandle Stream, int64_t Count, int8_t SingleTag, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_AddKnownPath(TElASN1SmartStreamProcessorHandle _Handle, TElASN1TagPathHandle Path, TSBASN1TagPathHandler pMethodHandler, void * pDataHandler, int8_t TransferOwnership, int8_t CreateCopy, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_AddKnownPath_1(TElASN1SmartStreamProcessorHandle _Handle, const char * pcPath, int32_t szPath, TSBASN1TagPathHandler pMethodHandler, void * pDataHandler, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_AddKnownPath_2(TElASN1SmartStreamProcessorHandle _Handle, const char * pcPath, int32_t szPath, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_RemoveKnownPath(TElASN1SmartStreamProcessorHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_ClearKnownPaths(TElASN1SmartStreamProcessorHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_get_Paths(TElASN1SmartStreamProcessorHandle _Handle, int32_t Index, TElASN1TagPathHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_get_PathCount(TElASN1SmartStreamProcessorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_get_TolerateUnknownPaths(TElASN1SmartStreamProcessorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_set_TolerateUnknownPaths(TElASN1SmartStreamProcessorHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_get_UserData(TElASN1SmartStreamProcessorHandle _Handle, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_set_UserData(TElASN1SmartStreamProcessorHandle _Handle, TObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_get_OnKnownPath(TElASN1SmartStreamProcessorHandle _Handle, TSBASN1TagPathHandler * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_set_OnKnownPath(TElASN1SmartStreamProcessorHandle _Handle, TSBASN1TagPathHandler pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_get_OnUnknownPath(TElASN1SmartStreamProcessorHandle _Handle, TSBASN1TagPathHandler * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_set_OnUnknownPath(TElASN1SmartStreamProcessorHandle _Handle, TSBASN1TagPathHandler pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElASN1SmartStreamProcessor_Create(TElASN1SmartStreamProcessorHandle * OutResult);
#endif /* SB_USE_CLASS_TELASN1SMARTSTREAMPROCESSOR */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElASN1CustomTag_ce_ptr;
extern zend_class_entry *TElASN1ConstrainedTag_ce_ptr;
extern zend_class_entry *TElASN1DataSource_ce_ptr;
extern zend_class_entry *TElASN1SimpleTag_ce_ptr;
extern zend_class_entry *TElASN1TagInfo_ce_ptr;
extern zend_class_entry *TElASN1StreamProcessor_ce_ptr;
extern zend_class_entry *TElASN1TagInfoFactory_ce_ptr;
extern zend_class_entry *TElASN1TagPath_ce_ptr;
extern zend_class_entry *TElASN1TagPathElement_ce_ptr;
extern zend_class_entry *TElASN1SmartStreamProcessor_ce_ptr;

void SB_CALLBACK TSBASN1VirtualDataNeededEventRaw(void * _ObjectData, TObjectHandle Sender, int64_t StartIndex, void * Buffer, int32_t MaxSize, int32_t * Read);
void SB_CALLBACK TSBASN1StreamProcessorTagBeginEventRaw(void * _ObjectData, TObjectHandle Sender, TElASN1TagInfoHandle TagInfo, int8_t * Skip);
void SB_CALLBACK TSBASN1StreamProcessorTagEndEventRaw(void * _ObjectData, TObjectHandle Sender, TElASN1TagInfoHandle TagInfo);
void SB_CALLBACK TSBASN1StreamProcessorTagDataEventRaw(void * _ObjectData, TObjectHandle Sender, TElASN1TagInfoHandle TagInfo, void * Buffer, int32_t Count, int8_t * SkipRest);
void SB_CALLBACK TSBASN1TagPathHandlerRaw(void * _ObjectData, TObjectHandle Sender, TElASN1TagPathHandle Path, TElASN1TagInfoHandle TagInfo, TSBASN1TagPathActionRaw * Action);
void Register_TElASN1CustomTag(TSRMLS_D);
void Register_TElASN1ConstrainedTag(TSRMLS_D);
void Register_TElASN1DataSource(TSRMLS_D);
void Register_TElASN1SimpleTag(TSRMLS_D);
void Register_TElASN1TagInfo(TSRMLS_D);
void Register_TElASN1StreamProcessor(TSRMLS_D);
void Register_TElASN1TagInfoFactory(TSRMLS_D);
void Register_TElASN1TagPath(TSRMLS_D);
void Register_TElASN1TagPathElement(TSRMLS_D);
void Register_TElASN1SmartStreamProcessor(TSRMLS_D);
SB_PHP_FUNCTION(SBASN1Tree, asymWriteInteger);
SB_PHP_FUNCTION(SBASN1Tree, ASN1ReadInteger);
SB_PHP_FUNCTION(SBASN1Tree, ASN1ReadInteger64);
SB_PHP_FUNCTION(SBASN1Tree, ASN1WriteInteger);
SB_PHP_FUNCTION(SBASN1Tree, ASN1WriteInteger64);
SB_PHP_FUNCTION(SBASN1Tree, ASN1ReadSimpleValue);
SB_PHP_FUNCTION(SBASN1Tree, ASN1WriteTagAndLength);
SB_PHP_FUNCTION(SBASN1Tree, ASN1ReadBoolean);
SB_PHP_FUNCTION(SBASN1Tree, ASN1WriteBoolean);
SB_PHP_FUNCTION(SBASN1Tree, ASN1ReadString);
SB_PHP_FUNCTION(SBASN1Tree, ASN1ReadStringAnsi);
SB_PHP_FUNCTION(SBASN1Tree, FormatAttributeValue);
SB_PHP_FUNCTION(SBASN1Tree, UnformatAttributeValue);
SB_PHP_FUNCTION(SBASN1Tree, GetTagDisplayName);
SB_PHP_FUNCTION(SBASN1Tree, GetTagByDisplayName);
SB_PHP_FUNCTION(SBASN1Tree, GetMaxASN1TreeDepth);
SB_PHP_FUNCTION(SBASN1Tree, SetMaxASN1TreeDepth);
SB_PHP_FUNCTION(SBASN1Tree, GetMaxASN1BufferLength);
SB_PHP_FUNCTION(SBASN1Tree, SetMaxASN1BufferLength);
SB_PHP_FUNCTION(SBASN1Tree, GetASN1CopyBuffers);
SB_PHP_FUNCTION(SBASN1Tree, SetASN1CopyBuffers);
SB_PHP_FUNCTION(SBASN1Tree, ASN1TagInfoFactory);
void Register_SBASN1Tree_Constants(int module_number TSRMLS_DC);
void Register_SBASN1Tree_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_ASN1TREE
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_asymWriteInteger(TElASN1SimpleTagHandle Tag, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_ASN1ReadInteger(TElASN1SimpleTagHandle Tag, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_ASN1ReadInteger64(TElASN1SimpleTagHandle Tag, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_ASN1WriteInteger(TElASN1SimpleTagHandle Tag, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_ASN1WriteInteger64(TElASN1SimpleTagHandle Tag, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_ASN1ReadSimpleValue(const uint8_t pData[], int32_t szData, int32_t * TagID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_ASN1WriteTagAndLength(int32_t Tag, int64_t Len, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_ASN1ReadBoolean(TElASN1SimpleTagHandle Tag, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_ASN1WriteBoolean(TElASN1SimpleTagHandle Tag, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_ASN1ReadString(const uint8_t pData[], int32_t szData, int32_t TagId, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_ASN1ReadStringAnsi(const uint8_t pData[], int32_t szData, int32_t TagId, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_FormatAttributeValue(int32_t TagID, const uint8_t pValue[], int32_t szValue, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_UnformatAttributeValue(const uint8_t pValue[], int32_t szValue, int32_t * TagID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_GetTagDisplayName(int32_t TagID, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_GetTagByDisplayName(const char * pcName, int32_t szName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_GetMaxASN1TreeDepth(int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_SetMaxASN1TreeDepth(int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_GetMaxASN1BufferLength(int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_SetMaxASN1BufferLength(int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_GetASN1CopyBuffers(int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_SetASN1CopyBuffers(int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY SBASN1Tree_ASN1TagInfoFactory(TElASN1TagInfoFactoryHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_ASN1TREE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBASN1TREE */

