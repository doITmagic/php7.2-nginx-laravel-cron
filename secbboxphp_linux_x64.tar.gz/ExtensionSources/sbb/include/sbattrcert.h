#ifndef __INC_SBATTRCERT
#define __INC_SBATTRCERT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbencoding.h"
#include "sbmath.h"
#include "sbrdn.h"
#include "sbasn1.h"
#include "sbpem.h"
#include "sbhashfunction.h"
#include "sbx509ext.h"
#include "sbcustomcrypto.h"
#include "sbsymmetriccrypto.h"
#include "sbpublickeycrypto.h"
#include "sbalgorithmidentifier.h"
#include "sbcryptoprov.h"
#include "sbasn1tree.h"
#include "sbx509.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_ATTRCERT 	37376
#define SB_ATTRCER_ERROR_WRONG_FORMAT 	37377
#define SB_ATTRCER_ERROR_FIELD_MISSING 	37378
#define SB_ATTRCER_ERROR_WRONG_FIELD 	37379
#define SB_OID_ATTRIBUTE_CERT 	"+\x06""\x01""\x05""\x05""\a\x00""\f"
#define SB_OID_AC_AUDIT_IDENTITY 	"+\x06""\x01""\x05""\x05""\a\x01""\x04"
#define SB_OID_AC_PROXYING 	"+\x06""\x01""\x05""\x05""\a\x01""\n"
#define SB_OID_AC_TARGET_INFORMATION 	"U\x1D""7"
#define SB_OID_AC_AA_CONTROLS 	"+\x06""\x01""\x05""\x05""\a\x01""\x06"
#define SB_OID_AC_AUTHENTICATION_INFO 	"+\x06""\x01""\x05""\x05""\a\n\x01"
#define SB_OID_AC_ACCESS_IDENTITY 	"+\x06""\x01""\x05""\x05""\a\n\x02"
#define SB_OID_AC_CHARGING_IDENTITY 	"+\x06""\x01""\x05""\x05""\a\n\x03"
#define SB_OID_AC_GROUP 	"+\x06""\x01""\x05""\x05""\a\n\x04"
#define SB_OID_AC_ENC_ATTRS 	"+\x06""\x01""\x05""\x05""\a\n\x06"
#define SB_OID_AC_AT_ROLE 	"U\x04""H"
#define SB_OID_AC_AT_CLEARANCE 	"U\x01""\x05""7"
#define SB_OID_AC_NO_REV_AVAIL 	"U\x1D""8"

typedef TElClassHandle TElACIssuerSerialHandle;

typedef TElClassHandle TElACObjectDigestInfoHandle;

typedef TElClassHandle TElACAttributeHandle;

typedef TElClassHandle TElACTargetsHandle;

typedef TElClassHandle TElACExtensionHandle;

typedef TElClassHandle TElACAuditIdentityExtensionHandle;

typedef TElClassHandle TElACTargetInformationExtensionHandle;

typedef TElClassHandle TElACAuthorityKeyIdentifierExtensionHandle;

typedef TElClassHandle TElACAuthorityInformationAccessExtensionHandle;

typedef TElClassHandle TElACCRLDistributionPointsExtensionHandle;

typedef TElClassHandle TElNoRevocationExtensionHandle;

typedef TElClassHandle TElACProxyInfoHandle;

typedef TElClassHandle TElACAttrSpecHandle;

typedef TElClassHandle TElACClearAttrsHandle;

typedef TElClassHandle TElACAAControlsHandle;

typedef TElClassHandle TElACSecurityCategoryHandle;

typedef TElClassHandle TElACClassListHandle;

typedef TElClassHandle TElACClearanceHandle;

typedef TElClassHandle TElACRoleSyntaxHandle;

typedef TElClassHandle TElACSvceAuthInfoHandle;

typedef TElClassHandle TElACIetfAttrSyntaxHandle;

typedef TElClassHandle TElACTargetCertHandle;

typedef TElClassHandle TElACTargetHandle;

typedef TElClassHandle TElACSvceAuthInfoBasedAttributeHandle;

typedef TElClassHandle TElACAuthenticationInfoAttributeHandle;

typedef TElClassHandle TElACAccessIndentityAttributeHandle;

typedef TElClassHandle TElACIetfAttrSyntaxBasedAttributeHandle;

typedef TElClassHandle TElACChargingIdentityAttributeHandle;

typedef TElClassHandle TElACGroupAttributeHandle;

typedef TElClassHandle TElACRoleAttributeHandle;

typedef TElClassHandle TElACClearanceAttributeHandle;

typedef TElClassHandle TElACValidityPeriodHandle;

typedef TElClassHandle TElACIssuerHandle;

typedef TElClassHandle TElACHolderHandle;

typedef TElClassHandle TElAttributeCertificateInfoHandle;

typedef TElClassHandle TElAttributeCertificateHandle;

typedef uint8_t TSBDigestedObjectTypeRaw;

typedef enum
{
	dotUnknown = 0,
	dotPublicKey = 1,
	dotPublicKeyCert = 2
} TSBDigestedObjectType;

#ifdef SB_USE_CLASS_TELACISSUERSERIAL
SB_IMPORT uint32_t SB_APIENTRY TElACIssuerSerial_LoadFromTag(TElACIssuerSerialHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACIssuerSerial_SaveToTag(TElACIssuerSerialHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACIssuerSerial_get_Issuer(TElACIssuerSerialHandle _Handle, TElGeneralNamesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACIssuerSerial_get_Serial(TElACIssuerSerialHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACIssuerSerial_set_Serial(TElACIssuerSerialHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElACIssuerSerial_get_IssuerUID(TElACIssuerSerialHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACIssuerSerial_set_IssuerUID(TElACIssuerSerialHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElACIssuerSerial_Create(TElACIssuerSerialHandle * OutResult);
#endif /* SB_USE_CLASS_TELACISSUERSERIAL */

#ifdef SB_USE_CLASS_TELACOBJECTDIGESTINFO
SB_IMPORT uint32_t SB_APIENTRY TElACObjectDigestInfo_LoadFromTag(TElACObjectDigestInfoHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACObjectDigestInfo_SaveToTag(TElACObjectDigestInfoHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACObjectDigestInfo_get_DigestedObjType(TElACObjectDigestInfoHandle _Handle, TSBDigestedObjectTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACObjectDigestInfo_set_DigestedObjType(TElACObjectDigestInfoHandle _Handle, TSBDigestedObjectTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElACObjectDigestInfo_get_DigestAlg(TElACObjectDigestInfoHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACObjectDigestInfo_set_DigestAlg(TElACObjectDigestInfoHandle _Handle, TElAlgorithmIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElACObjectDigestInfo_get_ObjDigest(TElACObjectDigestInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACObjectDigestInfo_set_ObjDigest(TElACObjectDigestInfoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElACObjectDigestInfo_Create(TElACObjectDigestInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELACOBJECTDIGESTINFO */

#ifdef SB_USE_CLASS_TELACATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElACAttribute_ExtractOID(TElASN1ConstrainedTagHandle Tag, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACAttribute_ExtractOID_1(TElACAttributeHandle _Handle, TElASN1ConstrainedTagHandle Tag, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACAttribute_CreateInstance(const uint8_t pOID[], int32_t szOID, TElACAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACAttribute_CreateInstance_1(TElACAttributeHandle _Handle, const uint8_t pOID[], int32_t szOID, TElACAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACAttribute_LoadFromTag(TElACAttributeHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACAttribute_SaveToTag(TElACAttributeHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACAttribute_get_AType(TElACAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACAttribute_set_AType(TElACAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElACAttribute_get_Values(TElACAttributeHandle _Handle, TElByteArrayListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACAttribute_Create(TElACAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELACATTRIBUTE */

#ifdef SB_USE_CLASS_TELACTARGETS
SB_IMPORT uint32_t SB_APIENTRY TElACTargets_LoadFromTag(TElACTargetsHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACTargets_SaveToTag(TElACTargetsHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACTargets_AddTarget(TElACTargetsHandle _Handle, TElACSecurityCategoryHandle Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACTargets_RemoveTarget(TElACTargetsHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElACTargets_get_Targets(TElACTargetsHandle _Handle, int32_t Index, TElACTargetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACTargets_get_TargetCount(TElACTargetsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACTargets_Create(TElACTargetsHandle * OutResult);
#endif /* SB_USE_CLASS_TELACTARGETS */

#ifdef SB_USE_CLASS_TELACEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElACExtension_LoadFromTag(TElACExtensionHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACExtension_SaveToTag(TElACExtensionHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACExtension_ExtractOID(TElASN1ConstrainedTagHandle Tag, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACExtension_ExtractOID_1(TElACExtensionHandle _Handle, TElASN1ConstrainedTagHandle Tag, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACExtension_CreateInstance(const uint8_t pOID[], int32_t szOID, TElACExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACExtension_CreateInstance_1(TElACExtensionHandle _Handle, const uint8_t pOID[], int32_t szOID, TElACExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACExtension_get_PKIXExtension(TElACExtensionHandle _Handle, TElCustomExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACExtension_get_IsPKIXExtension(TElACExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACExtension_Create(TElACExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELACEXTENSION */

#ifdef SB_USE_CLASS_TELACAUDITIDENTITYEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElACAuditIdentityExtension_Create(TElACAuditIdentityExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELACAUDITIDENTITYEXTENSION */

#ifdef SB_USE_CLASS_TELACTARGETINFORMATIONEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElACTargetInformationExtension_get_Targets(TElACTargetInformationExtensionHandle _Handle, TElACTargetsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACTargetInformationExtension_Create(TElACTargetInformationExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELACTARGETINFORMATIONEXTENSION */

#ifdef SB_USE_CLASS_TELACAUTHORITYKEYIDENTIFIEREXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElACAuthorityKeyIdentifierExtension_Create(TElACAuthorityKeyIdentifierExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELACAUTHORITYKEYIDENTIFIEREXTENSION */

#ifdef SB_USE_CLASS_TELACAUTHORITYINFORMATIONACCESSEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElACAuthorityInformationAccessExtension_Create(TElACAuthorityInformationAccessExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELACAUTHORITYINFORMATIONACCESSEXTENSION */

#ifdef SB_USE_CLASS_TELACCRLDISTRIBUTIONPOINTSEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElACCRLDistributionPointsExtension_Create(TElACCRLDistributionPointsExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELACCRLDISTRIBUTIONPOINTSEXTENSION */

#ifdef SB_USE_CLASS_TELNOREVOCATIONEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElNoRevocationExtension_Create(TElNoRevocationExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELNOREVOCATIONEXTENSION */

#ifdef SB_USE_CLASS_TELACPROXYINFO
SB_IMPORT uint32_t SB_APIENTRY TElACProxyInfo_LoadFromTag(TElACProxyInfoHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACProxyInfo_SaveToTag(TElACProxyInfoHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACProxyInfo_AddTargets(TElACProxyInfoHandle _Handle, TElACTargetsHandle Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACProxyInfo_RemoveTargets(TElACProxyInfoHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElACProxyInfo_get_Targets(TElACProxyInfoHandle _Handle, int32_t Index, TElACTargetsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACProxyInfo_get_TargetsCount(TElACProxyInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACProxyInfo_Create(TElACProxyInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELACPROXYINFO */

#ifdef SB_USE_CLASS_TELACATTRSPEC
SB_IMPORT uint32_t SB_APIENTRY TElACAttrSpec_LoadFromTag(TElACAttrSpecHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACAttrSpec_SaveToTag(TElACAttrSpecHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACAttrSpec_get_OIDs(TElACAttrSpecHandle _Handle, TElByteArrayListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACAttrSpec_Create(TElACAttrSpecHandle * OutResult);
#endif /* SB_USE_CLASS_TELACATTRSPEC */

#ifdef SB_USE_CLASS_TELACCLEARATTRS
SB_IMPORT uint32_t SB_APIENTRY TElACClearAttrs_LoadFromTag(TElACClearAttrsHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACClearAttrs_SaveToTag(TElACClearAttrsHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACClearAttrs_AddAttributes(TElACClearAttrsHandle _Handle, TElACAttributeHandle Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClearAttrs_RemoveAttribute(TElACClearAttrsHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElACClearAttrs_get_ACIssuer(TElACClearAttrsHandle _Handle, TElGeneralNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClearAttrs_get_ACSerial(TElACClearAttrsHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClearAttrs_set_ACSerial(TElACClearAttrsHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElACClearAttrs_get_Attributes(TElACClearAttrsHandle _Handle, int32_t Index, TElACAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClearAttrs_get_AttributeCount(TElACClearAttrsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClearAttrs_Create(TElACClearAttrsHandle * OutResult);
#endif /* SB_USE_CLASS_TELACCLEARATTRS */

#ifdef SB_USE_CLASS_TELACAACONTROLS
SB_IMPORT uint32_t SB_APIENTRY TElACAAControls_LoadFromTag(TElACAAControlsHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACAAControls_SaveToTag(TElACAAControlsHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACAAControls_get_PathLenConstraint(TElACAAControlsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACAAControls_set_PathLenConstraint(TElACAAControlsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElACAAControls_get_PermittedAttrs(TElACAAControlsHandle _Handle, TElACAttrSpecHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACAAControls_set_PermittedAttrs(TElACAAControlsHandle _Handle, TElACAttrSpecHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElACAAControls_get_ExcludedAttrs(TElACAAControlsHandle _Handle, TElACAttrSpecHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACAAControls_set_ExcludedAttrs(TElACAAControlsHandle _Handle, TElACAttrSpecHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElACAAControls_get_PermitSpecified(TElACAAControlsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACAAControls_set_PermitSpecified(TElACAAControlsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElACAAControls_Create(TElACAAControlsHandle * OutResult);
#endif /* SB_USE_CLASS_TELACAACONTROLS */

#ifdef SB_USE_CLASS_TELACSECURITYCATEGORY
SB_IMPORT uint32_t SB_APIENTRY TElACSecurityCategory_LoadFromTag(TElACSecurityCategoryHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACSecurityCategory_SaveToTag(TElACSecurityCategoryHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACSecurityCategory_get_AType(TElACSecurityCategoryHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACSecurityCategory_set_AType(TElACSecurityCategoryHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElACSecurityCategory_get_Value(TElACSecurityCategoryHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACSecurityCategory_set_Value(TElACSecurityCategoryHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElACSecurityCategory_get_SimpleValue(TElACSecurityCategoryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACSecurityCategory_set_SimpleValue(TElACSecurityCategoryHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElACSecurityCategory_Create(TElACSecurityCategoryHandle * OutResult);
#endif /* SB_USE_CLASS_TELACSECURITYCATEGORY */

#ifdef SB_USE_CLASS_TELACCLASSLIST
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_LoadFromTag(TElACClassListHandle _Handle, TElASN1SimpleTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_SaveToTag(TElACClassListHandle _Handle, TElASN1SimpleTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_get_Unmarked(TElACClassListHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_set_Unmarked(TElACClassListHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_get_Unclassified(TElACClassListHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_set_Unclassified(TElACClassListHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_get_Restricted(TElACClassListHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_set_Restricted(TElACClassListHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_get_Confidential(TElACClassListHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_set_Confidential(TElACClassListHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_get_Secret(TElACClassListHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_set_Secret(TElACClassListHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_get_TopSecret(TElACClassListHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_set_TopSecret(TElACClassListHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_get_Value(TElACClassListHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_set_Value(TElACClassListHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElACClassList_Create(TElACClassListHandle * OutResult);
#endif /* SB_USE_CLASS_TELACCLASSLIST */

#ifdef SB_USE_CLASS_TELACCLEARANCE
SB_IMPORT uint32_t SB_APIENTRY TElACClearance_LoadFromTag(TElACClearanceHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACClearance_SaveToTag(TElACClearanceHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACClearance_AddSecurityCategory(TElACClearanceHandle _Handle, TElACSecurityCategoryHandle Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClearance_RemoveSecurityCategory(TElACClearanceHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElACClearance_get_PolicyID(TElACClearanceHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClearance_set_PolicyID(TElACClearanceHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElACClearance_get_ClassList(TElACClearanceHandle _Handle, TElACClassListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClearance_get_SecurityCategories(TElACClearanceHandle _Handle, int32_t Index, TElACSecurityCategoryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClearance_get_SecurityCategoriesCount(TElACClearanceHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClearance_Create(TElACClearanceHandle * OutResult);
#endif /* SB_USE_CLASS_TELACCLEARANCE */

#ifdef SB_USE_CLASS_TELACROLESYNTAX
SB_IMPORT uint32_t SB_APIENTRY TElACRoleSyntax_LoadFromTag(TElACRoleSyntaxHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACRoleSyntax_SaveToTag(TElACRoleSyntaxHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACRoleSyntax_get_RoleAuthority(TElACRoleSyntaxHandle _Handle, TElGeneralNamesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACRoleSyntax_set_RoleAuthority(TElACRoleSyntaxHandle _Handle, TElGeneralNamesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElACRoleSyntax_get_RoleName(TElACRoleSyntaxHandle _Handle, TElGeneralNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACRoleSyntax_Create(TElACRoleSyntaxHandle * OutResult);
#endif /* SB_USE_CLASS_TELACROLESYNTAX */

#ifdef SB_USE_CLASS_TELACSVCEAUTHINFO
SB_IMPORT uint32_t SB_APIENTRY TElACSvceAuthInfo_LoadFromTag(TElACSvceAuthInfoHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACSvceAuthInfo_SaveToTag(TElACSvceAuthInfoHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACSvceAuthInfo_get_Service(TElACSvceAuthInfoHandle _Handle, TElGeneralNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACSvceAuthInfo_get_Ident(TElACSvceAuthInfoHandle _Handle, TElGeneralNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACSvceAuthInfo_get_AuthInfo(TElACSvceAuthInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACSvceAuthInfo_set_AuthInfo(TElACSvceAuthInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElACSvceAuthInfo_Create(TElACSvceAuthInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELACSVCEAUTHINFO */

#ifdef SB_USE_CLASS_TELACIETFATTRSYNTAX
SB_IMPORT uint32_t SB_APIENTRY TElACIetfAttrSyntax_LoadFromTag(TElACIetfAttrSyntaxHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACIetfAttrSyntax_SaveToTag(TElACIetfAttrSyntaxHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACIetfAttrSyntax_get_PolicyAuthority(TElACIetfAttrSyntaxHandle _Handle, TElGeneralNamesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACIetfAttrSyntax_set_PolicyAuthority(TElACIetfAttrSyntaxHandle _Handle, TElGeneralNamesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElACIetfAttrSyntax_get_Values(TElACIetfAttrSyntaxHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACIetfAttrSyntax_get_ValuesType(TElACIetfAttrSyntaxHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACIetfAttrSyntax_set_ValuesType(TElACIetfAttrSyntaxHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElACIetfAttrSyntax_Create(TElACIetfAttrSyntaxHandle * OutResult);
#endif /* SB_USE_CLASS_TELACIETFATTRSYNTAX */

#ifdef SB_USE_CLASS_TELACTARGETCERT
SB_IMPORT uint32_t SB_APIENTRY TElACTargetCert_LoadFromTag(TElACTargetCertHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACTargetCert_SaveToTag(TElACTargetCertHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACTargetCert_get_TargetCertificate(TElACTargetCertHandle _Handle, TElACIssuerSerialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACTargetCert_get_TargetName(TElACTargetCertHandle _Handle, TElGeneralNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACTargetCert_set_TargetName(TElACTargetCertHandle _Handle, TElGeneralNameHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElACTargetCert_get_CertDigestInfo(TElACTargetCertHandle _Handle, TElACObjectDigestInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACTargetCert_set_CertDigestInfo(TElACTargetCertHandle _Handle, TElACObjectDigestInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElACTargetCert_Create(TElACTargetCertHandle * OutResult);
#endif /* SB_USE_CLASS_TELACTARGETCERT */

#ifdef SB_USE_CLASS_TELACTARGET
SB_IMPORT uint32_t SB_APIENTRY TElACTarget_LoadFromTag(TElACTargetHandle _Handle, TElASN1CustomTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACTarget_SaveToTag(TElACTargetHandle _Handle, TElASN1SimpleTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACTarget_get_TargetName(TElACTargetHandle _Handle, TElGeneralNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACTarget_set_TargetName(TElACTargetHandle _Handle, TElGeneralNameHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElACTarget_get_TargetGroup(TElACTargetHandle _Handle, TElGeneralNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACTarget_set_TargetGroup(TElACTargetHandle _Handle, TElGeneralNameHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElACTarget_get_TargetCert(TElACTargetHandle _Handle, TElACTargetCertHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACTarget_set_TargetCert(TElACTargetHandle _Handle, TElACTargetCertHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElACTarget_Create(TElACTargetHandle * OutResult);
#endif /* SB_USE_CLASS_TELACTARGET */

#ifdef SB_USE_CLASS_TELACSVCEAUTHINFOBASEDATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElACSvceAuthInfoBasedAttribute_LoadFromTag(TElACSvceAuthInfoBasedAttributeHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACSvceAuthInfoBasedAttribute_SaveToTag(TElACSvceAuthInfoBasedAttributeHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACSvceAuthInfoBasedAttribute_AddAuthInfo(TElACSvceAuthInfoBasedAttributeHandle _Handle, TElACSvceAuthInfoHandle Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACSvceAuthInfoBasedAttribute_RemoveAuthInfo(TElACSvceAuthInfoBasedAttributeHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElACSvceAuthInfoBasedAttribute_get_AuthInfos(TElACSvceAuthInfoBasedAttributeHandle _Handle, int32_t Index, TElACSvceAuthInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACSvceAuthInfoBasedAttribute_get_AuthInfoCount(TElACSvceAuthInfoBasedAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACSvceAuthInfoBasedAttribute_Create(TElACSvceAuthInfoBasedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELACSVCEAUTHINFOBASEDATTRIBUTE */

#ifdef SB_USE_CLASS_TELACAUTHENTICATIONINFOATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElACAuthenticationInfoAttribute_Create(TElACAuthenticationInfoAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELACAUTHENTICATIONINFOATTRIBUTE */

#ifdef SB_USE_CLASS_TELACACCESSINDENTITYATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElACAccessIndentityAttribute_Create(TElACAccessIndentityAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELACACCESSINDENTITYATTRIBUTE */

#ifdef SB_USE_CLASS_TELACIETFATTRSYNTAXBASEDATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElACIetfAttrSyntaxBasedAttribute_LoadFromTag(TElACIetfAttrSyntaxBasedAttributeHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACIetfAttrSyntaxBasedAttribute_SaveToTag(TElACIetfAttrSyntaxBasedAttributeHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACIetfAttrSyntaxBasedAttribute_get_Value(TElACIetfAttrSyntaxBasedAttributeHandle _Handle, TElACIetfAttrSyntaxHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACIetfAttrSyntaxBasedAttribute_Create(TElACIetfAttrSyntaxBasedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELACIETFATTRSYNTAXBASEDATTRIBUTE */

#ifdef SB_USE_CLASS_TELACCHARGINGIDENTITYATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElACChargingIdentityAttribute_Create(TElACChargingIdentityAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELACCHARGINGIDENTITYATTRIBUTE */

#ifdef SB_USE_CLASS_TELACGROUPATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElACGroupAttribute_Create(TElACGroupAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELACGROUPATTRIBUTE */

#ifdef SB_USE_CLASS_TELACROLEATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElACRoleAttribute_LoadFromTag(TElACRoleAttributeHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACRoleAttribute_SaveToTag(TElACRoleAttributeHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACRoleAttribute_AddRole(TElACRoleAttributeHandle _Handle, TElACRoleSyntaxHandle Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACRoleAttribute_RemoveRole(TElACRoleAttributeHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElACRoleAttribute_get_Roles(TElACRoleAttributeHandle _Handle, int32_t Index, TElACRoleSyntaxHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACRoleAttribute_get_RoleCount(TElACRoleAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACRoleAttribute_Create(TElACRoleAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELACROLEATTRIBUTE */

#ifdef SB_USE_CLASS_TELACCLEARANCEATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElACClearanceAttribute_LoadFromTag(TElACClearanceAttributeHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACClearanceAttribute_SaveToTag(TElACClearanceAttributeHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACClearanceAttribute_AddClearance(TElACClearanceAttributeHandle _Handle, TElACClearanceHandle Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClearanceAttribute_RemoveClearance(TElACClearanceAttributeHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElACClearanceAttribute_get_Clearances(TElACClearanceAttributeHandle _Handle, int32_t Index, TElACClearanceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClearanceAttribute_get_ClearanceCount(TElACClearanceAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACClearanceAttribute_Create(TElACClearanceAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELACCLEARANCEATTRIBUTE */

#ifdef SB_USE_CLASS_TELACVALIDITYPERIOD
SB_IMPORT uint32_t SB_APIENTRY TElACValidityPeriod_LoadFromTag(TElACValidityPeriodHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACValidityPeriod_SaveToTag(TElACValidityPeriodHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACValidityPeriod_get_NotBeforeTime(TElACValidityPeriodHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACValidityPeriod_set_NotBeforeTime(TElACValidityPeriodHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElACValidityPeriod_get_NotAfterTime(TElACValidityPeriodHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACValidityPeriod_set_NotAfterTime(TElACValidityPeriodHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElACValidityPeriod_Create(TElACValidityPeriodHandle * OutResult);
#endif /* SB_USE_CLASS_TELACVALIDITYPERIOD */

#ifdef SB_USE_CLASS_TELACISSUER
SB_IMPORT uint32_t SB_APIENTRY TElACIssuer_LoadFromTag(TElACIssuerHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACIssuer_SaveToTag(TElACIssuerHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACIssuer_get_IssuerName(TElACIssuerHandle _Handle, TElGeneralNamesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACIssuer_Create(TElACIssuerHandle * OutResult);
#endif /* SB_USE_CLASS_TELACISSUER */

#ifdef SB_USE_CLASS_TELACHOLDER
SB_IMPORT uint32_t SB_APIENTRY TElACHolder_LoadFromTag(TElACHolderHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACHolder_SaveToTag(TElACHolderHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElACHolder_get_BaseCertID(TElACHolderHandle _Handle, TElACIssuerSerialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACHolder_set_BaseCertID(TElACHolderHandle _Handle, TElACIssuerSerialHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElACHolder_get_EntityName(TElACHolderHandle _Handle, TElGeneralNamesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACHolder_set_EntityName(TElACHolderHandle _Handle, TElGeneralNamesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElACHolder_get_ObjectDigestInfo(TElACHolderHandle _Handle, TElACObjectDigestInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElACHolder_set_ObjectDigestInfo(TElACHolderHandle _Handle, TElACObjectDigestInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElACHolder_Create(TElACHolderHandle * OutResult);
#endif /* SB_USE_CLASS_TELACHOLDER */

#ifdef SB_USE_CLASS_TELATTRIBUTECERTIFICATEINFO
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_LoadFromTag(TElAttributeCertificateInfoHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_SaveToTag(TElAttributeCertificateInfoHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_AddAttribute(TElAttributeCertificateInfoHandle _Handle, TElACAttributeHandle Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_RemoveAttribute(TElAttributeCertificateInfoHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_AddExtension(TElAttributeCertificateInfoHandle _Handle, TElACExtensionHandle Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_RemoveExtension(TElAttributeCertificateInfoHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_get_Version(TElAttributeCertificateInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_set_Version(TElAttributeCertificateInfoHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_get_Holder(TElAttributeCertificateInfoHandle _Handle, TElACHolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_get_Issuer(TElAttributeCertificateInfoHandle _Handle, TElACIssuerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_get_Signature(TElAttributeCertificateInfoHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_set_Signature(TElAttributeCertificateInfoHandle _Handle, TElAlgorithmIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_get_SerialNumber(TElAttributeCertificateInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_set_SerialNumber(TElAttributeCertificateInfoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_get_ValidityPeriod(TElAttributeCertificateInfoHandle _Handle, TElACValidityPeriodHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_get_IssuerUniqueID(TElAttributeCertificateInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_set_IssuerUniqueID(TElAttributeCertificateInfoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_get_Attributes(TElAttributeCertificateInfoHandle _Handle, int32_t Index, TElACAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_get_AttributeCount(TElAttributeCertificateInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_get_Extensions(TElAttributeCertificateInfoHandle _Handle, int32_t Index, TElACExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_get_ExtensionCount(TElAttributeCertificateInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateInfo_Create(TElAttributeCertificateInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELATTRIBUTECERTIFICATEINFO */

#ifdef SB_USE_CLASS_TELATTRIBUTECERTIFICATE
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificate_LoadFromStream(TElAttributeCertificateHandle _Handle, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificate_LoadFromFile(TElAttributeCertificateHandle _Handle, const char * pcFilename, int32_t szFilename);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificate_Validate(TElAttributeCertificateHandle _Handle, TElX509CertificateHandle IssuerCert, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificate_get_CryptoProvider(TElAttributeCertificateHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificate_set_CryptoProvider(TElAttributeCertificateHandle _Handle, TElCustomCryptoProviderHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificate_get_CryptoProviderManager(TElAttributeCertificateHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificate_set_CryptoProviderManager(TElAttributeCertificateHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificate_get_Data(TElAttributeCertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificate_get_CertInfo(TElAttributeCertificateHandle _Handle, TElAttributeCertificateInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificate_get_SignatureAlg(TElAttributeCertificateHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificate_get_SignatureValue(TElAttributeCertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificate_Create(TElAttributeCertificateHandle * OutResult);
#endif /* SB_USE_CLASS_TELATTRIBUTECERTIFICATE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElACIssuerSerial_ce_ptr;
extern zend_class_entry *TElACObjectDigestInfo_ce_ptr;
extern zend_class_entry *TElACAttribute_ce_ptr;
extern zend_class_entry *TElACTargets_ce_ptr;
extern zend_class_entry *TElACExtension_ce_ptr;
extern zend_class_entry *TElACAuditIdentityExtension_ce_ptr;
extern zend_class_entry *TElACTargetInformationExtension_ce_ptr;
extern zend_class_entry *TElACAuthorityKeyIdentifierExtension_ce_ptr;
extern zend_class_entry *TElACAuthorityInformationAccessExtension_ce_ptr;
extern zend_class_entry *TElACCRLDistributionPointsExtension_ce_ptr;
extern zend_class_entry *TElNoRevocationExtension_ce_ptr;
extern zend_class_entry *TElACProxyInfo_ce_ptr;
extern zend_class_entry *TElACAttrSpec_ce_ptr;
extern zend_class_entry *TElACClearAttrs_ce_ptr;
extern zend_class_entry *TElACAAControls_ce_ptr;
extern zend_class_entry *TElACSecurityCategory_ce_ptr;
extern zend_class_entry *TElACClassList_ce_ptr;
extern zend_class_entry *TElACClearance_ce_ptr;
extern zend_class_entry *TElACRoleSyntax_ce_ptr;
extern zend_class_entry *TElACSvceAuthInfo_ce_ptr;
extern zend_class_entry *TElACIetfAttrSyntax_ce_ptr;
extern zend_class_entry *TElACTargetCert_ce_ptr;
extern zend_class_entry *TElACTarget_ce_ptr;
extern zend_class_entry *TElACSvceAuthInfoBasedAttribute_ce_ptr;
extern zend_class_entry *TElACAuthenticationInfoAttribute_ce_ptr;
extern zend_class_entry *TElACAccessIndentityAttribute_ce_ptr;
extern zend_class_entry *TElACIetfAttrSyntaxBasedAttribute_ce_ptr;
extern zend_class_entry *TElACChargingIdentityAttribute_ce_ptr;
extern zend_class_entry *TElACGroupAttribute_ce_ptr;
extern zend_class_entry *TElACRoleAttribute_ce_ptr;
extern zend_class_entry *TElACClearanceAttribute_ce_ptr;
extern zend_class_entry *TElACValidityPeriod_ce_ptr;
extern zend_class_entry *TElACIssuer_ce_ptr;
extern zend_class_entry *TElACHolder_ce_ptr;
extern zend_class_entry *TElAttributeCertificateInfo_ce_ptr;
extern zend_class_entry *TElAttributeCertificate_ce_ptr;

void Register_TElACIssuerSerial(TSRMLS_D);
void Register_TElACObjectDigestInfo(TSRMLS_D);
void Register_TElACAttribute(TSRMLS_D);
void Register_TElACTargets(TSRMLS_D);
void Register_TElACExtension(TSRMLS_D);
void Register_TElACAuditIdentityExtension(TSRMLS_D);
void Register_TElACTargetInformationExtension(TSRMLS_D);
void Register_TElACAuthorityKeyIdentifierExtension(TSRMLS_D);
void Register_TElACAuthorityInformationAccessExtension(TSRMLS_D);
void Register_TElACCRLDistributionPointsExtension(TSRMLS_D);
void Register_TElNoRevocationExtension(TSRMLS_D);
void Register_TElACProxyInfo(TSRMLS_D);
void Register_TElACAttrSpec(TSRMLS_D);
void Register_TElACClearAttrs(TSRMLS_D);
void Register_TElACAAControls(TSRMLS_D);
void Register_TElACSecurityCategory(TSRMLS_D);
void Register_TElACClassList(TSRMLS_D);
void Register_TElACClearance(TSRMLS_D);
void Register_TElACRoleSyntax(TSRMLS_D);
void Register_TElACSvceAuthInfo(TSRMLS_D);
void Register_TElACIetfAttrSyntax(TSRMLS_D);
void Register_TElACTargetCert(TSRMLS_D);
void Register_TElACTarget(TSRMLS_D);
void Register_TElACSvceAuthInfoBasedAttribute(TSRMLS_D);
void Register_TElACAuthenticationInfoAttribute(TSRMLS_D);
void Register_TElACAccessIndentityAttribute(TSRMLS_D);
void Register_TElACIetfAttrSyntaxBasedAttribute(TSRMLS_D);
void Register_TElACChargingIdentityAttribute(TSRMLS_D);
void Register_TElACGroupAttribute(TSRMLS_D);
void Register_TElACRoleAttribute(TSRMLS_D);
void Register_TElACClearanceAttribute(TSRMLS_D);
void Register_TElACValidityPeriod(TSRMLS_D);
void Register_TElACIssuer(TSRMLS_D);
void Register_TElACHolder(TSRMLS_D);
void Register_TElAttributeCertificateInfo(TSRMLS_D);
void Register_TElAttributeCertificate(TSRMLS_D);
SB_PHP_FUNCTION(SBAttrCert, ACWriteBitString);
SB_PHP_FUNCTION(SBAttrCert, ACReadBitString);
void Register_SBAttrCert_Constants(int module_number TSRMLS_DC);
void Register_SBAttrCert_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_ATTRCERT
SB_IMPORT uint32_t SB_APIENTRY SBAttrCert_ACWriteBitString(const uint8_t pBuf[], int32_t szBuf, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBAttrCert_ACReadBitString(const uint8_t pBuf[], int32_t szBuf, uint8_t pOutResult[], int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_ATTRCERT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBATTRCERT */

