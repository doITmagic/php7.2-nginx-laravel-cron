#ifndef __INC_SBATTRCERTEX
#define __INC_SBATTRCERTEX

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbencoding.h"
#include "sbmath.h"
#include "sbrdn.h"
#include "sbasn1.h"
#include "sbpem.h"
#include "sbhashfunction.h"
#include "sbx509ext.h"
#include "sbcustomcrypto.h"
#include "sbsymmetriccrypto.h"
#include "sbpublickeycrypto.h"
#include "sbalgorithmidentifier.h"
#include "sbcryptoprov.h"
#include "sbasn1tree.h"
#include "sbx509.h"
#include "sbattrcert.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_ATTRCERT_EX 	37632
#define SB_ATTRCER_ERROR_NO_SIGN_CERT 	37633
#define SB_ATTRCER_ERROR_NO_PRIVATE_KEY 	37634
#define SB_ATTRCER_ERROR_UNSUPPORTED_CERT_TYPE 	37635

typedef TElClassHandle TElAttributeCertificateExHandle;

#ifdef SB_USE_CLASS_TELATTRIBUTECERTIFICATEEX
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateEx_SaveToStream(TElAttributeCertificateExHandle _Handle, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateEx_SaveToFile(TElAttributeCertificateExHandle _Handle, const char * pcFilename, int32_t szFilename);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateEx_get_SigningCert(TElAttributeCertificateExHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateEx_set_SigningCert(TElAttributeCertificateExHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateEx_get_PreferredHashAlgorithm(TElAttributeCertificateExHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateEx_set_PreferredHashAlgorithm(TElAttributeCertificateExHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeCertificateEx_Create(TElAttributeCertificateExHandle * OutResult);
#endif /* SB_USE_CLASS_TELATTRIBUTECERTIFICATEEX */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElAttributeCertificateEx_ce_ptr;

void Register_TElAttributeCertificateEx(TSRMLS_D);
void Register_SBAttrCertEx_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBATTRCERTEX */

