#ifndef __INC_SBAUTHDATASTREAM
#define __INC_SBAUTHDATASTREAM

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstringlist.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbcryptoprov.h"
#include "sbhashfunction.h"
#include "sbsymmetriccrypto.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElAuthenticatedDataWriteStreamHandle;

typedef TElClassHandle TElAuthenticatedDataReadStreamHandle;

typedef uint8_t TSBAuthenticatedDataDigestsLocationRaw;

typedef enum
{
	addlNoDigests = 0,
	addlExternal = 1,
	addlEmbedded = 2,
	addlAppended = 3
} TSBAuthenticatedDataDigestsLocation;

#ifdef SB_USE_CLASS_TELAUTHENTICATEDDATAWRITESTREAM
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataWriteStream_Read(TElAuthenticatedDataWriteStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataWriteStream_Write(TElAuthenticatedDataWriteStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataWriteStream_Seek(TElAuthenticatedDataWriteStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataWriteStream_Seek_1(TElAuthenticatedDataWriteStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataWriteStream_get_CachedDigests(TElAuthenticatedDataWriteStreamHandle _Handle, TElByteArrayListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataWriteStream_get_OnProgress(TElAuthenticatedDataWriteStreamHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataWriteStream_set_OnProgress(TElAuthenticatedDataWriteStreamHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataWriteStream_Create(TStreamHandle SourceStream, int32_t Algorithm, int64_t BlockSize, int32_t DigestSize, TSBAuthenticatedDataDigestsLocationRaw DigestsLocation, const uint8_t pKey[], int32_t szKey, int64_t StartBlockNumber, int64_t Count, TElCustomCryptoProviderManagerHandle Manager, TElAuthenticatedDataWriteStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELAUTHENTICATEDDATAWRITESTREAM */

#ifdef SB_USE_CLASS_TELAUTHENTICATEDDATAREADSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataReadStream_FinalizeOutput(TElAuthenticatedDataReadStreamHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataReadStream_Read(TElAuthenticatedDataReadStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataReadStream_Write(TElAuthenticatedDataReadStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataReadStream_Seek(TElAuthenticatedDataReadStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataReadStream_Seek_1(TElAuthenticatedDataReadStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataReadStream_get_ExpectFinalize(TElAuthenticatedDataReadStreamHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataReadStream_set_ExpectFinalize(TElAuthenticatedDataReadStreamHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataReadStream_get_CachedDigests(TElAuthenticatedDataReadStreamHandle _Handle, TElByteArrayListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataReadStream_get_OnProgress(TElAuthenticatedDataReadStreamHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataReadStream_set_OnProgress(TElAuthenticatedDataReadStreamHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataReadStream_Create(TStreamHandle DestStream, int32_t Algorithm, int64_t BlockSize, int32_t DigestSize, TSBAuthenticatedDataDigestsLocationRaw DigestsLocation, const uint8_t pKey[], int32_t szKey, int64_t StartBlockNumber, TElCustomCryptoProviderManagerHandle Manager, TElAuthenticatedDataReadStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELAUTHENTICATEDDATAREADSTREAM */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElAuthenticatedDataWriteStream_ce_ptr;
extern zend_class_entry *TElAuthenticatedDataReadStream_ce_ptr;

void Register_TElAuthenticatedDataWriteStream(TSRMLS_D);
void Register_TElAuthenticatedDataReadStream(TSRMLS_D);
void Register_SBAuthDataStream_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBAUTHDATASTREAM */

