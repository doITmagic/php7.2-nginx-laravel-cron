#ifndef __INC_SBAUTHENTICODE
#define __INC_SBAUTHENTICODE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbpkicommon.h"
#include "sbcms.h"
#include "sbpkcs7.h"
#include "sbpkcs7utils.h"
#include "sbhashfunction.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbencoding.h"
#include "sbx509.h"
#include "sbtspclient.h"
#include "sbcustomcertstorage.h"
#include "sbstreams.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_acMD5 	
#define SB_acSHA1 	
#define SB_acSHA224 	
#define SB_acSHA256 	
#define SB_acSHA384 	
#define SB_acSHA512 	
#define SB_acSHA3_224 	
#define SB_acSHA3_256 	
#define SB_acSHA3_384 	
#define SB_acSHA3_512 	
#define SB_acPrivate 	
#define SB_acCommercial 	
#define SB_AUTHENTICODE_ERROR_BASE 	9216
#define SB_AUTHENTICODE_ERROR_INVALID_ARGUMENT 	9217
#define SB_AUTHENTICODE_ERROR_CANCELLED 	9218
#define SB_AUTHENTICODE_ERROR_FILE_TOO_SMALL 	9219
#define SB_AUTHENTICODE_ERROR_INVALID_EXECUTABLE 	9220
#define SB_AUTHENTICODE_ERROR_INVALID_PE_FORMAT 	9221
#define SB_AUTHENTICODE_ERROR_NO_SIGNATURES 	9222
#define SB_AUTHENTICODE_ERROR_SIGNATURE_CORRUPTED 	9223
#define SB_AUTHENTICODE_ERROR_FILE_NOT_OPEN 	9224
#define SB_AUTHENTICODE_ERROR_SIGNATURE_NOT_LAST 	9225
#define SB_AUTHENTICODE_ERROR_SIGNATURE_TIMESTAMPED 	9226
#define SB_AUTHENTICODE_ERROR_CANNOT_TIMESTAMP 	9227
#define SB_AUTHENTICODE_ERROR_INVALID_TIMESTAMP 	9228
#define SB_AUTHENTICODE_ERROR_NO_PENDING_TIMESTAMP 	9229
#define SB_AUTHENTICODE_ERROR_SIGNATURE_NOT_SUPPORTED 	9230

typedef TElClassHandle TElAuthenticodeChecksumHandle;

typedef TElClassHandle TElAuthenticodeManagerHandle;

typedef TElClassHandle TElAuthenticodeSignatureHandle;

typedef TElClassHandle TElAuthenticodeTimestampHandle;

typedef TElAuthenticodeManagerHandle ElAuthenticodeProcessorHandle;

typedef uint8_t TSBAuthenticodeDigestAlgorithmRaw;

typedef enum
{
	acdUnknown = 0,
	acdMD5 = 1,
	acdSHA1 = 2,
	acdSHA224 = 3,
	acdSHA256 = 4,
	acdSHA384 = 5,
	acdSHA512 = 6,
	acdSHA3_224 = 7,
	acdSHA3_256 = 8,
	acdSHA3_384 = 9,
	acdSHA3_512 = 10
} TSBAuthenticodeDigestAlgorithm;

typedef uint8_t TSBAuthenticodeStatementTypeRaw;

typedef enum
{
	acsUnknown = 0,
	acsIndividual = 1,
	acsCommercial = 2
} TSBAuthenticodeStatementType;

typedef uint8_t TSBAuthenticodeValidityRaw;

typedef enum
{
	acvUnknown = 0,
	acvValid = 1,
	acvInvalid = 2,
	acvCorrupted = 3,
	acvNoSigner = 4,
	acvFileChanged = 5
} TSBAuthenticodeValidity;

typedef uint8_t TSBAuthenticodeTimestampTypeRaw;

typedef enum
{
	actLegacy = 0,
	actTrusted = 1
} TSBAuthenticodeTimestampType;

#ifdef SB_USE_CLASS_TELAUTHENTICODECHECKSUM
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeChecksum_Clear(TElAuthenticodeChecksumHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeChecksum_Clone(TElAuthenticodeChecksumHandle _Handle, TElAuthenticodeChecksumHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeChecksum_Finish(TElAuthenticodeChecksumHandle _Handle, uint32_t DataSize, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeChecksum_Update(TElAuthenticodeChecksumHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeChecksum_Update_1(TElAuthenticodeChecksumHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Offset, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeChecksum_Create(TElAuthenticodeChecksumHandle * OutResult);
#endif /* SB_USE_CLASS_TELAUTHENTICODECHECKSUM */

#ifdef SB_USE_CLASS_TELAUTHENTICODEMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_MoveSignature(TElAuthenticodeManagerHandle _Handle, int32_t CurrentIndex, int32_t NewIndex);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_RemoveSignature(TElAuthenticodeManagerHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_AddSignature(TElAuthenticodeManagerHandle _Handle, TSBAuthenticodeDigestAlgorithmRaw DigestAlgorithm, TElX509CertificateHandle SigningCertificate, TSBAuthenticodeStatementTypeRaw StatementType, const char * pcDescription, int32_t szDescription, const char * pcURL, int32_t szURL, int8_t IncludeSigningTime, TElAuthenticodeSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_RemoveSignatures(TElAuthenticodeManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_Open(TElAuthenticodeManagerHandle _Handle, TStreamHandle Stream, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_Open_1(TElAuthenticodeManagerHandle _Handle, const char * pcFileName, int32_t szFileName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_Save(TElAuthenticodeManagerHandle _Handle, TStreamHandle NewStream);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_Save_1(TElAuthenticodeManagerHandle _Handle, const char * pcNewFileName, int32_t szNewFileName);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_Close(TElAuthenticodeManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_get_ActualChecksum(TElAuthenticodeManagerHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_get_ReadOnly(TElAuthenticodeManagerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_get_SignatureCount(TElAuthenticodeManagerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_get_Signatures(TElAuthenticodeManagerHandle _Handle, int32_t Index, TElAuthenticodeSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_get_SpecifiedChecksum(TElAuthenticodeManagerHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_get_BufferSize(TElAuthenticodeManagerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_set_BufferSize(TElAuthenticodeManagerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_get_OnProgress(TElAuthenticodeManagerHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_set_OnProgress(TElAuthenticodeManagerHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeManager_Create(TComponentHandle AOwner, TElAuthenticodeManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELAUTHENTICODEMANAGER */

#ifdef SB_USE_CLASS_TELAUTHENTICODESIGNATURE
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_Move(TElAuthenticodeSignatureHandle _Handle, int32_t NewIndex);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_Remove(TElAuthenticodeSignatureHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_StartTimestamp(TElAuthenticodeSignatureHandle _Handle, TSBAuthenticodeTimestampTypeRaw TimestampType, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_CompleteTimestamp(TElAuthenticodeSignatureHandle _Handle, const uint8_t pTimestampResponse[], int32_t szTimestampResponse);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_CancelTimestamp(TElAuthenticodeSignatureHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_RemoveTimestamp(TElAuthenticodeSignatureHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_ActualDigest(TElAuthenticodeSignatureHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_Certificates(TElAuthenticodeSignatureHandle _Handle, TElMemoryCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_Description(TElAuthenticodeSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_ErrorCode(TElAuthenticodeSignatureHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_ErrorMessage(TElAuthenticodeSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_FileDigest(TElAuthenticodeSignatureHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_FileDigestAlgorithm(TElAuthenticodeSignatureHandle _Handle, TSBAuthenticodeDigestAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_FileDigestOID(TElAuthenticodeSignatureHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_Index(TElAuthenticodeSignatureHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_set_Index(TElAuthenticodeSignatureHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_SignatureDigest(TElAuthenticodeSignatureHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_SignatureDigestAlgorithm(TElAuthenticodeSignatureHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_SignatureDigestOID(TElAuthenticodeSignatureHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_Signer(TElAuthenticodeSignatureHandle _Handle, TElPKCS7IssuerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_SigningCertificate(TElAuthenticodeSignatureHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_SigningTime(TElAuthenticodeSignatureHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_StatementOID(TElAuthenticodeSignatureHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_StatementType(TElAuthenticodeSignatureHandle _Handle, TSBAuthenticodeStatementTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_Timestamp(TElAuthenticodeSignatureHandle _Handle, TElAuthenticodeTimestampHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_URL(TElAuthenticodeSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_get_Validity(TElAuthenticodeSignatureHandle _Handle, TSBAuthenticodeValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeSignature_Create(TElAuthenticodeManagerHandle AOwner, TElAuthenticodeSignatureHandle * OutResult);
#endif /* SB_USE_CLASS_TELAUTHENTICODESIGNATURE */

#ifdef SB_USE_CLASS_TELAUTHENTICODETIMESTAMP
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeTimestamp_Remove(TElAuthenticodeTimestampHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeTimestamp_get_ActualDigest(TElAuthenticodeTimestampHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeTimestamp_get_Signer(TElAuthenticodeTimestampHandle _Handle, TElPKCS7IssuerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeTimestamp_get_SignatureDigest(TElAuthenticodeTimestampHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeTimestamp_get_SignatureDigestAlgorithm(TElAuthenticodeTimestampHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeTimestamp_get_SignatureDigestOID(TElAuthenticodeTimestampHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeTimestamp_get_SigningCertificate(TElAuthenticodeTimestampHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeTimestamp_get_SigningTime(TElAuthenticodeTimestampHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeTimestamp_get_TimestampType(TElAuthenticodeTimestampHandle _Handle, TSBAuthenticodeTimestampTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeTimestamp_get_Validity(TElAuthenticodeTimestampHandle _Handle, TSBAuthenticodeValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticodeTimestamp_Create(TElAuthenticodeSignatureHandle AOwner, TSBAuthenticodeTimestampTypeRaw AType, TElAuthenticodeTimestampHandle * OutResult);
#endif /* SB_USE_CLASS_TELAUTHENTICODETIMESTAMP */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElAuthenticodeChecksum_ce_ptr;
extern zend_class_entry *TElAuthenticodeManager_ce_ptr;
extern zend_class_entry *TElAuthenticodeSignature_ce_ptr;
extern zend_class_entry *TElAuthenticodeTimestamp_ce_ptr;

void Register_TElAuthenticodeChecksum(TSRMLS_D);
void Register_TElAuthenticodeManager(TSRMLS_D);
void Register_TElAuthenticodeSignature(TSRMLS_D);
void Register_TElAuthenticodeTimestamp(TSRMLS_D);
SB_PHP_FUNCTION(SBAuthenticode, GetDigestAlgorithm);
SB_PHP_FUNCTION(SBAuthenticode, GetDigestAlgorithmOID);
SB_PHP_FUNCTION(SBAuthenticode, GetAuthenticodeDigestAlgorithm);
SB_PHP_FUNCTION(SBAuthenticode, GetAuthenticodeDigestAlgorithmName);
void Register_SBAuthenticode_Constants(int module_number TSRMLS_DC);
void Register_SBAuthenticode_Enum_Flags(TSRMLS_D);
void Register_SBAuthenticode_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_AUTHENTICODE
SB_IMPORT uint32_t SB_APIENTRY SBAuthenticode_GetDigestAlgorithm(TSBAuthenticodeDigestAlgorithmRaw Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBAuthenticode_GetDigestAlgorithmOID(TSBAuthenticodeDigestAlgorithmRaw Algorithm, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBAuthenticode_GetAuthenticodeDigestAlgorithm(int32_t Algorithm, TSBAuthenticodeDigestAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBAuthenticode_GetAuthenticodeDigestAlgorithm_1(const uint8_t pOID[], int32_t szOID, TSBAuthenticodeDigestAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBAuthenticode_GetAuthenticodeDigestAlgorithmName(TSBAuthenticodeDigestAlgorithmRaw Algorithm, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_AUTHENTICODE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBAUTHENTICODE */

