#ifndef __INC_SBAWSDATASTORAGE
#define __INC_SBAWSDATASTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbhttpscommon.h"
#include "sbhttpsclient.h"
#include "sbhttpsconstants.h"
#include "sbxmlutils.h"
#include "sbxmlcore.h"
#include "sbhashfunction.h"
#include "sbconstants.h"
#include "sbstringlist.h"
#include "sbstreams.h"
#include "sbencoding.h"
#include "sbdatastorage.h"
#include "sbdatastorageutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElAWSS3DataStorageHandle;

typedef TElClassHandle TElAWSS3DataStorageObjectHandle;

typedef TElClassHandle TElAWSS3DataStorageListStateHandle;

typedef TElClassHandle TElAWSS3AccessControlGrantHandle;

typedef TElClassHandle TElAWSS3AccessControlPolicyHandle;

typedef TElClassHandle TElAWSS3DataStorageBucketHandle;

typedef TElClassHandle TElAWSS3DataStorageBucketListHandle;

typedef uint8_t TSBAWSProtocolRaw;

typedef enum
{
	awspREST = 0,
	awspSOAP = 1
} TSBAWSProtocol;

typedef uint8_t TSBAWSAuthTypeRaw;

typedef enum
{
	awsaAccessKey = 0,
	awsaCertificate = 1
} TSBAWSAuthType;

typedef uint8_t TSBAWSS3ReadObjectConditionRaw;

typedef enum
{
	awsrNone = 0,
	awsrIfModifiedSince = 1,
	awsrIfUnmodifiedSince = 2,
	awsrIfMatch = 3,
	awsrIfNoneMatch = 4
} TSBAWSS3ReadObjectCondition;

typedef uint8_t TSBAWSS3BucketAccessTypeRaw;

typedef enum
{
	awsbatAuto = 0,
	awsbatVirtualHost = 1,
	awsbatVirtualPath = 2
} TSBAWSS3BucketAccessType;

typedef uint8_t TSBAWSS3AccessControlGranteeTypeRaw;

typedef enum
{
	acqtUnknown = 0,
	acgtCanonicalUser = 1,
	acgtAmazonCustomerByEmail = 2,
	acgtGroup = 3,
	acgtAuthenticatedUsersGroup = 4,
	acgtAllUsersGroup = 5,
	acgtLogDeliveryGroup = 6
} TSBAWSS3AccessControlGranteeType;

typedef uint8_t TSBAWSS3AccessControlPermissionRaw;

typedef enum
{
	acpUnknown = 0,
	acpRead = 1,
	acpWrite = 2,
	acpReadACP = 3,
	acpWriteACP = 4,
	acpFullControl = 5
} TSBAWSS3AccessControlPermission;

typedef uint8_t TSBAWSS3BucketVersioningRaw;

typedef enum
{
	bvEnabled = 0,
	bvSuspended = 1,
	bvDisabled = 2
} TSBAWSS3BucketVersioning;

typedef uint8_t TSBAWSS3DataStorageOptionRaw;

typedef enum
{
	awsoptDetailedList = 0,
	awsoptUseHeadRequests = 1,
	awsoptLiberalBucketNaming = 2
} TSBAWSS3DataStorageOption;

typedef uint32_t TSBAWSS3DataStorageOptionsRaw;

typedef enum 
{
	f_awsoptDetailedList = 1,
	f_awsoptUseHeadRequests = 2,
	f_awsoptLiberalBucketNaming = 4
} TSBAWSS3DataStorageOptions;

typedef uint8_t TSBAWSS3RegionRaw;

typedef enum
{
	awsrCustom = 0,
	awsrDefault = 1,
	awsrUSStandard = 2,
	awsrUSWestOregon = 3,
	awsrUSWestNCalifornia = 4,
	awsrEUIreland = 5,
	awsrEUFrankfurt = 6,
	awsrAPSingapore = 7,
	awsrAPSydney = 8,
	awsrAPTokyo = 9,
	awsrSASaoPaulo = 10,
	awsrAPSeoul = 11,
	awsrUSEastOhio = 12,
	awsrCanadaCentral = 13,
	awsrAPMumbai = 14,
	awsrEULondon = 15
} TSBAWSS3Region;

typedef void (SB_CALLBACK *TSBAWSS3BeforeRequestSigningEvent)(void * _ObjectData, TObjectHandle Sender, TElHTTPSClientHandle HttpClient);

#ifdef SB_USE_CLASS_TELAWSS3DATASTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_AcquireObject(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_AcquireObject_1(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TElStringListHandle Headers, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_AcquireObject_2(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, const char * pcKey, int32_t szKey, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_AcquireObject_3(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_List(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_List_1(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElDataStorageObjectListHandle Objects, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_List_2(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_List_3(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElDataStorageObjectListHandle Objects, const char * pcPrefix, int32_t szPrefix, const char * pcDelimiter, int32_t szDelimiter, int32_t MaxCount, TElStringListHandle Prefixes, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_List_4(TElCustomDataStorageHandle _Handle, TElDataStorageObjectListHandle Objs);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ListInit(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElAWSS3DataStorageListStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ListInit_1(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcPrefix, int32_t szPrefix, const char * pcDelimiter, int32_t szDelimiter, TElStringListHandle Prefixes, TElStringListHandle Headers, TElAWSS3DataStorageListStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ListNext(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageListStateHandle State, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ListNext_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageListStateHandle State, TElDataStorageObjectListHandle Objects, int32_t MaxCount);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ListFinal(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageListStateHandle * State);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CreateObject(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcObjName, int32_t szObjName, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CreateObject_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, const char * pcObjName, int32_t szObjName, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CreateObject_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcObjName, int32_t szObjName, TElCustomDataStorageSecurityHandlerHandle Handler, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CreateObject_3(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, const char * pcObjName, int32_t szObjName, TElCustomDataStorageSecurityHandlerHandle Handler, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CreateObject_4(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcObjName, int32_t szObjName, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, TElStringListHandle Metadata, TElStringListHandle Headers, TElCustomDataStorageSecurityHandlerHandle Handler, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CreateObject_5(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcObjName, int32_t szObjName, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, const char * pcStorageClass, int32_t szStorageClass, TElStringListHandle Metadata, TElStringListHandle Headers, TElCustomDataStorageSecurityHandlerHandle Handler, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CreateObject_6(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcObjName, int32_t szObjName, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, const char * pcContentEncoding, int32_t szContentEncoding, const char * pcStorageClass, int32_t szStorageClass, TElStringListHandle Metadata, TElStringListHandle Headers, TElCustomDataStorageSecurityHandlerHandle Handler, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_DeleteObject(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_DeleteObject_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_DeleteObject_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_DeleteObject_3(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ObjectExists(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ObjectExists_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ObjectExists_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TElStringListHandle Headers, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_RefreshObject(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_RefreshObject_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_WriteObject(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TStreamHandle Data, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_WriteObject_1(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TStreamHandle Data, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, TElStringListHandle Metadata, TElStringListHandle Headers, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_WriteObject_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TStreamHandle Data, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, const char * pcStorageClass, int32_t szStorageClass, TElStringListHandle Metadata, TElStringListHandle Headers, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_WriteObject_3(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TStreamHandle Data, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, const char * pcContentEncoding, int32_t szContentEncoding, const char * pcStorageClass, int32_t szStorageClass, TElStringListHandle Metadata, TElStringListHandle Headers, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_WriteObject_4(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TStreamHandle Data, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, const char * pcContentEncoding, int32_t szContentEncoding, const char * pcStorageClass, int32_t szStorageClass, TElStringListHandle Metadata, TElStringListHandle Headers, TElCustomDataStorageSecurityHandlerHandle Handler, char * pcNewETag, int32_t * szNewETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_WriteObject_5(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, TStreamHandle Data, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, TElStringListHandle Metadata, TElStringListHandle Headers, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_WriteObject_6(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, TStreamHandle Data, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, const char * pcStorageClass, int32_t szStorageClass, TElStringListHandle Metadata, TElStringListHandle Headers, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_WriteObject_7(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, TStreamHandle Data, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, const char * pcContentEncoding, int32_t szContentEncoding, const char * pcStorageClass, int32_t szStorageClass, TElStringListHandle Metadata, TElStringListHandle Headers, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_WriteObject_8(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TStreamHandle Strm, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadObject(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadObject_1(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TStreamHandle Strm, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadObject_2(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, TStreamHandle Strm, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadObject_3(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TStreamHandle Strm, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, TElStringListHandle Headers, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadObject_4(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TStreamHandle Strm, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, TElStringListHandle Headers, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjContentEncoding, int32_t * szObjContentEncoding, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadObject_5(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, TStreamHandle Strm, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, TElStringListHandle Headers, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadObject_6(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, TStreamHandle Strm, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, TElStringListHandle Headers, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjContentEncoding, int32_t * szObjContentEncoding, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadObject_7(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadBlock(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadBlock_1(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadBlock_2(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadBlock_3(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, TElStringListHandle Headers, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadBlock_4(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, TElStringListHandle Headers, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjContentEncoding, int32_t * szObjContentEncoding, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadBlock_5(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, TElStringListHandle Headers, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadBlock_6(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, TElStringListHandle Headers, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjContentEncoding, int32_t * szObjContentEncoding, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReadBlock_7(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CopyObject(TElAWSS3DataStorageHandle _Handle, const char * pcSourceBucketName, int32_t szSourceBucketName, const char * pcSourceKey, int32_t szSourceKey, const char * pcDestBucketName, int32_t szDestBucketName, const char * pcDestKey, int32_t szDestKey, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CopyObject_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, const char * pcDestBucketName, int32_t szDestBucketName, const char * pcDestKey, int32_t szDestKey, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CopyObject_2(TElAWSS3DataStorageHandle _Handle, const char * pcSourceBucketName, int32_t szSourceBucketName, const char * pcSourceKey, int32_t szSourceKey, const char * pcDestBucketName, int32_t szDestBucketName, const char * pcDestKey, int32_t szDestKey, int8_t PreserveMetadata, TElStringListHandle Metadata, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CopyObject_3(TElAWSS3DataStorageHandle _Handle, const char * pcSourceBucketName, int32_t szSourceBucketName, const char * pcSourceKey, int32_t szSourceKey, const char * pcDestBucketName, int32_t szDestBucketName, const char * pcDestKey, int32_t szDestKey, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, int8_t PreserveMetadata, TElStringListHandle Metadata, TElStringListHandle Headers, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CopyObject_4(TElAWSS3DataStorageHandle _Handle, const char * pcSourceBucketName, int32_t szSourceBucketName, const char * pcSourceKey, int32_t szSourceKey, const char * pcDestBucketName, int32_t szDestBucketName, const char * pcDestKey, int32_t szDestKey, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, const char * pcStorageClass, int32_t szStorageClass, int8_t PreserveMetadata, TElStringListHandle Metadata, TElStringListHandle Headers, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CopyObject_5(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetObjectACL(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetObjectACL_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetObjectACL_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TElStringListHandle Headers, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetObjectACL_3(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TElAWSS3AccessControlPolicyHandle Policy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetObjectACL_4(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, TElAWSS3AccessControlPolicyHandle Policy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetObjectACL_5(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TElAWSS3AccessControlPolicyHandle Policy, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetObjectACL(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, const char * pcACL, int32_t szACL);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetObjectACL_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, const char * pcACL, int32_t szACL);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetObjectACL_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, const char * pcACL, int32_t szACL, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetObjectACL_3(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TElAWSS3AccessControlPolicyHandle Policy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetObjectACL_4(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, TElAWSS3AccessControlPolicyHandle Policy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetObjectACL_5(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TElAWSS3AccessControlPolicyHandle Policy, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetLocalETag(TElAWSS3DataStorageHandle _Handle, TStreamHandle Stream, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetLocalETag_1(TElAWSS3DataStorageHandle _Handle, const char * pcFilename, int32_t szFilename, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetRemoteETag(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetRemoteETag_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetRemoteETag_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TElStringListHandle Headers, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetObjectTorrent(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetObjectTorrent_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageObjectHandle Obj, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetObjectTorrent_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TElStringListHandle Headers, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_AcquireBucket(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElAWSS3DataStorageBucketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ReleaseBucket(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle * Bucket);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CreateBucket(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElAWSS3DataStorageBucketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CreateBucket_1(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcLocation, int32_t szLocation, TElAWSS3DataStorageBucketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CreateBucket_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcLocation, int32_t szLocation, const char * pcACL, int32_t szACL, TElAWSS3DataStorageBucketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CreateBucket_3(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcLocation, int32_t szLocation, TElStringListHandle Headers, TElAWSS3DataStorageBucketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_CreateBucket_4(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcLocation, int32_t szLocation, const char * pcACL, int32_t szACL, TElStringListHandle Headers, TElAWSS3DataStorageBucketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_DeleteBucket(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_DeleteBucket_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle * Bucket);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_DeleteBucket_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_BucketExists(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_BucketExists_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_BucketExists_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElStringListHandle Headers, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketLocation(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketLocation_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketLocation_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElStringListHandle Headers, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketACL(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketACL_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketACL_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElStringListHandle Headers, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketACL_3(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElAWSS3AccessControlPolicyHandle Policy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketACL_4(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, TElAWSS3AccessControlPolicyHandle Policy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketACL_5(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElAWSS3AccessControlPolicyHandle Policy, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketACL(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcACL, int32_t szACL);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketACL_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, const char * pcACL, int32_t szACL);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketACL_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcACL, int32_t szACL, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketACL_3(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElAWSS3AccessControlPolicyHandle Policy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketACL_4(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, TElAWSS3AccessControlPolicyHandle Policy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketACL_5(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElAWSS3AccessControlPolicyHandle Policy, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketPolicy(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketPolicy_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketPolicy_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElStringListHandle Headers, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketPolicy(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcPolicy, int32_t szPolicy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketPolicy_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, const char * pcPolicy, int32_t szPolicy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketPolicy_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcPolicy, int32_t szPolicy, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_DeleteBucketPolicy(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_DeleteBucketPolicy_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_DeleteBucketPolicy_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketPaymentConfiguration(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcPaymentConfig, int32_t szPaymentConfig);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketPaymentConfiguration_1(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, int8_t RequesterPays);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketPaymentConfiguration_2(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, const char * pcPaymentConfig, int32_t szPaymentConfig);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketPaymentConfiguration_3(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, int8_t RequesterPays);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketPaymentConfiguration_4(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcPaymentConfig, int32_t szPaymentConfig, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketPaymentConfiguration(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketPaymentConfiguration_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketPaymentConfiguration_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElStringListHandle Headers, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_IsRequesterPaysBucket(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_IsRequesterPaysBucket_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_IsRequesterPaysBucket_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElStringListHandle Headers, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketVersioning(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TSBAWSS3BucketVersioningRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketVersioning_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, TSBAWSS3BucketVersioningRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketVersioning_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElStringListHandle Headers, TSBAWSS3BucketVersioningRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketVersioning(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TSBAWSS3BucketVersioningRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketVersioning_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, TSBAWSS3BucketVersioningRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketVersioning_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TSBAWSS3BucketVersioningRaw Value, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketNotificationConfiguration(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElStringListHandle Topics, TElStringListHandle Events);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketNotificationConfiguration_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, TElStringListHandle Topics, TElStringListHandle Events);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketNotificationConfiguration_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElStringListHandle Topics, TElStringListHandle Events, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketNotificationConfiguration(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElStringListHandle Topics, TElStringListHandle Events);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketNotificationConfiguration_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, TElStringListHandle Topics, TElStringListHandle Events);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketNotificationConfiguration_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElStringListHandle Topics, TElStringListHandle Events, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketWebSiteConfiguration(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, char * pcIndexDocument, int32_t * szIndexDocument, char * pcErrorDocument, int32_t * szErrorDocument);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketWebSiteConfiguration_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, char * pcIndexDocument, int32_t * szIndexDocument, char * pcErrorDocument, int32_t * szErrorDocument);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_GetBucketWebSiteConfiguration_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, char * pcIndexDocument, int32_t * szIndexDocument, char * pcErrorDocument, int32_t * szErrorDocument, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketWebSiteConfiguration(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcIndexDocument, int32_t szIndexDocument, const char * pcErrorDocument, int32_t szErrorDocument);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketWebSiteConfiguration_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket, const char * pcIndexDocument, int32_t szIndexDocument, const char * pcErrorDocument, int32_t szErrorDocument);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_SetBucketWebSiteConfiguration_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, const char * pcIndexDocument, int32_t szIndexDocument, const char * pcErrorDocument, int32_t szErrorDocument, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_DeleteBucketWebSiteConfiguration(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_DeleteBucketWebSiteConfiguration_1(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketHandle Bucket);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_DeleteBucketWebSiteConfiguration_2(TElAWSS3DataStorageHandle _Handle, const char * pcBucketName, int32_t szBucketName, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ListBuckets(TElAWSS3DataStorageHandle _Handle, TElStringListHandle Buckets);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ListBuckets_1(TElAWSS3DataStorageHandle _Handle, TElStringListHandle Buckets, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ListBuckets_2(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketListHandle Buckets);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_ListBuckets_3(TElAWSS3DataStorageHandle _Handle, TElAWSS3DataStorageBucketListHandle Buckets, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_PerformIAMRequest(TElAWSS3DataStorageHandle _Handle, const char * pcAddress, int32_t szAddress, TElStringListHandle Parameters, TElStringListHandle Headers, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_OutputStream(TElAWSS3DataStorageHandle _Handle, TMemoryStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_Protocol(TElAWSS3DataStorageHandle _Handle, TSBAWSProtocolRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_Protocol(TElAWSS3DataStorageHandle _Handle, TSBAWSProtocolRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_AuthType(TElAWSS3DataStorageHandle _Handle, TSBAWSAuthTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_AuthType(TElAWSS3DataStorageHandle _Handle, TSBAWSAuthTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_KeyID(TElAWSS3DataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_KeyID(TElAWSS3DataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_AccessKey(TElAWSS3DataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_AccessKey(TElAWSS3DataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_SecurityToken(TElAWSS3DataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_SecurityToken(TElAWSS3DataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_UseSSL(TElAWSS3DataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_UseSSL(TElAWSS3DataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_HTTPClient(TElAWSS3DataStorageHandle _Handle, TElHTTPSClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_HTTPClient(TElAWSS3DataStorageHandle _Handle, TElHTTPSClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_AWSHeaders(TElAWSS3DataStorageHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_UseCRCCheck(TElAWSS3DataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_UseCRCCheck(TElAWSS3DataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_UseDelayedPut(TElAWSS3DataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_UseDelayedPut(TElAWSS3DataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_UseURLEncoding(TElAWSS3DataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_UseURLEncoding(TElAWSS3DataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_UseVersion4Signatures(TElAWSS3DataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_UseVersion4Signatures(TElAWSS3DataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_Version4SignatureHashAlgorithm(TElAWSS3DataStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_Version4SignatureHashAlgorithm(TElAWSS3DataStorageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_SecMetadataID(TElAWSS3DataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_SecMetadataID(TElAWSS3DataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_MultipartUploadPartSize(TElAWSS3DataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_MultipartUploadPartSize(TElAWSS3DataStorageHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_MultipartUploadThreshold(TElAWSS3DataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_MultipartUploadThreshold(TElAWSS3DataStorageHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_RetryCount(TElAWSS3DataStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_RetryCount(TElAWSS3DataStorageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_Options(TElAWSS3DataStorageHandle _Handle, TSBAWSS3DataStorageOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_Options(TElAWSS3DataStorageHandle _Handle, TSBAWSS3DataStorageOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_Overwrite(TElAWSS3DataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_Overwrite(TElAWSS3DataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_PassthroughMode(TElAWSS3DataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_PassthroughMode(TElAWSS3DataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_BucketAccessType(TElAWSS3DataStorageHandle _Handle, TSBAWSS3BucketAccessTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_BucketAccessType(TElAWSS3DataStorageHandle _Handle, TSBAWSS3BucketAccessTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_EmbeddedMetadataMode(TElAWSS3DataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_EmbeddedMetadataMode(TElAWSS3DataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_BaseURL(TElAWSS3DataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_BaseURL(TElAWSS3DataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_RegionID(TElAWSS3DataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_RegionID(TElAWSS3DataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_Region(TElAWSS3DataStorageHandle _Handle, TSBAWSS3RegionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_Region(TElAWSS3DataStorageHandle _Handle, TSBAWSS3RegionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_get_OnBeforeRequestSigning(TElAWSS3DataStorageHandle _Handle, TSBAWSS3BeforeRequestSigningEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_set_OnBeforeRequestSigning(TElAWSS3DataStorageHandle _Handle, TSBAWSS3BeforeRequestSigningEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorage_Create(TComponentHandle AOwner, TElAWSS3DataStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELAWSS3DATASTORAGE */

#ifdef SB_USE_CLASS_TELAWSS3DATASTORAGEOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Assign(TElAWSS3DataStorageObjectHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Clone(TElAWSS3DataStorageObjectHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Delete(TElAWSS3DataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Exists(TElAWSS3DataStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Refresh(TElAWSS3DataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Write(TElAWSS3DataStorageObjectHandle _Handle, TStreamHandle Data, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Write_1(TElAWSS3DataStorageObjectHandle _Handle, TStreamHandle Data, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, TElStringListHandle Metadata, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Write_2(TElAWSS3DataStorageObjectHandle _Handle, TStreamHandle Data, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, const char * pcStorageClass, int32_t szStorageClass, TElStringListHandle Metadata, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Write_3(TElAWSS3DataStorageObjectHandle _Handle, TStreamHandle Data, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, const char * pcContentEncoding, int32_t szContentEncoding, const char * pcStorageClass, int32_t szStorageClass, TElStringListHandle Metadata, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Read(TElAWSS3DataStorageObjectHandle _Handle, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Read_1(TElAWSS3DataStorageObjectHandle _Handle, TStreamHandle Strm, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Read_2(TElAWSS3DataStorageObjectHandle _Handle, TStreamHandle Strm, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Read_3(TElAWSS3DataStorageObjectHandle _Handle, TStreamHandle Strm, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjContentEncoding, int32_t * szObjContentEncoding, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_ReadBlock(TElAWSS3DataStorageObjectHandle _Handle, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_ReadBlock_1(TElAWSS3DataStorageObjectHandle _Handle, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_ReadBlock_2(TElAWSS3DataStorageObjectHandle _Handle, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_ReadBlock_3(TElAWSS3DataStorageObjectHandle _Handle, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjContentEncoding, int32_t * szObjContentEncoding, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Copy(TElAWSS3DataStorageObjectHandle _Handle, const char * pcDestBucketName, int32_t szDestBucketName, const char * pcDestKey, int32_t szDestKey, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Copy_1(TElAWSS3DataStorageObjectHandle _Handle, const char * pcDestBucketName, int32_t szDestBucketName, const char * pcDestKey, int32_t szDestKey, int8_t PreserveMetadata, TElStringListHandle Metadata, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Copy_2(TElAWSS3DataStorageObjectHandle _Handle, const char * pcDestBucketName, int32_t szDestBucketName, const char * pcDestKey, int32_t szDestKey, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, int8_t PreserveMetadata, TElStringListHandle Metadata, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Copy_3(TElAWSS3DataStorageObjectHandle _Handle, const char * pcDestBucketName, int32_t szDestBucketName, const char * pcDestKey, int32_t szDestKey, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, const char * pcStorageClass, int32_t szStorageClass, int8_t PreserveMetadata, TElStringListHandle Metadata, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_GetACL(TElAWSS3DataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_GetACL_1(TElAWSS3DataStorageObjectHandle _Handle, TElAWSS3AccessControlPolicyHandle Policy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_SetACL(TElAWSS3DataStorageObjectHandle _Handle, const char * pcACL, int32_t szACL);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_SetACL_1(TElAWSS3DataStorageObjectHandle _Handle, TElAWSS3AccessControlPolicyHandle Policy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_GetLocalETag(TElAWSS3DataStorageObjectHandle _Handle, TStreamHandle Stream, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_GetLocalETag_1(TElAWSS3DataStorageObjectHandle _Handle, const char * pcFilename, int32_t szFilename, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_GetRemoteETag(TElAWSS3DataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_GetTorrent(TElAWSS3DataStorageObjectHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_get_BucketName(TElAWSS3DataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_get_Key(TElAWSS3DataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_get_LastModified(TElAWSS3DataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_get_ETag(TElAWSS3DataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_get_Size(TElAWSS3DataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_get_StorageClass(TElAWSS3DataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_get_OwnerID(TElAWSS3DataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_get_OwnerDisplayName(TElAWSS3DataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_get_ContentType(TElAWSS3DataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_get_ContentDisposition(TElAWSS3DataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_get_ContentEncoding(TElAWSS3DataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_get_Metadata(TElAWSS3DataStorageObjectHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_get_CustomHeaders(TElAWSS3DataStorageObjectHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Create(TElAWSS3DataStorageHandle Storage, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageObject_Create_1(TElAWSS3DataStorageHandle Storage, const char * pcBucketName, int32_t szBucketName, const char * pcKey, int32_t szKey, TElAWSS3DataStorageObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELAWSS3DATASTORAGEOBJECT */

#ifdef SB_USE_CLASS_TELAWSS3DATASTORAGELISTSTATE
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageListState_Completed(TElAWSS3DataStorageListStateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageListState_Create(const char * pcBucketName, int32_t szBucketName, const char * pcPrefix, int32_t szPrefix, const char * pcDelimiter, int32_t szDelimiter, TElStringListHandle Prefixes, TElStringListHandle Headers, TElAWSS3DataStorageListStateHandle * OutResult);
#endif /* SB_USE_CLASS_TELAWSS3DATASTORAGELISTSTATE */

#ifdef SB_USE_CLASS_TELAWSS3ACCESSCONTROLGRANT
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_Reset(TElAWSS3AccessControlGrantHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_SaveToXML(TElAWSS3AccessControlGrantHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_LoadFromXML(TElAWSS3AccessControlGrantHandle _Handle, const char * pcXml, int32_t szXml);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_LoadFromXML_1(TElAWSS3AccessControlGrantHandle _Handle, TStreamHandle XmlStream);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_LoadFromXML_2(TElAWSS3AccessControlGrantHandle _Handle, TElXMLDOMElementHandle Elem);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_get_GranteeType(TElAWSS3AccessControlGrantHandle _Handle, TSBAWSS3AccessControlGranteeTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_set_GranteeType(TElAWSS3AccessControlGrantHandle _Handle, TSBAWSS3AccessControlGranteeTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_get_UserID(TElAWSS3AccessControlGrantHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_set_UserID(TElAWSS3AccessControlGrantHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_get_UserDisplayName(TElAWSS3AccessControlGrantHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_set_UserDisplayName(TElAWSS3AccessControlGrantHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_get_GroupURI(TElAWSS3AccessControlGrantHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_set_GroupURI(TElAWSS3AccessControlGrantHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_get_Email(TElAWSS3AccessControlGrantHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_set_Email(TElAWSS3AccessControlGrantHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_get_Permission(TElAWSS3AccessControlGrantHandle _Handle, TSBAWSS3AccessControlPermissionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_set_Permission(TElAWSS3AccessControlGrantHandle _Handle, TSBAWSS3AccessControlPermissionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_get_CustomPermission(TElAWSS3AccessControlGrantHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_set_CustomPermission(TElAWSS3AccessControlGrantHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_get_CustomGrantee(TElAWSS3AccessControlGrantHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_set_CustomGrantee(TElAWSS3AccessControlGrantHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlGrant_Create(TElAWSS3AccessControlGrantHandle * OutResult);
#endif /* SB_USE_CLASS_TELAWSS3ACCESSCONTROLGRANT */

#ifdef SB_USE_CLASS_TELAWSS3ACCESSCONTROLPOLICY
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlPolicy_AddGrant(TElAWSS3AccessControlPolicyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlPolicy_RemoveGrant(TElAWSS3AccessControlPolicyHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlPolicy_ClearGrants(TElAWSS3AccessControlPolicyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlPolicy_SaveToXML(TElAWSS3AccessControlPolicyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlPolicy_LoadFromXML(TElAWSS3AccessControlPolicyHandle _Handle, const char * pcXml, int32_t szXml);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlPolicy_LoadFromXML_1(TElAWSS3AccessControlPolicyHandle _Handle, TStreamHandle XmlStream);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlPolicy_Reset(TElAWSS3AccessControlPolicyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlPolicy_get_Grants(TElAWSS3AccessControlPolicyHandle _Handle, int32_t Index, TElAWSS3AccessControlGrantHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlPolicy_get_GrantCount(TElAWSS3AccessControlPolicyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlPolicy_get_OwnerID(TElAWSS3AccessControlPolicyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlPolicy_set_OwnerID(TElAWSS3AccessControlPolicyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlPolicy_get_OwnerDisplayName(TElAWSS3AccessControlPolicyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlPolicy_set_OwnerDisplayName(TElAWSS3AccessControlPolicyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3AccessControlPolicy_Create(TElAWSS3AccessControlPolicyHandle * OutResult);
#endif /* SB_USE_CLASS_TELAWSS3ACCESSCONTROLPOLICY */

#ifdef SB_USE_CLASS_TELAWSS3DATASTORAGEBUCKET
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_AcquireObject(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_List(TElAWSS3DataStorageBucketHandle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_List_1(TElAWSS3DataStorageBucketHandle _Handle, TElDataStorageObjectListHandle Objects, const char * pcPrefix, int32_t szPrefix, const char * pcDelimiter, int32_t szDelimiter, int32_t MaxCount, TElStringListHandle Prefixes, TElStringListHandle Headers);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_ListInit(TElAWSS3DataStorageBucketHandle _Handle, TElAWSS3DataStorageListStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_ListInit_1(TElAWSS3DataStorageBucketHandle _Handle, const char * pcPrefix, int32_t szPrefix, const char * pcDelimiter, int32_t szDelimiter, TElStringListHandle Prefixes, TElStringListHandle Headers, TElAWSS3DataStorageListStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_ListNext(TElAWSS3DataStorageBucketHandle _Handle, TElAWSS3DataStorageListStateHandle State, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_ListNext_1(TElAWSS3DataStorageBucketHandle _Handle, TElAWSS3DataStorageListStateHandle State, TElDataStorageObjectListHandle Objects, int32_t MaxCount);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_ListFinal(TElAWSS3DataStorageBucketHandle _Handle, TElAWSS3DataStorageListStateHandle * State);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_CreateObject(TElAWSS3DataStorageBucketHandle _Handle, const char * pcObjName, int32_t szObjName, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_CreateObject_1(TElAWSS3DataStorageBucketHandle _Handle, const char * pcObjName, int32_t szObjName, TElCustomDataStorageSecurityHandlerHandle Handler, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_CreateObject_2(TElAWSS3DataStorageBucketHandle _Handle, const char * pcObjName, int32_t szObjName, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, TElStringListHandle Metadata, TElCustomDataStorageSecurityHandlerHandle Handler, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_CreateObject_3(TElAWSS3DataStorageBucketHandle _Handle, const char * pcObjName, int32_t szObjName, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, const char * pcStorageClass, int32_t szStorageClass, TElStringListHandle Metadata, TElCustomDataStorageSecurityHandlerHandle Handler, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_CreateObject_4(TElAWSS3DataStorageBucketHandle _Handle, const char * pcObjName, int32_t szObjName, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, const char * pcContentEncoding, int32_t szContentEncoding, const char * pcStorageClass, int32_t szStorageClass, TElStringListHandle Metadata, TElCustomDataStorageSecurityHandlerHandle Handler, TElAWSS3DataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_DeleteObject(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_ObjectExists(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_WriteObject(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, TStreamHandle Data, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_WriteObject_1(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, TStreamHandle Data, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, TElStringListHandle Metadata, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_WriteObject_2(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, TStreamHandle Data, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, const char * pcStorageClass, int32_t szStorageClass, TElStringListHandle Metadata, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_WriteObject_3(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, TStreamHandle Data, const char * pcContentType, int32_t szContentType, const char * pcContentDisposition, int32_t szContentDisposition, const char * pcContentEncoding, int32_t szContentEncoding, const char * pcStorageClass, int32_t szStorageClass, TElStringListHandle Metadata, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_ReadObject(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_ReadObject_1(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, TStreamHandle Strm, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_ReadObject_2(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, TStreamHandle Strm, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_ReadObject_3(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, TStreamHandle Strm, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjContentEncoding, int32_t * szObjContentEncoding, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_ReadBlock(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_ReadBlock_1(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_ReadBlock_2(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_ReadBlock_3(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, TElStringListHandle Metadata, char * pcObjContentType, int32_t * szObjContentType, char * pcObjContentDisposition, int32_t * szObjContentDisposition, char * pcObjContentEncoding, int32_t * szObjContentEncoding, char * pcObjETag, int32_t * szObjETag);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_CopyObject(TElAWSS3DataStorageBucketHandle _Handle, const char * pcSourceKey, int32_t szSourceKey, const char * pcDestBucketName, int32_t szDestBucketName, const char * pcDestKey, int32_t szDestKey, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_CopyObject_1(TElAWSS3DataStorageBucketHandle _Handle, const char * pcSourceKey, int32_t szSourceKey, const char * pcDestBucketName, int32_t szDestBucketName, const char * pcDestKey, int32_t szDestKey, int8_t PreserveMetadata, TElStringListHandle Metadata, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_CopyObject_2(TElAWSS3DataStorageBucketHandle _Handle, const char * pcSourceKey, int32_t szSourceKey, const char * pcDestBucketName, int32_t szDestBucketName, const char * pcDestKey, int32_t szDestKey, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, int8_t PreserveMetadata, TElStringListHandle Metadata, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_CopyObject_3(TElAWSS3DataStorageBucketHandle _Handle, const char * pcSourceKey, int32_t szSourceKey, const char * pcDestBucketName, int32_t szDestBucketName, const char * pcDestKey, int32_t szDestKey, TSBAWSS3ReadObjectConditionRaw Condition, int64_t DateTime, const char * pcETag, int32_t szETag, const char * pcStorageClass, int32_t szStorageClass, int8_t PreserveMetadata, TElStringListHandle Metadata, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_GetObjectACL(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_SetObjectACL(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, const char * pcACL, int32_t szACL);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_GetRemoteETag(TElAWSS3DataStorageBucketHandle _Handle, const char * pcKey, int32_t szKey, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_Delete(TElAWSS3DataStorageBucketHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_Exists(TElAWSS3DataStorageBucketHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_GetLocation(TElAWSS3DataStorageBucketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_GetACL(TElAWSS3DataStorageBucketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_GetACL_1(TElAWSS3DataStorageBucketHandle _Handle, TElAWSS3AccessControlPolicyHandle Policy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_SetACL(TElAWSS3DataStorageBucketHandle _Handle, const char * pcACL, int32_t szACL);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_SetACL_1(TElAWSS3DataStorageBucketHandle _Handle, TElAWSS3AccessControlPolicyHandle Policy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_GetPolicy(TElAWSS3DataStorageBucketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_SetPolicy(TElAWSS3DataStorageBucketHandle _Handle, const char * pcPolicy, int32_t szPolicy);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_DeletePolicy(TElAWSS3DataStorageBucketHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_SetPaymentConfiguration(TElAWSS3DataStorageBucketHandle _Handle, const char * pcPaymentConfig, int32_t szPaymentConfig);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_SetPaymentConfiguration_1(TElAWSS3DataStorageBucketHandle _Handle, int8_t RequesterPays);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_GetPaymentConfiguration(TElAWSS3DataStorageBucketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_IsRequesterPaysBucket(TElAWSS3DataStorageBucketHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_GetVersioning(TElAWSS3DataStorageBucketHandle _Handle, TSBAWSS3BucketVersioningRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_SetVersioning(TElAWSS3DataStorageBucketHandle _Handle, TSBAWSS3BucketVersioningRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_GetNotificationConfiguration(TElAWSS3DataStorageBucketHandle _Handle, TElStringListHandle Topics, TElStringListHandle Events);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_SetNotificationConfiguration(TElAWSS3DataStorageBucketHandle _Handle, TElStringListHandle Topics, TElStringListHandle Events);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_GetWebSiteConfiguration(TElAWSS3DataStorageBucketHandle _Handle, char * pcIndexDocument, int32_t * szIndexDocument, char * pcErrorDocument, int32_t * szErrorDocument);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_SetWebSiteConfiguration(TElAWSS3DataStorageBucketHandle _Handle, const char * pcIndexDocument, int32_t szIndexDocument, const char * pcErrorDocument, int32_t szErrorDocument);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_DeleteWebSiteConfiguration(TElAWSS3DataStorageBucketHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_get_Name(TElAWSS3DataStorageBucketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_get_CreationDate(TElAWSS3DataStorageBucketHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_get_CustomHeaders(TElAWSS3DataStorageBucketHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_Create(TElAWSS3DataStorageBucketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucket_Create_1(TElAWSS3DataStorageHandle Storage, TElAWSS3DataStorageBucketHandle * OutResult);
#endif /* SB_USE_CLASS_TELAWSS3DATASTORAGEBUCKET */

#ifdef SB_USE_CLASS_TELAWSS3DATASTORAGEBUCKETLIST
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucketList_get_Buckets(TElAWSS3DataStorageBucketListHandle _Handle, int32_t Index, TElAWSS3DataStorageBucketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucketList_get_Count(TElAWSS3DataStorageBucketListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucketList_get_OwnerID(TElAWSS3DataStorageBucketListHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucketList_get_OwnerDisplayName(TElAWSS3DataStorageBucketListHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucketList_Create(TElAWSS3DataStorageBucketListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAWSS3DataStorageBucketList_Create_1(TElAWSS3DataStorageHandle Storage, TElAWSS3DataStorageBucketListHandle * OutResult);
#endif /* SB_USE_CLASS_TELAWSS3DATASTORAGEBUCKETLIST */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElAWSS3DataStorage_ce_ptr;
extern zend_class_entry *TElAWSS3DataStorageObject_ce_ptr;
extern zend_class_entry *TElAWSS3DataStorageListState_ce_ptr;
extern zend_class_entry *TElAWSS3AccessControlGrant_ce_ptr;
extern zend_class_entry *TElAWSS3AccessControlPolicy_ce_ptr;
extern zend_class_entry *TElAWSS3DataStorageBucket_ce_ptr;
extern zend_class_entry *TElAWSS3DataStorageBucketList_ce_ptr;

void SB_CALLBACK TSBAWSS3BeforeRequestSigningEventRaw(void * _ObjectData, TObjectHandle Sender, TElHTTPSClientHandle HttpClient);
void Register_TElAWSS3DataStorage(TSRMLS_D);
void Register_TElAWSS3DataStorageObject(TSRMLS_D);
void Register_TElAWSS3DataStorageListState(TSRMLS_D);
void Register_TElAWSS3AccessControlGrant(TSRMLS_D);
void Register_TElAWSS3AccessControlPolicy(TSRMLS_D);
void Register_TElAWSS3DataStorageBucket(TSRMLS_D);
void Register_TElAWSS3DataStorageBucketList(TSRMLS_D);
SB_PHP_FUNCTION(SBAWSDataStorage, GetNodeInnerXML);
void Register_SBAWSDataStorage_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_AWSDATASTORAGE
SB_IMPORT uint32_t SB_APIENTRY SBAWSDataStorage_GetNodeInnerXML(TElXMLDOMNodeHandle XmlNode, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_AWSDATASTORAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBAWSDATASTORAGE */

