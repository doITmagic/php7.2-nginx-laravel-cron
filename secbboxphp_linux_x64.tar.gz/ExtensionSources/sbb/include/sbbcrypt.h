#ifndef __INC_SBBCRYPT
#define __INC_SBBCRYPT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbencoding.h"
#include "sbtypes.h"
#include "sbrandom.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SInvalidRoundsNumber 	"Invalid rounds number"
#define SB_SInvalidSaltSize 	"Invalid salt size"
#define SB_SInvalidPasswordLength 	"Invalid password length"
#define SB_SInvalidBase64Encoding 	"Invalid Base-64 encoding"
#define SB_SInvalidEncryptedPassword 	"Invalid encrypted password"

typedef TElClassHandle TElBCryptHandle;

#ifdef SB_USE_CLASS_TELBCRYPT
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_EncryptRaw(int32_t Rounds, const uint8_t pPassword[], int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_EncryptRaw_1(TElBCryptHandle _Handle, int32_t Rounds, const uint8_t pPassword[], int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_EncryptRaw32(const uint8_t pPassword[], int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, uint8_t pOutput[], int32_t * szOutput);
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_EncryptRaw32_1(TElBCryptHandle _Handle, const uint8_t pPassword[], int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, uint8_t pOutput[], int32_t * szOutput);
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_GenerateSalt(uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_GenerateSalt_1(TElBCryptHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_EncryptPassword(const char * pcPassword, int32_t szPassword, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_EncryptPassword_1(TElBCryptHandle _Handle, const char * pcPassword, int32_t szPassword, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_EncryptPassword_2(const char * pcPassword, int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_EncryptPassword_3(TElBCryptHandle _Handle, const char * pcPassword, int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_EncryptPassword_4(const char * pcPassword, int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, int32_t Rounds, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_EncryptPassword_5(TElBCryptHandle _Handle, const char * pcPassword, int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, int32_t Rounds, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_CheckPassword(const char * pcPassword, int32_t szPassword, const char * pcEncryptedPassword, int32_t szEncryptedPassword, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_CheckPassword_1(TElBCryptHandle _Handle, const char * pcPassword, int32_t szPassword, const char * pcEncryptedPassword, int32_t szEncryptedPassword, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBCrypt_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELBCRYPT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElBCrypt_ce_ptr;

void Register_TElBCrypt(TSRMLS_D);
void Register_SBBCrypt_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBBCRYPT */

