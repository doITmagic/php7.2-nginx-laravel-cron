#ifndef __INC_SBBOXDATASTORAGE
#define __INC_SBBOXDATASTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbencoding.h"
#include "sbstringlist.h"
#include "sbdatastorage.h"
#include "sbdatastorageutils.h"
#include "sbstrutils.h"
#include "sbjson.h"
#include "sbhttpsconstants.h"
#include "sbhttpscommon.h"
#include "sbhttpsclient.h"
#include "sboauth2.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElBoxDataStorageHandle;

typedef TElClassHandle TElBoxDataStorageObjectHandle;

typedef TElClassHandle TElBoxFileHandle;

typedef TElClassHandle TElBoxFolderHandle;

typedef TElClassHandle TElBoxGroupHandle;

typedef TElClassHandle TElBoxUserHandle;

typedef TElClassHandle TElBoxEnterpriseHandle;

typedef TElClassHandle TElBoxUserEmailAliasHandle;

typedef TElClassHandle TElBoxUserEmailAliasesHandle;

typedef TElClassHandle TElBoxGroupMembershipHandle;

typedef TElClassHandle TElBoxGroupMembershipsHandle;

typedef TElClassHandle TElBoxUserInfoHandle;

typedef TElClassHandle TElBoxUsersHandle;

typedef TElClassHandle TElBoxGroupMemberHandle;

typedef TElClassHandle TElBoxGroupMembersHandle;

typedef TElClassHandle TElBoxGroupInfoHandle;

typedef TElClassHandle TElBoxGroupsHandle;

typedef TElClassHandle TElBoxSharedLinkHandle;

typedef TElClassHandle TElBoxSharedLinkPermissionsHandle;

typedef TElClassHandle TElBoxCollaborationHandle;

typedef TElClassHandle TElBoxCollaborationsHandle;

typedef TElClassHandle TElBoxDataStorageObjectPermissionsHandle;

typedef TElClassHandle TElBoxCommentHandle;

typedef TElClassHandle TElBoxCommentsHandle;

typedef uint8_t TSBBoxGroupRoleRaw;

typedef enum
{
	bgrUnknown = 0,
	bgrMember = 1,
	bgrAdmin = 2
} TSBBoxGroupRole;

typedef uint8_t TSBBoxUserRoleRaw;

typedef enum
{
	burUnknown = 0,
	burAdmin = 1,
	burCoadmin = 2,
	burUser = 3
} TSBBoxUserRole;

typedef uint8_t TSBBoxUserStatusRaw;

typedef enum
{
	busUnknown = 0,
	busActive = 1,
	busInactive = 2
} TSBBoxUserStatus;

typedef uint8_t TSBBoxSyncStateRaw;

typedef enum
{
	bssUnknown = 0,
	bssNotSynced = 1,
	bssPartiallySynced = 2,
	bssSynced = 3
} TSBBoxSyncState;

typedef uint8_t TSBBoxSharedLinkAccessRaw;

typedef enum
{
	bslUnknown = 0,
	bslOpen = 1,
	bslCollaborators = 2,
	bslCompany = 3
} TSBBoxSharedLinkAccess;

typedef uint8_t TSBBoxObjectStatusRaw;

typedef enum
{
	bosUnknown = 0,
	bosActive = 1,
	bosTrashed = 2
} TSBBoxObjectStatus;

typedef uint8_t TSBBoxCollaborationStatusRaw;

typedef enum
{
	bcsUnknown = 0,
	bcsPending = 1,
	bcsRejected = 2,
	bcsAccepted = 3
} TSBBoxCollaborationStatus;

typedef uint8_t TSBBoxCollaborationRoleRaw;

typedef enum
{
	bcrUnknown = 0,
	bcrEditor = 1,
	bcrViewer = 2,
	bcrPreviewer = 3,
	bcrUploader = 4,
	bcrPreviewerUploader = 5,
	bcrViewerUploader = 6,
	bcrCoOwner = 7
} TSBBoxCollaborationRole;

#ifdef SB_USE_CLASS_TELBOXDATASTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_StartAuthorization(TElBoxDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_CompleteAuthorization(TElBoxDataStorageHandle _Handle, const char * pcAuthorizationCode, int32_t szAuthorizationCode);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_CloseSession(TElBoxDataStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_AcquireFile(TElBoxDataStorageHandle _Handle, const char * pcID, int32_t szID, TElBoxFileHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_AcquireFolder(TElBoxDataStorageHandle _Handle, const char * pcID, int32_t szID, TElBoxFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_AcquireTrashedFile(TElBoxDataStorageHandle _Handle, const char * pcID, int32_t szID, TElBoxFileHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_AcquireTrashedFolder(TElBoxDataStorageHandle _Handle, const char * pcID, int32_t szID, TElBoxFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_CopyObject(TElBoxDataStorageHandle _Handle, TElBoxDataStorageObjectHandle Obj, TElBoxFolderHandle Destination, TElBoxDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_CopyObject_1(TElBoxDataStorageHandle _Handle, TElBoxDataStorageObjectHandle Obj, TElBoxFolderHandle Destination, const char * pcNewName, int32_t szNewName, TElBoxDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_CopyObject_2(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_GetAccountInfo(TElBoxDataStorageHandle _Handle, TElBoxUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_ListTrashed(TElBoxDataStorageHandle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_PurgeObject(TElBoxDataStorageHandle _Handle, TElBoxDataStorageObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_RestoreObject(TElBoxDataStorageHandle _Handle, TElBoxDataStorageObjectHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_RestoreObject_1(TElBoxDataStorageHandle _Handle, TElBoxDataStorageObjectHandle Obj, TElBoxFolderHandle NewParent, const char * pcNewName, int32_t szNewName);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_get_AccessToken(TElBoxDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_get_AccessTokenExpiration(TElBoxDataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_get_Groups(TElBoxDataStorageHandle _Handle, TElBoxGroupsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_get_Users(TElBoxDataStorageHandle _Handle, TElBoxUsersHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_get_ClientID(TElBoxDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_set_ClientID(TElBoxDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_get_ClientSecret(TElBoxDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_set_ClientSecret(TElBoxDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_get_HTTPClient(TElBoxDataStorageHandle _Handle, TElHTTPSClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_set_HTTPClient(TElBoxDataStorageHandle _Handle, TElHTTPSClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_get_PassthroughMode(TElBoxDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_set_PassthroughMode(TElBoxDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_get_RedirectURL(TElBoxDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_set_RedirectURL(TElBoxDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_get_RefreshToken(TElBoxDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_set_RefreshToken(TElBoxDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_get_UseETags(TElBoxDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_set_UseETags(TElBoxDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorage_Create(TComponentHandle AOwner, TElBoxDataStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXDATASTORAGE */

#ifdef SB_USE_CLASS_TELBOXDATASTORAGEOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_Assign(TElBoxDataStorageObjectHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_Copy(TElBoxDataStorageObjectHandle _Handle, TElBoxFolderHandle Destination, TElBoxDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_Copy_1(TElBoxDataStorageObjectHandle _Handle, TElBoxFolderHandle Destination, const char * pcNewName, int32_t szNewName, TElBoxDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_Delete(TElBoxDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_Move(TElBoxDataStorageObjectHandle _Handle, TElBoxFolderHandle Destination);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_Release(TElBoxDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_Rename(TElBoxDataStorageObjectHandle _Handle, const char * pcNewName, int32_t szNewName);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_Restore(TElBoxDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_Restore_1(TElBoxDataStorageObjectHandle _Handle, TElBoxFolderHandle Destination, const char * pcNewName, int32_t szNewName);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_Purge(TElBoxDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_TransferOwnership(TElBoxDataStorageObjectHandle _Handle, TElBoxUserInfoHandle NewOwner);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_ContentCreatedAt(TElBoxDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_ContentModifiedAt(TElBoxDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_CreatedAt(TElBoxDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_CreatedBy(TElBoxDataStorageObjectHandle _Handle, TElBoxUserInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_Description(TElBoxDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_set_Description(TElBoxDataStorageObjectHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_ETag(TElBoxDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_ID(TElBoxDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_ModifiedAt(TElBoxDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_ModifiedBy(TElBoxDataStorageObjectHandle _Handle, TElBoxUserInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_OwnedBy(TElBoxDataStorageObjectHandle _Handle, TElBoxUserInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_ParentID(TElBoxDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_PurgedAt(TElBoxDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_SequenceID(TElBoxDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_SharedLink(TElBoxDataStorageObjectHandle _Handle, TElBoxSharedLinkHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_Size(TElBoxDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_Status(TElBoxDataStorageObjectHandle _Handle, TSBBoxObjectStatusRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_get_TrashedAt(TElBoxDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObject_Create(TElBoxDataStorageHandle AStorage, TElBoxDataStorageObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXDATASTORAGEOBJECT */

#ifdef SB_USE_CLASS_TELBOXFILE
SB_IMPORT uint32_t SB_APIENTRY TElBoxFile_Assign(TElBoxFileHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFile_Clone(TElBoxFileHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFile_Read(TElBoxFileHandle _Handle, TStreamHandle Data);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFile_Read_1(TElBoxFileHandle _Handle, int64_t Offset, int64_t Size, TStreamHandle Data, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFile_Write(TElBoxFileHandle _Handle, TStreamHandle Data, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFile_Write_1(TElBoxFileHandle _Handle, TStreamHandle Data, int64_t DataModifiedAt, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFile_get_Comments(TElBoxFileHandle _Handle, TElBoxCommentsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFile_get_Sha1(TElBoxFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFile_get_VersionNumber(TElBoxFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFile_Create(TElBoxDataStorageHandle AStorage, TElBoxFileHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXFILE */

#ifdef SB_USE_CLASS_TELBOXFOLDER
SB_IMPORT uint32_t SB_APIENTRY TElBoxFolder_Assign(TElBoxFolderHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFolder_Clone(TElBoxFolderHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFolder_CreateFolder(TElBoxFolderHandle _Handle, const char * pcName, int32_t szName, TElBoxFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFolder_CreateObject(TElBoxFolderHandle _Handle, const char * pcName, int32_t szName, TStreamHandle Data, TElCustomDataStorageSecurityHandlerHandle Handler, TElBoxDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFolder_CreateObject_1(TElBoxFolderHandle _Handle, const char * pcName, int32_t szName, TStreamHandle Data, int64_t DataCreatedAt, int64_t DataModifiedAt, TElCustomDataStorageSecurityHandlerHandle Handler, TElBoxDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFolder_Delete(TElBoxFolderHandle _Handle, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFolder_Delete_1(TElBoxDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFolder_List(TElBoxFolderHandle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFolder_get_Collaborations(TElBoxFolderHandle _Handle, TElBoxCollaborationsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFolder_get_SyncState(TElBoxFolderHandle _Handle, TSBBoxSyncStateRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFolder_set_SyncState(TElBoxFolderHandle _Handle, TSBBoxSyncStateRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElBoxFolder_Create(TElBoxDataStorageHandle AStorage, TElBoxFolderHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXFOLDER */

#ifdef SB_USE_CLASS_TELBOXGROUPINFO
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupInfo_get_ID(TElBoxGroupInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupInfo_get_Name(TElBoxGroupInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupInfo_Create(TElBoxGroupInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXGROUPINFO */

#ifdef SB_USE_CLASS_TELBOXUSERINFO
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserInfo_Assign(TElBoxUserInfoHandle _Handle, TElBoxUserInfoHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserInfo_Clone(TElBoxUserInfoHandle _Handle, TElBoxUserInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserInfo_get_ID(TElBoxUserInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserInfo_get_Login(TElBoxUserInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserInfo_get_Name(TElBoxUserInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserInfo_Create(TElBoxUserInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXUSERINFO */

#ifdef SB_USE_CLASS_TELBOXENTERPRISE
SB_IMPORT uint32_t SB_APIENTRY TElBoxEnterprise_get_ID(TElBoxEnterpriseHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxEnterprise_get_Name(TElBoxEnterpriseHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxEnterprise_Create(TElBoxEnterpriseHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXENTERPRISE */

#ifdef SB_USE_CLASS_TELBOXUSEREMAILALIAS
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAlias_Delete(TElBoxUserEmailAliasHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAlias_MakePrimary(TElBoxUserEmailAliasHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAlias_get_Email(TElBoxUserEmailAliasHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAlias_get_ID(TElBoxUserEmailAliasHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAlias_get_IsConfirmed(TElBoxUserEmailAliasHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAlias_get_IsPrimary(TElBoxUserEmailAliasHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAlias_get_Owner(TElBoxUserEmailAliasHandle _Handle, TElBoxUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAlias_Create(TElBoxUserHandle AOwner, TElBoxUserEmailAliasHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXUSEREMAILALIAS */

#ifdef SB_USE_CLASS_TELBOXUSEREMAILALIASES
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAliases_Add(TElBoxUserEmailAliasesHandle _Handle, const char * pcEmail, int32_t szEmail, TElBoxUserEmailAliasHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAliases_IndexOf(TElBoxUserEmailAliasesHandle _Handle, TElBoxUserEmailAliasHandle Alias, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAliases_IndexOf_1(TElBoxUserEmailAliasesHandle _Handle, const char * pcID, int32_t szID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAliases_Refresh(TElBoxUserEmailAliasesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAliases_get_Count(TElBoxUserEmailAliasesHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAliases_get_Items(TElBoxUserEmailAliasesHandle _Handle, int32_t Index, TElBoxUserEmailAliasHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUserEmailAliases_Create(TElBoxUserHandle AOwner, TElBoxUserEmailAliasesHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXUSEREMAILALIASES */

#ifdef SB_USE_CLASS_TELBOXGROUPMEMBERSHIP
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMembership_Discontinue(TElBoxGroupMembershipHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMembership_get_GroupID(TElBoxGroupMembershipHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMembership_get_GroupName(TElBoxGroupMembershipHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMembership_get_ID(TElBoxGroupMembershipHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMembership_get_JoinedAt(TElBoxGroupMembershipHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMembership_get_Role(TElBoxGroupMembershipHandle _Handle, TSBBoxGroupRoleRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMembership_set_Role(TElBoxGroupMembershipHandle _Handle, TSBBoxGroupRoleRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMembership_Create(TElBoxUserHandle AOwner, TElBoxGroupMembershipHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXGROUPMEMBERSHIP */

#ifdef SB_USE_CLASS_TELBOXGROUPMEMBERSHIPS
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMemberships_Join(TElBoxGroupMembershipsHandle _Handle, TElBoxGroupHandle Group, TElBoxGroupMembershipHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMemberships_Refresh(TElBoxGroupMembershipsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMemberships_get_Count(TElBoxGroupMembershipsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMemberships_get_Items(TElBoxGroupMembershipsHandle _Handle, int32_t Index, TElBoxGroupMembershipHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMemberships_Create(TElBoxUserHandle AOwner, TElBoxGroupMembershipsHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXGROUPMEMBERSHIPS */

#ifdef SB_USE_CLASS_TELBOXUSER
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_Assign(TElBoxUserHandle _Handle, TElBoxUserInfoHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_BeginUpdate(TElBoxUserHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_Clone(TElBoxUserHandle _Handle, TElBoxUserInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_Delete(TElBoxUserHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_EndUpdate(TElBoxUserHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_Refresh(TElBoxUserHandle _Handle, int8_t RequestSpecialFields);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_RemoveFromEnterprise(TElBoxUserHandle _Handle, int8_t Notify);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_RequestPasswordReset(TElBoxUserHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_Address(TElBoxUserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_set_Address(TElBoxUserHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_CanSeeManagedUsers(TElBoxUserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_set_CanSeeManagedUsers(TElBoxUserHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_EmailAliases(TElBoxUserHandle _Handle, TElBoxUserEmailAliasesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_Enterprise(TElBoxUserHandle _Handle, TElBoxEnterpriseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_ID(TElBoxUserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_IsExemptFromDeviceLimits(TElBoxUserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_set_IsExemptFromDeviceLimits(TElBoxUserHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_IsExemptFromLoginVerification(TElBoxUserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_set_IsExemptFromLoginVerification(TElBoxUserHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_IsSyncEnabled(TElBoxUserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_set_IsSyncEnabled(TElBoxUserHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_Login(TElBoxUserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_Memberships(TElBoxUserHandle _Handle, TElBoxGroupMembershipsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_Name(TElBoxUserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_set_Name(TElBoxUserHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_JobTitle(TElBoxUserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_set_JobTitle(TElBoxUserHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_Language(TElBoxUserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_set_Language(TElBoxUserHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_Phone(TElBoxUserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_set_Phone(TElBoxUserHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_Role(TElBoxUserHandle _Handle, TSBBoxUserRoleRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_set_Role(TElBoxUserHandle _Handle, TSBBoxUserRoleRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_SpaceAmount(TElBoxUserHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_set_SpaceAmount(TElBoxUserHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_SpaceUsed(TElBoxUserHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_get_Status(TElBoxUserHandle _Handle, TSBBoxUserStatusRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_set_Status(TElBoxUserHandle _Handle, TSBBoxUserStatusRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUser_Create(TElBoxDataStorageHandle AStorage, TElBoxUserHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXUSER */

#ifdef SB_USE_CLASS_TELBOXUSERS
SB_IMPORT uint32_t SB_APIENTRY TElBoxUsers_Add(TElBoxUsersHandle _Handle, const char * pcLogin, int32_t szLogin, const char * pcName, int32_t szName, TElBoxUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUsers_Clear(TElBoxUsersHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUsers_IndexOf(TElBoxUsersHandle _Handle, TElBoxUserHandle User, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUsers_IndexOf_1(TElBoxUsersHandle _Handle, const char * pcID, int32_t szID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUsers_Refresh(TElBoxUsersHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUsers_get_Count(TElBoxUsersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUsers_get_Items(TElBoxUsersHandle _Handle, int32_t Index, TElBoxUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxUsers_Create(TElBoxDataStorageHandle AStorage, TElBoxUsersHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXUSERS */

#ifdef SB_USE_CLASS_TELBOXGROUPMEMBER
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMember_Refresh(TElBoxGroupMemberHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMember_Remove(TElBoxGroupMemberHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMember_get_ID(TElBoxGroupMemberHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMember_get_JoinedAt(TElBoxGroupMemberHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMember_get_Role(TElBoxGroupMemberHandle _Handle, TSBBoxGroupRoleRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMember_set_Role(TElBoxGroupMemberHandle _Handle, TSBBoxGroupRoleRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMember_get_UserID(TElBoxGroupMemberHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMember_get_UserLogin(TElBoxGroupMemberHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMember_get_UserName(TElBoxGroupMemberHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMember_Create(TElBoxGroupHandle AOwner, TElBoxGroupMemberHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXGROUPMEMBER */

#ifdef SB_USE_CLASS_TELBOXGROUPMEMBERS
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMembers_Add(TElBoxGroupMembersHandle _Handle, TElBoxUserHandle User, TElBoxGroupMemberHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMembers_Refresh(TElBoxGroupMembersHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMembers_get_Count(TElBoxGroupMembersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMembers_get_Items(TElBoxGroupMembersHandle _Handle, int32_t Index, TElBoxGroupMemberHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroupMembers_Create(TElBoxGroupHandle AOwner, TElBoxGroupMembersHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXGROUPMEMBERS */

#ifdef SB_USE_CLASS_TELBOXGROUP
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroup_Delete(TElBoxGroupHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroup_Refresh(TElBoxGroupHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroup_get_CreatedAt(TElBoxGroupHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroup_get_Members(TElBoxGroupHandle _Handle, TElBoxGroupMembersHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroup_get_ModifiedAt(TElBoxGroupHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroup_get_Name(TElBoxGroupHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroup_set_Name(TElBoxGroupHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroup_Create(TElBoxDataStorageHandle AStorage, TElBoxGroupHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXGROUP */

#ifdef SB_USE_CLASS_TELBOXGROUPS
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroups_Add(TElBoxGroupsHandle _Handle, const char * pcName, int32_t szName, TElBoxGroupHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroups_IndexOf(TElBoxGroupsHandle _Handle, const char * pcID, int32_t szID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroups_IndexOf_1(TElBoxGroupsHandle _Handle, TElBoxGroupHandle Group, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroups_Refresh(TElBoxGroupsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroups_get_Count(TElBoxGroupsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroups_get_Item(TElBoxGroupsHandle _Handle, int32_t Index, TElBoxGroupHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxGroups_Create(TElBoxDataStorageHandle AStorage, TElBoxGroupsHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXGROUPS */

#ifdef SB_USE_CLASS_TELBOXSHAREDLINK
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLink_Assign(TElBoxSharedLinkHandle _Handle, TElBoxSharedLinkHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLink_Clone(TElBoxSharedLinkHandle _Handle, TElBoxSharedLinkHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLink_get_Access(TElBoxSharedLinkHandle _Handle, TSBBoxSharedLinkAccessRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLink_get_DownloadCount(TElBoxSharedLinkHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLink_get_DownloadURL(TElBoxSharedLinkHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLink_get_IsPasswordEnabled(TElBoxSharedLinkHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLink_get_Permissions(TElBoxSharedLinkHandle _Handle, TElBoxSharedLinkPermissionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLink_get_PreviewCount(TElBoxSharedLinkHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLink_get_UnsharedAt(TElBoxSharedLinkHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLink_get_URL(TElBoxSharedLinkHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLink_get_VanityURL(TElBoxSharedLinkHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLink_Create(TElBoxDataStorageObjectHandle AOwner, TElBoxSharedLinkHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXSHAREDLINK */

#ifdef SB_USE_CLASS_TELBOXSHAREDLINKPERMISSIONS
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLinkPermissions_Assign(TElBoxSharedLinkPermissionsHandle _Handle, TElBoxSharedLinkPermissionsHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLinkPermissions_Clone(TElBoxSharedLinkPermissionsHandle _Handle, TElBoxSharedLinkPermissionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLinkPermissions_get_CanDownload(TElBoxSharedLinkPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLinkPermissions_get_CanPreview(TElBoxSharedLinkPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxSharedLinkPermissions_Create(TElBoxSharedLinkHandle AOwner, TElBoxSharedLinkPermissionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXSHAREDLINKPERMISSIONS */

#ifdef SB_USE_CLASS_TELBOXCOLLABORATION
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_Accept(TElBoxCollaborationHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_Delete(TElBoxCollaborationHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_Refresh(TElBoxCollaborationHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_Reject(TElBoxCollaborationHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_get_AcknowledgedAt(TElBoxCollaborationHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_get_CreatedAt(TElBoxCollaborationHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_get_CreatedBy(TElBoxCollaborationHandle _Handle, TElBoxUserInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_get_ExpiresAt(TElBoxCollaborationHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_get_Group(TElBoxCollaborationHandle _Handle, TElBoxGroupInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_get_ID(TElBoxCollaborationHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_get_ModifiedAt(TElBoxCollaborationHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_get_Role(TElBoxCollaborationHandle _Handle, TSBBoxCollaborationRoleRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_set_Role(TElBoxCollaborationHandle _Handle, TSBBoxCollaborationRoleRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_get_Status(TElBoxCollaborationHandle _Handle, TSBBoxCollaborationStatusRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_get_User(TElBoxCollaborationHandle _Handle, TElBoxUserInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaboration_Create(TElBoxFolderHandle AOwner, TElBoxCollaborationHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXCOLLABORATION */

#ifdef SB_USE_CLASS_TELBOXCOLLABORATIONS
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaborations_Add(TElBoxCollaborationsHandle _Handle, TElBoxGroupInfoHandle Group, TSBBoxCollaborationRoleRaw Role, int8_t Notify, TElBoxCollaborationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaborations_Add_1(TElBoxCollaborationsHandle _Handle, TElBoxUserInfoHandle User, TSBBoxCollaborationRoleRaw Role, int8_t Notify, TElBoxCollaborationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaborations_Add_2(TElBoxCollaborationsHandle _Handle, const char * pcUserLogin, int32_t szUserLogin, TSBBoxCollaborationRoleRaw Role, int8_t Notify, TElBoxCollaborationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaborations_IndexOf(TElBoxCollaborationsHandle _Handle, const char * pcID, int32_t szID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaborations_IndexOf_1(TElBoxCollaborationsHandle _Handle, TElBoxCollaborationHandle Collaboration, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaborations_Refresh(TElBoxCollaborationsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaborations_get_Count(TElBoxCollaborationsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaborations_get_Item(TElBoxCollaborationsHandle _Handle, int32_t Index, TElBoxCollaborationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxCollaborations_Create(TElBoxFolderHandle AOwner, TElBoxCollaborationsHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXCOLLABORATIONS */

#ifdef SB_USE_CLASS_TELBOXDATASTORAGEOBJECTPERMISSIONS
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObjectPermissions_Assign(TElBoxDataStorageObjectPermissionsHandle _Handle, TElBoxDataStorageObjectPermissionsHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObjectPermissions_Clone(TElBoxDataStorageObjectPermissionsHandle _Handle, TElBoxDataStorageObjectPermissionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObjectPermissions_get_CanComment(TElBoxDataStorageObjectPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObjectPermissions_get_CanDelete(TElBoxDataStorageObjectPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObjectPermissions_get_CanDownload(TElBoxDataStorageObjectPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObjectPermissions_get_CanInviteCollaborator(TElBoxDataStorageObjectPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObjectPermissions_get_CanPreview(TElBoxDataStorageObjectPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObjectPermissions_get_CanRename(TElBoxDataStorageObjectPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObjectPermissions_get_CanSetShareAccess(TElBoxDataStorageObjectPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObjectPermissions_get_CanShare(TElBoxDataStorageObjectPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObjectPermissions_get_CanUpload(TElBoxDataStorageObjectPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxDataStorageObjectPermissions_Create(TElBoxDataStorageObjectHandle AOwner, TElBoxDataStorageObjectPermissionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXDATASTORAGEOBJECTPERMISSIONS */

#ifdef SB_USE_CLASS_TELBOXCOMMENT
SB_IMPORT uint32_t SB_APIENTRY TElBoxComment_Clone(TElBoxCommentHandle _Handle, TElBoxCommentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComment_Delete(TElBoxCommentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComment_Refresh(TElBoxCommentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComment_Reply(TElBoxCommentHandle _Handle, const char * pcMessage, int32_t szMessage, TElBoxCommentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComment_get_CreatedAt(TElBoxCommentHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComment_get_CreatedBy(TElBoxCommentHandle _Handle, TElBoxUserInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComment_get_ID(TElBoxCommentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComment_get_IsReply(TElBoxCommentHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComment_get_Message(TElBoxCommentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComment_set_Message(TElBoxCommentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComment_get_ModifiedAt(TElBoxCommentHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComment_get_TaggedMessage(TElBoxCommentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComment_Create(TElBoxFileHandle AOwner, TElBoxCommentHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXCOMMENT */

#ifdef SB_USE_CLASS_TELBOXCOMMENTS
SB_IMPORT uint32_t SB_APIENTRY TElBoxComments_Add(TElBoxCommentsHandle _Handle, const char * pcMessage, int32_t szMessage, TElBoxCommentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComments_IndexOf(TElBoxCommentsHandle _Handle, const char * pcID, int32_t szID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComments_IndexOf_1(TElBoxCommentsHandle _Handle, TElBoxCommentHandle Comment, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComments_Refresh(TElBoxCommentsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComments_get_Count(TElBoxCommentsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComments_get_Item(TElBoxCommentsHandle _Handle, int32_t Index, TElBoxCommentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoxComments_Create(TElBoxFileHandle AOwner, TElBoxCommentsHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOXCOMMENTS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElBoxDataStorage_ce_ptr;
extern zend_class_entry *TElBoxDataStorageObject_ce_ptr;
extern zend_class_entry *TElBoxFile_ce_ptr;
extern zend_class_entry *TElBoxFolder_ce_ptr;
extern zend_class_entry *TElBoxGroupInfo_ce_ptr;
extern zend_class_entry *TElBoxUserInfo_ce_ptr;
extern zend_class_entry *TElBoxEnterprise_ce_ptr;
extern zend_class_entry *TElBoxUserEmailAlias_ce_ptr;
extern zend_class_entry *TElBoxUserEmailAliases_ce_ptr;
extern zend_class_entry *TElBoxGroupMembership_ce_ptr;
extern zend_class_entry *TElBoxGroupMemberships_ce_ptr;
extern zend_class_entry *TElBoxUser_ce_ptr;
extern zend_class_entry *TElBoxUsers_ce_ptr;
extern zend_class_entry *TElBoxGroupMember_ce_ptr;
extern zend_class_entry *TElBoxGroupMembers_ce_ptr;
extern zend_class_entry *TElBoxGroup_ce_ptr;
extern zend_class_entry *TElBoxGroups_ce_ptr;
extern zend_class_entry *TElBoxSharedLink_ce_ptr;
extern zend_class_entry *TElBoxSharedLinkPermissions_ce_ptr;
extern zend_class_entry *TElBoxCollaboration_ce_ptr;
extern zend_class_entry *TElBoxCollaborations_ce_ptr;
extern zend_class_entry *TElBoxDataStorageObjectPermissions_ce_ptr;
extern zend_class_entry *TElBoxComment_ce_ptr;
extern zend_class_entry *TElBoxComments_ce_ptr;

void Register_TElBoxDataStorage(TSRMLS_D);
void Register_TElBoxDataStorageObject(TSRMLS_D);
void Register_TElBoxFile(TSRMLS_D);
void Register_TElBoxFolder(TSRMLS_D);
void Register_TElBoxGroupInfo(TSRMLS_D);
void Register_TElBoxUserInfo(TSRMLS_D);
void Register_TElBoxEnterprise(TSRMLS_D);
void Register_TElBoxUserEmailAlias(TSRMLS_D);
void Register_TElBoxUserEmailAliases(TSRMLS_D);
void Register_TElBoxGroupMembership(TSRMLS_D);
void Register_TElBoxGroupMemberships(TSRMLS_D);
void Register_TElBoxUser(TSRMLS_D);
void Register_TElBoxUsers(TSRMLS_D);
void Register_TElBoxGroupMember(TSRMLS_D);
void Register_TElBoxGroupMembers(TSRMLS_D);
void Register_TElBoxGroup(TSRMLS_D);
void Register_TElBoxGroups(TSRMLS_D);
void Register_TElBoxSharedLink(TSRMLS_D);
void Register_TElBoxSharedLinkPermissions(TSRMLS_D);
void Register_TElBoxCollaboration(TSRMLS_D);
void Register_TElBoxCollaborations(TSRMLS_D);
void Register_TElBoxDataStorageObjectPermissions(TSRMLS_D);
void Register_TElBoxComment(TSRMLS_D);
void Register_TElBoxComments(TSRMLS_D);
void Register_SBBoxDataStorage_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBBOXDATASTORAGE */

