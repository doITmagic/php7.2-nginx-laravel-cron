#ifndef __INC_SBCARDCOMMON
#define __INC_SBCARDCOMMON

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbutils.h"
#include "sbtypes.h"
#ifdef SB_WINDOWS
#include "sbscwin.h"
#endif

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifndef SB_WINDOWS
#define SB_SCARD_S_SUCCESS 	0
#endif

typedef TElClassHandle TElSmartCardObjectHandle;

typedef uint8_t TSBCryptoCardTypeRaw;

typedef enum
{
	_ctUnknown = 0,
	ctPIV = 1,
	ctEMV = 2
} TSBCryptoCardType;

#ifdef SB_USE_CLASS_TELSMARTCARDOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardObject_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELSMARTCARDOBJECT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSmartCardObject_ce_ptr;

void Register_TElSmartCardObject(TSRMLS_D);
#ifndef SB_WINDOWS
void Register_SBCardCommon_Constants(int module_number TSRMLS_DC);
#endif
void Register_SBCardCommon_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCARDCOMMON */
