#ifndef __INC_SBCARDMANAGER
#define __INC_SBCARDMANAGER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#ifdef SB_WINDOWS
#include "sbtypes.h"
#include "sbcustomcertstorage.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbalgorithmidentifier.h"
#include "sbconstants.h"
#include "sbsharedresource.h"
#include "sbcryptoprov.h"
#include "sbcardcommon.h"
#include "sbcryptoprovcard.h"
#include "sbcryptoprovcardpiv.h"
#include "sbuniversalkeystorage.h"
#include "sbuniversalcertstorage.h"
#include "sbscwin.h"
#endif

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef SB_WINDOWS
typedef TElClassHandle TElCryptoCardManagerHandle;

typedef TElClassHandle TElCryptoCardReaderHandle;

#ifdef SB_USE_CLASS_TELCRYPTOCARDMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElCryptoCardManager_Refresh(TElCryptoCardManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCryptoCardManager_DiscardReader(TElCryptoCardManagerHandle _Handle, TElCryptoCardReaderHandle Reader);
SB_IMPORT uint32_t SB_APIENTRY TElCryptoCardManager_get_Count(TElCryptoCardManagerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCryptoCardManager_get_CardReaders(TElCryptoCardManagerHandle _Handle, int32_t Index, TElCryptoCardReaderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCryptoCardManager_Create(TComponentHandle AOwner, TElCryptoCardManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELCRYPTOCARDMANAGER */

#ifdef SB_USE_CLASS_TELCRYPTOCARDREADER
SB_IMPORT uint32_t SB_APIENTRY TElCryptoCardReader_GetKeyStorage(TElCryptoCardReaderHandle _Handle, TElUniversalKeyStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCryptoCardReader_GetCertStorage(TElCryptoCardReaderHandle _Handle, TElUniversalCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCryptoCardReader_Login(TElCryptoCardReaderHandle _Handle, const char * pcPIN, int32_t szPIN);
SB_IMPORT uint32_t SB_APIENTRY TElCryptoCardReader_get_CardType(TElCryptoCardReaderHandle _Handle, TSBCryptoCardTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCryptoCardReader_get_Name(TElCryptoCardReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCryptoCardReader_get_CardID(TElCryptoCardReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCryptoCardReader_Create(TElCryptoCardReaderHandle * OutResult);
#endif /* SB_USE_CLASS_TELCRYPTOCARDREADER */
#endif

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef SB_WINDOWS
extern zend_class_entry *TElCryptoCardManager_ce_ptr;
extern zend_class_entry *TElCryptoCardReader_ce_ptr;

void Register_TElCryptoCardManager(TSRMLS_D);
void Register_TElCryptoCardReader(TSRMLS_D);
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCARDMANAGER */
