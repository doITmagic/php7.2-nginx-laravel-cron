#ifndef __INC_SBCERTRETRIEVER
#define __INC_SBCERTRETRIEVER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbencoding.h"
#include "sbconstants.h"
#include "sbx509.h"
#include "sbx509ext.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_CERT_RETRIEVER 	110592
#define SB_ERROR_CERT_RETRIEVER_ERROR_FLAG 	2048
#define SB_CERT_RETRIEVER_ERROR_NO_PARAMETERS 	112645
#define SB_CERT_RETRIEVER_ERROR_NO_REPLY 	112646

typedef TElClassHandle TElCustomCertificateRetrieverHandle;

typedef TElClassHandle TElFileCertificateRetrieverHandle;

typedef TElFileCertificateRetrieverHandle ElFileCertificateRetrieverHandle;

typedef TElClassHandle TElCustomCertificateRetrieverFactoryHandle;

typedef TElCustomCertificateRetrieverFactoryHandle ElCustomCertificateRetrieverFactoryHandle;

typedef TElClassHandle TElCertificateRetrieverManagerHandle;

typedef TElCertificateRetrieverManagerHandle ElCertRetrieverManagerHandle;

typedef void (SB_CALLBACK *TSBCertificateRetrievalEvent)(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle Certificate, TSBGeneralNameRaw NameType, const char * pcLocation, int32_t szLocation, TElX509CertificateHandle * CACertificate);

#ifdef SB_USE_CLASS_TELCUSTOMCERTIFICATERETRIEVER
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertificateRetriever_SupportsLocation(TElCustomCertificateRetrieverHandle _Handle, TSBGeneralNameRaw NameType, const char * pcURI, int32_t szURI, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertificateRetriever_RetrieveCertificate(TElCustomCertificateRetrieverHandle _Handle, TElX509CertificateHandle Certificate, TSBGeneralNameRaw NameType, const char * pcURL, int32_t szURL, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertificateRetriever_Create(TComponentHandle Owner, TElCustomCertificateRetrieverHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMCERTIFICATERETRIEVER */

#ifdef SB_USE_CLASS_TELFILECERTIFICATERETRIEVER
SB_IMPORT uint32_t SB_APIENTRY TElFileCertificateRetriever_RetrieveCertificate(TElFileCertificateRetrieverHandle _Handle, TElX509CertificateHandle Certificate, TSBGeneralNameRaw NameType, const char * pcURL, int32_t szURL, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertificateRetriever_SupportsLocation(TElFileCertificateRetrieverHandle _Handle, TSBGeneralNameRaw NameType, const char * pcURI, int32_t szURI, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertificateRetriever_get_OnCertificateNeeded(TElFileCertificateRetrieverHandle _Handle, TSBCertificateRetrievalEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertificateRetriever_set_OnCertificateNeeded(TElFileCertificateRetrieverHandle _Handle, TSBCertificateRetrievalEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertificateRetriever_Create(TComponentHandle Owner, TElCustomCertificateRetrieverHandle * OutResult);
#endif /* SB_USE_CLASS_TELFILECERTIFICATERETRIEVER */

#ifdef SB_USE_CLASS_TELCUSTOMCERTIFICATERETRIEVERFACTORY
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertificateRetrieverFactory_SupportsLocation(TElCustomCertificateRetrieverFactoryHandle _Handle, TSBGeneralNameRaw NameType, const char * pcURI, int32_t szURI, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertificateRetrieverFactory_GetClientInstance(TElCustomCertificateRetrieverFactoryHandle _Handle, TObjectHandle Validator, TElCustomCertificateRetrieverHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertificateRetrieverFactory_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMCERTIFICATERETRIEVERFACTORY */

#ifdef SB_USE_CLASS_TELCERTIFICATERETRIEVERMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRetrieverManager_FindCertificateRetrieverByLocation(TElCertificateRetrieverManagerHandle _Handle, TSBGeneralNameRaw NameType, const char * pcLocation, int32_t szLocation, TObjectHandle Validator, TElCustomCertificateRetrieverHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRetrieverManager_RegisterCertificateRetrieverFactory(TElCertificateRetrieverManagerHandle _Handle, TElCustomCertificateRetrieverFactoryHandle Factory);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRetrieverManager_UnregisterCertificateRetrieverFactory(TElCertificateRetrieverManagerHandle _Handle, TElCustomCertificateRetrieverFactoryHandle Factory);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRetrieverManager_Create(TElCertificateRetrieverManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELCERTIFICATERETRIEVERMANAGER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElCustomCertificateRetriever_ce_ptr;
extern zend_class_entry *TElFileCertificateRetriever_ce_ptr;
extern zend_class_entry *TElCustomCertificateRetrieverFactory_ce_ptr;
extern zend_class_entry *TElCertificateRetrieverManager_ce_ptr;

void SB_CALLBACK TSBCertificateRetrievalEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle Certificate, TSBGeneralNameRaw NameType, const char * pcLocation, int32_t szLocation, TElX509CertificateHandle * CACertificate);
void Register_TElCustomCertificateRetriever(TSRMLS_D);
void Register_TElFileCertificateRetriever(TSRMLS_D);
void Register_TElCustomCertificateRetrieverFactory(TSRMLS_D);
void Register_TElCertificateRetrieverManager(TSRMLS_D);
SB_PHP_FUNCTION(SBCertRetriever, CertificateRetrieverManagerAddRef);
SB_PHP_FUNCTION(SBCertRetriever, CertificateRetrieverManagerRelease);
void Register_SBCertRetriever_Constants(int module_number TSRMLS_DC);
void Register_SBCertRetriever_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_CERTRETRIEVER
SB_IMPORT uint32_t SB_APIENTRY SBCertRetriever_CertificateRetrieverManagerAddRef(TElCertificateRetrieverManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCertRetriever_CertificateRetrieverManagerRelease(void);
#endif /* SB_USE_GLOBAL_PROCS_CERTRETRIEVER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCERTRETRIEVER */

