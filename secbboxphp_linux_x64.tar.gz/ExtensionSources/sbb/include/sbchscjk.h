#ifndef __INC_SBCHSCJK
#define __INC_SBCHSCJK

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbchsconvbase.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SShiftJIS 	"Japanese (Shift-JIS)"
#define SB_SEUC_JP 	"Japanese (EUC)"
#define SB_SISO_2022_JP 	"Japanese (ISO-2022-JP)"
#define SB_SISO_2022_JP_1 	"Japanese (ISO-2022-JP-1)"
#define SB_SISO_2022_JP_2 	"Japanese (ISO-2022-JP-2)"
#define SB_SGBK 	"Chinese Simplified (GBK/GB2312)"
#define SB_SHZ_GB_2312 	"Chinese Simplified (HZ-GB2312)"
#define SB_SGB_18030 	"Chinese Simplified (GB-18030)"
#define SB_SISO_2022_CN 	"Chinese Simplified (ISO-2022-CN)"
#define SB_SISO_2022_CN_EXT 	"Chinese Simplified (ISO-2022-CN-EXT)"
#define SB_SBigFiveHKSCS 	"Chinese Traditional (Big5 HKSCS)"
#define SB_SCP950 	"Chinese Traditional (Windows-950)"
#define SB_SEUC_TW 	"Chinese Traditional (EUC-TW)"
#define SB_SCP949 	"Korean (CP949)"
#define SB_SJohab 	"Korean (Johab)"
#define SB_SEUC_KR 	"Korean (EUC)"
#define SB_SISO_2022_KR 	"Korean (ISO-2022-KR)"

typedef TElClassHandle TPlCustomEUCCharsetHandle;

typedef TElClassHandle TPlCustomISO_2022CharsetHandle;

typedef TElClassHandle TPlShiftJISCodeHandle;

typedef TElClassHandle TPlShiftJISHandle;

typedef TElClassHandle TPlEUC_JPHandle;

typedef TElClassHandle TPlISO_2022_JPHandle;

typedef TElClassHandle TPlISO_2022_JP_1Handle;

typedef TElClassHandle TPlISO_2022_JP_2Handle;

typedef TElClassHandle TPlGBKHandle;

typedef TElClassHandle TPlHZ_GB_2312Handle;

typedef TElClassHandle TPlGB_18030CodeHandle;

typedef TElClassHandle TPlGB_18030Handle;

typedef TElClassHandle TPlISO_2022_CNHandle;

typedef TElClassHandle TPlISO_2022_CN_EXTHandle;

typedef TElClassHandle TPlBigFiveHKSCSHandle;

typedef TElClassHandle TPlCP950Handle;

typedef TElClassHandle TPlCNS_11643Handle;

typedef TElClassHandle TPlEUC_TWHandle;

typedef TElClassHandle TPlCP949Handle;

typedef TElClassHandle TPlJohabHangulHandle;

typedef TElClassHandle TPlJohabNonHangulHandle;

typedef TElClassHandle TPlJohabHandle;

typedef TElClassHandle TPlEUC_KRHandle;

typedef TElClassHandle TPlISO_2022_KRHandle;

#ifdef SB_USE_CLASS_TPLCUSTOMEUCCHARSET
SB_IMPORT uint32_t SB_APIENTRY TPlCustomEUCCharset_ConvertFromUCS(TPlCustomEUCCharsetHandle _Handle, uint32_t Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomEUCCharset_ConvertToUCS(TPlCustomEUCCharsetHandle _Handle, TStreamHandle Stream, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomEUCCharset_ConvertBufferToUCS(TPlCustomEUCCharsetHandle _Handle, const void * Buf, int32_t Count, int8_t IsLastChunk, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomEUCCharset_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomEUCCharset_Create(TPlCustomEUCCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLCUSTOMEUCCHARSET */

#ifdef SB_USE_CLASS_TPLCUSTOMISO_2022CHARSET
SB_IMPORT uint32_t SB_APIENTRY TPlCustomISO_2022Charset_ConvertFromUCS(TPlCustomISO_2022CharsetHandle _Handle, uint32_t Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomISO_2022Charset_ConvertToUCS(TPlCustomISO_2022CharsetHandle _Handle, TStreamHandle Stream, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomISO_2022Charset_ConvertBufferToUCS(TPlCustomISO_2022CharsetHandle _Handle, const void * Buf, int32_t Count, int8_t IsLastChunk, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomISO_2022Charset_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomISO_2022Charset_Create(TPlCustomISO_2022CharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLCUSTOMISO_2022CHARSET */

#ifdef SB_USE_CLASS_TPLSHIFTJISCODE
SB_IMPORT uint32_t SB_APIENTRY TPlShiftJISCode_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlShiftJISCode_Create(TPlConvertingCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLSHIFTJISCODE */

#ifdef SB_USE_CLASS_TPLSHIFTJIS
SB_IMPORT uint32_t SB_APIENTRY TPlShiftJIS_GetCategory(TPlShiftJISHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlShiftJIS_GetDescription(TPlShiftJISHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlShiftJIS_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlShiftJIS_Create(TPlMixedCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlShiftJIS_CreateShift(int32_t Shift, TPlMixedCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLSHIFTJIS */

#ifdef SB_USE_CLASS_TPLEUC_JP
SB_IMPORT uint32_t SB_APIENTRY TPlEUC_JP_GetCategory(TPlEUC_JPHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlEUC_JP_GetDescription(TPlEUC_JPHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlEUC_JP_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlEUC_JP_Create(TPlCustomEUCCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLEUC_JP */

#ifdef SB_USE_CLASS_TPLISO_2022_JP
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_JP_GetCategory(TPlISO_2022_JPHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_JP_GetDescription(TPlISO_2022_JPHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_JP_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_JP_Create(TPlCustomISO_2022CharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLISO_2022_JP */

#ifdef SB_USE_CLASS_TPLISO_2022_JP_1
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_JP_1_GetCategory(TPlISO_2022_JP_1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_JP_1_GetDescription(TPlISO_2022_JP_1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_JP_1_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_JP_1_Create(TPlCustomISO_2022CharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLISO_2022_JP_1 */

#ifdef SB_USE_CLASS_TPLISO_2022_JP_2
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_JP_2_GetCategory(TPlISO_2022_JP_2Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_JP_2_GetDescription(TPlISO_2022_JP_2Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_JP_2_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_JP_2_Create(TPlCustomISO_2022CharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLISO_2022_JP_2 */

#ifdef SB_USE_CLASS_TPLGBK
SB_IMPORT uint32_t SB_APIENTRY TPlGBK_GetCategory(TPlGBKHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGBK_GetDescription(TPlGBKHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGBK_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGBK_Create(TPlMixedCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGBK_CreateShift(int32_t Shift, TPlMixedCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLGBK */

#ifdef SB_USE_CLASS_TPLHZ_GB_2312
SB_IMPORT uint32_t SB_APIENTRY TPlHZ_GB_2312_GetCategory(TPlHZ_GB_2312Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlHZ_GB_2312_GetDescription(TPlHZ_GB_2312Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlHZ_GB_2312_ConvertFromUCS(TPlHZ_GB_2312Handle _Handle, uint32_t Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlHZ_GB_2312_ConvertToUCS(TPlHZ_GB_2312Handle _Handle, TStreamHandle Stream, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlHZ_GB_2312_ConvertBufferToUCS(TPlHZ_GB_2312Handle _Handle, const void * Buf, int32_t Count, int8_t IsLastChunk, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlHZ_GB_2312_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlHZ_GB_2312_Create(TPlHZ_GB_2312Handle * OutResult);
#endif /* SB_USE_CLASS_TPLHZ_GB_2312 */

#ifdef SB_USE_CLASS_TPLGB_18030CODE
SB_IMPORT uint32_t SB_APIENTRY TPlGB_18030Code_CanConvert(TPlGB_18030CodeHandle _Handle, uint32_t Char, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGB_18030Code_ConvertFromUCS(TPlGB_18030CodeHandle _Handle, uint32_t Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGB_18030Code_ConvertToUCS(TPlGB_18030CodeHandle _Handle, TStreamHandle Stream, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGB_18030Code_ConvertBufferToUCS(TPlGB_18030CodeHandle _Handle, const void * Buf, int32_t Count, int8_t IsLastChunk, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGB_18030Code_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGB_18030Code_Create(TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGB_18030Code_CreateShift(int32_t Shift, TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGB_18030Code_CreateNoInit(TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGB_18030Code_CreateForFinalize(TPlCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLGB_18030CODE */

#ifdef SB_USE_CLASS_TPLGB_18030
SB_IMPORT uint32_t SB_APIENTRY TPlGB_18030_GetCategory(TPlGB_18030Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGB_18030_GetDescription(TPlGB_18030Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGB_18030_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGB_18030_Create(TPlMixedCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlGB_18030_CreateShift(int32_t Shift, TPlMixedCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLGB_18030 */

#ifdef SB_USE_CLASS_TPLISO_2022_CN
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_CN_GetCategory(TPlISO_2022_CNHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_CN_GetDescription(TPlISO_2022_CNHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_CN_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_CN_Create(TPlCustomISO_2022CharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLISO_2022_CN */

#ifdef SB_USE_CLASS_TPLISO_2022_CN_EXT
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_CN_EXT_GetCategory(TPlISO_2022_CN_EXTHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_CN_EXT_GetDescription(TPlISO_2022_CN_EXTHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_CN_EXT_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_CN_EXT_Create(TPlCustomISO_2022CharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLISO_2022_CN_EXT */

#ifdef SB_USE_CLASS_TPLBIGFIVEHKSCS
SB_IMPORT uint32_t SB_APIENTRY TPlBigFiveHKSCS_GetCategory(TPlBigFiveHKSCSHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlBigFiveHKSCS_GetDescription(TPlBigFiveHKSCSHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlBigFiveHKSCS_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlBigFiveHKSCS_Create(TPlMixedCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlBigFiveHKSCS_CreateShift(int32_t Shift, TPlMixedCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLBIGFIVEHKSCS */

#ifdef SB_USE_CLASS_TPLCP950
SB_IMPORT uint32_t SB_APIENTRY TPlCP950_GetCategory(TPlCP950Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCP950_GetDescription(TPlCP950Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCP950_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCP950_Create(TPlMixedCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCP950_CreateShift(int32_t Shift, TPlMixedCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLCP950 */

#ifdef SB_USE_CLASS_TPLCNS_11643
SB_IMPORT uint32_t SB_APIENTRY TPlCNS_11643_ConvertFromUCS(TPlCNS_11643Handle _Handle, uint32_t Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCNS_11643_ConvertToUCS(TPlCNS_11643Handle _Handle, TStreamHandle Stream, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCNS_11643_ConvertBufferToUCS(TPlCNS_11643Handle _Handle, const void * Buf, int32_t Count, int8_t IsLastChunk, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCNS_11643_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCNS_11643_Create(TPlMixedCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCNS_11643_CreateShift(int32_t Shift, TPlMixedCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLCNS_11643 */

#ifdef SB_USE_CLASS_TPLEUC_TW
SB_IMPORT uint32_t SB_APIENTRY TPlEUC_TW_GetCategory(TPlEUC_TWHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlEUC_TW_GetDescription(TPlEUC_TWHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlEUC_TW_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlEUC_TW_Create(TPlCustomEUCCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLEUC_TW */

#ifdef SB_USE_CLASS_TPLCP949
SB_IMPORT uint32_t SB_APIENTRY TPlCP949_GetCategory(TPlCP949Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCP949_GetDescription(TPlCP949Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCP949_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCP949_Create(TPlMixedCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCP949_CreateShift(int32_t Shift, TPlMixedCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLCP949 */

#ifdef SB_USE_CLASS_TPLJOHABHANGUL
SB_IMPORT uint32_t SB_APIENTRY TPlJohabHangul_CanConvert(TPlJohabHangulHandle _Handle, uint32_t Char, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlJohabHangul_ConvertFromUCS(TPlJohabHangulHandle _Handle, uint32_t Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlJohabHangul_ConvertToUCS(TPlJohabHangulHandle _Handle, TStreamHandle Stream, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlJohabHangul_ConvertBufferToUCS(TPlJohabHangulHandle _Handle, const void * Buf, int32_t Count, int8_t IsLastChunk, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlJohabHangul_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlJohabHangul_Create(TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlJohabHangul_CreateShift(int32_t Shift, TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlJohabHangul_CreateNoInit(TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlJohabHangul_CreateForFinalize(TPlCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLJOHABHANGUL */

#ifdef SB_USE_CLASS_TPLJOHABNONHANGUL
SB_IMPORT uint32_t SB_APIENTRY TPlJohabNonHangul_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlJohabNonHangul_Create(TPlConvertingCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLJOHABNONHANGUL */

#ifdef SB_USE_CLASS_TPLJOHAB
SB_IMPORT uint32_t SB_APIENTRY TPlJohab_GetCategory(TPlJohabHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlJohab_GetDescription(TPlJohabHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlJohab_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlJohab_Create(TPlMixedCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlJohab_CreateShift(int32_t Shift, TPlMixedCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLJOHAB */

#ifdef SB_USE_CLASS_TPLEUC_KR
SB_IMPORT uint32_t SB_APIENTRY TPlEUC_KR_GetCategory(TPlEUC_KRHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlEUC_KR_GetDescription(TPlEUC_KRHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlEUC_KR_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlEUC_KR_Create(TPlCustomEUCCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLEUC_KR */

#ifdef SB_USE_CLASS_TPLISO_2022_KR
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_KR_GetCategory(TPlISO_2022_KRHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_KR_GetDescription(TPlISO_2022_KRHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_KR_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_2022_KR_Create(TPlCustomISO_2022CharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLISO_2022_KR */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TPlCustomEUCCharset_ce_ptr;
extern zend_class_entry *TPlCustomISO_2022Charset_ce_ptr;
extern zend_class_entry *TPlShiftJISCode_ce_ptr;
extern zend_class_entry *TPlShiftJIS_ce_ptr;
extern zend_class_entry *TPlEUC_JP_ce_ptr;
extern zend_class_entry *TPlISO_2022_JP_ce_ptr;
extern zend_class_entry *TPlISO_2022_JP_1_ce_ptr;
extern zend_class_entry *TPlISO_2022_JP_2_ce_ptr;
extern zend_class_entry *TPlGBK_ce_ptr;
extern zend_class_entry *TPlHZ_GB_2312_ce_ptr;
extern zend_class_entry *TPlGB_18030Code_ce_ptr;
extern zend_class_entry *TPlGB_18030_ce_ptr;
extern zend_class_entry *TPlISO_2022_CN_ce_ptr;
extern zend_class_entry *TPlISO_2022_CN_EXT_ce_ptr;
extern zend_class_entry *TPlBigFiveHKSCS_ce_ptr;
extern zend_class_entry *TPlCP950_ce_ptr;
extern zend_class_entry *TPlCNS_11643_ce_ptr;
extern zend_class_entry *TPlEUC_TW_ce_ptr;
extern zend_class_entry *TPlCP949_ce_ptr;
extern zend_class_entry *TPlJohabHangul_ce_ptr;
extern zend_class_entry *TPlJohabNonHangul_ce_ptr;
extern zend_class_entry *TPlJohab_ce_ptr;
extern zend_class_entry *TPlEUC_KR_ce_ptr;
extern zend_class_entry *TPlISO_2022_KR_ce_ptr;

void Register_TPlCustomEUCCharset(TSRMLS_D);
void Register_TPlCustomISO_2022Charset(TSRMLS_D);
void Register_TPlShiftJISCode(TSRMLS_D);
void Register_TPlShiftJIS(TSRMLS_D);
void Register_TPlEUC_JP(TSRMLS_D);
void Register_TPlISO_2022_JP(TSRMLS_D);
void Register_TPlISO_2022_JP_1(TSRMLS_D);
void Register_TPlISO_2022_JP_2(TSRMLS_D);
void Register_TPlGBK(TSRMLS_D);
void Register_TPlHZ_GB_2312(TSRMLS_D);
void Register_TPlGB_18030Code(TSRMLS_D);
void Register_TPlGB_18030(TSRMLS_D);
void Register_TPlISO_2022_CN(TSRMLS_D);
void Register_TPlISO_2022_CN_EXT(TSRMLS_D);
void Register_TPlBigFiveHKSCS(TSRMLS_D);
void Register_TPlCP950(TSRMLS_D);
void Register_TPlCNS_11643(TSRMLS_D);
void Register_TPlEUC_TW(TSRMLS_D);
void Register_TPlCP949(TSRMLS_D);
void Register_TPlJohabHangul(TSRMLS_D);
void Register_TPlJohabNonHangul(TSRMLS_D);
void Register_TPlJohab(TSRMLS_D);
void Register_TPlEUC_KR(TSRMLS_D);
void Register_TPlISO_2022_KR(TSRMLS_D);
void Register_SBChSCJK_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCHSCJK */

