#ifndef __INC_SBCHSCONV
#define __INC_SBCHSCONV

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbsharedresource.h"
#include "sbconstants.h"
#include "sbchsconvbase.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TPlConverterHandle;

typedef TElClassHandle TPlCustomUTFHandle;

typedef TElClassHandle TPlUTF32Handle;

typedef TElClassHandle TPlUTF32BEHandle;

typedef TElClassHandle TPlUTF16Handle;

typedef TElClassHandle TPlUTF16BEHandle;

typedef TElClassHandle TPlUTF8Handle;

typedef TElClassHandle TPlCustomUTF7Handle;

typedef TElClassHandle TPlUTF7Handle;

typedef TElClassHandle TPlUTF7_IMAPHandle;

typedef TElClassHandle TPlConvBufferHandle;

typedef TElClassHandle TPlCustomStringStreamHandle;

typedef TElClassHandle TPlAnsiStringStreamHandle;

typedef TElClassHandle TPlWideStringStreamHandle;

typedef TElClassHandle TPlByteArrayStreamHandle;

typedef TElClassHandle TPlCustomStringStreamPoolHandle;

typedef TElClassHandle TPlAnsiStringStreamPoolHandle;

typedef TElClassHandle TPlWideStringStreamPoolHandle;

typedef uint8_t TPlConvertOptionRaw;

typedef enum
{
	coContinuePrevious = 0,
	coNoDefaultChar = 1,
	coInvalidCharException = 2,
	coWriteFileHeader = 3,
	coWriteLineBegin = 4,
	coWriteLineEnd = 5
} TPlConvertOption;

typedef uint32_t TPlConvertOptionsRaw;

typedef enum 
{
	f_coContinuePrevious = 1,
	f_coNoDefaultChar = 2,
	f_coInvalidCharException = 4,
	f_coWriteFileHeader = 8,
	f_coWriteLineBegin = 16,
	f_coWriteLineEnd = 32
} TPlConvertOptions;

typedef uint8_t TPlConverterLineStateRaw;

typedef enum
{
	lsStarted = 0,
	lsFinished = 1
} TPlConverterLineState;

typedef uint32_t TPlConverterLineStatesRaw;

typedef enum 
{
	f_lsStarted = 1,
	f_lsFinished = 2
} TPlConverterLineStates;

typedef uint8_t TPlUTF7StateRaw;

typedef enum
{
	usDirect = 0,
	usBase64 = 1,
	usShift = 2
} TPlUTF7State;

typedef Pointer TUserData;

typedef void (SB_CALLBACK *TEnumCharsetsProc)(void * _ObjectData, const char * pcCategory, int32_t szCategory, const char * pcDescription, int32_t szDescription, const char * pcName, int32_t szName, const char * pcAliases, int32_t szAliases, int8_t * Stop);

#ifdef SB_USE_CLASS_TPLCONVERTER
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_Convert(TPlConverterHandle _Handle, const char * pcSource, int32_t szSource, char * pcDest, int32_t * szDest, TPlConvertOptionsRaw Options);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_Convert_1(TPlConverterHandle _Handle, TStreamHandle Source, TStreamHandle Dest, TPlConvertOptionsRaw Options, int32_t MaxChars);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_IsConvert(TPlConverterHandle _Handle, const char * pcSource, int32_t szSource, char * pcDest, int32_t * szDest, TPlConvertOptionsRaw Options, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_IsConvert_1(TPlConverterHandle _Handle, TStreamHandle Source, TStreamHandle Dest, TPlConvertOptionsRaw Options, int32_t MaxChars, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_ConvertFromUnicode(TPlConverterHandle _Handle, const char * pcSource, int32_t szSource, char * pcDest, int32_t * szDest, TPlConvertOptionsRaw Options);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_ConvertToUnicode(TPlConverterHandle _Handle, const char * pcSource, int32_t szSource, char * pcDest, int32_t * szDest, TPlConvertOptionsRaw Options);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_IsConvertFromUnicode(TPlConverterHandle _Handle, const char * pcSource, int32_t szSource, char * pcDest, int32_t * szDest, TPlConvertOptionsRaw Options, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_IsConvertToUnicode(TPlConverterHandle _Handle, const char * pcSource, int32_t szSource, char * pcDest, int32_t * szDest, TPlConvertOptionsRaw Options, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_get_DstCharset(TPlConverterHandle _Handle, IPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_get_DstCharsetName(TPlConverterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_set_DstCharsetName(TPlConverterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_get_SrcCharset(TPlConverterHandle _Handle, IPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_get_SrcCharsetName(TPlConverterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_set_SrcCharsetName(TPlConverterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_Create(TPlConverterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_Create_1(const char * pcSrcCharset, int32_t szSrcCharset, const char * pcDstCharset, int32_t szDstCharset, TPlConverterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConverter_Create_2(IPlCharsetHandle SrcCharset, IPlCharsetHandle DstCharset, TPlConverterHandle * OutResult);
#endif /* SB_USE_CLASS_TPLCONVERTER */

#ifdef SB_USE_CLASS_TPLCUSTOMUTF
SB_IMPORT uint32_t SB_APIENTRY TPlCustomUTF_GetCategory(TPlCustomUTFHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomUTF_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomUTF_Create(TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomUTF_CreateShift(int32_t Shift, TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomUTF_CreateNoInit(TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomUTF_CreateForFinalize(TPlCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLCUSTOMUTF */

#ifdef SB_USE_CLASS_TPLUTF32
SB_IMPORT uint32_t SB_APIENTRY TPlUTF32_ConvertFromUCS(TPlUTF32Handle _Handle, uint32_t Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF32_ConvertToUCS(TPlUTF32Handle _Handle, TStreamHandle Stream, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF32_ConvertBufferToUCS(TPlUTF32Handle _Handle, const void * Buf, int32_t Count, int8_t IsLastChunk, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF32_GetDescription(TPlUTF32Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF32_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF32_Create(TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF32_CreateShift(int32_t Shift, TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF32_CreateNoInit(TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF32_CreateForFinalize(TPlCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLUTF32 */

#ifdef SB_USE_CLASS_TPLUTF32BE
SB_IMPORT uint32_t SB_APIENTRY TPlUTF32BE_GetDescription(TPlUTF32BEHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF32BE_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF32BE_Create(TPlUTF32BEHandle * OutResult);
#endif /* SB_USE_CLASS_TPLUTF32BE */

#ifdef SB_USE_CLASS_TPLUTF16
SB_IMPORT uint32_t SB_APIENTRY TPlUTF16_ConvertFromUCS(TPlUTF16Handle _Handle, uint32_t Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF16_ConvertToUCS(TPlUTF16Handle _Handle, TStreamHandle Stream, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF16_ConvertBufferToUCS(TPlUTF16Handle _Handle, const void * Buf, int32_t Count, int8_t IsLastChunk, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF16_GetDescription(TPlUTF16Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF16_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF16_Create(TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF16_CreateShift(int32_t Shift, TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF16_CreateNoInit(TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF16_CreateForFinalize(TPlCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLUTF16 */

#ifdef SB_USE_CLASS_TPLUTF16BE
SB_IMPORT uint32_t SB_APIENTRY TPlUTF16BE_GetDescription(TPlUTF16BEHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF16BE_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF16BE_Create(TPlUTF16BEHandle * OutResult);
#endif /* SB_USE_CLASS_TPLUTF16BE */

#ifdef SB_USE_CLASS_TPLUTF8
SB_IMPORT uint32_t SB_APIENTRY TPlUTF8_ConvertFromUCS(TPlUTF8Handle _Handle, uint32_t Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF8_ConvertToUCS(TPlUTF8Handle _Handle, TStreamHandle Stream, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF8_ConvertBufferToUCS(TPlUTF8Handle _Handle, const void * Buf, int32_t Count, int8_t IsLastChunk, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF8_GetCategory(TPlUTF8Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF8_GetDescription(TPlUTF8Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF8_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF8_Create(TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF8_CreateShift(int32_t Shift, TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF8_CreateNoInit(TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF8_CreateForFinalize(TPlCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLUTF8 */

#ifdef SB_USE_CLASS_TPLCUSTOMUTF7
SB_IMPORT uint32_t SB_APIENTRY TPlCustomUTF7_ConvertFromUCS(TPlCustomUTF7Handle _Handle, uint32_t Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomUTF7_ConvertToUCS(TPlCustomUTF7Handle _Handle, TStreamHandle Stream, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomUTF7_ConvertBufferToUCS(TPlCustomUTF7Handle _Handle, const void * Buf, int32_t Count, int8_t IsLastChunk, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomUTF7_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomUTF7_Create(TPlCustomUTF7Handle * OutResult);
#endif /* SB_USE_CLASS_TPLCUSTOMUTF7 */

#ifdef SB_USE_CLASS_TPLUTF7
SB_IMPORT uint32_t SB_APIENTRY TPlUTF7_GetCategory(TPlUTF7Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF7_GetDescription(TPlUTF7Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF7_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF7_Create(TPlUTF7Handle * OutResult);
#endif /* SB_USE_CLASS_TPLUTF7 */

#ifdef SB_USE_CLASS_TPLUTF7_IMAP
SB_IMPORT uint32_t SB_APIENTRY TPlUTF7_IMAP_GetCategory(TPlUTF7_IMAPHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF7_IMAP_GetDescription(TPlUTF7_IMAPHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF7_IMAP_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlUTF7_IMAP_Create(TPlUTF7_IMAPHandle * OutResult);
#endif /* SB_USE_CLASS_TPLUTF7_IMAP */

#ifdef SB_USE_CLASS_TPLCONVBUFFER
SB_IMPORT uint32_t SB_APIENTRY TPlConvBuffer_CheckString(TPlConvBufferHandle _Handle, TStreamHandle Stream, const char * pcStr, int32_t szStr, int32_t Shift, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConvBuffer_GetByte(TPlConvBufferHandle _Handle, TStreamHandle Stream, int8_t * Exists, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConvBuffer_GetWide(TPlConvBufferHandle _Handle, TStreamHandle Stream, int8_t * Exists, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConvBuffer_GetLong(TPlConvBufferHandle _Handle, TStreamHandle Stream, int8_t * Exists, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConvBuffer_ReturnByte(TPlConvBufferHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TPlConvBuffer_ReturnByte_1(TPlConvBufferHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TPlConvBuffer_ReturnBytes(TPlConvBufferHandle _Handle, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TPlConvBuffer_Flush(TPlConvBufferHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TPlConvBuffer_Put(TPlConvBufferHandle _Handle, const void * Data, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TPlConvBuffer_PutByte(TPlConvBufferHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TPlConvBuffer_PutWordLE(TPlConvBufferHandle _Handle, uint16_t Value);
SB_IMPORT uint32_t SB_APIENTRY TPlConvBuffer_RevokeByte(TPlConvBufferHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConvBuffer_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TPLCONVBUFFER */

#ifdef SB_USE_CLASS_TPLCUSTOMSTRINGSTREAM
SB_IMPORT uint32_t SB_APIENTRY TPlCustomStringStream_Read(TPlCustomStringStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomStringStream_Write(TPlCustomStringStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomStringStream_Seek(TPlCustomStringStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomStringStream_Seek_1(TPlCustomStringStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomStringStream_Clear(TPlCustomStringStreamHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TPlCustomStringStream_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TPLCUSTOMSTRINGSTREAM */

#ifdef SB_USE_CLASS_TPLANSISTRINGSTREAM
SB_IMPORT uint32_t SB_APIENTRY TPlAnsiStringStream_get_Data(TPlAnsiStringStreamHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlAnsiStringStream_set_Data(TPlAnsiStringStreamHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TPlAnsiStringStream_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TPLANSISTRINGSTREAM */

#ifdef SB_USE_CLASS_TPLWIDESTRINGSTREAM
SB_IMPORT uint32_t SB_APIENTRY TPlWideStringStream_get_Data(TPlWideStringStreamHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlWideStringStream_set_Data(TPlWideStringStreamHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TPlWideStringStream_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TPLWIDESTRINGSTREAM */

#ifdef SB_USE_CLASS_TPLBYTEARRAYSTREAM
SB_IMPORT uint32_t SB_APIENTRY TPlByteArrayStream_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TPLBYTEARRAYSTREAM */

#ifdef SB_USE_CLASS_TPLCUSTOMSTRINGSTREAMPOOL
SB_IMPORT uint32_t SB_APIENTRY TPlCustomStringStreamPool_Create(TPlCustomStringStreamPoolHandle * OutResult);
#endif /* SB_USE_CLASS_TPLCUSTOMSTRINGSTREAMPOOL */

#ifdef SB_USE_CLASS_TPLANSISTRINGSTREAMPOOL
SB_IMPORT uint32_t SB_APIENTRY TPlAnsiStringStreamPool_AcquireStream(TPlAnsiStringStreamPoolHandle _Handle, TPlAnsiStringStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlAnsiStringStreamPool_ReleaseStream(TPlAnsiStringStreamPoolHandle _Handle, TPlAnsiStringStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TPlAnsiStringStreamPool_Create(TPlCustomStringStreamPoolHandle * OutResult);
#endif /* SB_USE_CLASS_TPLANSISTRINGSTREAMPOOL */

#ifdef SB_USE_CLASS_TPLWIDESTRINGSTREAMPOOL
SB_IMPORT uint32_t SB_APIENTRY TPlWideStringStreamPool_AcquireStream(TPlWideStringStreamPoolHandle _Handle, TPlWideStringStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlWideStringStreamPool_ReleaseStream(TPlWideStringStreamPoolHandle _Handle, TPlWideStringStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TPlWideStringStreamPool_Create(TPlCustomStringStreamPoolHandle * OutResult);
#endif /* SB_USE_CLASS_TPLWIDESTRINGSTREAMPOOL */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TPlConverter_ce_ptr;
extern zend_class_entry *TPlCustomUTF_ce_ptr;
extern zend_class_entry *TPlUTF32_ce_ptr;
extern zend_class_entry *TPlUTF32BE_ce_ptr;
extern zend_class_entry *TPlUTF16_ce_ptr;
extern zend_class_entry *TPlUTF16BE_ce_ptr;
extern zend_class_entry *TPlUTF8_ce_ptr;
extern zend_class_entry *TPlCustomUTF7_ce_ptr;
extern zend_class_entry *TPlUTF7_ce_ptr;
extern zend_class_entry *TPlUTF7_IMAP_ce_ptr;
extern zend_class_entry *TPlConvBuffer_ce_ptr;
extern zend_class_entry *TPlCustomStringStream_ce_ptr;
extern zend_class_entry *TPlAnsiStringStream_ce_ptr;
extern zend_class_entry *TPlWideStringStream_ce_ptr;
extern zend_class_entry *TPlByteArrayStream_ce_ptr;
extern zend_class_entry *TPlCustomStringStreamPool_ce_ptr;
extern zend_class_entry *TPlAnsiStringStreamPool_ce_ptr;
extern zend_class_entry *TPlWideStringStreamPool_ce_ptr;

void SB_CALLBACK TEnumCharsetsProcRaw(void * _ObjectData, const char * pcCategory, int32_t szCategory, const char * pcDescription, int32_t szDescription, const char * pcName, int32_t szName, const char * pcAliases, int32_t szAliases, int8_t * Stop);
void Register_TPlConverter(TSRMLS_D);
void Register_TPlCustomUTF(TSRMLS_D);
void Register_TPlUTF32(TSRMLS_D);
void Register_TPlUTF32BE(TSRMLS_D);
void Register_TPlUTF16(TSRMLS_D);
void Register_TPlUTF16BE(TSRMLS_D);
void Register_TPlUTF8(TSRMLS_D);
void Register_TPlCustomUTF7(TSRMLS_D);
void Register_TPlUTF7(TSRMLS_D);
void Register_TPlUTF7_IMAP(TSRMLS_D);
void Register_TPlConvBuffer(TSRMLS_D);
void Register_TPlCustomStringStream(TSRMLS_D);
void Register_TPlAnsiStringStream(TSRMLS_D);
void Register_TPlWideStringStream(TSRMLS_D);
void Register_TPlByteArrayStream(TSRMLS_D);
void Register_TPlCustomStringStreamPool(TSRMLS_D);
void Register_TPlAnsiStringStreamPool(TSRMLS_D);
void Register_TPlWideStringStreamPool(TSRMLS_D);
SB_PHP_FUNCTION(SBChSConv, EnumCharsets);
SB_PHP_FUNCTION(SBChSConv, CreateCharset);
SB_PHP_FUNCTION(SBChSConv, CreateCharsetByDescription);
SB_PHP_FUNCTION(SBChSConv, CreateSystemDefaultCharset);
SB_PHP_FUNCTION(SBChSConv, GetSystemDefaultCharsetName);
SB_PHP_FUNCTION(SBChSConv, GetCharsetNameByAlias);
SB_PHP_FUNCTION(SBChSConv, ConvertCharset);
SB_PHP_FUNCTION(SBChSConv, InitializeCharsetObjects);
void Register_SBChSConv_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_CHSCONV
SB_IMPORT uint32_t SB_APIENTRY SBChSConv_EnumCharsets(TEnumCharsetsProc pMethodEnumProc, void * pDataEnumProc);
SB_IMPORT uint32_t SB_APIENTRY SBChSConv_CreateCharset(const char * pcName, int32_t szName, IPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSConv_CreateCharsetByDescription(const char * pcADescription, int32_t szADescription, IPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSConv_CreateSystemDefaultCharset(IPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSConv_GetSystemDefaultCharsetName(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSConv_GetCharsetNameByAlias(const char * pcAlias, int32_t szAlias, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSConv_ConvertCharset(const char * pcSource, int32_t szSource, int32_t SourceCP, int32_t DestCP, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSConv_InitializeCharsetObjects(void);
#endif /* SB_USE_GLOBAL_PROCS_CHSCONV */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCHSCONV */

