#ifndef __INC_SBCHSCONVBASE
#define __INC_SBCHSCONVBASE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbstrutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_CHS 	143360
#define SB_ERROR_CHS_ERROR_FLAG 	2048
#define SB_CHS_ERROR_INVALID_INPUT_DATA 	145409
#define SB_CHS_ERROR_CHARSET_UNDEFINED 	145410
#define SB_cNilPrefixes 	NULL
#define SB_cNilHiBytes 	NULL
#define SB_cNilConvTable 	NULL
#define SB_UCS_Count 	1114112
#define SB_UCSCharByteOrderLE32 	65279
#define SB_UCSCharByteOrderBE32 	4294836224
#define SB_UCSCharByteOrderLE16 	65279
#define SB_UCSCharByteOrderBE16 	65534
#define SB_UCSCharIgnore 	65535
#define SB_UCSCharIllegal 	65533
#define SB_MAX_CHARACTER_LENGTH 	16

typedef TStreamHandle SBChSConvBase_TElNativeStreamHandle;

typedef TElClassHandle TPlCharsetHandle;

typedef TElClassHandle TPlTableCharsetHandle;

typedef TElClassHandle TPlMixedCharsetHandle;

typedef TElClassHandle TPlConvertingCharsetHandle;

typedef TElClassHandle TPlASCIIHandle;

typedef TElClassHandle TPlISO_8859_1Handle;

typedef TElClassHandle IPlConvBufferHandle;

typedef TElClassHandle IPlCharsetHandle;

typedef TElClassHandle TPlCharsetClassHandle;

typedef uint8_t * SBChSConvBase_PByte;

typedef uint16_t * SBChSConvBase_PWord;

typedef uint32_t * PLong;

typedef uint32_t TPlPrefixes[8];

typedef TPlPrefixes * PPlPrefixes;

typedef uint8_t TPlHiBytes[256];

typedef TPlHiBytes * PPlHiBytes;

typedef uint16_t TPlChars[256];

typedef TPlChars * PPlChars;

#pragma pack(1)
typedef struct 
{
	PPlChars Chars;
	PPlHiBytes HiBytes;
	TPlPrefixes * Prefixes;
	uint8_t CharsLoIndex;
	uint8_t CharsHiIndex;
	uint8_t PriorPageIndex;
	uint8_t PriorPageChar;
} TPlConversionPage, * PPlConversionPage;

typedef TPlConversionPage TPlConversionPages[256];

typedef TPlConversionPages * PPlConversionPages;

#pragma pack(1)
typedef struct 
{
	uint8_t Page;
	uint8_t Char;
} TPlUCSToMultiByteItem;

#pragma pack(4)
typedef struct 
{
	int32_t MaxDirectMapped;
	int32_t PagesCount;
	PPlConversionPages Pages;
	uint32_t BackItemsCount;
	union
	{
		struct
		{
			uint8_t * (* ToSingleByte);
		} S1;
		struct
		{
			TPlUCSToMultiByteItem * (* ToMultiByte);
		} S2;
	};
} TPlConversionTable, * PPlConversionTable;

typedef Pointer TPlCharsetClassPtr;

typedef void (SB_CALLBACK *TCharsetCreateProc)(void * Handle, IPlCharsetHandle * OutResult);

typedef void (SB_CALLBACK *TCharsetLibraryRegProc)(char * Category, char * Description, char * Aliases, void * Handle, void * CreateProc);

#ifdef SB_USE_CLASS_TPLCHARSET
SB_IMPORT uint32_t SB_APIENTRY TPlCharset_CanConvert(TPlCharsetHandle _Handle, uint32_t Char, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCharset_ConvertFromUCS(TPlCharsetHandle _Handle, uint32_t Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCharset_ConvertToUCS(TPlCharsetHandle _Handle, TStreamHandle Stream, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCharset_ConvertBufferToUCS(TPlCharsetHandle _Handle, const void * Buf, int32_t Count, int8_t IsLastChunk, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCharset_ConvertBufferToUTF16(TPlCharsetHandle _Handle, const void * SrcBuf, int32_t SrcCount, int8_t IsLastChunk, void * DstBuf, int32_t * DstCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCharset_GetCategory(TPlCharsetHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCharset_GetDescription(TPlCharsetHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCharset_GetName(TPlCharsetHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCharset_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCharset_Create(TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCharset_CreateShift(int32_t Shift, TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCharset_CreateNoInit(TPlCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlCharset_CreateForFinalize(TPlCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLCHARSET */

#ifdef SB_USE_CLASS_TPLTABLECHARSET
SB_IMPORT uint32_t SB_APIENTRY TPlTableCharset_CanConvert(TPlTableCharsetHandle _Handle, uint32_t Char, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlTableCharset_ConvertFromUCS(TPlTableCharsetHandle _Handle, uint32_t Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlTableCharset_ConvertToUCS(TPlTableCharsetHandle _Handle, TStreamHandle Stream, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlTableCharset_ConvertBufferToUCS(TPlTableCharsetHandle _Handle, const void * Buf, int32_t Count, int8_t IsLastChunk, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlTableCharset_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlTableCharset_Create(TPlTableCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlTableCharset_CreateForFinalize(TPlTableCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLTABLECHARSET */

#ifdef SB_USE_CLASS_TPLMIXEDCHARSET
SB_IMPORT uint32_t SB_APIENTRY TPlMixedCharset_CanConvert(TPlMixedCharsetHandle _Handle, uint32_t Char, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlMixedCharset_ConvertFromUCS(TPlMixedCharsetHandle _Handle, uint32_t Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlMixedCharset_ConvertToUCS(TPlMixedCharsetHandle _Handle, TStreamHandle Stream, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlMixedCharset_ConvertBufferToUCS(TPlMixedCharsetHandle _Handle, const void * Buf, int32_t Count, int8_t IsLastChunk, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlMixedCharset_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlMixedCharset_Create(TPlMixedCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlMixedCharset_CreateShift(int32_t Shift, TPlMixedCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLMIXEDCHARSET */

#ifdef SB_USE_CLASS_TPLCONVERTINGCHARSET
SB_IMPORT uint32_t SB_APIENTRY TPlConvertingCharset_CanConvert(TPlConvertingCharsetHandle _Handle, uint32_t Char, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConvertingCharset_ConvertFromUCS(TPlConvertingCharsetHandle _Handle, uint32_t Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConvertingCharset_ConvertToUCS(TPlConvertingCharsetHandle _Handle, TStreamHandle Stream, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConvertingCharset_ConvertBufferToUCS(TPlConvertingCharsetHandle _Handle, const void * Buf, int32_t Count, int8_t IsLastChunk, uint32_t * Char, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConvertingCharset_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlConvertingCharset_Create(TPlConvertingCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLCONVERTINGCHARSET */

#ifdef SB_USE_CLASS_TPLASCII
SB_IMPORT uint32_t SB_APIENTRY TPlASCII_GetCategory(TPlASCIIHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlASCII_GetDescription(TPlASCIIHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlASCII_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlASCII_Create(TPlTableCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlASCII_CreateForFinalize(TPlTableCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLASCII */

#ifdef SB_USE_CLASS_TPLISO_8859_1
SB_IMPORT uint32_t SB_APIENTRY TPlISO_8859_1_GetCategory(TPlISO_8859_1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_8859_1_GetDescription(TPlISO_8859_1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_8859_1_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_8859_1_Create(TPlTableCharsetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TPlISO_8859_1_CreateForFinalize(TPlTableCharsetHandle * OutResult);
#endif /* SB_USE_CLASS_TPLISO_8859_1 */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *IPlConvBuffer_ce_ptr;
extern zend_class_entry *IPlCharset_ce_ptr;
extern zend_class_entry *TPlCharsetClass_ce_ptr;
extern zend_class_entry *TPlHiBytes_ce_ptr;
extern zend_class_entry *TPlChars_ce_ptr;
extern zend_class_entry *TPlConversionPage_ce_ptr;
extern zend_class_entry *TPlConversionPages_ce_ptr;
extern zend_class_entry *TPlUCSToMultiByteItem_ce_ptr;
extern zend_class_entry *TPlConversionTable_ce_ptr;
extern zend_class_entry *TPlCharset_ce_ptr;
extern zend_class_entry *TPlTableCharset_ce_ptr;
extern zend_class_entry *TPlMixedCharset_ce_ptr;
extern zend_class_entry *TPlConvertingCharset_ce_ptr;
extern zend_class_entry *TPlASCII_ce_ptr;
extern zend_class_entry *TPlISO_8859_1_ce_ptr;

void Register_TPlHiBytes(TSRMLS_D);
void Register_TPlChars(TSRMLS_D);
void Register_TPlConversionPage(TSRMLS_D);
void Register_TPlConversionPages(TSRMLS_D);
void Register_TPlUCSToMultiByteItem(TSRMLS_D);
void Register_TPlConversionTable(TSRMLS_D);
void Register_TPlCharset(TSRMLS_D);
void Register_TPlTableCharset(TSRMLS_D);
void Register_TPlMixedCharset(TSRMLS_D);
void Register_TPlConvertingCharset(TSRMLS_D);
void Register_TPlASCII(TSRMLS_D);
void Register_TPlISO_8859_1(TSRMLS_D);
SB_PHP_FUNCTION(SBChSConvBase, RegisterCharset);
SB_PHP_FUNCTION(SBChSConvBase, UnregisterCharset);
SB_PHP_FUNCTION(SBChSConvBase, RegisterCharsetLibrary);
SB_PHP_FUNCTION(SBChSConvBase, AbstractError);
SB_PHP_FUNCTION(SBChSConvBase, Initialize);
void Register_SBChSConvBase_Constants(int module_number TSRMLS_DC);
void Register_SBChSConvBase_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_CHSCONVBASE
SB_IMPORT uint32_t SB_APIENTRY SBChSConvBase_RegisterCharset(TPlCharsetClassHandle CharsetClass);
SB_IMPORT uint32_t SB_APIENTRY SBChSConvBase_UnregisterCharset(TPlCharsetClassHandle CharsetClass);
SB_IMPORT uint32_t SB_APIENTRY SBChSConvBase_RegisterCharsetLibrary(void * RegistrationProc);
SB_IMPORT uint32_t SB_APIENTRY SBChSConvBase_AbstractError(const char * pcClassName, int32_t szClassName, const char * pcMethod, int32_t szMethod);
SB_IMPORT uint32_t SB_APIENTRY SBChSConvBase_Initialize(void);
#endif /* SB_USE_GLOBAL_PROCS_CHSCONVBASE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCHSCONVBASE */

