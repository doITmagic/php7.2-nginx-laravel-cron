#ifndef __INC_SBCHSUNICODE
#define __INC_SBCHSUNICODE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbstrutils.h"
#include "sbchsconvbase.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_HANGUL_SBASE 	44032
#define SB_HANGUL_LBASE 	4352
#define SB_HANGUL_VBASE 	4449
#define SB_HANGUL_TBASE 	4519
#define SB_HANGUL_LCOUNT 	19
#define SB_HANGUL_VCOUNT 	21
#define SB_HANGUL_TCOUNT 	28
#define SB_HANGUL_NCOUNT 	588
#define SB_HANGUL_SCOUNT 	11172
#define SB_HANGUL_L_START 	4352
#define SB_HANGUL_L_END 	4442
#define SB_HANGUL_L_FILLER 	4447
#define SB_HANGUL_V_START 	4448
#define SB_HANGUL_V_END 	4515
#define SB_HANGUL_T_START 	4520
#define SB_HANGUL_T_END 	4602
#define SB_HANGUL_S_START 	44032
#define SB_HANGUL_S_END 	55204
#define SB_UnassignedCodesCount 	396
#define SB_DeprecatedCodesCount 	4
#define SB_PrivateCodesCount 	3
#define SB_NonCharacterCodesCount 	18
#define SB_SurrogateCodesCount 	1
#define SB_BidiControlCount 	12

typedef uint8_t TPlCharTypeRaw;

typedef enum
{
	ctOther = 0,
	ctLetterUpper = 1,
	ctLetterLower = 2,
	ctLetterTitle = 3,
	ctLetterOther = 4,
	ctNumber = 5,
	ctPunctuation = 6,
	ctSpace = 7,
	ctControl = 8,
	ctMark = 9
} TPlCharType;

#ifdef __cplusplus
};	/* extern "C" */
#endif

SB_PHP_FUNCTION(SBChSUnicode, WideUpperCase);
SB_PHP_FUNCTION(SBChSUnicode, WideTitleCase);
SB_PHP_FUNCTION(SBChSUnicode, GetCharType);
SB_PHP_FUNCTION(SBChSUnicode, WideLowerCase);
SB_PHP_FUNCTION(SBChSUnicode, Normalize_NFD);
SB_PHP_FUNCTION(SBChSUnicode, Normalize_NFC);
SB_PHP_FUNCTION(SBChSUnicode, Normalize_NFKD);
SB_PHP_FUNCTION(SBChSUnicode, Normalize_NFKC);
SB_PHP_FUNCTION(SBChSUnicode, CheckProhibit);
SB_PHP_FUNCTION(SBChSUnicode, CheckBidi);
SB_PHP_FUNCTION(SBChSUnicode, GetCharCode);
SB_PHP_FUNCTION(SBChSUnicode, GetCharValue);
void Register_SBChSUnicode_Constants(int module_number TSRMLS_DC);
void Register_SBChSUnicode_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_CHSUNICODE
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_WideUpperCase(char * pcC, int32_t * szC);
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_WideUpperCase_1(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_WideTitleCase(char * pcC, int32_t * szC);
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_WideTitleCase_1(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_GetCharType(const char * pcC, int32_t szC, TPlCharTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_WideLowerCase(char * pcC, int32_t * szC);
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_WideLowerCase_1(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_Normalize_NFD(const char * pcAString, int32_t szAString, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_Normalize_NFC(const char * pcAString, int32_t szAString, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_Normalize_NFKD(const char * pcAString, int32_t szAString, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_Normalize_NFKC(const char * pcAString, int32_t szAString, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_CheckProhibit(const char * pcstr, int32_t szstr, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_CheckBidi(const char * pcstr, int32_t szstr, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_GetCharCode(const char * pcInCh, int32_t szInCh, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBChSUnicode_GetCharValue(uint32_t Code, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_CHSUNICODE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCHSUNICODE */

