#ifndef __INC_SBCMC
#define __INC_SBCMC

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbpkcs10.h"
#include "sbx509.h"
#include "sbx509ex.h"
#include "sbx509ext.h"
#include "sbcrlstorage.h"
#include "sbcustomcertstorage.h"
#include "sbalgorithmidentifier.h"
#include "sbcms.h"
#include "sbencoding.h"
#include "sbrdn.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_CMC_STATUS_SUCCESS 	0
#define SB_CMC_STATUS_RESERVED 	1
#define SB_CMC_STATUS_FAILED 	2
#define SB_CMC_STATUS_PENDING 	3
#define SB_CMC_STATUS_NO_SUPPORT 	4
#define SB_CMC_STATUS_CONFIRM_REQUIRED 	5
#define SB_CMC_STATUS_POP_REQUIRED 	6
#define SB_CMC_STATUS_PARTIAL 	7
#define SB_CMC_FAIL_INFO_BAD_ALG 	0
#define SB_CMC_FAIL_INFO_BAD_MESSAGE_CHECK 	1
#define SB_CMC_FAIL_INFO_BAD_REQUEST 	2
#define SB_CMC_FAIL_INFO_BAD_TIME 	3
#define SB_CMC_FAIL_INFO_BAD_CERT_ID 	4
#define SB_CMC_FAIL_INFO_UNSUPPORTED_EXT 	5
#define SB_CMC_FAIL_INFO_MUST_ARCHIVE_KEYS 	6
#define SB_CMC_FAIL_INFO_BAD_IDENTITY 	7
#define SB_CMC_FAIL_INFO_POP_REQUIRED 	8
#define SB_CMC_FAIL_INFO_POP_FAILED 	9
#define SB_CMC_FAIL_INFO_NO_KEY_REUSE 	10
#define SB_CMC_FAIL_INFO_INTERNAL_CA_ERROR 	11
#define SB_CMC_FAIL_INFO_TRY_LATER 	12
#define SB_CMC_FAIL_INFO_AUTH_DATA_FAIL 	13

typedef TElClassHandle TElAttributeValueHandle;

typedef TElClassHandle TElTaggedAttributeHandle;

typedef TElClassHandle TElTaggedCertificationRequestHandle;

typedef TElClassHandle TElExternallyDefinedCertificationRequestHandle;

typedef TElClassHandle TElTaggedRequestHandle;

typedef TElClassHandle TElContentInfoHandle;

typedef TElClassHandle TElTaggedContentInfoHandle;

typedef TElClassHandle TElOtherMsgHandle;

typedef TElClassHandle TElPKIDataHandle;

typedef TElClassHandle TElPKIResponseHandle;

typedef TElClassHandle TElControlAttributeHandle;

typedef TElClassHandle TElIdentificationAttributeHandle;

typedef TElClassHandle TElPendInfoHandle;

typedef TElClassHandle TElCMCStatusInfoAttributeHandle;

typedef TElClassHandle TElBodyPartReferenceHandle;

typedef TElClassHandle TElBodyPartIDHandle;

typedef TElClassHandle TElBodyPartPathHandle;

typedef TElClassHandle TElExtendedFailInfoHandle;

typedef TElClassHandle TElCMCStatusInfoV2AttributeHandle;

typedef TElClassHandle TElAddExtensionsAttributeHandle;

typedef TElClassHandle TElIdentityProofV2AttributeHandle;

typedef TElClassHandle TElIdentityProofAttributeHandle;

typedef TElClassHandle TElPopLinkWitnessV2AttributeHandle;

typedef TElClassHandle TElPopLinkWitnessAttributeHandle;

typedef TElClassHandle TElDataReturnAttributeHandle;

typedef TElClassHandle TElTransactionIdentifierAttributeHandle;

typedef TElClassHandle TElSenderNonceAttributeHandle;

typedef TElClassHandle TElRecipientNonceAttributeHandle;

typedef TElClassHandle TElEncryptedPopAttributeHandle;

typedef TElClassHandle TElDecryptedPopAttributeHandle;

typedef TElClassHandle TElLraPopWitnessAttributeHandle;

typedef TElClassHandle TElGetCertificateAttributeHandle;

typedef TElClassHandle TElGetCRLAttributeHandle;

typedef TElClassHandle TElRevocationRequestAttributeHandle;

typedef TElClassHandle TElRegistrationInformationAttributeHandle;

typedef TElClassHandle TElResponseInformationAttributeHandle;

typedef TElClassHandle TElQueryPendingAttributeHandle;

typedef TElClassHandle TElConfirmCertAcceptanceAttributeHandle;

typedef TElClassHandle TElPublishTrustAnchorsAttributeHandle;

typedef TElClassHandle TElAuthenticatedDataAttributeHandle;

typedef TElClassHandle TElBatchRequestsAttributeHandle;

typedef TElClassHandle TElBatchResponsesAttributeHandle;

typedef TElClassHandle TElPopLinkRandomAttributeHandle;

typedef TElClassHandle TElSinglePubInfoHandle;

typedef TElClassHandle TElPKIPublicationInfoHandle;

typedef TElClassHandle TElPublicationInformationAttributeHandle;

typedef TElClassHandle TElControlProcessedAttributeHandle;

typedef TElClassHandle TElOptionalValidityHandle;

typedef TElClassHandle TElPublicKeyInfoHandle;

typedef TElClassHandle TElCertTemplateHandle;

typedef TElClassHandle TElModCertificationRequestAttributeHandle;

typedef TElClassHandle TElFullPKIRequestHandle;

typedef TElClassHandle TElFullPKIResponseHandle;

typedef void (SB_CALLBACK *TSBFullPKISignatureEvent)(void * _ObjectData, TObjectHandle Sender, TElCMSSignatureHandle Signature, int8_t * Continue);

typedef uint8_t TSBFullPKIFormatRaw;

typedef enum
{
	fpfBinary = 0,
	fpfBase64 = 1
} TSBFullPKIFormat;

typedef uint8_t TSBTaggedRequestTypeRaw;

typedef enum
{
	trtUnknown = 0,
	trtPKCS10 = 1,
	trtCRMF = 2,
	trtExternal = 3
} TSBTaggedRequestType;

typedef TElClassHandle TElControlAttributeClassHandle;

typedef uint8_t TSBPKIPublicationActionRaw;

typedef enum
{
	ppaDontPublish = 0,
	ppaPleasePublish = 1
} TSBPKIPublicationAction;

typedef uint8_t TSBPKIPublishMethodRaw;

typedef enum
{
	ppmDontCare = 0,
	ppmX500 = 1,
	ppmWeb = 2,
	ppmLDAP = 3
} TSBPKIPublishMethod;

#ifdef SB_USE_CLASS_TELATTRIBUTEVALUE
SB_IMPORT uint32_t SB_APIENTRY TElAttributeValue_get_Value(TElAttributeValueHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeValue_set_Value(TElAttributeValueHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeValue_Create(TElAttributeValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAttributeValue_Create_1(const uint8_t pValue[], int32_t szValue, TElAttributeValueHandle * OutResult);
#endif /* SB_USE_CLASS_TELATTRIBUTEVALUE */

#ifdef SB_USE_CLASS_TELTAGGEDATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElTaggedAttribute_get_BodyPartId(TElTaggedAttributeHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedAttribute_set_BodyPartId(TElTaggedAttributeHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedAttribute_get_AttrType(TElTaggedAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedAttribute_set_AttrType(TElTaggedAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedAttribute_get_AttrValues(TElTaggedAttributeHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedAttribute_Create(TElTaggedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELTAGGEDATTRIBUTE */

#ifdef SB_USE_CLASS_TELTAGGEDCERTIFICATIONREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElTaggedCertificationRequest_get_BodyPartId(TElTaggedCertificationRequestHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedCertificationRequest_set_BodyPartId(TElTaggedCertificationRequestHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedCertificationRequest_get_CertificationRequest(TElTaggedCertificationRequestHandle _Handle, TElCertificateRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedCertificationRequest_set_CertificationRequest(TElTaggedCertificationRequestHandle _Handle, TElCertificateRequestHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedCertificationRequest_Create(TElTaggedCertificationRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELTAGGEDCERTIFICATIONREQUEST */

#ifdef SB_USE_CLASS_TELEXTERNALLYDEFINEDCERTIFICATIONREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElExternallyDefinedCertificationRequest_get_BodyPartId(TElExternallyDefinedCertificationRequestHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElExternallyDefinedCertificationRequest_set_BodyPartId(TElExternallyDefinedCertificationRequestHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElExternallyDefinedCertificationRequest_get_MessageType(TElExternallyDefinedCertificationRequestHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElExternallyDefinedCertificationRequest_set_MessageType(TElExternallyDefinedCertificationRequestHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElExternallyDefinedCertificationRequest_get_MessageValue(TElExternallyDefinedCertificationRequestHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElExternallyDefinedCertificationRequest_set_MessageValue(TElExternallyDefinedCertificationRequestHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElExternallyDefinedCertificationRequest_Create(TElExternallyDefinedCertificationRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELEXTERNALLYDEFINEDCERTIFICATIONREQUEST */

#ifdef SB_USE_CLASS_TELTAGGEDREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElTaggedRequest_get_RequestType(TElTaggedRequestHandle _Handle, TSBTaggedRequestTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedRequest_get_TaggedCertificationRequest(TElTaggedRequestHandle _Handle, TElTaggedCertificationRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedRequest_set_TaggedCertificationRequest(TElTaggedRequestHandle _Handle, TElTaggedCertificationRequestHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedRequest_get_CertReqMsg(TElTaggedRequestHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedRequest_set_CertReqMsg(TElTaggedRequestHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedRequest_get_ExternallyDefinedCertificationRequest(TElTaggedRequestHandle _Handle, TElExternallyDefinedCertificationRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedRequest_set_ExternallyDefinedCertificationRequest(TElTaggedRequestHandle _Handle, TElExternallyDefinedCertificationRequestHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedRequest_Create(TElTaggedRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELTAGGEDREQUEST */

#ifdef SB_USE_CLASS_TELCONTENTINFO
SB_IMPORT uint32_t SB_APIENTRY TElContentInfo_get_ContentType(TElContentInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElContentInfo_set_ContentType(TElContentInfoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElContentInfo_get_Content(TElContentInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElContentInfo_set_Content(TElContentInfoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElContentInfo_Create(TElContentInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELCONTENTINFO */

#ifdef SB_USE_CLASS_TELTAGGEDCONTENTINFO
SB_IMPORT uint32_t SB_APIENTRY TElTaggedContentInfo_LoadFromTag(TElTaggedContentInfoHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedContentInfo_SaveToTag(TElTaggedContentInfoHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedContentInfo_get_BodyPartId(TElTaggedContentInfoHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedContentInfo_set_BodyPartId(TElTaggedContentInfoHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedContentInfo_get_ContentInfo(TElTaggedContentInfoHandle _Handle, TElContentInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedContentInfo_set_ContentInfo(TElTaggedContentInfoHandle _Handle, TElContentInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElTaggedContentInfo_Create(TElTaggedContentInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELTAGGEDCONTENTINFO */

#ifdef SB_USE_CLASS_TELOTHERMSG
SB_IMPORT uint32_t SB_APIENTRY TElOtherMsg_get_MsgType(TElOtherMsgHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOtherMsg_set_MsgType(TElOtherMsgHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOtherMsg_get_MsgValue(TElOtherMsgHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOtherMsg_set_MsgValue(TElOtherMsgHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOtherMsg_Create(TElOtherMsgHandle * OutResult);
#endif /* SB_USE_CLASS_TELOTHERMSG */

#ifdef SB_USE_CLASS_TELPKIDATA
SB_IMPORT uint32_t SB_APIENTRY TElPKIData_SaveToBuffer(TElPKIDataHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKIData_LoadFromBuffer(TElPKIDataHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElPKIData_get_ControlSequence(TElPKIDataHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKIData_get_ReqSequence(TElPKIDataHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKIData_get_CMSSequence(TElPKIDataHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKIData_get_OtherMsgSequence(TElPKIDataHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKIData_Create(TElPKIDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKIDATA */

#ifdef SB_USE_CLASS_TELPKIRESPONSE
SB_IMPORT uint32_t SB_APIENTRY TElPKIResponse_SaveToBuffer(TElPKIResponseHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKIResponse_LoadFromBuffer(TElPKIResponseHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElPKIResponse_get_ControlSequence(TElPKIResponseHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKIResponse_get_CMSSequence(TElPKIResponseHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKIResponse_get_OtherMsgSequence(TElPKIResponseHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKIResponse_Create(TElPKIResponseHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKIRESPONSE */

#ifdef SB_USE_CLASS_TELCONTROLATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElControlAttribute_CreateInstance(TElTaggedAttributeHandle Tagged, TElControlAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElControlAttribute_CreateInstance_1(TElControlAttributeHandle _Handle, TElTaggedAttributeHandle Tagged, TElControlAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElControlAttribute_LoadFromTagged(TElControlAttributeHandle _Handle, TElTaggedAttributeHandle Tagged);
SB_IMPORT uint32_t SB_APIENTRY TElControlAttribute_SaveToBuffer(TElControlAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElControlAttribute_LoadFromBuffer(TElControlAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElControlAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElControlAttribute_get_OID(TElControlAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElControlAttribute_get_Values(TElControlAttributeHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElControlAttribute_get_ValueCount(TElControlAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElControlAttribute_Create(TElControlAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELCONTROLATTRIBUTE */

#ifdef SB_USE_CLASS_TELIDENTIFICATIONATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElIdentificationAttribute_SaveToBuffer(TElIdentificationAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentificationAttribute_LoadFromBuffer(TElIdentificationAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElIdentificationAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentificationAttribute_get_OID(TElIdentificationAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentificationAttribute_get_Content(TElIdentificationAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentificationAttribute_set_Content(TElIdentificationAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElIdentificationAttribute_Create(TElIdentificationAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELIDENTIFICATIONATTRIBUTE */

#ifdef SB_USE_CLASS_TELPENDINFO
SB_IMPORT uint32_t SB_APIENTRY TElPendInfo_get_PendToken(TElPendInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPendInfo_set_PendToken(TElPendInfoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPendInfo_get_PendTime(TElPendInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPendInfo_set_PendTime(TElPendInfoHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPendInfo_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELPENDINFO */

#ifdef SB_USE_CLASS_TELCMCSTATUSINFOATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_SaveToBuffer(TElCMCStatusInfoAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_LoadFromBuffer(TElCMCStatusInfoAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_get_OID(TElCMCStatusInfoAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_get_CMCStatus(TElCMCStatusInfoAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_set_CMCStatus(TElCMCStatusInfoAttributeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_get_BodyList(TElCMCStatusInfoAttributeHandle _Handle, int32_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_set_BodyList(TElCMCStatusInfoAttributeHandle _Handle, const int32_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_get_StatusString(TElCMCStatusInfoAttributeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_set_StatusString(TElCMCStatusInfoAttributeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_get_HasPendInfo(TElCMCStatusInfoAttributeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_set_HasPendInfo(TElCMCStatusInfoAttributeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_get_HasFailInfo(TElCMCStatusInfoAttributeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_set_HasFailInfo(TElCMCStatusInfoAttributeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_get_FailInfo(TElCMCStatusInfoAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_set_FailInfo(TElCMCStatusInfoAttributeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_get_PendInfo(TElCMCStatusInfoAttributeHandle _Handle, TElPendInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_set_PendInfo(TElCMCStatusInfoAttributeHandle _Handle, TElPendInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoAttribute_Create(TElCMCStatusInfoAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELCMCSTATUSINFOATTRIBUTE */

#ifdef SB_USE_CLASS_TELBODYPARTREFERENCE
SB_IMPORT uint32_t SB_APIENTRY TElBodyPartReference_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELBODYPARTREFERENCE */

#ifdef SB_USE_CLASS_TELBODYPARTID
SB_IMPORT uint32_t SB_APIENTRY TElBodyPartID_get_BodyPartID(TElBodyPartIDHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBodyPartID_set_BodyPartID(TElBodyPartIDHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBodyPartID_Create(TElBodyPartIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBodyPartID_Create_1(int32_t Value, TElBodyPartIDHandle * OutResult);
#endif /* SB_USE_CLASS_TELBODYPARTID */

#ifdef SB_USE_CLASS_TELBODYPARTPATH
SB_IMPORT uint32_t SB_APIENTRY TElBodyPartPath_get_BodyPartPath(TElBodyPartPathHandle _Handle, int32_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBodyPartPath_set_BodyPartPath(TElBodyPartPathHandle _Handle, const int32_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBodyPartPath_Create(TElBodyPartPathHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBodyPartPath_Create_1(const int32_t pValue[], int32_t szValue, TElBodyPartPathHandle * OutResult);
#endif /* SB_USE_CLASS_TELBODYPARTPATH */

#ifdef SB_USE_CLASS_TELEXTENDEDFAILINFO
SB_IMPORT uint32_t SB_APIENTRY TElExtendedFailInfo_get_FailInfoOID(TElExtendedFailInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElExtendedFailInfo_set_FailInfoOID(TElExtendedFailInfoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElExtendedFailInfo_get_FailInfoValue(TElExtendedFailInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElExtendedFailInfo_set_FailInfoValue(TElExtendedFailInfoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElExtendedFailInfo_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELEXTENDEDFAILINFO */

#ifdef SB_USE_CLASS_TELCMCSTATUSINFOV2ATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_SaveToBuffer(TElCMCStatusInfoV2AttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_LoadFromBuffer(TElCMCStatusInfoV2AttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_AddBodyPartReference(TElCMCStatusInfoV2AttributeHandle _Handle, TElBodyPartReferenceHandle Ref, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_RemoveBodyPartReferece(TElCMCStatusInfoV2AttributeHandle _Handle, int32_t Idx);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_get_OID(TElCMCStatusInfoV2AttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_get_CMCStatus(TElCMCStatusInfoV2AttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_set_CMCStatus(TElCMCStatusInfoV2AttributeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_get_BodyList(TElCMCStatusInfoV2AttributeHandle _Handle, int32_t Index, TElBodyPartReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_get_BodyListCount(TElCMCStatusInfoV2AttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_get_StatusString(TElCMCStatusInfoV2AttributeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_set_StatusString(TElCMCStatusInfoV2AttributeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_get_HasPendInfo(TElCMCStatusInfoV2AttributeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_set_HasPendInfo(TElCMCStatusInfoV2AttributeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_get_HasFailInfo(TElCMCStatusInfoV2AttributeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_set_HasFailInfo(TElCMCStatusInfoV2AttributeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_get_HasExtendedFailInfo(TElCMCStatusInfoV2AttributeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_set_HasExtendedFailInfo(TElCMCStatusInfoV2AttributeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_get_FailInfo(TElCMCStatusInfoV2AttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_set_FailInfo(TElCMCStatusInfoV2AttributeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_get_PendInfo(TElCMCStatusInfoV2AttributeHandle _Handle, TElPendInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_set_PendInfo(TElCMCStatusInfoV2AttributeHandle _Handle, TElPendInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_get_ExtendedFailInfo(TElCMCStatusInfoV2AttributeHandle _Handle, TElExtendedFailInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_set_ExtendedFailInfo(TElCMCStatusInfoV2AttributeHandle _Handle, TElExtendedFailInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCMCStatusInfoV2Attribute_Create(TElCMCStatusInfoV2AttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELCMCSTATUSINFOV2ATTRIBUTE */

#ifdef SB_USE_CLASS_TELADDEXTENSIONSATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElAddExtensionsAttribute_SaveToBuffer(TElAddExtensionsAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAddExtensionsAttribute_LoadFromBuffer(TElAddExtensionsAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElAddExtensionsAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAddExtensionsAttribute_get_OID(TElAddExtensionsAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAddExtensionsAttribute_get_PKIDataReference(TElAddExtensionsAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAddExtensionsAttribute_set_PKIDataReference(TElAddExtensionsAttributeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAddExtensionsAttribute_get_CertReferences(TElAddExtensionsAttributeHandle _Handle, int32_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAddExtensionsAttribute_set_CertReferences(TElAddExtensionsAttributeHandle _Handle, const int32_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAddExtensionsAttribute_get_Extensions(TElAddExtensionsAttributeHandle _Handle, TElCertificateExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAddExtensionsAttribute_Create(TElAddExtensionsAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELADDEXTENSIONSATTRIBUTE */

#ifdef SB_USE_CLASS_TELIDENTITYPROOFV2ATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofV2Attribute_SaveToBuffer(TElIdentityProofV2AttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofV2Attribute_LoadFromBuffer(TElIdentityProofV2AttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofV2Attribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofV2Attribute_get_OID(TElIdentityProofV2AttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofV2Attribute_get_HashAlgID(TElIdentityProofV2AttributeHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofV2Attribute_set_HashAlgID(TElIdentityProofV2AttributeHandle _Handle, TElAlgorithmIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofV2Attribute_get_MacAlgID(TElIdentityProofV2AttributeHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofV2Attribute_set_MacAlgID(TElIdentityProofV2AttributeHandle _Handle, TElAlgorithmIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofV2Attribute_get_Witness(TElIdentityProofV2AttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofV2Attribute_set_Witness(TElIdentityProofV2AttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofV2Attribute_Create(TElIdentityProofV2AttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELIDENTITYPROOFV2ATTRIBUTE */

#ifdef SB_USE_CLASS_TELIDENTITYPROOFATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofAttribute_SaveToBuffer(TElIdentityProofAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofAttribute_LoadFromBuffer(TElIdentityProofAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofAttribute_get_OID(TElIdentityProofAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofAttribute_get_IdentifyProof(TElIdentityProofAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofAttribute_set_IdentifyProof(TElIdentityProofAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElIdentityProofAttribute_Create(TElIdentityProofAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELIDENTITYPROOFATTRIBUTE */

#ifdef SB_USE_CLASS_TELPOPLINKWITNESSV2ATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessV2Attribute_SaveToBuffer(TElPopLinkWitnessV2AttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessV2Attribute_LoadFromBuffer(TElPopLinkWitnessV2AttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessV2Attribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessV2Attribute_get_OID(TElPopLinkWitnessV2AttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessV2Attribute_get_KeyGenAlgID(TElPopLinkWitnessV2AttributeHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessV2Attribute_set_KeyGenAlgID(TElPopLinkWitnessV2AttributeHandle _Handle, TElAlgorithmIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessV2Attribute_get_MacAlgID(TElPopLinkWitnessV2AttributeHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessV2Attribute_set_MacAlgID(TElPopLinkWitnessV2AttributeHandle _Handle, TElAlgorithmIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessV2Attribute_get_Witness(TElPopLinkWitnessV2AttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessV2Attribute_set_Witness(TElPopLinkWitnessV2AttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessV2Attribute_Create(TElPopLinkWitnessV2AttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELPOPLINKWITNESSV2ATTRIBUTE */

#ifdef SB_USE_CLASS_TELPOPLINKWITNESSATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessAttribute_SaveToBuffer(TElPopLinkWitnessAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessAttribute_LoadFromBuffer(TElPopLinkWitnessAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessAttribute_get_OID(TElPopLinkWitnessAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessAttribute_get_PopLinkWitness(TElPopLinkWitnessAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessAttribute_set_PopLinkWitness(TElPopLinkWitnessAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkWitnessAttribute_Create(TElPopLinkWitnessAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELPOPLINKWITNESSATTRIBUTE */

#ifdef SB_USE_CLASS_TELDATARETURNATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElDataReturnAttribute_SaveToBuffer(TElDataReturnAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDataReturnAttribute_LoadFromBuffer(TElDataReturnAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElDataReturnAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDataReturnAttribute_get_OID(TElDataReturnAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDataReturnAttribute_get_DataReturn(TElDataReturnAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDataReturnAttribute_set_DataReturn(TElDataReturnAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDataReturnAttribute_Create(TElDataReturnAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELDATARETURNATTRIBUTE */

#ifdef SB_USE_CLASS_TELTRANSACTIONIDENTIFIERATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElTransactionIdentifierAttribute_SaveToBuffer(TElTransactionIdentifierAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTransactionIdentifierAttribute_LoadFromBuffer(TElTransactionIdentifierAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElTransactionIdentifierAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTransactionIdentifierAttribute_get_OID(TElTransactionIdentifierAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTransactionIdentifierAttribute_get_TransactionId(TElTransactionIdentifierAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTransactionIdentifierAttribute_set_TransactionId(TElTransactionIdentifierAttributeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTransactionIdentifierAttribute_Create(TElTransactionIdentifierAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELTRANSACTIONIDENTIFIERATTRIBUTE */

#ifdef SB_USE_CLASS_TELSENDERNONCEATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElSenderNonceAttribute_SaveToBuffer(TElSenderNonceAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSenderNonceAttribute_LoadFromBuffer(TElSenderNonceAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSenderNonceAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSenderNonceAttribute_get_OID(TElSenderNonceAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSenderNonceAttribute_get_Nonce(TElSenderNonceAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSenderNonceAttribute_set_Nonce(TElSenderNonceAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSenderNonceAttribute_Create(TElSenderNonceAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSENDERNONCEATTRIBUTE */

#ifdef SB_USE_CLASS_TELRECIPIENTNONCEATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElRecipientNonceAttribute_SaveToBuffer(TElRecipientNonceAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRecipientNonceAttribute_LoadFromBuffer(TElRecipientNonceAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElRecipientNonceAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRecipientNonceAttribute_get_OID(TElRecipientNonceAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRecipientNonceAttribute_get_Nonce(TElRecipientNonceAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRecipientNonceAttribute_set_Nonce(TElRecipientNonceAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElRecipientNonceAttribute_Create(TElRecipientNonceAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELRECIPIENTNONCEATTRIBUTE */

#ifdef SB_USE_CLASS_TELENCRYPTEDPOPATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_SaveToBuffer(TElEncryptedPopAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_LoadFromBuffer(TElEncryptedPopAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_get_OID(TElEncryptedPopAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_get_Request(TElEncryptedPopAttributeHandle _Handle, TElTaggedRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_set_Request(TElEncryptedPopAttributeHandle _Handle, TElTaggedRequestHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_get_CMS(TElEncryptedPopAttributeHandle _Handle, TElContentInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_set_CMS(TElEncryptedPopAttributeHandle _Handle, TElContentInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_get_POPAlgID(TElEncryptedPopAttributeHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_set_POPAlgID(TElEncryptedPopAttributeHandle _Handle, TElAlgorithmIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_get_WitnessAlgID(TElEncryptedPopAttributeHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_set_WitnessAlgID(TElEncryptedPopAttributeHandle _Handle, TElAlgorithmIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_get_Witness(TElEncryptedPopAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_set_Witness(TElEncryptedPopAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElEncryptedPopAttribute_Create(TElEncryptedPopAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELENCRYPTEDPOPATTRIBUTE */

#ifdef SB_USE_CLASS_TELDECRYPTEDPOPATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElDecryptedPopAttribute_SaveToBuffer(TElDecryptedPopAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDecryptedPopAttribute_LoadFromBuffer(TElDecryptedPopAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElDecryptedPopAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDecryptedPopAttribute_get_OID(TElDecryptedPopAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDecryptedPopAttribute_get_BodyPartId(TElDecryptedPopAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDecryptedPopAttribute_set_BodyPartId(TElDecryptedPopAttributeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDecryptedPopAttribute_get_POPAlgID(TElDecryptedPopAttributeHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDecryptedPopAttribute_set_POPAlgID(TElDecryptedPopAttributeHandle _Handle, TElAlgorithmIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDecryptedPopAttribute_get_POP(TElDecryptedPopAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDecryptedPopAttribute_set_POP(TElDecryptedPopAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDecryptedPopAttribute_Create(TElDecryptedPopAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELDECRYPTEDPOPATTRIBUTE */

#ifdef SB_USE_CLASS_TELLRAPOPWITNESSATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElLraPopWitnessAttribute_SaveToBuffer(TElLraPopWitnessAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLraPopWitnessAttribute_LoadFromBuffer(TElLraPopWitnessAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElLraPopWitnessAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLraPopWitnessAttribute_get_OID(TElLraPopWitnessAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLraPopWitnessAttribute_get_BodyPartId(TElLraPopWitnessAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLraPopWitnessAttribute_set_BodyPartId(TElLraPopWitnessAttributeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElLraPopWitnessAttribute_get_BodyIds(TElLraPopWitnessAttributeHandle _Handle, int32_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLraPopWitnessAttribute_set_BodyIds(TElLraPopWitnessAttributeHandle _Handle, const int32_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLraPopWitnessAttribute_Create(TElLraPopWitnessAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELLRAPOPWITNESSATTRIBUTE */

#ifdef SB_USE_CLASS_TELGETCERTIFICATEATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElGetCertificateAttribute_SaveToBuffer(TElGetCertificateAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGetCertificateAttribute_LoadFromBuffer(TElGetCertificateAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElGetCertificateAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGetCertificateAttribute_get_OID(TElGetCertificateAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGetCertificateAttribute_get_IssuerName(TElGetCertificateAttributeHandle _Handle, TElGeneralNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGetCertificateAttribute_set_IssuerName(TElGetCertificateAttributeHandle _Handle, TElGeneralNameHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElGetCertificateAttribute_get_SerialNumber(TElGetCertificateAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGetCertificateAttribute_set_SerialNumber(TElGetCertificateAttributeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGetCertificateAttribute_Create(TElGetCertificateAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELGETCERTIFICATEATTRIBUTE */

#ifdef SB_USE_CLASS_TELGETCRLATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElGetCRLAttribute_SaveToBuffer(TElGetCRLAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGetCRLAttribute_LoadFromBuffer(TElGetCRLAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElGetCRLAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGetCRLAttribute_get_OID(TElGetCRLAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGetCRLAttribute_get_IssuerName(TElGetCRLAttributeHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGetCRLAttribute_set_IssuerName(TElGetCRLAttributeHandle _Handle, TElRelativeDistinguishedNameHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElGetCRLAttribute_get_CRLName(TElGetCRLAttributeHandle _Handle, TElGeneralNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGetCRLAttribute_set_CRLName(TElGetCRLAttributeHandle _Handle, TElGeneralNameHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElGetCRLAttribute_get_Time(TElGetCRLAttributeHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGetCRLAttribute_set_Time(TElGetCRLAttributeHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGetCRLAttribute_get_Reasons(TElGetCRLAttributeHandle _Handle, TSBCRLReasonFlagsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGetCRLAttribute_set_Reasons(TElGetCRLAttributeHandle _Handle, TSBCRLReasonFlagsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElGetCRLAttribute_Create(TElGetCRLAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELGETCRLATTRIBUTE */

#ifdef SB_USE_CLASS_TELREVOCATIONREQUESTATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_SaveToBuffer(TElRevocationRequestAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_LoadFromBuffer(TElRevocationRequestAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_get_OID(TElRevocationRequestAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_get_IssuerName(TElRevocationRequestAttributeHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_set_IssuerName(TElRevocationRequestAttributeHandle _Handle, TElRelativeDistinguishedNameHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_get_SerialNumber(TElRevocationRequestAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_set_SerialNumber(TElRevocationRequestAttributeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_get_Reason(TElRevocationRequestAttributeHandle _Handle, TSBCRLReasonFlagRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_set_Reason(TElRevocationRequestAttributeHandle _Handle, TSBCRLReasonFlagRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_get_InvalidityDate(TElRevocationRequestAttributeHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_set_InvalidityDate(TElRevocationRequestAttributeHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_get_SharedSecret(TElRevocationRequestAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_set_SharedSecret(TElRevocationRequestAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_get_Comment(TElRevocationRequestAttributeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_set_Comment(TElRevocationRequestAttributeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationRequestAttribute_Create(TElRevocationRequestAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELREVOCATIONREQUESTATTRIBUTE */

#ifdef SB_USE_CLASS_TELREGISTRATIONINFORMATIONATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElRegistrationInformationAttribute_SaveToBuffer(TElRegistrationInformationAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRegistrationInformationAttribute_LoadFromBuffer(TElRegistrationInformationAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElRegistrationInformationAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRegistrationInformationAttribute_get_OID(TElRegistrationInformationAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRegistrationInformationAttribute_get_RegInfo(TElRegistrationInformationAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRegistrationInformationAttribute_set_RegInfo(TElRegistrationInformationAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElRegistrationInformationAttribute_Create(TElRegistrationInformationAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELREGISTRATIONINFORMATIONATTRIBUTE */

#ifdef SB_USE_CLASS_TELRESPONSEINFORMATIONATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElResponseInformationAttribute_SaveToBuffer(TElResponseInformationAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElResponseInformationAttribute_LoadFromBuffer(TElResponseInformationAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElResponseInformationAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElResponseInformationAttribute_get_OID(TElResponseInformationAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElResponseInformationAttribute_get_ResponseInfo(TElResponseInformationAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElResponseInformationAttribute_set_ResponseInfo(TElResponseInformationAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElResponseInformationAttribute_Create(TElResponseInformationAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELRESPONSEINFORMATIONATTRIBUTE */

#ifdef SB_USE_CLASS_TELQUERYPENDINGATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElQueryPendingAttribute_SaveToBuffer(TElQueryPendingAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElQueryPendingAttribute_LoadFromBuffer(TElQueryPendingAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElQueryPendingAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElQueryPendingAttribute_get_OID(TElQueryPendingAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElQueryPendingAttribute_get_QueryPending(TElQueryPendingAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElQueryPendingAttribute_set_QueryPending(TElQueryPendingAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElQueryPendingAttribute_Create(TElQueryPendingAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELQUERYPENDINGATTRIBUTE */

#ifdef SB_USE_CLASS_TELCONFIRMCERTACCEPTANCEATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElConfirmCertAcceptanceAttribute_SaveToBuffer(TElConfirmCertAcceptanceAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElConfirmCertAcceptanceAttribute_LoadFromBuffer(TElConfirmCertAcceptanceAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElConfirmCertAcceptanceAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElConfirmCertAcceptanceAttribute_get_OID(TElConfirmCertAcceptanceAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElConfirmCertAcceptanceAttribute_get_IssuerName(TElConfirmCertAcceptanceAttributeHandle _Handle, TElGeneralNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElConfirmCertAcceptanceAttribute_set_IssuerName(TElConfirmCertAcceptanceAttributeHandle _Handle, TElGeneralNameHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElConfirmCertAcceptanceAttribute_get_SerialNumber(TElConfirmCertAcceptanceAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElConfirmCertAcceptanceAttribute_set_SerialNumber(TElConfirmCertAcceptanceAttributeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElConfirmCertAcceptanceAttribute_Create(TElConfirmCertAcceptanceAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELCONFIRMCERTACCEPTANCEATTRIBUTE */

#ifdef SB_USE_CLASS_TELPUBLISHTRUSTANCHORSATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElPublishTrustAnchorsAttribute_SaveToBuffer(TElPublishTrustAnchorsAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublishTrustAnchorsAttribute_LoadFromBuffer(TElPublishTrustAnchorsAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElPublishTrustAnchorsAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublishTrustAnchorsAttribute_get_OID(TElPublishTrustAnchorsAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublishTrustAnchorsAttribute_get_SeqNumber(TElPublishTrustAnchorsAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublishTrustAnchorsAttribute_set_SeqNumber(TElPublishTrustAnchorsAttributeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPublishTrustAnchorsAttribute_get_HashAlgorithm(TElPublishTrustAnchorsAttributeHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublishTrustAnchorsAttribute_set_HashAlgorithm(TElPublishTrustAnchorsAttributeHandle _Handle, TElAlgorithmIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPublishTrustAnchorsAttribute_Create(TElPublishTrustAnchorsAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELPUBLISHTRUSTANCHORSATTRIBUTE */

#ifdef SB_USE_CLASS_TELAUTHENTICATEDDATAATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataAttribute_SaveToBuffer(TElAuthenticatedDataAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataAttribute_LoadFromBuffer(TElAuthenticatedDataAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataAttribute_get_OID(TElAuthenticatedDataAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataAttribute_get_AuthPublish(TElAuthenticatedDataAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataAttribute_set_AuthPublish(TElAuthenticatedDataAttributeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticatedDataAttribute_Create(TElAuthenticatedDataAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELAUTHENTICATEDDATAATTRIBUTE */

#ifdef SB_USE_CLASS_TELBATCHREQUESTSATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElBatchRequestsAttribute_SaveToBuffer(TElBatchRequestsAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBatchRequestsAttribute_LoadFromBuffer(TElBatchRequestsAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElBatchRequestsAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBatchRequestsAttribute_get_OID(TElBatchRequestsAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBatchRequestsAttribute_get_BodyPartList(TElBatchRequestsAttributeHandle _Handle, int32_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBatchRequestsAttribute_set_BodyPartList(TElBatchRequestsAttributeHandle _Handle, const int32_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBatchRequestsAttribute_Create(TElBatchRequestsAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELBATCHREQUESTSATTRIBUTE */

#ifdef SB_USE_CLASS_TELBATCHRESPONSESATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElBatchResponsesAttribute_SaveToBuffer(TElBatchResponsesAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBatchResponsesAttribute_LoadFromBuffer(TElBatchResponsesAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElBatchResponsesAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBatchResponsesAttribute_get_OID(TElBatchResponsesAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBatchResponsesAttribute_get_BodyPartList(TElBatchResponsesAttributeHandle _Handle, int32_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBatchResponsesAttribute_set_BodyPartList(TElBatchResponsesAttributeHandle _Handle, const int32_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBatchResponsesAttribute_Create(TElBatchResponsesAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELBATCHRESPONSESATTRIBUTE */

#ifdef SB_USE_CLASS_TELPOPLINKRANDOMATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkRandomAttribute_SaveToBuffer(TElPopLinkRandomAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkRandomAttribute_LoadFromBuffer(TElPopLinkRandomAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkRandomAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkRandomAttribute_get_OID(TElPopLinkRandomAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkRandomAttribute_get_PopLinkRandom(TElPopLinkRandomAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkRandomAttribute_set_PopLinkRandom(TElPopLinkRandomAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPopLinkRandomAttribute_Create(TElPopLinkRandomAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELPOPLINKRANDOMATTRIBUTE */

#ifdef SB_USE_CLASS_TELSINGLEPUBINFO
SB_IMPORT uint32_t SB_APIENTRY TElSinglePubInfo_get_PubMethod(TElSinglePubInfoHandle _Handle, TSBPKIPublishMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSinglePubInfo_set_PubMethod(TElSinglePubInfoHandle _Handle, TSBPKIPublishMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSinglePubInfo_get_PubLocation(TElSinglePubInfoHandle _Handle, TElGeneralNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSinglePubInfo_set_PubLocation(TElSinglePubInfoHandle _Handle, TElGeneralNameHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSinglePubInfo_Create(TElSinglePubInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELSINGLEPUBINFO */

#ifdef SB_USE_CLASS_TELPKIPUBLICATIONINFO
SB_IMPORT uint32_t SB_APIENTRY TElPKIPublicationInfo_AddInfo(TElPKIPublicationInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKIPublicationInfo_RemoveInfo(TElPKIPublicationInfoHandle _Handle, int32_t Idx);
SB_IMPORT uint32_t SB_APIENTRY TElPKIPublicationInfo_get_Action(TElPKIPublicationInfoHandle _Handle, TSBPKIPublicationActionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKIPublicationInfo_set_Action(TElPKIPublicationInfoHandle _Handle, TSBPKIPublicationActionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKIPublicationInfo_get_Infos(TElPKIPublicationInfoHandle _Handle, int32_t Index, TElSinglePubInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKIPublicationInfo_get_Count(TElPKIPublicationInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKIPublicationInfo_Create(TElPKIPublicationInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKIPUBLICATIONINFO */

#ifdef SB_USE_CLASS_TELPUBLICATIONINFORMATIONATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElPublicationInformationAttribute_SaveToBuffer(TElPublicationInformationAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicationInformationAttribute_LoadFromBuffer(TElPublicationInformationAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElPublicationInformationAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicationInformationAttribute_get_OID(TElPublicationInformationAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicationInformationAttribute_get_HashAlgorithm(TElPublicationInformationAttributeHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicationInformationAttribute_set_HashAlgorithm(TElPublicationInformationAttributeHandle _Handle, TElAlgorithmIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPublicationInformationAttribute_get_PubInfo(TElPublicationInformationAttributeHandle _Handle, TElPKIPublicationInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicationInformationAttribute_Create(TElPublicationInformationAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELPUBLICATIONINFORMATIONATTRIBUTE */

#ifdef SB_USE_CLASS_TELCONTROLPROCESSEDATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElControlProcessedAttribute_AddBodyPartReference(TElControlProcessedAttributeHandle _Handle, TElBodyPartReferenceHandle Ref, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElControlProcessedAttribute_RemoveBodyPartReferece(TElControlProcessedAttributeHandle _Handle, int32_t Idx);
SB_IMPORT uint32_t SB_APIENTRY TElControlProcessedAttribute_SaveToBuffer(TElControlProcessedAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElControlProcessedAttribute_LoadFromBuffer(TElControlProcessedAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElControlProcessedAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElControlProcessedAttribute_get_OID(TElControlProcessedAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElControlProcessedAttribute_get_BodyList(TElControlProcessedAttributeHandle _Handle, int32_t Index, TElBodyPartReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElControlProcessedAttribute_get_BodyListCount(TElControlProcessedAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElControlProcessedAttribute_Create(TElControlProcessedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELCONTROLPROCESSEDATTRIBUTE */

#ifdef SB_USE_CLASS_TELOPTIONALVALIDITY
SB_IMPORT uint32_t SB_APIENTRY TElOptionalValidity_get_NotBefore(TElOptionalValidityHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOptionalValidity_set_NotBefore(TElOptionalValidityHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOptionalValidity_get_NotAfter(TElOptionalValidityHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOptionalValidity_set_NotAfter(TElOptionalValidityHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOptionalValidity_Create(TElOptionalValidityHandle * OutResult);
#endif /* SB_USE_CLASS_TELOPTIONALVALIDITY */

#ifdef SB_USE_CLASS_TELPUBLICKEYINFO
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyInfo_get_Algorithm(TElPublicKeyInfoHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyInfo_set_Algorithm(TElPublicKeyInfoHandle _Handle, TElAlgorithmIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyInfo_get_PublicKey(TElPublicKeyInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyInfo_set_PublicKey(TElPublicKeyInfoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyInfo_Create(TElPublicKeyInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELPUBLICKEYINFO */

#ifdef SB_USE_CLASS_TELCERTTEMPLATE
SB_IMPORT uint32_t SB_APIENTRY TElCertTemplate_SaveToTag(TElCertTemplateHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElCertTemplate_LoadFromTag(TElCertTemplateHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElCertTemplate_get_Subject(TElCertTemplateHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertTemplate_set_Subject(TElCertTemplateHandle _Handle, TElRelativeDistinguishedNameHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertTemplate_get_SubjectPublicKeyInfo(TElCertTemplateHandle _Handle, TElPublicKeyInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertTemplate_get_Validity(TElCertTemplateHandle _Handle, TElOptionalValidityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertTemplate_set_Validity(TElCertTemplateHandle _Handle, TElOptionalValidityHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertTemplate_get_Extensions(TElCertTemplateHandle _Handle, TElCertificateExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertTemplate_Create(TElCertTemplateHandle * OutResult);
#endif /* SB_USE_CLASS_TELCERTTEMPLATE */

#ifdef SB_USE_CLASS_TELMODCERTIFICATIONREQUESTATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElModCertificationRequestAttribute_SaveToBuffer(TElModCertificationRequestAttributeHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElModCertificationRequestAttribute_LoadFromBuffer(TElModCertificationRequestAttributeHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElModCertificationRequestAttribute_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElModCertificationRequestAttribute_get_OID(TElModCertificationRequestAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElModCertificationRequestAttribute_get_PKIDataReference(TElModCertificationRequestAttributeHandle _Handle, TElBodyPartPathHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElModCertificationRequestAttribute_get_CertReferences(TElModCertificationRequestAttributeHandle _Handle, int32_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElModCertificationRequestAttribute_set_CertReferences(TElModCertificationRequestAttributeHandle _Handle, const int32_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElModCertificationRequestAttribute_get_Replace(TElModCertificationRequestAttributeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElModCertificationRequestAttribute_set_Replace(TElModCertificationRequestAttributeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElModCertificationRequestAttribute_get_CertTemplate(TElModCertificationRequestAttributeHandle _Handle, TElCertTemplateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElModCertificationRequestAttribute_Create(TElModCertificationRequestAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELMODCERTIFICATIONREQUESTATTRIBUTE */

#ifdef SB_USE_CLASS_TELFULLPKIREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_CreateSimpleRequest(TElCertificateRequestHandle Request, TElFullPKIRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_CreateSimpleRequest_1(TElFullPKIRequestHandle _Handle, TElCertificateRequestHandle Request, TElFullPKIRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_CreateSimpleRequest_2(TElCertificateRequestHandle Request, TElCustomCertStorageHandle EncryptionCertificates, TElFullPKIRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_CreateSimpleRequest_3(TElFullPKIRequestHandle _Handle, TElCertificateRequestHandle Request, TElCustomCertStorageHandle EncryptionCertificates, TElFullPKIRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_SaveToBuffer(TElFullPKIRequestHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_LoadFromBuffer(TElFullPKIRequestHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_LoadFromStream(TElFullPKIRequestHandle _Handle, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_SaveToStream(TElFullPKIRequestHandle _Handle, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_SaveToFile(TElFullPKIRequestHandle _Handle, const char * pcFileName, int32_t szFileName);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_LoadFromFile(TElFullPKIRequestHandle _Handle, const char * pcFileName, int32_t szFileName);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_AddRequest(TElFullPKIRequestHandle _Handle, TElCertificateRequestHandle Req, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_RemoveRequest(TElFullPKIRequestHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_AddControlAttribute(TElFullPKIRequestHandle _Handle, TElControlAttributeHandle Attr, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_RemoveControlAttribute(TElFullPKIRequestHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_AddCMS(TElFullPKIRequestHandle _Handle, const uint8_t pCMS[], int32_t szCMS, const uint8_t pContentType[], int32_t szContentType, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_AddCMS_1(TElFullPKIRequestHandle _Handle, TElFullPKIRequestHandle CMS, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_RemoveCMS(TElFullPKIRequestHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_AddOtherMsg(TElFullPKIRequestHandle _Handle, const uint8_t pMsg[], int32_t szMsg, const uint8_t pContentType[], int32_t szContentType, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_RemoveOtherMsg(TElFullPKIRequestHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_GetBodyPartID(TElFullPKIRequestHandle _Handle, TObjectHandle Part, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_get_Requests(TElFullPKIRequestHandle _Handle, int32_t Index, TElCertificateRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_get_ControlAttributes(TElFullPKIRequestHandle _Handle, int32_t Index, TElControlAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_get_CMSs(TElFullPKIRequestHandle _Handle, int32_t Index, TElContentInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_get_OtherMessages(TElFullPKIRequestHandle _Handle, int32_t Index, TElOtherMsgHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_get_RequestCount(TElFullPKIRequestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_get_ControlAttributeCount(TElFullPKIRequestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_get_CMSCount(TElFullPKIRequestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_get_OtherMessageCount(TElFullPKIRequestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_get_StoreFormat(TElFullPKIRequestHandle _Handle, TSBFullPKIFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_set_StoreFormat(TElFullPKIRequestHandle _Handle, TSBFullPKIFormatRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_get_SigningCertificates(TElFullPKIRequestHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_set_SigningCertificates(TElFullPKIRequestHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_get_EncryptionCertificates(TElFullPKIRequestHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_set_EncryptionCertificates(TElFullPKIRequestHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_get_MainRequestIndex(TElFullPKIRequestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_set_MainRequestIndex(TElFullPKIRequestHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_get_OnSignature(TElFullPKIRequestHandle _Handle, TSBFullPKISignatureEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_set_OnSignature(TElFullPKIRequestHandle _Handle, TSBFullPKISignatureEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIRequest_Create(TElFullPKIRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELFULLPKIREQUEST */

#ifdef SB_USE_CLASS_TELFULLPKIRESPONSE
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_SaveToBuffer(TElFullPKIResponseHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_LoadFromBuffer(TElFullPKIResponseHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_LoadFromStream(TElFullPKIResponseHandle _Handle, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_SaveToStream(TElFullPKIResponseHandle _Handle, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_SaveToFile(TElFullPKIResponseHandle _Handle, const char * pcFileName, int32_t szFileName);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_LoadFromFile(TElFullPKIResponseHandle _Handle, const char * pcFileName, int32_t szFileName);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_AddControlAttribute(TElFullPKIResponseHandle _Handle, TElControlAttributeHandle Attr, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_RemoveControlAttribute(TElFullPKIResponseHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_AddCMS(TElFullPKIResponseHandle _Handle, const uint8_t pCMS[], int32_t szCMS, const uint8_t pContentType[], int32_t szContentType, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_RemoveCMS(TElFullPKIResponseHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_AddOtherMsg(TElFullPKIResponseHandle _Handle, const uint8_t pMsg[], int32_t szMsg, const uint8_t pContentType[], int32_t szContentType, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_RemoveOtherMsg(TElFullPKIResponseHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_GetBodyPartID(TElFullPKIResponseHandle _Handle, TObjectHandle Part, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_get_ControlAttributes(TElFullPKIResponseHandle _Handle, int32_t Index, TElControlAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_get_CMSs(TElFullPKIResponseHandle _Handle, int32_t Index, TElContentInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_get_OtherMessages(TElFullPKIResponseHandle _Handle, int32_t Index, TElOtherMsgHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_get_ControlAttributeCount(TElFullPKIResponseHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_get_CMSCount(TElFullPKIResponseHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_get_OtherMessageCount(TElFullPKIResponseHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_get_StoreFormat(TElFullPKIResponseHandle _Handle, TSBFullPKIFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_set_StoreFormat(TElFullPKIResponseHandle _Handle, TSBFullPKIFormatRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_get_SigningCertificates(TElFullPKIResponseHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_set_SigningCertificates(TElFullPKIResponseHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_get_EncryptionCertificates(TElFullPKIResponseHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_set_EncryptionCertificates(TElFullPKIResponseHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_get_IssuedCertificates(TElFullPKIResponseHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_get_IssuerCRLs(TElFullPKIResponseHandle _Handle, TElMemoryCRLStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_get_OnSignature(TElFullPKIResponseHandle _Handle, TSBFullPKISignatureEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_set_OnSignature(TElFullPKIResponseHandle _Handle, TSBFullPKISignatureEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElFullPKIResponse_Create(TElFullPKIResponseHandle * OutResult);
#endif /* SB_USE_CLASS_TELFULLPKIRESPONSE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElControlAttributeClass_ce_ptr;
extern zend_class_entry *TElAttributeValue_ce_ptr;
extern zend_class_entry *TElTaggedAttribute_ce_ptr;
extern zend_class_entry *TElTaggedCertificationRequest_ce_ptr;
extern zend_class_entry *TElExternallyDefinedCertificationRequest_ce_ptr;
extern zend_class_entry *TElTaggedRequest_ce_ptr;
extern zend_class_entry *TElContentInfo_ce_ptr;
extern zend_class_entry *TElTaggedContentInfo_ce_ptr;
extern zend_class_entry *TElOtherMsg_ce_ptr;
extern zend_class_entry *TElPKIData_ce_ptr;
extern zend_class_entry *TElPKIResponse_ce_ptr;
extern zend_class_entry *TElControlAttribute_ce_ptr;
extern zend_class_entry *TElIdentificationAttribute_ce_ptr;
extern zend_class_entry *TElPendInfo_ce_ptr;
extern zend_class_entry *TElCMCStatusInfoAttribute_ce_ptr;
extern zend_class_entry *TElBodyPartReference_ce_ptr;
extern zend_class_entry *TElBodyPartID_ce_ptr;
extern zend_class_entry *TElBodyPartPath_ce_ptr;
extern zend_class_entry *TElExtendedFailInfo_ce_ptr;
extern zend_class_entry *TElCMCStatusInfoV2Attribute_ce_ptr;
extern zend_class_entry *TElAddExtensionsAttribute_ce_ptr;
extern zend_class_entry *TElIdentityProofV2Attribute_ce_ptr;
extern zend_class_entry *TElIdentityProofAttribute_ce_ptr;
extern zend_class_entry *TElPopLinkWitnessV2Attribute_ce_ptr;
extern zend_class_entry *TElPopLinkWitnessAttribute_ce_ptr;
extern zend_class_entry *TElDataReturnAttribute_ce_ptr;
extern zend_class_entry *TElTransactionIdentifierAttribute_ce_ptr;
extern zend_class_entry *TElSenderNonceAttribute_ce_ptr;
extern zend_class_entry *TElRecipientNonceAttribute_ce_ptr;
extern zend_class_entry *TElEncryptedPopAttribute_ce_ptr;
extern zend_class_entry *TElDecryptedPopAttribute_ce_ptr;
extern zend_class_entry *TElLraPopWitnessAttribute_ce_ptr;
extern zend_class_entry *TElGetCertificateAttribute_ce_ptr;
extern zend_class_entry *TElGetCRLAttribute_ce_ptr;
extern zend_class_entry *TElRevocationRequestAttribute_ce_ptr;
extern zend_class_entry *TElRegistrationInformationAttribute_ce_ptr;
extern zend_class_entry *TElResponseInformationAttribute_ce_ptr;
extern zend_class_entry *TElQueryPendingAttribute_ce_ptr;
extern zend_class_entry *TElConfirmCertAcceptanceAttribute_ce_ptr;
extern zend_class_entry *TElPublishTrustAnchorsAttribute_ce_ptr;
extern zend_class_entry *TElAuthenticatedDataAttribute_ce_ptr;
extern zend_class_entry *TElBatchRequestsAttribute_ce_ptr;
extern zend_class_entry *TElBatchResponsesAttribute_ce_ptr;
extern zend_class_entry *TElPopLinkRandomAttribute_ce_ptr;
extern zend_class_entry *TElSinglePubInfo_ce_ptr;
extern zend_class_entry *TElPKIPublicationInfo_ce_ptr;
extern zend_class_entry *TElPublicationInformationAttribute_ce_ptr;
extern zend_class_entry *TElControlProcessedAttribute_ce_ptr;
extern zend_class_entry *TElOptionalValidity_ce_ptr;
extern zend_class_entry *TElPublicKeyInfo_ce_ptr;
extern zend_class_entry *TElCertTemplate_ce_ptr;
extern zend_class_entry *TElModCertificationRequestAttribute_ce_ptr;
extern zend_class_entry *TElFullPKIRequest_ce_ptr;
extern zend_class_entry *TElFullPKIResponse_ce_ptr;

void SB_CALLBACK TSBFullPKISignatureEventRaw(void * _ObjectData, TObjectHandle Sender, TElCMSSignatureHandle Signature, int8_t * Continue);
void Register_TElAttributeValue(TSRMLS_D);
void Register_TElTaggedAttribute(TSRMLS_D);
void Register_TElTaggedCertificationRequest(TSRMLS_D);
void Register_TElExternallyDefinedCertificationRequest(TSRMLS_D);
void Register_TElTaggedRequest(TSRMLS_D);
void Register_TElContentInfo(TSRMLS_D);
void Register_TElTaggedContentInfo(TSRMLS_D);
void Register_TElOtherMsg(TSRMLS_D);
void Register_TElPKIData(TSRMLS_D);
void Register_TElPKIResponse(TSRMLS_D);
void Register_TElControlAttribute(TSRMLS_D);
void Register_TElIdentificationAttribute(TSRMLS_D);
void Register_TElPendInfo(TSRMLS_D);
void Register_TElCMCStatusInfoAttribute(TSRMLS_D);
void Register_TElBodyPartReference(TSRMLS_D);
void Register_TElBodyPartID(TSRMLS_D);
void Register_TElBodyPartPath(TSRMLS_D);
void Register_TElExtendedFailInfo(TSRMLS_D);
void Register_TElCMCStatusInfoV2Attribute(TSRMLS_D);
void Register_TElAddExtensionsAttribute(TSRMLS_D);
void Register_TElIdentityProofV2Attribute(TSRMLS_D);
void Register_TElIdentityProofAttribute(TSRMLS_D);
void Register_TElPopLinkWitnessV2Attribute(TSRMLS_D);
void Register_TElPopLinkWitnessAttribute(TSRMLS_D);
void Register_TElDataReturnAttribute(TSRMLS_D);
void Register_TElTransactionIdentifierAttribute(TSRMLS_D);
void Register_TElSenderNonceAttribute(TSRMLS_D);
void Register_TElRecipientNonceAttribute(TSRMLS_D);
void Register_TElEncryptedPopAttribute(TSRMLS_D);
void Register_TElDecryptedPopAttribute(TSRMLS_D);
void Register_TElLraPopWitnessAttribute(TSRMLS_D);
void Register_TElGetCertificateAttribute(TSRMLS_D);
void Register_TElGetCRLAttribute(TSRMLS_D);
void Register_TElRevocationRequestAttribute(TSRMLS_D);
void Register_TElRegistrationInformationAttribute(TSRMLS_D);
void Register_TElResponseInformationAttribute(TSRMLS_D);
void Register_TElQueryPendingAttribute(TSRMLS_D);
void Register_TElConfirmCertAcceptanceAttribute(TSRMLS_D);
void Register_TElPublishTrustAnchorsAttribute(TSRMLS_D);
void Register_TElAuthenticatedDataAttribute(TSRMLS_D);
void Register_TElBatchRequestsAttribute(TSRMLS_D);
void Register_TElBatchResponsesAttribute(TSRMLS_D);
void Register_TElPopLinkRandomAttribute(TSRMLS_D);
void Register_TElSinglePubInfo(TSRMLS_D);
void Register_TElPKIPublicationInfo(TSRMLS_D);
void Register_TElPublicationInformationAttribute(TSRMLS_D);
void Register_TElControlProcessedAttribute(TSRMLS_D);
void Register_TElOptionalValidity(TSRMLS_D);
void Register_TElPublicKeyInfo(TSRMLS_D);
void Register_TElCertTemplate(TSRMLS_D);
void Register_TElModCertificationRequestAttribute(TSRMLS_D);
void Register_TElFullPKIRequest(TSRMLS_D);
void Register_TElFullPKIResponse(TSRMLS_D);
void Register_SBCMC_Constants(int module_number TSRMLS_DC);
void Register_SBCMC_Enum_Flags(TSRMLS_D);
void Register_SBCMC_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCMC */

