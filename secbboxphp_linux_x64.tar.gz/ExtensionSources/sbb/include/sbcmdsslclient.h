#ifndef __INC_SBCMDSSLCLIENT
#define __INC_SBCMDSSLCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbcrc.h"
#include "sbx509.h"
#include "sbx509ext.h"
#include "sbcustomcertstorage.h"
#include "sbsslcommon.h"
#include "sbconstants.h"
#include "sbsslconstants.h"
#include "sbsharedresource.h"
#include "sbsslclient.h"
#include "sbsimplessl.h"
#include "sbsocket.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_CMDSSL 	163840
#define SB_ERROR_CMDSSL_ERROR_FLAG 	2048
#define SB_CMDSSL_ERROR_INVALID_REPLY 	165889

typedef TElClassHandle TElCommandSSLClientHandle;

typedef TElCommandSSLClientHandle ElCommandSSLClientHandle;

#ifdef SB_USE_CLASS_TELCOMMANDSSLCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSLClient_SendCmd(TElCommandSSLClientHandle _Handle, const char * pcCommand, int32_t szCommand, const int16_t pAcceptCodes[], int32_t szAcceptCodes, int16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSLClient_get_LastReply(TElCommandSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSLClient_get_OnSent(TElCommandSSLClientHandle _Handle, TSBTextDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSLClient_set_OnSent(TElCommandSSLClientHandle _Handle, TSBTextDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSLClient_get_OnReceived(TElCommandSSLClientHandle _Handle, TSBTextDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSLClient_set_OnReceived(TElCommandSSLClientHandle _Handle, TSBTextDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSLClient_Create(TComponentHandle AOwner, TElCommandSSLClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELCOMMANDSSLCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElCommandSSLClient_ce_ptr;

void Register_TElCommandSSLClient(TSRMLS_D);
void Register_SBCmdSSLClient_Constants(int module_number TSRMLS_DC);
void Register_SBCmdSSLClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCMDSSLCLIENT */

