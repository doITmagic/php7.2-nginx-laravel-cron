#ifndef __INC_SBCOMPOUNDFILE
#define __INC_SBCOMPOUNDFILE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcompoundfilebase.h"
#include "sbcompoundfileresources.h"
#include "sbstreams.h"
#include "sbtypes.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElCompoundFileStorageHandle;

typedef TElClassHandle TElCompoundFileStreamEntryHandle;

typedef TElClassHandle TElCompoundFileStorageEntryHandle;

typedef TElClassHandle TElCompoundFileVirtualStreamHandle;

typedef TElClassHandle TElCompoundFileTableStreamHandle;

typedef TElClassHandle TElCompoundFileDirectoryStreamHandle;

typedef TElClassHandle TElCompoundFileCustomEntryHandle;

#ifdef SB_USE_CLASS_TELCOMPOUNDFILESTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_CreateNew(TElCompoundFileStorageHandle _Handle, const char * pcFileName, int32_t szFileName, int32_t Version);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_CreateNew_1(TElCompoundFileStorageHandle _Handle, TStreamHandle Stream, int32_t Version);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_CreateNew_2(TElCompoundFileStorageHandle _Handle, TStreamHandle Stream, int32_t Version, int8_t OwnStream);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_Open(TElCompoundFileStorageHandle _Handle, const char * pcFileName, int32_t szFileName, int8_t ReadOnly);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_Open_1(TElCompoundFileStorageHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_Open_2(TElCompoundFileStorageHandle _Handle, TStreamHandle Stream, int8_t OwnStream);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_Open_3(TElCompoundFileStorageHandle _Handle, TStreamHandle Stream, int8_t OwnStream, int8_t ReadOnly);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_Close(TElCompoundFileStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_Flush(TElCompoundFileStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_get_FileVersion(TElCompoundFileStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_get_IsReadOnly(TElCompoundFileStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_get_SectorSize(TElCompoundFileStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_get_MiniSectorSize(TElCompoundFileStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_get_MiniSectorCutoffSize(TElCompoundFileStorageHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_get_RootEntry(TElCompoundFileStorageHandle _Handle, TElCompoundFileStorageEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorage_Create(TElCompoundFileStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELCOMPOUNDFILESTORAGE */

#ifdef SB_USE_CLASS_TELCOMPOUNDFILECUSTOMENTRY
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileCustomEntry_get_Name(TElCompoundFileCustomEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileCustomEntry_set_Name(TElCompoundFileCustomEntryHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileCustomEntry_get_Parent(TElCompoundFileCustomEntryHandle _Handle, TElCompoundFileStorageEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileCustomEntry_get_Storage(TElCompoundFileCustomEntryHandle _Handle, TElCompoundFileStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileCustomEntry_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELCOMPOUNDFILECUSTOMENTRY */

#ifdef SB_USE_CLASS_TELCOMPOUNDFILESTORAGEENTRY
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_CreateStream(TElCompoundFileStorageEntryHandle _Handle, const char * pcStreamName, int32_t szStreamName, TElCompoundFileStreamEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_CreateSubStorage(TElCompoundFileStorageEntryHandle _Handle, const char * pcStorageName, int32_t szStorageName, TElCompoundFileStorageEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_DeleteStream(TElCompoundFileStorageEntryHandle _Handle, const char * pcStreamName, int32_t szStreamName);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_DeleteSubStorage(TElCompoundFileStorageEntryHandle _Handle, const char * pcStorageName, int32_t szStorageName);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_GetStream(TElCompoundFileStorageEntryHandle _Handle, const char * pcStreamName, int32_t szStreamName, TElCompoundFileStreamEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_GetSubStorage(TElCompoundFileStorageEntryHandle _Handle, const char * pcStorageName, int32_t szStorageName, TElCompoundFileStorageEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_FindEntryByName(TElCompoundFileStorageEntryHandle _Handle, const char * pcEntryName, int32_t szEntryName, TElCompoundFileCustomEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_StreamExists(TElCompoundFileStorageEntryHandle _Handle, const char * pcStreamName, int32_t szStreamName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_SubStorageExists(TElCompoundFileStorageEntryHandle _Handle, const char * pcStorageName, int32_t szStorageName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_GetFirstChild(TElCompoundFileStorageEntryHandle _Handle, TElCompoundFileCustomEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_GetNextEntry(TElCompoundFileStorageEntryHandle _Handle, TElCompoundFileCustomEntryHandle Last, TElCompoundFileCustomEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_get_CLSID(TElCompoundFileStorageEntryHandle _Handle, TGuid * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_set_CLSID(TElCompoundFileStorageEntryHandle _Handle, TGuid * Value);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_get_CreationTime(TElCompoundFileStorageEntryHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_set_CreationTime(TElCompoundFileStorageEntryHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_get_ModifiedTime(TElCompoundFileStorageEntryHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_set_ModifiedTime(TElCompoundFileStorageEntryHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStorageEntry_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELCOMPOUNDFILESTORAGEENTRY */

#ifdef SB_USE_CLASS_TELCOMPOUNDFILEVIRTUALSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileVirtualStream_Flush(TElCompoundFileVirtualStreamHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileVirtualStream_Close(TElCompoundFileVirtualStreamHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileVirtualStream_Close_1(TElCompoundFileVirtualStreamHandle _Handle, int8_t FlushData);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileVirtualStream_Read(TElCompoundFileVirtualStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileVirtualStream_Write(TElCompoundFileVirtualStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileVirtualStream_Seek(TElCompoundFileVirtualStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileVirtualStream_Seek_1(TElCompoundFileVirtualStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileVirtualStream_get_IsMiniStream(TElCompoundFileVirtualStreamHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileVirtualStream_Create(TElCompoundFileStorageHandle Storage, TElCompoundFileVirtualStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileVirtualStream_Create_1(TElCompoundFileStorageHandle Storage, TElCompoundFileStreamEntryHandle StreamEntry, TElCompoundFileVirtualStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELCOMPOUNDFILEVIRTUALSTREAM */

#ifdef SB_USE_CLASS_TELCOMPOUNDFILETABLESTREAM
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileTableStream_Read(TElCompoundFileTableStreamHandle _Handle, uint32_t * Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileTableStream_Read_1(TElCompoundFileVirtualStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileTableStream_Write(TElCompoundFileTableStreamHandle _Handle, uint32_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileTableStream_Write_1(TElCompoundFileVirtualStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileTableStream_Create(TElCompoundFileStorageHandle Storage, TElCompoundFileVirtualStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileTableStream_Create_1(TElCompoundFileStorageHandle Storage, TElCompoundFileStreamEntryHandle StreamEntry, TElCompoundFileVirtualStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELCOMPOUNDFILETABLESTREAM */

#ifdef SB_USE_CLASS_TELCOMPOUNDFILEDIRECTORYSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileDirectoryStream_Read(TElCompoundFileDirectoryStreamHandle _Handle, TSBCompoundFileDirectoryEntry * Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileDirectoryStream_Read_1(TElCompoundFileVirtualStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileDirectoryStream_Write(TElCompoundFileDirectoryStreamHandle _Handle, const TSBCompoundFileDirectoryEntry * Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileDirectoryStream_Write_1(TElCompoundFileVirtualStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileDirectoryStream_Create(TElCompoundFileStorageHandle Storage, TElCompoundFileVirtualStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileDirectoryStream_Create_1(TElCompoundFileStorageHandle Storage, TElCompoundFileStreamEntryHandle StreamEntry, TElCompoundFileVirtualStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELCOMPOUNDFILEDIRECTORYSTREAM */

#ifdef SB_USE_CLASS_TELCOMPOUNDFILESTREAMENTRY
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStreamEntry_get_Stream(TElCompoundFileStreamEntryHandle _Handle, TElCompoundFileVirtualStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCompoundFileStreamEntry_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELCOMPOUNDFILESTREAMENTRY */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElCompoundFileStorage_ce_ptr;
extern zend_class_entry *TElCompoundFileCustomEntry_ce_ptr;
extern zend_class_entry *TElCompoundFileStorageEntry_ce_ptr;
extern zend_class_entry *TElCompoundFileVirtualStream_ce_ptr;
extern zend_class_entry *TElCompoundFileTableStream_ce_ptr;
extern zend_class_entry *TElCompoundFileDirectoryStream_ce_ptr;
extern zend_class_entry *TElCompoundFileStreamEntry_ce_ptr;

void Register_TElCompoundFileStorage(TSRMLS_D);
void Register_TElCompoundFileCustomEntry(TSRMLS_D);
void Register_TElCompoundFileStorageEntry(TSRMLS_D);
void Register_TElCompoundFileVirtualStream(TSRMLS_D);
void Register_TElCompoundFileTableStream(TSRMLS_D);
void Register_TElCompoundFileDirectoryStream(TSRMLS_D);
void Register_TElCompoundFileStreamEntry(TSRMLS_D);
SB_PHP_FUNCTION(SBCompoundFile, IsValidDirectoryEntryName);
SB_PHP_FUNCTION(SBCompoundFile, CompareDirectoryEntryNames);
SB_PHP_FUNCTION(SBCompoundFile, CopyStorage);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_COMPOUNDFILE
SB_IMPORT uint32_t SB_APIENTRY SBCompoundFile_IsValidDirectoryEntryName(const char * pcEntryName, int32_t szEntryName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCompoundFile_CompareDirectoryEntryNames(const char * pcX, int32_t szX, const char * pcY, int32_t szY, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCompoundFile_CopyStorage(TElCompoundFileStorageEntryHandle SourceStorage, TElCompoundFileStorageEntryHandle DestStorage);
#endif /* SB_USE_GLOBAL_PROCS_COMPOUNDFILE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCOMPOUNDFILE */

