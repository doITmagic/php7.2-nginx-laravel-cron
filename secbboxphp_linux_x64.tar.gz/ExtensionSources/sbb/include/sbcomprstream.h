#ifndef __INC_SBCOMPRSTREAM
#define __INC_SBCOMPRSTREAM

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElCustomCompressingStreamHandle;

typedef TElClassHandle TElCustomDecompressingStreamHandle;

typedef TElClassHandle TElZlibCompressingStreamHandle;

typedef TElClassHandle TElZlibDecompressingStreamHandle;

#ifdef SB_USE_CLASS_TELCUSTOMCOMPRESSINGSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElCustomCompressingStream_Read(TElCustomCompressingStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCompressingStream_Write(TElCustomCompressingStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCompressingStream_Seek(TElCustomCompressingStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCompressingStream_Seek_1(TElCustomCompressingStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCompressingStream_Create(TStreamHandle SourceStream, int64_t Count, int8_t ReleaseSourceStream, TElCustomCompressingStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMCOMPRESSINGSTREAM */

#ifdef SB_USE_CLASS_TELCUSTOMDECOMPRESSINGSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElCustomDecompressingStream_FinalizeOutput(TElCustomDecompressingStreamHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomDecompressingStream_Read(TElCustomDecompressingStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomDecompressingStream_Write(TElCustomDecompressingStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomDecompressingStream_Seek(TElCustomDecompressingStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomDecompressingStream_Seek_1(TElCustomDecompressingStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomDecompressingStream_get_DestStream(TElCustomDecompressingStreamHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomDecompressingStream_Create(TStreamHandle DestStream, int8_t ReleaseDestStream, TElCustomDecompressingStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMDECOMPRESSINGSTREAM */

#ifdef SB_USE_CLASS_TELZLIBCOMPRESSINGSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElZlibCompressingStream_Create(int32_t CompressionLevel, TStreamHandle SourceStream, int64_t Count, int8_t ReleaseSourceStream, TElZlibCompressingStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELZLIBCOMPRESSINGSTREAM */

#ifdef SB_USE_CLASS_TELZLIBDECOMPRESSINGSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElZlibDecompressingStream_Create(TStreamHandle DestStream, int8_t ReleaseDestStream, TElZlibDecompressingStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELZLIBDECOMPRESSINGSTREAM */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElCustomCompressingStream_ce_ptr;
extern zend_class_entry *TElCustomDecompressingStream_ce_ptr;
extern zend_class_entry *TElZlibCompressingStream_ce_ptr;
extern zend_class_entry *TElZlibDecompressingStream_ce_ptr;

void Register_TElCustomCompressingStream(TSRMLS_D);
void Register_TElCustomDecompressingStream(TSRMLS_D);
void Register_TElZlibCompressingStream(TSRMLS_D);
void Register_TElZlibDecompressingStream(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCOMPRSTREAM */

