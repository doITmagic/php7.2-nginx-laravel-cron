#ifndef __INC_SBCOOKIEMGR
#define __INC_SBCOOKIEMGR

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstringlist.h"
#include "sbxmlcore.h"
#include "sbsharedresource.h"
#include "sbhttpsconstants.h"
#include "sbhttpscommon.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbencoding.h"
#include "sbstreams.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_cpComment 	1
#define SB_cpCommentURL 	2
#define SB_cpExpires 	4
#define SB_cpDiscard 	8
#define SB_cpDomain 	16
#define SB_cpPath 	32
#define SB_cpPort 	64
#define SB_cpSecure 	128
#define SB_cpVersion 	256
#define SB_cpHostOnly 	512
#define SB_cpHttpOnly 	1024
#define SB_cpFormat 	2048
#define SB_cfUndefined 	0
#define SB_cfNetscape 	1
#define SB_cfRFC2109 	2
#define SB_cfRFC2965 	3
#define SB_cfRFC6265 	4

typedef TElClassHandle TElCookieHandle;

typedef TElClassHandle TElCookieDomainHandle;

typedef TElClassHandle TElCookieManagerHandle;

typedef TElCookieManagerHandle ElCookieManagerHandle;

#ifdef SB_USE_CLASS_TELCOOKIE
SB_IMPORT uint32_t SB_APIENTRY TElCookie_Assign(TPersistentHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_AssembleClientCookie(TElCookieHandle _Handle, int32_t Format, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_ParseServerCookie(TElCookieHandle _Handle, const char * pcACookie, int32_t szACookie, int64_t ReceivedAt, int8_t * DiscardCookie);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_Included(TElCookieHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_Persistent(TElCookieHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_set_Persistent(TElCookieHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_Name(TElCookieHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_set_Name(TElCookieHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_Value(TElCookieHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_set_Value(TElCookieHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_Comment(TElCookieHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_set_Comment(TElCookieHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_CommentURL(TElCookieHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_set_CommentURL(TElCookieHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_Domain(TElCookieHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_set_Domain(TElCookieHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_Expires(TElCookieHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_set_Expires(TElCookieHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_Format(TElCookieHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_set_Format(TElCookieHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_HostOnly(TElCookieHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_set_HostOnly(TElCookieHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_HTTPOnly(TElCookieHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_set_HTTPOnly(TElCookieHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_Path(TElCookieHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_set_Path(TElCookieHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_Port(TElCookieHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_set_Port(TElCookieHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_Secure(TElCookieHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_set_Secure(TElCookieHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_get_Version(TElCookieHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_set_Version(TElCookieHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCookie_Create(TElCookieHandle * OutResult);
#endif /* SB_USE_CLASS_TELCOOKIE */

#ifdef SB_USE_CLASS_TELCOOKIEDOMAIN
SB_IMPORT uint32_t SB_APIENTRY TElCookieDomain_AddCookie(TElCookieDomainHandle _Handle, TElCookieHandle ACookie);
SB_IMPORT uint32_t SB_APIENTRY TElCookieDomain_Clear(TElCookieDomainHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCookieDomain_RemoveCookie(TElCookieDomainHandle _Handle, TElCookieHandle ACookie);
SB_IMPORT uint32_t SB_APIENTRY TElCookieDomain_DeleteCookie(TElCookieDomainHandle _Handle, int32_t index);
SB_IMPORT uint32_t SB_APIENTRY TElCookieDomain_FindSameCookie(TElCookieDomainHandle _Handle, TElCookieHandle Cookie, TElCookieHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookieDomain_get_Cookies(TElCookieDomainHandle _Handle, int32_t Index, TElCookieHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookieDomain_get_CookieCount(TElCookieDomainHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookieDomain_get_Domain(TElCookieDomainHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookieDomain_set_Domain(TElCookieDomainHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCookieDomain_Create(TElCookieDomainHandle * OutResult);
#endif /* SB_USE_CLASS_TELCOOKIEDOMAIN */

#ifdef SB_USE_CLASS_TELCOOKIEMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElCookieManager_Clear(TElCookieManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCookieManager_AddDomain(TElCookieManagerHandle _Handle, TElCookieDomainHandle Domain);
SB_IMPORT uint32_t SB_APIENTRY TElCookieManager_DeleteDomain(TElCookieManagerHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElCookieManager_RemoveDomain(TElCookieManagerHandle _Handle, TElCookieDomainHandle Domain);
SB_IMPORT uint32_t SB_APIENTRY TElCookieManager_LoadFromStream(TElCookieManagerHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElCookieManager_SaveToStream(TElCookieManagerHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElCookieManager_GetCookiesForURL(TElCookieManagerHandle _Handle, const char * pcURL, int32_t szURL, int8_t SecureSession, int32_t * Format, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookieManager_SetCookiesForURL(TElCookieManagerHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle CookieList, int64_t ReceivedAt, int32_t ForceFormat);
SB_IMPORT uint32_t SB_APIENTRY TElCookieManager_get_DomainCount(TElCookieManagerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookieManager_get_Domains(TElCookieManagerHandle _Handle, int32_t Index, TElCookieDomainHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCookieManager_Create(TComponentHandle AOwner, TElCookieManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELCOOKIEMANAGER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElCookie_ce_ptr;
extern zend_class_entry *TElCookieDomain_ce_ptr;
extern zend_class_entry *TElCookieManager_ce_ptr;

void Register_TElCookie(TSRMLS_D);
void Register_TElCookieDomain(TSRMLS_D);
void Register_TElCookieManager(TSRMLS_D);
void Register_SBCookieMgr_Constants(int module_number TSRMLS_DC);
void Register_SBCookieMgr_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCOOKIEMGR */

