#ifndef __INC_SBCRL
#define __INC_SBCRL

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstreams.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbencoding.h"
#include "sbx509.h"
#include "sbpem.h"
#include "sbx509ext.h"
#include "sbrdn.h"
#include "sbstrutils.h"
#include "sbsharedresource.h"
#include "sbcustomcrypto.h"
#include "sbpublickeycrypto.h"
#include "sbhashfunction.h"
#include "sbalgorithmidentifier.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_CRL_ERROR_INVALID_FORMAT 	8705
#define SB_CRL_ERROR_BAD_SIGNATURE_ALGORITHM 	8706
#define SB_CRL_ERROR_INVALID_ISSUER 	8707
#define SB_CRL_ERROR_INVALID_SIGNATURE 	8708
#define SB_CRL_ERROR_UNSUPPORTED_VERSION 	8709
#define SB_CRL_ERROR_UNSUPPORTED_ALGORITHM 	8710
#define SB_CRL_ERROR_INVALID_CERTIFICATE 	8711
#define SB_CRL_ERROR_ALREADY_EXISTS 	8712
#define SB_CRL_ERROR_NOT_FOUND 	8713
#define SB_CRL_ERROR_PRIVATE_KEY_NOT_FOUND 	8714
#define SB_CRL_ERROR_UNSUPPORTED_CERTIFICATE 	8715
#define SB_CRL_ERROR_INTERNAL_ERROR 	8716
#define SB_CRL_ERROR_BUFFER_TOO_SMALL 	8717
#define SB_CRL_ERROR_NOTHING_TO_VERIFY 	8718
#define SB_CRL_ERROR_NO_SIGNED_CRL_FOUND 	8719
#define SB_CRL_ERROR_ABSTRACT_ERROR 	8720

typedef TElCustomExtensionHandle TElCRLExtensionHandle;

typedef TElCustomExtensionHandle ElCRLExtensionHandle;

typedef TElClassHandle TElAuthorityKeyIdentifierCRLExtensionHandle;

typedef TElAuthorityKeyIdentifierCRLExtensionHandle ElAuthorityKeyIdentifierCRLExtensionHandle;

typedef TElClassHandle TElCRLNumberCRLExtensionHandle;

typedef TElCRLNumberCRLExtensionHandle ElCRLNumberCRLExtensionHandle;

typedef TElClassHandle TElDeltaCRLIndicatorCRLExtensionHandle;

typedef TElDeltaCRLIndicatorCRLExtensionHandle ElDeltaCRLIndicatorCRLExtensionHandle;

typedef TElClassHandle TElReasonCodeCRLExtensionHandle;

typedef TElReasonCodeCRLExtensionHandle ElReasonCodeCRLExtensionHandle;

typedef TElClassHandle TElHoldInstructionCodeCRLExtensionHandle;

typedef TElHoldInstructionCodeCRLExtensionHandle ElHoldInstructionCodeCRLExtensionHandle;

typedef TElClassHandle TElInvalidityDateCRLExtensionHandle;

typedef TElInvalidityDateCRLExtensionHandle ElInvalidityDateCRLExtensionHandle;

typedef TElClassHandle TElCertificateIssuerCRLExtensionHandle;

typedef TElCertificateIssuerCRLExtensionHandle ElCertificateIssuerCRLExtensionHandle;

typedef TElClassHandle TElIssuingDistributionPointCRLExtensionHandle;

typedef TElClassHandle TElCRLExtensionsHandle;

typedef TElCRLExtensionsHandle ElCRLExtensionsHandle;

typedef TElClassHandle TElCRLEntryExtensionsHandle;

typedef TElCRLEntryExtensionsHandle ElCRLEntryExtensionsHandle;

typedef TElClassHandle TElCertificateRevocationListHandle;

typedef TElClassHandle TElRevocationItemHandle;

typedef TElRevocationItemHandle ElRevocationItemHandle;

typedef TElClassHandle TElAbstractCRLHandle;

typedef TElClassHandle TElRawCRLHandle;

typedef TElClassHandle TElRevocationItemInfoHandle;

typedef TElAbstractCRLHandle ElAbstractCRLHandle;

typedef TElRawCRLHandle ElRawCRLHandle;

typedef TElCertificateRevocationListHandle ElCertificateRevocationListHandle;

typedef TElClassHandle TElCRLObjectFactoryHandle;

typedef uint8_t TSBCRLFileFormatRaw;

typedef enum
{
	crlfUnknown = 0,
	crlfDER = 1,
	crlfPEM = 2
} TSBCRLFileFormat;

typedef uint8_t TElInstructionCodeRaw;

typedef enum
{
	icNone = 0,
	icCallIssuer = 1,
	icReject = 2
} TElInstructionCode;

typedef uint8_t TSBCRLExtensionRaw;

typedef enum
{
	crlAuthorityKeyIdentifier = 0,
	crlIssuerAlternativeName = 1,
	crlCRLNumber = 2,
	crlDeltaCRLIndicator = 3,
	crlIssuingDistributionPoint = 4
} TSBCRLExtension;

typedef uint32_t TSBCRLExtensionsRaw;

typedef enum 
{
	f_crlAuthorityKeyIdentifier = 1,
	f_crlIssuerAlternativeName = 2,
	f_crlCRLNumber = 4,
	f_crlDeltaCRLIndicator = 8,
	f_crlIssuingDistributionPoint = 16
} TSBCRLExtensions;

typedef uint8_t TSBCRLEntryExtensionRaw;

typedef enum
{
	crlReasonCode = 0,
	crlHoldInstructionCode = 1,
	crlInvalidityDate = 2,
	crlCertificateIssuer = 3
} TSBCRLEntryExtension;

typedef uint32_t TSBCRLEntryExtensionsRaw;

typedef enum 
{
	f_crlReasonCode = 1,
	f_crlHoldInstructionCode = 2,
	f_crlInvalidityDate = 4,
	f_crlCertificateIssuer = 8
} TSBCRLEntryExtensions;

typedef uint8_t TSBCRLObjectFactoryModeRaw;

typedef enum
{
	cofmDefault = 0,
	cofmPreferRaw = 1,
	cofmPreferStandard = 2
} TSBCRLObjectFactoryMode;

#ifdef SB_USE_CLASS_TELAUTHORITYKEYIDENTIFIERCRLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElAuthorityKeyIdentifierCRLExtension_get_KeyIdentifier(TElAuthorityKeyIdentifierCRLExtensionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthorityKeyIdentifierCRLExtension_set_KeyIdentifier(TElAuthorityKeyIdentifierCRLExtensionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAuthorityKeyIdentifierCRLExtension_get_AuthorityCertIssuer(TElAuthorityKeyIdentifierCRLExtensionHandle _Handle, TElGeneralNamesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthorityKeyIdentifierCRLExtension_get_AuthorityCertSerial(TElAuthorityKeyIdentifierCRLExtensionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthorityKeyIdentifierCRLExtension_set_AuthorityCertSerial(TElAuthorityKeyIdentifierCRLExtensionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAuthorityKeyIdentifierCRLExtension_get_IssuerSet(TElAuthorityKeyIdentifierCRLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAuthorityKeyIdentifierCRLExtension_set_IssuerSet(TElAuthorityKeyIdentifierCRLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAuthorityKeyIdentifierCRLExtension_Create(TElAuthorityKeyIdentifierCRLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELAUTHORITYKEYIDENTIFIERCRLEXTENSION */

#ifdef SB_USE_CLASS_TELCRLNUMBERCRLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElCRLNumberCRLExtension_get_Number(TElCRLNumberCRLExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLNumberCRLExtension_set_Number(TElCRLNumberCRLExtensionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCRLNumberCRLExtension_get_BinaryNumber(TElCRLNumberCRLExtensionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLNumberCRLExtension_set_BinaryNumber(TElCRLNumberCRLExtensionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCRLNumberCRLExtension_Create(TElCustomExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELCRLNUMBERCRLEXTENSION */

#ifdef SB_USE_CLASS_TELDELTACRLINDICATORCRLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElDeltaCRLIndicatorCRLExtension_get_Number(TElDeltaCRLIndicatorCRLExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDeltaCRLIndicatorCRLExtension_set_Number(TElDeltaCRLIndicatorCRLExtensionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDeltaCRLIndicatorCRLExtension_get_BinaryNumber(TElDeltaCRLIndicatorCRLExtensionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDeltaCRLIndicatorCRLExtension_set_BinaryNumber(TElDeltaCRLIndicatorCRLExtensionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDeltaCRLIndicatorCRLExtension_Create(TElCustomExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELDELTACRLINDICATORCRLEXTENSION */

#ifdef SB_USE_CLASS_TELREASONCODECRLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElReasonCodeCRLExtension_get_Reason(TElReasonCodeCRLExtensionHandle _Handle, TSBCRLReasonFlagRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElReasonCodeCRLExtension_set_Reason(TElReasonCodeCRLExtensionHandle _Handle, TSBCRLReasonFlagRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElReasonCodeCRLExtension_get_RemoveFromCRL(TElReasonCodeCRLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElReasonCodeCRLExtension_set_RemoveFromCRL(TElReasonCodeCRLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElReasonCodeCRLExtension_Create(TElCustomExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELREASONCODECRLEXTENSION */

#ifdef SB_USE_CLASS_TELHOLDINSTRUCTIONCODECRLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElHoldInstructionCodeCRLExtension_get_Code(TElHoldInstructionCodeCRLExtensionHandle _Handle, TElInstructionCodeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHoldInstructionCodeCRLExtension_set_Code(TElHoldInstructionCodeCRLExtensionHandle _Handle, TElInstructionCodeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElHoldInstructionCodeCRLExtension_Create(TElCustomExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELHOLDINSTRUCTIONCODECRLEXTENSION */

#ifdef SB_USE_CLASS_TELINVALIDITYDATECRLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElInvalidityDateCRLExtension_get_InvalidityDate(TElInvalidityDateCRLExtensionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElInvalidityDateCRLExtension_set_InvalidityDate(TElInvalidityDateCRLExtensionHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElInvalidityDateCRLExtension_Create(TElCustomExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELINVALIDITYDATECRLEXTENSION */

#ifdef SB_USE_CLASS_TELCERTIFICATEISSUERCRLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElCertificateIssuerCRLExtension_get_Issuer(TElCertificateIssuerCRLExtensionHandle _Handle, TElGeneralNamesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateIssuerCRLExtension_Create(TElCertificateIssuerCRLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELCERTIFICATEISSUERCRLEXTENSION */

#ifdef SB_USE_CLASS_TELISSUINGDISTRIBUTIONPOINTCRLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElIssuingDistributionPointCRLExtension_get_DistributionPoint(TElIssuingDistributionPointCRLExtensionHandle _Handle, TElGeneralNamesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIssuingDistributionPointCRLExtension_get_OnlySomeReasons(TElIssuingDistributionPointCRLExtensionHandle _Handle, TSBCRLReasonFlagsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIssuingDistributionPointCRLExtension_set_OnlySomeReasons(TElIssuingDistributionPointCRLExtensionHandle _Handle, TSBCRLReasonFlagsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElIssuingDistributionPointCRLExtension_get_OnlyContainsUserCerts(TElIssuingDistributionPointCRLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIssuingDistributionPointCRLExtension_set_OnlyContainsUserCerts(TElIssuingDistributionPointCRLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIssuingDistributionPointCRLExtension_get_OnlyContainsCACerts(TElIssuingDistributionPointCRLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIssuingDistributionPointCRLExtension_set_OnlyContainsCACerts(TElIssuingDistributionPointCRLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIssuingDistributionPointCRLExtension_get_OnlyContainsAttributeCerts(TElIssuingDistributionPointCRLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIssuingDistributionPointCRLExtension_set_OnlyContainsAttributeCerts(TElIssuingDistributionPointCRLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIssuingDistributionPointCRLExtension_get_IndirectCRL(TElIssuingDistributionPointCRLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIssuingDistributionPointCRLExtension_set_IndirectCRL(TElIssuingDistributionPointCRLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIssuingDistributionPointCRLExtension_get_ReasonFlagsIncluded(TElIssuingDistributionPointCRLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIssuingDistributionPointCRLExtension_set_ReasonFlagsIncluded(TElIssuingDistributionPointCRLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIssuingDistributionPointCRLExtension_Create(TElIssuingDistributionPointCRLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELISSUINGDISTRIBUTIONPOINTCRLEXTENSION */

#ifdef SB_USE_CLASS_TELCRLEXTENSIONS
SB_IMPORT uint32_t SB_APIENTRY TElCRLExtensions_Assign(TElCRLExtensionsHandle _Handle, TElCRLExtensionsHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElCRLExtensions_get_AuthorityKeyIdentifier(TElCRLExtensionsHandle _Handle, TElAuthorityKeyIdentifierCRLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLExtensions_get_IssuerAlternativeName(TElCRLExtensionsHandle _Handle, TElAlternativeNameExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLExtensions_get_CRLNumber(TElCRLExtensionsHandle _Handle, TElCRLNumberCRLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLExtensions_get_DeltaCRLIndicator(TElCRLExtensionsHandle _Handle, TElDeltaCRLIndicatorCRLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLExtensions_get_IssuingDistributionPoint(TElCRLExtensionsHandle _Handle, TElIssuingDistributionPointCRLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLExtensions_get_OtherExtensions(TElCRLExtensionsHandle _Handle, int32_t Index, TElCustomExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLExtensions_get_OtherCount(TElCRLExtensionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLExtensions_set_OtherCount(TElCRLExtensionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCRLExtensions_get_Included(TElCRLExtensionsHandle _Handle, TSBCRLExtensionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLExtensions_set_Included(TElCRLExtensionsHandle _Handle, TSBCRLExtensionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCRLExtensions_get_SaveDefaultASN1Tags(TElCRLExtensionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLExtensions_set_SaveDefaultASN1Tags(TElCRLExtensionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCRLExtensions_Create(TElCRLExtensionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELCRLEXTENSIONS */

#ifdef SB_USE_CLASS_TELCRLENTRYEXTENSIONS
SB_IMPORT uint32_t SB_APIENTRY TElCRLEntryExtensions_Assign(TElCRLEntryExtensionsHandle _Handle, TElCRLEntryExtensionsHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElCRLEntryExtensions_get_ReasonCode(TElCRLEntryExtensionsHandle _Handle, TElReasonCodeCRLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLEntryExtensions_get_HoldInstructionCode(TElCRLEntryExtensionsHandle _Handle, TElHoldInstructionCodeCRLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLEntryExtensions_get_InvalidityDate(TElCRLEntryExtensionsHandle _Handle, TElInvalidityDateCRLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLEntryExtensions_get_CertificateIssuer(TElCRLEntryExtensionsHandle _Handle, TElCertificateIssuerCRLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLEntryExtensions_get_OtherExtensions(TElCRLEntryExtensionsHandle _Handle, int32_t Index, TElCustomExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLEntryExtensions_get_OtherCount(TElCRLEntryExtensionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLEntryExtensions_set_OtherCount(TElCRLEntryExtensionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCRLEntryExtensions_get_Included(TElCRLEntryExtensionsHandle _Handle, TSBCRLEntryExtensionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLEntryExtensions_set_Included(TElCRLEntryExtensionsHandle _Handle, TSBCRLEntryExtensionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCRLEntryExtensions_get_SaveDefaultASN1Tags(TElCRLEntryExtensionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLEntryExtensions_set_SaveDefaultASN1Tags(TElCRLEntryExtensionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCRLEntryExtensions_Create(TElCRLEntryExtensionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELCRLENTRYEXTENSIONS */

#ifdef SB_USE_CLASS_TELABSTRACTCRL
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_Assign(TElAbstractCRLHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_Clone(TElAbstractCRLHandle _Handle, TElAbstractCRLHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_LoadFromBuffer(TElAbstractCRLHandle _Handle, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_LoadFromBufferPEM(TElAbstractCRLHandle _Handle, void * Buffer, int32_t Size, const char * pcPassphrase, int32_t szPassphrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_SaveToBuffer(TElAbstractCRLHandle _Handle, void * Buffer, int32_t * Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_SaveToBufferPEM(TElAbstractCRLHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassphrase, int32_t szPassphrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_LoadFromStream(TElAbstractCRLHandle _Handle, TStreamHandle Stream, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_LoadFromStreamPEM(TElAbstractCRLHandle _Handle, TStreamHandle Stream, const char * pcPassphrase, int32_t szPassphrase, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_Validate(TElAbstractCRLHandle _Handle, TElX509CertificateHandle Certificate, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_SameCRL(TElAbstractCRLHandle _Handle, TElAbstractCRLHandle CRL, int8_t CheckUpdateTime, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_GetCRLHash(TElAbstractCRLHandle _Handle, int32_t Alg, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_Equals(TElAbstractCRLHandle _Handle, TElAbstractCRLHandle CRL, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_IsPresent(TElAbstractCRLHandle _Handle, TElX509CertificateHandle Certificate, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_GetCertItem(TElAbstractCRLHandle _Handle, TElX509CertificateHandle Certificate, TElRevocationItemHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_get_CRLBinary(TElAbstractCRLHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_get_CRLSize(TElAbstractCRLHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_get_Extensions(TElAbstractCRLHandle _Handle, TElCRLExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_get_Issuer(TElAbstractCRLHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_get_Location(TElAbstractCRLHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_set_Location(TElAbstractCRLHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_get_NextUpdate(TElAbstractCRLHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_set_NextUpdate(TElAbstractCRLHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_get_Signature(TElAbstractCRLHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_get_SignatureAlgorithm(TElAbstractCRLHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_get_SignatureAlgorithmIdentifier(TElAbstractCRLHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_get_TBS(TElAbstractCRLHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_get_ThisUpdate(TElAbstractCRLHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_set_ThisUpdate(TElAbstractCRLHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElAbstractCRL_Create(TComponentHandle Owner, TElAbstractCRLHandle * OutResult);
#endif /* SB_USE_CLASS_TELABSTRACTCRL */

#ifdef SB_USE_CLASS_TELREVOCATIONITEM
SB_IMPORT uint32_t SB_APIENTRY TElRevocationItem_Assign(TElRevocationItemHandle _Handle, TElRevocationItemHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationItem_LoadFromBuffer(TElRevocationItemHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationItem_get_SerialNumber(TElRevocationItemHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationItem_set_SerialNumber(TElRevocationItemHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationItem_get_RevocationDate(TElRevocationItemHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationItem_set_RevocationDate(TElRevocationItemHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationItem_get_Extensions(TElRevocationItemHandle _Handle, TElCRLEntryExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRevocationItem_Create(TElAbstractCRLHandle Owner, TElRevocationItemHandle * OutResult);
#endif /* SB_USE_CLASS_TELREVOCATIONITEM */

#ifdef SB_USE_CLASS_TELCERTIFICATEREVOCATIONLIST
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_DetectCRLFileFormat(const char * pcFileName, int32_t szFileName, TSBCRLFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_DetectCRLFileFormat_1(TElCertificateRevocationListHandle _Handle, const char * pcFileName, int32_t szFileName, TSBCRLFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_DetectCRLFileFormat_2(TStreamHandle Stream, TSBCRLFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_DetectCRLFileFormat_3(TElCertificateRevocationListHandle _Handle, TStreamHandle Stream, TSBCRLFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_DetectCRLFileFormat_4(void * Buffer, int32_t Size, TSBCRLFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_DetectCRLFileFormat_5(TElCertificateRevocationListHandle _Handle, void * Buffer, int32_t Size, TSBCRLFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_Add(TElCertificateRevocationListHandle _Handle, TElX509CertificateHandle Certificate, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_Add_1(TElCertificateRevocationListHandle _Handle, const uint8_t pSerialNumber[], int32_t szSerialNumber, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_Assign(TElCertificateRevocationListHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_Clone(TElCertificateRevocationListHandle _Handle, TElAbstractCRLHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_Remove(TElCertificateRevocationListHandle _Handle, TElX509CertificateHandle Certificate, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_Remove_1(TElCertificateRevocationListHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_IsPresent(TElCertificateRevocationListHandle _Handle, TElX509CertificateHandle Certificate, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_GetCertItem(TElCertificateRevocationListHandle _Handle, TElX509CertificateHandle Certificate, TElRevocationItemHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_IndexOf(TElCertificateRevocationListHandle _Handle, TElX509CertificateHandle Certificate, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_Clear(TElCertificateRevocationListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_LoadFromBuffer(TElCertificateRevocationListHandle _Handle, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_LoadFromStream(TElCertificateRevocationListHandle _Handle, TStreamHandle Stream, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_get_Items(TElCertificateRevocationListHandle _Handle, int32_t Index, TElRevocationItemHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_get_SerialNumbers(TElCertificateRevocationListHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_get_RevocationDates(TElCertificateRevocationListHandle _Handle, int32_t Index, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_get_Count(TElCertificateRevocationListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_get_UseDelayedLoad(TElCertificateRevocationListHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_set_UseDelayedLoad(TElCertificateRevocationListHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_get_UseLegacyLoadMode(TElCertificateRevocationListHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_set_UseLegacyLoadMode(TElCertificateRevocationListHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationList_Create(TComponentHandle Owner, TElCertificateRevocationListHandle * OutResult);
#endif /* SB_USE_CLASS_TELCERTIFICATEREVOCATIONLIST */

#ifdef SB_USE_CLASS_TELRAWCRL
SB_IMPORT uint32_t SB_APIENTRY TElRawCRL_Assign(TElRawCRLHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElRawCRL_Clone(TElRawCRLHandle _Handle, TElAbstractCRLHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRawCRL_IsPresent(TElRawCRLHandle _Handle, TElX509CertificateHandle Certificate, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRawCRL_GetCertItem(TElRawCRLHandle _Handle, TElX509CertificateHandle Certificate, TElRevocationItemHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRawCRL_Create(TComponentHandle Owner, TElRawCRLHandle * OutResult);
#endif /* SB_USE_CLASS_TELRAWCRL */

#ifdef SB_USE_CLASS_TELREVOCATIONITEMINFO
SB_IMPORT uint32_t SB_APIENTRY TElRevocationItemInfo_Create(TElRevocationItemInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELREVOCATIONITEMINFO */

#ifdef SB_USE_CLASS_TELCRLOBJECTFACTORY
SB_IMPORT uint32_t SB_APIENTRY TElCRLObjectFactory_CreateDefaultCRLObject(TElCRLObjectFactoryHandle _Handle, TElAbstractCRLHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLObjectFactory_CreateRawCRLObject(TElCRLObjectFactoryHandle _Handle, TElRawCRLHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLObjectFactory_CreateStandardCRLObject(TElCRLObjectFactoryHandle _Handle, TElCertificateRevocationListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLObjectFactory_get_Mode(TElCRLObjectFactoryHandle _Handle, TSBCRLObjectFactoryModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCRLObjectFactory_set_Mode(TElCRLObjectFactoryHandle _Handle, TSBCRLObjectFactoryModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCRLObjectFactory_Create(TElCRLObjectFactoryHandle * OutResult);
#endif /* SB_USE_CLASS_TELCRLOBJECTFACTORY */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElAuthorityKeyIdentifierCRLExtension_ce_ptr;
extern zend_class_entry *TElCRLNumberCRLExtension_ce_ptr;
extern zend_class_entry *TElDeltaCRLIndicatorCRLExtension_ce_ptr;
extern zend_class_entry *TElReasonCodeCRLExtension_ce_ptr;
extern zend_class_entry *TElHoldInstructionCodeCRLExtension_ce_ptr;
extern zend_class_entry *TElInvalidityDateCRLExtension_ce_ptr;
extern zend_class_entry *TElCertificateIssuerCRLExtension_ce_ptr;
extern zend_class_entry *TElIssuingDistributionPointCRLExtension_ce_ptr;
extern zend_class_entry *TElCRLExtensions_ce_ptr;
extern zend_class_entry *TElCRLEntryExtensions_ce_ptr;
extern zend_class_entry *TElAbstractCRL_ce_ptr;
extern zend_class_entry *TElRevocationItem_ce_ptr;
extern zend_class_entry *TElCertificateRevocationList_ce_ptr;
extern zend_class_entry *TElRawCRL_ce_ptr;
extern zend_class_entry *TElRevocationItemInfo_ce_ptr;
extern zend_class_entry *TElCRLObjectFactory_ce_ptr;

void Register_TElAuthorityKeyIdentifierCRLExtension(TSRMLS_D);
void Register_TElCRLNumberCRLExtension(TSRMLS_D);
void Register_TElDeltaCRLIndicatorCRLExtension(TSRMLS_D);
void Register_TElReasonCodeCRLExtension(TSRMLS_D);
void Register_TElHoldInstructionCodeCRLExtension(TSRMLS_D);
void Register_TElInvalidityDateCRLExtension(TSRMLS_D);
void Register_TElCertificateIssuerCRLExtension(TSRMLS_D);
void Register_TElIssuingDistributionPointCRLExtension(TSRMLS_D);
void Register_TElCRLExtensions(TSRMLS_D);
void Register_TElCRLEntryExtensions(TSRMLS_D);
void Register_TElAbstractCRL(TSRMLS_D);
void Register_TElRevocationItem(TSRMLS_D);
void Register_TElCertificateRevocationList(TSRMLS_D);
void Register_TElRawCRL(TSRMLS_D);
void Register_TElRevocationItemInfo(TSRMLS_D);
void Register_TElCRLObjectFactory(TSRMLS_D);
SB_PHP_FUNCTION(SBCRL, CRLObjectFactory);
void Register_SBCRL_Constants(int module_number TSRMLS_DC);
void Register_SBCRL_Enum_Flags(TSRMLS_D);
void Register_SBCRL_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_CRL
SB_IMPORT uint32_t SB_APIENTRY SBCRL_CRLObjectFactory(TElCRLObjectFactoryHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_CRL */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCRL */

