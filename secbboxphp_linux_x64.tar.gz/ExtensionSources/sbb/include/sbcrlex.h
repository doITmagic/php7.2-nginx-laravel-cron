#ifndef __INC_SBCRLEX
#define __INC_SBCRLEX

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcrl.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbalgorithmidentifier.h"
#include "sbcustomcrypto.h"
#include "sbpublickeycrypto.h"
#include "sbpem.h"
#include "sbx509.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElCertificateRevocationListExHandle;

#ifdef SB_USE_CLASS_TELCERTIFICATEREVOCATIONLISTEX
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationListEx_SaveToBuffer(TElCertificateRevocationListExHandle _Handle, void * Buffer, int32_t * Size, TElX509CertificateHandle Certificate, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationListEx_SaveToBuffer_1(TElAbstractCRLHandle _Handle, void * Buffer, int32_t * Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationListEx_SaveToBufferPEM(TElCertificateRevocationListExHandle _Handle, void * Buffer, int32_t * Size, TElX509CertificateHandle Certificate, const char * pcPassphrase, int32_t szPassphrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationListEx_SaveToBufferPEM_1(TElCertificateRevocationListExHandle _Handle, uint8_t pBuffer[], int32_t * szBuffer, TElX509CertificateHandle Certificate, const char * pcPassphrase, int32_t szPassphrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationListEx_SaveToBufferPEM_2(TElAbstractCRLHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassphrase, int32_t szPassphrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationListEx_SaveToStream(TElCertificateRevocationListExHandle _Handle, TStreamHandle Stream, TElX509CertificateHandle Certificate, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationListEx_SaveToStreamPEM(TElCertificateRevocationListExHandle _Handle, TStreamHandle Stream, TElX509CertificateHandle Certificate, const char * pcPassphrase, int32_t szPassphrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationListEx_get_PreferredHashAlgorithm(TElCertificateRevocationListExHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationListEx_set_PreferredHashAlgorithm(TElCertificateRevocationListExHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRevocationListEx_Create(TComponentHandle Owner, TElCertificateRevocationListExHandle * OutResult);
#endif /* SB_USE_CLASS_TELCERTIFICATEREVOCATIONLISTEX */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElCertificateRevocationListEx_ce_ptr;

void Register_TElCertificateRevocationListEx(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCRLEX */

