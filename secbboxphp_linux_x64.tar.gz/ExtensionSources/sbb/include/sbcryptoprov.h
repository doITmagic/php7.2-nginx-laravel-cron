#ifndef __INC_SBCRYPTOPROV
#define __INC_SBCRYPTOPROV

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbrdn.h"
#include "sbasn1.h"
#include "sbmath.h"
#include "sbsharedresource.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbstrutils.h"
#include "sbstringlist.h"
#include "sbconstants.h"
#include "sbasn1tree.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ALGCLASS_NONE 	0
#define SB_ALGCLASS_BLOCK 	1
#define SB_ALGCLASS_STREAM 	2
#define SB_ALGCLASS_PUBLICKEY 	3
#define SB_ALGCLASS_HASH 	4
#define SB_SYMENC_MODE_DEFAULT 	0
#define SB_SYMENC_MODE_BLOCK 	1
#define SB_SYMENC_MODE_CBC 	2
#define SB_SYMENC_MODE_CFB8 	3
#define SB_SYMENC_MODE_CTR 	4
#define SB_SYMENC_MODE_ECB 	5
#define SB_SYMENC_MODE_CCM 	6
#define SB_SYMENC_MODE_GCM 	7
#define SB_SYMENC_MODE_AEADCHACHA20POLY1305 	8
#define SB_SYMENC_PADDING_NONE 	0
#define SB_SYMENC_PADDING_PKCS5 	1
#define SB_SYMENC_PADDING_ANSIX923 	2
#define SB_VR_SUCCESS 	0
#define SB_VR_INVALID_SIGNATURE 	1
#define SB_VR_KEY_NOT_FOUND 	2
#define SB_VR_FAILURE 	3
#define SB_OPTYPE_NONE 	0
#define SB_OPTYPE_ENCRYPT 	1
#define SB_OPTYPE_DECRYPT 	2
#define SB_OPTYPE_SIGN 	3
#define SB_OPTYPE_SIGN_DETACHED 	4
#define SB_OPTYPE_VERIFY 	5
#define SB_OPTYPE_VERIFY_DETACHED 	6
#define SB_OPTYPE_HASH 	7
#define SB_OPTYPE_KEY_GENERATE 	8
#define SB_OPTYPE_KEY_DECRYPT 	9
#define SB_OPTYPE_RANDOM 	10
#define SB_OPTYPE_KEY_CREATE 	11
#define SB_OPTYPE_KEYCONTAINER_CREATE 	12
#define SB_ERROR_FACILITY_CRYPTOPROV 	86016
#define SB_ERROR_CRYPTOPROV_ERROR_FLAG 	2048
#define SB_ERROR_CP_NOT_INITIALIZED 	88065
#define SB_ERROR_CP_FEATURE_NOT_SUPPORTED 	88066
#define SB_ERROR_CP_OPERATION_NOT_SUPPORTED 	88067
#define SB_ERROR_CP_METHOD_NOT_IMPLEMENTED 	88068
#define SB_ERROR_CP_INVALID_KEY_PROP 	88069
#define SB_ERROR_CP_INVALID_KEY_MATERIAL 	88070
#define SB_ERROR_CP_INVALID_KEY_SIZE 	88071
#define SB_ERROR_CP_INVALID_IV_SIZE 	88072
#define SB_ERROR_CP_INVALID_ALG 	88073
#define SB_ERROR_CP_INVALID_CONTEXT 	88074
#define SB_ERROR_CP_INVALID_CRYPTOPROV 	88075
#define SB_ERROR_CP_INVALID_MODE 	88076
#define SB_ERROR_CP_INVALID_PROP_VALUE 	88077
#define SB_ERROR_CP_INVALID_PADDING 	88078
#define SB_ERROR_CP_INVALID_OPERATION 	88079
#define SB_ERROR_CP_BUFFER_TOO_SMALL 	88080
#define SB_ERROR_CP_UNSUPPORTED_ALGORITHM 	88081
#define SB_ERROR_CP_UNSUPPORTED_PROPERTY 	88082
#define SB_ERROR_CP_UNSUPPORTED_PROP_VALUE 	88083
#define SB_ERROR_CP_UNSUPPORTED_PROVIDER 	88084
#define SB_ERROR_CP_UNSUPPORTED_KEY_FORMAT 	88085
#define SB_ERROR_CP_INSTANTIATION_FAILED 	88086
#define SB_ERROR_CP_CANT_UNREG_DEFAULT 	88087
#define SB_ERROR_CP_NO_SUITABLE_PROV 	88088
#define SB_ERROR_CP_CANT_CHANGE_ALG 	88089
#define SB_ERROR_CP_UNKNOWN_ALG_PROP 	88090
#define SB_ERROR_CP_CANT_CHANGE_RO_PROP 	88091
#define SB_ERROR_CP_WRONG_CONTEXT_TYPE 	88092
#define SB_ERROR_CP_CANT_CLONE_CONTEXT 	88093
#define SB_ERROR_CP_PRIMITIVE_OP_FAILED 	88094
#define SB_ERROR_CP_KEY_GENERATION_FAILED 	88095
#define SB_ERROR_CP_KEY_ALREADY_PREPARED 	88096
#define SB_ERROR_CP_KEY_NOT_PREPARED 	88097
#define SB_ERROR_CP_KEY_NOT_FOUND 	88098
#define SB_ERROR_CP_IV_NOT_FOUND 	88099
#define SB_ERROR_CP_WRONG_INPUT_SIZE 	88100
#define SB_ERROR_CP_INTERRUPTED_BY_USER 	88101
#define SB_ERROR_CP_WRONG_OBJECT_TYPE 	88102
#define SB_ERROR_CP_WRONG_KEY_TYPE 	88103
#define SB_ERROR_CP_NO_SESSION 	88104
#define SB_ERROR_CP_NO_MODULE 	88105
#define SB_ERROR_CP_NO_DRIVER 	88106
#define SB_ERROR_CP_KEY_NOT_EXPORTABLE 	88107
#define SB_ERROR_CP_OBJECT_ACQUIRED 	88108
#define SB_ERROR_CP_OBJECT_PERSISTENT 	88109
#define SB_ERROR_CP_BAD_DATA_FORMAT 	88110
#define SB_ERROR_CP_DATA_TOO_LARGE 	88111
#define SB_ERROR_CP_DECRYPTION_FAILED 	88112
#define SB_ERROR_CP_SIGNING_FAILED 	88113
#define SB_ERROR_CP_CONTAINER_NOT_FOUND 	88114
#define SB_ERROR_CP_UNSUPPORTED_CONTAINER_ACCESS_MODE 	88115
#define SB_ERROR_CP_CONTAINER_NOT_OPENED 	88116
#define SB_ERROR_CP_NO_KEY_WITH_HANDLE 	88117
#define SB_ERROR_CP_KEY_NOT_FROM_CONTAINER 	88118
#define SB_ERROR_CP_NO_OBJECT_WITH_HANDLE 	88119
#define SB_ERROR_CP_OBJECT_NOT_PREPARED 	88120
#define SB_ERROR_CP_OBJECT_NOT_FROM_CONTAINER 	88121
#define SB_ERROR_CP_CANNOT_CLONE_CONTAINER 	88122
#define SB_ERROR_CP_UNSUPPORTED_OBJECT_TYPE 	88123
#define SB_ERROR_CP_CANNOT_CHANGE_OBJECT 	88124
#define SB_ERROR_CP_UNSUPPORTED_CONTAINER_FORMAT 	88125
#define SB_ERROR_CP_UNSUPPORTED_PROTECTION 	88126
#define SB_ERROR_CP_UNSUPPORTED_ELEMENT_FORMAT 	88127
#define SB_ERROR_CP_PROTECTION_INFO_NOT_AVAILABLE 	88128
#define SB_ERROR_CP_PROTECTION_LOCKED 	88129
#define SB_ERROR_CP_ELEMENT_UNPROTECTION_FAILED 	88130
#define SB_ERROR_CP_NO_PASSWORD 	88131
#define SB_ERROR_CP_ELEMENT_ALREADY_PROTECTED 	88132
#define SB_ERROR_CP_INTERNAL_ERROR 	88133
#define SB_ERROR_CP_ELEMENT_PROTECTION_FAILED 	88134
#define SB_ERROR_CP_PROTECTION_NOT_LOCKED 	88135
#define SB_ERROR_CP_ELEMENT_PROTECTED 	88136
#define SB_ERROR_CP_ELEMENT_CHANGED 	88137
#define SB_ERROR_CP_UNSUPPORTED_S2K 	88138
#define SB_ERROR_CP_INVALID_PASSWORD 	88139
#define SB_ERROR_CP_NO_FILESYSTEM_ADAPTER 	88140
#define SB_ERROR_CP_CONTAINER_FILE_ALREADY_EXISTS 	88141
#define SB_ERROR_CP_CANT_CREATE_CONTAINER_FILE 	88142
#define SB_ERROR_CP_CANT_ACCESS_CONTAINER_FILE 	88143
#define SB_ERROR_CP_OBJECT_PROTECTED 	88144
#define SB_ERROR_CP_PROTECTION_CANT_BE_CHANGED 	88145
#define SB_ERROR_CP_UNSUPPORTED_KEY_TYPE 	88146
#define SB_ERROR_CP_OBJECT_REFERENCES_EXIST 	88147
#define SB_ERROR_CP_CONTAINER_READONLY 	88148
#define SB_ERROR_CP_CONTAINER_PERSISTENT 	88149
#define SB_ERROR_CP_BAD_PARAMETER 	88150
#define SB_ERROR_CP_ELEVATION_NEEDED 	88165
#define SB_ERROR_CP_BACKEND_ERROR 	88265
#define SB_ERROR_CP_CONTEXT_NOT_ACQUIRED 	88266
#define SB_CRYPTOPROV_GENERAL_ERROR 	1

typedef TElRelativeDistinguishedNameHandle TElCPParametersHandle;

typedef TElClassHandle TElCustomCryptoProviderHandle;

typedef TElClassHandle TElCustomCryptoProviderManagerHandle;

typedef TElClassHandle TElCustomCryptoKeyContainerHandle;

typedef TElClassHandle TElCustomCryptoKeyHandle;

typedef TElClassHandle TElCustomCryptoObjectHandle;

typedef TElClassHandle TElCustomCryptoContextHandle;

typedef TElClassHandle TElCustomCryptoProviderOptionsHandle;

typedef TElClassHandle TElBlackboxCryptoProviderHandle;

typedef TElClassHandle TElExternalCryptoProviderHandle;

typedef Pointer TElCPKeyHandle;

typedef uint8_t TSBKeyContainerAccessModeRaw;

typedef enum
{
	kcamDefault = 0,
	kcamTransactional = 1,
	kcamInstant = 2
} TSBKeyContainerAccessMode;

typedef void (SB_CALLBACK *TSBCryptoProviderObjectEvent)(void * _ObjectData, TObjectHandle Sender, TObjectHandle Obj);

typedef TElClassHandle TElCustomCryptoProviderClassHandle;

#ifdef SB_USE_CLASS_TELCUSTOMCRYPTOPROVIDER
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Init(TElCustomCryptoProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Deinit(TElCustomCryptoProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_SetAsDefault();
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_SetAsDefault_1(TElCustomCryptoProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_GetDefaultInstance(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Clone(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_IsAlgorithmSupported(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_IsAlgorithmSupported_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_IsOperationSupported(TElCustomCryptoProviderHandle _Handle, int32_t Operation, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_IsOperationSupported_1(TElCustomCryptoProviderHandle _Handle, int32_t Operation, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_GetAlgorithmProperty(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, const uint8_t pPropID[], int32_t szPropID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_GetAlgorithmProperty_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, const uint8_t pPropID[], int32_t szPropID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_GetAlgorithmClass(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_GetAlgorithmClass_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_GetProviderProp(TElCustomCryptoProviderHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_SetProviderProp(TElCustomCryptoProviderHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_CreateKey(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_CreateKey_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_CloneKey(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoKeyHandle Key, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_ReleaseKey(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoKeyHandle * Key);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_DeleteKey(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoKeyHandle * Key);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_DecryptKey(TElCustomCryptoProviderHandle _Handle, void * EncKey, int32_t EncKeySize, const uint8_t pEncKeyAlgOID[], int32_t szEncKeyAlgOID, const uint8_t pEncKeyAlgParams[], int32_t szEncKeyAlgParams, TElCustomCryptoKeyHandle Key, const uint8_t pKeyAlgOID[], int32_t szKeyAlgOID, const uint8_t pKeyAlgParams[], int32_t szKeyAlgParams, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_CreateObject(TElCustomCryptoProviderHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_CloneObject(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoObjectHandle Obj, TElCustomCryptoObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_ReleaseObject(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_DeleteObject(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_CreateKeyContainer(TElCustomCryptoProviderHandle _Handle, int8_t Persistent, const char * pcID, int32_t szID, TSBKeyContainerAccessModeRaw AccessMode, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_OpenKeyContainer(TElCustomCryptoProviderHandle _Handle, const char * pcID, int32_t szID, TSBKeyContainerAccessModeRaw AccessMode, int8_t ReadOnly, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_ReleaseKeyContainer(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoKeyContainerHandle * KeyContainer);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_DeleteKeyContainer(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoKeyContainerHandle * KeyContainer);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_ListKeyContainers(TElCustomCryptoProviderHandle _Handle, TElStringListHandle IDList, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_ListKeyContainers_1(TElCustomCryptoProviderHandle _Handle, TElStringListHandle IDList, int32_t StartIndex, int32_t MaxCount, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_EncryptInit(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_EncryptInit_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_DecryptInit(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_DecryptInit_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_SignInit(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, int8_t Detached, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_SignInit_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, int8_t Detached, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_VerifyInit(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, void * SigBuffer, int32_t SigSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_VerifyInit_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, void * SigBuffer, int32_t SigSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_EncryptUpdate(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_DecryptUpdate(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_SignUpdate(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_VerifyUpdate(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_EncryptFinal(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_DecryptFinal(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_SignFinal(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_VerifyFinal(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Encrypt(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Encrypt_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Decrypt(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Decrypt_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Sign(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, int8_t Detached, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Sign_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, int8_t Detached, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Verify(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Verify_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_VerifyDetached(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, void * InBuffer, int32_t InSize, void * SigBuffer, int32_t SigSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_VerifyDetached_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, void * InBuffer, int32_t InSize, void * SigBuffer, int32_t SigSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_HashInit(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_HashInit_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_HashFinal(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_HashUpdate(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Hash(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Hash_1(TElCustomCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_ReleaseCryptoContext(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoContextHandle * Context);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_RandomInit(TElCustomCryptoProviderHandle _Handle, void * BaseData, int32_t BaseDataSize, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_RandomSeed(TElCustomCryptoProviderHandle _Handle, void * Data, int32_t DataSize);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_RandomGenerate(TElCustomCryptoProviderHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_RandomGenerate_1(TElCustomCryptoProviderHandle _Handle, int32_t MaxValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_OwnsObject(TElCustomCryptoProviderHandle _Handle, TObjectHandle Obj, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_get_Options(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoProviderOptionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_get_Enabled(TElCustomCryptoProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_set_Enabled(TElCustomCryptoProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_get_CryptoProviderManager(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_set_CryptoProviderManager(TElCustomCryptoProviderHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_get_OnCreateObject(TElCustomCryptoProviderHandle _Handle, TSBCryptoProviderObjectEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_set_OnCreateObject(TElCustomCryptoProviderHandle _Handle, TSBCryptoProviderObjectEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_get_OnDestroyObject(TElCustomCryptoProviderHandle _Handle, TSBCryptoProviderObjectEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_set_OnDestroyObject(TElCustomCryptoProviderHandle _Handle, TSBCryptoProviderObjectEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Create(TComponentHandle AOwner, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProvider_Create_1(TElCustomCryptoProviderOptionsHandle Options, TComponentHandle AOwner, TElCustomCryptoProviderHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMCRYPTOPROVIDER */

#ifdef SB_USE_CLASS_TELCUSTOMCRYPTOPROVIDERMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_Init(TElCustomCryptoProviderManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_Deinit(TElCustomCryptoProviderManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_RegisterCryptoProvider(TElCustomCryptoProviderManagerHandle _Handle, TElCustomCryptoProviderHandle Prov, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_UnregisterCryptoProvider(TElCustomCryptoProviderManagerHandle _Handle, TElCustomCryptoProviderHandle Prov);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_UnregisterCryptoProvider_1(TElCustomCryptoProviderManagerHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_SetDefaultCryptoProvider(TElCustomCryptoProviderManagerHandle _Handle, TElCustomCryptoProviderHandle Prov);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_SetDefaultCryptoProvider_1(TElCustomCryptoProviderManagerHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_SetDefaultCryptoProviderType(TElCustomCryptoProviderManagerHandle _Handle, TElCustomCryptoProviderClassHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_GetSuitableProvider(TElCustomCryptoProviderManagerHandle _Handle, int32_t Operation, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_GetSuitableProvider_1(TElCustomCryptoProviderManagerHandle _Handle, int32_t Operation, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_GetSuitableProvider_2(TElCustomCryptoProviderManagerHandle _Handle, int32_t Algorithm, int32_t Mode, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_GetSuitableProvider_3(TElCustomCryptoProviderManagerHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_IsOperationSupported(TElCustomCryptoProviderManagerHandle _Handle, int32_t Operation, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_IsOperationSupported_1(TElCustomCryptoProviderManagerHandle _Handle, int32_t Operation, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_IsAlgorithmSupported(TElCustomCryptoProviderManagerHandle _Handle, int32_t Algorithm, int32_t Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_IsAlgorithmSupported_1(TElCustomCryptoProviderManagerHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_IsProviderAllowed(TElCustomCryptoProviderManagerHandle _Handle, TElCustomCryptoProviderHandle Prov, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_GetAlgorithmProperty(TElCustomCryptoProviderManagerHandle _Handle, int32_t Algorithm, int32_t Mode, const uint8_t pPropID[], int32_t szPropID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_GetAlgorithmProperty_1(TElCustomCryptoProviderManagerHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, const uint8_t pPropID[], int32_t szPropID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_GetAlgorithmClass(TElCustomCryptoProviderManagerHandle _Handle, int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_GetAlgorithmClass_1(TElCustomCryptoProviderManagerHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_get_CryptoProviders(TElCustomCryptoProviderManagerHandle _Handle, int32_t Index, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_get_Count(TElCustomCryptoProviderManagerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_get_DefaultCryptoProvider(TElCustomCryptoProviderManagerHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderManager_Create(TComponentHandle AOwner, TElCustomCryptoProviderManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMCRYPTOPROVIDERMANAGER */

#ifdef SB_USE_CLASS_TELCUSTOMCRYPTOKEYCONTAINER
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_SupportsAccessMode(TElCustomCryptoKeyContainerHandle _Handle, TSBKeyContainerAccessModeRaw Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_AcquireKey(TElCustomCryptoKeyContainerHandle _Handle, const char * pcHandle, int32_t szHandle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_ReleaseKey(TElCustomCryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle * Key);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_AddKey(TElCustomCryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_AddKeyPair(TElCustomCryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle PubKey, TElCustomCryptoKeyHandle PrivKey, char * pcPubKeyHandle, int32_t * szPubKeyHandle, char * pcPrivKeyHandle, int32_t * szPrivKeyHandle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_RemoveKey(TElCustomCryptoKeyContainerHandle _Handle, const char * pcHandle, int32_t szHandle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_RemoveKey_1(TElCustomCryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_GenerateKey(TElCustomCryptoKeyContainerHandle _Handle, int32_t Algorithm, int32_t Bits, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_GenerateKeyPair(TElCustomCryptoKeyContainerHandle _Handle, int32_t Algorithm, int32_t Bits, char * pcPubKeyHandle, int32_t * szPubKeyHandle, char * pcPrivKeyHandle, int32_t * szPrivKeyHandle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_ListKeys(TElCustomCryptoKeyContainerHandle _Handle, TElStringListHandle HandleList, const char * pcAssociatedWithHandle, int32_t szAssociatedWithHandle, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_ListKeys_1(TElCustomCryptoKeyContainerHandle _Handle, TElStringListHandle HandleList, const char * pcAssociatedWithHandle, int32_t szAssociatedWithHandle, int32_t StartIndex, int32_t MaxCount, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_ClearKeys(TElCustomCryptoKeyContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_AcquireObject(TElCustomCryptoKeyContainerHandle _Handle, const char * pcHandle, int32_t szHandle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_ReleaseObject(TElCustomCryptoKeyContainerHandle _Handle, TElCustomCryptoObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_AddObject(TElCustomCryptoKeyContainerHandle _Handle, TElCustomCryptoObjectHandle Obj, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_AddObject_1(TElCustomCryptoKeyContainerHandle _Handle, const uint8_t pObjectType[], int32_t szObjectType, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_AddObject_2(TElCustomCryptoKeyContainerHandle _Handle, const uint8_t pObjectType[], int32_t szObjectType, const uint8_t pData[], int32_t szData, int32_t StartIndex, int32_t Size, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_AddObject_3(TElCustomCryptoKeyContainerHandle _Handle, const uint8_t pObjectType[], int32_t szObjectType, TStreamHandle Stream, int64_t Count, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_RemoveObject(TElCustomCryptoKeyContainerHandle _Handle, const char * pcHandle, int32_t szHandle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_RemoveObject_1(TElCustomCryptoKeyContainerHandle _Handle, TElCustomCryptoObjectHandle Obj, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_ListObjects(TElCustomCryptoKeyContainerHandle _Handle, TElStringListHandle HandleList, const uint8_t pObjectType[], int32_t szObjectType, const char * pcAssociatedWithHandle, int32_t szAssociatedWithHandle, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_ListObjects_1(TElCustomCryptoKeyContainerHandle _Handle, TElStringListHandle HandleList, const uint8_t pObjectType[], int32_t szObjectType, const char * pcAssociatedWithHandle, int32_t szAssociatedWithHandle, int32_t StartIndex, int32_t MaxCount, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_ClearObjects(TElCustomCryptoKeyContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_Clone(TElCustomCryptoKeyContainerHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_Lock(TElCustomCryptoKeyContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_Unlock(TElCustomCryptoKeyContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_Update(TElCustomCryptoKeyContainerHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_Commit(TElCustomCryptoKeyContainerHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_Persistentiate(TElCustomCryptoKeyContainerHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_GetContainerProp(TElCustomCryptoKeyContainerHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_SetContainerProp(TElCustomCryptoKeyContainerHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_GetContainerAttribute(TElCustomCryptoKeyContainerHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, int8_t * Protected, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_SetContainerAttribute(TElCustomCryptoKeyContainerHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int8_t Protected);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_get_IsPersistent(TElCustomCryptoKeyContainerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_get_IsReadOnly(TElCustomCryptoKeyContainerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_get_AccessMode(TElCustomCryptoKeyContainerHandle _Handle, TSBKeyContainerAccessModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_get_ID(TElCustomCryptoKeyContainerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_get_CryptoProvider(TElCustomCryptoKeyContainerHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKeyContainer_Create(TElCustomCryptoProviderHandle CryptoProvider, TElCustomCryptoKeyContainerHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMCRYPTOKEYCONTAINER */

#ifdef SB_USE_CLASS_TELCUSTOMCRYPTOKEY
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_Reset(TElCustomCryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_Generate(TElCustomCryptoKeyHandle _Handle, int32_t Bits, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_ImportPublic(TElCustomCryptoKeyHandle _Handle, void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_ImportSecret(TElCustomCryptoKeyHandle _Handle, void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_ExportPublic(TElCustomCryptoKeyHandle _Handle, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_ExportSecret(TElCustomCryptoKeyHandle _Handle, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_Clone(TElCustomCryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_ClonePublic(TElCustomCryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_ClearPublic(TElCustomCryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_ClearSecret(TElCustomCryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_GetKeyProp(TElCustomCryptoKeyHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_SetKeyProp(TElCustomCryptoKeyHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_GetKeyObjectProp(TElCustomCryptoKeyHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const TObjectHandle Default, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_SetKeyObjectProp(TElCustomCryptoKeyHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const TObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_GetKeyAttribute(TElCustomCryptoKeyHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, int8_t * Protected, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_SetKeyAttribute(TElCustomCryptoKeyHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int8_t Protected);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_ChangeAlgorithm(TElCustomCryptoKeyHandle _Handle, int32_t Algorithm);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_PrepareForEncryption(TElCustomCryptoKeyHandle _Handle, int8_t MultiUse);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_PrepareForSigning(TElCustomCryptoKeyHandle _Handle, int8_t MultiUse);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_CancelPreparation(TElCustomCryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_AsyncOperationFinished(TElCustomCryptoKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_Equals(TElCustomCryptoKeyHandle _Handle, TElCustomCryptoKeyHandle Key, int8_t PublicOnly, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_Matches(TElCustomCryptoKeyHandle _Handle, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_Persistentiate(TElCustomCryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_Update(TElCustomCryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_Commit(TElCustomCryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_get_IsPublic(TElCustomCryptoKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_get_IsSecret(TElCustomCryptoKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_get_IsExportable(TElCustomCryptoKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_get_IsPersistent(TElCustomCryptoKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_get_IsValid(TElCustomCryptoKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_get_Bits(TElCustomCryptoKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_get_Algorithm(TElCustomCryptoKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_get_Value(TElCustomCryptoKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_set_Value(TElCustomCryptoKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_get_IV(TElCustomCryptoKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_set_IV(TElCustomCryptoKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_get_Mode(TElCustomCryptoKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_set_Mode(TElCustomCryptoKeyHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_get_CryptoProvider(TElCustomCryptoKeyHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_get_KeyContainer(TElCustomCryptoKeyHandle _Handle, TElCustomCryptoKeyContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_get_KeyHandle(TElCustomCryptoKeyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoKey_Create(TElCustomCryptoProviderHandle CryptoProvider, TElCustomCryptoKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMCRYPTOKEY */

#ifdef SB_USE_CLASS_TELCUSTOMCRYPTOOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_Clone(TElCustomCryptoObjectHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_Clear(TElCustomCryptoObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_Reset(TElCustomCryptoObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_Persistentiate(TElCustomCryptoObjectHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_Update(TElCustomCryptoObjectHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_Commit(TElCustomCryptoObjectHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_GetObjectProp(TElCustomCryptoObjectHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_SetObjectProp(TElCustomCryptoObjectHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_GetObjectAttribute(TElCustomCryptoObjectHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, int8_t * Protected, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_SetObjectAttribute(TElCustomCryptoObjectHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int8_t Protected);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_GetData(TElCustomCryptoObjectHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_GetData_1(TElCustomCryptoObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_PutData(TElCustomCryptoObjectHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_PutData_1(TElCustomCryptoObjectHandle _Handle, const uint8_t pData[], int32_t szData, int32_t StartIndex, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_get_IsExportable(TElCustomCryptoObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_get_IsPersistent(TElCustomCryptoObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_get_Size(TElCustomCryptoObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_get_CryptoProvider(TElCustomCryptoObjectHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_get_KeyContainer(TElCustomCryptoObjectHandle _Handle, TElCustomCryptoKeyContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_get_ObjectHandle(TElCustomCryptoObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_get_ObjectType(TElCustomCryptoObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoObject_Create(TElCustomCryptoProviderHandle CryptoProvider, TElCustomCryptoObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMCRYPTOOBJECT */

#ifdef SB_USE_CLASS_TELCUSTOMCRYPTOCONTEXT
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_GetContextProp(TElCustomCryptoContextHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_SetContextProp(TElCustomCryptoContextHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_Clone(TElCustomCryptoContextHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_EstimateOutputSize(TElCustomCryptoContextHandle _Handle, int64_t InSize, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_get_Algorithm(TElCustomCryptoContextHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_get_CryptoProvider(TElCustomCryptoContextHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_get_KeySize(TElCustomCryptoContextHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_set_KeySize(TElCustomCryptoContextHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_get_BlockSize(TElCustomCryptoContextHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_set_BlockSize(TElCustomCryptoContextHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_get_DigestSize(TElCustomCryptoContextHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_set_DigestSize(TElCustomCryptoContextHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_get_Mode(TElCustomCryptoContextHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_set_Mode(TElCustomCryptoContextHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_get_Padding(TElCustomCryptoContextHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_set_Padding(TElCustomCryptoContextHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_get_AlgorithmClass(TElCustomCryptoContextHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_get_Provider(TElCustomCryptoContextHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoContext_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMCRYPTOCONTEXT */

#ifdef SB_USE_CLASS_TELCUSTOMCRYPTOPROVIDEROPTIONS
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderOptions_Assign(TElCustomCryptoProviderOptionsHandle _Handle, TElCustomCryptoProviderOptionsHandle Options);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderOptions_get_MaxPublicKeySize(TElCustomCryptoProviderOptionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderOptions_set_MaxPublicKeySize(TElCustomCryptoProviderOptionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderOptions_get_StoreKeys(TElCustomCryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderOptions_set_StoreKeys(TElCustomCryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderOptions_get_AutoGenerateKeyIDs(TElCustomCryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderOptions_set_AutoGenerateKeyIDs(TElCustomCryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCryptoProviderOptions_Create(TElCustomCryptoProviderOptionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMCRYPTOPROVIDEROPTIONS */

#ifdef SB_USE_CLASS_TELBLACKBOXCRYPTOPROVIDER
SB_IMPORT uint32_t SB_APIENTRY TElBlackboxCryptoProvider_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBlackboxCryptoProvider_Create(TComponentHandle AOwner, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBlackboxCryptoProvider_Create_1(TElCustomCryptoProviderOptionsHandle Options, TComponentHandle AOwner, TElCustomCryptoProviderHandle * OutResult);
#endif /* SB_USE_CLASS_TELBLACKBOXCRYPTOPROVIDER */

#ifdef SB_USE_CLASS_TELEXTERNALCRYPTOPROVIDER
SB_IMPORT uint32_t SB_APIENTRY TElExternalCryptoProvider_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElExternalCryptoProvider_Create(TComponentHandle AOwner, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElExternalCryptoProvider_Create_1(TElCustomCryptoProviderOptionsHandle Options, TComponentHandle AOwner, TElCustomCryptoProviderHandle * OutResult);
#endif /* SB_USE_CLASS_TELEXTERNALCRYPTOPROVIDER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElCustomCryptoProviderClass_ce_ptr;
extern zend_class_entry *TElCustomCryptoProvider_ce_ptr;
extern zend_class_entry *TElCustomCryptoProviderManager_ce_ptr;
extern zend_class_entry *TElCustomCryptoKeyContainer_ce_ptr;
extern zend_class_entry *TElCustomCryptoKey_ce_ptr;
extern zend_class_entry *TElCustomCryptoObject_ce_ptr;
extern zend_class_entry *TElCustomCryptoContext_ce_ptr;
extern zend_class_entry *TElCustomCryptoProviderOptions_ce_ptr;
extern zend_class_entry *TElBlackboxCryptoProvider_ce_ptr;
extern zend_class_entry *TElExternalCryptoProvider_ce_ptr;

void SB_CALLBACK TSBCryptoProviderObjectEventRaw(void * _ObjectData, TObjectHandle Sender, TObjectHandle Obj);
void Register_TElCustomCryptoProvider(TSRMLS_D);
void Register_TElCustomCryptoProviderManager(TSRMLS_D);
void Register_TElCustomCryptoKeyContainer(TSRMLS_D);
void Register_TElCustomCryptoKey(TSRMLS_D);
void Register_TElCustomCryptoObject(TSRMLS_D);
void Register_TElCustomCryptoContext(TSRMLS_D);
void Register_TElCustomCryptoProviderOptions(TSRMLS_D);
void Register_TElBlackboxCryptoProvider(TSRMLS_D);
void Register_TElExternalCryptoProvider(TSRMLS_D);
void Register_SBCryptoProv_Constants(int module_number TSRMLS_DC);
void Register_SBCryptoProv_Enum_Flags(TSRMLS_D);
void Register_SBCryptoProv_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCRYPTOPROV */

