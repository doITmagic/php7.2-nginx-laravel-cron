#ifndef __INC_SBCRYPTOPROVBUILTINEX
#define __INC_SBCRYPTOPROVBUILTINEX

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcryptoprov.h"
#include "sbcryptoprovbuiltin.h"
#include "sbcryptoprovbuiltinsym.h"
#include "sbcryptoprovrs.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElBuiltInExtendedCryptoProviderHandle;

typedef TElClassHandle TElBuiltInExtendedSymmetricCryptoFactoryHandle;

typedef TElClassHandle TElBuiltInIDEASymmetricCryptoHandle;

#ifdef SB_USE_CLASS_TELBUILTINEXTENDEDCRYPTOPROVIDER
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInExtendedCryptoProvider_GetDefaultInstance(TElBuiltInExtendedCryptoProviderHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInExtendedCryptoProvider_SetAsDefault();
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInExtendedCryptoProvider_SetAsDefault_1(TElBuiltInExtendedCryptoProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInExtendedCryptoProvider_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInExtendedCryptoProvider_Create(TComponentHandle AOwner, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInExtendedCryptoProvider_Create_1(TElCustomCryptoProviderOptionsHandle Options, TComponentHandle AOwner, TElCustomCryptoProviderHandle * OutResult);
#endif /* SB_USE_CLASS_TELBUILTINEXTENDEDCRYPTOPROVIDER */

#ifdef SB_USE_CLASS_TELBUILTINEXTENDEDSYMMETRICCRYPTOFACTORY
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInExtendedSymmetricCryptoFactory_Create(TElBuiltInSymmetricCryptoFactoryHandle * OutResult);
#endif /* SB_USE_CLASS_TELBUILTINEXTENDEDSYMMETRICCRYPTOFACTORY */

#ifdef SB_USE_CLASS_TELBUILTINIDEASYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInIDEASymmetricCrypto_InitializeEncryption(TElBuiltInIDEASymmetricCryptoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInIDEASymmetricCrypto_InitializeDecryption(TElBuiltInIDEASymmetricCryptoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInIDEASymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInIDEASymmetricCrypto_Create(int32_t AlgID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInIDEASymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInIDEASymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInIDEASymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInIDEASymmetricCrypto_Create_2(TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInIDEASymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELBUILTINIDEASYMMETRICCRYPTO */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElBuiltInExtendedCryptoProvider_ce_ptr;
extern zend_class_entry *TElBuiltInExtendedSymmetricCryptoFactory_ce_ptr;
extern zend_class_entry *TElBuiltInIDEASymmetricCrypto_ce_ptr;

void Register_TElBuiltInExtendedCryptoProvider(TSRMLS_D);
void Register_TElBuiltInExtendedSymmetricCryptoFactory(TSRMLS_D);
void Register_TElBuiltInIDEASymmetricCrypto(TSRMLS_D);
SB_PHP_FUNCTION(SBCryptoProvBuiltInEx, BuiltInCryptoProviderEx);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_CRYPTOPROVBUILTINEX
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvBuiltInEx_BuiltInCryptoProviderEx(TElCustomCryptoProviderHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_CRYPTOPROVBUILTINEX */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCRYPTOPROVBUILTINEX */

