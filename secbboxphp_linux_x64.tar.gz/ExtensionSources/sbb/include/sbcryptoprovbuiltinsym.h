#ifndef __INC_SBCRYPTOPROVBUILTINSYM
#define __INC_SBCRYPTOPROVBUILTINSYM

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcryptoprov.h"
#include "sbcryptoprovbuiltin.h"
#include "sbcryptoprovutils.h"
#include "sbcryptoprovrs.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbconstants.h"
#include "sbpoly1305.h"
#include "sbrdn.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SYMMETRIC_BLOCK_SIZE 	16384
#define SB_SYMMETRIC_DEFAULT_MODE 	

typedef TElClassHandle TElBuiltInSymmetricCryptoKeyHandle;

typedef TElClassHandle TElBuiltInSymmetricCryptoHandle;

typedef TElClassHandle TElBuiltInSymmetricCryptoFactoryHandle;

typedef TElClassHandle TElBuiltInIdentitySymmetricCryptoHandle;

typedef TElClassHandle TElBuiltInRC4SymmetricCryptoHandle;

typedef TElClassHandle TElBuiltInGOST28147SymmetricCryptoHandle;

typedef TElClassHandle TElBuiltInChaCha20SymmetricCryptoHandle;

typedef TElClassHandle TElBuiltInAEADChaCha20Poly1305SymmetricCryptoHandle;

typedef uint8_t TSBBuiltInSymmetricCryptoModeRaw;

typedef enum
{
	cmDefault = 0,
	cmECB = 1,
	cmCBC = 2,
	cmCTR = 3,
	cmCFB8 = 4,
	cmCCM = 5,
	cmGCM = 6,
	cmAEADChaCha20Poly1305 = 7
} TSBBuiltInSymmetricCryptoMode;

typedef uint8_t TSBBuiltInSymmetricCipherPaddingRaw;

typedef enum
{
	cpNone = 0,
	cpPKCS5 = 1,
	cpANSIX923 = 2
} TSBBuiltInSymmetricCipherPadding;

typedef uint8_t TSBBuiltInSymmetricCryptoOperationRaw;

typedef enum
{
	coNone = 0,
	coEncryption = 1,
	coDecryption = 2
} TSBBuiltInSymmetricCryptoOperation;

typedef void (SB_CALLBACK *TSBSymmetricCryptoProcessingFunction)(void * _ObjectData, void * Buffer, void * OutBuffer, int32_t Size);

#pragma pack(8)
typedef struct 
{
	uint32_t IV0;
	uint32_t IV1;
	uint32_t IV2;
	uint32_t IV3;
	uint64_t H0;
	uint64_t H1;
	uint64_t Y0;
	uint64_t Y1;
	uint64_t Ctr0;
	uint64_t Ctr1;
	uint64_t ASize;
	uint64_t PSize;
	uint64_t HTable[32];
} TSBGCMContext;

typedef TElClassHandle TElBuiltInSymmetricCryptoClassHandle;

#ifdef SB_USE_CLASS_TELBUILTINSYMMETRICCRYPTOKEY
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_Generate(TElBuiltInSymmetricCryptoKeyHandle _Handle, int32_t Bits, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_GenerateIV(TElBuiltInSymmetricCryptoKeyHandle _Handle, int32_t Bits);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_ImportPublic(TElBuiltInSymmetricCryptoKeyHandle _Handle, void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_ImportSecret(TElBuiltInSymmetricCryptoKeyHandle _Handle, void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_ExportPublic(TElBuiltInSymmetricCryptoKeyHandle _Handle, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_ExportSecret(TElBuiltInSymmetricCryptoKeyHandle _Handle, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_ChangeAlgorithm(TElBuiltInSymmetricCryptoKeyHandle _Handle, int32_t Algorithm);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_Reset(TElBuiltInSymmetricCryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_Clone(TElBuiltInSymmetricCryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_ClonePublic(TElBuiltInSymmetricCryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_ClearPublic(TElBuiltInSymmetricCryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_ClearSecret(TElBuiltInSymmetricCryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_GetKeyProp(TElBuiltInSymmetricCryptoKeyHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_SetKeyProp(TElBuiltInSymmetricCryptoKeyHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_Equals(TElBuiltInSymmetricCryptoKeyHandle _Handle, TElCustomCryptoKeyHandle Source, int8_t PublicOnly, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_Matches(TElBuiltInSymmetricCryptoKeyHandle _Handle, TElCustomCryptoKeyHandle Source, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_Create(TElCustomCryptoProviderHandle CryptoProvider, TElBuiltInSymmetricCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoKey_Create_1(TElCustomCryptoProviderHandle CryptoProvider, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElBuiltInSymmetricCryptoKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELBUILTINSYMMETRICCRYPTOKEY */

#ifdef SB_USE_CLASS_TELBUILTINSYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_InitializeEncryption(TElBuiltInSymmetricCryptoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_InitializeDecryption(TElBuiltInSymmetricCryptoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_Encrypt(TElBuiltInSymmetricCryptoHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_Encrypt_1(TElBuiltInSymmetricCryptoHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_EncryptUpdate(TElBuiltInSymmetricCryptoHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_FinalizeEncryption(TElBuiltInSymmetricCryptoHandle _Handle, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_Decrypt(TElBuiltInSymmetricCryptoHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_Decrypt_1(TElBuiltInSymmetricCryptoHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int32_t InCount);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_DecryptUpdate(TElBuiltInSymmetricCryptoHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_FinalizeDecryption(TElBuiltInSymmetricCryptoHandle _Handle, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_get_KeyMaterial(TElBuiltInSymmetricCryptoHandle _Handle, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_set_KeyMaterial(TElBuiltInSymmetricCryptoHandle _Handle, TElCustomCryptoKeyHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_get_AssociatedData(TElBuiltInSymmetricCryptoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_set_AssociatedData(TElBuiltInSymmetricCryptoHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_get_AssociatedDataSize(TElBuiltInSymmetricCryptoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_set_AssociatedDataSize(TElBuiltInSymmetricCryptoHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_get_PayloadSize(TElBuiltInSymmetricCryptoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_set_PayloadSize(TElBuiltInSymmetricCryptoHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_get_Nonce(TElBuiltInSymmetricCryptoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_set_Nonce(TElBuiltInSymmetricCryptoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_get_TagSize(TElBuiltInSymmetricCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_set_TagSize(TElBuiltInSymmetricCryptoHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_get_Mode(TElBuiltInSymmetricCryptoHandle _Handle, TSBBuiltInSymmetricCryptoModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_get_BlockSize(TElBuiltInSymmetricCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_get_KeySize(TElBuiltInSymmetricCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_get_Padding(TElBuiltInSymmetricCryptoHandle _Handle, TSBBuiltInSymmetricCipherPaddingRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_set_Padding(TElBuiltInSymmetricCryptoHandle _Handle, TSBBuiltInSymmetricCipherPaddingRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_get_CTRLittleEndian(TElBuiltInSymmetricCryptoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_set_CTRLittleEndian(TElBuiltInSymmetricCryptoHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_get_IsStreamCipher(TElBuiltInSymmetricCryptoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_get_OnProgress(TElBuiltInSymmetricCryptoHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_set_OnProgress(TElBuiltInSymmetricCryptoHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_Create(int32_t AlgID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCrypto_Create_2(TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInSymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELBUILTINSYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELBUILTINSYMMETRICCRYPTOFACTORY
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoFactory_RegisterClass(TElBuiltInSymmetricCryptoFactoryHandle _Handle, TElBuiltInSymmetricCryptoClassHandle Cls);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoFactory_CreateInstance(TElBuiltInSymmetricCryptoFactoryHandle _Handle, const uint8_t pOID[], int32_t szOID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoFactory_CreateInstance_1(TElBuiltInSymmetricCryptoFactoryHandle _Handle, int32_t Alg, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoFactory_CreateInstance_2(TElBuiltInSymmetricCryptoFactoryHandle _Handle, int32_t Alg, int32_t MacAlg, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoFactory_IsAlgorithmSupported(TElBuiltInSymmetricCryptoFactoryHandle _Handle, const uint8_t pOID[], int32_t szOID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoFactory_IsAlgorithmSupported_1(TElBuiltInSymmetricCryptoFactoryHandle _Handle, int32_t Alg, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoFactory_IsAlgorithmSupported_2(TElBuiltInSymmetricCryptoFactoryHandle _Handle, int32_t Alg, int32_t MacAlg, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoFactory_GetDefaultKeyAndBlockLengths(TElBuiltInSymmetricCryptoFactoryHandle _Handle, int32_t Alg, int32_t * KeyLen, int32_t * BlockLen, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoFactory_GetDefaultKeyAndBlockLengths_1(TElBuiltInSymmetricCryptoFactoryHandle _Handle, const uint8_t pOID[], int32_t szOID, int32_t * KeyLen, int32_t * BlockLen, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoFactory_get_RegisteredClasses(TElBuiltInSymmetricCryptoFactoryHandle _Handle, int32_t Index, TElBuiltInSymmetricCryptoClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoFactory_get_RegisteredClassCount(TElBuiltInSymmetricCryptoFactoryHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInSymmetricCryptoFactory_Create(TElBuiltInSymmetricCryptoFactoryHandle * OutResult);
#endif /* SB_USE_CLASS_TELBUILTINSYMMETRICCRYPTOFACTORY */

#ifdef SB_USE_CLASS_TELBUILTINIDENTITYSYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInIdentitySymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInIdentitySymmetricCrypto_Create(int32_t AlgID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInIdentitySymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInIdentitySymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInIdentitySymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInIdentitySymmetricCrypto_Create_2(TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInIdentitySymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELBUILTINIDENTITYSYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELBUILTINRC4SYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInRC4SymmetricCrypto_InitializeEncryption(TElBuiltInRC4SymmetricCryptoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInRC4SymmetricCrypto_InitializeDecryption(TElBuiltInRC4SymmetricCryptoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInRC4SymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInRC4SymmetricCrypto_get_SkipKeystreamBytes(TElBuiltInRC4SymmetricCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInRC4SymmetricCrypto_set_SkipKeystreamBytes(TElBuiltInRC4SymmetricCryptoHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInRC4SymmetricCrypto_Create(int32_t AlgID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInRC4SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInRC4SymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInRC4SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInRC4SymmetricCrypto_Create_2(TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInRC4SymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELBUILTINRC4SYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELBUILTINGOST28147SYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInGOST28147SymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInGOST28147SymmetricCrypto_set_ParamSet(TElBuiltInGOST28147SymmetricCryptoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInGOST28147SymmetricCrypto_set_SBoxes(TElBuiltInGOST28147SymmetricCryptoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInGOST28147SymmetricCrypto_get_UseKeyMeshing(TElBuiltInGOST28147SymmetricCryptoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInGOST28147SymmetricCrypto_set_UseKeyMeshing(TElBuiltInGOST28147SymmetricCryptoHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInGOST28147SymmetricCrypto_Create(int32_t AlgID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInGOST28147SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInGOST28147SymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInGOST28147SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInGOST28147SymmetricCrypto_Create_2(TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInGOST28147SymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELBUILTINGOST28147SYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELBUILTINCHACHA20SYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInChaCha20SymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInChaCha20SymmetricCrypto_get_Counter(TElBuiltInChaCha20SymmetricCryptoHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInChaCha20SymmetricCrypto_set_Counter(TElBuiltInChaCha20SymmetricCryptoHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInChaCha20SymmetricCrypto_Create(int32_t AlgID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInChaCha20SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInChaCha20SymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInChaCha20SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInChaCha20SymmetricCrypto_Create_2(TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInChaCha20SymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELBUILTINCHACHA20SYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELBUILTINAEADCHACHA20POLY1305SYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInAEADChaCha20Poly1305SymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInAEADChaCha20Poly1305SymmetricCrypto_get_AAD(TElBuiltInAEADChaCha20Poly1305SymmetricCryptoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInAEADChaCha20Poly1305SymmetricCrypto_set_AAD(TElBuiltInAEADChaCha20Poly1305SymmetricCryptoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInAEADChaCha20Poly1305SymmetricCrypto_get_Tag(TElBuiltInAEADChaCha20Poly1305SymmetricCryptoHandle _Handle, TSBPoly1305Tag * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInAEADChaCha20Poly1305SymmetricCrypto_set_Tag(TElBuiltInAEADChaCha20Poly1305SymmetricCryptoHandle _Handle, TSBPoly1305Tag * Value);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInAEADChaCha20Poly1305SymmetricCrypto_get_Poly1305Mode(TElBuiltInAEADChaCha20Poly1305SymmetricCryptoHandle _Handle, TSBPoly1305ModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInAEADChaCha20Poly1305SymmetricCrypto_set_Poly1305Mode(TElBuiltInAEADChaCha20Poly1305SymmetricCryptoHandle _Handle, TSBPoly1305ModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInAEADChaCha20Poly1305SymmetricCrypto_Create(int32_t AlgID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInAEADChaCha20Poly1305SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInAEADChaCha20Poly1305SymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInAEADChaCha20Poly1305SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInAEADChaCha20Poly1305SymmetricCrypto_Create_2(TSBBuiltInSymmetricCryptoModeRaw Mode, TElBuiltInAEADChaCha20Poly1305SymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELBUILTINAEADCHACHA20POLY1305SYMMETRICCRYPTO */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TSBGCMContext_ce_ptr;
extern zend_class_entry *TElBuiltInSymmetricCryptoClass_ce_ptr;
extern zend_class_entry *TElBuiltInSymmetricCryptoKey_ce_ptr;
extern zend_class_entry *TElBuiltInSymmetricCrypto_ce_ptr;
extern zend_class_entry *TElBuiltInSymmetricCryptoFactory_ce_ptr;
extern zend_class_entry *TElBuiltInIdentitySymmetricCrypto_ce_ptr;
extern zend_class_entry *TElBuiltInRC4SymmetricCrypto_ce_ptr;
extern zend_class_entry *TElBuiltInGOST28147SymmetricCrypto_ce_ptr;
extern zend_class_entry *TElBuiltInChaCha20SymmetricCrypto_ce_ptr;
extern zend_class_entry *TElBuiltInAEADChaCha20Poly1305SymmetricCrypto_ce_ptr;

void SB_CALLBACK TSBSymmetricCryptoProcessingFunctionRaw(void * _ObjectData, void * Buffer, void * OutBuffer, int32_t Size);
void Register_TSBGCMContext(TSRMLS_D);
void Register_TElBuiltInSymmetricCryptoKey(TSRMLS_D);
void Register_TElBuiltInSymmetricCrypto(TSRMLS_D);
void Register_TElBuiltInSymmetricCryptoFactory(TSRMLS_D);
void Register_TElBuiltInIdentitySymmetricCrypto(TSRMLS_D);
void Register_TElBuiltInRC4SymmetricCrypto(TSRMLS_D);
void Register_TElBuiltInGOST28147SymmetricCrypto(TSRMLS_D);
void Register_TElBuiltInChaCha20SymmetricCrypto(TSRMLS_D);
void Register_TElBuiltInAEADChaCha20Poly1305SymmetricCrypto(TSRMLS_D);
void Register_SBCryptoProvBuiltInSym_Constants(int module_number TSRMLS_DC);
void Register_SBCryptoProvBuiltInSym_Enum_Flags(TSRMLS_D);
void Register_SBCryptoProvBuiltInSym_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCRYPTOPROVBUILTINSYM */

