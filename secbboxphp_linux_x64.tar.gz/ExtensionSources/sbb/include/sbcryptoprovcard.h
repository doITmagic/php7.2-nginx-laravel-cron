#ifndef __INC_SBCRYPTOPROVCARD
#define __INC_SBCRYPTOPROVCARD

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcryptoprov.h"
#include "sbcryptoprovutils.h"
#include "sbcryptoprovrs.h"
#include "sbcardcommon.h"
#include "sbsharedresource.h"
#include "sbeccommon.h"
#include "sbasn1tree.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbrandom.h"
#include "sbstreams.h"
#include "sbstringlist.h"
#include "sbdynstruct.h"
#include "sbrdn.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSmartCardCryptoKeyContainerHandle;

typedef TElClassHandle TElSmartCardCryptoKeyHandle;

typedef TElClassHandle TElSmartCardCryptoObjectHandle;

typedef TElClassHandle TElSmartCardCryptoContextHandle;

typedef TElClassHandle TElSmartCardCryptoProviderOptionsHandle;

typedef TElClassHandle TElSmartCardCryptoProviderHandle;

typedef uint8_t TSBSmartCardCryptoContextTypeRaw;

typedef enum
{
	scctUndefined = 0,
	scctSymCrypto = 1,
	scctPKICrypto = 2,
	scctHash = 3,
	scctHMAC = 4
} TSBSmartCardCryptoContextType;

typedef uint8_t TSBSmartCardCryptoContextOperationRaw;

typedef enum
{
	sccoUndefined = 0,
	sccoEncrypt = 1,
	sccoDecrypt = 2,
	sccoSign = 3,
	sccoVerify = 4,
	sccoSignDetached = 5,
	sccoVerifyDetached = 6,
	sccoHash = 7
} TSBSmartCardCryptoContextOperation;

typedef uint8_t TSBSmartCardCryptoObjectOperationRaw;

typedef enum
{
	scooGenerateKeyPair = 0,
	scooGenerateKey = 1,
	scooCreatePublicKey = 2,
	scooCreatePrivateKey = 3,
	scooCreateSecretKey = 4,
	scooCreateCertificate = 5,
	scooCreateData = 6
} TSBSmartCardCryptoObjectOperation;

typedef void (SB_CALLBACK *TSBSmartCardCryptoProviderAttributesPreparedEvent)(void * _ObjectData, TObjectHandle Sender, TElCustomCryptoKeyHandle CryptoKey, TSBSmartCardCryptoObjectOperationRaw Operation);

typedef void (SB_CALLBACK *TSBSmartCardConditionalListFunc)(void * _ObjectData, TObjectHandle Sender, TObjectHandle Obj, const uint8_t pObjType[], int32_t szObjType, TObjectHandle AssociatedWithObj, TObjectHandle Data, TElRelativeDistinguishedNameHandle Pars, int8_t * OutResult);

#ifdef SB_USE_CLASS_TELSMARTCARDCRYPTOKEYCONTAINER
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_SupportsAccessMode(TElSmartCardCryptoKeyContainerHandle _Handle, TSBKeyContainerAccessModeRaw Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_ReleaseKey(TElSmartCardCryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle * Key);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_AddKey(TElSmartCardCryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_AddKeyPair(TElSmartCardCryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle PubKey, TElCustomCryptoKeyHandle PrivKey, char * pcPubKeyHandle, int32_t * szPubKeyHandle, char * pcPrivKeyHandle, int32_t * szPrivKeyHandle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_GenerateKey(TElSmartCardCryptoKeyContainerHandle _Handle, int32_t Algorithm, int32_t Bits, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_GenerateKeyPair(TElSmartCardCryptoKeyContainerHandle _Handle, int32_t Algorithm, int32_t Bits, char * pcPubKeyHandle, int32_t * szPubKeyHandle, char * pcPrivKeyHandle, int32_t * szPrivKeyHandle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_RemoveKey(TElSmartCardCryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_RemoveKey_1(TElSmartCardCryptoKeyContainerHandle _Handle, const char * pcHandle, int32_t szHandle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_ListKeys(TElSmartCardCryptoKeyContainerHandle _Handle, TElStringListHandle HandleList, const char * pcAssociatedWithHandle, int32_t szAssociatedWithHandle, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_ListKeys_1(TElSmartCardCryptoKeyContainerHandle _Handle, TElStringListHandle HandleList, const char * pcAssociatedWithHandle, int32_t szAssociatedWithHandle, int32_t StartIndex, int32_t MaxCount, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_ClearKeys(TElSmartCardCryptoKeyContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_ReleaseObject(TElSmartCardCryptoKeyContainerHandle _Handle, TElCustomCryptoObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_AddObject(TElSmartCardCryptoKeyContainerHandle _Handle, TElCustomCryptoObjectHandle Obj, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_AddObject_1(TElSmartCardCryptoKeyContainerHandle _Handle, const uint8_t pObjectType[], int32_t szObjectType, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_AddObject_2(TElSmartCardCryptoKeyContainerHandle _Handle, const uint8_t pObjectType[], int32_t szObjectType, const uint8_t pData[], int32_t szData, int32_t StartIndex, int32_t Size, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_AddObject_3(TElSmartCardCryptoKeyContainerHandle _Handle, const uint8_t pObjectType[], int32_t szObjectType, TStreamHandle Stream, int64_t Count, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_RemoveObject(TElSmartCardCryptoKeyContainerHandle _Handle, const char * pcHandle, int32_t szHandle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_RemoveObject_1(TElSmartCardCryptoKeyContainerHandle _Handle, TElCustomCryptoObjectHandle Obj, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_ListObjects(TElSmartCardCryptoKeyContainerHandle _Handle, TElStringListHandle HandleList, const uint8_t pObjectType[], int32_t szObjectType, const char * pcAssociatedWithHandle, int32_t szAssociatedWithHandle, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_ListObjects_1(TElSmartCardCryptoKeyContainerHandle _Handle, TElStringListHandle HandleList, const uint8_t pObjectType[], int32_t szObjectType, const char * pcAssociatedWithHandle, int32_t szAssociatedWithHandle, int32_t StartIndex, int32_t MaxCount, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_ClearObjects(TElSmartCardCryptoKeyContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_Clone(TElSmartCardCryptoKeyContainerHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_Lock(TElSmartCardCryptoKeyContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_Unlock(TElSmartCardCryptoKeyContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_Update(TElSmartCardCryptoKeyContainerHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_Commit(TElSmartCardCryptoKeyContainerHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_Persistentiate(TElSmartCardCryptoKeyContainerHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_GetContainerProp(TElSmartCardCryptoKeyContainerHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_SetContainerProp(TElSmartCardCryptoKeyContainerHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_GetContainerAttribute(TElSmartCardCryptoKeyContainerHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, int8_t * Protected, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_SetContainerAttribute(TElSmartCardCryptoKeyContainerHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int8_t Protected);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKeyContainer_Create(TElCustomCryptoProviderHandle CryptoProvider, TElSmartCardCryptoKeyContainerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSMARTCARDCRYPTOKEYCONTAINER */

#ifdef SB_USE_CLASS_TELSMARTCARDCRYPTOKEY
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKey_Equals(TElSmartCardCryptoKeyHandle _Handle, TElCustomCryptoKeyHandle Source, int8_t PublicOnly, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKey_Matches(TElSmartCardCryptoKeyHandle _Handle, TElCustomCryptoKeyHandle Source, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoKey_Create(TElCustomCryptoProviderHandle CryptoProvider, TElSmartCardCryptoKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELSMARTCARDCRYPTOKEY */

#ifdef SB_USE_CLASS_TELSMARTCARDCRYPTOOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoObject_Clear(TElSmartCardCryptoObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoObject_Create(TElCustomCryptoProviderHandle CryptoProvider, TElSmartCardCryptoObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELSMARTCARDCRYPTOOBJECT */

#ifdef SB_USE_CLASS_TELSMARTCARDCRYPTOCONTEXT
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoContext_Clone(TElSmartCardCryptoContextHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoContext_GetContextProp(TElSmartCardCryptoContextHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoContext_SetContextProp(TElSmartCardCryptoContextHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoContext_Create(int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TSBSmartCardCryptoContextOperationRaw Operation, TElCustomCryptoProviderHandle Prov, TElRelativeDistinguishedNameHandle Params, TElSmartCardCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoContext_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TSBSmartCardCryptoContextOperationRaw Operation, TElCustomCryptoProviderHandle Prov, TElRelativeDistinguishedNameHandle Params, TElSmartCardCryptoContextHandle * OutResult);
#endif /* SB_USE_CLASS_TELSMARTCARDCRYPTOCONTEXT */

#ifdef SB_USE_CLASS_TELSMARTCARDCRYPTOPROVIDEROPTIONS
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProviderOptions_Assign(TElSmartCardCryptoProviderOptionsHandle _Handle, TElCustomCryptoProviderOptionsHandle Options);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProviderOptions_get_OperationPIN(TElSmartCardCryptoProviderOptionsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProviderOptions_set_OperationPIN(TElSmartCardCryptoProviderOptionsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProviderOptions_Create(TElCustomCryptoProviderOptionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELSMARTCARDCRYPTOPROVIDEROPTIONS */

#ifdef SB_USE_CLASS_TELSMARTCARDCRYPTOPROVIDER
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_Init(TElSmartCardCryptoProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_Deinit(TElSmartCardCryptoProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_IsAlgorithmSupported(TElSmartCardCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_IsAlgorithmSupported_1(TElCustomCryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_IsOperationSupported(TElSmartCardCryptoProviderHandle _Handle, int32_t Operation, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_IsOperationSupported_1(TElCustomCryptoProviderHandle _Handle, int32_t Operation, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_GetAlgorithmProperty(TElSmartCardCryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, const uint8_t pPropID[], int32_t szPropID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_GetAlgorithmProperty_1(TElSmartCardCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, const uint8_t pPropID[], int32_t szPropID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_GetAlgorithmClass(TElSmartCardCryptoProviderHandle _Handle, int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_GetAlgorithmClass_1(TElSmartCardCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_GetProviderProp(TElSmartCardCryptoProviderHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_SetProviderProp(TElSmartCardCryptoProviderHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_CreateKey(TElSmartCardCryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_CreateKey_1(TElSmartCardCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_CloneKey(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoKeyHandle Key, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_ReleaseKey(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoKeyHandle * Key);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_DeleteKey(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoKeyHandle * Key);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_DecryptKey(TElSmartCardCryptoProviderHandle _Handle, void * EncKey, int32_t EncKeySize, const uint8_t pEncKeyAlgOID[], int32_t szEncKeyAlgOID, const uint8_t pEncKeyAlgParams[], int32_t szEncKeyAlgParams, TElCustomCryptoKeyHandle Key, const uint8_t pKeyAlgOID[], int32_t szKeyAlgOID, const uint8_t pKeyAlgParams[], int32_t szKeyAlgParams, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_CreateObject(TElSmartCardCryptoProviderHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_CloneObject(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoObjectHandle Obj, TElCustomCryptoObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_ReleaseObject(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_DeleteObject(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_EncryptInit(TElSmartCardCryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_EncryptInit_1(TElSmartCardCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_DecryptInit(TElSmartCardCryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_DecryptInit_1(TElSmartCardCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_SignInit(TElSmartCardCryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, int8_t Detached, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_SignInit_1(TElSmartCardCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, int8_t Detached, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_VerifyInit(TElSmartCardCryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, void * SigBuffer, int32_t SigSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_VerifyInit_1(TElSmartCardCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, void * SigBuffer, int32_t SigSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_EncryptUpdate(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_DecryptUpdate(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_SignUpdate(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_VerifyUpdate(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_EncryptFinal(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_DecryptFinal(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_SignFinal(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_VerifyFinal(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_HashInit(TElSmartCardCryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_HashInit_1(TElSmartCardCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_HashUpdate(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_HashFinal(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_ReleaseCryptoContext(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoContextHandle * Context);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_CreateKeyContainer(TElSmartCardCryptoProviderHandle _Handle, int8_t Persistent, const char * pcID, int32_t szID, TSBKeyContainerAccessModeRaw AccessMode, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_OpenKeyContainer(TElSmartCardCryptoProviderHandle _Handle, const char * pcID, int32_t szID, TSBKeyContainerAccessModeRaw AccessMode, int8_t ReadOnly, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_ReleaseKeyContainer(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoKeyContainerHandle * KeyContainer);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_DeleteKeyContainer(TElSmartCardCryptoProviderHandle _Handle, TElCustomCryptoKeyContainerHandle * KeyContainer);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_ListKeyContainers(TElSmartCardCryptoProviderHandle _Handle, TElStringListHandle IDList, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_ListKeyContainers_1(TElSmartCardCryptoProviderHandle _Handle, TElStringListHandle IDList, int32_t StartIndex, int32_t MaxCount, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_get_IsObsolete(TElSmartCardCryptoProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_set_IsObsolete(TElSmartCardCryptoProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_get_ReaderName(TElSmartCardCryptoProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
#ifndef CPU64
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_get_CardHandle(TElSmartCardCryptoProviderHandle _Handle, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_get_CardHandle(TElSmartCardCryptoProviderHandle _Handle, uint64_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_get_OnAttributesPrepared(TElSmartCardCryptoProviderHandle _Handle, TSBSmartCardCryptoProviderAttributesPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_set_OnAttributesPrepared(TElSmartCardCryptoProviderHandle _Handle, TSBSmartCardCryptoProviderAttributesPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_Create(TComponentHandle AOwner, TElSmartCardCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSmartCardCryptoProvider_Create_1(TElCustomCryptoProviderOptionsHandle Options, TComponentHandle AOwner, TElSmartCardCryptoProviderHandle * OutResult);
#endif /* SB_USE_CLASS_TELSMARTCARDCRYPTOPROVIDER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSmartCardCryptoKeyContainer_ce_ptr;
extern zend_class_entry *TElSmartCardCryptoKey_ce_ptr;
extern zend_class_entry *TElSmartCardCryptoObject_ce_ptr;
extern zend_class_entry *TElSmartCardCryptoContext_ce_ptr;
extern zend_class_entry *TElSmartCardCryptoProviderOptions_ce_ptr;
extern zend_class_entry *TElSmartCardCryptoProvider_ce_ptr;

void SB_CALLBACK TSBSmartCardCryptoProviderAttributesPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomCryptoKeyHandle CryptoKey, TSBSmartCardCryptoObjectOperationRaw Operation);
void SB_CALLBACK TSBSmartCardConditionalListFuncRaw(void * _ObjectData, TObjectHandle Sender, TObjectHandle Obj, const uint8_t pObjType[], int32_t szObjType, TObjectHandle AssociatedWithObj, TObjectHandle Data, TElRelativeDistinguishedNameHandle Pars, int8_t * OutResult);
void Register_TElSmartCardCryptoKeyContainer(TSRMLS_D);
void Register_TElSmartCardCryptoKey(TSRMLS_D);
void Register_TElSmartCardCryptoObject(TSRMLS_D);
void Register_TElSmartCardCryptoContext(TSRMLS_D);
void Register_TElSmartCardCryptoProviderOptions(TSRMLS_D);
void Register_TElSmartCardCryptoProvider(TSRMLS_D);
void Register_SBCryptoProvCard_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCRYPTOPROVCARD */
