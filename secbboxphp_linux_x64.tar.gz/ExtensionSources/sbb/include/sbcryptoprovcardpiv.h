#ifndef __INC_SBCRYPTOPROVCARDPIV
#define __INC_SBCRYPTOPROVCARDPIV

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#ifdef SB_WINDOWS
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstringlist.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbcryptoprovutils.h"
#include "sbcryptoprovrs.h"
#include "sbcryptoprov.h"
#include "sbcryptoprovcard.h"
#include "sbcardcommon.h"
#include "sbx509.h"
#include "sbscwin.h"
#include "sbrdn.h"
#endif

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef SB_WINDOWS
typedef TElClassHandle TElPIVCardCryptoProviderOptionsHandle;

typedef TElClassHandle TElPIVCardCryptoProviderHandle;

typedef TElClassHandle TElPIVCardCryptoKeyContainerHandle;

typedef TElClassHandle TElPIVCardCryptoContextHandle;

typedef TElClassHandle TElPIVCardCryptoKeyHandle;

typedef TElClassHandle TElPIVCardCryptoObjectHandle;

#ifdef SB_USE_CLASS_TELPIVCARDCRYPTOPROVIDEROPTIONS
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProviderOptions_Assign(TElPIVCardCryptoProviderOptionsHandle _Handle, TElCustomCryptoProviderOptionsHandle Options);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProviderOptions_get_UseForPublicKeyOperations(TElPIVCardCryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProviderOptions_set_UseForPublicKeyOperations(TElPIVCardCryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProviderOptions_get_UseForSymmetricKeyOperations(TElPIVCardCryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProviderOptions_set_UseForSymmetricKeyOperations(TElPIVCardCryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProviderOptions_get_UseForHashingOperations(TElPIVCardCryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProviderOptions_set_UseForHashingOperations(TElPIVCardCryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProviderOptions_get_UseForNonPrivateOperations(TElPIVCardCryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProviderOptions_set_UseForNonPrivateOperations(TElPIVCardCryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProviderOptions_Create(TElCustomCryptoProviderOptionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELPIVCARDCRYPTOPROVIDEROPTIONS */

#ifdef SB_USE_CLASS_TELPIVCARDCRYPTOPROVIDER
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProvider_SetAsDefault();
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProvider_SetAsDefault_1(TElPIVCardCryptoProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProvider_Clone(TElPIVCardCryptoProviderHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProvider_IsAlgorithmSupported(TElPIVCardCryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProvider_IsAlgorithmSupported_1(TElSmartCardCryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProvider_IsOperationSupported(TElPIVCardCryptoProviderHandle _Handle, int32_t Operation, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProvider_IsOperationSupported_1(TElSmartCardCryptoProviderHandle _Handle, int32_t Operation, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProvider_RandomInit(TElPIVCardCryptoProviderHandle _Handle, void * BaseData, int32_t BaseDataSize, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProvider_RandomSeed(TElPIVCardCryptoProviderHandle _Handle, void * Data, int32_t DataSize);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProvider_RandomGenerate(TElPIVCardCryptoProviderHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProvider_RandomGenerate_1(TElPIVCardCryptoProviderHandle _Handle, int32_t MaxValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProvider_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProvider_Create(TComponentHandle AOwner, TElSmartCardCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoProvider_Create_1(TElCustomCryptoProviderOptionsHandle Options, TComponentHandle AOwner, TElSmartCardCryptoProviderHandle * OutResult);
#endif /* SB_USE_CLASS_TELPIVCARDCRYPTOPROVIDER */

#ifdef SB_USE_CLASS_TELPIVCARDCRYPTOKEYCONTAINER
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKeyContainer_AcquireKey(TElPIVCardCryptoKeyContainerHandle _Handle, const char * pcHandle, int32_t szHandle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKeyContainer_AcquireObject(TElPIVCardCryptoKeyContainerHandle _Handle, const char * pcHandle, int32_t szHandle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKeyContainer_ReleaseObject(TElPIVCardCryptoKeyContainerHandle _Handle, TElCustomCryptoObjectHandle * Key);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKeyContainer_ReleaseKey(TElPIVCardCryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle * Key);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKeyContainer_AddSymmetricKey(TElPIVCardCryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKeyContainer_AddPublicKeyPair(TElPIVCardCryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle PubKey, TElCustomCryptoKeyHandle PrivKey, char * pcPubKeyHandle, int32_t * szPubKeyHandle, char * pcPrivKeyHandle, int32_t * szPrivKeyHandle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKeyContainer_AddPublicKey(TElPIVCardCryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKeyContainer_GenerateSymmetricKey(TElPIVCardCryptoKeyContainerHandle _Handle, int32_t Algorithm, int32_t Bits, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKeyContainer_GeneratePublicKeyPair(TElPIVCardCryptoKeyContainerHandle _Handle, int32_t Algorithm, int32_t Bits, char * pcPubKeyHandle, int32_t * szPubKeyHandle, char * pcPrivKeyHandle, int32_t * szPrivKeyHandle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKeyContainer_CreateCertificateObject(TElPIVCardCryptoKeyContainerHandle _Handle, const uint8_t pData[], int32_t szData, int32_t StartIndex, int32_t Size, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKeyContainer_CreateDataObject(TElPIVCardCryptoKeyContainerHandle _Handle, const uint8_t pData[], int32_t szData, int32_t StartIndex, int32_t Size, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKeyContainer_Create(TElCustomCryptoProviderHandle CryptoProvider, TElSmartCardCryptoKeyContainerHandle * OutResult);
#endif /* SB_USE_CLASS_TELPIVCARDCRYPTOKEYCONTAINER */

#ifdef SB_USE_CLASS_TELPIVCARDCRYPTOCONTEXT
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoContext_EstimateOutputSize(TElPIVCardCryptoContextHandle _Handle, int64_t InSize, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoContext_GetContextProp(TElPIVCardCryptoContextHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoContext_SetContextProp(TElPIVCardCryptoContextHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoContext_Create(int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TSBSmartCardCryptoContextOperationRaw Operation, TElCustomCryptoProviderHandle Prov, TElRelativeDistinguishedNameHandle Params, TElSmartCardCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoContext_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TSBSmartCardCryptoContextOperationRaw Operation, TElCustomCryptoProviderHandle Prov, TElRelativeDistinguishedNameHandle Params, TElSmartCardCryptoContextHandle * OutResult);
#endif /* SB_USE_CLASS_TELPIVCARDCRYPTOCONTEXT */

#ifdef SB_USE_CLASS_TELPIVCARDCRYPTOKEY
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_Reset(TElPIVCardCryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_Generate(TElPIVCardCryptoKeyHandle _Handle, int32_t Bits, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_ChangeAlgorithm(TElPIVCardCryptoKeyHandle _Handle, int32_t Algorithm);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_ImportPublic(TElPIVCardCryptoKeyHandle _Handle, void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_ImportSecret(TElPIVCardCryptoKeyHandle _Handle, void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_ExportPublic(TElPIVCardCryptoKeyHandle _Handle, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_ExportSecret(TElPIVCardCryptoKeyHandle _Handle, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_Clone(TElPIVCardCryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_ClonePublic(TElPIVCardCryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_ClearPublic(TElPIVCardCryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_ClearSecret(TElPIVCardCryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_GetKeyProp(TElPIVCardCryptoKeyHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_SetKeyProp(TElPIVCardCryptoKeyHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_GetKeyAttribute(TElPIVCardCryptoKeyHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, int8_t * Protected, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_SetKeyAttribute(TElPIVCardCryptoKeyHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int8_t Protected);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_PrepareForEncryption(TElPIVCardCryptoKeyHandle _Handle, int8_t MultiUse);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_PrepareForSigning(TElPIVCardCryptoKeyHandle _Handle, int8_t MultiUse);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_CancelPreparation(TElPIVCardCryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_AsyncOperationFinished(TElPIVCardCryptoKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_Equals(TElPIVCardCryptoKeyHandle _Handle, TElCustomCryptoKeyHandle Source, int8_t PublicOnly, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_Matches(TElPIVCardCryptoKeyHandle _Handle, TElCustomCryptoKeyHandle Source, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_Persistentiate(TElPIVCardCryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_Update(TElPIVCardCryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_Commit(TElPIVCardCryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_get_KeyID(TElPIVCardCryptoKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
#ifndef CPU64
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_get_Handle(TElPIVCardCryptoKeyHandle _Handle, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_get_Handle(TElPIVCardCryptoKeyHandle _Handle, uint64_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoKey_Create(TElCustomCryptoProviderHandle CryptoProvider, TElSmartCardCryptoKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELPIVCARDCRYPTOKEY */

#ifdef SB_USE_CLASS_TELPIVCARDCRYPTOOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_Clone(TElPIVCardCryptoObjectHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_Reset(TElPIVCardCryptoObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_Persistentiate(TElPIVCardCryptoObjectHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_Update(TElPIVCardCryptoObjectHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_Commit(TElPIVCardCryptoObjectHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_GetObjectProp(TElPIVCardCryptoObjectHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_SetObjectProp(TElPIVCardCryptoObjectHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_GetObjectAttribute(TElPIVCardCryptoObjectHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, int8_t * Protected, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_SetObjectAttribute(TElPIVCardCryptoObjectHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int8_t Protected);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_GetData(TElPIVCardCryptoObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_GetData_1(TElPIVCardCryptoObjectHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_PutData(TElPIVCardCryptoObjectHandle _Handle, TStreamHandle Data);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_PutData_1(TElPIVCardCryptoObjectHandle _Handle, const uint8_t pData[], int32_t szData, int32_t StartIndex, int32_t Count);
#ifndef CPU64
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_get_Handle(TElPIVCardCryptoObjectHandle _Handle, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_get_Handle(TElPIVCardCryptoObjectHandle _Handle, uint64_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_get_Subject(TElPIVCardCryptoObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_get_KeyID(TElPIVCardCryptoObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_get_Issuer(TElPIVCardCryptoObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPIVCardCryptoObject_Create(TElCustomCryptoProviderHandle CryptoProvider, TElSmartCardCryptoObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELPIVCARDCRYPTOOBJECT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPIVCardCryptoProviderOptions_ce_ptr;
extern zend_class_entry *TElPIVCardCryptoProvider_ce_ptr;
extern zend_class_entry *TElPIVCardCryptoKeyContainer_ce_ptr;
extern zend_class_entry *TElPIVCardCryptoContext_ce_ptr;
extern zend_class_entry *TElPIVCardCryptoKey_ce_ptr;
extern zend_class_entry *TElPIVCardCryptoObject_ce_ptr;

void Register_TElPIVCardCryptoProviderOptions(TSRMLS_D);
void Register_TElPIVCardCryptoProvider(TSRMLS_D);
void Register_TElPIVCardCryptoKeyContainer(TSRMLS_D);
void Register_TElPIVCardCryptoContext(TSRMLS_D);
void Register_TElPIVCardCryptoKey(TSRMLS_D);
void Register_TElPIVCardCryptoObject(TSRMLS_D);
SB_PHP_FUNCTION(SBCryptoProvCardPIV, PIVCardCryptoProvider);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_CRYPTOPROVCARDPIV
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvCardPIV_PIVCardCryptoProvider(TElCustomCryptoProviderHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_CRYPTOPROVCARDPIV */
#endif

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCRYPTOPROVCARDPIV */
