#ifndef __INC_SBCRYPTOPROVMANAGER
#define __INC_SBCRYPTOPROVMANAGER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbsharedresource.h"
#include "sbcryptoprov.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElBuiltInCryptoProviderManagerHandle;

typedef TElClassHandle TElFIPSCompliantCryptoProviderManagerHandle;

typedef uint8_t TSBCryptoEngineTypeRaw;

typedef enum
{
	cetDefault = 0,
	cetFIPS = 1,
	cetCustom = 2
} TSBCryptoEngineType;

#ifdef SB_USE_CLASS_TELBUILTINCRYPTOPROVIDERMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInCryptoProviderManager_Init(TElBuiltInCryptoProviderManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInCryptoProviderManager_Deinit(TElBuiltInCryptoProviderManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInCryptoProviderManager_IsProviderAllowed(TElBuiltInCryptoProviderManagerHandle _Handle, TElCustomCryptoProviderHandle Prov, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInCryptoProviderManager_get_EngineType(TElBuiltInCryptoProviderManagerHandle _Handle, TSBCryptoEngineTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInCryptoProviderManager_set_EngineType(TElBuiltInCryptoProviderManagerHandle _Handle, TSBCryptoEngineTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInCryptoProviderManager_get_BuiltInCryptoProvider(TElBuiltInCryptoProviderManagerHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInCryptoProviderManager_get_Win32CryptoProvider(TElBuiltInCryptoProviderManagerHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBuiltInCryptoProviderManager_Create(TComponentHandle AOwner, TElCustomCryptoProviderManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELBUILTINCRYPTOPROVIDERMANAGER */

#ifdef SB_USE_CLASS_TELFIPSCOMPLIANTCRYPTOPROVIDERMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElFIPSCompliantCryptoProviderManager_Init(TElFIPSCompliantCryptoProviderManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElFIPSCompliantCryptoProviderManager_Deinit(TElFIPSCompliantCryptoProviderManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElFIPSCompliantCryptoProviderManager_IsProviderAllowed(TElFIPSCompliantCryptoProviderManagerHandle _Handle, TElCustomCryptoProviderHandle Prov, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFIPSCompliantCryptoProviderManager_Create(TComponentHandle AOwner, TElCustomCryptoProviderManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELFIPSCOMPLIANTCRYPTOPROVIDERMANAGER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElBuiltInCryptoProviderManager_ce_ptr;
extern zend_class_entry *TElFIPSCompliantCryptoProviderManager_ce_ptr;

void Register_TElBuiltInCryptoProviderManager(TSRMLS_D);
void Register_TElFIPSCompliantCryptoProviderManager(TSRMLS_D);
SB_PHP_FUNCTION(SBCryptoProvManager, DefaultCryptoProviderManager);
#ifdef SB_WINDOWS
SB_PHP_FUNCTION(SBCryptoProvManager, FIPSCompliantCryptoProviderManager);
#endif
void Register_SBCryptoProvManager_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_CRYPTOPROVMANAGER
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvManager_DefaultCryptoProviderManager(TElBuiltInCryptoProviderManagerHandle * OutResult);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvManager_FIPSCompliantCryptoProviderManager(TElFIPSCompliantCryptoProviderManagerHandle * OutResult);
#endif
#endif /* SB_USE_GLOBAL_PROCS_CRYPTOPROVMANAGER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCRYPTOPROVMANAGER */
