#ifndef __INC_SBCRYPTOPROVPKCS11
#define __INC_SBCRYPTOPROVPKCS11

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcryptoprov.h"
#include "sbcryptoprovutils.h"
#include "sbcryptoprovrs.h"
#include "sbpkcs11base.h"
#include "sbpkcs11common.h"
#include "sbpkcs11certstorage.h"
#include "sbsharedresource.h"
#include "sbeccommon.h"
#include "sbasn1tree.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbrandom.h"
#include "sbstreams.h"
#include "sbstringlist.h"
#include "sbdynstruct.h"
#include "sbrdn.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElPKCS11CryptoProviderOptionsHandle;

typedef TElClassHandle TElPKCS11CryptoProviderHandle;

typedef TElClassHandle TElPKCS11CryptoKeyContainerHandle;

typedef TElClassHandle TElPKCS11CryptoObjectHandle;

typedef TElClassHandle TElPKCS11CryptoKeyHandle;

typedef TElClassHandle TElPKCS11CryptoContextHandle;

typedef TElClassHandle TElPKCS11ECParamsDirectoryHandle;

typedef uint8_t TSBPKCS11CryptoObjectOperationRaw;

typedef enum
{
	pcooGenerateKeyPair = 0,
	pcooGenerateKey = 1,
	pcooCreatePublicKey = 2,
	pcooCreatePrivateKey = 3,
	pcooCreateDomainParams = 4,
	pcooCreateSecretKey = 5,
	pcooCreateCertificate = 6,
	pcooCreateData = 7
} TSBPKCS11CryptoObjectOperation;

typedef void (SB_CALLBACK *TSBPKCS11CryptoProviderAttributesPreparedEvent)(void * _ObjectData, TObjectHandle Sender, TElCustomCryptoKeyHandle CryptoKey, TSBPKCS11CryptoObjectOperationRaw Operation, TElPKCS11AttributeListHandle PubSet, TElPKCS11AttributeListHandle PrivSet);

typedef void (SB_CALLBACK *TSBPKCS11ConditionalListFunc)(void * _ObjectData, TObjectHandle Sender, TElPKCS11ObjectHandle Obj, const uint8_t pObjType[], int32_t szObjType, TElPKCS11ObjectHandle AssociatedWithObj, TObjectHandle Data, TElRelativeDistinguishedNameHandle Pars, int8_t * OutResult);

typedef uint8_t TSBPKCS11CryptoContextTypeRaw;

typedef enum
{
	cctUndefined = 0,
	cctSymCrypto = 1,
	cctPKICrypto = 2,
	cctHash = 3,
	cctHMAC = 4
} TSBPKCS11CryptoContextType;

typedef uint8_t TSBPKCS11CryptoContextOperationRaw;

typedef enum
{
	ccoUndefined = 0,
	ccoEncrypt = 1,
	ccoDecrypt = 2,
	ccoSign = 3,
	ccoVerify = 4,
	ccoSignDetached = 5,
	ccoVerifyDetached = 6,
	ccoHash = 7
} TSBPKCS11CryptoContextOperation;

#ifdef SB_USE_CLASS_TELPKCS11CRYPTOPROVIDEROPTIONS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_Assign(TElPKCS11CryptoProviderOptionsHandle _Handle, TElCustomCryptoProviderOptionsHandle Options);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_get_UseForPublicKeyOperations(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_set_UseForPublicKeyOperations(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_get_UseForSymmetricKeyOperations(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_set_UseForSymmetricKeyOperations(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_get_UseForHashingOperations(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_set_UseForHashingOperations(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_get_UseForNonPrivateOperations(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_set_UseForNonPrivateOperations(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_get_ForceUseForIndirectHashingOperations(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_set_ForceUseForIndirectHashingOperations(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_get_DelayedPublicKeyImport(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_set_DelayedPublicKeyImport(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_get_ThreadSafe(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_set_ThreadSafe(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_get_IgnoreReportedSupportedAlgorithms(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_set_IgnoreReportedSupportedAlgorithms(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_get_NormalizeSourceLength(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_set_NormalizeSourceLength(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_get_OperationPIN(TElPKCS11CryptoProviderOptionsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_set_OperationPIN(TElPKCS11CryptoProviderOptionsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_get_DefaultRSAPublicExponent(TElPKCS11CryptoProviderOptionsHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_set_DefaultRSAPublicExponent(TElPKCS11CryptoProviderOptionsHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_get_AutoDetectStructAlignment(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_set_AutoDetectStructAlignment(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_get_CreatePublicKeyObjects(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_set_CreatePublicKeyObjects(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_get_SmartKeyImport(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_set_SmartKeyImport(TElPKCS11CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProviderOptions_Create(TElCustomCryptoProviderOptionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11CRYPTOPROVIDEROPTIONS */

#ifdef SB_USE_CLASS_TELPKCS11CRYPTOPROVIDER
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_Init(TElPKCS11CryptoProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_Deinit(TElPKCS11CryptoProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_SetAsDefault();
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_SetAsDefault_1(TElPKCS11CryptoProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_Clone(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_IsAlgorithmSupported(TElPKCS11CryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_IsAlgorithmSupported_1(TElPKCS11CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_IsOperationSupported(TElPKCS11CryptoProviderHandle _Handle, int32_t Operation, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_IsOperationSupported_1(TElPKCS11CryptoProviderHandle _Handle, int32_t Operation, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_GetAlgorithmProperty(TElPKCS11CryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, const uint8_t pPropID[], int32_t szPropID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_GetAlgorithmProperty_1(TElPKCS11CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, const uint8_t pPropID[], int32_t szPropID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_GetAlgorithmClass(TElPKCS11CryptoProviderHandle _Handle, int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_GetAlgorithmClass_1(TElPKCS11CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_GetProviderProp(TElPKCS11CryptoProviderHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_SetProviderProp(TElPKCS11CryptoProviderHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_GetDefaultInstance(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_CreateKey(TElPKCS11CryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_CreateKey_1(TElPKCS11CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_CloneKey(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoKeyHandle Key, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_ReleaseKey(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoKeyHandle * Key);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_DeleteKey(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoKeyHandle * Key);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_DecryptKey(TElPKCS11CryptoProviderHandle _Handle, void * EncKey, int32_t EncKeySize, const uint8_t pEncKeyAlgOID[], int32_t szEncKeyAlgOID, const uint8_t pEncKeyAlgParams[], int32_t szEncKeyAlgParams, TElCustomCryptoKeyHandle Key, const uint8_t pKeyAlgOID[], int32_t szKeyAlgOID, const uint8_t pKeyAlgParams[], int32_t szKeyAlgParams, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_CreateObject(TElPKCS11CryptoProviderHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_CloneObject(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoObjectHandle Obj, TElCustomCryptoObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_ReleaseObject(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_DeleteObject(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_EncryptInit(TElPKCS11CryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_EncryptInit_1(TElPKCS11CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_DecryptInit(TElPKCS11CryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_DecryptInit_1(TElPKCS11CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_SignInit(TElPKCS11CryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, int8_t Detached, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_SignInit_1(TElPKCS11CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, int8_t Detached, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_VerifyInit(TElPKCS11CryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, void * SigBuffer, int32_t SigSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_VerifyInit_1(TElPKCS11CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, void * SigBuffer, int32_t SigSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_EncryptUpdate(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_DecryptUpdate(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_SignUpdate(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_VerifyUpdate(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_EncryptFinal(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_DecryptFinal(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_SignFinal(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_VerifyFinal(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_HashInit(TElPKCS11CryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_HashInit_1(TElPKCS11CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_HashUpdate(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_HashFinal(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_ReleaseCryptoContext(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoContextHandle * Context);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_CreateKeyContainer(TElPKCS11CryptoProviderHandle _Handle, int8_t Persistent, const char * pcID, int32_t szID, TSBKeyContainerAccessModeRaw AccessMode, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_OpenKeyContainer(TElPKCS11CryptoProviderHandle _Handle, const char * pcID, int32_t szID, TSBKeyContainerAccessModeRaw AccessMode, int8_t ReadOnly, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_ReleaseKeyContainer(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoKeyContainerHandle * KeyContainer);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_DeleteKeyContainer(TElPKCS11CryptoProviderHandle _Handle, TElCustomCryptoKeyContainerHandle * KeyContainer);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_ListKeyContainers(TElPKCS11CryptoProviderHandle _Handle, TElStringListHandle IDList, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_ListKeyContainers_1(TElPKCS11CryptoProviderHandle _Handle, TElStringListHandle IDList, int32_t StartIndex, int32_t MaxCount, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_RandomInit(TElPKCS11CryptoProviderHandle _Handle, void * BaseData, int32_t BaseDataSize, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_RandomSeed(TElPKCS11CryptoProviderHandle _Handle, void * Data, int32_t DataSize);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_RandomGenerate(TElPKCS11CryptoProviderHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_RandomGenerate_1(TElPKCS11CryptoProviderHandle _Handle, int32_t MaxValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_get_OnAttributesPrepared(TElPKCS11CryptoProviderHandle _Handle, TSBPKCS11CryptoProviderAttributesPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_set_OnAttributesPrepared(TElPKCS11CryptoProviderHandle _Handle, TSBPKCS11CryptoProviderAttributesPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_Create(TComponentHandle AOwner, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoProvider_Create_1(TElCustomCryptoProviderOptionsHandle Options, TComponentHandle AOwner, TElCustomCryptoProviderHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11CRYPTOPROVIDER */

#ifdef SB_USE_CLASS_TELPKCS11CRYPTOKEYCONTAINER
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_SupportsAccessMode(TElPKCS11CryptoKeyContainerHandle _Handle, TSBKeyContainerAccessModeRaw Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_AcquireKey(TElPKCS11CryptoKeyContainerHandle _Handle, const char * pcHandle, int32_t szHandle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_ReleaseKey(TElPKCS11CryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle * Key);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_AddKey(TElPKCS11CryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_AddKeyPair(TElPKCS11CryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle PubKey, TElCustomCryptoKeyHandle PrivKey, char * pcPubKeyHandle, int32_t * szPubKeyHandle, char * pcPrivKeyHandle, int32_t * szPrivKeyHandle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_GenerateKey(TElPKCS11CryptoKeyContainerHandle _Handle, int32_t Algorithm, int32_t Bits, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_GenerateKeyPair(TElPKCS11CryptoKeyContainerHandle _Handle, int32_t Algorithm, int32_t Bits, char * pcPubKeyHandle, int32_t * szPubKeyHandle, char * pcPrivKeyHandle, int32_t * szPrivKeyHandle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_RemoveKey(TElPKCS11CryptoKeyContainerHandle _Handle, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_RemoveKey_1(TElPKCS11CryptoKeyContainerHandle _Handle, const char * pcHandle, int32_t szHandle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_ListKeys(TElPKCS11CryptoKeyContainerHandle _Handle, TElStringListHandle HandleList, const char * pcAssociatedWithHandle, int32_t szAssociatedWithHandle, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_ListKeys_1(TElPKCS11CryptoKeyContainerHandle _Handle, TElStringListHandle HandleList, const char * pcAssociatedWithHandle, int32_t szAssociatedWithHandle, int32_t StartIndex, int32_t MaxCount, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_ClearKeys(TElPKCS11CryptoKeyContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_AcquireObject(TElPKCS11CryptoKeyContainerHandle _Handle, const char * pcHandle, int32_t szHandle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_ReleaseObject(TElPKCS11CryptoKeyContainerHandle _Handle, TElCustomCryptoObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_AddObject(TElPKCS11CryptoKeyContainerHandle _Handle, TElCustomCryptoObjectHandle Obj, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_AddObject_1(TElPKCS11CryptoKeyContainerHandle _Handle, const uint8_t pObjectType[], int32_t szObjectType, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_AddObject_2(TElPKCS11CryptoKeyContainerHandle _Handle, const uint8_t pObjectType[], int32_t szObjectType, const uint8_t pData[], int32_t szData, int32_t StartIndex, int32_t Size, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_AddObject_3(TElPKCS11CryptoKeyContainerHandle _Handle, const uint8_t pObjectType[], int32_t szObjectType, TStreamHandle Stream, int64_t Count, TElRelativeDistinguishedNameHandle Params, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_RemoveObject(TElPKCS11CryptoKeyContainerHandle _Handle, const char * pcHandle, int32_t szHandle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_RemoveObject_1(TElPKCS11CryptoKeyContainerHandle _Handle, TElCustomCryptoObjectHandle Obj, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_ListObjects(TElPKCS11CryptoKeyContainerHandle _Handle, TElStringListHandle HandleList, const uint8_t pObjectType[], int32_t szObjectType, const char * pcAssociatedWithHandle, int32_t szAssociatedWithHandle, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_ListObjects_1(TElPKCS11CryptoKeyContainerHandle _Handle, TElStringListHandle HandleList, const uint8_t pObjectType[], int32_t szObjectType, const char * pcAssociatedWithHandle, int32_t szAssociatedWithHandle, int32_t StartIndex, int32_t MaxCount, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_ClearObjects(TElPKCS11CryptoKeyContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_Clone(TElPKCS11CryptoKeyContainerHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_Lock(TElPKCS11CryptoKeyContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_Unlock(TElPKCS11CryptoKeyContainerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_Update(TElPKCS11CryptoKeyContainerHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_Commit(TElPKCS11CryptoKeyContainerHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_Persistentiate(TElPKCS11CryptoKeyContainerHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_GetContainerProp(TElPKCS11CryptoKeyContainerHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_SetContainerProp(TElPKCS11CryptoKeyContainerHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_GetContainerAttribute(TElPKCS11CryptoKeyContainerHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, int8_t * Protected, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_SetContainerAttribute(TElPKCS11CryptoKeyContainerHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int8_t Protected);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKeyContainer_Create(TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11CryptoKeyContainerHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11CRYPTOKEYCONTAINER */

#ifdef SB_USE_CLASS_TELPKCS11CRYPTOOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_Clone(TElPKCS11CryptoObjectHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_Clear(TElPKCS11CryptoObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_Reset(TElPKCS11CryptoObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_Persistentiate(TElPKCS11CryptoObjectHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_Update(TElPKCS11CryptoObjectHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_Commit(TElPKCS11CryptoObjectHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_GetObjectProp(TElPKCS11CryptoObjectHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_SetObjectProp(TElPKCS11CryptoObjectHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_GetObjectAttribute(TElPKCS11CryptoObjectHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, int8_t * Protected, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_SetObjectAttribute(TElPKCS11CryptoObjectHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int8_t Protected);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_GetData(TElPKCS11CryptoObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_GetData_1(TElPKCS11CryptoObjectHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_PutData(TElPKCS11CryptoObjectHandle _Handle, TStreamHandle Data);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_PutData_1(TElPKCS11CryptoObjectHandle _Handle, const uint8_t pData[], int32_t szData, int32_t StartIndex, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoObject_Create(TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11CryptoObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11CRYPTOOBJECT */

#ifdef SB_USE_CLASS_TELPKCS11CRYPTOKEY
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_Reset(TElPKCS11CryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_Generate(TElPKCS11CryptoKeyHandle _Handle, int32_t Bits, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_ChangeAlgorithm(TElPKCS11CryptoKeyHandle _Handle, int32_t Algorithm);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_ImportPublic(TElPKCS11CryptoKeyHandle _Handle, void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_ImportSecret(TElPKCS11CryptoKeyHandle _Handle, void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_ExportPublic(TElPKCS11CryptoKeyHandle _Handle, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_ExportSecret(TElPKCS11CryptoKeyHandle _Handle, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_Clone(TElPKCS11CryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_ClonePublic(TElPKCS11CryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_ClearPublic(TElPKCS11CryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_ClearSecret(TElPKCS11CryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_GetKeyProp(TElPKCS11CryptoKeyHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_SetKeyProp(TElPKCS11CryptoKeyHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_GetKeyAttribute(TElPKCS11CryptoKeyHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, int8_t * Protected, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_SetKeyAttribute(TElPKCS11CryptoKeyHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int8_t Protected);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_PrepareForEncryption(TElPKCS11CryptoKeyHandle _Handle, int8_t MultiUse);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_PrepareForSigning(TElPKCS11CryptoKeyHandle _Handle, int8_t MultiUse);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_CancelPreparation(TElPKCS11CryptoKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_AsyncOperationFinished(TElPKCS11CryptoKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_Equals(TElPKCS11CryptoKeyHandle _Handle, TElCustomCryptoKeyHandle Source, int8_t PublicOnly, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_Matches(TElPKCS11CryptoKeyHandle _Handle, TElCustomCryptoKeyHandle Source, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_Persistentiate(TElPKCS11CryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_Update(TElPKCS11CryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_Commit(TElPKCS11CryptoKeyHandle _Handle, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoKey_Create(TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11CryptoKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11CRYPTOKEY */

#ifdef SB_USE_CLASS_TELPKCS11CRYPTOCONTEXT
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoContext_EstimateOutputSize(TElPKCS11CryptoContextHandle _Handle, int64_t InSize, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoContext_Clone(TElPKCS11CryptoContextHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoContext_GetContextProp(TElPKCS11CryptoContextHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoContext_SetContextProp(TElPKCS11CryptoContextHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoContext_Create(int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TSBPKCS11CryptoContextOperationRaw Operation, TElCustomCryptoProviderHandle Prov, TElRelativeDistinguishedNameHandle Params, TElPKCS11CryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CryptoContext_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TSBPKCS11CryptoContextOperationRaw Operation, TElCustomCryptoProviderHandle Prov, TElRelativeDistinguishedNameHandle Params, TElPKCS11CryptoContextHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11CRYPTOCONTEXT */

#ifdef SB_USE_CLASS_TELPKCS11ECPARAMSDIRECTORY
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11ECParamsDirectory_AddKnownCurve(TElPKCS11ECParamsDirectoryHandle _Handle, const char * pcName, int32_t szName, const uint8_t pCurveOID[], int32_t szCurveOID, int32_t KeyBits);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11ECParamsDirectory_GetKeyBits(TElPKCS11ECParamsDirectoryHandle _Handle, const uint8_t pCurveOID[], int32_t szCurveOID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11ECParamsDirectory_IsKnownCurve(TElPKCS11ECParamsDirectoryHandle _Handle, const uint8_t pCurveOID[], int32_t szCurveOID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11ECParamsDirectory_Create(TElPKCS11ECParamsDirectoryHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11ECPARAMSDIRECTORY */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPKCS11CryptoProviderOptions_ce_ptr;
extern zend_class_entry *TElPKCS11CryptoProvider_ce_ptr;
extern zend_class_entry *TElPKCS11CryptoKeyContainer_ce_ptr;
extern zend_class_entry *TElPKCS11CryptoObject_ce_ptr;
extern zend_class_entry *TElPKCS11CryptoKey_ce_ptr;
extern zend_class_entry *TElPKCS11CryptoContext_ce_ptr;
extern zend_class_entry *TElPKCS11ECParamsDirectory_ce_ptr;

void SB_CALLBACK TSBPKCS11CryptoProviderAttributesPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomCryptoKeyHandle CryptoKey, TSBPKCS11CryptoObjectOperationRaw Operation, TElPKCS11AttributeListHandle PubSet, TElPKCS11AttributeListHandle PrivSet);
void SB_CALLBACK TSBPKCS11ConditionalListFuncRaw(void * _ObjectData, TObjectHandle Sender, TElPKCS11ObjectHandle Obj, const uint8_t pObjType[], int32_t szObjType, TElPKCS11ObjectHandle AssociatedWithObj, TObjectHandle Data, TElRelativeDistinguishedNameHandle Pars, int8_t * OutResult);
void Register_TElPKCS11CryptoProviderOptions(TSRMLS_D);
void Register_TElPKCS11CryptoProvider(TSRMLS_D);
void Register_TElPKCS11CryptoKeyContainer(TSRMLS_D);
void Register_TElPKCS11CryptoObject(TSRMLS_D);
void Register_TElPKCS11CryptoKey(TSRMLS_D);
void Register_TElPKCS11CryptoContext(TSRMLS_D);
void Register_TElPKCS11ECParamsDirectory(TSRMLS_D);
SB_PHP_FUNCTION(SBCryptoProvPKCS11, PKCS11CryptoProvider);
void Register_SBCryptoProvPKCS11_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_CRYPTOPROVPKCS11
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvPKCS11_PKCS11CryptoProvider(TElCustomCryptoProviderHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_CRYPTOPROVPKCS11 */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCRYPTOPROVPKCS11 */

