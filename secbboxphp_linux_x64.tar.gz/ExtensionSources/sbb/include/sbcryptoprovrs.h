#ifndef __INC_SBCRYPTOPROVRS
#define __INC_SBCRYPTOPROVRS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SInvalidPublicKey 	"Invalid public key"
#define SB_SInvalidSecretKey 	"Invalid secret key"
#ifndef SB_SBufferTooSmall
#define SB_SBufferTooSmall 	"Buffer too small"
#endif
#define SB_SPrimitiveOpFailed 	"Primitive operation failed"
#define SB_SUnsupportedAlgorithmInt 	"Unsupported algorithm (%d)"
#define SB_SUnsupportedAlgorithmStr 	"Unsupported algorithm (%s)"
#define SB_SUnsupportedPropertyStr 	"Unsupported property (%s)"
#define SB_SUnknownAlgorithmProperty 	"Unknown algorithm property (%s)"
#define SB_SCryptoAPIError 	"CryptoAPI error %d"
#define SB_SUnsupportedHashAlgorithmInt 	"Unsupported hash algorithm (%d)"
#define SB_SUnsupportedPropertyValue 	"Unsupported property value (%s)"
#define SB_SUnsupportedInputIsHashValue 	"Unsupported InputIsHash value (%s)"
#define SB_SUnsupportedUseAlgorithmPrefixValue 	"Unsupported UseAlgorithmPrefix value (%s)"
#define SB_SModuleInitializationFailed 	"Module initialization failed (%s)"
#define SB_SHashAlgorithmMismatch 	"Hash algorithm mismatch (%d)"
#define SB_SCannotChangeAlgorithm 	"The algorithm cannot be changed"
#define SB_SCannotChangeROProperty 	"Cannot change read-only property"
#define SB_SNotASymmetricCipherContext 	"Not a symmetric cipher context"
#define SB_SNotAHashContext 	"Not a hash context"
#define SB_SNotAPKIContext 	"Not a public key operation context"
#define SB_SNotARC4Context 	"Not a RC4 context"
#define SB_SNotAGOST89Context 	"Not a GOST 28147-89 context"
#define SB_SNotAGOST2001Context 	"Not a GOST 34.10-2001 context"
#define SB_SNotARSAContext 	"Not a RSA context"
#define SB_SNotAECDSAContext 	"Not a ECDSA context"
#define SB_SNotAEdDSAContext 	"Not a EdDSA context"
#define SB_SCannotCloneContext 	"Cannot clone a context"
#define SB_SUnrecognizedPadding 	"Unrecognized padding mode"
#define SB_SInternalException 	"Internal exception"
#define SB_SNoIVInKeyMaterial 	"Required IV not set in key material"
#define SB_SInvalidKeyFormat 	"Invalid key format"
#define SB_SInvalidCipherMode 	"Invalid cipher mode of operation"
#define SB_SInvalidCryptoProvider 	"Invalid cryptographic provider"
#define SB_SCannotCompleteOperation 	"Cannot complete operation"
#ifndef SB_SInterruptedByUser
#define SB_SInterruptedByUser 	"Interrupted by user"
#endif
#define SB_SUnsupportedCryptoProvider 	"Unsupported crypto provider"
#define SB_SPublicKeyNotFound 	"Public key not found"
#define SB_SSecretKeyNotFound 	"Secret key not found"
#define SB_SBadKeyMaterial 	"Bad key material"
#define SB_SInvalidKeyMaterialType 	"Invalid key material type"
#ifndef SB_SSigningFailed
#define SB_SSigningFailed 	"Signing failed"
#endif
#ifndef SB_SEncryptionFailed
#define SB_SEncryptionFailed 	"Encryption failed"
#endif
#define SB_SDecryptionFailed 	"Decryption failed"
#define SB_SKEKDerivationFailed 	"KEK derivation failed"
#define SB_SUnsupportedEncryptionType 	"Encryption type"
#define SB_SOnlyDetachedSigningSupported 	"Only detached signing supported"
#define SB_SInputTooLong 	"Input too long"
#define SB_SBadSignatureFormatting 	"Bad signature formatting"
#ifndef SB_SInvalidSignature
#define SB_SInvalidSignature 	"Invalid signature"
#endif
#define SB_SCannotModifyReadOnlyProperty 	"Cannot modify read-only property"
#define SB_SKeyGenerationFailed 	"Key generation failed"
#define SB_SNotASigningAlgorithm 	"Not a signing algorithm"
#ifndef SB_SFeatureNotAvailable
#define SB_SFeatureNotAvailable 	"Feature not available"
#endif
#define SB_SFailedToModifyReadonlyProperty 	"Failed to modify read-only property"
#define SB_SUnsupportedKeyMaterial 	"Unsupported key material"
#define SB_SKeyPropertyNotSupported 	"Key does not support the property"
#define SB_SInvalidPadding 	"Invalid symmetric cipher padding"
#define SB_SKeyDecryptionFailed 	"Key decryption failed"
#define SB_SDriverNotFound 	"Driver not found"
#define SB_SUnsupportedFeature 	"Unsupported feature"
#define SB_SCannotClonePKCS11Context 	"Cannot clone PKCS#11 context"
#define SB_SCannotCloneWin32Context 	"Cannot clone Win32 context"
#define SB_SKeyAlreadyPrepared 	"Key is already prepared"
#define SB_SFailedToExportSecretKey 	"Failed to export secret key"
#define SB_SObjectNotFound 	"Object not found"
#define SB_SBadObjectType 	"Bad object type"
#define SB_SHandleNotFound 	"Handle not found"
#define SB_SMethodNotImplemented 	"Method not implemented"
#define SB_SPublicKeyTooLong 	"Public key is too long"
#define SB_SInvalidECDomainParameters 	"Invalid elliptic curve domain parameters"
#define SB_SUnknownEC 	"Unknown elliptic curve"
#define SB_SUnknownField 	"Unknown elliptic curve field"
#define SB_SInvalidKeyProperty 	"Invalid key property"
#define SB_SOperationInitializationFailed 	"Operation initialization failed"
#define SB_SInstantiationFailed 	"Failed to instantiate the type"
#define SB_SInvalidPropertyValue 	"Invalid property value"
#define SB_SUnsupportedPublicKeyFormat 	"Unsupported public key format"
#define SB_SCannotUnregisterDefaultProvider 	"Cannot unregister the default cryptographic provider"
#define SB_SContainerNotFound 	"Key container not found"
#define SB_SUnsupportedContainerAccessMode 	"Unsupported key container access mode"
#define SB_SKeyNotFromContainer 	"Key does not originate from this key container object"
#define SB_SNoObjectWithHandle 	"Object with the provided handle was not found"
#define SB_SObjectNotInitialized 	"Object has not been initialized"
#define SB_SObjectNotFromContainer 	"Object was not acquired from this container"
#define SB_SCannotCloneContainer 	"Cannot clone this container"
#define SB_SWrongKeyType 	"Wrong key type"
#define SB_SUnsupportedObjectType 	"Unsupported object type"
#define SB_SCannotChangeObject 	"Cannot change object"
#define SB_SUnsupportedContainerFormat 	"Unsupported container format"
#define SB_SUnsupportedProtection 	"Unsupported protection"
#define SB_SUnsupportedElementFormat 	"Unsupported element format"
#define SB_SProtectionInfoNotAvailable 	"Protection information is not available"
#define SB_SProtectionLocked 	"Protection locked"
#define SB_SElementUnprotectionFailed 	"Element unprotection failed"
#define SB_SNoPassword 	"No password"
#define SB_SElementAlreadyProtected 	"Element is already protected"
#define SB_SElementProtectionFailed 	"Element protection failed"
#define SB_SProtectionNotLocked 	"Protection not locked"
#define SB_SElementProtected 	"Element is protected"
#define SB_SElementChanged 	"Element has changed and needs to be re-protected before saving"
#define SB_SUnsupportedS2K 	"Unsupported S2K algorithm"
#define SB_SInvalidPassword 	"Invalid password"
#define SB_SNoFileSystemAdapter 	"No file system adapter attached"
#define SB_SContainerFileAlreadyExists 	"Container file already exists"
#define SB_SCantCreateContainerFile 	"Cannot create container file"
#define SB_SCantAccessContainerFile 	"Cannot access container file"
#define SB_SUnsupportedKeyFormat 	"Unsupported key format"
#define SB_SObjectProtected 	"Object protected"
#define SB_SNoKeyWithHandle 	"No key with the provided handle found"
#define SB_SProtectionCantBeChanged 	"Protection cannot be changed"
#define SB_SContainerNotOpened 	"Container not opened"
#define SB_SUnsupportedKeyType 	"Unsupported key type"
#define SB_SObjectReferencesExist 	"There exist unreleased references to the object"
#define SB_SContainerReadOnly 	"Container is read-only"
#define SB_SContainerPersistent 	"Container is persistent"
#define SB_SStorageReadOnly 	"Storage is read-only"
#define SB_SStoragePersistent 	"Storage is persistent"
#define SB_SBadParameter 	"Bad parameter"
#define SB_SObjectAlreadyAcquired 	"Object already acquired"
#define SB_SObjectNotAcquired 	"Object not acquired"
#define SB_SObjectIsNotASecretKey 	"Object is not a secret key"
#define SB_SObjectIsNotAPrivateKey 	"Object is not a private key"
#define SB_SObjectIsNotAGenericSecret 	"Object is not a generic secret key"
#define SB_SCannotAccessValueForNonSymmetricKeyAlgorithm 	"Cannot access value for a non-symmetric key algorithm"
#define SB_SCannotAccessValueForSymmetricKeyAlgorithm 	"Cannot access value for a symmetric key algorithm"
#define SB_SCannotImportPublicKeyToExistingObject 	"Cannot import public key to an existing key object"
#define SB_SCannotImportSecretKeyToExistingObject 	"Cannot import secret key to an existing key object"
#define SB_SObjectIsAlreadyPersistent 	"Object is already persistent"
#define SB_SKeyMaterialNotInitialized 	"Key material has not been initialized"
#define SB_SSignatureValueTooLong 	"Signature value is too long"
#define SB_SCannotModifyExistingKey 	"Cannot modify existing key"
#define SB_SNoSuitableProviderInt 	"Unsupported cryptographic operation. Operation: %d, Algorithm: %d, Mode: %d."
#define SB_SNoSuitableProviderStr 	"Unsupported cryptographic operation. Operation: %d, Algorithm: %s, Params: %s, Mode: %d."

#ifdef __cplusplus
};	/* extern "C" */
#endif

void Register_SBCryptoProvRS_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCRYPTOPROVRS */

