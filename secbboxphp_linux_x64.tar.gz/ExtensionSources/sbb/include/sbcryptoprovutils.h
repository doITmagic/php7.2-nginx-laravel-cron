#ifndef __INC_SBCRYPTOPROVUTILS
#define __INC_SBCRYPTOPROVUTILS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcryptoprov.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbrdn.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
};	/* extern "C" */
#endif

SB_PHP_FUNCTION(SBCryptoProvUtils, CryptoProvGetBoolParam);
SB_PHP_FUNCTION(SBCryptoProvUtils, GetIntegerPropFromBuffer);
SB_PHP_FUNCTION(SBCryptoProvUtils, GetInt64PropFromBuffer);
SB_PHP_FUNCTION(SBCryptoProvUtils, GetInt64PropFromString);
SB_PHP_FUNCTION(SBCryptoProvUtils, GetBufferFromInteger);
SB_PHP_FUNCTION(SBCryptoProvUtils, GetBufferFromInt64);
SB_PHP_FUNCTION(SBCryptoProvUtils, GetStringFromInt64);
SB_PHP_FUNCTION(SBCryptoProvUtils, GetBoolFromBuffer);
SB_PHP_FUNCTION(SBCryptoProvUtils, GetBufferFromBool);
SB_PHP_FUNCTION(SBCryptoProvUtils, GetPointerFromBuffer);
SB_PHP_FUNCTION(SBCryptoProvUtils, GetBufferFromPointer);
SB_PHP_FUNCTION(SBCryptoProvUtils, ExtractSymmetricCipherParams);
SB_PHP_FUNCTION(SBCryptoProvUtils, SerializeParams);
SB_PHP_FUNCTION(SBCryptoProvUtils, UnserializeParams);
SB_PHP_FUNCTION(SBCryptoProvUtils, IsKeyDrivenOperation);
SB_PHP_FUNCTION(SBCryptoProvUtils, IsSecretKeyOperation);
SB_PHP_FUNCTION(SBCryptoProvUtils, IsAlgorithmIndependentOperation);
SB_PHP_FUNCTION(SBCryptoProvUtils, GetBoolParameter);
SB_PHP_FUNCTION(SBCryptoProvUtils, GetBufferTypeParameter);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_CRYPTOPROVUTILS
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_CryptoProvGetBoolParam(TElRelativeDistinguishedNameHandle Params, const uint8_t pName[], int32_t szName, int8_t Default, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_GetIntegerPropFromBuffer(const uint8_t pValue[], int32_t szValue, int32_t Default, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_GetInt64PropFromBuffer(const uint8_t pValue[], int32_t szValue, int32_t Default, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_GetInt64PropFromString(const char * pcValue, int32_t szValue, int64_t Default, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_GetBufferFromInteger(int32_t Value, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_GetBufferFromInt64(int64_t Value, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_GetStringFromInt64(int64_t Value, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_GetBoolFromBuffer(const uint8_t pValue[], int32_t szValue, int8_t Default, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_GetBufferFromBool(int8_t Value, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_GetPointerFromBuffer(const uint8_t pValue[], int32_t szValue, void * * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_GetBufferFromPointer(void * Value, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_ExtractSymmetricCipherParams(const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t * KeyLen, uint8_t pIV[], int32_t * szIV, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_SerializeParams(TElRelativeDistinguishedNameHandle Params, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_UnserializeParams(void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_IsKeyDrivenOperation(int32_t OpType, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_IsSecretKeyOperation(int32_t OpType, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_IsAlgorithmIndependentOperation(int32_t OpType, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_GetBoolParameter(TElRelativeDistinguishedNameHandle Pars, const uint8_t pParName[], int32_t szParName, int8_t Def, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvUtils_GetBufferTypeParameter(TElRelativeDistinguishedNameHandle Pars, const uint8_t pParName[], int32_t szParName, const uint8_t pDef[], int32_t szDef, uint8_t pOutResult[], int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_CRYPTOPROVUTILS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCRYPTOPROVUTILS */

