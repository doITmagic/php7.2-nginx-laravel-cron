#ifndef __INC_SBCRYPTOPROVWIN32
#define __INC_SBCRYPTOPROVWIN32

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcryptoprov.h"
#include "sbcryptoprovutils.h"
#include "sbcryptoprovrs.h"
#include "sbsharedresource.h"
#include "sbmskeyblob.h"
#include "sbasn1tree.h"
#include "sbeccommon.h"
#ifdef SB_WINDOWS
#include "sbwincrypt.h"
#endif
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbrandom.h"
#include "sbstringlist.h"
#include "sbstrutils.h"
#ifdef SB_WINDOWS
#include "sbrdn.h"
#endif

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef SB_WINDOWS
typedef TElClassHandle TElWin32CryptoProviderOptionsHandle;

typedef TElClassHandle TElWin32CryptoProviderHandle;

typedef TElClassHandle TElCNGCryptoProviderHandleInfoHandle;

typedef TElClassHandle TElCNGCryptoProviderHandleManagerHandle;

#ifdef SB_USE_CLASS_TELWIN32CRYPTOPROVIDEROPTIONS
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_Assign(TElWin32CryptoProviderOptionsHandle _Handle, TElCustomCryptoProviderOptionsHandle Options);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseForPublicKeyOperations(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseForPublicKeyOperations(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseForSymmetricKeyOperations(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseForSymmetricKeyOperations(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseForHashingOperations(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseForHashingOperations(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseForNonPrivateOperations(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseForNonPrivateOperations(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_ThreadSafe(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_ThreadSafe(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseBaseCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseBaseCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseStrongCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseStrongCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseEnhancedCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseEnhancedCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseAESCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseAESCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseDSSCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseDSSCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseBaseDSSDHCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseBaseDSSDHCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseEnhancedDSSDHCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseEnhancedDSSDHCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseRSASchannelCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseRSASchannelCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseRSASignatureCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseRSASignatureCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseECDSASigCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseECDSASigCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseECNRASigCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseECNRASigCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseECDSAFullCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseECDSAFullCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseECNRAFullCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseECNRAFullCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseDHSchannelCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseDHSchannelCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseCPGOST(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseCPGOST(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseCNGProvider(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseCNGProvider(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_FIPSMode(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_FIPSMode(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_CacheKeyContexts(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_CacheKeyContexts(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_StorePublicKeysInMemoryContainers(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_StorePublicKeysInMemoryContainers(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_ForceEnhancedCSPForLongKeys(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_ForceEnhancedCSPForLongKeys(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_AutoSelectEnhancedCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_AutoSelectEnhancedCSP(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_TryAlternativeKeySpecOnFailure(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_TryAlternativeKeySpecOnFailure(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_GenerateExportablePrivateKeys(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_GenerateExportablePrivateKeys(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_get_UseLocalMachineAccount(TElWin32CryptoProviderOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_set_UseLocalMachineAccount(TElWin32CryptoProviderOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProviderOptions_Create(TElCustomCryptoProviderOptionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELWIN32CRYPTOPROVIDEROPTIONS */

#ifdef SB_USE_CLASS_TELWIN32CRYPTOPROVIDER
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_Init(TElWin32CryptoProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_Deinit(TElWin32CryptoProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_SetAsDefault();
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_SetAsDefault_1(TElWin32CryptoProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_IsAlgorithmSupported(TElWin32CryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_IsAlgorithmSupported_1(TElWin32CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_IsOperationSupported(TElWin32CryptoProviderHandle _Handle, int32_t Operation, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_IsOperationSupported_1(TElWin32CryptoProviderHandle _Handle, int32_t Operation, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_GetAlgorithmProperty(TElWin32CryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, const uint8_t pPropID[], int32_t szPropID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_GetAlgorithmProperty_1(TElWin32CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, const uint8_t pPropID[], int32_t szPropID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_GetAlgorithmClass(TElWin32CryptoProviderHandle _Handle, int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_GetAlgorithmClass_1(TElWin32CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_GetDefaultInstance(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_CreateKey(TElWin32CryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_CreateKey_1(TElWin32CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_CloneKey(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoKeyHandle Key, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_ReleaseKey(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoKeyHandle * Key);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_DeleteKey(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoKeyHandle * Key);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_DecryptKey(TElWin32CryptoProviderHandle _Handle, void * EncKey, int32_t EncKeySize, const uint8_t pEncKeyAlgOID[], int32_t szEncKeyAlgOID, const uint8_t pEncKeyAlgParams[], int32_t szEncKeyAlgParams, TElCustomCryptoKeyHandle Key, const uint8_t pKeyAlgOID[], int32_t szKeyAlgOID, const uint8_t pKeyAlgParams[], int32_t szKeyAlgParams, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_EncryptInit(TElWin32CryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_EncryptInit_1(TElWin32CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_DecryptInit(TElWin32CryptoProviderHandle _Handle, int32_t Algorithm, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_DecryptInit_1(TElWin32CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, int32_t Mode, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_SignInit(TElWin32CryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, int8_t Detached, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_SignInit_1(TElWin32CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, int8_t Detached, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_VerifyInit(TElWin32CryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, void * SigBuffer, int32_t SigSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_VerifyInit_1(TElWin32CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, void * SigBuffer, int32_t SigSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_EncryptUpdate(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_DecryptUpdate(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_SignUpdate(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_VerifyUpdate(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_EncryptFinal(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_DecryptFinal(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_SignFinal(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_VerifyFinal(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t * Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_HashInit(TElWin32CryptoProviderHandle _Handle, int32_t Algorithm, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_HashInit_1(TElWin32CryptoProviderHandle _Handle, const uint8_t pAlgOID[], int32_t szAlgOID, const uint8_t pAlgParams[], int32_t szAlgParams, TElCustomCryptoKeyHandle Key, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, TElCustomCryptoContextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_HashUpdate(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, void * Buffer, int32_t Size, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_HashFinal(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoContextHandle Context, TElRelativeDistinguishedNameHandle Params, TSBProgressFunc pMethodProgressFunc, void * pDataProgressFunc, void * ProgressData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_ReleaseCryptoContext(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoContextHandle * Context);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_CreateObject(TElWin32CryptoProviderHandle _Handle, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_CloneObject(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoObjectHandle Obj, TElCustomCryptoObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_ReleaseObject(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_DeleteObject(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_CreateKeyContainer(TElWin32CryptoProviderHandle _Handle, int8_t Persistent, const char * pcID, int32_t szID, TSBKeyContainerAccessModeRaw AccessMode, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_OpenKeyContainer(TElWin32CryptoProviderHandle _Handle, const char * pcID, int32_t szID, TSBKeyContainerAccessModeRaw AccessMode, int8_t ReadOnly, TElRelativeDistinguishedNameHandle Params, TElCustomCryptoKeyContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_ReleaseKeyContainer(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoKeyContainerHandle * KeyContainer);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_DeleteKeyContainer(TElWin32CryptoProviderHandle _Handle, TElCustomCryptoKeyContainerHandle * KeyContainer);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_ListKeyContainers(TElWin32CryptoProviderHandle _Handle, TElStringListHandle IDList, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_ListKeyContainers_1(TElWin32CryptoProviderHandle _Handle, TElStringListHandle IDList, int32_t StartIndex, int32_t MaxCount, TElRelativeDistinguishedNameHandle Params, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_RandomInit(TElWin32CryptoProviderHandle _Handle, void * BaseData, int32_t BaseDataSize, TElRelativeDistinguishedNameHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_RandomSeed(TElWin32CryptoProviderHandle _Handle, void * Data, int32_t DataSize);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_RandomGenerate(TElWin32CryptoProviderHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_RandomGenerate_1(TElWin32CryptoProviderHandle _Handle, int32_t MaxValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_GetProviderProp(TElWin32CryptoProviderHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_SetProviderProp(TElWin32CryptoProviderHandle _Handle, const uint8_t pPropID[], int32_t szPropID, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_get_TryEnhancedCryptoProvider(TElWin32CryptoProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_set_TryEnhancedCryptoProvider(TElWin32CryptoProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_get_NativeSizeCalculation(TElWin32CryptoProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_set_NativeSizeCalculation(TElWin32CryptoProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_Create(TComponentHandle AOwner, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWin32CryptoProvider_Create_1(TElCustomCryptoProviderOptionsHandle Options, TComponentHandle AOwner, TElCustomCryptoProviderHandle * OutResult);
#endif /* SB_USE_CLASS_TELWIN32CRYPTOPROVIDER */

#ifdef SB_USE_CLASS_TELCNGCRYPTOPROVIDERHANDLEINFO
#endif /* SB_USE_CLASS_TELCNGCRYPTOPROVIDERHANDLEINFO */

#ifdef SB_USE_CLASS_TELCNGCRYPTOPROVIDERHANDLEMANAGER
#ifndef CPU64
SB_IMPORT uint32_t SB_APIENTRY TElCNGCryptoProviderHandleManager_FreeCNGStorageProvider(TElCNGCryptoProviderHandleManagerHandle _Handle, uint32_t hProvider);
SB_IMPORT uint32_t SB_APIENTRY TElCNGCryptoProviderHandleManager_CNGStorageProviderAddRef(TElCNGCryptoProviderHandleManagerHandle _Handle, uint32_t hProvider);
#else
SB_IMPORT uint32_t SB_APIENTRY TElCNGCryptoProviderHandleManager_FreeCNGStorageProvider(TElCNGCryptoProviderHandleManagerHandle _Handle, uint64_t hProvider);
SB_IMPORT uint32_t SB_APIENTRY TElCNGCryptoProviderHandleManager_CNGStorageProviderAddRef(TElCNGCryptoProviderHandleManagerHandle _Handle, uint64_t hProvider);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElCNGCryptoProviderHandleManager_Create(TElCNGCryptoProviderHandleManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELCNGCRYPTOPROVIDERHANDLEMANAGER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElWin32CryptoProviderOptions_ce_ptr;
extern zend_class_entry *TElWin32CryptoProvider_ce_ptr;
extern zend_class_entry *TElCNGCryptoProviderHandleInfo_ce_ptr;
extern zend_class_entry *TElCNGCryptoProviderHandleManager_ce_ptr;

void Register_TElWin32CryptoProviderOptions(TSRMLS_D);
void Register_TElWin32CryptoProvider(TSRMLS_D);
void Register_TElCNGCryptoProviderHandleInfo(TSRMLS_D);
void Register_TElCNGCryptoProviderHandleManager(TSRMLS_D);
SB_PHP_FUNCTION(SBCryptoProvWin32, Win32CryptoProvider);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_CRYPTOPROVWIN32
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvWin32_Win32CryptoProvider(TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBCryptoProvWin32_Win32CryptoProvider_1(TElWin32CryptoProviderOptionsHandle OptionsTemplate, TElCustomCryptoProviderHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_CRYPTOPROVWIN32 */
#endif

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCRYPTOPROVWIN32 */
