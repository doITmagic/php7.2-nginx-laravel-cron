#ifndef __INC_SBCUSTOMCERTSTORAGE
#define __INC_SBCUSTOMCERTSTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbcryptoprov.h"
#include "sbrdn.h"
#include "sbsymmetriccrypto.h"
#include "sbx509.h"
#include "sbx509ext.h"
#include "sbcrl.h"
#include "sbpem.h"
#include "sbjks.h"
#include "sbstreams.h"
#include "sbsharedresource.h"
#include "sbconstants.h"
#include "sbencoding.h"
#include "sbtypes.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElCustomCertStorageHandle;

typedef TElCustomCertStorageHandle ElCustomCertStorageHandle;

typedef TElClassHandle TElCertificateLookupHandle;

typedef TElCertificateLookupHandle ElCertificateLookupHandle;

typedef TElClassHandle TElMemoryCertStorageHandle;

typedef TElMemoryCertStorageHandle ElMemoryCertStorageHandle;

typedef TElClassHandle TElFileCertStorageHandle;

typedef TElFileCertStorageHandle ElFileCertStorageHandle;

typedef uint8_t TSBLookupCriterionRaw;

typedef enum
{
	lcIssuer = 0,
	lcSubject = 1,
	lcValidity = 2,
	lcPublicKeyAlgorithm = 3,
	lcSignatureAlgorithm = 4,
	lcPublicKeySize = 5,
	lcAuthorityKeyIdentifier = 6,
	lcSubjectKeyIdentifier = 7,
	lcKeyUsage = 8,
	lcEmail = 9,
	lcSerialNumber = 10,
	lcPublicKeyHash = 11,
	lcCertificateHash = 12
} TSBLookupCriterion;

typedef uint32_t TSBLookupCriteriaRaw;

typedef enum 
{
	f_lcIssuer = 1,
	f_lcSubject = 2,
	f_lcValidity = 4,
	f_lcPublicKeyAlgorithm = 8,
	f_lcSignatureAlgorithm = 16,
	f_lcPublicKeySize = 32,
	f_lcAuthorityKeyIdentifier = 64,
	f_lcSubjectKeyIdentifier = 128,
	f_lcKeyUsage = 256,
	f_lcEmail = 512,
	f_lcSerialNumber = 1024,
	f_lcPublicKeyHash = 2048,
	f_lcCertificateHash = 4096
} TSBLookupCriteria;

typedef uint8_t TSBLookupOptionRaw;

typedef enum
{
	loExactMatch = 0,
	loMatchAll = 1,
	loCompareRDNAsStrings = 2
} TSBLookupOption;

typedef uint32_t TSBLookupOptionsRaw;

typedef enum 
{
	f_loExactMatch = 1,
	f_loMatchAll = 2,
	f_loCompareRDNAsStrings = 4
} TSBLookupOptions;

typedef uint8_t TSBDateLookupOptionRaw;

typedef enum
{
	dloBefore = 0,
	dloAfter = 1,
	dloBetween = 2
} TSBDateLookupOption;

typedef uint32_t TSBDateLookupOptionsRaw;

typedef enum 
{
	f_dloBefore = 1,
	f_dloAfter = 2,
	f_dloBetween = 4
} TSBDateLookupOptions;

typedef uint8_t TSBKeySizeLookupOptionRaw;

typedef enum
{
	ksloSmaller = 0,
	ksloGreater = 1,
	ksloBetween = 2
} TSBKeySizeLookupOption;

typedef uint8_t TSBKeyUsageLookupOptionRaw;

typedef enum
{
	kuloMatchAll = 0
} TSBKeyUsageLookupOption;

typedef uint32_t TSBKeyUsageLookupOptionsRaw;

typedef enum 
{
	f_kuloMatchAll = 1
} TSBKeyUsageLookupOptions;

typedef uint8_t TSBCertStorageOptionRaw;

typedef enum
{
	csoStrictChainBuilding = 0,
	csoIgnoreInvalidCertificates = 1
} TSBCertStorageOption;

typedef uint32_t TSBCertStorageOptionsRaw;

typedef enum 
{
	f_csoStrictChainBuilding = 1,
	f_csoIgnoreInvalidCertificates = 2
} TSBCertStorageOptions;

typedef void (SB_CALLBACK *TSBCertificateValidationEvent)(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle Certificate, TElCustomCertStorageHandle AdditionalCertificates, TSBCertificateValidityRaw * Validity, TSBCertificateValidityReasonRaw * Reason, int8_t * DoContinue);

typedef uint8_t TSBFileCertStorageAccessTypeRaw;

typedef enum
{
	csatImmediate = 0,
	csatOnDemand = 1
} TSBFileCertStorageAccessType;

typedef uint8_t TSBFileCertStorageSaveOptionRaw;

typedef enum
{
	fcsoSaveOnDestroy = 0,
	fcsoSaveOnFilenameChange = 1,
	fcsoSaveOnChange = 2
} TSBFileCertStorageSaveOption;

typedef uint32_t TSBFileCertStorageSaveOptionsRaw;

typedef enum 
{
	f_fcsoSaveOnDestroy = 1,
	f_fcsoSaveOnFilenameChange = 2,
	f_fcsoSaveOnChange = 4
} TSBFileCertStorageSaveOptions;

#ifdef SB_USE_CLASS_TELCUSTOMCERTSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_Validate(TElCustomCertStorageHandle _Handle, TElX509CertificateHandle Certificate, TSBCertificateValidityReasonRaw * Reason, int64_t ValidityMoment, TSBCertificateValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_Validate_1(TElCustomCertStorageHandle _Handle, TElX509CertificateHandle Certificate, TSBCertificateValidityReasonRaw * Reason, int8_t CheckCACertDates, int64_t ValidityMoment, TSBCertificateValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_Add(TElCustomCertStorageHandle _Handle, TElX509CertificateHandle Certificate, int8_t CopyPrivateKey);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_Remove(TElCustomCertStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_ExportTo(TElCustomCertStorageHandle _Handle, TElCustomCertStorageHandle Storage);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_LoadFromBufferPKCS7(TElCustomCertStorageHandle _Handle, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToBufferPKCS7(TElCustomCertStorageHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_LoadFromStreamPKCS7(TElCustomCertStorageHandle _Handle, TStreamHandle Stream, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToStreamPKCS7(TElCustomCertStorageHandle _Handle, TStreamHandle Stream, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_LoadFromBufferPEM(TElCustomCertStorageHandle _Handle, void * Buffer, int32_t Size, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToBufferPEM(TElCustomCertStorageHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassword, int32_t szPassword, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToBufferPEM_1(TElCustomCertStorageHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassword, int32_t szPassword, int32_t EncryptionAlgorithm, TSBSymmetricCryptoModeRaw EncryptionMode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_LoadFromStreamPEM(TElCustomCertStorageHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToStreamPEM(TElCustomCertStorageHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToStreamPEM_1(TElCustomCertStorageHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t EncryptionAlgorithm, TSBSymmetricCryptoModeRaw EncryptionMode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_LoadFromBufferJKS(TElCustomCertStorageHandle _Handle, void * Buffer, const char * pcPass, int32_t szPass, int32_t Size, TElJKSPasswordEvent pMethodOnPasswordNeeded, void * pDataOnPasswordNeeded, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToBufferJKS(TElCustomCertStorageHandle _Handle, void * Buffer, const char * pcPass, int32_t szPass, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToBufferJKSEx(TElCustomCertStorageHandle _Handle, void * Buffer, const char * pcPass, int32_t szPass, int32_t * Size, TElJKSAliasNeededEvent pMethodOnAliasNeeded, void * pDataOnAliasNeeded, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_LoadFromStreamJKS(TElCustomCertStorageHandle _Handle, TStreamHandle Stream, const char * pcPass, int32_t szPass, int32_t Count, TElJKSPasswordEvent pMethodOnPasswordNeeded, void * pDataOnPasswordNeeded, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToStreamJKS(TElCustomCertStorageHandle _Handle, TStreamHandle Stream, const char * pcPass, int32_t szPass, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToStreamJKSEx(TElCustomCertStorageHandle _Handle, TStreamHandle Stream, const char * pcPass, int32_t szPass, TElJKSAliasNeededEvent pMethodOnAliasNeeded, void * pDataOnAliasNeeded, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_LoadFromBufferPFX(TElCustomCertStorageHandle _Handle, void * Buffer, int32_t Size, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToBufferPFX(TElCustomCertStorageHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassword, int32_t szPassword, int32_t KeyEncryptionAlgorithm, int32_t CertEncryptionAlgorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToBufferPFX_1(TElCustomCertStorageHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_LoadFromStreamPFX(TElCustomCertStorageHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToStreamPFX(TElCustomCertStorageHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t KeyEncryptionAlgorithm, int32_t CertEncryptionAlgorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToStreamPFX_1(TElCustomCertStorageHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_LoadFromBufferPkiPath(TElCustomCertStorageHandle _Handle, void * Buffer, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToBufferPkiPath(TElCustomCertStorageHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_LoadFromStreamPkiPath(TElCustomCertStorageHandle _Handle, TStreamHandle Stream, int32_t Count, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_SaveToStreamPkiPath(TElCustomCertStorageHandle _Handle, TStreamHandle Stream, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_BuildChain(TElCustomCertStorageHandle _Handle, TElX509CertificateHandle Certificate, TElX509CertificateChainHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_BuildChain_1(TElCustomCertStorageHandle _Handle, int32_t ChainIndex, TElX509CertificateChainHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_IndexOf(TElCustomCertStorageHandle _Handle, TElX509CertificateHandle Certificate, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_IsPresent(TElCustomCertStorageHandle _Handle, TElX509CertificateHandle Certificate, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_Clear(TElCustomCertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_FindByHash(TElCustomCertStorageHandle _Handle, const TMessageDigest160 * Digest, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_FindByHash_1(TElCustomCertStorageHandle _Handle, const TMessageDigest128 * Digest, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_GetIssuerCertificate(TElCustomCertStorageHandle _Handle, TElX509CertificateHandle Certificate, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_GetIssuerCertificates(TElCustomCertStorageHandle _Handle, TElX509CertificateHandle Certificate, TListHandle List, int8_t ExcludeDuplicates);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_IsReadOnly(int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_IsReadOnly_1(TElCustomCertStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_FindFirst(TElCustomCertStorageHandle _Handle, TElCertificateLookupHandle Lookup, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_FindNext(TElCustomCertStorageHandle _Handle, TElCertificateLookupHandle Lookup, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_ImportFrom(TElCustomCertStorageHandle _Handle, TElX509CertificateChainHandle Chain);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_ImportFrom_1(TElCustomCertStorageHandle _Handle, TElX509CertificateChainHandle Chain, int8_t ImportEndEntity);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_BeginRead(TElCustomCertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_Contains(TElCustomCertStorageHandle _Handle, TElX509CertificateHandle Certificate, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_EndRead(TElCustomCertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_get_Count(TElCustomCertStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_get_ChainCount(TElCustomCertStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_get_Certificates(TElCustomCertStorageHandle _Handle, int32_t Index, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_get_Chains(TElCustomCertStorageHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_get_CRL(TElCustomCertStorageHandle _Handle, TElAbstractCRLHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_set_CRL(TElCustomCertStorageHandle _Handle, TElAbstractCRLHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_get_CryptoProviderManager(TElCustomCertStorageHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_set_CryptoProviderManager(TElCustomCertStorageHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_get_Options(TElCustomCertStorageHandle _Handle, TSBCertStorageOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_set_Options(TElCustomCertStorageHandle _Handle, TSBCertStorageOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomCertStorage_Create(TComponentHandle Owner, TElCustomCertStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMCERTSTORAGE */

#ifdef SB_USE_CLASS_TELCERTIFICATELOOKUP
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_AuthorityKeyIdentifier(TElCertificateLookupHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_AuthorityKeyIdentifier(TElCertificateLookupHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_SubjectKeyIdentifier(TElCertificateLookupHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_SubjectKeyIdentifier(TElCertificateLookupHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_SerialNumber(TElCertificateLookupHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_SerialNumber(TElCertificateLookupHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_PublicKeyHash(TElCertificateLookupHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_PublicKeyHash(TElCertificateLookupHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_CertificateHash(TElCertificateLookupHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_CertificateHash(TElCertificateLookupHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_Criteria(TElCertificateLookupHandle _Handle, TSBLookupCriteriaRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_Criteria(TElCertificateLookupHandle _Handle, TSBLookupCriteriaRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_Options(TElCertificateLookupHandle _Handle, TSBLookupOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_Options(TElCertificateLookupHandle _Handle, TSBLookupOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_IssuerRDN(TElCertificateLookupHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_SubjectRDN(TElCertificateLookupHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_ValidFrom(TElCertificateLookupHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_ValidFrom(TElCertificateLookupHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_ValidTo(TElCertificateLookupHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_ValidTo(TElCertificateLookupHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_PublicKeyAlgorithm(TElCertificateLookupHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_PublicKeyAlgorithm(TElCertificateLookupHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_SignatureAlgorithm(TElCertificateLookupHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_SignatureAlgorithm(TElCertificateLookupHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_PublicKeySizeMin(TElCertificateLookupHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_PublicKeySizeMin(TElCertificateLookupHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_PublicKeySizeMax(TElCertificateLookupHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_PublicKeySizeMax(TElCertificateLookupHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_KeyUsage(TElCertificateLookupHandle _Handle, TSBKeyUsageRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_KeyUsage(TElCertificateLookupHandle _Handle, TSBKeyUsageRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_EmailAddresses(TElCertificateLookupHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_PublicKeyHashAlgorithm(TElCertificateLookupHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_PublicKeyHashAlgorithm(TElCertificateLookupHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_CertificateHashAlgorithm(TElCertificateLookupHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_CertificateHashAlgorithm(TElCertificateLookupHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_DateLookupOptions(TElCertificateLookupHandle _Handle, TSBDateLookupOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_DateLookupOptions(TElCertificateLookupHandle _Handle, TSBDateLookupOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_KeySizeLookupOption(TElCertificateLookupHandle _Handle, TSBKeySizeLookupOptionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_KeySizeLookupOption(TElCertificateLookupHandle _Handle, TSBKeySizeLookupOptionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_get_KeyUsageLookupOptions(TElCertificateLookupHandle _Handle, TSBKeyUsageLookupOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_set_KeyUsageLookupOptions(TElCertificateLookupHandle _Handle, TSBKeyUsageLookupOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateLookup_Create(TComponentHandle AOwner, TElCertificateLookupHandle * OutResult);
#endif /* SB_USE_CLASS_TELCERTIFICATELOOKUP */

#ifdef SB_USE_CLASS_TELMEMORYCERTSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElMemoryCertStorage_Add(TElMemoryCertStorageHandle _Handle, TElX509CertificateHandle X509Certificate, int8_t CopyPrivateKey);
SB_IMPORT uint32_t SB_APIENTRY TElMemoryCertStorage_Remove(TElMemoryCertStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElMemoryCertStorage_get_CertificateList(TElMemoryCertStorageHandle _Handle, TSBObjectListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMemoryCertStorage_Create(TComponentHandle Owner, TElMemoryCertStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELMEMORYCERTSTORAGE */

#ifdef SB_USE_CLASS_TELFILECERTSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_Validate(TElFileCertStorageHandle _Handle, TElX509CertificateHandle Certificate, TSBCertificateValidityReasonRaw * Reason, int8_t CheckCACertDates, int64_t ValidityMoment, TSBCertificateValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_Validate_1(TElCustomCertStorageHandle _Handle, TElX509CertificateHandle Certificate, TSBCertificateValidityReasonRaw * Reason, int64_t ValidityMoment, TSBCertificateValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_Add(TElFileCertStorageHandle _Handle, TElX509CertificateHandle X509Certificate, int8_t CopyPrivateKey);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_Remove(TElFileCertStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_Clear(TElFileCertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_SaveToFile(TElFileCertStorageHandle _Handle, const char * pcFileName, int32_t szFileName);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_Reload(TElFileCertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_Save(TElFileCertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_get_FileName(TElFileCertStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_set_FileName(TElFileCertStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_get_AccessType(TElFileCertStorageHandle _Handle, TSBFileCertStorageAccessTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_set_AccessType(TElFileCertStorageHandle _Handle, TSBFileCertStorageAccessTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_get_SaveOptions(TElFileCertStorageHandle _Handle, TSBFileCertStorageSaveOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_set_SaveOptions(TElFileCertStorageHandle _Handle, TSBFileCertStorageSaveOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElFileCertStorage_Create(TComponentHandle Owner, TElFileCertStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELFILECERTSTORAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElCustomCertStorage_ce_ptr;
extern zend_class_entry *TElCertificateLookup_ce_ptr;
extern zend_class_entry *TElMemoryCertStorage_ce_ptr;
extern zend_class_entry *TElFileCertStorage_ce_ptr;

void SB_CALLBACK TSBCertificateValidationEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle Certificate, TElCustomCertStorageHandle AdditionalCertificates, TSBCertificateValidityRaw * Validity, TSBCertificateValidityReasonRaw * Reason, int8_t * DoContinue);
void Register_TElCustomCertStorage(TSRMLS_D);
void Register_TElCertificateLookup(TSRMLS_D);
void Register_TElMemoryCertStorage(TSRMLS_D);
void Register_TElFileCertStorage(TSRMLS_D);
SB_PHP_FUNCTION(SBCustomCertStorage, IsIssuerCertificate);
void Register_SBCustomCertStorage_Enum_Flags(TSRMLS_D);
void Register_SBCustomCertStorage_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_CUSTOMCERTSTORAGE
SB_IMPORT uint32_t SB_APIENTRY SBCustomCertStorage_IsIssuerCertificate(TElX509CertificateHandle Subject, TElX509CertificateHandle Issuer, int8_t StrictChainBuilding, int8_t * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_CUSTOMCERTSTORAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCUSTOMCERTSTORAGE */

