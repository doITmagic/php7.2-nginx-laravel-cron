#ifndef __INC_SBCUSTOMCRYPTO
#define __INC_SBCUSTOMCRYPTO

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcryptoprov.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbstrutils.h"
#include "sbsharedresource.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElKeyMaterialHandle;

typedef TElKeyMaterialHandle ElKeyMaterialHandle;

typedef TElClassHandle TElCustomCryptoHandle;

typedef TElCustomCryptoHandle ElCustomCryptoHandle;

typedef TElClassHandle TElKeyMaterialStorageHandle;

typedef TElKeyMaterialStorageHandle ElKeyMaterialStorageHandle;

#ifdef SB_USE_CLASS_TELKEYMATERIAL
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_Generate(TElKeyMaterialHandle _Handle, int32_t Bits);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_Save(TElKeyMaterialHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_Load(TElKeyMaterialHandle _Handle, TStreamHandle Stream, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_Assign(TElKeyMaterialHandle _Handle, TElKeyMaterialHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_Equals(TElKeyMaterialHandle _Handle, TElKeyMaterialHandle Source, int8_t PublicOnly, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_Clone(TElKeyMaterialHandle _Handle, TElKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_AssignCryptoKey(TElKeyMaterialHandle _Handle, TElCustomCryptoKeyHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_Persistentiate(TElKeyMaterialHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_Invalidate(TElKeyMaterialHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_get_Exportable(TElKeyMaterialHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_get_Valid(TElKeyMaterialHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_get_Bits(TElKeyMaterialHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_get_CryptoKey(TElKeyMaterialHandle _Handle, TElCustomCryptoKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_get_Algorithm(TElKeyMaterialHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_get_KeyID(TElKeyMaterialHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_set_KeyID(TElKeyMaterialHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_get_KeySubject(TElKeyMaterialHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_set_KeySubject(TElKeyMaterialHandle _Handle, const uint8_t pValue[], int32_t szValue);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_get_ProviderName(TElKeyMaterialHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_set_ProviderName(TElKeyMaterialHandle _Handle, const char * pcValue, int32_t szValue);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_Create(TElKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterial_Create_1(TElCustomCryptoKeyHandle Key, TElCustomCryptoProviderHandle Prov, TElKeyMaterialHandle * OutResult);
#endif /* SB_USE_CLASS_TELKEYMATERIAL */

#ifdef SB_USE_CLASS_TELCUSTOMCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElCustomCrypto_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMCRYPTO */

#ifdef SB_USE_CLASS_TELKEYMATERIALSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterialStorage_Clear(TElKeyMaterialStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterialStorage_ImportFrom(TElKeyMaterialStorageHandle _Handle, TElKeyMaterialStorageHandle KeyStorage);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterialStorage_Add(TElKeyMaterialStorageHandle _Handle, TElKeyMaterialHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterialStorage_Remove(TElKeyMaterialStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterialStorage_get_KeyList(TElKeyMaterialStorageHandle _Handle, TSBObjectListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterialStorage_get_Count(TElKeyMaterialStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterialStorage_get_Keys(TElKeyMaterialStorageHandle _Handle, int32_t Index, TElKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElKeyMaterialStorage_Create(TComponentHandle Owner, TElKeyMaterialStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELKEYMATERIALSTORAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElKeyMaterial_ce_ptr;
extern zend_class_entry *TElCustomCrypto_ce_ptr;
extern zend_class_entry *TElKeyMaterialStorage_ce_ptr;

void Register_TElKeyMaterial(TSRMLS_D);
void Register_TElCustomCrypto(TSRMLS_D);
void Register_TElKeyMaterialStorage(TSRMLS_D);
void Register_SBCustomCrypto_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCUSTOMCRYPTO */
