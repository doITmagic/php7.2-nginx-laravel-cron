#ifndef __INC_SBCUSTOMFSADAPTER
#define __INC_SBCUSTOMFSADAPTER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstringlist.h"
#include "sbconstants.h"
#include "sbsharedresource.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_fileOpenRead 	1
#define SB_fileOpenWrite 	2
#define SB_fileOpenCreate 	4
#define SB_fileOpenAppend 	8
#define SB_fileOpenTruncate 	16
#define SB_fileAttributeReadonly 	1
#define SB_fileAttributeHidden 	2
#define SB_fileAttributeSystem 	4
#define SB_fileAttributeArchive 	32
#define SB_fileAttributeSymlink 	64
#define SB_entryInfoAttributes 	1
#define SB_entryInfoModifyDate 	2
#define SB_entryInfoCreateDate 	4
#define SB_entryInfoAccessDate 	8
#define SB_entryInfoAllFileDate 	14
#define SB_ERROR_FACILITY_VFS 	102400
#define SB_ERROR_VFS_ERROR_FLAG 	1024
#define SB_ERROR_VFS_CUSTOM_ERROR_FLAG 	2048
#define SB_VFS_ERROR_NO_ERROR 	0
#define SB_VFS_ERROR_FILE_NOT_FOUND 	103426
#define SB_VFS_ERROR_PATH_NOT_FOUND 	103427
#define SB_VFS_ERROR_ACCESS_DENIED 	103429
#define SB_VFS_ERROR_WRITE_PROTECT 	103443
#define SB_VFS_ERROR_ERROR_CRC 	103447
#define SB_VFS_ERROR_READ_FAILED 	103454
#define SB_VFS_ERROR_WRITE_FAILED 	103455
#define SB_VFS_ERROR_WRITE_QUOTA_EXCEEDED 	103456
#define SB_VFS_ERROR_NOT_SUPPORTED 	103474
#define SB_VFS_ERROR_INVALID_PARAMETER 	103511
#define SB_VFS_ERROR_NO_MEDIA 	104536
#define SB_VFS_UNSPECIFIED_ERROR 	104448
#define SB_SFileSystemOperationFailed 	"File system operation failed with error %d. Requested path is "

typedef TObjectHandle TElVFSHandleHandle;

typedef TElClassHandle TElVFSEntryInformationHandle;

typedef TElClassHandle TElVFSEntryInformationListHandle;

typedef TElClassHandle TElCustomFileSystemAdapterHandle;

typedef uint8_t TSBFileShareModeRaw;

typedef enum
{
	ssmExclusive = 0,
	ssmDenyRead = 1,
	ssmDenyWrite = 2,
	ssmNone = 3
} TSBFileShareMode;

typedef uint8_t TSBFileTypeRaw;

typedef enum
{
	sftUnknown = 0,
	sftFile = 1,
	sftDirectory = 2,
	sftSymLink = 3
} TSBFileType;

typedef uint8_t TSBFileSeekOriginRaw;

typedef enum
{
	sfsoBegin = 0,
	sfsoCurrent = 1,
	sfsoEnd = 2
} TSBFileSeekOrigin;

#ifdef SB_USE_CLASS_TELVFSENTRYINFORMATION
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_Assign(TElVFSEntryInformationHandle _Handle, TElVFSEntryInformationHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_get_AccessMode(TElVFSEntryInformationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_set_AccessMode(TElVFSEntryInformationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_get_Attributes(TElVFSEntryInformationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_set_Attributes(TElVFSEntryInformationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_get_DateAccessed(TElVFSEntryInformationHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_set_DateAccessed(TElVFSEntryInformationHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_get_DateCreated(TElVFSEntryInformationHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_set_DateCreated(TElVFSEntryInformationHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_get_DateModified(TElVFSEntryInformationHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_set_DateModified(TElVFSEntryInformationHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_get_FileType(TElVFSEntryInformationHandle _Handle, TSBFileTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_set_FileType(TElVFSEntryInformationHandle _Handle, TSBFileTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_get_Name(TElVFSEntryInformationHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_set_Name(TElVFSEntryInformationHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_get_FullName(TElVFSEntryInformationHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_set_FullName(TElVFSEntryInformationHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_get_OwnerName(TElVFSEntryInformationHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_set_OwnerName(TElVFSEntryInformationHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_get_Size(TElVFSEntryInformationHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_set_Size(TElVFSEntryInformationHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformation_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELVFSENTRYINFORMATION */

#ifdef SB_USE_CLASS_TELVFSENTRYINFORMATIONLIST
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformationList_Add(TElVFSEntryInformationListHandle _Handle, TElVFSEntryInformationHandle Item);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformationList_Remove(TElVFSEntryInformationListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformationList_get_Count(TElVFSEntryInformationListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformationList_get_Item(TElVFSEntryInformationListHandle _Handle, int32_t index, TElVFSEntryInformationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVFSEntryInformationList_Create(TElVFSEntryInformationListHandle * OutResult);
#endif /* SB_USE_CLASS_TELVFSENTRYINFORMATIONLIST */

#ifdef SB_USE_CLASS_TELCUSTOMFILESYSTEMADAPTER
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_Clone(TElCustomFileSystemAdapterHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_NameMatchesMask(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, const char * pcMask, int32_t szMask, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_GetFileStream(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, uint32_t OpenMode, TSBFileShareModeRaw ShareMode, TStreamHandle * FileStream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_FileOpen(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, uint32_t OpenMode, TSBFileShareModeRaw ShareMode, TObjectHandle * FileHandle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_FileClose(TElCustomFileSystemAdapterHandle _Handle, TObjectHandle FileHandle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_CloseAllFiles(TElCustomFileSystemAdapterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_FileExists(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_DirectoryExists(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_FileRead(TElCustomFileSystemAdapterHandle _Handle, TObjectHandle FileHandle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t Size, int32_t * ErrorCode, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_FileWrite(TElCustomFileSystemAdapterHandle _Handle, TObjectHandle FileHandle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t Size, int32_t * ErrorCode, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_FileGetSize(TElCustomFileSystemAdapterHandle _Handle, TObjectHandle FileHandle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_FileSetSize(TElCustomFileSystemAdapterHandle _Handle, TObjectHandle FileHandle, int64_t NewSize);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_FileGetPosition(TElCustomFileSystemAdapterHandle _Handle, TObjectHandle FileHandle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_FileSeek(TElCustomFileSystemAdapterHandle _Handle, TObjectHandle FileHandle, int64_t Position, TSBFileSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_FileGetTimes(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, int64_t * CreationTime, int64_t * ModificationTime, int64_t * LastAccessTime, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_FileSetTimes(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, int64_t CreationTime, int64_t ModificationTime, int64_t LastAccessTime, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_FileDelete(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_FileMove(TElCustomFileSystemAdapterHandle _Handle, const char * pcFromName, int32_t szFromName, const char * pcToName, int32_t szToName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_FileCopy(TElCustomFileSystemAdapterHandle _Handle, const char * pcFromName, int32_t szFromName, const char * pcToName, int32_t szToName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_WriteFileTag(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, const char * pcTagValue, int32_t szTagValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_ReadFileTag(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, char * pcTagValue, int32_t * szTagValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_DeleteFileTag(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_DirectoryMake(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_DirectoryRemove(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_EnumDirectoryEntries(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, const char * pcMask, int32_t szMask, int8_t Recursive, TElVFSEntryInformationListHandle * EntryInfos, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_GetEntryInformation(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, TElVFSEntryInformationHandle EntryInfo, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_SetEntryInformation(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, TElVFSEntryInformationHandle EntryInfo, int32_t InfoFlags, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_IsAccessible(TElCustomFileSystemAdapterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_GetDirectoryName(TElCustomFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_GetFullPath(TElCustomFileSystemAdapterHandle _Handle, const char * pcFileName, int32_t szFileName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_get_CaseSensitive(TElCustomFileSystemAdapterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_set_CaseSensitive(TElCustomFileSystemAdapterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_get_BasePath(TElCustomFileSystemAdapterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_set_BasePath(TElCustomFileSystemAdapterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_get_PathSeparator(TElCustomFileSystemAdapterHandle _Handle, char * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_set_PathSeparator(TElCustomFileSystemAdapterHandle _Handle, char Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_get_PathSeparator2(TElCustomFileSystemAdapterHandle _Handle, char * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_set_PathSeparator2(TElCustomFileSystemAdapterHandle _Handle, char Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomFileSystemAdapter_Create(TComponentHandle AOwner, TElCustomFileSystemAdapterHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMFILESYSTEMADAPTER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElVFSEntryInformation_ce_ptr;
extern zend_class_entry *TElVFSEntryInformationList_ce_ptr;
extern zend_class_entry *TElCustomFileSystemAdapter_ce_ptr;

void Register_TElVFSEntryInformation(TSRMLS_D);
void Register_TElVFSEntryInformationList(TSRMLS_D);
void Register_TElCustomFileSystemAdapter(TSRMLS_D);
SB_PHP_FUNCTION(SBCustomFSAdapter, RaiseVFSAdapterError);
SB_PHP_FUNCTION(SBCustomFSAdapter, RaiseVFSAdapterErrorEx);
void Register_SBCustomFSAdapter_Constants(int module_number TSRMLS_DC);
void Register_SBCustomFSAdapter_Enum_Flags(TSRMLS_D);
void Register_SBCustomFSAdapter_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_CUSTOMFSADAPTER
SB_IMPORT uint32_t SB_APIENTRY SBCustomFSAdapter_RaiseVFSAdapterError(int32_t ErrorCode, const char * pcFileName, int32_t szFileName);
SB_IMPORT uint32_t SB_APIENTRY SBCustomFSAdapter_RaiseVFSAdapterErrorEx(TElCustomFileSystemAdapterHandle Adapter, int32_t ErrorCode, const char * pcFileName, int32_t szFileName);
#endif /* SB_USE_GLOBAL_PROCS_CUSTOMFSADAPTER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBCUSTOMFSADAPTER */

