#ifndef __INC_SBDATASTORAGEENCODINGS
#define __INC_SBDATASTORAGEENCODINGS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbdatastorage.h"
#include "sbcomprstream.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElZlibDataStorageEncodingHandlerHandle;

#ifdef SB_USE_CLASS_TELZLIBDATASTORAGEENCODINGHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElZlibDataStorageEncodingHandler_Reset(TElZlibDataStorageEncodingHandlerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElZlibDataStorageEncodingHandler_GetOID(TElZlibDataStorageEncodingHandlerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZlibDataStorageEncodingHandler_GetDescription(TElZlibDataStorageEncodingHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZlibDataStorageEncodingHandler_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZlibDataStorageEncodingHandler_get_CompressionLevel(TElZlibDataStorageEncodingHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElZlibDataStorageEncodingHandler_set_CompressionLevel(TElZlibDataStorageEncodingHandlerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElZlibDataStorageEncodingHandler_Create(TComponentHandle AOwner, TElCustomDataStorageEncodingHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELZLIBDATASTORAGEENCODINGHANDLER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElZlibDataStorageEncodingHandler_ce_ptr;

void Register_TElZlibDataStorageEncodingHandler(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDATASTORAGEENCODINGS */

