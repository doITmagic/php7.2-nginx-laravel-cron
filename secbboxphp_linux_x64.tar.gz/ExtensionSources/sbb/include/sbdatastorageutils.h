#ifndef __INC_SBDATASTORAGEUTILS
#define __INC_SBDATASTORAGEUTILS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbasn1tree.h"
#include "sbstringlist.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_DefaultMetadataCacheLimit 	1000

typedef TElClassHandle TElProxyStreamHandle;

typedef TElClassHandle TElMetadataCacheHandle;

typedef TElClassHandle TElProtectedObjectUploadStreamHandle;

typedef TElClassHandle TElProtectedObjectReaderHandle;

typedef TElClassHandle TElProtectedObjectDownloadStreamHandle;

typedef void (SB_CALLBACK *TSBProxyStreamBeforeWriteEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size, int8_t * Skip);

typedef void (SB_CALLBACK *TSBProxyStreamReadWriteEvent)(void * _ObjectData, TObjectHandle Sender, int64_t Count);

typedef uint8_t TSBProtectedObjectMetadataLocationRaw;

typedef enum
{
	omlUnprotectedObject = 0,
	omlNoMetadata = 1,
	omlExternal = 2,
	omlExternalObject = 3,
	omlBeginning = 4,
	omlEnd = 5
} TSBProtectedObjectMetadataLocation;

typedef void (SB_CALLBACK *TSBProtectedObjectWriteEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);

typedef void (SB_CALLBACK *TSBProtectedObjectMetadataNeededEvent)(void * _ObjectData, TObjectHandle Sender, uint8_t pMetadata[], int32_t * szMetadata);

typedef uint8_t TSBProtectedObjectReadStrategyRaw;

typedef enum
{
	orsMinimizeBlockReads = 0,
	orsMinimizeTraffic = 1
} TSBProtectedObjectReadStrategy;

typedef void (SB_CALLBACK *TSBProtectedObjectBlockReadEvent)(void * _ObjectData, TObjectHandle Sender, int64_t Offset, void * Buffer, int32_t MaxSize, int32_t * Read, int8_t * Last);

typedef void (SB_CALLBACK *TSBProtectedObjectStreamReadEvent)(void * _ObjectData, TObjectHandle Sender, int64_t Offset, TStreamHandle DestStream, int64_t MaxCount, int64_t * Read, int8_t * Last);

typedef void (SB_CALLBACK *TSBProtectedObjectBodyBlockEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);

typedef void (SB_CALLBACK *TSBProtectedObjectOutputStreamNeededEvent)(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream);

typedef void (SB_CALLBACK *TSBProtectedObjectReadEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);

typedef void (SB_CALLBACK *TSBProtectedObjectMetadataReceivedEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pMetadata[], int32_t szMetadata);

typedef void (SB_CALLBACK *TSBProtectedObjectMetadataObjectNameReceivedEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcObjName, int32_t szObjName);

#ifdef SB_USE_CLASS_TELPROXYSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_Read(TElProxyStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_Write(TElProxyStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_Seek(TElProxyStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_Seek_1(TElProxyStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_get_ClientStream(TElProxyStreamHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_get_TotalRead(TElProxyStreamHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_get_OnBeforeRead(TElProxyStreamHandle _Handle, TSBProxyStreamReadWriteEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_set_OnBeforeRead(TElProxyStreamHandle _Handle, TSBProxyStreamReadWriteEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_get_OnAfterRead(TElProxyStreamHandle _Handle, TSBProxyStreamReadWriteEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_set_OnAfterRead(TElProxyStreamHandle _Handle, TSBProxyStreamReadWriteEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_get_OnBeforeWrite(TElProxyStreamHandle _Handle, TSBProxyStreamBeforeWriteEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_set_OnBeforeWrite(TElProxyStreamHandle _Handle, TSBProxyStreamBeforeWriteEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_get_OnAfterWrite(TElProxyStreamHandle _Handle, TSBProxyStreamReadWriteEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_set_OnAfterWrite(TElProxyStreamHandle _Handle, TSBProxyStreamReadWriteEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_Create(TStreamHandle AClientStream, TElProxyStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProxyStream_Create_1(TStreamHandle AClientStream, int64_t StartOffset, int64_t Size, int8_t TreatSizeAsMaxSize, TElProxyStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELPROXYSTREAM */

#ifdef SB_USE_CLASS_TELMETADATACACHE
SB_IMPORT uint32_t SB_APIENTRY TElMetadataCache_Clear(TElMetadataCacheHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElMetadataCache_Delete(TElMetadataCacheHandle _Handle, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElMetadataCache_GetMetadata(TElMetadataCacheHandle _Handle, const char * pcAObjectID, int32_t szAObjectID, uint8_t pAMetadata[], int32_t * szAMetadata, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMetadataCache_GetMetadataID(TElMetadataCacheHandle _Handle, const char * pcAObjectID, int32_t szAObjectID, char * pcAMetadataID, int32_t * szAMetadataID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMetadataCache_SetMetadata(TElMetadataCacheHandle _Handle, const char * pcAObjectID, int32_t szAObjectID, const uint8_t pAMetadata[], int32_t szAMetadata);
SB_IMPORT uint32_t SB_APIENTRY TElMetadataCache_SetMetadataID(TElMetadataCacheHandle _Handle, const char * pcAObjectID, int32_t szAObjectID, const char * pcAMetadataID, int32_t szAMetadataID);
SB_IMPORT uint32_t SB_APIENTRY TElMetadataCache_get_MaxEntries(TElMetadataCacheHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMetadataCache_set_MaxEntries(TElMetadataCacheHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMetadataCache_Create(int32_t AMaxEntries, TElMetadataCacheHandle * OutResult);
#endif /* SB_USE_CLASS_TELMETADATACACHE */

#ifdef SB_USE_CLASS_TELPROTECTEDOBJECTUPLOADSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_Read(TElProtectedObjectUploadStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_Write(TElProtectedObjectUploadStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_Seek(TElProtectedObjectUploadStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_Seek_1(TElProtectedObjectUploadStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_get_Tag(TElProtectedObjectUploadStreamHandle _Handle, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_set_Tag(TElProtectedObjectUploadStreamHandle _Handle, TObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_get_OnObjectWriteBegin(TElProtectedObjectUploadStreamHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_set_OnObjectWriteBegin(TElProtectedObjectUploadStreamHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_get_OnObjectWriteEnd(TElProtectedObjectUploadStreamHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_set_OnObjectWriteEnd(TElProtectedObjectUploadStreamHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_get_OnObjectWrite(TElProtectedObjectUploadStreamHandle _Handle, TSBProtectedObjectWriteEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_set_OnObjectWrite(TElProtectedObjectUploadStreamHandle _Handle, TSBProtectedObjectWriteEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_get_OnMetadataNeeded(TElProtectedObjectUploadStreamHandle _Handle, TSBProtectedObjectMetadataNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_set_OnMetadataNeeded(TElProtectedObjectUploadStreamHandle _Handle, TSBProtectedObjectMetadataNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_get_OnTrailerNeeded(TElProtectedObjectUploadStreamHandle _Handle, TSBProtectedObjectMetadataNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_set_OnTrailerNeeded(TElProtectedObjectUploadStreamHandle _Handle, TSBProtectedObjectMetadataNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectUploadStream_Create(TStreamHandle SourceStream, TSBProtectedObjectMetadataLocationRaw MetadataLocation, int32_t MaxPrefixSize, int64_t MaxObjectSize, int32_t MaxPostfixSize, const uint8_t pMetadata[], int32_t szMetadata, const char * pcExternalMetadataObjectName, int32_t szExternalMetadataObjectName, int64_t Count, int8_t ReleaseSourceStream, TElProtectedObjectUploadStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELPROTECTEDOBJECTUPLOADSTREAM */

#ifdef SB_USE_CLASS_TELPROTECTEDOBJECTREADER
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_ReadObjectInfo(TElProtectedObjectReaderHandle _Handle, TSBProtectedObjectReadStrategyRaw ReadStrategy);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_Write(TElProtectedObjectReaderHandle _Handle, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_FlushCachedData(TElProtectedObjectReaderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_MetadataLocation(TElProtectedObjectReaderHandle _Handle, TSBProtectedObjectMetadataLocationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_Metadata(TElProtectedObjectReaderHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_Trailer(TElProtectedObjectReaderHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_MaxMetadataSize(TElProtectedObjectReaderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_MaxObjectSize(TElProtectedObjectReaderHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_ObjectSize(TElProtectedObjectReaderHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_MaxTrailerSize(TElProtectedObjectReaderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_ExternalMetadataObjectName(TElProtectedObjectReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_MetadataLengthThreshold(TElProtectedObjectReaderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_set_MetadataLengthThreshold(TElProtectedObjectReaderHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_Tag(TElProtectedObjectReaderHandle _Handle, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_set_Tag(TElProtectedObjectReaderHandle _Handle, TObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_DestStream(TElProtectedObjectReaderHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_ObjectInfoBlockSize(TElProtectedObjectReaderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_set_ObjectInfoBlockSize(TElProtectedObjectReaderHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_OnReadBlock(TElProtectedObjectReaderHandle _Handle, TSBProtectedObjectBlockReadEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_set_OnReadBlock(TElProtectedObjectReaderHandle _Handle, TSBProtectedObjectBlockReadEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_OnReadStream(TElProtectedObjectReaderHandle _Handle, TSBProtectedObjectStreamReadEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_set_OnReadStream(TElProtectedObjectReaderHandle _Handle, TSBProtectedObjectStreamReadEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_OnHeaderProcessed(TElProtectedObjectReaderHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_set_OnHeaderProcessed(TElProtectedObjectReaderHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_OnMetadataReceived(TElProtectedObjectReaderHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_set_OnMetadataReceived(TElProtectedObjectReaderHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_OnMetadataObjectNameReceived(TElProtectedObjectReaderHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_set_OnMetadataObjectNameReceived(TElProtectedObjectReaderHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_OnTrailerReceived(TElProtectedObjectReaderHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_set_OnTrailerReceived(TElProtectedObjectReaderHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_OnObjectBodyBegin(TElProtectedObjectReaderHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_set_OnObjectBodyBegin(TElProtectedObjectReaderHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_OnObjectBodyEnd(TElProtectedObjectReaderHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_set_OnObjectBodyEnd(TElProtectedObjectReaderHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_OnObjectBodyBlock(TElProtectedObjectReaderHandle _Handle, TSBProtectedObjectBodyBlockEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_set_OnObjectBodyBlock(TElProtectedObjectReaderHandle _Handle, TSBProtectedObjectBodyBlockEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_get_OnOutputStreamNeeded(TElProtectedObjectReaderHandle _Handle, TSBProtectedObjectOutputStreamNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_set_OnOutputStreamNeeded(TElProtectedObjectReaderHandle _Handle, TSBProtectedObjectOutputStreamNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_Create(TElProtectedObjectReaderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectReader_Create_1(TStreamHandle DestStream, TElProtectedObjectReaderHandle * OutResult);
#endif /* SB_USE_CLASS_TELPROTECTEDOBJECTREADER */

#ifdef SB_USE_CLASS_TELPROTECTEDOBJECTDOWNLOADSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_FlushCachedData(TElProtectedObjectDownloadStreamHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_Read(TElProtectedObjectDownloadStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_Write(TElProtectedObjectDownloadStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_Seek(TElProtectedObjectDownloadStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_Seek_1(TElProtectedObjectDownloadStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_get_DestStream(TElProtectedObjectDownloadStreamHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_get_Tag(TElProtectedObjectDownloadStreamHandle _Handle, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_set_Tag(TElProtectedObjectDownloadStreamHandle _Handle, TObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_get_Reader(TElProtectedObjectDownloadStreamHandle _Handle, TElProtectedObjectReaderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_get_OnHeaderProcessed(TElProtectedObjectDownloadStreamHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_set_OnHeaderProcessed(TElProtectedObjectDownloadStreamHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_get_OnObjectReadBegin(TElProtectedObjectDownloadStreamHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_set_OnObjectReadBegin(TElProtectedObjectDownloadStreamHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_get_OnObjectReadEnd(TElProtectedObjectDownloadStreamHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_set_OnObjectReadEnd(TElProtectedObjectDownloadStreamHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_get_OnObjectRead(TElProtectedObjectDownloadStreamHandle _Handle, TSBProtectedObjectReadEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_set_OnObjectRead(TElProtectedObjectDownloadStreamHandle _Handle, TSBProtectedObjectReadEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_get_OnMetadataReceived(TElProtectedObjectDownloadStreamHandle _Handle, TSBProtectedObjectMetadataReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_set_OnMetadataReceived(TElProtectedObjectDownloadStreamHandle _Handle, TSBProtectedObjectMetadataReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_get_OnMetadataObjectNameReceived(TElProtectedObjectDownloadStreamHandle _Handle, TSBProtectedObjectMetadataObjectNameReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_set_OnMetadataObjectNameReceived(TElProtectedObjectDownloadStreamHandle _Handle, TSBProtectedObjectMetadataObjectNameReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_get_OnTrailerReceived(TElProtectedObjectDownloadStreamHandle _Handle, TSBProtectedObjectMetadataReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_set_OnTrailerReceived(TElProtectedObjectDownloadStreamHandle _Handle, TSBProtectedObjectMetadataReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_get_OnOutputStreamNeeded(TElProtectedObjectDownloadStreamHandle _Handle, TSBProtectedObjectOutputStreamNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_set_OnOutputStreamNeeded(TElProtectedObjectDownloadStreamHandle _Handle, TSBProtectedObjectOutputStreamNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElProtectedObjectDownloadStream_Create(TStreamHandle DestStream, int8_t ReleaseDestStream, TElProtectedObjectDownloadStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELPROTECTEDOBJECTDOWNLOADSTREAM */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElProxyStream_ce_ptr;
extern zend_class_entry *TElMetadataCache_ce_ptr;
extern zend_class_entry *TElProtectedObjectUploadStream_ce_ptr;
extern zend_class_entry *TElProtectedObjectReader_ce_ptr;
extern zend_class_entry *TElProtectedObjectDownloadStream_ce_ptr;

void SB_CALLBACK TSBProxyStreamBeforeWriteEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size, int8_t * Skip);
void SB_CALLBACK TSBProxyStreamReadWriteEventRaw(void * _ObjectData, TObjectHandle Sender, int64_t Count);
void SB_CALLBACK TSBProtectedObjectWriteEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);
void SB_CALLBACK TSBProtectedObjectMetadataNeededEventRaw(void * _ObjectData, TObjectHandle Sender, uint8_t pMetadata[], int32_t * szMetadata);
void SB_CALLBACK TSBProtectedObjectBlockReadEventRaw(void * _ObjectData, TObjectHandle Sender, int64_t Offset, void * Buffer, int32_t MaxSize, int32_t * Read, int8_t * Last);
void SB_CALLBACK TSBProtectedObjectStreamReadEventRaw(void * _ObjectData, TObjectHandle Sender, int64_t Offset, TStreamHandle DestStream, int64_t MaxCount, int64_t * Read, int8_t * Last);
void SB_CALLBACK TSBProtectedObjectBodyBlockEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);
void SB_CALLBACK TSBProtectedObjectOutputStreamNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream);
void SB_CALLBACK TSBProtectedObjectReadEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);
void SB_CALLBACK TSBProtectedObjectMetadataReceivedEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pMetadata[], int32_t szMetadata);
void SB_CALLBACK TSBProtectedObjectMetadataObjectNameReceivedEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcObjName, int32_t szObjName);
void Register_TElProxyStream(TSRMLS_D);
void Register_TElMetadataCache(TSRMLS_D);
void Register_TElProtectedObjectUploadStream(TSRMLS_D);
void Register_TElProtectedObjectReader(TSRMLS_D);
void Register_TElProtectedObjectDownloadStream(TSRMLS_D);
SB_PHP_FUNCTION(SBDataStorageUtils, TryGetStreamSize);
SB_PHP_FUNCTION(SBDataStorageUtils, PathAddExtension);
void Register_SBDataStorageUtils_Constants(int module_number TSRMLS_DC);
void Register_SBDataStorageUtils_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_DATASTORAGEUTILS
SB_IMPORT uint32_t SB_APIENTRY SBDataStorageUtils_TryGetStreamSize(TStreamHandle Stream, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBDataStorageUtils_PathAddExtension(const char * pcPathName, int32_t szPathName, const char * pcExtension, int32_t szExtension, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_DATASTORAGEUTILS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDATASTORAGEUTILS */

