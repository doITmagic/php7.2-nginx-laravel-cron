#ifndef __INC_SBDC
#define __INC_SBDC

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbdcenc.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbrdn.h"
#include "sbencoding.h"
#include "sbstreams.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_DC 	131072
#define SB_DC_ERROR_BAD_ASYNC_STATE 	131073
#define SB_DC_ERROR_BAD_ASYNC_DATA 	131074
#define SB_DC_ERROR_REMOTE_ERROR 	131075
#define SB_DC_ERROR_DC_MODULE_UNAVAILABLE 	131076
#define SB_DC_ERROR_REQUEST_UNAUTHENTICATED 	131077
#define SB_AST_STANDARD 	"standard"
#define SB_ASST_PKCS1SIG 	"pkcs1sig"
#define SB_ASST_PKCS7SIG 	"pkcs7sig"

typedef TElClassHandle TElDCBaseMessageHandle;

typedef TElClassHandle TElDCUnsupportedMessageHandle;

typedef TElClassHandle TElDCMessageMDCMessageHandle;

typedef TElClassHandle TElDCErrorMessageHandle;

typedef TElClassHandle TElDCOperationRequestMessageHandle;

typedef TElClassHandle TElDCOperationResponseMessageHandle;

typedef TElClassHandle TElDCDataMessageHandle;

typedef TElClassHandle TElDCParametersMessageHandle;

typedef TElClassHandle TElDCSignatureMessageHandle;

typedef TElClassHandle TElDCBatchMessageHandle;

typedef TElClassHandle TElDCMessageFactoryHandle;

typedef TElClassHandle TElDCAsyncStateHandle;

typedef TElClassHandle TElDCAsyncStateCollectionHandle;

typedef TElClassHandle TElDCMessageClassHandle;

typedef uint8_t TSBDCOperationRaw;

typedef enum
{
	dcUnknown = 0,
	dcRawSign = 1,
	dcPKCS7Sign = 2
} TSBDCOperation;

typedef uint8_t TSBDCRequestedCertificatesOptionRaw;

typedef enum
{
	rcoNone = 0,
	rcoSigningOnly = 1,
	rcoChain = 2,
	rcoAllAvailable = 3
} TSBDCRequestedCertificatesOption;

typedef uint8_t TSBDCAsyncSignMethodRaw;

typedef enum
{
	asmPKCS1 = 0,
	asmPKCS7 = 1
} TSBDCAsyncSignMethod;

#ifdef SB_USE_CLASS_TELDCBASEMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_Assign(TElDCBaseMessageHandle _Handle, TElDCBaseMessageHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_InitializeMessage(TElDCBaseMessageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_Clone(TElDCBaseMessageHandle _Handle, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_Clone_1(TElDCBaseMessageHandle _Handle, int8_t RenegerateID, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_SaveToNode(TElDCBaseMessageHandle _Handle, TElDCNodeHandle Node);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_LoadFromNode(TElDCBaseMessageHandle _Handle, TElDCNodeHandle Node);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_SaveToStream(TElDCBaseMessageHandle _Handle, TStreamHandle Stream, TElDCEncodingHandle Encoding, const char * pcRootNodeName, int32_t szRootNodeName);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_LoadFromStream(TElDCBaseMessageHandle _Handle, TStreamHandle Stream, TElDCEncodingHandle Encoding, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_get_ID(TElDCBaseMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_set_ID(TElDCBaseMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_get_Name(TElDCBaseMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_set_Name(TElDCBaseMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_get_Pars(TElDCBaseMessageHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_get_OriginalMessage(TElDCBaseMessageHandle _Handle, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_Create(TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCBaseMessage_Create_1(TElDCBaseMessageHandle OrigMessage, TElDCBaseMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCBASEMESSAGE */

#ifdef SB_USE_CLASS_TELDCUNSUPPORTEDMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElDCUnsupportedMessage_Assign(TElDCUnsupportedMessageHandle _Handle, TElDCBaseMessageHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDCUnsupportedMessage_Clone(TElDCUnsupportedMessageHandle _Handle, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCUnsupportedMessage_Clone_1(TElDCBaseMessageHandle _Handle, int8_t RenegerateID, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCUnsupportedMessage_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCUnsupportedMessage_Create(TElDCUnsupportedMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCUNSUPPORTEDMESSAGE */

#ifdef SB_USE_CLASS_TELDCMESSAGEMDCMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElDCMessageMDCMessage_Assign(TElDCMessageMDCMessageHandle _Handle, TElDCBaseMessageHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDCMessageMDCMessage_Clone(TElDCMessageMDCMessageHandle _Handle, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCMessageMDCMessage_Clone_1(TElDCBaseMessageHandle _Handle, int8_t RenegerateID, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCMessageMDCMessage_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCMessageMDCMessage_get_TargetID(TElDCMessageMDCMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCMessageMDCMessage_set_TargetID(TElDCMessageMDCMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCMessageMDCMessage_get_MDC(TElDCMessageMDCMessageHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCMessageMDCMessage_set_MDC(TElDCMessageMDCMessageHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCMessageMDCMessage_Create(TElDCMessageMDCMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCMESSAGEMDCMESSAGE */

#ifdef SB_USE_CLASS_TELDCERRORMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElDCErrorMessage_Assign(TElDCErrorMessageHandle _Handle, TElDCBaseMessageHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDCErrorMessage_Clone(TElDCErrorMessageHandle _Handle, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCErrorMessage_Clone_1(TElDCBaseMessageHandle _Handle, int8_t RenegerateID, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCErrorMessage_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCErrorMessage_get_Code(TElDCErrorMessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCErrorMessage_set_Code(TElDCErrorMessageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCErrorMessage_get_ErrorMessage(TElDCErrorMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCErrorMessage_set_ErrorMessage(TElDCErrorMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCErrorMessage_Create(TElDCErrorMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCERRORMESSAGE */

#ifdef SB_USE_CLASS_TELDCOPERATIONREQUESTMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_Assign(TElDCOperationRequestMessageHandle _Handle, TElDCBaseMessageHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_Clone(TElDCOperationRequestMessageHandle _Handle, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_Clone_1(TElDCBaseMessageHandle _Handle, int8_t RenegerateID, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_get_Operation(TElDCOperationRequestMessageHandle _Handle, TSBDCOperationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_set_Operation(TElDCOperationRequestMessageHandle _Handle, TSBDCOperationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_get_OperationID(TElDCOperationRequestMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_set_OperationID(TElDCOperationRequestMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_get_Source(TElDCOperationRequestMessageHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_set_Source(TElDCOperationRequestMessageHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_get_HashAlgorithm(TElDCOperationRequestMessageHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_set_HashAlgorithm(TElDCOperationRequestMessageHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_get_RequestedCertificates(TElDCOperationRequestMessageHandle _Handle, TSBDCRequestedCertificatesOptionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_set_RequestedCertificates(TElDCOperationRequestMessageHandle _Handle, TSBDCRequestedCertificatesOptionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_get_SigningCertInfo(TElDCOperationRequestMessageHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_get_TransactionID(TElDCOperationRequestMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_set_TransactionID(TElDCOperationRequestMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationRequestMessage_Create(TElDCOperationRequestMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCOPERATIONREQUESTMESSAGE */

#ifdef SB_USE_CLASS_TELDCOPERATIONRESPONSEMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationResponseMessage_InitializeMessage(TElDCOperationResponseMessageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationResponseMessage_Assign(TElDCOperationResponseMessageHandle _Handle, TElDCBaseMessageHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationResponseMessage_Clone(TElDCOperationResponseMessageHandle _Handle, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationResponseMessage_Clone_1(TElDCBaseMessageHandle _Handle, int8_t RenegerateID, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationResponseMessage_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationResponseMessage_get_Operation(TElDCOperationResponseMessageHandle _Handle, TSBDCOperationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationResponseMessage_set_Operation(TElDCOperationResponseMessageHandle _Handle, TSBDCOperationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationResponseMessage_get_OperationResult(TElDCOperationResponseMessageHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationResponseMessage_set_OperationResult(TElDCOperationResponseMessageHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationResponseMessage_get_KeysRDN(TElDCOperationResponseMessageHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationResponseMessage_Create(TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationResponseMessage_Create_1(TElDCBaseMessageHandle OrigMessage, TElDCBaseMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCOPERATIONRESPONSEMESSAGE */

#ifdef SB_USE_CLASS_TELDCDATAMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElDCDataMessage_Assign(TElDCDataMessageHandle _Handle, TElDCBaseMessageHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDCDataMessage_Clone(TElDCDataMessageHandle _Handle, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDataMessage_Clone_1(TElDCBaseMessageHandle _Handle, int8_t RenegerateID, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDataMessage_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDataMessage_get_DataID(TElDCDataMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDataMessage_set_DataID(TElDCDataMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCDataMessage_get_Data(TElDCDataMessageHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDataMessage_set_Data(TElDCDataMessageHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCDataMessage_Create(TElDCDataMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCDATAMESSAGE */

#ifdef SB_USE_CLASS_TELDCPARAMETERSMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElDCParametersMessage_Assign(TElDCParametersMessageHandle _Handle, TElDCBaseMessageHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDCParametersMessage_Clone(TElDCParametersMessageHandle _Handle, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCParametersMessage_Clone_1(TElDCBaseMessageHandle _Handle, int8_t RenegerateID, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCParametersMessage_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCParametersMessage_Create(TElDCParametersMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCPARAMETERSMESSAGE */

#ifdef SB_USE_CLASS_TELDCSIGNATUREMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElDCSignatureMessage_Assign(TElDCSignatureMessageHandle _Handle, TElDCBaseMessageHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDCSignatureMessage_Clone(TElDCSignatureMessageHandle _Handle, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSignatureMessage_Clone_1(TElDCBaseMessageHandle _Handle, int8_t RenegerateID, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSignatureMessage_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSignatureMessage_get_Targets(TElDCSignatureMessageHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSignatureMessage_get_SignatureType(TElDCSignatureMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSignatureMessage_set_SignatureType(TElDCSignatureMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCSignatureMessage_get_Signature(TElDCSignatureMessageHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSignatureMessage_set_Signature(TElDCSignatureMessageHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCSignatureMessage_get_SignatureParams(TElDCSignatureMessageHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSignatureMessage_Create(TElDCSignatureMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCSIGNATUREMESSAGE */

#ifdef SB_USE_CLASS_TELDCBATCHMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElDCBatchMessage_Assign(TElDCBatchMessageHandle _Handle, TElDCBaseMessageHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDCBatchMessage_Clone(TElDCBatchMessageHandle _Handle, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCBatchMessage_Clone_1(TElDCBaseMessageHandle _Handle, int8_t RenegerateID, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCBatchMessage_Add(TElDCBatchMessageHandle _Handle, TElDCBaseMessageHandle Message, int8_t CreateCopy, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCBatchMessage_Remove(TElDCBatchMessageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElDCBatchMessage_Clear(TElDCBatchMessageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDCBatchMessage_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCBatchMessage_get_Messages(TElDCBatchMessageHandle _Handle, int32_t Index, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCBatchMessage_get_Count(TElDCBatchMessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCBatchMessage_Create(TElDCBatchMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCBATCHMESSAGE */

#ifdef SB_USE_CLASS_TELDCMESSAGEFACTORY
SB_IMPORT uint32_t SB_APIENTRY TElDCMessageFactory_CreateInstance(TElDCMessageFactoryHandle _Handle, TStreamHandle Stream, TElDCEncodingHandle Encoding, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCMessageFactory_CreateInstance_1(TElDCMessageFactoryHandle _Handle, TElDCNodeHandle Node, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCMessageFactory_RegisterClass(TElDCMessageFactoryHandle _Handle, TElDCMessageClassHandle Cls);
SB_IMPORT uint32_t SB_APIENTRY TElDCMessageFactory_Create(TElDCMessageFactoryHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCMESSAGEFACTORY */

#ifdef SB_USE_CLASS_TELDCASYNCSTATE
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_Clear(TElDCAsyncStateHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_Clone(TElDCAsyncStateHandle _Handle, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_Assign(TElDCAsyncStateHandle _Handle, TElDCAsyncStateHandle State, int8_t CopyMessages);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_SaveToNode(TElDCAsyncStateHandle _Handle, TElDCNodeHandle Node);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_SaveToStream(TElDCAsyncStateHandle _Handle, TStreamHandle Stream, TElDCEncodingHandle Encoding);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_LoadFromNode(TElDCAsyncStateHandle _Handle, TElDCNodeHandle Node);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_LoadFromStream(TElDCAsyncStateHandle _Handle, TStreamHandle Stream, TElDCEncodingHandle Encoding);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_SubtypePresent(TElDCAsyncStateHandle _Handle, const char * pcSubtype, int32_t szSubtype, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_FindMessageByType(TElDCAsyncStateHandle _Handle, TElDCMessageClassHandle MsgType, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_FindMessageByName(TElDCAsyncStateHandle _Handle, const char * pcName, int32_t szName, TElDCBaseMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_get_Messages(TElDCAsyncStateHandle _Handle, TElDCBatchMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_get_StateType(TElDCAsyncStateHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_set_StateType(TElDCAsyncStateHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_get_StateSubtypes(TElDCAsyncStateHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_get_UserData(TElDCAsyncStateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_set_UserData(TElDCAsyncStateHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_get_Generator(TElDCAsyncStateHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_get_InnerState(TElDCAsyncStateHandle _Handle, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_Create(TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncState_Create_1(TElDCAsyncStateHandle InnerState, int8_t ReleaseOnDestruction, TElDCAsyncStateHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCASYNCSTATE */

#ifdef SB_USE_CLASS_TELDCASYNCSTATECOLLECTION
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncStateCollection_Add(TElDCAsyncStateCollectionHandle _Handle, TElDCAsyncStateHandle State, int8_t Clone, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncStateCollection_Remove(TElDCAsyncStateCollectionHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncStateCollection_Clear(TElDCAsyncStateCollectionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncStateCollection_FindState(TElDCAsyncStateCollectionHandle _Handle, const uint8_t pUserData[], int32_t szUserData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncStateCollection_SaveToNode(TElDCAsyncStateCollectionHandle _Handle, TElDCNodeHandle Node);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncStateCollection_SaveToStream(TElDCAsyncStateCollectionHandle _Handle, TStreamHandle Stream, TElDCEncodingHandle Encoding);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncStateCollection_LoadFromNode(TElDCAsyncStateCollectionHandle _Handle, TElDCNodeHandle Node);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncStateCollection_LoadFromStream(TElDCAsyncStateCollectionHandle _Handle, TStreamHandle Stream, TElDCEncodingHandle Encoding);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncStateCollection_get_UserData(TElDCAsyncStateCollectionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncStateCollection_set_UserData(TElDCAsyncStateCollectionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncStateCollection_get_States(TElDCAsyncStateCollectionHandle _Handle, int32_t Index, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncStateCollection_get_Count(TElDCAsyncStateCollectionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAsyncStateCollection_Create(int8_t OwnsObjects, TElDCAsyncStateCollectionHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCASYNCSTATECOLLECTION */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDCMessageClass_ce_ptr;
extern zend_class_entry *TElDCBaseMessage_ce_ptr;
extern zend_class_entry *TElDCUnsupportedMessage_ce_ptr;
extern zend_class_entry *TElDCMessageMDCMessage_ce_ptr;
extern zend_class_entry *TElDCErrorMessage_ce_ptr;
extern zend_class_entry *TElDCOperationRequestMessage_ce_ptr;
extern zend_class_entry *TElDCOperationResponseMessage_ce_ptr;
extern zend_class_entry *TElDCDataMessage_ce_ptr;
extern zend_class_entry *TElDCParametersMessage_ce_ptr;
extern zend_class_entry *TElDCSignatureMessage_ce_ptr;
extern zend_class_entry *TElDCBatchMessage_ce_ptr;
extern zend_class_entry *TElDCMessageFactory_ce_ptr;
extern zend_class_entry *TElDCAsyncState_ce_ptr;
extern zend_class_entry *TElDCAsyncStateCollection_ce_ptr;

void Register_TElDCBaseMessage(TSRMLS_D);
void Register_TElDCUnsupportedMessage(TSRMLS_D);
void Register_TElDCMessageMDCMessage(TSRMLS_D);
void Register_TElDCErrorMessage(TSRMLS_D);
void Register_TElDCOperationRequestMessage(TSRMLS_D);
void Register_TElDCOperationResponseMessage(TSRMLS_D);
void Register_TElDCDataMessage(TSRMLS_D);
void Register_TElDCParametersMessage(TSRMLS_D);
void Register_TElDCSignatureMessage(TSRMLS_D);
void Register_TElDCBatchMessage(TSRMLS_D);
void Register_TElDCMessageFactory(TSRMLS_D);
void Register_TElDCAsyncState(TSRMLS_D);
void Register_TElDCAsyncStateCollection(TSRMLS_D);
SB_PHP_FUNCTION(SBDC, DCBoolToStr);
SB_PHP_FUNCTION(SBDC, DCStrToBool);
SB_PHP_FUNCTION(SBDC, DCBoolToByteArray);
SB_PHP_FUNCTION(SBDC, DCByteArrayToBool);
SB_PHP_FUNCTION(SBDC, DCSigMessageSort);
void Register_SBDC_Constants(int module_number TSRMLS_DC);
void Register_SBDC_Enum_Flags(TSRMLS_D);
void Register_SBDC_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_DC
SB_IMPORT uint32_t SB_APIENTRY SBDC_DCBoolToStr(int8_t B, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBDC_DCStrToBool(const char * pcS, int32_t szS, int8_t Def, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBDC_DCBoolToByteArray(int8_t B, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBDC_DCByteArrayToBool(const uint8_t pS[], int32_t szS, int8_t Def, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBDC_DCSigMessageSort(void * Item1, void * Item2, int32_t * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_DC */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDC */

