#ifndef __INC_SBDCASN1ENC
#define __INC_SBDCASN1ENC

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbdcenc.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDCASN1EncodingHandle;

#ifdef SB_USE_CLASS_TELDCASN1ENCODING
SB_IMPORT uint32_t SB_APIENTRY TElDCASN1Encoding_Encode(TElDCASN1EncodingHandle _Handle, TElDCNodeHandle Root, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDCASN1Encoding_Decode(TElDCASN1EncodingHandle _Handle, TElDCNodeHandle Root, TStreamHandle Stream, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElDCASN1Encoding_GetName(TElDCASN1EncodingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCASN1Encoding_GetDescription(TElDCASN1EncodingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCASN1Encoding_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCASN1ENCODING */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDCASN1Encoding_ce_ptr;

void Register_TElDCASN1Encoding(TSRMLS_D);
SB_PHP_FUNCTION(SBDCASN1Enc, DCASN1Encoding);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_DCASN1ENC
SB_IMPORT uint32_t SB_APIENTRY SBDCASN1Enc_DCASN1Encoding(TElDCEncodingHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_DCASN1ENC */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDCASN1ENC */

