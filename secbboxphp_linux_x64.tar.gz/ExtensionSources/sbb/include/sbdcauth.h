#ifndef __INC_SBDCAUTH
#define __INC_SBDCAUTH

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbtypes.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbrandom.h"
#include "sbdc.h"
#include "sbdcdef.h"
#include "sbhashfunction.h"
#include "sbcustomcertstorage.h"
#include "sbx509.h"
#include "sbpkcs7utils.h"
#include "sbcustomcrypto.h"
#include "sbpublickeycrypto.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_AUTH_ERROR 	4352
#define SB_AUTH_ERROR_UNSUPPORTED_OPERATION 	4353
#define SB_AUTH_ERROR_TOKEN_READONLY 	4354
#define SB_AUTH_ERROR_OBJECT_NOT_INITIALIZED 	4355
#define SB_AUTH_ERROR_BAD_ASYNC_STATE 	4356
#define SB_AUTH_ERROR_CANCELLED_BY_USER 	4357
#define SB_AUTH_ERROR_INVALID_AUTH_TOKEN 	4358
#define SB_DC_AUTH_NONCE_LENGTH 	8

typedef TElClassHandle TElDCAuthTokenHandle;

typedef TElClassHandle TElCustomAuthenticatorHandle;

typedef TElClassHandle TElBasicDCAuthTokenHandle;

typedef TElClassHandle TElBasicDCAuthenticatorHandle;

typedef uint8_t TSBAuthResultRaw;

typedef enum
{
	arSuccess = 0,
	arFailure = 1,
	arFurtherAuthNeeded = 2
} TSBAuthResult;

typedef void (SB_CALLBACK *TSBDCAuthStartEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pData[], int32_t szData, int64_t StartTime, int8_t * DoContinue);

typedef void (SB_CALLBACK *TSBDCAuthSigningCertNeededEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pData[], int32_t szData, int64_t StartTime, TElX509CertificateHandle * Cert);

#ifdef SB_USE_CLASS_TELDCAUTHTOKEN
SB_IMPORT uint32_t SB_APIENTRY TElDCAuthToken_LoadFromStream(TElDCAuthTokenHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDCAuthToken_SaveToStream(TElDCAuthTokenHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDCAuthToken_Clear(TElDCAuthTokenHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDCAuthToken_Validate(TElDCAuthTokenHandle _Handle, TSBAuthResultRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCAuthToken_Create(TElDCAuthTokenHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCAUTHTOKEN */

#ifdef SB_USE_CLASS_TELCUSTOMAUTHENTICATOR
SB_IMPORT uint32_t SB_APIENTRY TElCustomAuthenticator_StartAuthentication(TElCustomAuthenticatorHandle _Handle, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomAuthenticator_StartAuthentication_1(TElCustomAuthenticatorHandle _Handle, const uint8_t pData[], int32_t szData, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomAuthenticator_ContinueAuthentication(TElCustomAuthenticatorHandle _Handle, TElDCAsyncStateHandle State, TElDCAsyncStateHandle * NextState, TElDCAuthTokenHandle * AuthToken, TSBAuthResultRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomAuthenticator_get_LastAuthResult(TElCustomAuthenticatorHandle _Handle, TSBAuthResultRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomAuthenticator_Create(TComponentHandle Owner, TElCustomAuthenticatorHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMAUTHENTICATOR */

#ifdef SB_USE_CLASS_TELBASICDCAUTHTOKEN
SB_IMPORT uint32_t SB_APIENTRY TElBasicDCAuthToken_Clear(TElBasicDCAuthTokenHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBasicDCAuthToken_Validate(TElBasicDCAuthTokenHandle _Handle, TSBAuthResultRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBasicDCAuthToken_Create(TElBasicDCAuthTokenHandle * OutResult);
#endif /* SB_USE_CLASS_TELBASICDCAUTHTOKEN */

#ifdef SB_USE_CLASS_TELBASICDCAUTHENTICATOR
SB_IMPORT uint32_t SB_APIENTRY TElBasicDCAuthenticator_get_HashAlgorithm(TElBasicDCAuthenticatorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBasicDCAuthenticator_set_HashAlgorithm(TElBasicDCAuthenticatorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBasicDCAuthenticator_get_CertStorage(TElBasicDCAuthenticatorHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBasicDCAuthenticator_set_CertStorage(TElBasicDCAuthenticatorHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElBasicDCAuthenticator_get_SigningCertIndex(TElBasicDCAuthenticatorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBasicDCAuthenticator_set_SigningCertIndex(TElBasicDCAuthenticatorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElBasicDCAuthenticator_get_OnAuthStart(TElBasicDCAuthenticatorHandle _Handle, TSBDCAuthStartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBasicDCAuthenticator_set_OnAuthStart(TElBasicDCAuthenticatorHandle _Handle, TSBDCAuthStartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElBasicDCAuthenticator_get_OnSigningCertNeeded(TElBasicDCAuthenticatorHandle _Handle, TSBDCAuthSigningCertNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBasicDCAuthenticator_set_OnSigningCertNeeded(TElBasicDCAuthenticatorHandle _Handle, TSBDCAuthSigningCertNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElBasicDCAuthenticator_Create(TComponentHandle Owner, TElBasicDCAuthenticatorHandle * OutResult);
#endif /* SB_USE_CLASS_TELBASICDCAUTHENTICATOR */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDCAuthToken_ce_ptr;
extern zend_class_entry *TElCustomAuthenticator_ce_ptr;
extern zend_class_entry *TElBasicDCAuthToken_ce_ptr;
extern zend_class_entry *TElBasicDCAuthenticator_ce_ptr;

void SB_CALLBACK TSBDCAuthStartEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pData[], int32_t szData, int64_t StartTime, int8_t * DoContinue);
void SB_CALLBACK TSBDCAuthSigningCertNeededEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pData[], int32_t szData, int64_t StartTime, TElX509CertificateHandle * Cert);
void Register_TElDCAuthToken(TSRMLS_D);
void Register_TElCustomAuthenticator(TSRMLS_D);
void Register_TElBasicDCAuthToken(TSRMLS_D);
void Register_TElBasicDCAuthenticator(TSRMLS_D);
void Register_SBDCAuth_Constants(int module_number TSRMLS_DC);
void Register_SBDCAuth_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDCAUTH */

