#ifndef __INC_SBDCCANONENC
#define __INC_SBDCCANONENC

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbdcenc.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDCCanonEncodingHandle;

#ifdef SB_USE_CLASS_TELDCCANONENCODING
SB_IMPORT uint32_t SB_APIENTRY TElDCCanonEncoding_Encode(TElDCCanonEncodingHandle _Handle, TElDCNodeHandle Root, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDCCanonEncoding_Decode(TElDCCanonEncodingHandle _Handle, TElDCNodeHandle Root, TStreamHandle Stream, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElDCCanonEncoding_GetName(TElDCCanonEncodingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCCanonEncoding_GetDescription(TElDCCanonEncodingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCCanonEncoding_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCCANONENCODING */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDCCanonEncoding_ce_ptr;

void Register_TElDCCanonEncoding(TSRMLS_D);
SB_PHP_FUNCTION(SBDCCanonEnc, DCCanonEncoding);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_DCCANONENC
SB_IMPORT uint32_t SB_APIENTRY SBDCCanonEnc_DCCanonEncoding(TElDCEncodingHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_DCCANONENC */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDCCANONENC */

