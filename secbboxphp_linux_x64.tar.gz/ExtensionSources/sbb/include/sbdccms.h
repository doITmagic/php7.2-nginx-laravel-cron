#ifndef __INC_SBDCCMS
#define __INC_SBDCCMS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbdc.h"
#include "sbdcdef.h"
#include "sbdcserver.h"
#include "sbdcpkiconstants.h"
#include "sbrdn.h"
#include "sbx509.h"
#include "sbasn1tree.h"
#include "sbtspclient.h"
#include "sbtspcommon.h"
#include "sbcms.h"
#include "sbcmsutils.h"
#include "sbpkicommon.h"
#include "sbstreams.h"
#include "sbstringlist.h"
#include "sbcustomcertstorage.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDCCMSSignOperationHandlerHandle;

typedef TElClassHandle TElDCServerCMSRequestSignatureHandlerHandle;

typedef void (SB_CALLBACK *TSBDCCMSPreparedEvent)(void * _ObjectData, TObjectHandle Sender, TElSignedCMSMessageHandle Msg);

typedef void (SB_CALLBACK *TSBDCCMSTSPClientNeededEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pTSPServiceID[], int32_t szTSPServiceID, TElCustomTSPClientHandle * TSPClient, int8_t * Success);

#ifdef SB_USE_CLASS_TELDCCMSSIGNOPERATIONHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElDCCMSSignOperationHandler_get_CertStorage(TElDCCMSSignOperationHandlerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCCMSSignOperationHandler_set_CertStorage(TElDCCMSSignOperationHandlerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCCMSSignOperationHandler_get_OnTSPClientNeeded(TElDCCMSSignOperationHandlerHandle _Handle, TSBDCCMSTSPClientNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCCMSSignOperationHandler_set_OnTSPClientNeeded(TElDCCMSSignOperationHandlerHandle _Handle, TSBDCCMSTSPClientNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCCMSSignOperationHandler_get_OnCMSPrepared(TElDCCMSSignOperationHandlerHandle _Handle, TSBDCCMSPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCCMSSignOperationHandler_set_OnCMSPrepared(TElDCCMSSignOperationHandlerHandle _Handle, TSBDCCMSPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCCMSSignOperationHandler_Create(TElDCCMSSignOperationHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCCMSSIGNOPERATIONHANDLER */

#ifdef SB_USE_CLASS_TELDCSERVERCMSREQUESTSIGNATUREHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElDCServerCMSRequestSignatureHandler_ValidateSignature(TElDCServerCMSRequestSignatureHandlerHandle _Handle, const uint8_t pSignature[], int32_t szSignature, const uint8_t pHash[], int32_t szHash, int32_t HashAlgorithm, TElStringListHandle SigParams);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerCMSRequestSignatureHandler_GetName(TElDCServerCMSRequestSignatureHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerCMSRequestSignatureHandler_get_OnCertificateValidate(TElDCServerCMSRequestSignatureHandlerHandle _Handle, TSBDCServerCertificateValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerCMSRequestSignatureHandler_set_OnCertificateValidate(TElDCServerCMSRequestSignatureHandlerHandle _Handle, TSBDCServerCertificateValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerCMSRequestSignatureHandler_get_OnCertificateNeeded(TElDCServerCMSRequestSignatureHandlerHandle _Handle, TSBDCServerCertificateNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerCMSRequestSignatureHandler_set_OnCertificateNeeded(TElDCServerCMSRequestSignatureHandlerHandle _Handle, TSBDCServerCertificateNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerCMSRequestSignatureHandler_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCSERVERCMSREQUESTSIGNATUREHANDLER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDCCMSSignOperationHandler_ce_ptr;
extern zend_class_entry *TElDCServerCMSRequestSignatureHandler_ce_ptr;

void SB_CALLBACK TSBDCCMSPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElSignedCMSMessageHandle Msg);
void SB_CALLBACK TSBDCCMSTSPClientNeededEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pTSPServiceID[], int32_t szTSPServiceID, TElCustomTSPClientHandle * TSPClient, int8_t * Success);
void Register_TElDCCMSSignOperationHandler(TSRMLS_D);
void Register_TElDCServerCMSRequestSignatureHandler(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDCCMS */

