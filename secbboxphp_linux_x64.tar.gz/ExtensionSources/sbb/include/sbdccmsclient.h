#ifndef __INC_SBDCCMSCLIENT
#define __INC_SBDCCMSCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbconstants.h"
#include "sbutils.h"
#include "sbdcsec.h"
#include "sbcms.h"
#include "sbx509.h"
#include "sbstreams.h"
#include "sbcustomcertstorage.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDCClientCMSRequestSignatureHandlerHandle;

typedef void (SB_CALLBACK *TSBDCBeforeCMSSignEvent)(void * _ObjectData, TObjectHandle Sender, TElCMSSignatureHandle Sig);

typedef void (SB_CALLBACK *TSBDCAfterCMSSignEvent)(void * _ObjectData, TObjectHandle Sender, TElCMSSignatureHandle Sig);

#ifdef SB_USE_CLASS_TELDCCLIENTCMSREQUESTSIGNATUREHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElDCClientCMSRequestSignatureHandler_SignHash(TElDCClientCMSRequestSignatureHandlerHandle _Handle, const uint8_t pHash[], int32_t szHash, TElDCParametersHandle Pars, TElStringListHandle SigParams, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCClientCMSRequestSignatureHandler_GetName(TElDCClientCMSRequestSignatureHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCClientCMSRequestSignatureHandler_get_OnBeforeCMSSign(TElDCClientCMSRequestSignatureHandlerHandle _Handle, TSBDCBeforeCMSSignEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCClientCMSRequestSignatureHandler_set_OnBeforeCMSSign(TElDCClientCMSRequestSignatureHandlerHandle _Handle, TSBDCBeforeCMSSignEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCClientCMSRequestSignatureHandler_get_OnAfterCMSSign(TElDCClientCMSRequestSignatureHandlerHandle _Handle, TSBDCAfterCMSSignEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCClientCMSRequestSignatureHandler_set_OnAfterCMSSign(TElDCClientCMSRequestSignatureHandlerHandle _Handle, TSBDCAfterCMSSignEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCClientCMSRequestSignatureHandler_Create(TElDCClientCMSRequestSignatureHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCCLIENTCMSREQUESTSIGNATUREHANDLER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDCClientCMSRequestSignatureHandler_ce_ptr;

void SB_CALLBACK TSBDCBeforeCMSSignEventRaw(void * _ObjectData, TObjectHandle Sender, TElCMSSignatureHandle Sig);
void SB_CALLBACK TSBDCAfterCMSSignEventRaw(void * _ObjectData, TObjectHandle Sender, TElCMSSignatureHandle Sig);
void Register_TElDCClientCMSRequestSignatureHandler(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDCCMSCLIENT */

