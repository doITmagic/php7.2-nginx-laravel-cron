#ifndef __INC_SBDCDEF
#define __INC_SBDCDEF

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbpkcs7utils.h"
#include "sbstrutils.h"
#include "sbrdn.h"
#include "sbdcpkiconstants.h"
#include "sbdcsec.h"
#include "sbhashfunction.h"
#include "sbrandom.h"
#include "sbcustomcertstorage.h"
#include "sbstreams.h"
#include "sbpublickeycrypto.h"
#include "sbcustomcrypto.h"
#include "sbx509.h"
#include "sbdcstatestorage.h"
#include "sbdccanonenc.h"
#include "sbdc.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDCPKCS7SignParametersHandle;

typedef TElClassHandle TElDCDefaultRequestFactoryHandle;

typedef uint8_t TSBDCResponseVerificationResultRaw;

typedef enum
{
	rvrSuccess = 0,
	rvrUnknown = 1,
	rvrUnsupported = 2,
	rvrUnsigned = 3,
	rvrBadSignature = 4,
	rvrExpired = 5,
	rvrDuplicate = 6
} TSBDCResponseVerificationResult;

#ifdef SB_USE_CLASS_TELDCPKCS7SIGNPARAMETERS
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_SaveToRDN(TElDCPKCS7SignParametersHandle _Handle, TElRelativeDistinguishedNameHandle Rdn);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_LoadFromRDN(TElDCPKCS7SignParametersHandle _Handle, TElRelativeDistinguishedNameHandle Rdn);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_ContentType(TElDCPKCS7SignParametersHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_ContentType(TElDCPKCS7SignParametersHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_SgnDataVersion(TElDCPKCS7SignParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_SgnDataVersion(TElDCPKCS7SignParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_SigningTime(TElDCPKCS7SignParametersHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_SigningTime(TElDCPKCS7SignParametersHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_Timestamp(TElDCPKCS7SignParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_Timestamp(TElDCPKCS7SignParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_TimestampServiceID(TElDCPKCS7SignParametersHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_TimestampServiceID(TElDCPKCS7SignParametersHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_TimestampHashAlgorithm(TElDCPKCS7SignParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_TimestampHashAlgorithm(TElDCPKCS7SignParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_IncludeCertsToSgnData(TElDCPKCS7SignParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_IncludeCertsToSgnData(TElDCPKCS7SignParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_IncludeCRLsToSgnData(TElDCPKCS7SignParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_IncludeCRLsToSgnData(TElDCPKCS7SignParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_IncludeRevInfoToAttributes(TElDCPKCS7SignParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_IncludeRevInfoToAttributes(TElDCPKCS7SignParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_IncludeCertChain(TElDCPKCS7SignParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_IncludeCertChain(TElDCPKCS7SignParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_InsertMessageDigests(TElDCPKCS7SignParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_InsertMessageDigests(TElDCPKCS7SignParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_InsertSigningTime(TElDCPKCS7SignParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_InsertSigningTime(TElDCPKCS7SignParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_InsertContentType(TElDCPKCS7SignParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_InsertContentType(TElDCPKCS7SignParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_InsertSigningCertificateAttr(TElDCPKCS7SignParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_InsertSigningCertificateAttr(TElDCPKCS7SignParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_IgnoreTimestampFailure(TElDCPKCS7SignParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_IgnoreTimestampFailure(TElDCPKCS7SignParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_UseGeneralizedTimeFormat(TElDCPKCS7SignParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_UseGeneralizedTimeFormat(TElDCPKCS7SignParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_ForceSigningCertificateV2Usage(TElDCPKCS7SignParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_ForceSigningCertificateV2Usage(TElDCPKCS7SignParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_UseUndefSize(TElDCPKCS7SignParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_set_UseUndefSize(TElDCPKCS7SignParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_CustomSignedAttributes(TElDCPKCS7SignParametersHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_CustomUnsignedAttributes(TElDCPKCS7SignParametersHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_get_CustomOptions(TElDCPKCS7SignParametersHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignParameters_Create(TElDCPKCS7SignParametersHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCPKCS7SIGNPARAMETERS */

#ifdef SB_USE_CLASS_TELDCDEFAULTREQUESTFACTORY
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_CreatePKCS1SignRequest(TElDCDefaultRequestFactoryHandle _Handle, const char * pcOpName, int32_t szOpName, const uint8_t pSource[], int32_t szSource, int32_t HashAlgorithm, int8_t IncludeKeysInResponse, char * pcTransactionID, int32_t * szTransactionID, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_CreatePKCS1SignRequest_1(TElDCDefaultRequestFactoryHandle _Handle, const char * pcOpName, int32_t szOpName, const uint8_t pSource[], int32_t szSource, int32_t HashAlgorithm, int8_t IncludeKeysInResponse, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCParametersHandle DCPars, char * pcTransactionID, int32_t * szTransactionID, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_CreatePKCS7SignRequest(TElDCDefaultRequestFactoryHandle _Handle, const char * pcOpName, int32_t szOpName, const uint8_t pSource[], int32_t szSource, int32_t HashAlgorithm, TElDCPKCS7SignParametersHandle Pars, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCParametersHandle DCPars, char * pcTransactionID, int32_t * szTransactionID, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_ProcessPKCS1SignResponse(TElDCDefaultRequestFactoryHandle _Handle, TElDCAsyncStateHandle State, uint8_t pSource[], int32_t * szSource, int32_t * HashAlgorithm, uint8_t pSignature[], int32_t * szSignature, uint8_t pAdditionalData[], int32_t * szAdditionalData, TElByteArrayListHandle Keys, TElByteArrayListHandle SigningKeys);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_VerifyResponseMDC(TElDCDefaultRequestFactoryHandle _Handle, TElDCAsyncStateHandle AsyncState, TSBDCResponseVerificationResultRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_ExtractAdditionalData(TElDCDefaultRequestFactoryHandle _Handle, TElDCAsyncStateHandle AsyncState, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_get_StateStorage(TElDCDefaultRequestFactoryHandle _Handle, TElCustomDCStateStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_set_StateStorage(TElDCDefaultRequestFactoryHandle _Handle, TElCustomDCStateStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_get_DefaultParameters(TElDCDefaultRequestFactoryHandle _Handle, TElDCParametersHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_get_RequestExpirationTime(TElDCDefaultRequestFactoryHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_set_RequestExpirationTime(TElDCDefaultRequestFactoryHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_get_MDCKey(TElDCDefaultRequestFactoryHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_set_MDCKey(TElDCDefaultRequestFactoryHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_get_UseMDC(TElDCDefaultRequestFactoryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_set_UseMDC(TElDCDefaultRequestFactoryHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCDefaultRequestFactory_Create(TElDCDefaultRequestFactoryHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCDEFAULTREQUESTFACTORY */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDCPKCS7SignParameters_ce_ptr;
extern zend_class_entry *TElDCDefaultRequestFactory_ce_ptr;

void Register_TElDCPKCS7SignParameters(TSRMLS_D);
void Register_TElDCDefaultRequestFactory(TSRMLS_D);
SB_PHP_FUNCTION(SBDCDef, DefaultDCRequestFactory);
void Register_SBDCDef_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_DCDEF
SB_IMPORT uint32_t SB_APIENTRY SBDCDef_DefaultDCRequestFactory(TElDCDefaultRequestFactoryHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_DCDEF */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDCDEF */

