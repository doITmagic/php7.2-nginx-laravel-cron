#ifndef __INC_SBDCENC
#define __INC_SBDCENC

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbrdn.h"
#include "sbencoding.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDCEncodingHandle;

typedef TElClassHandle TElDCNodeHandle;

#ifdef SB_USE_CLASS_TELDCENCODING
SB_IMPORT uint32_t SB_APIENTRY TElDCEncoding_Encode(TElDCEncodingHandle _Handle, TElDCNodeHandle Root, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDCEncoding_Decode(TElDCEncodingHandle _Handle, TElDCNodeHandle Root, TStreamHandle Stream, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElDCEncoding_GetName(TElDCEncodingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCEncoding_GetDescription(TElDCEncodingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCEncoding_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCENCODING */

#ifdef SB_USE_CLASS_TELDCNODE
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_AddNode(TElDCNodeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_AddNode_1(TElDCNodeHandle _Handle, const char * pcName, int32_t szName, const char * pcValue, int32_t szValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_AddNode_2(TElDCNodeHandle _Handle, const char * pcName, int32_t szName, int32_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_AddNode_3(TElDCNodeHandle _Handle, const char * pcName, int32_t szName, int8_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_AddNode_4(TElDCNodeHandle _Handle, const char * pcName, int32_t szName, TElRelativeDistinguishedNameHandle Value, const char * pcElemName, int32_t szElemName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_AddNode_5(TElDCNodeHandle _Handle, const char * pcName, int32_t szName, TElStringListHandle Value, const char * pcElemName, int32_t szElemName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_RemoveNode(TElDCNodeHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_Clear(TElDCNodeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_ReadString(TElDCNodeHandle _Handle, const char * pcName, int32_t szName, const char * pcDefault, int32_t szDefault, int8_t RaiseExceptionIfNotFound, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_ReadInteger(TElDCNodeHandle _Handle, const char * pcName, int32_t szName, int32_t Default, int8_t RaiseExceptionIfNotFound, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_ReadBoolean(TElDCNodeHandle _Handle, const char * pcName, int32_t szName, int8_t Default, int8_t RaiseExceptionIfNotFound, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_ReadRDN(TElDCNodeHandle _Handle, const char * pcName, int32_t szName, TElRelativeDistinguishedNameHandle Rdn, int8_t RaiseExceptionIfNotFound);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_ReadStringList(TElDCNodeHandle _Handle, const char * pcName, int32_t szName, TElStringListHandle Lst, int8_t RaiseExceptionIfNotFound);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_LoadFromStream(TElDCNodeHandle _Handle, TStreamHandle Stream, int32_t Count, TElDCEncodingHandle Encoding);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_SaveToStream(TElDCNodeHandle _Handle, TStreamHandle Stream, TElDCEncodingHandle Encoding);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_get_Nodes(TElDCNodeHandle _Handle, int32_t Index, TElDCNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_get_NodeCount(TElDCNodeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_get_Name(TElDCNodeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_set_Name(TElDCNodeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_get_Value(TElDCNodeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_set_Value(TElDCNodeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_get_Params(TElDCNodeHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCNode_Create(TElDCNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCNODE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDCEncoding_ce_ptr;
extern zend_class_entry *TElDCNode_ce_ptr;

void Register_TElDCEncoding(TSRMLS_D);
void Register_TElDCNode(TSRMLS_D);
SB_PHP_FUNCTION(SBDCEnc, SetDefaultDCEncoding);
SB_PHP_FUNCTION(SBDCEnc, GetDefaultDCEncoding);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_DCENC
SB_IMPORT uint32_t SB_APIENTRY SBDCEnc_SetDefaultDCEncoding(TElDCEncodingHandle Value);
SB_IMPORT uint32_t SB_APIENTRY SBDCEnc_GetDefaultDCEncoding(TElDCEncodingHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_DCENC */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDCENC */

