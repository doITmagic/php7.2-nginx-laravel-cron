#ifndef __INC_SBDCPKCS7
#define __INC_SBDCPKCS7

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbdc.h"
#include "sbdcdef.h"
#include "sbdcserver.h"
#include "sbdcpkiconstants.h"
#include "sbrdn.h"
#include "sbx509.h"
#include "sbasn1tree.h"
#include "sbtspclient.h"
#include "sbtspcommon.h"
#include "sbmessages.h"
#include "sbcustomcertstorage.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDCPKCS7SignOperationHandlerHandle;

typedef void (SB_CALLBACK *TSBDCPKCS7SignerPreparedEvent)(void * _ObjectData, TObjectHandle Sender, TElMessageSignerHandle Signer);

typedef void (SB_CALLBACK *TSBDCPKCS7TSPClientNeededEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pTSPServiceID[], int32_t szTSPServiceID, TElCustomTSPClientHandle * TSPClient, int8_t * Success);

#ifdef SB_USE_CLASS_TELDCPKCS7SIGNOPERATIONHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignOperationHandler_get_CertStorage(TElDCPKCS7SignOperationHandlerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignOperationHandler_set_CertStorage(TElDCPKCS7SignOperationHandlerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignOperationHandler_get_OnTSPClientNeeded(TElDCPKCS7SignOperationHandlerHandle _Handle, TSBDCPKCS7TSPClientNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignOperationHandler_set_OnTSPClientNeeded(TElDCPKCS7SignOperationHandlerHandle _Handle, TSBDCPKCS7TSPClientNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignOperationHandler_get_OnSignerPrepared(TElDCPKCS7SignOperationHandlerHandle _Handle, TSBDCPKCS7SignerPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignOperationHandler_set_OnSignerPrepared(TElDCPKCS7SignOperationHandlerHandle _Handle, TSBDCPKCS7SignerPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCPKCS7SignOperationHandler_Create(TElDCPKCS7SignOperationHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCPKCS7SIGNOPERATIONHANDLER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDCPKCS7SignOperationHandler_ce_ptr;

void SB_CALLBACK TSBDCPKCS7SignerPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElMessageSignerHandle Signer);
void SB_CALLBACK TSBDCPKCS7TSPClientNeededEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pTSPServiceID[], int32_t szTSPServiceID, TElCustomTSPClientHandle * TSPClient, int8_t * Success);
void Register_TElDCPKCS7SignOperationHandler(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDCPKCS7 */

