#ifndef __INC_SBDCPKI
#define __INC_SBDCPKI

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbdc.h"
#include "sbdcserver.h"
#include "sbdcpkiconstants.h"
#include "sbdcsec.h"
#include "sbrdn.h"
#include "sbx509.h"
#include "sbasn1tree.h"
#include "sbcustomcrypto.h"
#include "sbpublickeycrypto.h"
#include "sbcustomcertstorage.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDCX509SignOperationHandlerHandle;

#ifdef SB_USE_CLASS_TELDCX509SIGNOPERATIONHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElDCX509SignOperationHandler_get_CertStorage(TElDCX509SignOperationHandlerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCX509SignOperationHandler_set_CertStorage(TElDCX509SignOperationHandlerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCX509SignOperationHandler_Create(TElDCX509SignOperationHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCX509SIGNOPERATIONHANDLER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDCX509SignOperationHandler_ce_ptr;

void Register_TElDCX509SignOperationHandler(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDCPKI */

