#ifndef __INC_SBDCSEC
#define __INC_SBDCSEC

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbutils.h"
#include "sbtypes.h"
#include "sbstrutils.h"
#include "sbhashfunction.h"
#include "sbsymmetriccrypto.h"
#include "sbpublickeycrypto.h"
#include "sbstreams.h"
#include "sbpkcs7utils.h"
#include "sbrandom.h"
#include "sbcustomcertstorage.h"
#include "sbx509.h"
#include "sbrdn.h"
#include "sbdc.h"
#include "sbdcasn1enc.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDCMDCHandle;

typedef TElClassHandle TElDCParametersHandle;

typedef TElClassHandle TElDCClientRequestSignatureHandlerHandle;

typedef TElClassHandle TElDCClientPKCS1RequestSignatureHandlerHandle;

typedef TElClassHandle TElDCSecurityParametersHandle;

typedef uint8_t TSBDCMDCVerificationResultRaw;

typedef enum
{
	mdcSuccess = 0,
	mdcFailure = 1,
	mdcExpired = 2
} TSBDCMDCVerificationResult;

typedef void (SB_CALLBACK *TSBDCBeforePKCS1SignEvent)(void * _ObjectData, TObjectHandle Sender, TElPublicKeyCryptoHandle Crypto);

#ifdef SB_USE_CLASS_TELDCMDC
SB_IMPORT uint32_t SB_APIENTRY TElDCMDC_CalculateMDC(TElDCMDCHandle _Handle, TElDCBaseMessageHandle Msg, uint32_t Epoch, const uint8_t pKey[], int32_t szKey, TElDCMessageMDCMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCMDC_VerifyMDC(TElDCMDCHandle _Handle, TElDCBaseMessageHandle Msg, TElDCMessageMDCMessageHandle MDCMsg, uint32_t Epoch, uint32_t ExpirationTime, const uint8_t pKey[], int32_t szKey, TSBDCMDCVerificationResultRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCMDC_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCMDC */

#ifdef SB_USE_CLASS_TELDCPARAMETERS
SB_IMPORT uint32_t SB_APIENTRY TElDCParameters_get_AsyncSignMethod(TElDCParametersHandle _Handle, TSBDCAsyncSignMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCParameters_set_AsyncSignMethod(TElDCParametersHandle _Handle, TSBDCAsyncSignMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCParameters_get_SigningCertInfo(TElDCParametersHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCParameters_get_RequestedCertificates(TElDCParametersHandle _Handle, TSBDCRequestedCertificatesOptionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCParameters_set_RequestedCertificates(TElDCParametersHandle _Handle, TSBDCRequestedCertificatesOptionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCParameters_get_Parameters(TElDCParametersHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCParameters_get_SecurityParameters(TElDCParametersHandle _Handle, TElDCSecurityParametersHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCParameters_Create(TElDCParametersHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCPARAMETERS */

#ifdef SB_USE_CLASS_TELDCCLIENTREQUESTSIGNATUREHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElDCClientRequestSignatureHandler_SignHash(TElDCClientRequestSignatureHandlerHandle _Handle, const uint8_t pHash[], int32_t szHash, TElDCParametersHandle Pars, TElStringListHandle SigParams, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCClientRequestSignatureHandler_GetName(TElDCClientRequestSignatureHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCClientRequestSignatureHandler_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCCLIENTREQUESTSIGNATUREHANDLER */

#ifdef SB_USE_CLASS_TELDCCLIENTPKCS1REQUESTSIGNATUREHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElDCClientPKCS1RequestSignatureHandler_SignHash(TElDCClientPKCS1RequestSignatureHandlerHandle _Handle, const uint8_t pHash[], int32_t szHash, TElDCParametersHandle Pars, TElStringListHandle SigParams, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCClientPKCS1RequestSignatureHandler_GetName(TElDCClientPKCS1RequestSignatureHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCClientPKCS1RequestSignatureHandler_get_OnBeforeSign(TElDCClientPKCS1RequestSignatureHandlerHandle _Handle, TSBDCBeforePKCS1SignEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCClientPKCS1RequestSignatureHandler_set_OnBeforeSign(TElDCClientPKCS1RequestSignatureHandlerHandle _Handle, TSBDCBeforePKCS1SignEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCClientPKCS1RequestSignatureHandler_Create(TElDCClientPKCS1RequestSignatureHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCCLIENTPKCS1REQUESTSIGNATUREHANDLER */

#ifdef SB_USE_CLASS_TELDCSECURITYPARAMETERS
SB_IMPORT uint32_t SB_APIENTRY TElDCSecurityParameters_GetAppropriateSignatureHandler(TElDCSecurityParametersHandle _Handle, TElDCClientRequestSignatureHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSecurityParameters_get_UseAuthenticatedRequests(TElDCSecurityParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSecurityParameters_set_UseAuthenticatedRequests(TElDCSecurityParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCSecurityParameters_get_SignatureHandler(TElDCSecurityParametersHandle _Handle, TElDCClientRequestSignatureHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSecurityParameters_set_SignatureHandler(TElDCSecurityParametersHandle _Handle, TElDCClientRequestSignatureHandlerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCSecurityParameters_get_HashAlgorithm(TElDCSecurityParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSecurityParameters_set_HashAlgorithm(TElDCSecurityParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCSecurityParameters_get_CertStorage(TElDCSecurityParametersHandle _Handle, TElMemoryCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSecurityParameters_set_CertStorage(TElDCSecurityParametersHandle _Handle, TElMemoryCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCSecurityParameters_get_IncludeCertificates(TElDCSecurityParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSecurityParameters_set_IncludeCertificates(TElDCSecurityParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCSecurityParameters_Create(TElDCSecurityParametersHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCSECURITYPARAMETERS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDCMDC_ce_ptr;
extern zend_class_entry *TElDCParameters_ce_ptr;
extern zend_class_entry *TElDCClientRequestSignatureHandler_ce_ptr;
extern zend_class_entry *TElDCClientPKCS1RequestSignatureHandler_ce_ptr;
extern zend_class_entry *TElDCSecurityParameters_ce_ptr;

void SB_CALLBACK TSBDCBeforePKCS1SignEventRaw(void * _ObjectData, TObjectHandle Sender, TElPublicKeyCryptoHandle Crypto);
void Register_TElDCMDC(TSRMLS_D);
void Register_TElDCParameters(TSRMLS_D);
void Register_TElDCClientRequestSignatureHandler(TSRMLS_D);
void Register_TElDCClientPKCS1RequestSignatureHandler(TSRMLS_D);
void Register_TElDCSecurityParameters(TSRMLS_D);
void Register_SBDCSec_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDCSEC */

