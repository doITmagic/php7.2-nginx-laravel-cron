#ifndef __INC_SBDCSERVER
#define __INC_SBDCSERVER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstringlist.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbhashfunction.h"
#include "sbpublickeycrypto.h"
#include "sbcustomcertstorage.h"
#include "sbx509.h"
#include "sbrdn.h"
#include "sbencoding.h"
#include "sbpkicommon.h"
#include "sbasn1tree.h"
#include "sbdc.h"
#include "sbdcpkiconstants.h"
#include "sbdcenc.h"
#include "sbdcsec.h"
#include "sbdccanonenc.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDCStandardServerHandle;

typedef TElClassHandle TElDCOperationHandlerHandle;

typedef TElClassHandle TElDCSignOperationHandlerHandle;

typedef TElClassHandle TElDCSingleServerRequestHandle;

typedef TElClassHandle TElDCServerRequestHandle;

typedef TElClassHandle TElDCServerSecurityParametersHandle;

typedef TElClassHandle TElDCServerRequestSignatureHandlerHandle;

typedef TElClassHandle TElDCServerPKCS1RequestSignatureHandlerHandle;

typedef void (SB_CALLBACK *TSBDCSignRequestEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pData[], int32_t szData, const uint8_t pHashAlg[], int32_t szHashAlg, TSBDCRequestedCertificatesOptionRaw RequestedCertificates, TElRelativeDistinguishedNameHandle SigningCertInfo, TElRelativeDistinguishedNameHandle InputPars, TElRelativeDistinguishedNameHandle Keys, TElRelativeDistinguishedNameHandle OutputPars, uint8_t pSignResult[], int32_t * szSignResult);

typedef void (SB_CALLBACK *TSBDCServerCertificateNeededEvent)(void * _ObjectData, TObjectHandle Sender, TObjectHandle CertID, TElX509CertificateHandle * Certificate, int8_t * FreeOnFinish);

typedef void (SB_CALLBACK *TSBDCServerCertificateValidateEvent)(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle Certificate, TElMemoryCertStorageHandle OtherCertificates, int8_t * Valid);

typedef void (SB_CALLBACK *TSBDCServerSignatureFoundEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcSigType, int32_t szSigType, TElStringListHandle Params, int8_t * Accept);

typedef void (SB_CALLBACK *TSBDCServerSignatureHandlerNeededEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcSigType, int32_t szSigType, TElStringListHandle Params, TElDCServerRequestSignatureHandlerHandle * Handler);

typedef void (SB_CALLBACK *TSBDCServerParametersReceivedEvent)(void * _ObjectData, TObjectHandle Sender, TElRelativeDistinguishedNameHandle Params);

#ifdef SB_USE_CLASS_TELDCSTANDARDSERVER
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_Process(TElDCStandardServerHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, TElDCEncodingHandle InEncoding, TElDCEncodingHandle OutEncoding);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_Process_1(TElDCStandardServerHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_BeginProcess(TElDCStandardServerHandle _Handle, TStreamHandle InStream, TElDCEncodingHandle InEncoding, TElDCServerRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_BeginProcess_1(TElDCStandardServerHandle _Handle, TStreamHandle InStream, TElDCServerRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_EndProcess(TElDCStandardServerHandle _Handle, TElDCServerRequestHandle Request, TStreamHandle OutStream, TElDCEncodingHandle OutEncoding);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_EndProcess_1(TElDCStandardServerHandle _Handle, TElDCServerRequestHandle Request, TStreamHandle OutStream);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_AddOperationHandler(TElDCStandardServerHandle _Handle, TElDCOperationHandlerHandle Handler, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_RemoveOperationHandler(TElDCStandardServerHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_ClearOperationHandlers(TElDCStandardServerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_AddRequestSignatureHandler(TElDCStandardServerHandle _Handle, TElDCServerRequestSignatureHandlerHandle Handler, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_RemoveRequestSignatureHandler(TElDCStandardServerHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_ClearRequestSignatureHandlers(TElDCStandardServerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_get_OperationHandlers(TElDCStandardServerHandle _Handle, int32_t Index, TElDCOperationHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_get_OperationHandlerCount(TElDCStandardServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_get_RequestSignatureHandlers(TElDCStandardServerHandle _Handle, int32_t Index, TElDCServerRequestSignatureHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_get_RequestSignatureHandlerCount(TElDCStandardServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_get_SecurityParameters(TElDCStandardServerHandle _Handle, TElDCServerSecurityParametersHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_get_OnSignatureFound(TElDCStandardServerHandle _Handle, TSBDCServerSignatureFoundEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_set_OnSignatureFound(TElDCStandardServerHandle _Handle, TSBDCServerSignatureFoundEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_get_OnSignatureHandlerNeeded(TElDCStandardServerHandle _Handle, TSBDCServerSignatureHandlerNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_set_OnSignatureHandlerNeeded(TElDCStandardServerHandle _Handle, TSBDCServerSignatureHandlerNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_get_OnParametersReceived(TElDCStandardServerHandle _Handle, TSBDCServerParametersReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_set_OnParametersReceived(TElDCStandardServerHandle _Handle, TSBDCServerParametersReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCStandardServer_Create(TElDCStandardServerHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCSTANDARDSERVER */

#ifdef SB_USE_CLASS_TELDCOPERATIONHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationHandler_get_AcceptedOperationIDs(TElDCOperationHandlerHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCOperationHandler_Create(TElDCOperationHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCOPERATIONHANDLER */

#ifdef SB_USE_CLASS_TELDCSIGNOPERATIONHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElDCSignOperationHandler_get_OnSignRequest(TElDCSignOperationHandlerHandle _Handle, TSBDCSignRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSignOperationHandler_set_OnSignRequest(TElDCSignOperationHandlerHandle _Handle, TSBDCSignRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCSignOperationHandler_Create(TElDCOperationHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCSIGNOPERATIONHANDLER */

#ifdef SB_USE_CLASS_TELDCSINGLESERVERREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElDCSingleServerRequest_get_Parameters(TElDCSingleServerRequestHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSingleServerRequest_get_RequestedCertificates(TElDCSingleServerRequestHandle _Handle, TSBDCRequestedCertificatesOptionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSingleServerRequest_get_SigningCertInfo(TElDCSingleServerRequestHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCSingleServerRequest_Create(TElDCStandardServerHandle Owner, TElDCSingleServerRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCSINGLESERVERREQUEST */

#ifdef SB_USE_CLASS_TELDCSERVERREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElDCServerRequest_BeginProcess(TElDCServerRequestHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerRequest_Clear(TElDCServerRequestHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerRequest_get_Requests(TElDCServerRequestHandle _Handle, int32_t Index, TElDCSingleServerRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerRequest_get_RequestCount(TElDCServerRequestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerRequest_get_Parameters(TElDCServerRequestHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerRequest_get_SigningCertInfo(TElDCServerRequestHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerRequest_get_RequestedCertificates(TElDCServerRequestHandle _Handle, TSBDCRequestedCertificatesOptionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerRequest_Create(TElDCStandardServerHandle Owner, TElDCNodeHandle ReqRoot, TElDCServerRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCSERVERREQUEST */

#ifdef SB_USE_CLASS_TELDCSERVERSECURITYPARAMETERS
SB_IMPORT uint32_t SB_APIENTRY TElDCServerSecurityParameters_get_RequireSignature(TElDCServerSecurityParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerSecurityParameters_set_RequireSignature(TElDCServerSecurityParametersHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerSecurityParameters_Create(TElDCServerSecurityParametersHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCSERVERSECURITYPARAMETERS */

#ifdef SB_USE_CLASS_TELDCSERVERREQUESTSIGNATUREHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElDCServerRequestSignatureHandler_ValidateSignature(TElDCServerRequestSignatureHandlerHandle _Handle, const uint8_t pSignature[], int32_t szSignature, const uint8_t pHash[], int32_t szHash, int32_t HashAlgorithm, TElStringListHandle SigParams);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerRequestSignatureHandler_GetName(TElDCServerRequestSignatureHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerRequestSignatureHandler_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCSERVERREQUESTSIGNATUREHANDLER */

#ifdef SB_USE_CLASS_TELDCSERVERPKCS1REQUESTSIGNATUREHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElDCServerPKCS1RequestSignatureHandler_ValidateSignature(TElDCServerPKCS1RequestSignatureHandlerHandle _Handle, const uint8_t pSignature[], int32_t szSignature, const uint8_t pHash[], int32_t szHash, int32_t HashAlgorithm, TElStringListHandle SigParams);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerPKCS1RequestSignatureHandler_GetName(TElDCServerPKCS1RequestSignatureHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerPKCS1RequestSignatureHandler_get_OnCertificateValidate(TElDCServerPKCS1RequestSignatureHandlerHandle _Handle, TSBDCServerCertificateValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerPKCS1RequestSignatureHandler_set_OnCertificateValidate(TElDCServerPKCS1RequestSignatureHandlerHandle _Handle, TSBDCServerCertificateValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerPKCS1RequestSignatureHandler_get_OnCertificateNeeded(TElDCServerPKCS1RequestSignatureHandlerHandle _Handle, TSBDCServerCertificateNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerPKCS1RequestSignatureHandler_set_OnCertificateNeeded(TElDCServerPKCS1RequestSignatureHandlerHandle _Handle, TSBDCServerCertificateNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDCServerPKCS1RequestSignatureHandler_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELDCSERVERPKCS1REQUESTSIGNATUREHANDLER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDCStandardServer_ce_ptr;
extern zend_class_entry *TElDCOperationHandler_ce_ptr;
extern zend_class_entry *TElDCSignOperationHandler_ce_ptr;
extern zend_class_entry *TElDCSingleServerRequest_ce_ptr;
extern zend_class_entry *TElDCServerRequest_ce_ptr;
extern zend_class_entry *TElDCServerSecurityParameters_ce_ptr;
extern zend_class_entry *TElDCServerRequestSignatureHandler_ce_ptr;
extern zend_class_entry *TElDCServerPKCS1RequestSignatureHandler_ce_ptr;

void SB_CALLBACK TSBDCSignRequestEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pData[], int32_t szData, const uint8_t pHashAlg[], int32_t szHashAlg, TSBDCRequestedCertificatesOptionRaw RequestedCertificates, TElRelativeDistinguishedNameHandle SigningCertInfo, TElRelativeDistinguishedNameHandle InputPars, TElRelativeDistinguishedNameHandle Keys, TElRelativeDistinguishedNameHandle OutputPars, uint8_t pSignResult[], int32_t * szSignResult);
void SB_CALLBACK TSBDCServerCertificateNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TObjectHandle CertID, TElX509CertificateHandle * Certificate, int8_t * FreeOnFinish);
void SB_CALLBACK TSBDCServerCertificateValidateEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle Certificate, TElMemoryCertStorageHandle OtherCertificates, int8_t * Valid);
void SB_CALLBACK TSBDCServerSignatureFoundEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcSigType, int32_t szSigType, TElStringListHandle Params, int8_t * Accept);
void SB_CALLBACK TSBDCServerSignatureHandlerNeededEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcSigType, int32_t szSigType, TElStringListHandle Params, TElDCServerRequestSignatureHandlerHandle * Handler);
void SB_CALLBACK TSBDCServerParametersReceivedEventRaw(void * _ObjectData, TObjectHandle Sender, TElRelativeDistinguishedNameHandle Params);
void Register_TElDCStandardServer(TSRMLS_D);
void Register_TElDCOperationHandler(TSRMLS_D);
void Register_TElDCSignOperationHandler(TSRMLS_D);
void Register_TElDCSingleServerRequest(TSRMLS_D);
void Register_TElDCServerRequest(TSRMLS_D);
void Register_TElDCServerSecurityParameters(TSRMLS_D);
void Register_TElDCServerRequestSignatureHandler(TSRMLS_D);
void Register_TElDCServerPKCS1RequestSignatureHandler(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDCSERVER */

