#ifndef __INC_SBDCSTATESTORAGE
#define __INC_SBDCSTATESTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcustomfsadapter.h"
#include "sbdiskfsadapter.h"
#include "sbsharedresource.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbrandom.h"
#include "sbdc.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_DC_STORAGE 	131136
#define SB_DC_ERROR_STORAGE_FEATURE_NOT_IMPLEMENTED 	131137
#define SB_DC_ERROR_STORAGE_COULD_NOT_PICK_RANDOM_NAME 	131138
#define SB_DC_ERROR_STORAGE_COULD_NOT_CREATE_TEMP_STREAM 	131139
#define SB_DC_ERROR_STORAGE_BAD_TEMP_STREAM 	131140
#define SB_DC_ERROR_STORAGE_FAILED_TO_RENAME_FILE 	131141
#define SB_DC_ERROR_STORAGE_FILE_ALREADY_EXISTS 	131142
#define SB_DC_ERROR_STORAGE_FAILED_TO_DELETE_FILE 	131143
#define SB_DC_ERROR_STORAGE_FILE_NOT_FOUND 	131144
#define SB_DC_ERROR_STORAGE_COULD_NOT_OPEN_STATE_FILE 	131145

typedef TElClassHandle TElCustomDCStateStorageHandle;

typedef TElClassHandle TElFileDCStateStorageHandle;

#ifdef SB_USE_CLASS_TELCUSTOMDCSTATESTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElCustomDCStateStorage_CreateStreamForPreSignedData(TElCustomDCStateStorageHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomDCStateStorage_ClosePreSignedStream(TElCustomDCStateStorageHandle _Handle, TStreamHandle Stream, const char * pcTransactionID, int32_t szTransactionID);
SB_IMPORT uint32_t SB_APIENTRY TElCustomDCStateStorage_DiscardPreSignedStream(TElCustomDCStateStorageHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElCustomDCStateStorage_OpenPreSignedStream(TElCustomDCStateStorageHandle _Handle, const char * pcTransactionID, int32_t szTransactionID, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomDCStateStorage_DeletePreSignedStream(TElCustomDCStateStorageHandle _Handle, const char * pcTransactionID, int32_t szTransactionID);
SB_IMPORT uint32_t SB_APIENTRY TElCustomDCStateStorage_Create(TComponentHandle AOwner, TElCustomDCStateStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMDCSTATESTORAGE */

#ifdef SB_USE_CLASS_TELFILEDCSTATESTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElFileDCStateStorage_CreateStreamForPreSignedData(TElFileDCStateStorageHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDCStateStorage_ClosePreSignedStream(TElFileDCStateStorageHandle _Handle, TStreamHandle Stream, const char * pcTransactionID, int32_t szTransactionID);
SB_IMPORT uint32_t SB_APIENTRY TElFileDCStateStorage_DiscardPreSignedStream(TElFileDCStateStorageHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElFileDCStateStorage_OpenPreSignedStream(TElFileDCStateStorageHandle _Handle, const char * pcTransactionID, int32_t szTransactionID, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDCStateStorage_DeletePreSignedStream(TElFileDCStateStorageHandle _Handle, const char * pcTransactionID, int32_t szTransactionID);
SB_IMPORT uint32_t SB_APIENTRY TElFileDCStateStorage_get_FileSystemAdapter(TElFileDCStateStorageHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDCStateStorage_set_FileSystemAdapter(TElFileDCStateStorageHandle _Handle, TElCustomFileSystemAdapterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElFileDCStateStorage_get_StorageRoot(TElFileDCStateStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDCStateStorage_set_StorageRoot(TElFileDCStateStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElFileDCStateStorage_Create(TComponentHandle AOwner, TElFileDCStateStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELFILEDCSTATESTORAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElCustomDCStateStorage_ce_ptr;
extern zend_class_entry *TElFileDCStateStorage_ce_ptr;

void Register_TElCustomDCStateStorage(TSRMLS_D);
void Register_TElFileDCStateStorage(TSRMLS_D);
void Register_SBDCStateStorage_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDCSTATESTORAGE */

