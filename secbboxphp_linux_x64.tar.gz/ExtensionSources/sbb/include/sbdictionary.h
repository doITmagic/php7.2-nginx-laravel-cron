#ifndef __INC_SBDICTIONARY
#define __INC_SBDICTIONARY

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbtypes.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDictionaryEntryHandle;

typedef TElClassHandle TElDictionaryHandle;

typedef void (SB_CALLBACK *TSBDictionaryDeleteValueEvent)(void * _ObjectData, TObjectHandle Sender, TObjectHandle Value);

#ifdef SB_USE_CLASS_TELDICTIONARYENTRY
SB_IMPORT uint32_t SB_APIENTRY TElDictionaryEntry_get_HashCode(TElDictionaryEntryHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionaryEntry_set_HashCode(TElDictionaryEntryHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDictionaryEntry_get_Next(TElDictionaryEntryHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionaryEntry_set_Next(TElDictionaryEntryHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDictionaryEntry_get_Value(TElDictionaryEntryHandle _Handle, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionaryEntry_set_Value(TElDictionaryEntryHandle _Handle, TObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDictionaryEntry_get_StrKey(TElDictionaryEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionaryEntry_set_StrKey(TElDictionaryEntryHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDictionaryEntry_get_ByteKey(TElDictionaryEntryHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionaryEntry_set_ByteKey(TElDictionaryEntryHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDictionaryEntry_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELDICTIONARYENTRY */

#ifdef SB_USE_CLASS_TELDICTIONARY
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_Clear(TElDictionaryHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_Add(TElDictionaryHandle _Handle, const char * pcKey, int32_t szKey, TObjectHandle Value, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_Add_1(TElDictionaryHandle _Handle, const uint8_t pKey[], int32_t szKey, TObjectHandle Value, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_ContainsKey(TElDictionaryHandle _Handle, const char * pcKey, int32_t szKey, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_ContainsKey_1(TElDictionaryHandle _Handle, const uint8_t pKey[], int32_t szKey, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_ContainsValue(TElDictionaryHandle _Handle, TObjectHandle Value, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_Remove(TElDictionaryHandle _Handle, const char * pcKey, int32_t szKey, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_Remove_1(TElDictionaryHandle _Handle, const uint8_t pKey[], int32_t szKey, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_Remove_2(TElDictionaryHandle _Handle, TObjectHandle Value, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_TryGetValue(TElDictionaryHandle _Handle, const char * pcKey, int32_t szKey, TObjectHandle * Value, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_TryGetValue_1(TElDictionaryHandle _Handle, const uint8_t pKey[], int32_t szKey, TObjectHandle * Value, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_GetItem(TElDictionaryHandle _Handle, const uint8_t pKey[], int32_t szKey, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_GetItem_1(TElDictionaryHandle _Handle, const char * pcKey, int32_t szKey, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_SetItem(TElDictionaryHandle _Handle, const uint8_t pKey[], int32_t szKey, TObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_SetItem_1(TElDictionaryHandle _Handle, const char * pcKey, int32_t szKey, TObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_get_Count(TElDictionaryHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_get_FreeCount(TElDictionaryHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_get_Values(TElDictionaryHandle _Handle, int32_t Index, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_get_StringKeys(TElDictionaryHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_get_ByteKeys(TElDictionaryHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_get_OnDeleteValue(TElDictionaryHandle _Handle, TSBDictionaryDeleteValueEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_set_OnDeleteValue(TElDictionaryHandle _Handle, TSBDictionaryDeleteValueEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_Create(TElDictionaryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDictionary_Create_1(int32_t Capacity, TElDictionaryHandle * OutResult);
#endif /* SB_USE_CLASS_TELDICTIONARY */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDictionaryEntry_ce_ptr;
extern zend_class_entry *TElDictionary_ce_ptr;

void SB_CALLBACK TSBDictionaryDeleteValueEventRaw(void * _ObjectData, TObjectHandle Sender, TObjectHandle Value);
void Register_TElDictionaryEntry(TSRMLS_D);
void Register_TElDictionary(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDICTIONARY */

