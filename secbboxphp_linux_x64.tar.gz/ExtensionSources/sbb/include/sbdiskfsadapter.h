#ifndef __INC_SBDISKFSADAPTER
#define __INC_SBDISKFSADAPTER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#ifdef SB_WINDOWS
#include "sbchsconv.h"
#endif
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbconstants.h"
#include "sbstringlist.h"
#include "sbcustomfsadapter.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDiskFileSystemAdapterHandle;

typedef void (SB_CALLBACK *TElVFSWriteFileTagEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, const char * pcTagValue, int32_t szTagValue, int32_t * ResultCode);

typedef void (SB_CALLBACK *TElVFSReadFileTagEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, char * pcTagValue, int32_t * szTagValue, int32_t * ResultCode);

typedef void (SB_CALLBACK *TElVFSDeleteFileTagEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, int32_t * ResultCode);

#ifdef SB_USE_CLASS_TELDISKFILESYSTEMADAPTER
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_AdjustPath(TElDiskFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_Clone(TElDiskFileSystemAdapterHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_GetFileStream(TElDiskFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, uint32_t OpenMode, TSBFileShareModeRaw ShareMode, TStreamHandle * FileStream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_FileExists(TElDiskFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_DirectoryExists(TElDiskFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_FileDelete(TElDiskFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_FileMove(TElDiskFileSystemAdapterHandle _Handle, const char * pcFromName, int32_t szFromName, const char * pcToName, int32_t szToName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_DirectoryRemove(TElDiskFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_DirectoryMake(TElDiskFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_FileRead(TElDiskFileSystemAdapterHandle _Handle, TObjectHandle FileHandle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t Size, int32_t * ErrorCode, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_FileWrite(TElDiskFileSystemAdapterHandle _Handle, TObjectHandle FileHandle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t Size, int32_t * ErrorCode, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_FileSeek(TElDiskFileSystemAdapterHandle _Handle, TObjectHandle FileHandle, int64_t Position, TSBFileSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_FileSetSize(TElDiskFileSystemAdapterHandle _Handle, TObjectHandle FileHandle, int64_t NewSize);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_FileGetSize(TElDiskFileSystemAdapterHandle _Handle, TObjectHandle FileHandle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_FileGetPosition(TElDiskFileSystemAdapterHandle _Handle, TObjectHandle FileHandle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_WriteFileTag(TElDiskFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, const char * pcTagValue, int32_t szTagValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_ReadFileTag(TElDiskFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, char * pcTagValue, int32_t * szTagValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_DeleteFileTag(TElDiskFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_FileGetTimes(TElDiskFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, int64_t * CreationTime, int64_t * ModificationTime, int64_t * LastAccessTime, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_GetEntryInformation(TElDiskFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, TElVFSEntryInformationHandle EntryInfo, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_SetEntryInformation(TElDiskFileSystemAdapterHandle _Handle, const char * pcPath, int32_t szPath, TElVFSEntryInformationHandle EntryInfo, int32_t InfoFlags, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_GetFullPath(TElDiskFileSystemAdapterHandle _Handle, const char * pcFileName, int32_t szFileName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_get_OnWriteFileTag(TElDiskFileSystemAdapterHandle _Handle, TElVFSWriteFileTagEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_set_OnWriteFileTag(TElDiskFileSystemAdapterHandle _Handle, TElVFSWriteFileTagEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_get_OnReadFileTag(TElDiskFileSystemAdapterHandle _Handle, TElVFSReadFileTagEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_set_OnReadFileTag(TElDiskFileSystemAdapterHandle _Handle, TElVFSReadFileTagEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_get_OnDeleteFileTag(TElDiskFileSystemAdapterHandle _Handle, TElVFSDeleteFileTagEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_set_OnDeleteFileTag(TElDiskFileSystemAdapterHandle _Handle, TElVFSDeleteFileTagEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDiskFileSystemAdapter_Create(TComponentHandle AOwner, TElCustomFileSystemAdapterHandle * OutResult);
#endif /* SB_USE_CLASS_TELDISKFILESYSTEMADAPTER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDiskFileSystemAdapter_ce_ptr;

void SB_CALLBACK TElVFSWriteFileTagEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, const char * pcTagValue, int32_t szTagValue, int32_t * ResultCode);
void SB_CALLBACK TElVFSReadFileTagEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, char * pcTagValue, int32_t * szTagValue, int32_t * ResultCode);
void SB_CALLBACK TElVFSDeleteFileTagEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, const char * pcTagName, int32_t szTagName, int32_t * ResultCode);
void Register_TElDiskFileSystemAdapter(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDISKFSADAPTER */
