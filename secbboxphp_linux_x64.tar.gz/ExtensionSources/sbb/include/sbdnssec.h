#ifndef __INC_SBDNSSEC
#define __INC_SBDNSSEC

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbsocket.h"
#include "sbstreams.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbdnssectypes.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDNSQuestionHandle;

typedef TElClassHandle TElDNSQuestionListHandle;

typedef TElClassHandle TElDNSCacheHandle;

typedef TElClassHandle TElDNSMessageExtensionsHandle;

typedef TElClassHandle TElDNSMessageHandle;

typedef TElClassHandle TElDNSClientHandle;

typedef TElClassHandle TElDNSResolverHandle;

typedef void (SB_CALLBACK *TSBDNSClientSendingEvent)(void * _ObjectData, TObjectHandle Sender, TElDNSMessageHandle Request);

typedef void (SB_CALLBACK *TSBDNSClientTimeoutEvent)(void * _ObjectData, TObjectHandle Sender, int8_t * Wait);

typedef void (SB_CALLBACK *TSBDNSResolverPrepareEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcServerName, int32_t szServerName, const char * pcServerAddress, int32_t szServerAddress, uint16_t ServerPort, const char * pcCriteria, int32_t szCriteria, TSBDNSResourceTypeRaw InfoType);

typedef void (SB_CALLBACK *TSBDNSResolverRequestEvent)(void * _ObjectData, TObjectHandle Sender, TElDNSMessageHandle Request);

typedef void (SB_CALLBACK *TSBDNSResolverResponseEvent)(void * _ObjectData, TObjectHandle Sender, TElDNSMessageHandle Response);

typedef void (SB_CALLBACK *TSBDNSResolverErrorEvent)(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode, const char * pcErrorMessage, int32_t szErrorMessage);

typedef void (SB_CALLBACK *TSBDNSResolverTraceEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcInfo, int32_t szInfo);

#ifdef SB_USE_CLASS_TELDNSQUESTION
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestion_Assign(TElDNSQuestionHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestion_Read(TElDNSQuestionHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, uint16_t * Offset);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestion_Write(TElDNSQuestionHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestion_get_Name(TElDNSQuestionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestion_set_Name(TElDNSQuestionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestion_get_ResourceCode(TElDNSQuestionHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestion_set_ResourceCode(TElDNSQuestionHandle _Handle, uint16_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestion_get_ResourceType(TElDNSQuestionHandle _Handle, TSBDNSResourceTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestion_set_ResourceType(TElDNSQuestionHandle _Handle, TSBDNSResourceTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestion_Create(TElDNSQuestionHandle * OutResult);
#endif /* SB_USE_CLASS_TELDNSQUESTION */

#ifdef SB_USE_CLASS_TELDNSQUESTIONLIST
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestionList_Add(TElDNSQuestionListHandle _Handle, TElDNSQuestionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestionList_Assign(TElDNSQuestionListHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestionList_Clear(TElDNSQuestionListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestionList_Delete(TElDNSQuestionListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestionList_IndexOf(TElDNSQuestionListHandle _Handle, TElDNSQuestionHandle Question, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestionList_Insert(TElDNSQuestionListHandle _Handle, int32_t Index, TElDNSQuestionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestionList_Remove(TElDNSQuestionListHandle _Handle, TElDNSQuestionHandle Question, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestionList_get_Count(TElDNSQuestionListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestionList_get_Items(TElDNSQuestionListHandle _Handle, int32_t Index, TElDNSQuestionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSQuestionList_Create(TElDNSQuestionListHandle * OutResult);
#endif /* SB_USE_CLASS_TELDNSQUESTIONLIST */

#ifdef SB_USE_CLASS_TELDNSCACHE
SB_IMPORT uint32_t SB_APIENTRY TElDNSCache_Add(TElDNSCacheHandle _Handle, TElDNSResourceRecordSetHandle Records);
SB_IMPORT uint32_t SB_APIENTRY TElDNSCache_Add_1(TElDNSResourceRecordSetHandle _Handle, TSBDNSResourceTypeRaw ResourceType, TElDNSResourceRecordHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSCache_Add_2(TElDNSResourceRecordSetHandle _Handle, TElDNSResourceRecordHandle ResourceRecord, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSCache_Create(TElDNSResourceRecordSetHandle * OutResult);
#endif /* SB_USE_CLASS_TELDNSCACHE */

#ifdef SB_USE_CLASS_TELDNSMESSAGEEXTENSIONS
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_Assign(TElDNSMessageExtensionsHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_Clear(TElDNSMessageExtensionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_get_Enabled(TElDNSMessageExtensionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_set_Enabled(TElDNSMessageExtensionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_get_DNSSECOK(TElDNSMessageExtensionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_set_DNSSECOK(TElDNSMessageExtensionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_get_Flags(TElDNSMessageExtensionsHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_set_Flags(TElDNSMessageExtensionsHandle _Handle, uint16_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_get_PayloadSize(TElDNSMessageExtensionsHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_set_PayloadSize(TElDNSMessageExtensionsHandle _Handle, uint16_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_get_ResponseCode(TElDNSMessageExtensionsHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_set_ResponseCode(TElDNSMessageExtensionsHandle _Handle, uint16_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_get_Version(TElDNSMessageExtensionsHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_set_Version(TElDNSMessageExtensionsHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessageExtensions_Create(TElDNSMessageExtensionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELDNSMESSAGEEXTENSIONS */

#ifdef SB_USE_CLASS_TELDNSMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_Assign(TElDNSMessageHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_Clear(TElDNSMessageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_Read(TElDNSMessageHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_Write(TElDNSMessageHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_Authenticated(TElDNSMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_Authenticated(TElDNSMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_Authoritative(TElDNSMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_Authoritative(TElDNSMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_CheckingDisabled(TElDNSMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_CheckingDisabled(TElDNSMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_Extensions(TElDNSMessageHandle _Handle, TElDNSMessageExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_Extensions(TElDNSMessageHandle _Handle, TElDNSMessageExtensionsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_ID(TElDNSMessageHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_ID(TElDNSMessageHandle _Handle, uint16_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_MessageType(TElDNSMessageHandle _Handle, TSBDNSMessageTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_MessageType(TElDNSMessageHandle _Handle, TSBDNSMessageTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_OpCode(TElDNSMessageHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_OpCode(TElDNSMessageHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_Operation(TElDNSMessageHandle _Handle, TSBDNSOperationCodeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_Operation(TElDNSMessageHandle _Handle, TSBDNSOperationCodeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_RCode(TElDNSMessageHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_RCode(TElDNSMessageHandle _Handle, uint16_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_RecursionAvailable(TElDNSMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_RecursionAvailable(TElDNSMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_RecursionDesired(TElDNSMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_RecursionDesired(TElDNSMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_ResponseCode(TElDNSMessageHandle _Handle, TSBDNSResponseCodeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_ResponseCode(TElDNSMessageHandle _Handle, TSBDNSResponseCodeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_Truncated(TElDNSMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_Truncated(TElDNSMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_Z(TElDNSMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_Z(TElDNSMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_Questions(TElDNSMessageHandle _Handle, TElDNSQuestionListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_Questions(TElDNSMessageHandle _Handle, TElDNSQuestionListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_Answers(TElDNSMessageHandle _Handle, TElDNSResourceRecordSetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_Answers(TElDNSMessageHandle _Handle, TElDNSResourceRecordSetHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_Authorities(TElDNSMessageHandle _Handle, TElDNSResourceRecordSetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_Authorities(TElDNSMessageHandle _Handle, TElDNSResourceRecordSetHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_get_Additionals(TElDNSMessageHandle _Handle, TElDNSResourceRecordSetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_set_Additionals(TElDNSMessageHandle _Handle, TElDNSResourceRecordSetHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSMessage_Create(TElDNSMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELDNSMESSAGE */

#ifdef SB_USE_CLASS_TELDNSCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_Activate(TElDNSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_Deactivate(TElDNSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_Lookup(TElDNSClientHandle _Handle, const char * pcName, int32_t szName, TSBDNSResourceTypeRaw ResourceType, TElDNSMessageHandle * Response);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_Lookup_1(TElDNSClientHandle _Handle, const char * pcName, int32_t szName, uint8_t ResourceCode, TElDNSMessageHandle * Response);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_get_Active(TElDNSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_get_BoundAddress(TElDNSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_get_BoundPort(TElDNSClientHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_get_UsingIPv6(TElDNSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_get_Address(TElDNSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_set_Address(TElDNSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_get_Binding(TElDNSClientHandle _Handle, TElClientSocketBindingHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_set_Binding(TElDNSClientHandle _Handle, TElClientSocketBindingHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_get_Port(TElDNSClientHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_set_Port(TElDNSClientHandle _Handle, uint16_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_get_Timeout(TElDNSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_set_Timeout(TElDNSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_get_UseIPv6(TElDNSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_set_UseIPv6(TElDNSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_get_UseRecursion(TElDNSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_set_UseRecursion(TElDNSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_get_UseSecurity(TElDNSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_set_UseSecurity(TElDNSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_get_OnSending(TElDNSClientHandle _Handle, TSBDNSClientSendingEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_set_OnSending(TElDNSClientHandle _Handle, TSBDNSClientSendingEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_get_OnTimeout(TElDNSClientHandle _Handle, TSBDNSClientTimeoutEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_set_OnTimeout(TElDNSClientHandle _Handle, TSBDNSClientTimeoutEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDNSClient_Create(TComponentHandle AOwner, TElDNSClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELDNSCLIENT */

#ifdef SB_USE_CLASS_TELDNSRESOLVER
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_Assign(TElDNSResolverHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_Lookup(TElDNSResolverHandle _Handle, const char * pcCriteria, int32_t szCriteria, TSBDNSResourceTypeRaw InfoType, TElDNSResourceRecordSetHandle FoundInfo, TSBDNSSecurityStatusRaw * SecurityStatus, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_get_Port(TElDNSResolverHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_set_Port(TElDNSResolverHandle _Handle, uint16_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_get_Servers(TElDNSResolverHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_set_Servers(TElDNSResolverHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_get_QueryTimeout(TElDNSResolverHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_set_QueryTimeout(TElDNSResolverHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_get_TotalTimeout(TElDNSResolverHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_set_TotalTimeout(TElDNSResolverHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_get_UseIPv6(TElDNSResolverHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_set_UseIPv6(TElDNSResolverHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_get_UseSecurity(TElDNSResolverHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_set_UseSecurity(TElDNSResolverHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_get_OnError(TElDNSResolverHandle _Handle, TSBDNSResolverErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_set_OnError(TElDNSResolverHandle _Handle, TSBDNSResolverErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_get_OnKeyNeeded(TElDNSResolverHandle _Handle, TSBDNSKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_set_OnKeyNeeded(TElDNSResolverHandle _Handle, TSBDNSKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_get_OnKeyValidate(TElDNSResolverHandle _Handle, TSBDNSKeyValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_set_OnKeyValidate(TElDNSResolverHandle _Handle, TSBDNSKeyValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_get_OnPrepare(TElDNSResolverHandle _Handle, TSBDNSResolverPrepareEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_set_OnPrepare(TElDNSResolverHandle _Handle, TSBDNSResolverPrepareEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_get_OnRequest(TElDNSResolverHandle _Handle, TSBDNSResolverRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_set_OnRequest(TElDNSResolverHandle _Handle, TSBDNSResolverRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_get_OnResponse(TElDNSResolverHandle _Handle, TSBDNSResolverResponseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_set_OnResponse(TElDNSResolverHandle _Handle, TSBDNSResolverResponseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_get_OnTrace(TElDNSResolverHandle _Handle, TSBDNSResolverTraceEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_set_OnTrace(TElDNSResolverHandle _Handle, TSBDNSResolverTraceEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDNSResolver_Create(TComponentHandle AOwner, TElDNSResolverHandle * OutResult);
#endif /* SB_USE_CLASS_TELDNSRESOLVER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDNSQuestion_ce_ptr;
extern zend_class_entry *TElDNSQuestionList_ce_ptr;
extern zend_class_entry *TElDNSCache_ce_ptr;
extern zend_class_entry *TElDNSMessageExtensions_ce_ptr;
extern zend_class_entry *TElDNSMessage_ce_ptr;
extern zend_class_entry *TElDNSClient_ce_ptr;
extern zend_class_entry *TElDNSResolver_ce_ptr;

void SB_CALLBACK TSBDNSClientSendingEventRaw(void * _ObjectData, TObjectHandle Sender, TElDNSMessageHandle Request);
void SB_CALLBACK TSBDNSClientTimeoutEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t * Wait);
void SB_CALLBACK TSBDNSResolverPrepareEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcServerName, int32_t szServerName, const char * pcServerAddress, int32_t szServerAddress, uint16_t ServerPort, const char * pcCriteria, int32_t szCriteria, TSBDNSResourceTypeRaw InfoType);
void SB_CALLBACK TSBDNSResolverRequestEventRaw(void * _ObjectData, TObjectHandle Sender, TElDNSMessageHandle Request);
void SB_CALLBACK TSBDNSResolverResponseEventRaw(void * _ObjectData, TObjectHandle Sender, TElDNSMessageHandle Response);
void SB_CALLBACK TSBDNSResolverErrorEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode, const char * pcErrorMessage, int32_t szErrorMessage);
void SB_CALLBACK TSBDNSResolverTraceEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcInfo, int32_t szInfo);
void Register_TElDNSQuestion(TSRMLS_D);
void Register_TElDNSQuestionList(TSRMLS_D);
void Register_TElDNSCache(TSRMLS_D);
void Register_TElDNSMessageExtensions(TSRMLS_D);
void Register_TElDNSMessage(TSRMLS_D);
void Register_TElDNSClient(TSRMLS_D);
void Register_TElDNSResolver(TSRMLS_D);
SB_PHP_FUNCTION(SBDNSSEC, CheckSystemNameServers);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_DNSSEC
SB_IMPORT uint32_t SB_APIENTRY SBDNSSEC_CheckSystemNameServers(TElStringListHandle SL, int8_t UseIPv6, int8_t * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_DNSSEC */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDNSSEC */

