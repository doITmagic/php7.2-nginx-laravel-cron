#ifndef __INC_SBDOMAINKEYS
#define __INC_SBDOMAINKEYS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbencoding.h"
#include "sbstreams.h"
#include "sbhashfunction.h"
#include "sbmath.h"
#include "sbmimeenc.h"
#include "sbmime.h"
#include "sbchsconv.h"
#include "sbchsconvcharsets.h"
#include "sbchscjk.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_DK_DNS_ERROR_SUCCESS 	0
#define SB_DK_DNS_ERROR_NODATA 	1
#define SB_DK_DNS_ERROR_NOPARAMS 	2
#define SB_DK_DNS_ERROR_NOKEY 	3
#define SB_DK_DNS_ERROR_INVALID_KEYTYPE 	4
#define SB_DK_DNS_ERROR_INVALID_KEYDATA 	5
#define SB_DK_SIGNER_ERROR_SUCCESS 	0
#define SB_DK_SIGNER_ERROR_INVALID_STATE 	1
#define SB_DK_SIGNER_ERROR_INVALID_HEADER 	2
#define SB_DK_SIGNER_ERROR_EMPTY_HEADER 	3
#define SB_DK_SIGNER_ERROR_INVALID_SENDER 	4
#define SB_DK_SIGNER_ERROR_SEVERAL_SENDERS 	5
#define SB_DK_SIGNER_ERROR_NO_DOMAIN 	6
#define SB_DK_SIGNER_ERROR_NO_AUTHOR 	7
#define SB_DK_SIGNER_ERROR_NO_PRIVATE_KEY 	8
#define SB_DK_SIGNER_ERROR_NO_SELECTOR 	9
#define SB_DK_SIGNER_ERROR_FAILURE 	10
#define SB_DK_VERIFIER_ERROR_SUCCESS 	0
#define SB_DK_VERIFIER_ERROR_INVALID_STATE 	1
#define SB_DK_VERIFIER_ERROR_INVALID_HEADER 	2
#define SB_DK_VERIFIER_ERROR_NO_ADDRESS 	3
#define SB_DK_VERIFIER_ERROR_NO_SIGNATURE 	4
#define SB_DK_VERIFIER_ERROR_INVALID_FORMAT 	5
#define SB_DK_VERIFIER_ERROR_UNKNOWN_ALGORITHM 	6
#define SB_DK_VERIFIER_ERROR_FAILURE 	7
#define SB_DK_VERIFIER_ERROR_DOMAIN_MISMATCH 	8
#define SB_DK_VERIFIER_ERROR_INVALID_TIMESTAMP 	9
#define SB_DK_VERIFIER_ERROR_SIGNATURE_EXPIRED 	10
#define SB_SDKInvalidPrivateKey 	"Invalid private key"
#define SB_SDKInvalidSignerState 	"Cannot change property value in the current state"
#define SB_SDKCannotGenerateKey 	"Cannot generate DNS key"

typedef TElClassHandle TElDKPublicKeyHandle;

typedef TElDKPublicKeyHandle ElDKPublicKeyHandle;

typedef TElClassHandle TElDKRSAPublicKeyHandle;

typedef TElDKRSAPublicKeyHandle ElDKRSAPublicKeyHandle;

typedef TElClassHandle TElDKDNSRecordHandle;

typedef TElDKDNSRecordHandle ElDKDNSRecordHandle;

typedef TElClassHandle TElDomainKeysClassHandle;

typedef TElDomainKeysClassHandle ElDomainKeysClassHandle;

typedef TElClassHandle TElDomainKeysSignerHandle;

typedef TElDomainKeysSignerHandle ElDomainKeysSignerHandle;

typedef TElClassHandle TElDomainKeysVerifierHandle;

typedef TElDomainKeysVerifierHandle ElDomainKeysVerifierHandle;

typedef TElClassHandle TElDKSignatureHandle;

typedef TElDKSignatureHandle ElDKSignatureHandle;

typedef uint8_t TSBDKPublicKeyTypeRaw;

typedef enum
{
	dkRSA = 0
} TSBDKPublicKeyType;

typedef uint8_t TSBDKCanonicalizationAlgorithmRaw;

typedef enum
{
	dkSimple = 0,
	dkRelaxed = 1
} TSBDKCanonicalizationAlgorithm;

typedef uint8_t TSBDKDigestAlgorithmRaw;

typedef enum
{
	dkSHA1 = 0,
	dkSHA256 = 1
} TSBDKDigestAlgorithm;

typedef uint8_t TSBDKQueryTypeRaw;

typedef enum
{
	dkDNS = 0
} TSBDKQueryType;

typedef uint8_t TSBDKStatusRaw;

typedef enum
{
	dkNone = 0,
	dkGood = 1,
	dkBad = 2,
	dkNoKey = 3,
	dkRevoked = 4,
	dkNoSignature = 5,
	dkBadFormat = 6,
	dkNonParticipant = 7,
	dkUnknown = 8,
	dkExpired = 9,
	dkNotExact = 10,
	dkBadGranularity = 11
} TSBDKStatus;

typedef uint8_t TSBDomainKeysVerifierStateRaw;

typedef enum
{
	dkvHeaders = 0,
	dkvBody = 1
} TSBDomainKeysVerifierState;

typedef uint8_t TSBDomainKeysVerifierSignatureRaw;

typedef enum
{
	dkvSender = 0,
	dkvAuthor = 1
} TSBDomainKeysVerifierSignature;

typedef uint8_t TSBDomainKeysSignerStateRaw;

typedef enum
{
	dksHeaders = 0,
	dksBody = 1
} TSBDomainKeysSignerState;

#ifdef SB_USE_CLASS_TELDKPUBLICKEY
SB_IMPORT uint32_t SB_APIENTRY TElDKPublicKey_Assign(TElDKPublicKeyHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDKPublicKey_Clear(TElDKPublicKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDKPublicKey_Clone(TElDKPublicKeyHandle _Handle, TElDKPublicKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKPublicKey_Revoke(TElDKPublicKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDKPublicKey_Load(TElDKPublicKeyHandle _Handle, const char * pcData, int32_t szData, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKPublicKey_Save(TElDKPublicKeyHandle _Handle, char * pcData, int32_t * szData, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKPublicKey_get_Available(TElDKPublicKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKPublicKey_get_KeyType(TElDKPublicKeyHandle _Handle, TSBDKPublicKeyTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKPublicKey_get_Revoked(TElDKPublicKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKPublicKey_Create(TElDKPublicKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELDKPUBLICKEY */

#ifdef SB_USE_CLASS_TELDKRSAPUBLICKEY
SB_IMPORT uint32_t SB_APIENTRY TElDKRSAPublicKey_Assign(TElDKRSAPublicKeyHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDKRSAPublicKey_Clear(TElDKRSAPublicKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDKRSAPublicKey_Clone(TElDKRSAPublicKeyHandle _Handle, TElDKPublicKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKRSAPublicKey_Generate(TElDKRSAPublicKeyHandle _Handle, int32_t Bits, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKRSAPublicKey_Load(TElDKRSAPublicKeyHandle _Handle, const char * pcData, int32_t szData, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKRSAPublicKey_Save(TElDKRSAPublicKeyHandle _Handle, char * pcData, int32_t * szData, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKRSAPublicKey_get_Exponent(TElDKRSAPublicKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKRSAPublicKey_get_Modulus(TElDKRSAPublicKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKRSAPublicKey_Create(TElDKRSAPublicKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELDKRSAPUBLICKEY */

#ifdef SB_USE_CLASS_TELDKDNSRECORD
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_Assign(TElDKDNSRecordHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_Clear(TElDKDNSRecordHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_CreatePublicKey(TElDKDNSRecordHandle _Handle, TSBDKPublicKeyTypeRaw KeyType);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_Load(TElDKDNSRecordHandle _Handle, const char * pcData, int32_t szData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_Save(TElDKDNSRecordHandle _Handle, char * pcData, int32_t * szData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_get_KeyGranularity(TElDKDNSRecordHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_set_KeyGranularity(TElDKDNSRecordHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_get_Notes(TElDKDNSRecordHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_set_Notes(TElDKDNSRecordHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_get_PublicKey(TElDKDNSRecordHandle _Handle, TElDKPublicKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_get_TestMode(TElDKDNSRecordHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_set_TestMode(TElDKDNSRecordHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_get_ExactMode(TElDKDNSRecordHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_set_ExactMode(TElDKDNSRecordHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_get_ServiceType(TElDKDNSRecordHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_set_ServiceType(TElDKDNSRecordHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_get_Version(TElDKDNSRecordHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_set_Version(TElDKDNSRecordHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_get_Algorithms(TElDKDNSRecordHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_set_Algorithms(TElDKDNSRecordHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDKDNSRecord_Create(TElDKDNSRecordHandle * OutResult);
#endif /* SB_USE_CLASS_TELDKDNSRECORD */

#ifdef SB_USE_CLASS_TELDOMAINKEYSCLASS
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysClass_Create(TComponentHandle AOwner, TComponentHandle * OutResult);
#endif /* SB_USE_CLASS_TELDOMAINKEYSCLASS */

#ifdef SB_USE_CLASS_TELDOMAINKEYSSIGNER
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_AddHash(TElDomainKeysSignerHandle _Handle, void * Data, int32_t DataSize, int8_t BodyHash);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_CanonicalizeBody(TElDomainKeysSignerHandle _Handle, TStringsHandle Body, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_CanonicalizeHeader(TElDomainKeysSignerHandle _Handle, TStringsHandle Header, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_ClearPrivateKey(TElDomainKeysSignerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_GetHash(TElDomainKeysSignerHandle _Handle, TSBDKDigestAlgorithmRaw HashAlgorithm, int8_t BodyHash, uint8_t pHash[], int32_t * szHash, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_ProcessHeader(TElDomainKeysSignerHandle _Handle, TStringsHandle Header, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_ProcessBodyLine(TElDomainKeysSignerHandle _Handle, const char * pcS, int32_t szS, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_ProcessMessage(TElDomainKeysSignerHandle _Handle, const char * pcMessageText, int32_t szMessageText, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_Reset(TElDomainKeysSignerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_SetPrivateKey(TElDomainKeysSignerHandle _Handle, void * Modulus, int32_t ModulusSize, void * Exponent, int32_t ExponentSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_SetPrivateKey_1(TElDomainKeysSignerHandle _Handle, void * Buffer, int32_t BufferSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_Sign(TElDomainKeysSignerHandle _Handle, TStringsHandle Signature, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_get_BodyCanonicalization(TElDomainKeysSignerHandle _Handle, TSBDKCanonicalizationAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_set_BodyCanonicalization(TElDomainKeysSignerHandle _Handle, TSBDKCanonicalizationAlgorithmRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_get_HeaderCanonicalization(TElDomainKeysSignerHandle _Handle, TSBDKCanonicalizationAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_set_HeaderCanonicalization(TElDomainKeysSignerHandle _Handle, TSBDKCanonicalizationAlgorithmRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_get_DigestAlgorithm(TElDomainKeysSignerHandle _Handle, TSBDKDigestAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_set_DigestAlgorithm(TElDomainKeysSignerHandle _Handle, TSBDKDigestAlgorithmRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_get_Domain(TElDomainKeysSignerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_get_BodyHashLimit(TElDomainKeysSignerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_set_BodyHashLimit(TElDomainKeysSignerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_get_HeaderFields(TElDomainKeysSignerHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_set_HeaderFields(TElDomainKeysSignerHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_get_QueryType(TElDomainKeysSignerHandle _Handle, TSBDKQueryTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_set_QueryType(TElDomainKeysSignerHandle _Handle, TSBDKQueryTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_get_Selector(TElDomainKeysSignerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_set_Selector(TElDomainKeysSignerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_get_SignatureAlgorithm(TElDomainKeysSignerHandle _Handle, TSBDKPublicKeyTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_set_SignatureAlgorithm(TElDomainKeysSignerHandle _Handle, TSBDKPublicKeyTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_get_SignatureExpiration(TElDomainKeysSignerHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_set_SignatureExpiration(TElDomainKeysSignerHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_get_UseCopiedFields(TElDomainKeysSignerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_set_UseCopiedFields(TElDomainKeysSignerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_get_UserIdentity(TElDomainKeysSignerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysSigner_Create(TComponentHandle AOwner, TElDomainKeysSignerHandle * OutResult);
#endif /* SB_USE_CLASS_TELDOMAINKEYSSIGNER */

#ifdef SB_USE_CLASS_TELDOMAINKEYSVERIFIER
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysVerifier_ProcessHeader(TElDomainKeysVerifierHandle _Handle, TStringsHandle Header, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysVerifier_ProcessHeader_1(TElDomainKeysVerifierHandle _Handle, const char * pcSource, int32_t szSource, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysVerifier_ProcessBodyLine(TElDomainKeysVerifierHandle _Handle, const char * pcS, int32_t szS, int32_t SignatureIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysVerifier_ProcessMessage(TElDomainKeysVerifierHandle _Handle, TStreamHandle Stream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysVerifier_Verify(TElDomainKeysVerifierHandle _Handle, int32_t SigIndex, TElDKDNSRecordHandle DNSRec, TSBDKStatusRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysVerifier_Reset(TElDomainKeysVerifierHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysVerifier_get_Signatures(TElDomainKeysVerifierHandle _Handle, int32_t Index, TElDKSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysVerifier_get_SignaturesCount(TElDomainKeysVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDomainKeysVerifier_Create(TComponentHandle AOwner, TElDomainKeysVerifierHandle * OutResult);
#endif /* SB_USE_CLASS_TELDOMAINKEYSVERIFIER */

#ifdef SB_USE_CLASS_TELDKSIGNATURE
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_Clear(TElDKSignatureHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_HashClear(TElDKSignatureHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_Verify(TElDKSignatureHandle _Handle, TElDKDNSRecordHandle DNS, TSBDKStatusRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_get_Available(TElDKSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_get_HeaderCanonicalization(TElDKSignatureHandle _Handle, TSBDKCanonicalizationAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_get_BodyCanonicalization(TElDKSignatureHandle _Handle, TSBDKCanonicalizationAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_get_DigestAlgorithm(TElDKSignatureHandle _Handle, TSBDKDigestAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_get_Domain(TElDKSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_set_Domain(TElDKSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_get_Address(TElDKSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_get_QueryType(TElDKSignatureHandle _Handle, TSBDKQueryTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_get_Selector(TElDKSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_get_SignatureAlgorithm(TElDKSignatureHandle _Handle, TSBDKPublicKeyTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_get_BodyHashLimit(TElDKSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_set_BodyHashLimit(TElDKSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_get_VerifierBodyHashLimit(TElDKSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_set_VerifierBodyHashLimit(TElDKSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_get_SignatureTime(TElDKSignatureHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_set_SignatureTime(TElDKSignatureHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_get_SignatureExpired(TElDKSignatureHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_set_SignatureExpired(TElDKSignatureHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_get_Hashed(TElDKSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_set_Hashed(TElDKSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDKSignature_Create(TElDKSignatureHandle * OutResult);
#endif /* SB_USE_CLASS_TELDKSIGNATURE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDKPublicKey_ce_ptr;
extern zend_class_entry *TElDKRSAPublicKey_ce_ptr;
extern zend_class_entry *TElDKDNSRecord_ce_ptr;
extern zend_class_entry *TElDomainKeysClass_ce_ptr;
extern zend_class_entry *TElDomainKeysSigner_ce_ptr;
extern zend_class_entry *TElDomainKeysVerifier_ce_ptr;
extern zend_class_entry *TElDKSignature_ce_ptr;

void Register_TElDKPublicKey(TSRMLS_D);
void Register_TElDKRSAPublicKey(TSRMLS_D);
void Register_TElDKDNSRecord(TSRMLS_D);
void Register_TElDomainKeysClass(TSRMLS_D);
void Register_TElDomainKeysSigner(TSRMLS_D);
void Register_TElDomainKeysVerifier(TSRMLS_D);
void Register_TElDKSignature(TSRMLS_D);
void Register_SBDomainKeys_Constants(int module_number TSRMLS_DC);
void Register_SBDomainKeys_Enum_Flags(TSRMLS_D);
void Register_SBDomainKeys_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDOMAINKEYS */

