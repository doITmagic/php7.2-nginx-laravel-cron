#ifndef __INC_SBDROPBOXDATASTORAGE
#define __INC_SBDROPBOXDATASTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbencoding.h"
#include "sbstringlist.h"
#include "sbdatastorage.h"
#include "sbdatastorageutils.h"
#include "sbstrutils.h"
#include "sbrandom.h"
#include "sbhashfunction.h"
#include "sbjson.h"
#include "sboauth2.h"
#include "sbhttpsconstants.h"
#include "sbhttpscommon.h"
#include "sbhttpsclient.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDropboxDataStorageHandle;

typedef TElClassHandle TElDropboxAccountInfoHandle;

typedef TElClassHandle TElDropboxTeamMemberInfoHandle;

typedef TElClassHandle TElDropboxSharedFilePermissionHandle;

typedef TElClassHandle TElDropboxSharedFilePermissionsHandle;

typedef TElClassHandle TElDropboxSharedFolderPermissionHandle;

typedef TElClassHandle TElDropboxSharedFolderPermissionsHandle;

typedef TElClassHandle TElDropboxUserPermissionHandle;

typedef TElClassHandle TElDropboxUserPermissionsHandle;

typedef TElClassHandle TElDropboxUserMembershipInfoHandle;

typedef TElClassHandle TElDropboxGroupMembershipInfoHandle;

typedef TElClassHandle TElDropboxInviteeMembershipInfoHandle;

typedef TElClassHandle TElDropboxDataStorageFileSystemObjectHandle;

typedef TElClassHandle TElDropboxDataStorageFolderHandle;

typedef TElClassHandle TElDropboxDataStorageSharedFileHandle;

typedef TElClassHandle TElDropboxDataStorageSharedFolderHandle;

typedef TElClassHandle TElDropboxDataStorageSharedLinkHandle;

typedef TElClassHandle TElDropboxFileSharingInfoHandle;

typedef TElClassHandle TElDropboxFolderSharingInfoHandle;

typedef TElClassHandle TElDropboxMediaInfoHandle;

typedef TElClassHandle TElDropboxDataStorageObjectHandle;

typedef TElClassHandle TElDropboxDataStorageFileHandle;

typedef TElClassHandle TElDropboxDataStorageDeletedObjectHandle;

typedef TElClassHandle TElDropboxDataStorageSharedObjectHandle;

typedef uint8_t TSBDropboxAccountTypeRaw;

typedef enum
{
	datUnknown = 0,
	datBasic = 1,
	datPro = 2,
	datBusiness = 3
} TSBDropboxAccountType;

typedef uint8_t TSBDropboxSharedFolderMemberPolicyRaw;

typedef enum
{
	dmpUnknown = 0,
	dmpTeam = 1,
	dmpAnyone = 2
} TSBDropboxSharedFolderMemberPolicy;

typedef uint8_t TSBDropboxSharedFolderJoinPolicyRaw;

typedef enum
{
	djpUnknown = 0,
	djpFromTeamOnly = 1,
	djpFromAnyone = 2
} TSBDropboxSharedFolderJoinPolicy;

typedef uint8_t TSBDropboxSharedLinkCreatePolicyRaw;

typedef enum
{
	dcpUnknown = 0,
	dcpDefaultPublic = 1,
	dcpDefaultTeampOnly = 2,
	dcpTeamOnly = 3
} TSBDropboxSharedLinkCreatePolicy;

typedef uint8_t TSBDropboxDataStorageIdentifierTypeRaw;

typedef enum
{
	ditPath = 0,
	ditID = 1,
	ditRevision = 2
} TSBDropboxDataStorageIdentifierType;

typedef uint8_t TSBDropboxSearchModeRaw;

typedef enum
{
	dsmUnknown = 0,
	dsmFilename = 1,
	dsmFilenameAndContent = 2,
	dsmDeletedFilename = 3
} TSBDropboxSearchMode;

typedef uint8_t TSBDropboxSearchMatchTypeRaw;

typedef enum
{
	dsmtUnspecified = 0,
	dsmtFilename = 1,
	dsmtContent = 2,
	dsmtFilenameAndContent = 3
} TSBDropboxSearchMatchType;

typedef uint8_t TSBDropboxMetadataLocationRaw;

typedef enum
{
	dmlColocatedObjects = 0,
	dmlMetadataSubdir = 1,
	dmlMetadataDir = 2
} TSBDropboxMetadataLocation;

typedef uint8_t TSBDropboxDataStorageWriteModeRaw;

typedef enum
{
	wmUnknown = 0,
	wmAdd = 1,
	wmOverwrite = 2,
	wmUpdate = 3
} TSBDropboxDataStorageWriteMode;

typedef uint8_t TSBDropboxImageSizeRaw;

typedef enum
{
	disUnknown = 0,
	disDefault = 1,
	disXS = 2,
	disS = 3,
	disM = 4,
	disL = 5,
	disXL = 6
} TSBDropboxImageSize;

typedef uint8_t TSBDropboxDocumentFilterRaw;

typedef enum
{
	dfUnknown = 0,
	dfAccessed = 1,
	dfCreated = 2
} TSBDropboxDocumentFilter;

typedef uint8_t TSBDropboxDocumentSortModeRaw;

typedef enum
{
	smUnknown = 0,
	smAccessed = 1,
	smModified = 2,
	smCreated = 3
} TSBDropboxDocumentSortMode;

typedef uint8_t TSBDropboxDocumentSortOrderRaw;

typedef enum
{
	soUnknown = 0,
	soAscending = 1,
	soDescending = 2
} TSBDropboxDocumentSortOrder;

typedef uint8_t TSBDropboxObjectAccessLevelRaw;

typedef enum
{
	alUnknown = 0,
	alOwner = 1,
	alEditor = 2,
	alViewer = 3,
	alViewerNoComment = 4
} TSBDropboxObjectAccessLevel;

typedef uint8_t TSBDropboxObjectUserPolicyRaw;

typedef enum
{
	oupUnknown = 0,
	oupTeam = 1,
	oupAnyone = 2
} TSBDropboxObjectUserPolicy;

typedef uint8_t TSBDropboxACLUpdatePolicyRaw;

typedef enum
{
	aupUnknown = 0,
	aupOwner = 1,
	aupEditors = 2
} TSBDropboxACLUpdatePolicy;

typedef uint8_t TSBDropboxSharedLinkPolicyRaw;

typedef enum
{
	slpUnknown = 0,
	slpAnyone = 1,
	slpUsers = 2
} TSBDropboxSharedLinkPolicy;

typedef uint8_t TSBDropboxSharedObjectVisibilityRaw;

typedef enum
{
	sovUnknown = 0,
	sovPublic = 1,
	sovTeamOnly = 2,
	sovPassword = 3,
	sovTeamAndPassword = 4,
	sovSharedFolderOnly = 5
} TSBDropboxSharedObjectVisibility;

typedef uint8_t TSBDropboxSharedObjectAccessFailureReasonRaw;

typedef enum
{
	afrUnknown = 0,
	afrLoginRequired = 1,
	afrEmailVerifyRequired = 2,
	afrPasswordRequired = 3,
	afrTeamOnly = 4,
	afrOwnerOnly = 5
} TSBDropboxSharedObjectAccessFailureReason;

typedef uint8_t TSBDropboxGroupManagementTypeRaw;

typedef enum
{
	gmtUnknown = 0,
	gmtUserManaged = 1,
	gmtCompanyManaged = 2,
	gmtSystemManaged = 3
} TSBDropboxGroupManagementType;

typedef uint8_t TSBDropboxGroupTypeRaw;

typedef enum
{
	gtUnknown = 0,
	gtTeam = 1,
	gtUserManaged = 2
} TSBDropboxGroupType;

typedef uint8_t TSBDropboxSharedFileActionRaw;

typedef enum
{
	sfaUnknown = 0,
	sfaEditContents = 1,
	sfaInviteViewer = 2,
	sfaInviteViewerNoComment = 3,
	sfaUnshare = 4,
	sfaRelinquishMembership = 5,
	sfaCreateLink = 6
} TSBDropboxSharedFileAction;

typedef uint32_t TSBDropboxSharedFileActionsRaw;

typedef enum 
{
	f_sfaUnknown = 1,
	f_sfaEditContents = 2,
	f_sfaInviteViewer = 4,
	f_sfaInviteViewerNoComment = 8,
	f_sfaUnshare = 16,
	f_sfaRelinquishMembership = 32,
	f_sfaCreateLink = 64
} TSBDropboxSharedFileActions;

typedef uint8_t TSBDropboxSharedFolderActionRaw;

typedef enum
{
	sdaUnknown = 0,
	sdaChangeOptions = 1,
	sdaEditContents = 2,
	sdaInviteEditor = 3,
	sdaInviteViewer = 4,
	sdaInviteViewerNoComment = 5,
	sdaRelinquishMembership = 6,
	sdaUnmount = 7,
	sdaUnshare = 8,
	sdaLeaveACopy = 9,
	sdaCreateLink = 10
} TSBDropboxSharedFolderAction;

typedef uint32_t TSBDropboxSharedFolderActionsRaw;

typedef enum 
{
	f_sdaUnknown = 1,
	f_sdaChangeOptions = 2,
	f_sdaEditContents = 4,
	f_sdaInviteEditor = 8,
	f_sdaInviteViewer = 16,
	f_sdaInviteViewerNoComment = 32,
	f_sdaRelinquishMembership = 64,
	f_sdaUnmount = 128,
	f_sdaUnshare = 256,
	f_sdaLeaveACopy = 512,
	f_sdaCreateLink = 1024
} TSBDropboxSharedFolderActions;

typedef uint8_t TSBDropboxPermissionDeniedReasonRaw;

typedef enum
{
	pdrUnknown = 0,
	pdrUserNotSameTeamAsOwner = 1,
	pdrUserNotAllowedByOwner = 2,
	pdrTargetIsIndirectMember = 3,
	pdrTargetIsOwner = 4,
	pdrTargetIsSelf = 5,
	pdrTargetNotActive = 6,
	pdrFolderIsLimitedTeamFolder = 7
} TSBDropboxPermissionDeniedReason;

typedef uint8_t TSBDropboxUserActionRaw;

typedef enum
{
	uaUnknown = 0,
	uaLeaveACopy = 1,
	uaMakeEditor = 2,
	uaMakeOwner = 3,
	uaMakeViewer = 4,
	uaMakeViewerNoComment = 5,
	uaRemove = 6
} TSBDropboxUserAction;

typedef uint32_t TSBDropboxUserActionsRaw;

typedef enum 
{
	f_uaUnknown = 1,
	f_uaLeaveACopy = 2,
	f_uaMakeEditor = 4,
	f_uaMakeOwner = 8,
	f_uaMakeViewer = 16,
	f_uaMakeViewerNoComment = 32,
	f_uaRemove = 64
} TSBDropboxUserActions;

typedef uint8_t TSBDropboxMetadataTypeRaw;

typedef enum
{
	dmtNotAvailable = 0,
	dmtPhoto = 1,
	dmtVideo = 2
} TSBDropboxMetadataType;

#ifdef SB_USE_CLASS_TELDROPBOXDATASTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_StartAuthorization(TElDropboxDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CompleteAuthorization(TElDropboxDataStorageHandle _Handle, const char * pcAuthorizationCode, int32_t szAuthorizationCode);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CancelAuthorization(TElDropboxDataStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CloseSession(TElDropboxDataStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RequestAccountInfo(TElDropboxDataStorageHandle _Handle, const char * pcAccountID, int32_t szAccountID, TElDropboxAccountInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RequestAccountInfos(TElDropboxDataStorageHandle _Handle, TElStringListHandle AccountIDs, TListHandle AccountInfos);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RefreshSpaceUsage(TElDropboxDataStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_AcquireObject(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_AcquireObject_1(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, const char * pcRev, int32_t szRev, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_AcquireObject_2(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, TSBDropboxDataStorageIdentifierTypeRaw IdentifierType, int8_t IncludeMediaInfo, int8_t IncludeDeleted, int8_t IncludeHasExplicitSharedMembers, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_AcquireObject_3(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_List(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_List_1(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFolderHandle Dir, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_List_2(TElCustomDataStorageHandle _Handle, TElDataStorageObjectListHandle Objs);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CreateObject(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CreateObject_1(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, int8_t Folder, int8_t AutoRename, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CreateObject_2(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, TElCustomDataStorageSecurityHandlerHandle Handler, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CreateFolder(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, TElDropboxDataStorageFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CreateFolder_1(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, int8_t AutoRename, TElDropboxDataStorageFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_DeleteObject(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_DeleteObject_1(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_DeleteObject_2(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_DeleteObjects(TElDropboxDataStorageHandle _Handle, TElStringListHandle Paths, char * pcAsyncJobID, int32_t * szAsyncJobID);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_DeleteObjectsCompleted(TElDropboxDataStorageHandle _Handle, const char * pcAsyncJobID, int32_t szAsyncJobID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_DeleteObjectPermanently(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_DeleteObjectPermanently_1(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ObjectExists(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ObjectExists_1(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, const char * pcRev, int32_t szRev, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ObjectExists_2(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle Obj, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ObjectExists_3(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, TSBDropboxDataStorageIdentifierTypeRaw IdentifierType, int8_t IncludeMediaInfo, int8_t IncludeDeleted, int8_t IncludeHasExplicitSharedMembers, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RefreshObject(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_WriteObject(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, TStreamHandle Data, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_WriteObject_1(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle Obj, TStreamHandle Data, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_WriteObject_2(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, const char * pcContentType, int32_t szContentType, TSBDropboxDataStorageWriteModeRaw WriteMode, const char * pcRev, int32_t szRev, int8_t AutoRename, int64_t ClientModified, int8_t Mute, TStreamHandle Data, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_WriteObject_3(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TStreamHandle Strm, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ReadObject(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ReadObject_1(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, TSBDropboxDataStorageIdentifierTypeRaw IdentifierType, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ReadObject_2(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle Obj, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ReadObject_3(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle Obj, const char * pcRev, int32_t szRev, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ReadObject_4(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ReadBlock(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ReadBlock_1(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, TSBDropboxDataStorageIdentifierTypeRaw IdentifierType, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ReadBlock_2(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_Search(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, const char * pcQuery, int32_t szQuery, int8_t IncludeDeleted, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_Search_1(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, const char * pcQuery, int32_t szQuery, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_Search_2(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, const char * pcQuery, int32_t szQuery, TSBDropboxSearchModeRaw SearchMode, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_Search_3(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, const char * pcQuery, int32_t szQuery, int32_t Start, int32_t MaxResults, TSBDropboxSearchModeRaw SearchMode, TElDataStorageObjectListHandle Objects, int8_t * MoreResultsAvailable, int32_t * NextStart);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CopyObject(TElDropboxDataStorageHandle _Handle, const char * pcSourcePath, int32_t szSourcePath, const char * pcDestPath, int32_t szDestPath, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CopyObject_1(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle Obj, const char * pcDestPath, int32_t szDestPath, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CopyObject_2(TElDropboxDataStorageHandle _Handle, const char * pcSourcePath, int32_t szSourcePath, const char * pcDestPath, int32_t szDestPath, int8_t AllowSharedFolder, int8_t AutoRename, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CopyObject_3(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CopyObjects(TElDropboxDataStorageHandle _Handle, TElStringListHandle SourcePaths, TElStringListHandle DestPaths, char * pcAsyncJobID, int32_t * szAsyncJobID);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CopyObjects_1(TElDropboxDataStorageHandle _Handle, TElStringListHandle SourcePaths, TElStringListHandle DestPaths, int8_t AllowSharedFolder, int8_t AutoRename, char * pcAsyncJobID, int32_t * szAsyncJobID);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CopyObjectsCompleted(TElDropboxDataStorageHandle _Handle, const char * pcAsyncJobID, int32_t szAsyncJobID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CopyObjectFromRef(TElDropboxDataStorageHandle _Handle, const char * pcCopyRef, int32_t szCopyRef, const char * pcDestPath, int32_t szDestPath, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CreateCopyReference(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CreateCopyReference_1(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle Obj, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_GetPreview(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_GetPreview_1(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle Obj, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_GetPreview_2(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, TSBDropboxDataStorageIdentifierTypeRaw IdentifierType, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_GetDirectLink(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_GetDirectLink_1(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle Obj, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_GetThumbnail(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, const char * pcImageFormat, int32_t szImageFormat, TSBDropboxImageSizeRaw Size, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_GetThumbnail_1(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle Obj, const char * pcImageFormat, int32_t szImageFormat, TSBDropboxImageSizeRaw Size, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_GetThumbnail_2(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, TSBDropboxDataStorageIdentifierTypeRaw IdentifierType, const char * pcImageFormat, int32_t szImageFormat, TSBDropboxImageSizeRaw Size, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RenameObject(TElDropboxDataStorageHandle _Handle, const char * pcSourcePath, int32_t szSourcePath, const char * pcDestPath, int32_t szDestPath);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RenameObject_1(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle Obj, const char * pcDestPath, int32_t szDestPath);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RenameObject_2(TElDropboxDataStorageHandle _Handle, const char * pcSourcePath, int32_t szSourcePath, const char * pcDestPath, int32_t szDestPath, int8_t AllowSharedFolder, int8_t AutoRename);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RenameObjects(TElDropboxDataStorageHandle _Handle, TElStringListHandle SourcePaths, TElStringListHandle DestPaths, char * pcAsyncJobID, int32_t * szAsyncJobID);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RenameObjects_1(TElDropboxDataStorageHandle _Handle, TElStringListHandle SourcePaths, TElStringListHandle DestPaths, int8_t AllowSharedFolder, int8_t AutoRename, char * pcAsyncJobID, int32_t * szAsyncJobID);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RenameObjectsCompleted(TElDropboxDataStorageHandle _Handle, const char * pcAsyncJobID, int32_t szAsyncJobID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RestoreObject(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, const char * pcRev, int32_t szRev);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RestoreObject_1(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, const char * pcRev, int32_t szRev, int8_t AcquireObject, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListRevisions(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListRevisions_1(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle Obj, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListRevisions_2(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, int32_t MaxRevisions, TElDataStorageObjectListHandle Objects, int8_t * IsDeleted);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListRevisions_3(TElDropboxDataStorageHandle _Handle, TElDropboxDataStorageFileSystemObjectHandle Obj, int32_t MaxRevisions, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_SaveURL(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, const char * pcURL, int32_t szURL, char * pcAsyncJobID, int32_t * szAsyncJobID);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_SaveURLCompleted(TElDropboxDataStorageHandle _Handle, const char * pcAsyncJobID, int32_t szAsyncJobID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListDocuments(TElDropboxDataStorageHandle _Handle, TSBDropboxDocumentFilterRaw FilterBy, TSBDropboxDocumentSortModeRaw SortBy, TSBDropboxDocumentSortOrderRaw SortOrder, TElStringListHandle ObjectIDs);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_InviteFileUsers(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, TElStringListHandle Users, const char * pcInvitationMessage, int32_t szInvitationMessage, int8_t IsComment, int8_t Quiet, TSBDropboxObjectAccessLevelRaw AccessLevel);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RemoveFileUser(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, const char * pcUser, int32_t szUser);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_UnshareFile(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_UpdateFileUser(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, const char * pcUser, int32_t szUser, TSBDropboxObjectAccessLevelRaw AccessLevel);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_InviteFolderUsers(TElDropboxDataStorageHandle _Handle, const char * pcSharedFolderID, int32_t szSharedFolderID, TElStringListHandle Users, TSBDropboxObjectAccessLevelRaw AccessLevel, const char * pcInvitationMessage, int32_t szInvitationMessage, int8_t Quiet);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RemoveFolderUser(TElDropboxDataStorageHandle _Handle, const char * pcSharedFolderID, int32_t szSharedFolderID, const char * pcUser, int32_t szUser, int8_t LeaveACopy);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_UpdateFolderUser(TElDropboxDataStorageHandle _Handle, const char * pcSharedFolderID, int32_t szSharedFolderID, const char * pcUser, int32_t szUser, TSBDropboxObjectAccessLevelRaw AccessLevel);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_UpdateFolderPolicy(TElDropboxDataStorageHandle _Handle, const char * pcSharedFolderID, int32_t szSharedFolderID, TSBDropboxObjectUserPolicyRaw UserPolicy, TSBDropboxACLUpdatePolicyRaw AclUpdatePolicy, TSBDropboxSharedLinkPolicyRaw SharedLinkPolicy);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ShareFolder(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, TSBDropboxObjectUserPolicyRaw UserPolicy, TSBDropboxACLUpdatePolicyRaw AclUpdatePolicy, TSBDropboxSharedLinkPolicyRaw SharedLinkPolicy, char * pcSharedFolderID, int32_t * szSharedFolderID);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_UnshareFolder(TElDropboxDataStorageHandle _Handle, const char * pcSharedFolderID, int32_t szSharedFolderID, int8_t LeaveACopy);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_MountFolder(TElDropboxDataStorageHandle _Handle, const char * pcSharedFolderID, int32_t szSharedFolderID);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_UnmountFolder(TElDropboxDataStorageHandle _Handle, const char * pcSharedFolderID, int32_t szSharedFolderID);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RelinquishFileAccess(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RelinquishFolderAccess(TElDropboxDataStorageHandle _Handle, const char * pcSharedFolderID, int32_t szSharedFolderID, int8_t LeaveACopy);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_AcquireSharedLink(TElDropboxDataStorageHandle _Handle, const char * pcLink, int32_t szLink, const char * pcSubPath, int32_t szSubPath, const char * pcPassword, int32_t szPassword, TElDropboxDataStorageSharedLinkHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_AcquireSharedLink_1(TElDropboxDataStorageHandle _Handle, const char * pcLink, int32_t szLink, TElDropboxDataStorageSharedLinkHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CreateSharedLink(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, TSBDropboxSharedObjectVisibilityRaw Visibility, const char * pcPassword, int32_t szPassword, int64_t Expires, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_CreateSharedLink_1(TElDropboxDataStorageHandle _Handle, const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ReadSharedLink(TElDropboxDataStorageHandle _Handle, const char * pcLink, int32_t szLink, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ReadSharedLink_1(TElDropboxDataStorageHandle _Handle, const char * pcLink, int32_t szLink, const char * pcSubPath, int32_t szSubPath, const char * pcPassword, int32_t szPassword, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListSharedLinks(TElDropboxDataStorageHandle _Handle, TElDataStorageObjectListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListSharedLinks_1(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, TSBDropboxDataStorageIdentifierTypeRaw IdentifierType, int8_t DirectOnly, TElDataStorageObjectListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListSharedLinks_2(TElDropboxDataStorageHandle _Handle, TStringListHandle OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ModifySharedLink(TElDropboxDataStorageHandle _Handle, const char * pcLink, int32_t szLink, TSBDropboxSharedObjectVisibilityRaw Visibility, const char * pcPassword, int32_t szPassword, int64_t Expires, int8_t RemoveExpiration);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_RevokeSharedLink(TElDropboxDataStorageHandle _Handle, const char * pcLink, int32_t szLink);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_AcquireSharedFile(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, TElDropboxDataStorageSharedFileHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_AcquireSharedFile_1(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, TSBDropboxSharedFileActionRaw Action, TElDropboxDataStorageSharedFileHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_AcquireSharedFile_2(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, TSBDropboxSharedFileActionsRaw Actions, TElDropboxDataStorageSharedFileHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_AcquireSharedFolder(TElDropboxDataStorageHandle _Handle, const char * pcSharedFolderID, int32_t szSharedFolderID, TElDropboxDataStorageSharedFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_AcquireSharedFolder_1(TElDropboxDataStorageHandle _Handle, const char * pcSharedFolderID, int32_t szSharedFolderID, TSBDropboxSharedFolderActionRaw Action, TElDropboxDataStorageSharedFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_AcquireSharedFolder_2(TElDropboxDataStorageHandle _Handle, const char * pcSharedFolderID, int32_t szSharedFolderID, TSBDropboxSharedFolderActionsRaw Actions, TElDropboxDataStorageSharedFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListSharedFolders(TElDropboxDataStorageHandle _Handle, TElDataStorageObjectListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListSharedFolders_1(TElDropboxDataStorageHandle _Handle, TSBDropboxSharedFolderActionsRaw Actions, TElDataStorageObjectListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListMountableSharedFolders(TElDropboxDataStorageHandle _Handle, TElDataStorageObjectListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListMountableSharedFolders_1(TElDropboxDataStorageHandle _Handle, TSBDropboxSharedFolderActionsRaw Actions, TElDataStorageObjectListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListSharedFiles(TElDropboxDataStorageHandle _Handle, TElDataStorageObjectListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListSharedFiles_1(TElDropboxDataStorageHandle _Handle, TSBDropboxSharedFileActionsRaw Actions, TElDataStorageObjectListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_TransferSharedFolderOwnership(TElDropboxDataStorageHandle _Handle, const char * pcSharedFolderID, int32_t szSharedFolderID, const char * pcDropboxUserID, int32_t szDropboxUserID);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListSharedFileUsers(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, int8_t IncludeInherited, TListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListSharedFileUsers_1(TElDropboxDataStorageHandle _Handle, const char * pcIdentifier, int32_t szIdentifier, TSBDropboxUserActionsRaw Actions, int8_t IncludeInherited, TListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListSharedFolderUsers(TElDropboxDataStorageHandle _Handle, const char * pcSharedFolderID, int32_t szSharedFolderID, TSBDropboxUserActionsRaw Actions, TListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_ListSharedFolderUsers_1(TElDropboxDataStorageHandle _Handle, const char * pcSharedFolderID, int32_t szSharedFolderID, TListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_AccountInfo(TElDropboxDataStorageHandle _Handle, TElDropboxAccountInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_SpaceAllocated(TElDropboxDataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_SpaceUsed(TElDropboxDataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_SpaceUsedByTeam(TElDropboxDataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_AccessToken(TElDropboxDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_AccessToken(TElDropboxDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_AccessTokenExpiration(TElDropboxDataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_AccessTokenExpiration(TElDropboxDataStorageHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_ClientID(TElDropboxDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_ClientID(TElDropboxDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_ClientSecret(TElDropboxDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_ClientSecret(TElDropboxDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_HTTPClient(TElDropboxDataStorageHandle _Handle, TElHTTPSClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_HTTPClient(TElDropboxDataStorageHandle _Handle, TElHTTPSClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_RedirectURL(TElDropboxDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_RedirectURL(TElDropboxDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_LiberalMode(TElDropboxDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_LiberalMode(TElDropboxDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_MetadataLocation(TElDropboxDataStorageHandle _Handle, TSBDropboxMetadataLocationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_MetadataLocation(TElDropboxDataStorageHandle _Handle, TSBDropboxMetadataLocationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_MetadataExtension(TElDropboxDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_MetadataExtension(TElDropboxDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_MetadataDirName(TElDropboxDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_MetadataDirName(TElDropboxDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_PickMetadataOnList(TElDropboxDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_PickMetadataOnList(TElDropboxDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_HideMetadataObjects(TElDropboxDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_HideMetadataObjects(TElDropboxDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_ChunkedUploadThreshold(TElDropboxDataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_ChunkedUploadThreshold(TElDropboxDataStorageHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_ChunkedUploadChunkSize(TElDropboxDataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_ChunkedUploadChunkSize(TElDropboxDataStorageHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_AsyncOperationTimeout(TElDropboxDataStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_AsyncOperationTimeout(TElDropboxDataStorageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_EmbeddedMetadataMode(TElDropboxDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_EmbeddedMetadataMode(TElDropboxDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_get_Overwrite(TElDropboxDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_set_Overwrite(TElDropboxDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorage_Create(TComponentHandle AOwner, TElDropboxDataStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXDATASTORAGE */

#ifdef SB_USE_CLASS_TELDROPBOXACCOUNTINFO
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_Refresh(TElDropboxAccountInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_AbbreviatedName(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_AccountID(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_Country(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_Disabled(TElDropboxAccountInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_DisplayName(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_Email(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_EmailVerified(TElDropboxAccountInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_FamiliarName(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_GivenName(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_IsPaired(TElDropboxAccountInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_Locale(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_ProfilePhotoUrl(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_ReferralLink(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_Surname(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_TeamID(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_TeamMemberID(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_TeamName(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_TeamSharedFolderJoinPolicy(TElDropboxAccountInfoHandle _Handle, TSBDropboxSharedFolderJoinPolicyRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_TeamSharedFolderMemberPolicy(TElDropboxAccountInfoHandle _Handle, TSBDropboxSharedFolderMemberPolicyRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_TeamSharedLinkCreatePolicy(TElDropboxAccountInfoHandle _Handle, TSBDropboxSharedLinkCreatePolicyRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_get_UID(TElDropboxAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxAccountInfo_Create(TElDropboxDataStorageHandle AStorage, TElDropboxAccountInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXACCOUNTINFO */

#ifdef SB_USE_CLASS_TELDROPBOXTEAMMEMBERINFO
SB_IMPORT uint32_t SB_APIENTRY TElDropboxTeamMemberInfo_Reset(TElDropboxTeamMemberInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxTeamMemberInfo_get_TeamID(TElDropboxTeamMemberInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxTeamMemberInfo_get_TeamName(TElDropboxTeamMemberInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxTeamMemberInfo_get_DisplayName(TElDropboxTeamMemberInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxTeamMemberInfo_get_MemberID(TElDropboxTeamMemberInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxTeamMemberInfo_Create(TElDropboxTeamMemberInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXTEAMMEMBERINFO */

#ifdef SB_USE_CLASS_TELDROPBOXSHAREDFILEPERMISSION
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFilePermission_Reset(TElDropboxSharedFilePermissionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFilePermission_LoadFromJSON(TElDropboxSharedFilePermissionHandle _Handle, TElJsonObjectHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFilePermission_get_Action(TElDropboxSharedFilePermissionHandle _Handle, TSBDropboxSharedFileActionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFilePermission_get_Allow(TElDropboxSharedFilePermissionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFilePermission_get_Reason(TElDropboxSharedFilePermissionHandle _Handle, TSBDropboxPermissionDeniedReasonRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFilePermission_Create(TElDropboxSharedFilePermissionHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXSHAREDFILEPERMISSION */

#ifdef SB_USE_CLASS_TELDROPBOXSHAREDFILEPERMISSIONS
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFilePermissions_Reset(TElDropboxSharedFilePermissionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFilePermissions_LoadFromJSON(TElDropboxSharedFilePermissionsHandle _Handle, TElJsonArrayHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFilePermissions_get_Permissions(TElDropboxSharedFilePermissionsHandle _Handle, int32_t Index, TElDropboxSharedFilePermissionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFilePermissions_get_Count(TElDropboxSharedFilePermissionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFilePermissions_Create(TElDropboxSharedFilePermissionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXSHAREDFILEPERMISSIONS */

#ifdef SB_USE_CLASS_TELDROPBOXSHAREDFOLDERPERMISSION
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFolderPermission_Reset(TElDropboxSharedFolderPermissionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFolderPermission_LoadFromJSON(TElDropboxSharedFolderPermissionHandle _Handle, TElJsonObjectHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFolderPermission_get_Action(TElDropboxSharedFolderPermissionHandle _Handle, TSBDropboxSharedFolderActionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFolderPermission_get_Allow(TElDropboxSharedFolderPermissionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFolderPermission_get_Reason(TElDropboxSharedFolderPermissionHandle _Handle, TSBDropboxPermissionDeniedReasonRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFolderPermission_Create(TElDropboxSharedFolderPermissionHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXSHAREDFOLDERPERMISSION */

#ifdef SB_USE_CLASS_TELDROPBOXSHAREDFOLDERPERMISSIONS
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFolderPermissions_Reset(TElDropboxSharedFolderPermissionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFolderPermissions_LoadFromJSON(TElDropboxSharedFolderPermissionsHandle _Handle, TElJsonArrayHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFolderPermissions_get_Permissions(TElDropboxSharedFolderPermissionsHandle _Handle, int32_t Index, TElDropboxSharedFolderPermissionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFolderPermissions_get_Count(TElDropboxSharedFolderPermissionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxSharedFolderPermissions_Create(TElDropboxSharedFolderPermissionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXSHAREDFOLDERPERMISSIONS */

#ifdef SB_USE_CLASS_TELDROPBOXUSERPERMISSION
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserPermission_Reset(TElDropboxUserPermissionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserPermission_LoadFromJSON(TElDropboxUserPermissionHandle _Handle, TElJsonObjectHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserPermission_get_Action(TElDropboxUserPermissionHandle _Handle, TSBDropboxUserActionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserPermission_get_Allow(TElDropboxUserPermissionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserPermission_get_Reason(TElDropboxUserPermissionHandle _Handle, TSBDropboxPermissionDeniedReasonRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserPermission_Create(TElDropboxUserPermissionHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXUSERPERMISSION */

#ifdef SB_USE_CLASS_TELDROPBOXUSERPERMISSIONS
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserPermissions_Reset(TElDropboxUserPermissionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserPermissions_LoadFromJSON(TElDropboxUserPermissionsHandle _Handle, TElJsonArrayHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserPermissions_get_Permissions(TElDropboxUserPermissionsHandle _Handle, int32_t Index, TElDropboxUserPermissionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserPermissions_get_Count(TElDropboxUserPermissionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserPermissions_Create(TElDropboxUserPermissionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXUSERPERMISSIONS */

#ifdef SB_USE_CLASS_TELDROPBOXUSERMEMBERSHIPINFO
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserMembershipInfo_Reset(TElDropboxUserMembershipInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserMembershipInfo_LoadFromJSON(TElDropboxUserMembershipInfoHandle _Handle, TElJsonObjectHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserMembershipInfo_get_AccessLevel(TElDropboxUserMembershipInfoHandle _Handle, TSBDropboxObjectAccessLevelRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserMembershipInfo_get_UserAccountID(TElDropboxUserMembershipInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserMembershipInfo_get_UserSameTeam(TElDropboxUserMembershipInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserMembershipInfo_get_UserTeamMemberID(TElDropboxUserMembershipInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserMembershipInfo_get_Permissions(TElDropboxUserMembershipInfoHandle _Handle, TElDropboxUserPermissionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserMembershipInfo_get_Initials(TElDropboxUserMembershipInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserMembershipInfo_get_IsInherited(TElDropboxUserMembershipInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxUserMembershipInfo_Create(TElDropboxUserMembershipInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXUSERMEMBERSHIPINFO */

#ifdef SB_USE_CLASS_TELDROPBOXGROUPMEMBERSHIPINFO
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_Reset(TElDropboxGroupMembershipInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_LoadFromJSON(TElDropboxGroupMembershipInfoHandle _Handle, TElJsonObjectHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_get_AccessLevel(TElDropboxGroupMembershipInfoHandle _Handle, TSBDropboxObjectAccessLevelRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_get_GroupName(TElDropboxGroupMembershipInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_get_GroupID(TElDropboxGroupMembershipInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_get_GroupManagementType(TElDropboxGroupMembershipInfoHandle _Handle, TSBDropboxGroupManagementTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_get_GroupType(TElDropboxGroupMembershipInfoHandle _Handle, TSBDropboxGroupTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_get_IsMember(TElDropboxGroupMembershipInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_get_IsOwner(TElDropboxGroupMembershipInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_get_SameTeam(TElDropboxGroupMembershipInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_get_GroupExternalID(TElDropboxGroupMembershipInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_get_MemberCount(TElDropboxGroupMembershipInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_get_Permissions(TElDropboxGroupMembershipInfoHandle _Handle, TElDropboxUserPermissionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_get_Initials(TElDropboxGroupMembershipInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_get_IsInherited(TElDropboxGroupMembershipInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxGroupMembershipInfo_Create(TElDropboxGroupMembershipInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXGROUPMEMBERSHIPINFO */

#ifdef SB_USE_CLASS_TELDROPBOXINVITEEMEMBERSHIPINFO
SB_IMPORT uint32_t SB_APIENTRY TElDropboxInviteeMembershipInfo_Reset(TElDropboxInviteeMembershipInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxInviteeMembershipInfo_LoadFromJSON(TElDropboxInviteeMembershipInfoHandle _Handle, TElJsonObjectHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxInviteeMembershipInfo_get_AccessLevel(TElDropboxInviteeMembershipInfoHandle _Handle, TSBDropboxObjectAccessLevelRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxInviteeMembershipInfo_get_InviteeEmail(TElDropboxInviteeMembershipInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxInviteeMembershipInfo_get_Permissions(TElDropboxInviteeMembershipInfoHandle _Handle, TElDropboxUserPermissionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxInviteeMembershipInfo_get_Initials(TElDropboxInviteeMembershipInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxInviteeMembershipInfo_get_IsInherited(TElDropboxInviteeMembershipInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxInviteeMembershipInfo_get_UserAccountID(TElDropboxInviteeMembershipInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxInviteeMembershipInfo_get_UserSameTeam(TElDropboxInviteeMembershipInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxInviteeMembershipInfo_get_UserTeamMemberID(TElDropboxInviteeMembershipInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxInviteeMembershipInfo_Create(TElDropboxInviteeMembershipInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXINVITEEMEMBERSHIPINFO */

#ifdef SB_USE_CLASS_TELDROPBOXDATASTORAGEOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageObject_Exists(TElDropboxDataStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageObject_Refresh(TElDropboxDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageObject_Create(TElCustomDataStorageObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXDATASTORAGEOBJECT */

#ifdef SB_USE_CLASS_TELDROPBOXDATASTORAGEFILESYSTEMOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_Assign(TElDropboxDataStorageFileSystemObjectHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_Reset(TElDropboxDataStorageFileSystemObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_MatchesTag(TElDropboxDataStorageFileSystemObjectHandle _Handle, const char * pcTag, int32_t szTag, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_Release(TElDropboxDataStorageFileSystemObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_IsMetadataObject(TElDropboxDataStorageFileSystemObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_IsMetadataDirectory(TElDropboxDataStorageFileSystemObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_Delete(TElDropboxDataStorageFileSystemObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_DeletePermanently(TElDropboxDataStorageFileSystemObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_Copy(TElDropboxDataStorageFileSystemObjectHandle _Handle, const char * pcDestPath, int32_t szDestPath, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_Copy_1(TElDropboxDataStorageFileSystemObjectHandle _Handle, const char * pcDestPath, int32_t szDestPath, int8_t AllowSharedFolder, int8_t AutoRename, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_CreateCopyReference(TElDropboxDataStorageFileSystemObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_Rename(TElDropboxDataStorageFileSystemObjectHandle _Handle, const char * pcDestPath, int32_t szDestPath);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_Rename_1(TElDropboxDataStorageFileSystemObjectHandle _Handle, const char * pcSourcePath, int32_t szSourcePath, const char * pcDestPath, int32_t szDestPath, int8_t AllowSharedFolder, int8_t AutoRename);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_get_PathLower(TElDropboxDataStorageFileSystemObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_get_PathDisplay(TElDropboxDataStorageFileSystemObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_get_Tag_AnsiString(TElDropboxDataStorageFileSystemObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_get_SearchMatchType(TElDropboxDataStorageFileSystemObjectHandle _Handle, TSBDropboxSearchMatchTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFileSystemObject_Create(TElDropboxDataStorageHandle AStorage, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXDATASTORAGEFILESYSTEMOBJECT */

#ifdef SB_USE_CLASS_TELDROPBOXDATASTORAGESHAREDOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedObject_Create(TElCustomDataStorageObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXDATASTORAGESHAREDOBJECT */

#ifdef SB_USE_CLASS_TELDROPBOXDATASTORAGESHAREDFOLDER
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_Reset(TElDropboxDataStorageSharedFolderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_LoadFromJSON(TElDropboxDataStorageSharedFolderHandle _Handle, TElJsonObjectHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_Exists(TElDropboxDataStorageSharedFolderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_Refresh(TElDropboxDataStorageSharedFolderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_InviteUsers(TElDropboxDataStorageSharedFolderHandle _Handle, TElStringListHandle Users, TSBDropboxObjectAccessLevelRaw AccessLevel, const char * pcInvitationMessage, int32_t szInvitationMessage, int8_t Quiet);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_RemoveUser(TElDropboxDataStorageSharedFolderHandle _Handle, const char * pcUser, int32_t szUser, int8_t LeaveACopy);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_UpdateUser(TElDropboxDataStorageSharedFolderHandle _Handle, const char * pcUser, int32_t szUser, TSBDropboxObjectAccessLevelRaw AccessLevel);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_UpdatePolicy(TElDropboxDataStorageSharedFolderHandle _Handle, TSBDropboxObjectUserPolicyRaw UserPolicy, TSBDropboxACLUpdatePolicyRaw AclUpdatePolicy, TSBDropboxSharedLinkPolicyRaw SharedLinkPolicy);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_Share(TElDropboxDataStorageSharedFolderHandle _Handle, TSBDropboxObjectUserPolicyRaw UserPolicy, TSBDropboxACLUpdatePolicyRaw AclUpdatePolicy, TSBDropboxSharedLinkPolicyRaw SharedLinkPolicy);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_Unshare(TElDropboxDataStorageSharedFolderHandle _Handle, int8_t LeaveACopy);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_Mount(TElDropboxDataStorageSharedFolderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_Unmount(TElDropboxDataStorageSharedFolderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_RelinquishAccess(TElDropboxDataStorageSharedFolderHandle _Handle, int8_t LeaveACopy);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_AccessLevel(TElDropboxDataStorageSharedFolderHandle _Handle, TSBDropboxObjectAccessLevelRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_IsInsideTeamFolder(TElDropboxDataStorageSharedFolderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_IsTeamFolder(TElDropboxDataStorageSharedFolderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_AclUpdatePolicy(TElDropboxDataStorageSharedFolderHandle _Handle, TSBDropboxACLUpdatePolicyRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_SharedLinkPolicy(TElDropboxDataStorageSharedFolderHandle _Handle, TSBDropboxSharedLinkPolicyRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_MemberPolicy(TElDropboxDataStorageSharedFolderHandle _Handle, TSBDropboxObjectUserPolicyRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_ResolvedMemberPolicy(TElDropboxDataStorageSharedFolderHandle _Handle, TSBDropboxObjectUserPolicyRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_PreviewURL(TElDropboxDataStorageSharedFolderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_SharedFolderID(TElDropboxDataStorageSharedFolderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_TimeInvited(TElDropboxDataStorageSharedFolderHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_OwnerTeamID(TElDropboxDataStorageSharedFolderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_OwnerTeamName(TElDropboxDataStorageSharedFolderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_ParentSharedFolderID(TElDropboxDataStorageSharedFolderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_PathLower(TElDropboxDataStorageSharedFolderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_get_Permissions(TElDropboxDataStorageSharedFolderHandle _Handle, TElDropboxSharedFolderPermissionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFolder_Create(TElDropboxDataStorageHandle AStorage, TElDropboxDataStorageSharedFolderHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXDATASTORAGESHAREDFOLDER */

#ifdef SB_USE_CLASS_TELDROPBOXDATASTORAGESHAREDLINK
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_Reset(TElDropboxDataStorageSharedLinkHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_LoadFromJSON(TElDropboxDataStorageSharedLinkHandle _Handle, TElJsonObjectHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_Exists(TElDropboxDataStorageSharedLinkHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_Refresh(TElDropboxDataStorageSharedLinkHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_Read(TElDropboxDataStorageSharedLinkHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_Read_1(TElDropboxDataStorageSharedLinkHandle _Handle, const char * pcSubPath, int32_t szSubPath, const char * pcPassword, int32_t szPassword, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_Modify(TElDropboxDataStorageSharedLinkHandle _Handle, TSBDropboxSharedObjectVisibilityRaw Visibility, const char * pcPassword, int32_t szPassword, int64_t Expires, int8_t RemoveExpiration);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_Revoke(TElDropboxDataStorageSharedLinkHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_Link(TElDropboxDataStorageSharedLinkHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_CanRevoke(TElDropboxDataStorageSharedLinkHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_ResolvedVisibility(TElDropboxDataStorageSharedLinkHandle _Handle, TSBDropboxSharedObjectVisibilityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_RequestedVisibility(TElDropboxDataStorageSharedLinkHandle _Handle, TSBDropboxSharedObjectVisibilityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_RevokeFailureReason(TElDropboxDataStorageSharedLinkHandle _Handle, TSBDropboxSharedObjectAccessFailureReasonRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_ClientModified(TElDropboxDataStorageSharedLinkHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_ServerModified(TElDropboxDataStorageSharedLinkHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_Revision(TElDropboxDataStorageSharedLinkHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_Size(TElDropboxDataStorageSharedLinkHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_ID(TElDropboxDataStorageSharedLinkHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_Expires(TElDropboxDataStorageSharedLinkHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_PathLower(TElDropboxDataStorageSharedLinkHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_TeamMemberInfo(TElDropboxDataStorageSharedLinkHandle _Handle, TElDropboxTeamMemberInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_ContentOwnerTeamID(TElDropboxDataStorageSharedLinkHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_ContentOwnerTeamName(TElDropboxDataStorageSharedLinkHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_Folder(TElDropboxDataStorageSharedLinkHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_get_Tag_AnsiString(TElDropboxDataStorageSharedLinkHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedLink_Create(TElDropboxDataStorageHandle AStorage, TElDropboxDataStorageSharedLinkHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXDATASTORAGESHAREDLINK */

#ifdef SB_USE_CLASS_TELDROPBOXFILESHARINGINFO
SB_IMPORT uint32_t SB_APIENTRY TElDropboxFileSharingInfo_LoadFromJSON(TElDropboxFileSharingInfoHandle _Handle, TElJsonObjectHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxFileSharingInfo_Reset(TElDropboxFileSharingInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxFileSharingInfo_get_ReadOnly(TElDropboxFileSharingInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxFileSharingInfo_get_ParentSharedFolderID(TElDropboxFileSharingInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxFileSharingInfo_get_ModifiedBy(TElDropboxFileSharingInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxFileSharingInfo_Create(TElDropboxFileSharingInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXFILESHARINGINFO */

#ifdef SB_USE_CLASS_TELDROPBOXFOLDERSHARINGINFO
SB_IMPORT uint32_t SB_APIENTRY TElDropboxFolderSharingInfo_get_ReadOnly(TElDropboxFolderSharingInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxFolderSharingInfo_get_ParentSharedFolderID(TElDropboxFolderSharingInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxFolderSharingInfo_get_SharedFolderID(TElDropboxFolderSharingInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxFolderSharingInfo_get_TraverseOnly(TElDropboxFolderSharingInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxFolderSharingInfo_get_NoAccess(TElDropboxFolderSharingInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxFolderSharingInfo_Create(TElDropboxFolderSharingInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXFOLDERSHARINGINFO */

#ifdef SB_USE_CLASS_TELDROPBOXMEDIAINFO
SB_IMPORT uint32_t SB_APIENTRY TElDropboxMediaInfo_get_MetadataType(TElDropboxMediaInfoHandle _Handle, TSBDropboxMetadataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxMediaInfo_get_Height(TElDropboxMediaInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxMediaInfo_get_Width(TElDropboxMediaInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxMediaInfo_get_Latitude(TElDropboxMediaInfoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxMediaInfo_get_Longitude(TElDropboxMediaInfoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxMediaInfo_get_TimeTaken(TElDropboxMediaInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxMediaInfo_get_Duration(TElDropboxMediaInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxMediaInfo_Create(TElDropboxMediaInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXMEDIAINFO */

#ifdef SB_USE_CLASS_TELDROPBOXDATASTORAGEFOLDER
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Assign(TElDropboxDataStorageFolderHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Clone(TElDropboxDataStorageFolderHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Reset(TElDropboxDataStorageFolderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_MatchesTag(TElDropboxDataStorageFolderHandle _Handle, const char * pcTag, int32_t szTag, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_IsMetadataObject(TElDropboxDataStorageFolderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_IsMetadataDirectory(TElDropboxDataStorageFolderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Exists(TElDropboxDataStorageFolderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Refresh(TElDropboxDataStorageFolderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Delete(TElDropboxDataStorageFolderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_DeletePermanently(TElDropboxDataStorageFolderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Copy(TElDropboxDataStorageFolderHandle _Handle, const char * pcDestPath, int32_t szDestPath, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Copy_1(TElDropboxDataStorageFolderHandle _Handle, const char * pcDestPath, int32_t szDestPath, int8_t AllowSharedFolder, int8_t AutoRename, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_CreateCopyReference(TElDropboxDataStorageFolderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Rename(TElDropboxDataStorageFolderHandle _Handle, const char * pcDestPath, int32_t szDestPath);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Rename_1(TElDropboxDataStorageFolderHandle _Handle, const char * pcSourcePath, int32_t szSourcePath, const char * pcDestPath, int32_t szDestPath, int8_t AllowSharedFolder, int8_t AutoRename);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_List(TElDropboxDataStorageFolderHandle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Search(TElDropboxDataStorageFolderHandle _Handle, const char * pcQuery, int32_t szQuery, int8_t IncludeDeleted, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Search_1(TElDropboxDataStorageFolderHandle _Handle, const char * pcQuery, int32_t szQuery, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Search_2(TElDropboxDataStorageFolderHandle _Handle, const char * pcQuery, int32_t szQuery, TSBDropboxSearchModeRaw SearchMode, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Search_3(TElDropboxDataStorageFolderHandle _Handle, const char * pcQuery, int32_t szQuery, int32_t Start, int32_t MaxResults, TSBDropboxSearchModeRaw SearchMode, TElDataStorageObjectListHandle Objects, int8_t * MoreResultsAvailable, int32_t * NextStart);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_InviteUsers(TElDropboxDataStorageFolderHandle _Handle, TElStringListHandle Users, TSBDropboxObjectAccessLevelRaw AccessLevel, const char * pcInvitationMessage, int32_t szInvitationMessage, int8_t Quiet);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_RemoveUser(TElDropboxDataStorageFolderHandle _Handle, const char * pcUser, int32_t szUser, int8_t LeaveACopy);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_UpdateUser(TElDropboxDataStorageFolderHandle _Handle, const char * pcUser, int32_t szUser, TSBDropboxObjectAccessLevelRaw AccessLevel);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_UpdatePolicy(TElDropboxDataStorageFolderHandle _Handle, TSBDropboxObjectUserPolicyRaw UserPolicy, TSBDropboxACLUpdatePolicyRaw AclUpdatePolicy, TSBDropboxSharedLinkPolicyRaw SharedLinkPolicy);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Share(TElDropboxDataStorageFolderHandle _Handle, TSBDropboxObjectUserPolicyRaw UserPolicy, TSBDropboxACLUpdatePolicyRaw AclUpdatePolicy, TSBDropboxSharedLinkPolicyRaw SharedLinkPolicy);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Unshare(TElDropboxDataStorageFolderHandle _Handle, int8_t LeaveACopy);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Mount(TElDropboxDataStorageFolderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Unmount(TElDropboxDataStorageFolderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_RelinquishAccess(TElDropboxDataStorageFolderHandle _Handle, int8_t LeaveACopy);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_ListUsers(TElDropboxDataStorageFolderHandle _Handle, TSBDropboxUserActionsRaw Actions, TListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_ListUsers_1(TElDropboxDataStorageFolderHandle _Handle, TListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_TransferOwnership(TElDropboxDataStorageFolderHandle _Handle, const char * pcDropboxUserID, int32_t szDropboxUserID);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_get_ID(TElDropboxDataStorageFolderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_get_SharedFolderID(TElDropboxDataStorageFolderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_get_SharingInfo(TElDropboxDataStorageFolderHandle _Handle, TElDropboxFolderSharingInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFolder_Create(TElDropboxDataStorageHandle AStorage, TElDropboxDataStorageFolderHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXDATASTORAGEFOLDER */

#ifdef SB_USE_CLASS_TELDROPBOXDATASTORAGEFILE
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Assign(TElDropboxDataStorageFileHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Clone(TElDropboxDataStorageFileHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Reset(TElDropboxDataStorageFileHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_MatchesTag(TElDropboxDataStorageFileHandle _Handle, const char * pcTag, int32_t szTag, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_GetMostAppropriatePath(TElDropboxDataStorageFileHandle _Handle, int8_t UsePath, int8_t UseRev, int8_t UseID, char * pcID, int32_t * szID, TSBDropboxDataStorageIdentifierTypeRaw * IDType, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_IsMetadataObject(TElDropboxDataStorageFileHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_IsMetadataDirectory(TElDropboxDataStorageFileHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Exists(TElDropboxDataStorageFileHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Refresh(TElDropboxDataStorageFileHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Delete(TElDropboxDataStorageFileHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_DeletePermanently(TElDropboxDataStorageFileHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Copy(TElDropboxDataStorageFileHandle _Handle, const char * pcDestPath, int32_t szDestPath, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Copy_1(TElDropboxDataStorageFileHandle _Handle, const char * pcDestPath, int32_t szDestPath, int8_t AllowSharedFolder, int8_t AutoRename, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_CreateCopyReference(TElDropboxDataStorageFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Rename(TElDropboxDataStorageFileHandle _Handle, const char * pcDestPath, int32_t szDestPath);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Rename_1(TElDropboxDataStorageFileHandle _Handle, const char * pcSourcePath, int32_t szSourcePath, const char * pcDestPath, int32_t szDestPath, int8_t AllowSharedFolder, int8_t AutoRename);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Write(TElDropboxDataStorageFileHandle _Handle, TStreamHandle Data, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Write_1(TElDropboxDataStorageFileHandle _Handle, const char * pcContentType, int32_t szContentType, TSBDropboxDataStorageWriteModeRaw WriteMode, const char * pcRev, int32_t szRev, int8_t AutoRename, int64_t ClientModified, int8_t Mute, TStreamHandle Data, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Read(TElDropboxDataStorageFileHandle _Handle, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_ReadBlock(TElDropboxDataStorageFileHandle _Handle, TStreamHandle Strm, int64_t Offset, int64_t Size, int64_t * Read);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_GetPreview(TElDropboxDataStorageFileHandle _Handle, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_GetDirectLink(TElDropboxDataStorageFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_GetThumbnail(TElDropboxDataStorageFileHandle _Handle, const char * pcImageFormat, int32_t szImageFormat, TSBDropboxImageSizeRaw Size, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Restore(TElDropboxDataStorageFileHandle _Handle, const char * pcRev, int32_t szRev);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_ListRevisions(TElDropboxDataStorageFileHandle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_ListRevisions_1(TElDropboxDataStorageFileHandle _Handle, int32_t MaxRevisions, TElDataStorageObjectListHandle Objects, int8_t * IsDeleted);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_InviteUsers(TElDropboxDataStorageFileHandle _Handle, TElStringListHandle Users, const char * pcInvitationMessage, int32_t szInvitationMessage, int8_t IsComment, int8_t Quiet, TSBDropboxObjectAccessLevelRaw AccessLevel);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_RemoveUser(TElDropboxDataStorageFileHandle _Handle, const char * pcUser, int32_t szUser);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Unshare(TElDropboxDataStorageFileHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_UpdateUser(TElDropboxDataStorageFileHandle _Handle, const char * pcUser, int32_t szUser, TSBDropboxObjectAccessLevelRaw AccessLevel);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_RelinquishAccess(TElDropboxDataStorageFileHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_ListUsers(TElDropboxDataStorageFileHandle _Handle, int8_t IncludeInherited, TListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_ListUsers_1(TElDropboxDataStorageFileHandle _Handle, TSBDropboxUserActionsRaw Actions, int8_t IncludeInherited, TListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_get_ID(TElDropboxDataStorageFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_get_ClientModified(TElDropboxDataStorageFileHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_get_ServerModified(TElDropboxDataStorageFileHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_get_Revision(TElDropboxDataStorageFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_get_Size(TElDropboxDataStorageFileHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_get_MediaInfo(TElDropboxDataStorageFileHandle _Handle, TElDropboxMediaInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_get_SharingInfo(TElDropboxDataStorageFileHandle _Handle, TElDropboxFolderSharingInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_get_HasExplicitSharedMembers(TElDropboxDataStorageFileHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageFile_Create(TElDropboxDataStorageHandle AStorage, TElDropboxDataStorageFileHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXDATASTORAGEFILE */

#ifdef SB_USE_CLASS_TELDROPBOXDATASTORAGEDELETEDOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_Clone(TElDropboxDataStorageDeletedObjectHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_MatchesTag(TElDropboxDataStorageDeletedObjectHandle _Handle, const char * pcTag, int32_t szTag, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_Exists(TElDropboxDataStorageDeletedObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_Refresh(TElDropboxDataStorageDeletedObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_IsMetadataObject(TElDropboxDataStorageDeletedObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_IsMetadataDirectory(TElDropboxDataStorageDeletedObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_Delete(TElDropboxDataStorageDeletedObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_DeletePermanently(TElDropboxDataStorageDeletedObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_Copy(TElDropboxDataStorageDeletedObjectHandle _Handle, const char * pcDestPath, int32_t szDestPath, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_Copy_1(TElDropboxDataStorageDeletedObjectHandle _Handle, const char * pcDestPath, int32_t szDestPath, int8_t AllowSharedFolder, int8_t AutoRename, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_CreateCopyReference(TElDropboxDataStorageDeletedObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_Rename(TElDropboxDataStorageDeletedObjectHandle _Handle, const char * pcDestPath, int32_t szDestPath);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_Rename_1(TElDropboxDataStorageDeletedObjectHandle _Handle, const char * pcSourcePath, int32_t szSourcePath, const char * pcDestPath, int32_t szDestPath, int8_t AllowSharedFolder, int8_t AutoRename);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_Restore(TElDropboxDataStorageDeletedObjectHandle _Handle, const char * pcRev, int32_t szRev);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_ListRevisions(TElDropboxDataStorageDeletedObjectHandle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_ListRevisions_1(TElDropboxDataStorageDeletedObjectHandle _Handle, int32_t MaxRevisions, TElDataStorageObjectListHandle Objects, int8_t * IsDeleted);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageDeletedObject_Create(TElDropboxDataStorageHandle AStorage, TElDropboxDataStorageFileSystemObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXDATASTORAGEDELETEDOBJECT */

#ifdef SB_USE_CLASS_TELDROPBOXDATASTORAGESHAREDFILE
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_Reset(TElDropboxDataStorageSharedFileHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_LoadFromJSON(TElDropboxDataStorageSharedFileHandle _Handle, TElJsonObjectHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_Exists(TElDropboxDataStorageSharedFileHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_Refresh(TElDropboxDataStorageSharedFileHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_InviteUsers(TElDropboxDataStorageSharedFileHandle _Handle, TElStringListHandle Users, const char * pcInvitationMessage, int32_t szInvitationMessage, int8_t IsComment, int8_t Quiet, TSBDropboxObjectAccessLevelRaw AccessLevel);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_RemoveUser(TElDropboxDataStorageSharedFileHandle _Handle, const char * pcUser, int32_t szUser);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_Unshare(TElDropboxDataStorageSharedFileHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_UpdateUser(TElDropboxDataStorageSharedFileHandle _Handle, const char * pcUser, int32_t szUser, TSBDropboxObjectAccessLevelRaw AccessLevel);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_RelinquishAccess(TElDropboxDataStorageSharedFileHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_get_AclUpdatePolicy(TElDropboxDataStorageSharedFileHandle _Handle, TSBDropboxACLUpdatePolicyRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_get_SharedLinkPolicy(TElDropboxDataStorageSharedFileHandle _Handle, TSBDropboxSharedLinkPolicyRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_get_MemberPolicy(TElDropboxDataStorageSharedFileHandle _Handle, TSBDropboxObjectUserPolicyRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_get_ResolvedMemberPolicy(TElDropboxDataStorageSharedFileHandle _Handle, TSBDropboxObjectUserPolicyRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_get_PreviewURL(TElDropboxDataStorageSharedFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_get_ID(TElDropboxDataStorageSharedFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_get_Permissions(TElDropboxDataStorageSharedFileHandle _Handle, TElDropboxSharedFilePermissionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_get_OwnerTeamID(TElDropboxDataStorageSharedFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_get_OwnerTeamName(TElDropboxDataStorageSharedFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_get_ParentSharedFolderID(TElDropboxDataStorageSharedFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_get_PathLower(TElDropboxDataStorageSharedFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_get_PathDisplay(TElDropboxDataStorageSharedFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_get_TimeInvited(TElDropboxDataStorageSharedFileHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDropboxDataStorageSharedFile_Create(TElDropboxDataStorageHandle AStorage, TElDropboxDataStorageSharedFileHandle * OutResult);
#endif /* SB_USE_CLASS_TELDROPBOXDATASTORAGESHAREDFILE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDropboxDataStorage_ce_ptr;
extern zend_class_entry *TElDropboxAccountInfo_ce_ptr;
extern zend_class_entry *TElDropboxTeamMemberInfo_ce_ptr;
extern zend_class_entry *TElDropboxSharedFilePermission_ce_ptr;
extern zend_class_entry *TElDropboxSharedFilePermissions_ce_ptr;
extern zend_class_entry *TElDropboxSharedFolderPermission_ce_ptr;
extern zend_class_entry *TElDropboxSharedFolderPermissions_ce_ptr;
extern zend_class_entry *TElDropboxUserPermission_ce_ptr;
extern zend_class_entry *TElDropboxUserPermissions_ce_ptr;
extern zend_class_entry *TElDropboxUserMembershipInfo_ce_ptr;
extern zend_class_entry *TElDropboxGroupMembershipInfo_ce_ptr;
extern zend_class_entry *TElDropboxInviteeMembershipInfo_ce_ptr;
extern zend_class_entry *TElDropboxDataStorageObject_ce_ptr;
extern zend_class_entry *TElDropboxDataStorageFileSystemObject_ce_ptr;
extern zend_class_entry *TElDropboxDataStorageSharedObject_ce_ptr;
extern zend_class_entry *TElDropboxDataStorageSharedFolder_ce_ptr;
extern zend_class_entry *TElDropboxDataStorageSharedLink_ce_ptr;
extern zend_class_entry *TElDropboxFileSharingInfo_ce_ptr;
extern zend_class_entry *TElDropboxFolderSharingInfo_ce_ptr;
extern zend_class_entry *TElDropboxMediaInfo_ce_ptr;
extern zend_class_entry *TElDropboxDataStorageFolder_ce_ptr;
extern zend_class_entry *TElDropboxDataStorageFile_ce_ptr;
extern zend_class_entry *TElDropboxDataStorageDeletedObject_ce_ptr;
extern zend_class_entry *TElDropboxDataStorageSharedFile_ce_ptr;

void Register_TElDropboxDataStorage(TSRMLS_D);
void Register_TElDropboxAccountInfo(TSRMLS_D);
void Register_TElDropboxTeamMemberInfo(TSRMLS_D);
void Register_TElDropboxSharedFilePermission(TSRMLS_D);
void Register_TElDropboxSharedFilePermissions(TSRMLS_D);
void Register_TElDropboxSharedFolderPermission(TSRMLS_D);
void Register_TElDropboxSharedFolderPermissions(TSRMLS_D);
void Register_TElDropboxUserPermission(TSRMLS_D);
void Register_TElDropboxUserPermissions(TSRMLS_D);
void Register_TElDropboxUserMembershipInfo(TSRMLS_D);
void Register_TElDropboxGroupMembershipInfo(TSRMLS_D);
void Register_TElDropboxInviteeMembershipInfo(TSRMLS_D);
void Register_TElDropboxDataStorageObject(TSRMLS_D);
void Register_TElDropboxDataStorageFileSystemObject(TSRMLS_D);
void Register_TElDropboxDataStorageSharedObject(TSRMLS_D);
void Register_TElDropboxDataStorageSharedFolder(TSRMLS_D);
void Register_TElDropboxDataStorageSharedLink(TSRMLS_D);
void Register_TElDropboxFileSharingInfo(TSRMLS_D);
void Register_TElDropboxFolderSharingInfo(TSRMLS_D);
void Register_TElDropboxMediaInfo(TSRMLS_D);
void Register_TElDropboxDataStorageFolder(TSRMLS_D);
void Register_TElDropboxDataStorageFile(TSRMLS_D);
void Register_TElDropboxDataStorageDeletedObject(TSRMLS_D);
void Register_TElDropboxDataStorageSharedFile(TSRMLS_D);
void Register_SBDropboxDataStorage_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDROPBOXDATASTORAGE */

