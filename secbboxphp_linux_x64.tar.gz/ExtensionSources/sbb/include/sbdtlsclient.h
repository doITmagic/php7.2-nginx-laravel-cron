#ifndef __INC_SBDTLSCLIENT
#define __INC_SBDTLSCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbsslclient.h"
#include "sbsslcommon.h"
#include "sbsslconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDTLSClientHandle;

typedef TElDTLSClientHandle ElDTLSClientHandle;

#ifdef SB_USE_CLASS_TELDTLSCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElDTLSClient_get_DatagramSize(TElDTLSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSClient_set_DatagramSize(TElDTLSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSClient_get_MaxDataSize(TElDTLSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSClient_get_SplitLongData(TElDTLSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSClient_set_SplitLongData(TElDTLSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSClient_get_UseRetransmissionTimer(TElDTLSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSClient_set_UseRetransmissionTimer(TElDTLSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSClient_get_TimerValue(TElDTLSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSClient_set_TimerValue(TElDTLSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSClient_get_AutoAdjustTimerValue(TElDTLSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSClient_set_AutoAdjustTimerValue(TElDTLSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSClient_Create(TComponentHandle Owner, TElDTLSClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELDTLSCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDTLSClient_ce_ptr;

void Register_TElDTLSClient(TSRMLS_D);
void Register_SBDTLSClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDTLSCLIENT */

