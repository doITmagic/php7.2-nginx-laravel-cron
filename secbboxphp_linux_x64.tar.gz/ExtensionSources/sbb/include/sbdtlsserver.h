#ifndef __INC_SBDTLSSERVER
#define __INC_SBDTLSSERVER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbsslserver.h"
#include "sbsslcommon.h"
#include "sbsslconstants.h"
#include "sbhashfunction.h"
#include "sbsharedresource.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDTLSServerHandle;

typedef TElDTLSServerHandle ElDTLSServerHandle;

typedef TElClassHandle TElDTLSServerFactoryHandle;

typedef TElDTLSServerFactoryHandle ElDTLSServerFactoryHandle;

typedef void (SB_CALLBACK *TSBDTLSServerCreatedEvent)(void * _ObjectData, TObjectHandle Sender, TElDTLSServerHandle Server, const uint8_t pClientID[], int32_t szClientID);

typedef void (SB_CALLBACK *TSBDTLSSendEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size, const uint8_t pClientID[], int32_t szClientID);

#ifdef SB_USE_CLASS_TELDTLSSERVER
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServer_get_UseClientVerification(TElDTLSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServer_set_UseClientVerification(TElDTLSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServer_get_DatagramSize(TElDTLSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServer_set_DatagramSize(TElDTLSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServer_get_MaxDataSize(TElDTLSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServer_get_SplitLongData(TElDTLSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServer_set_SplitLongData(TElDTLSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServer_get_UseRetransmissionTimer(TElDTLSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServer_set_UseRetransmissionTimer(TElDTLSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServer_get_TimerValue(TElDTLSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServer_set_TimerValue(TElDTLSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServer_get_AutoAdjustTimerValue(TElDTLSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServer_set_AutoAdjustTimerValue(TElDTLSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServer_Create(TComponentHandle Owner, TElDTLSServerHandle * OutResult);
#endif /* SB_USE_CLASS_TELDTLSSERVER */

#ifdef SB_USE_CLASS_TELDTLSSERVERFACTORY
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServerFactory_ProcessRequest(TElDTLSServerFactoryHandle _Handle, void * Buffer, int32_t Size, const uint8_t pClientID[], int32_t szClientID);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServerFactory_get_OnSend(TElDTLSServerFactoryHandle _Handle, TSBDTLSSendEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServerFactory_set_OnSend(TElDTLSServerFactoryHandle _Handle, TSBDTLSSendEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServerFactory_get_OnServerCreated(TElDTLSServerFactoryHandle _Handle, TSBDTLSServerCreatedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServerFactory_set_OnServerCreated(TElDTLSServerFactoryHandle _Handle, TSBDTLSServerCreatedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSServerFactory_Create(TComponentHandle AOwner, TElDTLSServerFactoryHandle * OutResult);
#endif /* SB_USE_CLASS_TELDTLSSERVERFACTORY */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDTLSServer_ce_ptr;
extern zend_class_entry *TElDTLSServerFactory_ce_ptr;

void SB_CALLBACK TSBDTLSServerCreatedEventRaw(void * _ObjectData, TObjectHandle Sender, TElDTLSServerHandle Server, const uint8_t pClientID[], int32_t szClientID);
void SB_CALLBACK TSBDTLSSendEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size, const uint8_t pClientID[], int32_t szClientID);
void Register_TElDTLSServer(TSRMLS_D);
void Register_TElDTLSServerFactory(TSRMLS_D);
void Register_SBDTLSServer_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDTLSSERVER */

