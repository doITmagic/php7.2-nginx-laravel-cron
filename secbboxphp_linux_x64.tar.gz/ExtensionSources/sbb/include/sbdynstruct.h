#ifndef __INC_SBDYNSTRUCT
#define __INC_SBDYNSTRUCT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstreams.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElDynStructHandle;

typedef Pointer TSBPointer;

typedef Pointer TSBArrayPointer;

#ifdef SB_USE_CLASS_TELDYNSTRUCT
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_Serialize(TElDynStructHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_Deserialize(TElDynStructHandle _Handle, const uint8_t pBuf[], int32_t szBuf);
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_Deserialize_1(TElDynStructHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_DeserializeFromPtr(TElDynStructHandle _Handle, void * P);
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_GetPointer(TElDynStructHandle _Handle, void * * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_get_MaxFieldLength(TElDynStructHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_get_Alignment(TElDynStructHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_set_Alignment(TElDynStructHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_get_PointerSize(TElDynStructHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_set_PointerSize(TElDynStructHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_get_LongIntSize(TElDynStructHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_set_LongIntSize(TElDynStructHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_get_Size(TElDynStructHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_get_Buffer(TElDynStructHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDynStruct_Create(int32_t Alignment, int32_t PointerSize, int32_t LongIntSize, TElDynStructHandle * OutResult);
#endif /* SB_USE_CLASS_TELDYNSTRUCT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDynStruct_ce_ptr;

void Register_TElDynStruct(TSRMLS_D);
SB_PHP_FUNCTION(SBDynStruct, NullPtr);
SB_PHP_FUNCTION(SBDynStruct, GetArrayPtr);
SB_PHP_FUNCTION(SBDynStruct, FreePointer);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_DYNSTRUCT
SB_IMPORT uint32_t SB_APIENTRY SBDynStruct_NullPtr(void * * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBDynStruct_GetArrayPtr(const uint8_t pBuf[], int32_t szBuf, void * * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBDynStruct_FreePointer(void * * Value);
#endif /* SB_USE_GLOBAL_PROCS_DYNSTRUCT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBDYNSTRUCT */

