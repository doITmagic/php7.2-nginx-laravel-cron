#ifndef __INC_SBECCOMMON
#define __INC_SBECCOMMON

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbmath.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElECDomainParametersHandle;

#ifdef SB_USE_CLASS_TELECDOMAINPARAMETERS
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_Reset(TElECDomainParametersHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_Assign(TElECDomainParametersHandle _Handle, TElECDomainParametersHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_Check(TElECDomainParametersHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_Curve(TElECDomainParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_Curve(TElECDomainParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_CurveOID(TElECDomainParametersHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_CurveOID(TElECDomainParametersHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_P(TElECDomainParametersHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_P(TElECDomainParametersHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_A(TElECDomainParametersHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_A(TElECDomainParametersHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_B(TElECDomainParametersHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_B(TElECDomainParametersHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_N(TElECDomainParametersHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_N(TElECDomainParametersHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_H(TElECDomainParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_H(TElECDomainParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_X(TElECDomainParametersHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_X(TElECDomainParametersHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_Y(TElECDomainParametersHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_Y(TElECDomainParametersHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_Seed(TElECDomainParametersHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_Seed(TElECDomainParametersHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_FieldType(TElECDomainParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_FieldType(TElECDomainParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_Field(TElECDomainParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_Field(TElECDomainParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_FieldBits(TElECDomainParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_SubgroupBits(TElECDomainParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_M(TElECDomainParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_M(TElECDomainParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_K1(TElECDomainParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_K1(TElECDomainParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_K2(TElECDomainParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_K2(TElECDomainParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_K3(TElECDomainParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_K3(TElECDomainParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_get_K4(TElECDomainParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_set_K4(TElECDomainParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElECDomainParameters_Create(TElECDomainParametersHandle * OutResult);
#endif /* SB_USE_CLASS_TELECDOMAINPARAMETERS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElECDomainParameters_ce_ptr;

void Register_TElECDomainParameters(TSRMLS_D);
SB_PHP_FUNCTION(SBECCommon, GetCurveByOID);
SB_PHP_FUNCTION(SBECCommon, GetOIDByCurve);
SB_PHP_FUNCTION(SBECCommon, IsPointCompressed);
SB_PHP_FUNCTION(SBECCommon, BufferToPoint);
SB_PHP_FUNCTION(SBECCommon, PointToBuffer);
SB_PHP_FUNCTION(SBECCommon, ValidateKey);
SB_PHP_FUNCTION(SBECCommon, HexStrToFieldElement);
SB_PHP_FUNCTION(SBECCommon, BufferToFieldElement);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_ECCOMMON
SB_IMPORT uint32_t SB_APIENTRY SBECCommon_GetCurveByOID(const uint8_t pOID[], int32_t szOID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBECCommon_GetOIDByCurve(int32_t Curve, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBECCommon_IsPointCompressed(void * Buffer, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBECCommon_BufferToPoint(void * Buffer, int32_t Size, TElECDomainParametersHandle DomainParams, void * X, int32_t * XSize, void * Y, int32_t * YSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBECCommon_PointToBuffer(void * X, int32_t XSize, void * Y, int32_t YSize, TElECDomainParametersHandle DomainParams, void * Buffer, int32_t * Size, int8_t Compress, int8_t Hybrid, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBECCommon_ValidateKey(TElECDomainParametersHandle DomainParams, void * D, int32_t DSize, void * Qx, int32_t QxSize, void * Qy, int32_t QySize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBECCommon_HexStrToFieldElement(const char * pcSrc, int32_t szSrc, int8_t LittleEndian, int32_t PSize, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBECCommon_BufferToFieldElement(const uint8_t pBuf[], int32_t szBuf, PLInt * A, PLInt P);
SB_IMPORT uint32_t SB_APIENTRY SBECCommon_BufferToFieldElement_1(void * Buf, int32_t Size, PLInt * A, PLInt P);
#endif /* SB_USE_GLOBAL_PROCS_ECCOMMON */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBECCOMMON */

