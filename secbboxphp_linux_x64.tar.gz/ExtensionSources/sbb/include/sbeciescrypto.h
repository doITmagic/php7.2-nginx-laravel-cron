#ifndef __INC_SBECIESCRYPTO
#define __INC_SBECIESCRYPTO

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstrutils.h"
#include "sbcustomcrypto.h"
#include "sbmath.h"
#include "sbeccommon.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbcryptoprovrs.h"
#include "sbcryptoprov.h"
#include "sbcryptoprovmanager.h"
#include "sbsymmetriccrypto.h"
#include "sbpublickeycrypto.h"
#include "sbhashfunction.h"
#include "sbconstants.h"
#include "sbrandom.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElECIESCryptoHandle;

typedef TElECIESCryptoHandle ElECIESCryptoHandle;

typedef uint8_t TSBECIESKATypeRaw;

typedef enum
{
	katPoint = 0,
	katCoordinate = 1,
	katHashPoint = 2,
	katHashCoordinate = 3
} TSBECIESKAType;

typedef uint8_t TSBECIESKDFTypeRaw;

typedef enum
{
	ktKDF1 = 0,
	ktKDF2 = 1
} TSBECIESKDFType;

typedef uint8_t TSBECIESKDFInterpretationRaw;

typedef enum
{
	kiEncMac = 0,
	kiMacEnc = 1
} TSBECIESKDFInterpretation;

typedef TElClassHandle TElECIESCryptoClassHandle;

typedef TElECIESCryptoClassHandle ElECIESCryptoClassHandle;

#ifdef SB_USE_CLASS_TELECIESCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_IsEncAlgorithmSupported(int32_t AlgID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_IsEncAlgorithmSupported_1(TElECIESCryptoHandle _Handle, int32_t AlgID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_IsHashAlgorithmSupported(int32_t AlgID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_IsHashAlgorithmSupported_1(TElECIESCryptoHandle _Handle, int32_t AlgID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_IsMACAlgorithmSupported(int32_t AlgID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_IsMACAlgorithmSupported_1(TElECIESCryptoHandle _Handle, int32_t AlgID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_InitializeEncryption(TElECIESCryptoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_Encrypt(TElECIESCryptoHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_Encrypt_1(TElECIESCryptoHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_EncryptUpdate(TElECIESCryptoHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_FinalizeEncryption(TElECIESCryptoHandle _Handle, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_InitializeDecryption(TElECIESCryptoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_Decrypt(TElECIESCryptoHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_Decrypt_1(TElECIESCryptoHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int32_t InCount, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_DecryptUpdate(TElECIESCryptoHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_FinalizeDecryption(TElECIESCryptoHandle _Handle, void * OutBuffer, int32_t * OutSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_EncryptionAlgorithm(TElECIESCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_HashAlgorithm(TElECIESCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_MACAlgorithm(TElECIESCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_TagSize(TElECIESCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_Padding(TElECIESCryptoHandle _Handle, TSBSymmetricCipherPaddingRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_set_Padding(TElECIESCryptoHandle _Handle, TSBSymmetricCipherPaddingRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_IV(TElECIESCryptoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_set_IV(TElECIESCryptoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_MACKeySize(TElECIESCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_set_MACKeySize(TElECIESCryptoHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_KeyAgreementType(TElECIESCryptoHandle _Handle, TSBECIESKATypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_set_KeyAgreementType(TElECIESCryptoHandle _Handle, TSBECIESKATypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_KDFType(TElECIESCryptoHandle _Handle, TSBECIESKDFTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_set_KDFType(TElECIESCryptoHandle _Handle, TSBECIESKDFTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_KDFInterpretation(TElECIESCryptoHandle _Handle, TSBECIESKDFInterpretationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_set_KDFInterpretation(TElECIESCryptoHandle _Handle, TSBECIESKDFInterpretationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_KDFOptionalInfo(TElECIESCryptoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_set_KDFOptionalInfo(TElECIESCryptoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_MACOptionalInfo(TElECIESCryptoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_set_MACOptionalInfo(TElECIESCryptoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_KeyMaterial(TElECIESCryptoHandle _Handle, TElECKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_set_KeyMaterial(TElECIESCryptoHandle _Handle, TElECKeyMaterialHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_CryptoProvider(TElECIESCryptoHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_set_CryptoProvider(TElECIESCryptoHandle _Handle, TElCustomCryptoProviderHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_CryptoProviderManager(TElECIESCryptoHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_set_CryptoProviderManager(TElECIESCryptoHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_UseCofactor(TElECIESCryptoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_set_UseCofactor(TElECIESCryptoHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_BouncyCastleCompatible(TElECIESCryptoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_set_BouncyCastleCompatible(TElECIESCryptoHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_get_OnProgress(TElECIESCryptoHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_set_OnProgress(TElECIESCryptoHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_Create(int32_t EncAlgID, int32_t HashAlgID, int32_t MACAlgID, TElCustomCryptoProviderHandle CryptoProvider, TElECIESCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_Create_1(int32_t EncAlgID, int32_t HashAlgID, TElCustomCryptoProviderHandle CryptoProvider, TElECIESCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_Create_2(int32_t EncAlgID, TElCustomCryptoProviderHandle CryptoProvider, TElECIESCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_Create_3(TElCustomCryptoProviderHandle CryptoProvider, TElECIESCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_Create_4(int32_t EncAlgID, int32_t HashAlgID, int32_t MACAlgID, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElECIESCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_Create_5(int32_t EncAlgID, int32_t HashAlgID, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElECIESCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_Create_6(int32_t EncAlgID, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElECIESCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECIESCrypto_Create_7(TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElECIESCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELECIESCRYPTO */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElECIESCryptoClass_ce_ptr;
extern zend_class_entry *TElECIESCrypto_ce_ptr;

void Register_TElECIESCrypto(TSRMLS_D);
void Register_SBECIESCrypto_Enum_Flags(TSRMLS_D);
void Register_SBECIESCrypto_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBECIESCRYPTO */

