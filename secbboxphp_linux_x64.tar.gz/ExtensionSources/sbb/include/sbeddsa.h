#ifndef __INC_SBEDDSA
#define __INC_SBEDDSA

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbstrutils.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ED25519_RAW_KEY_LENGTH 	32
#define SB_ED25519_SIGNATURE_LENGTH 	64
#define SB_ED448_RAW_KEY_LENGTH 	57
#define SB_ED448_SIGNATURE_LENGTH 	114
#define SB_GOLDILOCKS_RAW_KEY_LENGTH 	56
#define SB_GOLDILOCKS_PUBLIC_KEY_LENGTH 	56
#define SB_GOLDILOCKS_PRIVATE_KEY_LENGTH 	144
#define SB_GOLDILOCKS_SIGNATURE_LENGTH 	112

#ifdef __cplusplus
};	/* extern "C" */
#endif

void Register_SBEdDSA_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBEDDSA */

