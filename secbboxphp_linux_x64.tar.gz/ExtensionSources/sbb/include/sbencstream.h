#ifndef __INC_SBENCSTREAM
#define __INC_SBENCSTREAM

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbcryptoprov.h"
#include "sbhashfunction.h"
#include "sbsymmetriccrypto.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElChunkedEncryptingStreamHandle;

typedef TElClassHandle TElChunkedDecryptingStreamHandle;

#ifdef SB_USE_CLASS_TELCHUNKEDENCRYPTINGSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_Read(TElChunkedEncryptingStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_Write(TElChunkedEncryptingStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_Seek(TElChunkedEncryptingStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_Seek_1(TElChunkedEncryptingStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_get_HashAlgorithm(TElChunkedEncryptingStreamHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_set_HashAlgorithm(TElChunkedEncryptingStreamHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_get_HashResult(TElChunkedEncryptingStreamHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_get_SourceStream(TElChunkedEncryptingStreamHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_get_Finalized(TElChunkedEncryptingStreamHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_get_OnProgress(TElChunkedEncryptingStreamHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_set_OnProgress(TElChunkedEncryptingStreamHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_get_OnHashResultAvailable(TElChunkedEncryptingStreamHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_set_OnHashResultAvailable(TElChunkedEncryptingStreamHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_Create(TStreamHandle SourceStream, int32_t Algorithm, const uint8_t pKey[], int32_t szKey, const uint8_t pIV[], int32_t szIV, int64_t Count, TElCustomCryptoProviderManagerHandle Manager, int8_t ReleaseSourceStream, TElChunkedEncryptingStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_Create_1(TStreamHandle SourceStream, int32_t Algorithm, TSBSymmetricCryptoModeRaw Mode, const uint8_t pKey[], int32_t szKey, const uint8_t pIV[], int32_t szIV, int64_t Count, TElCustomCryptoProviderManagerHandle Manager, int8_t ReleaseSourceStream, TElChunkedEncryptingStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedEncryptingStream_Create_2(TStreamHandle SourceStream, int32_t Algorithm, TSBSymmetricCryptoModeRaw Mode, const uint8_t pKey[], int32_t szKey, const uint8_t pIV[], int32_t szIV, int64_t Offset, int64_t Count, TElCustomCryptoProviderManagerHandle Manager, int8_t ReleaseSourceStream, TElChunkedEncryptingStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELCHUNKEDENCRYPTINGSTREAM */

#ifdef SB_USE_CLASS_TELCHUNKEDDECRYPTINGSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_FinalizeOutput(TElChunkedDecryptingStreamHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_Read(TElChunkedDecryptingStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_Write(TElChunkedDecryptingStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_Seek(TElChunkedDecryptingStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_Seek_1(TElChunkedDecryptingStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_get_HashAlgorithm(TElChunkedDecryptingStreamHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_set_HashAlgorithm(TElChunkedDecryptingStreamHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_get_HashResult(TElChunkedDecryptingStreamHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_get_ExpectFinalize(TElChunkedDecryptingStreamHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_set_ExpectFinalize(TElChunkedDecryptingStreamHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_get_DestStream(TElChunkedDecryptingStreamHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_get_OnProgress(TElChunkedDecryptingStreamHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_set_OnProgress(TElChunkedDecryptingStreamHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_Create(TStreamHandle DestStream, int32_t Algorithm, const uint8_t pKey[], int32_t szKey, const uint8_t pIV[], int32_t szIV, int64_t Count, TElCustomCryptoProviderManagerHandle Manager, int8_t ReleaseDestStream, TElChunkedDecryptingStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_Create_1(TStreamHandle DestStream, int32_t Algorithm, TSBSymmetricCryptoModeRaw Mode, const uint8_t pKey[], int32_t szKey, const uint8_t pIV[], int32_t szIV, int64_t Count, TElCustomCryptoProviderManagerHandle Manager, int8_t ReleaseDestStream, TElChunkedDecryptingStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChunkedDecryptingStream_Create_2(TStreamHandle DestStream, int32_t Algorithm, TSBSymmetricCryptoModeRaw Mode, const uint8_t pKey[], int32_t szKey, const uint8_t pIV[], int32_t szIV, int64_t Offset, int64_t Count, TElCustomCryptoProviderManagerHandle Manager, int8_t ReleaseDestStream, TElChunkedDecryptingStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELCHUNKEDDECRYPTINGSTREAM */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElChunkedEncryptingStream_ce_ptr;
extern zend_class_entry *TElChunkedDecryptingStream_ce_ptr;

void Register_TElChunkedEncryptingStream(TSRMLS_D);
void Register_TElChunkedDecryptingStream(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBENCSTREAM */

