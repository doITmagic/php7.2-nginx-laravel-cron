#ifndef __INC_SBFILEDATASTORAGE
#define __INC_SBFILEDATASTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbdatastorage.h"
#include "sbcustomfsadapter.h"
#include "sbdiskfsadapter.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElFileDataStorageObjectHandle;

typedef TElClassHandle TElFileDataStorageHandle;

typedef uint8_t TSBFileDataStorageConditionRaw;

typedef enum
{
	fdscETag = 0,
	fdscModTime = 1
} TSBFileDataStorageCondition;

typedef uint32_t TSBFileDataStorageConditionsRaw;

typedef enum 
{
	f_fdscETag = 1,
	f_fdscModTime = 2
} TSBFileDataStorageConditions;

#ifdef SB_USE_CLASS_TELFILEDATASTORAGEOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorageObject_Assign(TElFileDataStorageObjectHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorageObject_Clone(TElFileDataStorageObjectHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorageObject_get_Size(TElFileDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorageObject_get_ModificationTime(TElFileDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorageObject_get_ETag(TElFileDataStorageObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorageObject_Create(TElFileDataStorageObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELFILEDATASTORAGEOBJECT */

#ifdef SB_USE_CLASS_TELFILEDATASTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_AcquireObject(TElFileDataStorageHandle _Handle, const char * pcObjName, int32_t szObjName, TElFileDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_AcquireObject_1(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_WriteObject(TElFileDataStorageHandle _Handle, const char * pcObjName, int32_t szObjName, const char * pcData, int32_t szData, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_WriteObject_1(TElFileDataStorageHandle _Handle, const char * pcObjName, int32_t szObjName, TStreamHandle Strm, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_WriteObject_2(TElFileDataStorageHandle _Handle, const char * pcObjName, int32_t szObjName, TStreamHandle Strm, const uint8_t pETag[], int32_t szETag, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_WriteObject_3(TElFileDataStorageHandle _Handle, const char * pcObjName, int32_t szObjName, TStreamHandle Strm, const uint8_t pETag[], int32_t szETag, TElCustomDataStorageSecurityHandlerHandle Handler, uint8_t pNewETag[], int32_t * szNewETag);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_WriteObject_4(TElFileDataStorageHandle _Handle, TElFileDataStorageObjectHandle Obj, TStreamHandle Strm, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_WriteObject_5(TElFileDataStorageHandle _Handle, TElFileDataStorageObjectHandle Obj, TStreamHandle Strm, const uint8_t pETag[], int32_t szETag, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_WriteObject_6(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TStreamHandle Strm, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_WriteBlock(TElFileDataStorageHandle _Handle, const char * pcObjName, int32_t szObjName, TStreamHandle Strm, TElCustomDataStorageSecurityHandlerHandle Handler, int64_t Offset, int64_t * Written);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_WriteBlock_1(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TStreamHandle Strm, TElCustomDataStorageSecurityHandlerHandle Handler, int64_t Offset, int64_t * Written);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_ReadObject(TElFileDataStorageHandle _Handle, const char * pcObjName, int32_t szObjName, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_ReadObject_1(TElFileDataStorageHandle _Handle, const char * pcObjName, int32_t szObjName, TStreamHandle Strm, const uint8_t pETag[], int32_t szETag);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_ReadObject_2(TElFileDataStorageHandle _Handle, TElFileDataStorageObjectHandle Obj, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_ReadObject_3(TElFileDataStorageHandle _Handle, TElFileDataStorageObjectHandle Obj, TStreamHandle Strm, const uint8_t pETag[], int32_t szETag);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_ReadObject_4(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_CopyObject(TElFileDataStorageHandle _Handle, const char * pcSrcObjName, int32_t szSrcObjName, const char * pcDestObjName, int32_t szDestObjName, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_CopyObject_1(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_DeleteObject(TElFileDataStorageHandle _Handle, const char * pcObjName, int32_t szObjName);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_DeleteObject_1(TElFileDataStorageHandle _Handle, const char * pcObjName, int32_t szObjName, const uint8_t pETag[], int32_t szETag);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_DeleteObject_2(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_ObjectExists(TElFileDataStorageHandle _Handle, const char * pcObjName, int32_t szObjName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_GetProtectionInfo(TElFileDataStorageHandle _Handle, const char * pcObjName, int32_t szObjName, TElCustomDataStorageSecurityHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_GetProtectionInfo_1(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TElCustomDataStorageSecurityHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_get_DataFileExtension(TElFileDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_set_DataFileExtension(TElFileDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_get_Directory(TElFileDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_set_Directory(TElFileDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_get_EmbeddedMetadataMode(TElFileDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_set_EmbeddedMetadataMode(TElFileDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_get_FileSystemAdapter(TElFileDataStorageHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_set_FileSystemAdapter(TElFileDataStorageHandle _Handle, TElCustomFileSystemAdapterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_get_MedataFileExtension(TElFileDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_set_MedataFileExtension(TElFileDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_get_Overwrite(TElFileDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_set_Overwrite(TElFileDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_get_PassthroughMode(TElFileDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_set_PassthroughMode(TElFileDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElFileDataStorage_Create(TComponentHandle AOwner, TElFileDataStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELFILEDATASTORAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElFileDataStorageObject_ce_ptr;
extern zend_class_entry *TElFileDataStorage_ce_ptr;

void Register_TElFileDataStorageObject(TSRMLS_D);
void Register_TElFileDataStorage(TSRMLS_D);
SB_PHP_FUNCTION(SBFileDataStorage, ComposeETag);
void Register_SBFileDataStorage_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_FILEDATASTORAGE
SB_IMPORT uint32_t SB_APIENTRY SBFileDataStorage_ComposeETag(int64_t ModTime, int64_t Size, uint8_t pOutResult[], int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_FILEDATASTORAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBFILEDATASTORAGE */

