#ifndef __INC_SBGOOGLEDRIVEDATASTORAGE
#define __INC_SBGOOGLEDRIVEDATASTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbencoding.h"
#include "sbstringlist.h"
#include "sbdatastorage.h"
#include "sbdatastorageutils.h"
#include "sbstrutils.h"
#include "sbjson.h"
#include "sbhttpsconstants.h"
#include "sbhttpscommon.h"
#include "sbhttpsclient.h"
#include "sboauth2.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElGoogleDriveDataStorageHandle;

typedef TElClassHandle TElGoogleDriveDataStorageObjectHandle;

typedef TElClassHandle TElGoogleDriveFolderHandle;

typedef TElClassHandle TElGoogleDrivePropertiesHandle;

typedef TElClassHandle TElGoogleDriveCommentHandle;

typedef TElClassHandle TElGoogleDriveRepliesHandle;

typedef TElClassHandle TElGoogleDriveUserHandle;

typedef TElClassHandle TElGoogleDriveAccountInfoHandle;

typedef TElClassHandle TElGoogleDriveCommentsHandle;

typedef TElClassHandle TElGoogleDriveReplyHandle;

typedef TElClassHandle TElGoogleDrivePropertyHandle;

typedef TElClassHandle TElGoogleDrivePermissionHandle;

typedef TElClassHandle TElGoogleDrivePermissionsHandle;

typedef TElClassHandle TElGoogleDriveCustomFileHandle;

typedef TElClassHandle TElGoogleDriveFileHandle;

typedef TElClassHandle TElGoogleDocumentHandle;

typedef uint8_t TSBGoogleDriveRootRaw;

typedef enum
{
	gdrDrive = 0,
	gdrAppFolder = 1
} TSBGoogleDriveRoot;

typedef uint8_t TSBGoogleDriveMetadataLocationRaw;

typedef enum
{
	gdmlColocatedObjects = 0,
	gdmlMetadataSubdir = 1,
	gdmlMetadataDir = 2
} TSBGoogleDriveMetadataLocation;

typedef uint8_t TSBGoogleDrivePropertyVisibilityRaw;

typedef enum
{
	gdpvPrivate = 0,
	gdpvPublic = 1
} TSBGoogleDrivePropertyVisibility;

typedef uint8_t TSBGoogleDriveUserRoleRaw;

typedef enum
{
	gdurReader = 0,
	gdurWriter = 1,
	gdurOwner = 2
} TSBGoogleDriveUserRole;

typedef uint8_t TSBGoogleDrivePermissionScopeRaw;

typedef enum
{
	gdpsUser = 0,
	gdpsGroup = 1,
	gdpsDomain = 2,
	gdpsAnyone = 3
} TSBGoogleDrivePermissionScope;

typedef uint8_t TSBGoogleDriveCommentStatusRaw;

typedef enum
{
	gdcsOpen = 0,
	gdcsResolved = 1
} TSBGoogleDriveCommentStatus;

typedef uint8_t TSBGoogleDriveReplyActionRaw;

typedef enum
{
	gdraNoAction = 0,
	gdraResolve = 1,
	gdraReopen = 2
} TSBGoogleDriveReplyAction;

#ifdef SB_USE_CLASS_TELGOOGLEDRIVEDATASTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_StartAuthorization(TElGoogleDriveDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_CompleteAuthorization(TElGoogleDriveDataStorageHandle _Handle, const char * pcAuthorizationCode, int32_t szAuthorizationCode);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_CloseSession(TElGoogleDriveDataStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_AcquireObject(TElGoogleDriveDataStorageHandle _Handle, const char * pcObjectID, int32_t szObjectID, TElGoogleDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_AcquireObject_1(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_CopyObject(TElGoogleDriveDataStorageHandle _Handle, TElGoogleDriveDataStorageObjectHandle Obj, TElGoogleDriveFolderHandle Destination, TElGoogleDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_CopyObject_1(TElGoogleDriveDataStorageHandle _Handle, TElGoogleDriveDataStorageObjectHandle Obj, const char * pcNewName, int32_t szNewName, const char * pcNewDescription, int32_t szNewDescription, TElGoogleDriveFolderHandle Destination, TElGoogleDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_CopyObject_2(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_CreateFolder(TElGoogleDriveDataStorageHandle _Handle, TElGoogleDriveFolderHandle AParent, const char * pcAName, int32_t szAName, const char * pcADescription, int32_t szADescription, TElGoogleDriveFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_CreateObject(TElGoogleDriveDataStorageHandle _Handle, TElGoogleDriveFolderHandle AParent, const char * pcAName, int32_t szAName, const char * pcADescription, int32_t szADescription, const char * pcAMimeType, int32_t szAMimeType, int8_t AHidden, int8_t ARestricted, int8_t AStarred, TElCustomDataStorageSecurityHandlerHandle Handler, TElGoogleDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_GetAccountInfo(TElGoogleDriveDataStorageHandle _Handle, TElGoogleDriveAccountInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_GetObjectThumbnail(TElGoogleDriveDataStorageHandle _Handle, TElGoogleDriveDataStorageObjectHandle Obj, TStreamHandle Stream, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_List(TElGoogleDriveDataStorageHandle _Handle, TElGoogleDriveFolderHandle Parent, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_List_1(TElGoogleDriveDataStorageHandle _Handle, TElGoogleDriveFolderHandle Parent, const char * pcObjectName, int32_t szObjectName, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_List_2(TElCustomDataStorageHandle _Handle, TElDataStorageObjectListHandle Objs);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_ListFolders(TElGoogleDriveDataStorageHandle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_ListFolders_1(TElGoogleDriveDataStorageHandle _Handle, TElGoogleDriveFolderHandle Parent, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_ListTrashed(TElGoogleDriveDataStorageHandle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_ListTrashed_1(TElGoogleDriveDataStorageHandle _Handle, TElGoogleDriveFolderHandle Parent, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_MoveObject(TElGoogleDriveDataStorageHandle _Handle, TElGoogleDriveDataStorageObjectHandle Obj, TElGoogleDriveFolderHandle Destination);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_MoveObject_1(TElGoogleDriveDataStorageHandle _Handle, TElGoogleDriveDataStorageObjectHandle Obj, const TElGoogleDriveFolderHandle pDestinations[], int32_t szDestinations);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_RenameObject(TElGoogleDriveDataStorageHandle _Handle, TElGoogleDriveDataStorageObjectHandle Obj, const char * pcNewName, int32_t szNewName);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_Search(TElGoogleDriveDataStorageHandle _Handle, const char * pcQuery, int32_t szQuery, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_AccessToken(TElGoogleDriveDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_AccessTokenExpiration(TElGoogleDriveDataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_ChunkedUploadChunkSize(TElGoogleDriveDataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_set_ChunkedUploadChunkSize(TElGoogleDriveDataStorageHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_ChunkedUploadThreshold(TElGoogleDriveDataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_set_ChunkedUploadThreshold(TElGoogleDriveDataStorageHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_ClientID(TElGoogleDriveDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_set_ClientID(TElGoogleDriveDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_ClientSecret(TElGoogleDriveDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_set_ClientSecret(TElGoogleDriveDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_HTTPClient(TElGoogleDriveDataStorageHandle _Handle, TElHTTPSClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_set_HTTPClient(TElGoogleDriveDataStorageHandle _Handle, TElHTTPSClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_PassthroughMode(TElGoogleDriveDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_set_PassthroughMode(TElGoogleDriveDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_ReadOnly(TElGoogleDriveDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_set_ReadOnly(TElGoogleDriveDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_RedirectURL(TElGoogleDriveDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_set_RedirectURL(TElGoogleDriveDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_RefreshToken(TElGoogleDriveDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_set_RefreshToken(TElGoogleDriveDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_Root(TElGoogleDriveDataStorageHandle _Handle, TSBGoogleDriveRootRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_set_Root(TElGoogleDriveDataStorageHandle _Handle, TSBGoogleDriveRootRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_UpdateViewedDateOnAcquire(TElGoogleDriveDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_set_UpdateViewedDateOnAcquire(TElGoogleDriveDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_UpdateViewedDateOnWrite(TElGoogleDriveDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_set_UpdateViewedDateOnWrite(TElGoogleDriveDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_UseETags(TElGoogleDriveDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_set_UseETags(TElGoogleDriveDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_get_UsePatchMethod(TElGoogleDriveDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_set_UsePatchMethod(TElGoogleDriveDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorage_Create(TComponentHandle AOwner, TElGoogleDriveDataStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVEDATASTORAGE */

#ifdef SB_USE_CLASS_TELGOOGLEDRIVEDATASTORAGEOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_Assign(TElGoogleDriveDataStorageObjectHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_Clear(TElGoogleDriveDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_Copy(TElGoogleDriveDataStorageObjectHandle _Handle, TElGoogleDriveFolderHandle Destination, TElGoogleDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_Delete(TElGoogleDriveDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_GetThumbnail(TElGoogleDriveDataStorageObjectHandle _Handle, TStreamHandle Stream, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_Move(TElGoogleDriveDataStorageObjectHandle _Handle, TElGoogleDriveFolderHandle Destination);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_Move_1(TElGoogleDriveDataStorageObjectHandle _Handle, const TElGoogleDriveFolderHandle pDestinations[], int32_t szDestinations);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_Refresh(TElGoogleDriveDataStorageObjectHandle _Handle, int8_t UpdateViewedDate);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_Release(TElGoogleDriveDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_Rename(TElGoogleDriveDataStorageObjectHandle _Handle, const char * pcNewName, int32_t szNewName);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_Touch(TElGoogleDriveDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_Trash(TElGoogleDriveDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_Untrash(TElGoogleDriveDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_AlternateLink(TElGoogleDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_AppDataContents(TElGoogleDriveDataStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Comments(TElGoogleDriveDataStorageObjectHandle _Handle, TElGoogleDriveCommentsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_CreatedDate(TElGoogleDriveDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Description(TElGoogleDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_set_Description(TElGoogleDriveDataStorageObjectHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Editable(TElGoogleDriveDataStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_ETag(TElGoogleDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_ExplicitlyTrashed(TElGoogleDriveDataStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Hidden(TElGoogleDriveDataStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_set_Hidden(TElGoogleDriveDataStorageObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_IconLink(TElGoogleDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_ID(TElGoogleDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Kind(TElGoogleDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_LastModifyingUser(TElGoogleDriveDataStorageObjectHandle _Handle, TElGoogleDriveUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_LastModifyingUserName(TElGoogleDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_LastViewedByMeDate(TElGoogleDriveDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_MimeType(TElGoogleDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_ModifiedByMeDate(TElGoogleDriveDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_ModifiedDate(TElGoogleDriveDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_set_ModifiedDate(TElGoogleDriveDataStorageObjectHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_OwnerNames(TElGoogleDriveDataStorageObjectHandle _Handle, TStringListHandle OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_OwnerCount(TElGoogleDriveDataStorageObjectHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Owners(TElGoogleDriveDataStorageObjectHandle _Handle, int32_t Index, TElGoogleDriveUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Parent(TElGoogleDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Parents(TElGoogleDriveDataStorageObjectHandle _Handle, TStringListHandle OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Permissions(TElGoogleDriveDataStorageObjectHandle _Handle, TElGoogleDrivePermissionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Properties(TElGoogleDriveDataStorageObjectHandle _Handle, TElGoogleDrivePropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Restricted(TElGoogleDriveDataStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_set_Restricted(TElGoogleDriveDataStorageObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_SelfLink(TElGoogleDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Shared(TElGoogleDriveDataStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_SharedWithMeDate(TElGoogleDriveDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Starred(TElGoogleDriveDataStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_set_Starred(TElGoogleDriveDataStorageObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_ThumbnailLink(TElGoogleDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Trashed(TElGoogleDriveDataStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_Viewed(TElGoogleDriveDataStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_WebContentLink(TElGoogleDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_get_WritersCanShare(TElGoogleDriveDataStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveDataStorageObject_Create(TElGoogleDriveDataStorageHandle AStorage, TElGoogleDriveDataStorageObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVEDATASTORAGEOBJECT */

#ifdef SB_USE_CLASS_TELGOOGLEDRIVEFOLDER
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFolder_Assign(TElGoogleDriveFolderHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFolder_Clear(TElGoogleDriveFolderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFolder_CreateFolder(TElGoogleDriveFolderHandle _Handle, const char * pcName, int32_t szName, TElGoogleDriveFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFolder_CreateFolder_1(TElGoogleDriveFolderHandle _Handle, const char * pcName, int32_t szName, const char * pcDescription, int32_t szDescription, TElGoogleDriveFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFolder_CreateObject(TElGoogleDriveFolderHandle _Handle, const char * pcName, int32_t szName, const char * pcDescription, int32_t szDescription, const char * pcMimeType, int32_t szMimeType, int8_t Hidden, int8_t Restricted, int8_t Starred, TElCustomDataStorageSecurityHandlerHandle Handler, TElGoogleDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFolder_Clone(TElGoogleDriveFolderHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFolder_List(TElGoogleDriveFolderHandle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFolder_List_1(TElGoogleDriveFolderHandle _Handle, const char * pcObjectName, int32_t szObjectName, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFolder_ListFolders(TElGoogleDriveFolderHandle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFolder_ListTrashed(TElGoogleDriveFolderHandle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFolder_get_WebViewLink(TElGoogleDriveFolderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFolder_Create(TElGoogleDriveDataStorageHandle Storage, TElGoogleDriveFolderHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVEFOLDER */

#ifdef SB_USE_CLASS_TELGOOGLEDRIVEPROPERTIES
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperties_Add(TElGoogleDrivePropertiesHandle _Handle, const char * pcKey, int32_t szKey, TSBGoogleDrivePropertyVisibilityRaw Visibility, const char * pcValue, int32_t szValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperties_Exists(TElGoogleDrivePropertiesHandle _Handle, const char * pcKey, int32_t szKey, TSBGoogleDrivePropertyVisibilityRaw Visibility, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperties_IndexOf(TElGoogleDrivePropertiesHandle _Handle, TElGoogleDrivePropertyHandle Prop, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperties_IndexOf_1(TElGoogleDrivePropertiesHandle _Handle, const char * pcKey, int32_t szKey, TSBGoogleDrivePropertyVisibilityRaw Visibility, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperties_Refresh(TElGoogleDrivePropertiesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperties_ValueByKey(TElGoogleDrivePropertiesHandle _Handle, const char * pcKey, int32_t szKey, TSBGoogleDrivePropertyVisibilityRaw Visibility, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperties_get_Count(TElGoogleDrivePropertiesHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperties_get_ETag(TElGoogleDrivePropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperties_get_Items(TElGoogleDrivePropertiesHandle _Handle, int32_t Index, TElGoogleDrivePropertyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperties_get_Owner(TElGoogleDrivePropertiesHandle _Handle, TElGoogleDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperties_Create(TElGoogleDriveDataStorageObjectHandle AOwner, TElGoogleDrivePropertiesHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVEPROPERTIES */

#ifdef SB_USE_CLASS_TELGOOGLEDRIVECOMMENT
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_Assign(TElGoogleDriveCommentHandle _Handle, TElGoogleDriveCommentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_Clone(TElGoogleDriveCommentHandle _Handle, TElGoogleDriveCommentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_Delete(TElGoogleDriveCommentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_Refresh(TElGoogleDriveCommentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_get_Author(TElGoogleDriveCommentHandle _Handle, TElGoogleDriveUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_get_Content(TElGoogleDriveCommentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_set_Content(TElGoogleDriveCommentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_get_CreatedDate(TElGoogleDriveCommentHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_get_Deleted(TElGoogleDriveCommentHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_get_HtmlContent(TElGoogleDriveCommentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_get_ID(TElGoogleDriveCommentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_get_ModifiedDate(TElGoogleDriveCommentHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_get_Owner(TElGoogleDriveCommentHandle _Handle, TElGoogleDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_get_Replies(TElGoogleDriveCommentHandle _Handle, TElGoogleDriveRepliesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_get_Status(TElGoogleDriveCommentHandle _Handle, TSBGoogleDriveCommentStatusRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComment_Create(TElGoogleDriveDataStorageObjectHandle AOwner, TElGoogleDriveCommentHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVECOMMENT */

#ifdef SB_USE_CLASS_TELGOOGLEDRIVEREPLIES
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReplies_Add(TElGoogleDriveRepliesHandle _Handle, const char * pcContent, int32_t szContent, TSBGoogleDriveReplyActionRaw Action, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReplies_Refresh(TElGoogleDriveRepliesHandle _Handle, int8_t IncludeDeleted);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReplies_get_Count(TElGoogleDriveRepliesHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReplies_get_Items(TElGoogleDriveRepliesHandle _Handle, int32_t Index, TElGoogleDriveReplyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReplies_Create(TElGoogleDriveCommentHandle AOwner, TElGoogleDriveRepliesHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVEREPLIES */

#ifdef SB_USE_CLASS_TELGOOGLEDRIVEUSER
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveUser_Clone(TElGoogleDriveUserHandle _Handle, TElGoogleDriveUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveUser_get_DisplayName(TElGoogleDriveUserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveUser_get_IsAuthenticated(TElGoogleDriveUserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveUser_get_PermissionID(TElGoogleDriveUserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveUser_get_PictureURL(TElGoogleDriveUserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveUser_Create(TElGoogleDriveUserHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVEUSER */

#ifdef SB_USE_CLASS_TELGOOGLEDRIVEACCOUNTINFO
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_Refresh(TElGoogleDriveAccountInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_get_DomainSharingPolicy(TElGoogleDriveAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_get_ETag(TElGoogleDriveAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_get_LanguageCode(TElGoogleDriveAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_get_LargestChangeID(TElGoogleDriveAccountInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_get_Name(TElGoogleDriveAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_get_PermissionID(TElGoogleDriveAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_get_QuotaBytesTotal(TElGoogleDriveAccountInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_get_QuotaBytesUsed(TElGoogleDriveAccountInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_get_QuotaBytesUsedAggregate(TElGoogleDriveAccountInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_get_QuotaBytesUsedInTrash(TElGoogleDriveAccountInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_get_RemainingChangeIDs(TElGoogleDriveAccountInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_get_RootFolderID(TElGoogleDriveAccountInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_get_User(TElGoogleDriveAccountInfoHandle _Handle, TElGoogleDriveUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveAccountInfo_Create(TElGoogleDriveDataStorageHandle AStorage, TElGoogleDriveAccountInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVEACCOUNTINFO */

#ifdef SB_USE_CLASS_TELGOOGLEDRIVECOMMENTS
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComments_Add(TElGoogleDriveCommentsHandle _Handle, const char * pcContent, int32_t szContent, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComments_Refresh(TElGoogleDriveCommentsHandle _Handle, int8_t IncludeDeleted);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComments_Refresh_1(TElGoogleDriveCommentsHandle _Handle, int64_t UpdatedAfter, int8_t IncludeDeleted);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComments_get_Count(TElGoogleDriveCommentsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComments_get_Items(TElGoogleDriveCommentsHandle _Handle, int32_t Index, TElGoogleDriveCommentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComments_get_Owner(TElGoogleDriveCommentsHandle _Handle, TElGoogleDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveComments_Create(TElGoogleDriveDataStorageObjectHandle AOwner, TElGoogleDriveCommentsHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVECOMMENTS */

#ifdef SB_USE_CLASS_TELGOOGLEDRIVEREPLY
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReply_Assign(TElGoogleDriveReplyHandle _Handle, TElGoogleDriveReplyHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReply_Clone(TElGoogleDriveReplyHandle _Handle, TElGoogleDriveReplyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReply_Delete(TElGoogleDriveReplyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReply_get_Author(TElGoogleDriveReplyHandle _Handle, TElGoogleDriveUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReply_get_Content(TElGoogleDriveReplyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReply_set_Content(TElGoogleDriveReplyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReply_get_CreatedDate(TElGoogleDriveReplyHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReply_get_Deleted(TElGoogleDriveReplyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReply_get_HtmlContent(TElGoogleDriveReplyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReply_get_ID(TElGoogleDriveReplyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReply_get_ModifiedDate(TElGoogleDriveReplyHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReply_get_Owner(TElGoogleDriveReplyHandle _Handle, TElGoogleDriveCommentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveReply_Create(TElGoogleDriveCommentHandle AOwner, TElGoogleDriveReplyHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVEREPLY */

#ifdef SB_USE_CLASS_TELGOOGLEDRIVEPROPERTY
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperty_Clone(TElGoogleDrivePropertyHandle _Handle, TElGoogleDrivePropertyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperty_Delete(TElGoogleDrivePropertyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperty_Refresh(TElGoogleDrivePropertyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperty_get_ETag(TElGoogleDrivePropertyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperty_get_Key(TElGoogleDrivePropertyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperty_get_Value(TElGoogleDrivePropertyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperty_set_Value(TElGoogleDrivePropertyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperty_get_Visibility(TElGoogleDrivePropertyHandle _Handle, TSBGoogleDrivePropertyVisibilityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveProperty_Create(TElGoogleDriveDataStorageObjectHandle AOwner, TElGoogleDrivePropertyHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVEPROPERTY */

#ifdef SB_USE_CLASS_TELGOOGLEDRIVEPERMISSION
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_Clone(TElGoogleDrivePermissionHandle _Handle, TElGoogleDrivePermissionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_Delete(TElGoogleDrivePermissionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_Refresh(TElGoogleDrivePermissionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_TransferOwnership(TElGoogleDrivePermissionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_get_AuthKey(TElGoogleDrivePermissionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_get_Commenter(TElGoogleDrivePermissionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_set_Commenter(TElGoogleDrivePermissionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_get_ETag(TElGoogleDrivePermissionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_get_ID(TElGoogleDrivePermissionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_get_Name(TElGoogleDrivePermissionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_get_Owner(TElGoogleDrivePermissionHandle _Handle, TElGoogleDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_get_PhotoLink(TElGoogleDrivePermissionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_get_Role(TElGoogleDrivePermissionHandle _Handle, TSBGoogleDriveUserRoleRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_set_Role(TElGoogleDrivePermissionHandle _Handle, TSBGoogleDriveUserRoleRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_get_Scope(TElGoogleDrivePermissionHandle _Handle, TSBGoogleDrivePermissionScopeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_get_Value(TElGoogleDrivePermissionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_get_WithLink(TElGoogleDrivePermissionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermission_Create(TElGoogleDriveDataStorageObjectHandle AOwner, TElGoogleDrivePermissionHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVEPERMISSION */

#ifdef SB_USE_CLASS_TELGOOGLEDRIVEPERMISSIONS
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermissions_Add(TElGoogleDrivePermissionsHandle _Handle, TSBGoogleDriveUserRoleRaw Role, TSBGoogleDrivePermissionScopeRaw AccountType, const char * pcValue, int32_t szValue, int8_t CanComment, int8_t WithLink, int8_t SendNotificationEMails, const char * pcEMailMessage, int32_t szEMailMessage, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermissions_Refresh(TElGoogleDrivePermissionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermissions_get_Count(TElGoogleDrivePermissionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermissions_get_ETag(TElGoogleDrivePermissionsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermissions_get_Items(TElGoogleDrivePermissionsHandle _Handle, int32_t Index, TElGoogleDrivePermissionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermissions_get_Owner(TElGoogleDrivePermissionsHandle _Handle, TElGoogleDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDrivePermissions_Create(TElGoogleDriveDataStorageObjectHandle AOwner, TElGoogleDrivePermissionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVEPERMISSIONS */

#ifdef SB_USE_CLASS_TELGOOGLEDRIVECUSTOMFILE
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveCustomFile_Create(TElGoogleDriveDataStorageHandle AStorage, TElGoogleDriveDataStorageObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVECUSTOMFILE */

#ifdef SB_USE_CLASS_TELGOOGLEDRIVEFILE
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFile_Assign(TElGoogleDriveFileHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFile_Clear(TElGoogleDriveFileHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFile_Clone(TElGoogleDriveFileHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFile_Read(TElGoogleDriveFileHandle _Handle, TStreamHandle Data);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFile_Write(TElGoogleDriveFileHandle _Handle, TStreamHandle Data, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFile_get_DownloadURL(TElGoogleDriveFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFile_get_FileExtension(TElGoogleDriveFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFile_get_FileSize(TElGoogleDriveFileHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFile_get_MD5Checksum(TElGoogleDriveFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFile_get_OriginalFileName(TElGoogleDriveFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFile_get_QuotaBytesUsed(TElGoogleDriveFileHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFile_get_Size(TElGoogleDriveFileHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDriveFile_Create(TElGoogleDriveDataStorageHandle AStorage, TElGoogleDriveFileHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDRIVEFILE */

#ifdef SB_USE_CLASS_TELGOOGLEDOCUMENT
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDocument_Assign(TElGoogleDocumentHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDocument_Clear(TElGoogleDocumentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDocument_Clone(TElGoogleDocumentHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDocument_get_EmbedLink(TElGoogleDocumentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGoogleDocument_Create(TElGoogleDriveDataStorageHandle AStorage, TElGoogleDocumentHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOOGLEDOCUMENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElGoogleDriveDataStorage_ce_ptr;
extern zend_class_entry *TElGoogleDriveDataStorageObject_ce_ptr;
extern zend_class_entry *TElGoogleDriveFolder_ce_ptr;
extern zend_class_entry *TElGoogleDriveProperties_ce_ptr;
extern zend_class_entry *TElGoogleDriveComment_ce_ptr;
extern zend_class_entry *TElGoogleDriveReplies_ce_ptr;
extern zend_class_entry *TElGoogleDriveUser_ce_ptr;
extern zend_class_entry *TElGoogleDriveAccountInfo_ce_ptr;
extern zend_class_entry *TElGoogleDriveComments_ce_ptr;
extern zend_class_entry *TElGoogleDriveReply_ce_ptr;
extern zend_class_entry *TElGoogleDriveProperty_ce_ptr;
extern zend_class_entry *TElGoogleDrivePermission_ce_ptr;
extern zend_class_entry *TElGoogleDrivePermissions_ce_ptr;
extern zend_class_entry *TElGoogleDriveCustomFile_ce_ptr;
extern zend_class_entry *TElGoogleDriveFile_ce_ptr;
extern zend_class_entry *TElGoogleDocument_ce_ptr;

void Register_TElGoogleDriveDataStorage(TSRMLS_D);
void Register_TElGoogleDriveDataStorageObject(TSRMLS_D);
void Register_TElGoogleDriveFolder(TSRMLS_D);
void Register_TElGoogleDriveProperties(TSRMLS_D);
void Register_TElGoogleDriveComment(TSRMLS_D);
void Register_TElGoogleDriveReplies(TSRMLS_D);
void Register_TElGoogleDriveUser(TSRMLS_D);
void Register_TElGoogleDriveAccountInfo(TSRMLS_D);
void Register_TElGoogleDriveComments(TSRMLS_D);
void Register_TElGoogleDriveReply(TSRMLS_D);
void Register_TElGoogleDriveProperty(TSRMLS_D);
void Register_TElGoogleDrivePermission(TSRMLS_D);
void Register_TElGoogleDrivePermissions(TSRMLS_D);
void Register_TElGoogleDriveCustomFile(TSRMLS_D);
void Register_TElGoogleDriveFile(TSRMLS_D);
void Register_TElGoogleDocument(TSRMLS_D);
void Register_SBGoogleDriveDataStorage_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBGOOGLEDRIVEDATASTORAGE */

