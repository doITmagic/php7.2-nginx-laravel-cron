#ifndef __INC_SBGSSWINAUTH
#define __INC_SBGSSWINAUTH

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbgssapibase.h"
#include "sbgssapi.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef SB_WINDOWS
#define SB_GSS_MECH_NTLM 	"+\x06""\x01""\x04""\x82""7\x02""\x02""\n"
#define SB_GSS_MECH_KRB5 	"*\x86""H\x86""\xF7""\x12""\x01""\x02""\x02"

typedef TElClassHandle TElGSSWinContextHandle;

typedef TElClassHandle TElGSSWinNameHandle;

typedef TElClassHandle TElGSSWinAuthMechanismHandle;

typedef uint32_t TElGSSWinAuthProtocolsRaw;

typedef enum 
{
	f_apKerberos = 1,
	f_apNTLM = 2
} TElGSSWinAuthProtocols;

#ifdef SB_USE_CLASS_TELGSSWINCONTEXT
SB_IMPORT uint32_t SB_APIENTRY TElGSSWinContext_Create(TElGSSWinContextHandle * OutResult);
#endif /* SB_USE_CLASS_TELGSSWINCONTEXT */

#ifdef SB_USE_CLASS_TELGSSWINNAME
SB_IMPORT uint32_t SB_APIENTRY TElGSSWinName_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELGSSWINNAME */

#ifdef SB_USE_CLASS_TELGSSWINAUTHMECHANISM
SB_IMPORT uint32_t SB_APIENTRY TElGSSWinAuthMechanism_Initialize(TElGSSWinAuthMechanismHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGSSWinAuthMechanism_AcquireCred(TElGSSWinAuthMechanismHandle _Handle, const uint8_t pMechOID[], int32_t szMechOID, TElGSSCustomContextHandle * Ctx, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGSSWinAuthMechanism_AcceptSecContext(TElGSSWinAuthMechanismHandle _Handle, TElGSSCustomContextHandle Ctx, TElGSSCustomNameHandle SourceName, const uint8_t pInputToken[], int32_t szInputToken, uint8_t pOutputToken[], int32_t * szOutputToken, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGSSWinAuthMechanism_InitSecContext(TElGSSWinAuthMechanismHandle _Handle, TElGSSCustomContextHandle Ctx, TElGSSCustomNameHandle TargetName, int8_t DelegateCred, const uint8_t pInputToken[], int32_t szInputToken, uint8_t pOutputToken[], int32_t * szOutputToken, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGSSWinAuthMechanism_ReleaseContext(TElGSSWinAuthMechanismHandle _Handle, TElGSSCustomContextHandle * Ctx, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGSSWinAuthMechanism_ImportName(TElGSSWinAuthMechanismHandle _Handle, const uint8_t pMechOID[], int32_t szMechOID, const char * pcInputName, int32_t szInputName, TElGSSCustomNameHandle * OutputName, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGSSWinAuthMechanism_ReleaseName(TElGSSWinAuthMechanismHandle _Handle, TElGSSCustomNameHandle * Name, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGSSWinAuthMechanism_GetMIC(TElGSSWinAuthMechanismHandle _Handle, TElGSSCustomContextHandle Ctx, const uint8_t pMessageBuffer[], int32_t szMessageBuffer, uint8_t pMessageToken[], int32_t * szMessageToken, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGSSWinAuthMechanism_VerifyMIC(TElGSSWinAuthMechanismHandle _Handle, TElGSSCustomContextHandle Ctx, const uint8_t pMessageBuffer[], int32_t szMessageBuffer, const uint8_t pMessageToken[], int32_t szMessageToken, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGSSWinAuthMechanism_get_AuthProtocols(TElGSSWinAuthMechanismHandle _Handle, TElGSSWinAuthProtocolsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGSSWinAuthMechanism_set_AuthProtocols(TElGSSWinAuthMechanismHandle _Handle, TElGSSWinAuthProtocolsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElGSSWinAuthMechanism_Create(TElGSSWinAuthMechanismHandle * OutResult);
#endif /* SB_USE_CLASS_TELGSSWINAUTHMECHANISM */
#endif

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef SB_WINDOWS
extern zend_class_entry *TElGSSWinContext_ce_ptr;
extern zend_class_entry *TElGSSWinName_ce_ptr;
extern zend_class_entry *TElGSSWinAuthMechanism_ce_ptr;

void Register_TElGSSWinContext(TSRMLS_D);
void Register_TElGSSWinName(TSRMLS_D);
void Register_TElGSSWinAuthMechanism(TSRMLS_D);
void Register_SBGSSWinAuth_Constants(int module_number TSRMLS_DC);
void Register_SBGSSWinAuth_Enum_Flags(TSRMLS_D);
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBGSSWINAUTH */
