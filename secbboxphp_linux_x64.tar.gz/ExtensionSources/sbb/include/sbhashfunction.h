#ifndef __INC_SBHASHFUNCTION
#define __INC_SBHASHFUNCTION

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbcryptoprov.h"
#include "sbcustomcrypto.h"
#include "sbrdn.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElHMACKeyMaterialHandle;

typedef TElHMACKeyMaterialHandle ElHMACKeyMaterialHandle;

typedef TElClassHandle TElHashFunctionHandle;

typedef TElHashFunctionHandle ElHashFunctionHandle;

#ifdef SB_USE_CLASS_TELHMACKEYMATERIAL
SB_IMPORT uint32_t SB_APIENTRY TElHMACKeyMaterial_get_Key(TElHMACKeyMaterialHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHMACKeyMaterial_set_Key(TElHMACKeyMaterialHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHMACKeyMaterial_get_Nonce(TElHMACKeyMaterialHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHMACKeyMaterial_set_Nonce(TElHMACKeyMaterialHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHMACKeyMaterial_get_CryptoProvider(TElHMACKeyMaterialHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHMACKeyMaterial_Create(TElCustomCryptoProviderHandle Prov, TElHMACKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHMACKeyMaterial_Create_1(TElCustomCryptoKeyHandle Key, TElCustomCryptoProviderHandle Prov, TElHMACKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHMACKeyMaterial_Create_2(TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElHMACKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHMACKeyMaterial_Create_3(TElCustomCryptoKeyHandle Key, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElHMACKeyMaterialHandle * OutResult);
#endif /* SB_USE_CLASS_TELHMACKEYMATERIAL */

#ifdef SB_USE_CLASS_TELHASHFUNCTION
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Reset(TElHashFunctionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Update(TElHashFunctionHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Update_1(TElHashFunctionHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Update_2(TElHashFunctionHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_UpdateStream(TElHashFunctionHandle _Handle, TStreamHandle Stream, int64_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Finish(TElHashFunctionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Clone(TElHashFunctionHandle _Handle, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_IsAlgorithmSupported(int32_t Algorithm, TElCustomCryptoProviderHandle CryptoProvider, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_IsAlgorithmSupported_1(TElHashFunctionHandle _Handle, int32_t Algorithm, TElCustomCryptoProviderHandle CryptoProvider, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_IsAlgorithmSupported_2(const uint8_t pOID[], int32_t szOID, TElCustomCryptoProviderHandle CryptoProvider, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_IsAlgorithmSupported_3(TElHashFunctionHandle _Handle, const uint8_t pOID[], int32_t szOID, TElCustomCryptoProviderHandle CryptoProvider, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_IsAlgorithmSupported_4(int32_t Algorithm, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_IsAlgorithmSupported_5(TElHashFunctionHandle _Handle, int32_t Algorithm, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_IsAlgorithmSupported_6(const uint8_t pOID[], int32_t szOID, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_IsAlgorithmSupported_7(TElHashFunctionHandle _Handle, const uint8_t pOID[], int32_t szOID, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_GetDigestSizeBits(int32_t Algorithm, TElCustomCryptoProviderHandle CryptoProvider, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_GetDigestSizeBits_1(TElHashFunctionHandle _Handle, int32_t Algorithm, TElCustomCryptoProviderHandle CryptoProvider, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_GetDigestSizeBits_2(const uint8_t pOID[], int32_t szOID, TElCustomCryptoProviderHandle CryptoProvider, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_GetDigestSizeBits_3(TElHashFunctionHandle _Handle, const uint8_t pOID[], int32_t szOID, TElCustomCryptoProviderHandle CryptoProvider, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_GetDigestSizeBits_4(int32_t Algorithm, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_GetDigestSizeBits_5(TElHashFunctionHandle _Handle, int32_t Algorithm, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_GetDigestSizeBits_6(const uint8_t pOID[], int32_t szOID, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_GetDigestSizeBits_7(TElHashFunctionHandle _Handle, const uint8_t pOID[], int32_t szOID, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Hash(int32_t Algorithm, void * Buffer, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Hash_1(TElHashFunctionHandle _Handle, int32_t Algorithm, void * Buffer, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Hash_2(int32_t Algorithm, TElHMACKeyMaterialHandle Key, void * Buffer, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Hash_3(TElHashFunctionHandle _Handle, int32_t Algorithm, TElHMACKeyMaterialHandle Key, void * Buffer, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_get_Algorithm(TElHashFunctionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_get_CryptoProvider(TElHashFunctionHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_set_CryptoProvider(TElHashFunctionHandle _Handle, TElCustomCryptoProviderHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_get_Key(TElHashFunctionHandle _Handle, TElHMACKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_set_Key(TElHashFunctionHandle _Handle, TElHMACKeyMaterialHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_get_ShakeOutputLength(TElHashFunctionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_set_ShakeOutputLength(TElHashFunctionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Create(int32_t Algorithm, TElCustomCryptoProviderHandle CryptoProvider, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Create_1(const uint8_t pOID[], int32_t szOID, TElCustomCryptoProviderHandle CryptoProvider, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Create_2(int32_t Algorithm, TElRelativeDistinguishedNameHandle Parameters, TElCustomCryptoProviderHandle CryptoProvider, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Create_3(const uint8_t pOID[], int32_t szOID, TElRelativeDistinguishedNameHandle Parameters, TElCustomCryptoProviderHandle CryptoProvider, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Create_4(TElCustomCryptoProviderHandle CryptoProvider, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Create_5(int32_t Algorithm, TElHMACKeyMaterialHandle Key, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Create_6(const uint8_t pOID[], int32_t szOID, TElHMACKeyMaterialHandle Key, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Create_7(int32_t Algorithm, TElHMACKeyMaterialHandle Key, TElCustomCryptoProviderHandle CryptoProvider, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Create_8(const uint8_t pOID[], int32_t szOID, TElHMACKeyMaterialHandle Key, TElCustomCryptoProviderHandle CryptoProvider, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Create_9(TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Create_10(int32_t Algorithm, TElRelativeDistinguishedNameHandle Parameters, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Create_11(const uint8_t pOID[], int32_t szOID, TElRelativeDistinguishedNameHandle Parameters, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Create_12(int32_t Algorithm, TElHMACKeyMaterialHandle Key, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHashFunction_Create_13(const uint8_t pOID[], int32_t szOID, TElHMACKeyMaterialHandle Key, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElHashFunctionHandle * OutResult);
#endif /* SB_USE_CLASS_TELHASHFUNCTION */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElHMACKeyMaterial_ce_ptr;
extern zend_class_entry *TElHashFunction_ce_ptr;

void Register_TElHMACKeyMaterial(TSRMLS_D);
void Register_TElHashFunction(TSRMLS_D);
void Register_SBHashFunction_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBHASHFUNCTION */

