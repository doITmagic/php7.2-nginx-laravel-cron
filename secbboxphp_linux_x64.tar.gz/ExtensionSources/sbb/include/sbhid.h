#ifndef __INC_SBHID
#define __INC_SBHID

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_HID 	147456
#define SB_ERROR_HID_ERROR_FLAG 	2048
#define SB_ERROR_HID_CORE_ERROR_FLAG 	2304
#define SB_HID_ERROR_DEVICE_NOT_OPEN 	149505
#define SB_HID_ERROR_DEVICE_WRITE_ONLY 	149506
#define SB_HID_ERROR_DEVICE_READ_ONLY 	149507
#define SB_HID_ERROR_FAILED_SET_INPUT_BUFNUM 	149508
#define SB_HID_ERROR_INDEX_OUT_OF_BOUNDS 	149509
#define SB_HID_ERROR_DEVICE_NO_FEATURE_REPORTS 	149510
#define SB_HID_ERROR_INVALID_DEVICE_HANDLE 	149761
#define SB_HID_ERROR_INVALID_DEVICE_OBJECT_CLASS 	149762
#define SB_HID_ERROR_HID_LIBRARY_LOAD_FAILED 	149776
#define SB_HID_ERROR_SETUP_API_LIBRARY_LOAD_FAILED 	149777
#define SB_HID_ERROR_DEVICE_INTFS_ENUM_FAILED 	149778
#define SB_HID_ERROR_DEVICE_INTF_DETAIL_GET_FAILED 	149779
#define SB_HID_ERROR_UDEV_LIBRARY_LOAD_FAILED 	149808
#define SB_HID_ERROR_UDEV_INIT_FAILED 	149809
#define SB_HID_ERROR_UDEV_INIT_ENUM_FAILED 	149810
#define SB_HID_ERROR_UDEV_ADD_MATCH_SUBSYSTEM_FAILED 	149811
#define SB_HID_ERROR_UDEV_DEVICES_ENUM_FAILED 	149812
#define SB_HID_ERROR_IOKIT_LIBRARY_LOAD_FAILED 	149840
#define SB_HID_ERROR_IOKIT_INIT_FAILED 	149841
#define SB_SHIDInvalidDeviceObjectClass 	"Invalid HID device object class"
#define SB_SHIDInvalidDeviceHandle 	"Invalid handle for HID device"

typedef TObjectHandle TSBHIDDeviceObjectHandle;

typedef TElClassHandle TElHIDDeviceInfoHandle;

typedef TElClassHandle TElHIDDeviceInfoListHandle;

typedef TElClassHandle TElHIDDeviceHandle;

typedef void (SB_CALLBACK *TSBHIDEnumerateDevicesProc)(void * _ObjectData, TElHIDDeviceInfoHandle DeviceInfo, int8_t * FreeDeviceInfoObject, int8_t * OutResult);

#ifdef SB_USE_CLASS_TELHIDDEVICEINFO
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_Clear(TElHIDDeviceInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_Clone(TElHIDDeviceInfoHandle _Handle, TElHIDDeviceInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_Init(TElHIDDeviceInfoHandle _Handle, const char * pcADevicePath, int32_t szADevicePath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_Init_1(TElHIDDeviceInfoHandle _Handle, const char * pcADevicePath, int32_t szADevicePath, TObjectHandle Device);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_get_DevicePath(TElHIDDeviceInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_get_Manufacturer(TElHIDDeviceInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_get_Product(TElHIDDeviceInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_get_SerialNumber(TElHIDDeviceInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_get_VendorID(TElHIDDeviceInfoHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_get_ProductID(TElHIDDeviceInfoHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_get_RevisionNumber(TElHIDDeviceInfoHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_get_Usage(TElHIDDeviceInfoHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_get_UsagePage(TElHIDDeviceInfoHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_get_InputReportByteLength(TElHIDDeviceInfoHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_get_OutputReportByteLength(TElHIDDeviceInfoHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_get_FeatureReportByteLength(TElHIDDeviceInfoHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfo_Create(TElHIDDeviceInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELHIDDEVICEINFO */

#ifdef SB_USE_CLASS_TELHIDDEVICEINFOLIST
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfoList_Add(TElHIDDeviceInfoListHandle _Handle, TElHIDDeviceInfoHandle AInfo, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfoList_Insert(TElHIDDeviceInfoListHandle _Handle, int32_t Index, TElHIDDeviceInfoHandle AInfo);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfoList_Delete(TElHIDDeviceInfoListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfoList_Clear(TElHIDDeviceInfoListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfoList_get_Count(TElHIDDeviceInfoListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfoList_get_DeviceInfos(TElHIDDeviceInfoListHandle _Handle, int32_t Index, TElHIDDeviceInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDeviceInfoList_Create(TElHIDDeviceInfoListHandle * OutResult);
#endif /* SB_USE_CLASS_TELHIDDEVICEINFOLIST */

#ifdef SB_USE_CLASS_TELHIDDEVICE
SB_IMPORT uint32_t SB_APIENTRY TElHIDDevice_Open(TElHIDDeviceHandle _Handle, const char * pcADevicePath, int32_t szADevicePath);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDevice_Close(TElHIDDeviceHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDevice_Read(TElHIDDeviceHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDevice_Write(TElHIDDeviceHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDevice_GetFeature(TElHIDDeviceHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDevice_SetFeature(TElHIDDeviceHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDevice_get_Info(TElHIDDeviceHandle _Handle, TElHIDDeviceInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDevice_get_Timeout(TElHIDDeviceHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDevice_set_Timeout(TElHIDDeviceHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHIDDevice_Create(TElHIDDeviceHandle * OutResult);
#endif /* SB_USE_CLASS_TELHIDDEVICE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElHIDDeviceInfo_ce_ptr;
extern zend_class_entry *TElHIDDeviceInfoList_ce_ptr;
extern zend_class_entry *TElHIDDevice_ce_ptr;

void SB_CALLBACK TSBHIDEnumerateDevicesProcRaw(void * _ObjectData, TElHIDDeviceInfoHandle DeviceInfo, int8_t * FreeDeviceInfoObject, int8_t * OutResult);
void Register_TElHIDDeviceInfo(TSRMLS_D);
void Register_TElHIDDeviceInfoList(TSRMLS_D);
void Register_TElHIDDevice(TSRMLS_D);
SB_PHP_FUNCTION(SBHID, HIDEnumerateDevices);
void Register_SBHID_Constants(int module_number TSRMLS_DC);
void Register_SBHID_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_HID
SB_IMPORT uint32_t SB_APIENTRY SBHID_HIDEnumerateDevices(TElHIDDeviceInfoListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHID_HIDEnumerateDevices_1(TSBHIDEnumerateDevicesProc pMethodEnumProc, void * pDataEnumProc);
#endif /* SB_USE_GLOBAL_PROCS_HID */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBHID */

