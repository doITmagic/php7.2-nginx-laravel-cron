#ifndef __INC_SBHIDLINUX
#define __INC_SBHIDLINUX

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#ifdef LINUX
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbhid.h"
#endif

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef LINUX
typedef uint8_t TSBHIDOptionRaw;

typedef enum
{
	hidDisableHidraw = 0,
	hidDisableHiddev = 1
} TSBHIDOption;

typedef uint32_t TSBHIDOptionsRaw;

typedef enum 
{
	f_hidDisableHidraw = 1,
	f_hidDisableHiddev = 2
} TSBHIDOptions;

#ifdef __cplusplus
};	/* extern "C" */
#endif

SB_PHP_FUNCTION(SBHIDLinux, HIDEnumerateDevices);
SB_PHP_FUNCTION(SBHIDLinux, LoadUdevModule);
SB_PHP_FUNCTION(SBHIDLinux, UnloadUdevModule);
SB_PHP_FUNCTION(SBHIDLinux, HIDOpenDevice);
SB_PHP_FUNCTION(SBHIDLinux, HIDCloseDevice);
SB_PHP_FUNCTION(SBHIDLinux, HIDReadTimeout);
SB_PHP_FUNCTION(SBHIDLinux, HIDWriteTimeout);
SB_PHP_FUNCTION(SBHIDLinux, HIDIsInvalidDevice);
SB_PHP_FUNCTION(SBHIDLinux, HIDGetDeviceAttributes);
SB_PHP_FUNCTION(SBHIDLinux, HIDGetDeviceSerialNumber);
SB_PHP_FUNCTION(SBHIDLinux, HIDGetDeviceManufacturer);
SB_PHP_FUNCTION(SBHIDLinux, HIDGetDeviceProduct);
SB_PHP_FUNCTION(SBHIDLinux, HIDGetDeviceIndexedString);
SB_PHP_FUNCTION(SBHIDLinux, HIDGetDeviceCapabilities);
SB_PHP_FUNCTION(SBHIDLinux, HIDGetDeviceFeature);
SB_PHP_FUNCTION(SBHIDLinux, HIDSetDeviceFeature);
SB_PHP_FUNCTION(SBHIDLinux, GetHIDOptions);
SB_PHP_FUNCTION(SBHIDLinux, SetHIDOptions);
void Register_SBHIDLinux_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_HIDLINUX
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_HIDEnumerateDevices(TElHIDDeviceInfoListHandle List, TSBHIDEnumerateDevicesProc pMethodEnumProc, void * pDataEnumProc);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_LoadUdevModule(void);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_UnloadUdevModule(void);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_HIDOpenDevice(const char * pcPath, int32_t szPath, int8_t ReadWriteAccess, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_HIDCloseDevice(TObjectHandle Device);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_HIDReadTimeout(TObjectHandle Device, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t Timeout, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_HIDWriteTimeout(TObjectHandle Device, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t Timeout, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_HIDIsInvalidDevice(TObjectHandle Device, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_HIDGetDeviceAttributes(TObjectHandle Device, uint16_t * VendorID, uint16_t * ProductID, uint16_t * VersionNumber);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_HIDGetDeviceSerialNumber(TObjectHandle Device, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_HIDGetDeviceManufacturer(TObjectHandle Device, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_HIDGetDeviceProduct(TObjectHandle Device, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_HIDGetDeviceIndexedString(TObjectHandle Device, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_HIDGetDeviceCapabilities(TObjectHandle Device, uint16_t * Usage, uint16_t * UsagePage, uint16_t * InputReportByteLength, uint16_t * OutputReportByteLength, uint16_t * FeatureReportByteLength);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_HIDGetDeviceFeature(TObjectHandle Device, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_HIDSetDeviceFeature(TObjectHandle Device, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_GetHIDOptions(TSBHIDOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDLinux_SetHIDOptions(TSBHIDOptionsRaw Value);
#endif /* SB_USE_GLOBAL_PROCS_HIDLINUX */
#endif

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBHIDLINUX */
