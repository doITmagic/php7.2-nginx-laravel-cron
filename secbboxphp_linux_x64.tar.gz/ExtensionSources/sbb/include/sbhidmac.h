#ifndef __INC_SBHIDMAC
#define __INC_SBHIDMAC

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#ifdef MACOS
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbhid.h"
#endif

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef MACOS
#ifdef __cplusplus
};	/* extern "C" */
#endif

SB_PHP_FUNCTION(SBHIDMac, HIDEnumerateDevices);
SB_PHP_FUNCTION(SBHIDMac, LoadIOHIDModule);
SB_PHP_FUNCTION(SBHIDMac, UnloadIOHIDModule);
SB_PHP_FUNCTION(SBHIDMac, HIDOpenDevice);
SB_PHP_FUNCTION(SBHIDMac, HIDCloseDevice);
SB_PHP_FUNCTION(SBHIDMac, HIDReadTimeout);
SB_PHP_FUNCTION(SBHIDMac, HIDWriteTimeout);
SB_PHP_FUNCTION(SBHIDMac, HIDIsInvalidDevice);
SB_PHP_FUNCTION(SBHIDMac, HIDGetDeviceAttributes);
SB_PHP_FUNCTION(SBHIDMac, HIDGetDeviceSerialNumber);
SB_PHP_FUNCTION(SBHIDMac, HIDGetDeviceManufacturer);
SB_PHP_FUNCTION(SBHIDMac, HIDGetDeviceProduct);
SB_PHP_FUNCTION(SBHIDMac, HIDGetDeviceIndexedString);
SB_PHP_FUNCTION(SBHIDMac, HIDGetDeviceCapabilities);
SB_PHP_FUNCTION(SBHIDMac, HIDGetDeviceFeature);
SB_PHP_FUNCTION(SBHIDMac, HIDSetDeviceFeature);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_HIDMAC
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_HIDEnumerateDevices(TElHIDDeviceInfoListHandle List, TSBHIDEnumerateDevicesProc pMethodEnumProc, void * pDataEnumProc);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_LoadIOHIDModule(void);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_UnloadIOHIDModule(void);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_HIDOpenDevice(const char * pcPath, int32_t szPath, int8_t ReadWriteAccess, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_HIDCloseDevice(TObjectHandle Device);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_HIDReadTimeout(TObjectHandle Device, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t Timeout, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_HIDWriteTimeout(TObjectHandle Device, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t Timeout, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_HIDIsInvalidDevice(TObjectHandle Device, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_HIDGetDeviceAttributes(TObjectHandle Device, uint16_t * VendorID, uint16_t * ProductID, uint16_t * VersionNumber);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_HIDGetDeviceSerialNumber(TObjectHandle Device, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_HIDGetDeviceManufacturer(TObjectHandle Device, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_HIDGetDeviceProduct(TObjectHandle Device, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_HIDGetDeviceIndexedString(TObjectHandle Device, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_HIDGetDeviceCapabilities(TObjectHandle Device, uint16_t * Usage, uint16_t * UsagePage, uint16_t * InputReportByteLength, uint16_t * OutputReportByteLength, uint16_t * FeatureReportByteLength);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_HIDGetDeviceFeature(TObjectHandle Device, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDMac_HIDSetDeviceFeature(TObjectHandle Device, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_HIDMAC */
#endif

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBHIDMAC */
