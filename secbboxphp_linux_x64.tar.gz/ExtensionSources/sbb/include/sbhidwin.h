#ifndef __INC_SBHIDWIN
#define __INC_SBHIDWIN

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#ifdef SB_WINDOWS
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbhid.h"
#endif

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef SB_WINDOWS
#ifdef __cplusplus
};	/* extern "C" */
#endif

SB_PHP_FUNCTION(SBHIDWin, HIDEnumerateDevices);
SB_PHP_FUNCTION(SBHIDWin, LoadHIDModule);
SB_PHP_FUNCTION(SBHIDWin, LoadSetupAPIModule);
SB_PHP_FUNCTION(SBHIDWin, UnloadHIDModule);
SB_PHP_FUNCTION(SBHIDWin, UnloadSetupAPIModule);
SB_PHP_FUNCTION(SBHIDWin, HIDOpenDevice);
SB_PHP_FUNCTION(SBHIDWin, HIDCloseDevice);
SB_PHP_FUNCTION(SBHIDWin, HIDReadTimeout);
SB_PHP_FUNCTION(SBHIDWin, HIDWriteTimeout);
SB_PHP_FUNCTION(SBHIDWin, HIDIsInvalidDevice);
SB_PHP_FUNCTION(SBHIDWin, HIDGetDeviceAttributes);
SB_PHP_FUNCTION(SBHIDWin, HIDGetDeviceSerialNumber);
SB_PHP_FUNCTION(SBHIDWin, HIDGetDeviceManufacturer);
SB_PHP_FUNCTION(SBHIDWin, HIDGetDeviceProduct);
SB_PHP_FUNCTION(SBHIDWin, HIDGetDeviceIndexedString);
SB_PHP_FUNCTION(SBHIDWin, HIDGetDeviceCapabilities);
SB_PHP_FUNCTION(SBHIDWin, HIDGetDeviceFeature);
SB_PHP_FUNCTION(SBHIDWin, HIDSetDeviceFeature);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_HIDWIN
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_HIDEnumerateDevices(TElHIDDeviceInfoListHandle List, TSBHIDEnumerateDevicesProc pMethodEnumProc, void * pDataEnumProc);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_LoadHIDModule(void);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_LoadSetupAPIModule(void);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_UnloadHIDModule(void);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_UnloadSetupAPIModule(void);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_HIDOpenDevice(const char * pcPath, int32_t szPath, int8_t ReadWriteAccess, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_HIDCloseDevice(TObjectHandle Device);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_HIDReadTimeout(TObjectHandle Device, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t Timeout, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_HIDWriteTimeout(TObjectHandle Device, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t Timeout, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_HIDIsInvalidDevice(TObjectHandle Device, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_HIDGetDeviceAttributes(TObjectHandle Device, uint16_t * VendorID, uint16_t * ProductID, uint16_t * VersionNumber);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_HIDGetDeviceSerialNumber(TObjectHandle Device, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_HIDGetDeviceManufacturer(TObjectHandle Device, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_HIDGetDeviceProduct(TObjectHandle Device, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_HIDGetDeviceIndexedString(TObjectHandle Device, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_HIDGetDeviceCapabilities(TObjectHandle Device, uint16_t * Usage, uint16_t * UsagePage, uint16_t * InputReportByteLength, uint16_t * OutputReportByteLength, uint16_t * FeatureReportByteLength);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_HIDGetDeviceFeature(TObjectHandle Device, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHIDWin_HIDSetDeviceFeature(TObjectHandle Device, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_HIDWIN */
#endif

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBHIDWIN */
