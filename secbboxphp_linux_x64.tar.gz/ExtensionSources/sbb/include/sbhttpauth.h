#ifndef __INC_SBHTTPAUTH
#define __INC_SBHTTPAUTH

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbencoding.h"
#include "sbhashfunction.h"
#include "sbconstants.h"
#include "sbhttpsconstants.h"
#include "sbrandom.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SEC_WINNT_AUTH_IDENTITY_ANSI 	1
#define SB_SEC_WINNT_AUTH_IDENTITY_UNICODE 	2
#define SB_SECPKG_CRED_OUTBOUND 	2
#define SB_SECBUFFER_TOKEN 	2
#define SB_SECURITY_NATIVE_DREP 	16
#define SB_SEC_I_CONTINUE_NEEDED 	590610
#define SB_SEC_I_COMPLETE_NEEDED 	590611
#define SB_SEC_I_COMPLETE_AND_CONTINUE 	590612

typedef int32_t * PInteger;

typedef uint32_t * SBHTTPAuth_PUInt32;

#pragma pack(8)
typedef struct 
{
#ifdef SB_WINDOWS
	uint32_t * dwLower;
	uint32_t * dwUpper;
} CredHandle, * PCredHandle, * PCtxtHandle;

typedef CredHandle CtxtHandle;

#pragma pack(8)
typedef struct 
{
	uint32_t cbBuffer;
	uint32_t BufferType;
	void * pvBuffer;
} SecBuffer, * PSecBuffer;

#pragma pack(8)
typedef struct 
{
	uint32_t ulVersion;
	uint32_t cBuffers;
	PSecBuffer pBuffers;
} SecBufferDesc, * PSecBufferDesc;

typedef int64_t * SBHTTPAuth_pint64;

#pragma pack(8)
typedef struct 
{
	uint32_t fCapabilities;
	uint16_t wVersion;
	uint16_t wRPCID;
	uint32_t cbMaxToken;
#ifdef CPU64
	int32_t _dummy0;
#endif
	char * Name;
	char * Comment;
} SecPkgInfo, * PSecPkgInfo;

#pragma pack(8)
typedef struct 
{
	char * User;
	uint32_t UserLength;
#ifdef CPU64
	int32_t _dummy0;
#endif
	char * Domain;
	uint32_t DomainLength;
#ifdef CPU64
	int32_t _dummy1;
#endif
	char * Password;
	uint32_t PasswordLength;
	uint32_t Flags;
} SBHTTPAuth_SEC_WINNT_AUTH_IDENTITY, * SBHTTPAuth_PSEC_WINNT_AUTH_IDENTITY;

#pragma pack(8)
typedef struct 
{
	int8_t NewConversation;
#else
	int8_t UUEncodeData;
#endif
	int8_t _dummy0;
	int16_t _dummy1;
#ifdef SB_WINDOWS
	CredHandle hcred;
	int8_t HaveCredHandle;
	int8_t _dummy2;
	int16_t _dummy3;
	uint32_t MaxToken;
	int8_t HaveCtxtHandle;
	int8_t _dummy4;
	int16_t _dummy5;
	CredHandle hctxt;
	SBHTTPAuth_SEC_WINNT_AUTH_IDENTITY AuthIdentity;
	int8_t UUEncodeData;
	int8_t _dummy6;
	int16_t _dummy7;
#endif
#ifndef SB_NOT_CPU64_OR_WINDOWS
	int32_t _dummy2;
#endif
	void * RequestURI;
	int32_t RequestMethod;
#ifndef SB_NOT_CPU64_OR_NOT_WINDOWS
	int32_t _dummy8;
#endif
#ifndef SB_NOT_CPU64_OR_WINDOWS
	int32_t _dummy3;
#endif
	void * sNonce;
	void * cNonce;
	int32_t cNonceCount;
#ifndef SB_NOT_CPU64_OR_NOT_WINDOWS
	int32_t _dummy9;
#endif
#ifndef SB_NOT_CPU64_OR_WINDOWS
	int32_t _dummy4;
#endif
	void * cRequest;
} AUTH_SEQ, * PAUTH_SEQ;

#ifdef SB_WINDOWS
typedef void (SB_CALLBACK *SEC_GET_KEY_FN)(void * Arg, void * Principal, uint32_t KeyVer, void * (* Key), int32_t * Status);

typedef void (SB_CALLBACK *FREE_CREDENTIALS_HANDLE_FN)(PCredHandle cred, int32_t * OutResult);

typedef void (SB_CALLBACK *ACQUIRE_CREDENTIALS_HANDLE_FN)(char * p1, char * p2, uint32_t p3, void * p4, void * p5, SEC_GET_KEY_FN p6, void * p7, PCredHandle p8, int64_t * p9, int32_t * OutResult);

typedef void (SB_CALLBACK *QUERY_SECURITY_PACKAGE_INFO_FN)(char * p1, PSecPkgInfo p2, int32_t * OutResult);

typedef void (SB_CALLBACK *FREE_CONTEXT_BUFFER_FN)(void * buf, int32_t * OutResult);

typedef void (SB_CALLBACK *INITIALIZE_SECURITY_CONTEXT_FN)(PCredHandle p1, PCtxtHandle p2, char * p3, uint32_t p4, uint32_t p5, uint32_t p6, PSecBufferDesc p7, uint32_t p8, PCtxtHandle p9, PSecBufferDesc p10, uint32_t * p11, int64_t * p12, int32_t * OutResult);

typedef void (SB_CALLBACK *COMPLETE_AUTH_TOKEN_FN)(PCtxtHandle p1, PSecBufferDesc p2, int32_t * OutResult);

typedef void (SB_CALLBACK *ENUMERATE_SECURITY_PACKAGES_FN)(uint32_t * p1, PSecPkgInfo p2, int32_t * OutResult);

typedef void (SB_CALLBACK *DELETE_SECURITY_CONTEXT_FN)(PCtxtHandle ctx, int32_t * OutResult);

#pragma pack(8)
typedef struct 
{
	void * FreeCredentialsHandle;
	void * AcquireCredentialsHandleA;
	void * QuerySecurityPackageInfoA;
	void * FreeContextBuffer;
	void * InitializeSecurityContextA;
	void * CompleteAuthToken;
	void * EnumerateSecurityPackagesA;
	void * DeleteSecurityContext;
} secFuncs;
#endif

typedef uint8_t TSBUsernameOptionRaw;

typedef enum
{
	unoSplitUsername = 0,
	unoFullUsernameNoDomain = 1,
	unoFullUsernameAndDomain = 2
} TSBUsernameOption;

typedef void * (* SBHTTPAuth_PPointer);

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef SB_WINDOWS
extern zend_class_entry *CredHandle_ce_ptr;
extern zend_class_entry *SecBuffer_ce_ptr;
extern zend_class_entry *SecBufferDesc_ce_ptr;
extern zend_class_entry *SecPkgInfo_ce_ptr;
extern zend_class_entry *SBHTTPAuth_SEC_WINNT_AUTH_IDENTITY_ce_ptr;
#endif
extern zend_class_entry *AUTH_SEQ_ce_ptr;
#ifdef SB_WINDOWS
extern zend_class_entry *secFuncs_ce_ptr;
#endif

#ifdef SB_WINDOWS
void Register_CredHandle(TSRMLS_D);
void Register_SecBuffer(TSRMLS_D);
void Register_SecBufferDesc(TSRMLS_D);
void Register_SecPkgInfo(TSRMLS_D);
void Register_SBHTTPAuth_SEC_WINNT_AUTH_IDENTITY(TSRMLS_D);
#endif
void Register_AUTH_SEQ(TSRMLS_D);
#ifdef SB_WINDOWS
void Register_secFuncs(TSRMLS_D);
#endif
SB_PHP_FUNCTION(SBHTTPAuth, AuthInit);
SB_PHP_FUNCTION(SBHTTPAuth, AuthTerm);
SB_PHP_FUNCTION(SBHTTPAuth, AuthConverse);
SB_PHP_FUNCTION(SBHTTPAuth, AddAuthorizationHeader);
SB_PHP_FUNCTION(SBHTTPAuth, ValidateSecPacks);
SB_PHP_FUNCTION(SBHTTPAuth, InitAuthLib);
void Register_SBHTTPAuth_Constants(int module_number TSRMLS_DC);
void Register_SBHTTPAuth_Enum_Flags(TSRMLS_D);
#ifdef SB_WINDOWS
void Register_SBHTTPAuth_Aliases(TSRMLS_D);
#endif

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_HTTPAUTH
SB_IMPORT uint32_t SB_APIENTRY SBHTTPAuth_AuthInit(PAUTH_SEQ pAS);
SB_IMPORT uint32_t SB_APIENTRY SBHTTPAuth_AuthTerm(PAUTH_SEQ pAS);
SB_IMPORT uint32_t SB_APIENTRY SBHTTPAuth_AuthConverse(PAUTH_SEQ pAS, const uint8_t pBuffIn[], int32_t szBuffIn, uint8_t pBuffOut[], int32_t * szBuffOut, int8_t * NeedMoreData, const char * pcPackage, int32_t szPackage, const char * pcUsername, int32_t szUsername, const char * pcPassword, int32_t szPassword, TSBUsernameOptionRaw UsernameOption, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHTTPAuth_AddAuthorizationHeader(char * pcStr, int32_t * szStr, const char * pcScheme, int32_t szScheme, const char * pcAuthData, int32_t szAuthData, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword, int8_t * NeedMoreData, int8_t ForProxy, PAUTH_SEQ aSeq, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBHTTPAuth_ValidateSecPacks(TElStringListHandle ls);
SB_IMPORT uint32_t SB_APIENTRY SBHTTPAuth_InitAuthLib(void);
#endif /* SB_USE_GLOBAL_PROCS_HTTPAUTH */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBHTTPAUTH */
