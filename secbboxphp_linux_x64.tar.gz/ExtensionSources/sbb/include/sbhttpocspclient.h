#ifndef __INC_SBHTTPOCSPCLIENT
#define __INC_SBHTTPOCSPCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbx509.h"
#include "sbx509ext.h"
#include "sbcrl.h"
#include "sbpkcs7.h"
#include "sbmessages.h"
#include "sbpkicommon.h"
#include "sbocspcommon.h"
#include "sbocspclient.h"
#include "sbhttpsclient.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElHTTPOCSPClientHandle;

typedef TElHTTPOCSPClientHandle ElHTTPOCSPClientHandle;

typedef TElClassHandle TElHTTPOCSPClientFactoryHandle;

#ifdef SB_USE_CLASS_TELHTTPOCSPCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOCSPClient_SupportsLocation(TElHTTPOCSPClientHandle _Handle, const char * pcURI, int32_t szURI, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOCSPClient_PerformRequest(TElHTTPOCSPClientHandle _Handle, TElOCSPServerErrorRaw * ServerResult, uint8_t pReply[], int32_t * szReply, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOCSPClient_get_HTTPClient(TElHTTPOCSPClientHandle _Handle, TElHTTPSClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOCSPClient_set_HTTPClient(TElHTTPOCSPClientHandle _Handle, TElHTTPSClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOCSPClient_Create(TComponentHandle Owner, TElOCSPClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPOCSPCLIENT */

#ifdef SB_USE_CLASS_TELHTTPOCSPCLIENTFACTORY
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOCSPClientFactory_SupportsLocation(TElHTTPOCSPClientFactoryHandle _Handle, const char * pcURI, int32_t szURI, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOCSPClientFactory_GetClientInstance(TElHTTPOCSPClientFactoryHandle _Handle, TObjectHandle Validator, TElOCSPClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOCSPClientFactory_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPOCSPCLIENTFACTORY */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElHTTPOCSPClient_ce_ptr;
extern zend_class_entry *TElHTTPOCSPClientFactory_ce_ptr;

void Register_TElHTTPOCSPClient(TSRMLS_D);
void Register_TElHTTPOCSPClientFactory(TSRMLS_D);
SB_PHP_FUNCTION(SBHTTPOCSPClient, RegisterHTTPOCSPClientFactory);
SB_PHP_FUNCTION(SBHTTPOCSPClient, UnregisterHTTPOCSPClientFactory);
void Register_SBHTTPOCSPClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_HTTPOCSPCLIENT
SB_IMPORT uint32_t SB_APIENTRY SBHTTPOCSPClient_RegisterHTTPOCSPClientFactory(void);
SB_IMPORT uint32_t SB_APIENTRY SBHTTPOCSPClient_UnregisterHTTPOCSPClientFactory(void);
#endif /* SB_USE_GLOBAL_PROCS_HTTPOCSPCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBHTTPOCSPCLIENT */

