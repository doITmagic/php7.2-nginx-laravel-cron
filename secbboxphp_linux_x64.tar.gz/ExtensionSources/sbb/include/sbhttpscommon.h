#ifndef __INC_SBHTTPSCOMMON
#define __INC_SBHTTPSCOMMON

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcrc.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbstrutils.h"
#include "sbstringlist.h"
#include "sbstreams.h"
#include "sbhttpsconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SCannotParseGZHeader 	"Invalid GZIP header."
#define SB_SCannotInflateCompressedData 	"Cannot inflate compressed data."
#define SB_ERROR_FACILITY_HTTP 	98304
#define SB_ERROR_HTTP_PROTOCOL_ERROR_FLAG 	2048
#define SB_HTTP_ERROR_CONNECT_FAILED 	100353
#define SB_HTTP_ERROR_REQUEST_NOT_COMPLETED 	100354
#define SB_HTTP_ERROR_INVALID_PROTOCOL_IN_URI 	100355
#define SB_HTTP_ERROR_DATETIME_PARSING_ERROR 	100356
#define SB_HTTP_ERROR_COMPRESSION_ERROR 	100357
#define SB_HTTP_ERROR_AUTH_FAILURE 	100358
#define SB_HTTP_ERROR_CANT_PARSE_RESPONSE 	100359
#define SB_HTTP_ERROR_CANT_PARSE_REQUEST 	100360
#define SB_HTTP_ERROR_UNKNOWN_TRANSFER_ENCODING 	100361
#define SB_HTTP_ERROR_TRANSFER_DECODING 	100362
#define SB_HTTP_ERROR_CONNECT_LOST_UNEXPECTEDLY 	100363
#define SB_HEAD_CRC 	2
#define SB_EXTRA_FIELD 	4
#define SB_ORIG_NAME 	8
#define SB_COMMENT 	16
#define SB_RESERVED 	224

typedef TElClassHandle TElHTTPSClientParamsHandle;

typedef TElClassHandle TElCustomSAMLAdapterHandle;

typedef TElClassHandle TElHTTPRangesHandle;

typedef TElClassHandle TElHTTPParamsHandle;

typedef TElHTTPParamsHandle ElHTTPParamsHandle;

typedef TElClassHandle TElHTTPCustomRequestParamsHandle;

typedef TElHTTPCustomRequestParamsHandle ElHTTPCustomRequestParamsHandle;

typedef TElClassHandle TElHTTPMultipartPartHandle;

typedef TElClassHandle TElHTTPMultipartListHandle;

typedef TElClassHandle TElHTTPEncodingProcessorHandle;

typedef TElClassHandle TElHTTPChunkedProcessorHandle;

typedef TElClassHandle TElHTTPCompressedProcessorHandle;

typedef TElClassHandle TElHTTPUtilsHandle;

typedef uint8_t TGZHeaderSkippedRaw;

typedef enum
{
	gzNone = 0,
	gzMagic = 1,
	gzMethod = 2,
	gzFlags = 3,
	gzTimeXFlagsOSCode = 4,
	gzExtra = 5,
	gzFileName = 6,
	gzFileComment = 7,
	gzCRC = 8,
	gzAll = 9
} TGZHeaderSkipped;

typedef uint8_t SBHTTPSCommon_TSBHTTPChunkStateRaw;

typedef enum
{
	_chSize = 0,
	_chLineFeed = 1,
	_chData = 2,
	_chHeader = 3
} SBHTTPSCommon_TSBHTTPChunkState;

typedef uint8_t TSBHTTPMethodRaw;

typedef enum
{
	hmGet = 0,
	hmPost = 1,
	hmHead = 2,
	hmOptions = 3,
	hmDelete = 4,
	hmTrace = 5,
	hmPut = 6,
	hmConnect = 7,
	hmCustom = 8
} TSBHTTPMethod;

typedef uint8_t TSBHTTPMultipartModeRaw;

typedef enum
{
	hmpFormData = 0,
	hmpRelated = 1,
	hmpCustom = 2
} TSBHTTPMultipartMode;

typedef void (SB_CALLBACK *TSBHTTPHeadersEvent)(void * _ObjectData, TObjectHandle Sender, TElStringListHandle Headers);

#ifdef SB_USE_CLASS_TELHTTPSCLIENTPARAMS
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_get_DoReconnect(TElHTTPSClientParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_set_DoReconnect(TElHTTPSClientParamsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_get_IntoDataRedirection(TElHTTPSClientParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_set_IntoDataRedirection(TElHTTPSClientParamsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_get_RelocationURL(TElHTTPSClientParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_set_RelocationURL(TElHTTPSClientParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_get_RequestMethod(TElHTTPSClientParamsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_set_RequestMethod(TElHTTPSClientParamsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_get_ContentLength(TElHTTPSClientParamsHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_set_ContentLength(TElHTTPSClientParamsHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_get_ContentType(TElHTTPSClientParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_set_ContentType(TElHTTPSClientParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_get_SentStreams(TElHTTPSClientParamsHandle _Handle, TSBObjectListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_set_SentStreams(TElHTTPSClientParamsHandle _Handle, TSBObjectListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_get_DataStreams(TElHTTPSClientParamsHandle _Handle, TSBObjectListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_set_DataStreams(TElHTTPSClientParamsHandle _Handle, TSBObjectListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_get_AllowRedirection(TElHTTPSClientParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_set_AllowRedirection(TElHTTPSClientParamsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_get_NewURL(TElHTTPSClientParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_set_NewURL(TElHTTPSClientParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_get_ServerStatusCode(TElHTTPSClientParamsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_set_ServerStatusCode(TElHTTPSClientParamsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_get_URL(TElHTTPSClientParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_set_URL(TElHTTPSClientParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSClientParams_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPSCLIENTPARAMS */

#ifdef SB_USE_CLASS_TELCUSTOMSAMLADAPTER
SB_IMPORT uint32_t SB_APIENTRY TElCustomSAMLAdapter_HandleDocumentEnd(TElCustomSAMLAdapterHandle _Handle, TElHTTPSClientParamsHandle Param);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSAMLAdapter_HandlePerformExchange(TElCustomSAMLAdapterHandle _Handle, TElHTTPSClientParamsHandle Param);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSAMLAdapter_HandleRedirection(TElCustomSAMLAdapterHandle _Handle, TElHTTPSClientParamsHandle Param);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSAMLAdapter_HandleReadyData(TElCustomSAMLAdapterHandle _Handle, const uint8_t pBuf[], int32_t szBuf);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSAMLAdapter_Reset(TElCustomSAMLAdapterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSAMLAdapter_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMSAMLADAPTER */

#ifdef SB_USE_CLASS_TELHTTPRANGES
SB_IMPORT uint32_t SB_APIENTRY TElHTTPRanges_Assign(TElHTTPRangesHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPRanges_Clone(TElHTTPRangesHandle _Handle, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPRanges_get_RangeCount(TElHTTPRangesHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPRanges_set_RangeCount(TElHTTPRangesHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPRanges_get_RangeEnd(TElHTTPRangesHandle _Handle, int32_t Index, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPRanges_set_RangeEnd(TElHTTPRangesHandle _Handle, int32_t Index, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPRanges_get_RangeStart(TElHTTPRangesHandle _Handle, int32_t Index, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPRanges_set_RangeStart(TElHTTPRangesHandle _Handle, int32_t Index, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPRanges_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPRANGES */

#ifdef SB_USE_CLASS_TELHTTPPARAMS
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_Assign(TElHTTPParamsHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_Clone(TElHTTPParamsHandle _Handle, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_get_ContentLength(TElHTTPParamsHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_set_ContentLength(TElHTTPParamsHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_get_ContentRangeStart(TElHTTPParamsHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_set_ContentRangeStart(TElHTTPParamsHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_get_ContentRangeEnd(TElHTTPParamsHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_set_ContentRangeEnd(TElHTTPParamsHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_get_ContentRangeFullSize(TElHTTPParamsHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_set_ContentRangeFullSize(TElHTTPParamsHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_get_ContentType(TElHTTPParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_set_ContentType(TElHTTPParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_get_Cookies(TElHTTPParamsHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_get_CustomHeaders(TElHTTPParamsHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_get_Date(TElHTTPParamsHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_set_Date(TElHTTPParamsHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPParams_Create(TElHTTPParamsHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPPARAMS */

#ifdef SB_USE_CLASS_TELHTTPCUSTOMREQUESTPARAMS
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_Assign(TElHTTPCustomRequestParamsHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_Clone(TElHTTPCustomRequestParamsHandle _Handle, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_Accept(TElHTTPCustomRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_Accept(TElHTTPCustomRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_AcceptCharset(TElHTTPCustomRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_AcceptCharset(TElHTTPCustomRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_AcceptLanguage(TElHTTPCustomRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_AcceptLanguage(TElHTTPCustomRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_AcceptRanges(TElHTTPCustomRequestParamsHandle _Handle, TElHTTPRangesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_Authorization(TElHTTPCustomRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_Authorization(TElHTTPCustomRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_Connection(TElHTTPCustomRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_Connection(TElHTTPCustomRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_IfMatch(TElHTTPCustomRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_IfMatch(TElHTTPCustomRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_IfModifiedSince(TElHTTPCustomRequestParamsHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_IfModifiedSince(TElHTTPCustomRequestParamsHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_IfNoneMatch(TElHTTPCustomRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_IfNoneMatch(TElHTTPCustomRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_IfUnmodifiedSince(TElHTTPCustomRequestParamsHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_IfUnmodifiedSince(TElHTTPCustomRequestParamsHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_From(TElHTTPCustomRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_From(TElHTTPCustomRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_Username(TElHTTPCustomRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_Username(TElHTTPCustomRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_Password(TElHTTPCustomRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_Password(TElHTTPCustomRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_Referer(TElHTTPCustomRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_Referer(TElHTTPCustomRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_UserAgent(TElHTTPCustomRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_UserAgent(TElHTTPCustomRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_get_Host(TElHTTPCustomRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_set_Host(TElHTTPCustomRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomRequestParams_Create(TElHTTPCustomRequestParamsHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPCUSTOMREQUESTPARAMS */

#ifdef SB_USE_CLASS_TELHTTPMULTIPARTPART
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_get_ContentType(TElHTTPMultipartPartHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_set_ContentType(TElHTTPMultipartPartHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_get_ContentTransferEncoding(TElHTTPMultipartPartHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_set_ContentTransferEncoding(TElHTTPMultipartPartHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_get_CustomHeaders(TElHTTPMultipartPartHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_get_Stream(TElHTTPMultipartPartHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_set_Stream(TElHTTPMultipartPartHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_get_CloseStream(TElHTTPMultipartPartHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_set_CloseStream(TElHTTPMultipartPartHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_get_FieldName(TElHTTPMultipartPartHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_set_FieldName(TElHTTPMultipartPartHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_get_FieldValue(TElHTTPMultipartPartHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_set_FieldValue(TElHTTPMultipartPartHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_get_Filename(TElHTTPMultipartPartHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_set_Filename(TElHTTPMultipartPartHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_get_ContentID(TElHTTPMultipartPartHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_set_ContentID(TElHTTPMultipartPartHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_get_ContentDescription(TElHTTPMultipartPartHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_set_ContentDescription(TElHTTPMultipartPartHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_get_ContentDisposition(TElHTTPMultipartPartHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_set_ContentDisposition(TElHTTPMultipartPartHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartPart_Create(TElHTTPMultipartPartHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPMULTIPARTPART */

#ifdef SB_USE_CLASS_TELHTTPMULTIPARTLIST
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartList_AddFormField(TElHTTPMultipartListHandle _Handle, const char * pcFieldName, int32_t szFieldName, const char * pcFieldValue, int32_t szFieldValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartList_AddFormFile(TElHTTPMultipartListHandle _Handle, const char * pcFieldName, int32_t szFieldName, const char * pcFilename, int32_t szFilename, const char * pcContentType, int32_t szContentType, TStreamHandle FileStream, int8_t CloseStream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartList_AddContentStream(TElHTTPMultipartListHandle _Handle, const char * pcContentID, int32_t szContentID, const char * pcContentType, int32_t szContentType, TStreamHandle AStream, int8_t CloseStream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartList_Add(TElHTTPMultipartListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartList_Add_1(TElHTTPMultipartListHandle _Handle, TElHTTPMultipartPartHandle APart, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartList_Insert(TElHTTPMultipartListHandle _Handle, int32_t Index, TElHTTPMultipartPartHandle APart);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartList_Delete(TElHTTPMultipartListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartList_Clear(TElHTTPMultipartListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartList_get_Count(TElHTTPMultipartListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartList_get_Parts(TElHTTPMultipartListHandle _Handle, int32_t Index, TElHTTPMultipartPartHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMultipartList_Create(TElHTTPMultipartListHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPMULTIPARTLIST */

#ifdef SB_USE_CLASS_TELHTTPENCODINGPROCESSOR
SB_IMPORT uint32_t SB_APIENTRY TElHTTPEncodingProcessor_Initialize(TElHTTPEncodingProcessorHandle _Handle, int8_t AsEncoder);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPEncodingProcessor_DecodeData(TElHTTPEncodingProcessorHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Position, int32_t Size, int32_t * Processed, int8_t * EndReached, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPEncodingProcessor_EncodeData(TElHTTPEncodingProcessorHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Position, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPEncodingProcessor_get_BytesEncoded(TElHTTPEncodingProcessorHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPEncodingProcessor_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPENCODINGPROCESSOR */

#ifdef SB_USE_CLASS_TELHTTPCHUNKEDPROCESSOR
SB_IMPORT uint32_t SB_APIENTRY TElHTTPChunkedProcessor_Initialize(TElHTTPChunkedProcessorHandle _Handle, int8_t AsEncoder);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPChunkedProcessor_DecodeData(TElHTTPChunkedProcessorHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Position, int32_t Size, int32_t * Processed, int8_t * EndReached, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPChunkedProcessor_EncodeData(TElHTTPChunkedProcessorHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Position, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPChunkedProcessor_EncodeLastData(TElHTTPChunkedProcessorHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Position, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPChunkedProcessor_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPCHUNKEDPROCESSOR */

#ifdef SB_USE_CLASS_TELHTTPCOMPRESSEDPROCESSOR
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCompressedProcessor_Initialize(TElHTTPCompressedProcessorHandle _Handle, int8_t AsEncoder);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCompressedProcessor_Reset(TElHTTPCompressedProcessorHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCompressedProcessor_DecodeData(TElHTTPCompressedProcessorHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Position, int32_t Size, int32_t * Processed, int8_t * EndReached, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCompressedProcessor_EncodeData(TElHTTPCompressedProcessorHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Position, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCompressedProcessor_get_Deflated(TElHTTPCompressedProcessorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCompressedProcessor_set_Deflated(TElHTTPCompressedProcessorHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCompressedProcessor_get_Gzipped(TElHTTPCompressedProcessorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCompressedProcessor_set_Gzipped(TElHTTPCompressedProcessorHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCompressedProcessor_get_CompressionLevel(TElHTTPCompressedProcessorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCompressedProcessor_set_CompressionLevel(TElHTTPCompressedProcessorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCompressedProcessor_Create(TElHTTPCompressedProcessorHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPCOMPRESSEDPROCESSOR */

#ifdef SB_USE_CLASS_TELHTTPUTILS
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_DateTimeToHTTPTime(int64_t D, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_DateTimeToHTTPTime_1(TElHTTPUtilsHandle _Handle, int64_t D, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_HTTPTimeToDateTime(const char * pcS, int32_t szS, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_HTTPTimeToDateTime_1(TElHTTPUtilsHandle _Handle, const char * pcS, int32_t szS, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_SetHeaderByName(TElStringListHandle Headers, const char * pcName, int32_t szName, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_SetHeaderByName_1(TElHTTPUtilsHandle _Handle, TElStringListHandle Headers, const char * pcName, int32_t szName, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_GetHeaderByName(TElStringListHandle Headers, const char * pcName, int32_t szName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_GetHeaderByName_1(TElHTTPUtilsHandle _Handle, TElStringListHandle Headers, const char * pcName, int32_t szName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_GetHeadersByName(TElStringListHandle Headers, const char * pcName, int32_t szName, TElStringListHandle Res);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_GetHeadersByName_1(TElHTTPUtilsHandle _Handle, TElStringListHandle Headers, const char * pcName, int32_t szName, TElStringListHandle Res);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_MergeHeaders(TElStringListHandle Source, TElStringListHandle Target);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_MergeHeaders_1(TElHTTPUtilsHandle _Handle, TElStringListHandle Source, TElStringListHandle Target);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_ParseHTTPParameters(const char * pcS, int32_t szS, TElStringListHandle Output);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_ParseHTTPParameters_1(TElHTTPUtilsHandle _Handle, const char * pcS, int32_t szS, TElStringListHandle Output);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_RemoveURLParams(const char * pcURL, int32_t szURL, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_RemoveURLParams_1(TElHTTPUtilsHandle _Handle, const char * pcURL, int32_t szURL, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_ExtractURLParams(const char * pcURL, int32_t szURL, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_ExtractURLParams_1(TElHTTPUtilsHandle _Handle, const char * pcURL, int32_t szURL, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_URLConcat(const char * pcURL, int32_t szURL, const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_URLConcat_1(TElHTTPUtilsHandle _Handle, const char * pcURL, int32_t szURL, const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPUtils_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPUTILS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElHTTPSClientParams_ce_ptr;
extern zend_class_entry *TElCustomSAMLAdapter_ce_ptr;
extern zend_class_entry *TElHTTPRanges_ce_ptr;
extern zend_class_entry *TElHTTPParams_ce_ptr;
extern zend_class_entry *TElHTTPCustomRequestParams_ce_ptr;
extern zend_class_entry *TElHTTPMultipartPart_ce_ptr;
extern zend_class_entry *TElHTTPMultipartList_ce_ptr;
extern zend_class_entry *TElHTTPEncodingProcessor_ce_ptr;
extern zend_class_entry *TElHTTPChunkedProcessor_ce_ptr;
extern zend_class_entry *TElHTTPCompressedProcessor_ce_ptr;
extern zend_class_entry *TElHTTPUtils_ce_ptr;

void SB_CALLBACK TSBHTTPHeadersEventRaw(void * _ObjectData, TObjectHandle Sender, TElStringListHandle Headers);
void Register_TElHTTPSClientParams(TSRMLS_D);
void Register_TElCustomSAMLAdapter(TSRMLS_D);
void Register_TElHTTPRanges(TSRMLS_D);
void Register_TElHTTPParams(TSRMLS_D);
void Register_TElHTTPCustomRequestParams(TSRMLS_D);
void Register_TElHTTPMultipartPart(TSRMLS_D);
void Register_TElHTTPMultipartList(TSRMLS_D);
void Register_TElHTTPEncodingProcessor(TSRMLS_D);
void Register_TElHTTPChunkedProcessor(TSRMLS_D);
void Register_TElHTTPCompressedProcessor(TSRMLS_D);
void Register_TElHTTPUtils(TSRMLS_D);
SB_PHP_FUNCTION(SBHTTPSCommon, HTTPHeaderGetDelimiter);
void Register_SBHTTPSCommon_Constants(int module_number TSRMLS_DC);
void Register_SBHTTPSCommon_Enum_Flags(TSRMLS_D);
void Register_SBHTTPSCommon_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_HTTPSCOMMON
SB_IMPORT uint32_t SB_APIENTRY SBHTTPSCommon_HTTPHeaderGetDelimiter(const uint8_t pHeader[], int32_t szHeader, int32_t Index, int32_t Length, uint8_t pDelimiter[], int32_t * szDelimiter, int32_t * EndHeaderIndex, int8_t * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_HTTPSCOMMON */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBHTTPSCOMMON */

