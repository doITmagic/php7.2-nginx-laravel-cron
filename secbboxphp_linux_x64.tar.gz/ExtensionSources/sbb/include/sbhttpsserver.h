#ifndef __INC_SBHTTPSSERVER
#define __INC_SBHTTPSSERVER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcustomcertstorage.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbrandom.h"
#include "sbencoding.h"
#include "sbx509.h"
#include "sbstringlist.h"
#include "sbconstants.h"
#include "sbsslcommon.h"
#include "sbsslserver.h"
#include "sbsessionpool.h"
#include "sbsslconstants.h"
#include "sbstreams.h"
#ifdef SB_WINDOWS
#include "sbhttpauth.h"
#endif
#include "sbwebsocketcommon.h"
#include "sbwebsocketserver.h"
#include "sbsrp.h"
#include "sbhttpsconstants.h"
#include "sbhashfunction.h"
#include "sbhttpscommon.h"
#include "sbsharedresource.h"
#include "sboauth2.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElHTTPSessionHandle;

typedef TElClassHandle TElHTTPServerRequestParamsHandle;

typedef TElHTTPServerRequestParamsHandle ElHTTPServerRequestParamsHandle;

typedef TElClassHandle TElHTTPOAuth2ApplicationInfoHandle;

typedef TElClassHandle TElHTTPOAuth2CustomApplicationStorageHandle;

typedef TElClassHandle TElHTTPOAuth2MemoryApplicationStorageHandle;

typedef TElClassHandle TElHTTPCustomSessionManagerHandle;

typedef TElClassHandle TElHTTPMemorySessionManagerHandle;

typedef TElClassHandle TElHTTPServerResponseParamsHandle;

typedef TElHTTPServerResponseParamsHandle ElHTTPServerResponseParamsHandle;

typedef TElClassHandle TElMultipartFormDataHandle;

typedef TElMultipartFormDataHandle ElMultipartFormDataHandle;

typedef TElClassHandle TElMultipartFormListHandle;

typedef TElMultipartFormListHandle ElMultipartFormListHandle;

typedef TElClassHandle TElHTTPSServerHandle;

typedef TElHTTPSServerHandle ElHTTPSServerHandle;

typedef TElClassHandle TElDigestAuthHandle;

typedef uint8_t TSBHTTPServerConnStageRaw;

typedef enum
{
	csHeader = 0,
	csBody = 1,
	csTunnel = 2
} TSBHTTPServerConnStage;

typedef uint8_t TSBOAUTH2ErrorReportTypeRaw;

typedef enum
{
	oerNone = 0,
	oerParam = 1,
	oerFragment = 2
} TSBOAUTH2ErrorReportType;

typedef void (SB_CALLBACK *TSBHTTPRequestHeadersEvent)(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle RequestInfo, int8_t * Accepted);

typedef void (SB_CALLBACK *TSBHTTPAfterAuthorizationEvent)(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle RequestInfo, int8_t * Accepted);

typedef void (SB_CALLBACK *TSBHTTPRequestBodyEvent)(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle RequestInfo);

typedef void (SB_CALLBACK *TSBHTTPBeforeWebSocketServerUsedEvent)(void * _ObjectData, TObjectHandle Sender, TElWebSocketServerHandle WSServer);

typedef void (SB_CALLBACK *SBHTTPSServer_TSBHTTPWebSocketConnectionEstablishedEvent)(void * _ObjectData, TObjectHandle Sender, TElWebSocketServerHandle WSServer);

typedef void (SB_CALLBACK *TSBHTTPSessionCreateEvent)(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle RequestInfo, TElHTTPSessionHandle Session, const char * pcCookie, int32_t szCookie);

typedef void (SB_CALLBACK *TSBHTTPSessionEvent)(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle RequestInfo, TElHTTPSessionHandle Session);

typedef void (SB_CALLBACK *TSBOnGetUserPasswordEvent)(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle ReqParams, char * pcPassword, int32_t * szPassword, int8_t * Accept);

typedef void (SB_CALLBACK *TSBOAuth2GrantTypeRequestedEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcID, int32_t szID, const char * pcScope, int32_t szScope, int8_t * Allow);

#ifdef SB_USE_CLASS_TELHTTPSESSION
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_Generate(TElHTTPSessionHandle _Handle, int32_t TTL);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_ResetOAuth2(TElHTTPSessionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_IsExpired(TElHTTPSessionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_IsAccessTokenExpired(TElHTTPSessionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_SessionID(TElHTTPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_SessionID(TElHTTPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_Username(TElHTTPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_Username(TElHTTPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_Expires(TElHTTPSessionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_Authenticated(TElHTTPSessionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_Authenticated(TElHTTPSessionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_OAuth2Authenticated(TElHTTPSessionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_OAuth2Authenticated(TElHTTPSessionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_RedirectURL(TElHTTPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_RedirectURL(TElHTTPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_Tag(TElHTTPSessionHandle _Handle, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_Tag(TElHTTPSessionHandle _Handle, TObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_OwnTag(TElHTTPSessionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_OwnTag(TElHTTPSessionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_AuthCode(TElHTTPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_AuthCode(TElHTTPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_AccessToken(TElHTTPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_AccessToken(TElHTTPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_RefreshToken(TElHTTPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_RefreshToken(TElHTTPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_TokenExpires(TElHTTPSessionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_TokenExpires(TElHTTPSessionHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_State(TElHTTPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_State(TElHTTPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_GrantType(TElHTTPSessionHandle _Handle, TSBOAuth2GrantTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_GrantType(TElHTTPSessionHandle _Handle, TSBOAuth2GrantTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_ConfirmPostfix(TElHTTPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_ConfirmPostfix(TElHTTPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_CSRFValue(TElHTTPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_CSRFValue(TElHTTPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_get_AuthAttempts(TElHTTPSessionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_set_AuthAttempts(TElHTTPSessionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSession_Create(TElHTTPSessionHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPSESSION */

#ifdef SB_USE_CLASS_TELHTTPSERVERREQUESTPARAMS
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_Assign(TElHTTPServerRequestParamsHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_Clone(TElHTTPServerRequestParamsHandle _Handle, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_IsAuthenticated(TElHTTPServerRequestParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_CustomMethod(TElHTTPServerRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_set_CustomMethod(TElHTTPServerRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_Expects100Continue(TElHTTPServerRequestParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_set_Expects100Continue(TElHTTPServerRequestParamsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_HTTPVersion(TElHTTPServerRequestParamsHandle _Handle, TSBHTTPVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_set_HTTPVersion(TElHTTPServerRequestParamsHandle _Handle, TSBHTTPVersionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_KeepAlive(TElHTTPServerRequestParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_set_KeepAlive(TElHTTPServerRequestParamsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_Method(TElHTTPServerRequestParamsHandle _Handle, TSBHTTPMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_set_Method(TElHTTPServerRequestParamsHandle _Handle, TSBHTTPMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_URL(TElHTTPServerRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_set_URL(TElHTTPServerRequestParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_Chunked(TElHTTPServerRequestParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_PreferGzip(TElHTTPServerRequestParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_AcceptGZip(TElHTTPServerRequestParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_AcceptDeflate(TElHTTPServerRequestParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_AcceptChunked(TElHTTPServerRequestParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_AcceptIdentity(TElHTTPServerRequestParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_AuthMethod(TElHTTPServerRequestParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_RequireAuth(TElHTTPServerRequestParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_set_RequireAuth(TElHTTPServerRequestParamsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_WebSocketRequest(TElHTTPServerRequestParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_Session(TElHTTPServerRequestParamsHandle _Handle, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_set_Session(TElHTTPServerRequestParamsHandle _Handle, TElHTTPSessionHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_RequireOAuth2(TElHTTPServerRequestParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_set_RequireOAuth2(TElHTTPServerRequestParamsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_get_SkipAuth(TElHTTPServerRequestParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_set_SkipAuth(TElHTTPServerRequestParamsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerRequestParams_Create(TElHTTPServerRequestParamsHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPSERVERREQUESTPARAMS */

#ifdef SB_USE_CLASS_TELHTTPOAUTH2APPLICATIONINFO
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2ApplicationInfo_Generate(TElHTTPOAuth2ApplicationInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2ApplicationInfo_Generate_1(TElHTTPOAuth2ApplicationInfoHandle _Handle, int32_t IDLen, int32_t SecretLen);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2ApplicationInfo_get_ClientID(TElHTTPOAuth2ApplicationInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2ApplicationInfo_set_ClientID(TElHTTPOAuth2ApplicationInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2ApplicationInfo_get_ClientSecret(TElHTTPOAuth2ApplicationInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2ApplicationInfo_set_ClientSecret(TElHTTPOAuth2ApplicationInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2ApplicationInfo_get_Name(TElHTTPOAuth2ApplicationInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2ApplicationInfo_set_Name(TElHTTPOAuth2ApplicationInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2ApplicationInfo_get_RedirectURI(TElHTTPOAuth2ApplicationInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2ApplicationInfo_set_RedirectURI(TElHTTPOAuth2ApplicationInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2ApplicationInfo_get_Scopes(TElHTTPOAuth2ApplicationInfoHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2ApplicationInfo_Create(TElHTTPOAuth2ApplicationInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2ApplicationInfo_Create_1(const char * pcName, int32_t szName, const char * pcRedirectURI, int32_t szRedirectURI, TElHTTPOAuth2ApplicationInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPOAUTH2APPLICATIONINFO */

#ifdef SB_USE_CLASS_TELHTTPOAUTH2CUSTOMAPPLICATIONSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2CustomApplicationStorage_Lock(TElHTTPOAuth2CustomApplicationStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2CustomApplicationStorage_Unlock(TElHTTPOAuth2CustomApplicationStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2CustomApplicationStorage_Clear(TElHTTPOAuth2CustomApplicationStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2CustomApplicationStorage_Add(TElHTTPOAuth2CustomApplicationStorageHandle _Handle, TElHTTPOAuth2ApplicationInfoHandle Info, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2CustomApplicationStorage_Remove(TElHTTPOAuth2CustomApplicationStorageHandle _Handle, int32_t Index, TElHTTPOAuth2ApplicationInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2CustomApplicationStorage_Find(TElHTTPOAuth2CustomApplicationStorageHandle _Handle, const char * pcClientID, int32_t szClientID, TElHTTPOAuth2ApplicationInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2CustomApplicationStorage_get_Count(TElHTTPOAuth2CustomApplicationStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2CustomApplicationStorage_get_Applications(TElHTTPOAuth2CustomApplicationStorageHandle _Handle, int32_t Index, TElHTTPOAuth2ApplicationInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2CustomApplicationStorage_Create(TElHTTPOAuth2CustomApplicationStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPOAUTH2CUSTOMAPPLICATIONSTORAGE */

#ifdef SB_USE_CLASS_TELHTTPOAUTH2MEMORYAPPLICATIONSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2MemoryApplicationStorage_Lock(TElHTTPOAuth2MemoryApplicationStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2MemoryApplicationStorage_Unlock(TElHTTPOAuth2MemoryApplicationStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2MemoryApplicationStorage_Clear(TElHTTPOAuth2MemoryApplicationStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2MemoryApplicationStorage_Add(TElHTTPOAuth2MemoryApplicationStorageHandle _Handle, TElHTTPOAuth2ApplicationInfoHandle Info, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2MemoryApplicationStorage_Remove(TElHTTPOAuth2MemoryApplicationStorageHandle _Handle, int32_t Index, TElHTTPOAuth2ApplicationInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2MemoryApplicationStorage_Find(TElHTTPOAuth2MemoryApplicationStorageHandle _Handle, const char * pcClientID, int32_t szClientID, TElHTTPOAuth2ApplicationInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPOAuth2MemoryApplicationStorage_Create(TElHTTPOAuth2MemoryApplicationStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPOAUTH2MEMORYAPPLICATIONSTORAGE */

#ifdef SB_USE_CLASS_TELHTTPCUSTOMSESSIONMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomSessionManager_Lock(TElHTTPCustomSessionManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomSessionManager_Unlock(TElHTTPCustomSessionManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomSessionManager_Clear(TElHTTPCustomSessionManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomSessionManager_Add(TElHTTPCustomSessionManagerHandle _Handle, TElHTTPSessionHandle Session, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomSessionManager_Remove(TElHTTPCustomSessionManagerHandle _Handle, int32_t Index, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomSessionManager_Remove_1(TElHTTPCustomSessionManagerHandle _Handle, const char * pcSessionID, int32_t szSessionID, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomSessionManager_Remove_2(TElHTTPCustomSessionManagerHandle _Handle, TElHTTPSessionHandle Session, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomSessionManager_FindBySessionID(TElHTTPCustomSessionManagerHandle _Handle, const char * pcSessionID, int32_t szSessionID, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomSessionManager_FindByAuthCode(TElHTTPCustomSessionManagerHandle _Handle, const char * pcAuthCode, int32_t szAuthCode, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomSessionManager_FindByAccessToken(TElHTTPCustomSessionManagerHandle _Handle, const char * pcToken, int32_t szToken, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomSessionManager_FindByRefreshToken(TElHTTPCustomSessionManagerHandle _Handle, const char * pcToken, int32_t szToken, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomSessionManager_get_Count(TElHTTPCustomSessionManagerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomSessionManager_get_Sessions(TElHTTPCustomSessionManagerHandle _Handle, int32_t Index, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPCustomSessionManager_Create(TElHTTPCustomSessionManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPCUSTOMSESSIONMANAGER */

#ifdef SB_USE_CLASS_TELHTTPMEMORYSESSIONMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMemorySessionManager_Lock(TElHTTPMemorySessionManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMemorySessionManager_Unlock(TElHTTPMemorySessionManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMemorySessionManager_Clear(TElHTTPMemorySessionManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMemorySessionManager_Add(TElHTTPMemorySessionManagerHandle _Handle, TElHTTPSessionHandle Session, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMemorySessionManager_Remove(TElHTTPMemorySessionManagerHandle _Handle, int32_t Index, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMemorySessionManager_Remove_1(TElHTTPMemorySessionManagerHandle _Handle, TElHTTPSessionHandle Session, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMemorySessionManager_Remove_2(TElHTTPMemorySessionManagerHandle _Handle, const char * pcSessionID, int32_t szSessionID, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMemorySessionManager_FindBySessionID(TElHTTPMemorySessionManagerHandle _Handle, const char * pcSessionID, int32_t szSessionID, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMemorySessionManager_FindByAuthCode(TElHTTPMemorySessionManagerHandle _Handle, const char * pcAuthCode, int32_t szAuthCode, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMemorySessionManager_FindByAccessToken(TElHTTPMemorySessionManagerHandle _Handle, const char * pcToken, int32_t szToken, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMemorySessionManager_FindByRefreshToken(TElHTTPMemorySessionManagerHandle _Handle, const char * pcToken, int32_t szToken, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPMemorySessionManager_Create(TElHTTPMemorySessionManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPMEMORYSESSIONMANAGER */

#ifdef SB_USE_CLASS_TELHTTPSERVERRESPONSEPARAMS
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_Assign(TElHTTPServerResponseParamsHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_Clone(TElHTTPServerResponseParamsHandle _Handle, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_get_AcceptRanges(TElHTTPServerResponseParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_set_AcceptRanges(TElHTTPServerResponseParamsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_get_Location(TElHTTPServerResponseParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_set_Location(TElHTTPServerResponseParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_get_StatusCode(TElHTTPServerResponseParamsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_set_StatusCode(TElHTTPServerResponseParamsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_get_Expires(TElHTTPServerResponseParamsHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_set_Expires(TElHTTPServerResponseParamsHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_get_LastModified(TElHTTPServerResponseParamsHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_set_LastModified(TElHTTPServerResponseParamsHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_get_ReasonPhrase(TElHTTPServerResponseParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_set_ReasonPhrase(TElHTTPServerResponseParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_get_Server(TElHTTPServerResponseParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_set_Server(TElHTTPServerResponseParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_get_UseChunkedTransfer(TElHTTPServerResponseParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_set_UseChunkedTransfer(TElHTTPServerResponseParamsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_get_UseCompression(TElHTTPServerResponseParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_set_UseCompression(TElHTTPServerResponseParamsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_get_CompressionLevel(TElHTTPServerResponseParamsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_set_CompressionLevel(TElHTTPServerResponseParamsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_get_UseKeepAlive(TElHTTPServerResponseParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_set_UseKeepAlive(TElHTTPServerResponseParamsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_get_WebSocketResponse(TElHTTPServerResponseParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_set_WebSocketResponse(TElHTTPServerResponseParamsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPServerResponseParams_Create(TElHTTPServerResponseParamsHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPSERVERRESPONSEPARAMS */

#ifdef SB_USE_CLASS_TELMULTIPARTFORMDATA
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormData_Parse(TElMultipartFormDataHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormData_ParseStream(TElMultipartFormDataHandle _Handle, TStreamHandle Stream, const char * pcBoundary, int32_t szBoundary);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormData_get_Headers(TElMultipartFormDataHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormData_get_Content(TElMultipartFormDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormData_get_ContentStartPos(TElMultipartFormDataHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormData_get_ContentSize(TElMultipartFormDataHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormData_get_IsMultipart(TElMultipartFormDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormData_get_Name(TElMultipartFormDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormData_get_FileName(TElMultipartFormDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormData_Create(TElMultipartFormDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELMULTIPARTFORMDATA */

#ifdef SB_USE_CLASS_TELMULTIPARTFORMLIST
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormList_Assign(TElMultipartFormListHandle _Handle, TElMultipartFormDataHandle Src);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormList_Parse(TElMultipartFormListHandle _Handle, const char * pcContentType, int32_t szContentType, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormList_Parse_1(TElMultipartFormDataHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormList_ParseStream(TElMultipartFormListHandle _Handle, const char * pcContentType, int32_t szContentType, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormList_ParseStream_1(TElMultipartFormDataHandle _Handle, TStreamHandle Stream, const char * pcBoundary, int32_t szBoundary);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormList_get_ValuesByName(TElMultipartFormListHandle _Handle, const char * pcName, int32_t szName, TElMultipartFormDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormList_get_ValuesByFileName(TElMultipartFormListHandle _Handle, const char * pcName, int32_t szName, TElMultipartFormDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormList_get_ValuesByIndex(TElMultipartFormListHandle _Handle, int32_t Idx, TElMultipartFormDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormList_get_Count(TElMultipartFormListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartFormList_Create(TElMultipartFormListHandle * OutResult);
#endif /* SB_USE_CLASS_TELMULTIPARTFORMLIST */

#ifdef SB_USE_CLASS_TELHTTPSSERVER
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_Open(TElHTTPSServerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_DataAvailable(TElHTTPSServerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_Send100Continue(TElHTTPSServerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_SendResponseHeaders(TElHTTPSServerHandle _Handle, TElHTTPServerRequestParamsHandle RequestParameters, TElHTTPServerResponseParamsHandle ResponseParameters);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_SendResponseData(TElHTTPSServerHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_SendResponseData_1(TElHTTPSServerHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_SendResponseData_2(TElHTTPSServerHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_SendResponseData_3(TElHTTPSServerHandle _Handle, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_ResponseComplete(TElHTTPSServerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_Close(TElHTTPSServerHandle _Handle, int8_t Silent);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_ParseMultipartFormData(TElHTTPSServerHandle _Handle, const char * pcContentType, int32_t szContentType, const uint8_t pBuffer[], int32_t szBuffer, TElMultipartFormListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_ParseMultipartFormData_1(TElHTTPSServerHandle _Handle, const char * pcContentType, int32_t szContentType, TStreamHandle Strm, TElMultipartFormListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_ParseMultipartFormData_2(TElHTTPSServerHandle _Handle, const char * pcContentType, int32_t szContentType, TStreamHandle Strm, int8_t LoadData, TElMultipartFormListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_GetControl(TElHTTPSServerHandle _Handle, TElSSLClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_AddCertTypeHandler(TElHTTPSServerHandle _Handle, TElSSLCertificateTypeHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_RemoveCertTypeHandler(TElHTTPSServerHandle _Handle, TElSSLCertificateTypeHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_GetCertTypeHandler(TElHTTPSServerHandle _Handle, TElSSLCertificateTypeRaw CertType, TElSSLCertificateTypeHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_AssignTLSParamsFromTemplate(TElHTTPSServerHandle _Handle, TElSSLServerHandle Tpl);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_ConfigureTLS(TElHTTPSServerHandle _Handle, TSBServerSSLPredefinedConfigurationRaw Configuration);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLCipherSuite(TElHTTPSServerHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLCipherSuites(TElHTTPSServerHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SSLCipherSuites(TElHTTPSServerHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLCipherSuitePriorities(TElHTTPSServerHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SSLCipherSuitePriorities(TElHTTPSServerHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLCompressionAlgorithms(TElHTTPSServerHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SSLCompressionAlgorithms(TElHTTPSServerHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLVersion(TElHTTPSServerHandle _Handle, TSBVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLCompressionAlgorithm(TElHTTPSServerHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLConnectionInfo(TElHTTPSServerHandle _Handle, TElSSLConnectionInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_Active(TElHTTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_AllowKeepAlive(TElHTTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_AllowKeepAlive(TElHTTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_AuthRealm(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_AuthRealm(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_AuthBasic(TElHTTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_AuthBasic(TElHTTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_AuthDigest(TElHTTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_AuthDigest(TElHTTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_AuthDigestExpire(TElHTTPSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_AuthDigestExpire(TElHTTPSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_CloseConnectionOnUnauthorizedData(TElHTTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_CloseConnectionOnUnauthorizedData(TElHTTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SendForbiddenAuto(TElHTTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SendForbiddenAuto(TElHTTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLMode(TElHTTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SSLMode(TElHTTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLClientAuthentication(TElHTTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SSLClientAuthentication(TElHTTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLAuthenticationLevel(TElHTTPSServerHandle _Handle, TSBAuthenticationLevelRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SSLAuthenticationLevel(TElHTTPSServerHandle _Handle, TSBAuthenticationLevelRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLForceCertificateChain(TElHTTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SSLForceCertificateChain(TElHTTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_CertStorage(TElHTTPSServerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_CertStorage(TElHTTPSServerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLSessionPool(TElHTTPSServerHandle _Handle, TElSessionPoolHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SSLSessionPool(TElHTTPSServerHandle _Handle, TElSessionPoolHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_ClientCertStorage(TElHTTPSServerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_ClientCertStorage(TElHTTPSServerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLVersions(TElHTTPSServerHandle _Handle, TSBVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SSLVersions(TElHTTPSServerHandle _Handle, TSBVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLExtensions(TElHTTPSServerHandle _Handle, TElServerSSLExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLPeerExtensions(TElHTTPSServerHandle _Handle, TElCustomSSLExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SSLOptions(TElHTTPSServerHandle _Handle, TSBSSLOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SSLOptions(TElHTTPSServerHandle _Handle, TSBSSLOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_RenegotiationAttackPreventionMode(TElHTTPSServerHandle _Handle, TSBRenegotiationAttackPreventionModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_RenegotiationAttackPreventionMode(TElHTTPSServerHandle _Handle, TSBRenegotiationAttackPreventionModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SRPCredentialStore(TElHTTPSServerHandle _Handle, TElSRPCredentialStoreHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SRPCredentialStore(TElHTTPSServerHandle _Handle, TElSRPCredentialStoreHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_AuthWebForm(TElHTTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_AuthWebForm(TElHTTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SessionManager(TElHTTPSServerHandle _Handle, TElHTTPCustomSessionManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SessionManager(TElHTTPSServerHandle _Handle, TElHTTPCustomSessionManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_LoginURL(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_LoginURL(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_LogoutURL(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_LogoutURL(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_AuthFormTemplate(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_AuthFormTemplate(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_LoginRequestSizeLimit(TElHTTPSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_LoginRequestSizeLimit(TElHTTPSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SessionTTL(TElHTTPSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SessionTTL(TElHTTPSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_TokenTTL(TElHTTPSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_TokenTTL(TElHTTPSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_SessionCookieName(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_SessionCookieName(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_CurrentSession(TElHTTPSServerHandle _Handle, TElHTTPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_AfterLogoutPage(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_AfterLogoutPage(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_UseCSRFAttacksProtection(TElHTTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_UseCSRFAttacksProtection(TElHTTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_CSRFFieldName(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_CSRFFieldName(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_AuthFormLoginFieldName(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_AuthFormLoginFieldName(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_AuthFormPasswordFieldName(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_AuthFormPasswordFieldName(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_MaxLoginAttempts(TElHTTPSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_MaxLoginAttempts(TElHTTPSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_UseOAuth2(TElHTTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_UseOAuth2(TElHTTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_ApplicationInfoStorage(TElHTTPSServerHandle _Handle, TElHTTPOAuth2CustomApplicationStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_ApplicationInfoStorage(TElHTTPSServerHandle _Handle, TElHTTPOAuth2CustomApplicationStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_AuthorizationURL(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_AuthorizationURL(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_TokenURL(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_TokenURL(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_ConfirmPageTemplate(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_ConfirmPageTemplate(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_AuthDenyURL(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_AuthDenyURL(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_AuthAllowURL(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_AuthAllowURL(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_AuthorizationDeniedPage(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_AuthorizationDeniedPage(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_TokenType(TElHTTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_TokenType(TElHTTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_TokenLength(TElHTTPSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_TokenLength(TElHTTPSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnGetSrpDb(TElHTTPSServerHandle _Handle, TSBServerSrpDbNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnGetSrpDb(TElHTTPSServerHandle _Handle, TSBServerSrpDbNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnSend(TElHTTPSServerHandle _Handle, TSBSendEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnSend(TElHTTPSServerHandle _Handle, TSBSendEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnReceive(TElHTTPSServerHandle _Handle, TSBReceiveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnReceive(TElHTTPSServerHandle _Handle, TSBReceiveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnData(TElHTTPSServerHandle _Handle, TSBDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnData(TElHTTPSServerHandle _Handle, TSBDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnOpenConnection(TElHTTPSServerHandle _Handle, TSBOpenConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnOpenConnection(TElHTTPSServerHandle _Handle, TSBOpenConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnCertificateValidate(TElHTTPSServerHandle _Handle, TSBCertificateValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnCertificateValidate(TElHTTPSServerHandle _Handle, TSBCertificateValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnCiphersNegotiated(TElHTTPSServerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnCiphersNegotiated(TElHTTPSServerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnSSLError(TElHTTPSServerHandle _Handle, TSBErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnSSLError(TElHTTPSServerHandle _Handle, TSBErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnExtensionsReceived(TElHTTPSServerHandle _Handle, TSBExtensionsReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnExtensionsReceived(TElHTTPSServerHandle _Handle, TSBExtensionsReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnExtensionsPrepared(TElHTTPSServerHandle _Handle, TSBExtensionsPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnExtensionsPrepared(TElHTTPSServerHandle _Handle, TSBExtensionsPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnKeyNeeded(TElHTTPSServerHandle _Handle, TSBServerKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnKeyNeeded(TElHTTPSServerHandle _Handle, TSBServerKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnCloseConnection(TElHTTPSServerHandle _Handle, TSBCloseConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnCloseConnection(TElHTTPSServerHandle _Handle, TSBCloseConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnRenegotiationStart(TElHTTPSServerHandle _Handle, TSBRenegotiationStartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnRenegotiationStart(TElHTTPSServerHandle _Handle, TSBRenegotiationStartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnCertificateURLs(TElHTTPSServerHandle _Handle, TSBCertificateURLsEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnCertificateURLs(TElHTTPSServerHandle _Handle, TSBCertificateURLsEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnPreparedHeaders(TElHTTPSServerHandle _Handle, TSBHTTPHeadersEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnPreparedHeaders(TElHTTPSServerHandle _Handle, TSBHTTPHeadersEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnRequestHeadersReceived(TElHTTPSServerHandle _Handle, TSBHTTPRequestHeadersEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnRequestHeadersReceived(TElHTTPSServerHandle _Handle, TSBHTTPRequestHeadersEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnAfterAuthorization(TElHTTPSServerHandle _Handle, TSBHTTPAfterAuthorizationEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnAfterAuthorization(TElHTTPSServerHandle _Handle, TSBHTTPAfterAuthorizationEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnRequestBodyReceived(TElHTTPSServerHandle _Handle, TSBHTTPRequestBodyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnRequestBodyReceived(TElHTTPSServerHandle _Handle, TSBHTTPRequestBodyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnGetUserPassword(TElHTTPSServerHandle _Handle, TSBOnGetUserPasswordEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnGetUserPassword(TElHTTPSServerHandle _Handle, TSBOnGetUserPasswordEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnBeforeWebSocketServerUsed(TElHTTPSServerHandle _Handle, TSBHTTPBeforeWebSocketServerUsedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnBeforeWebSocketServerUsed(TElHTTPSServerHandle _Handle, TSBHTTPBeforeWebSocketServerUsedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnWebSocketConnectionEstablished(TElHTTPSServerHandle _Handle, SBHTTPSServer_TSBHTTPWebSocketConnectionEstablishedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnWebSocketConnectionEstablished(TElHTTPSServerHandle _Handle, SBHTTPSServer_TSBHTTPWebSocketConnectionEstablishedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnSessionCreate(TElHTTPSServerHandle _Handle, TSBHTTPSessionCreateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnSessionCreate(TElHTTPSServerHandle _Handle, TSBHTTPSessionCreateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnSessionDestroy(TElHTTPSServerHandle _Handle, TSBHTTPSessionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnSessionDestroy(TElHTTPSServerHandle _Handle, TSBHTTPSessionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnSessionUpdate(TElHTTPSServerHandle _Handle, TSBHTTPSessionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnSessionUpdate(TElHTTPSServerHandle _Handle, TSBHTTPSessionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnAuthorizationDenied(TElHTTPSServerHandle _Handle, TSBHTTPSessionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnAuthorizationDenied(TElHTTPSServerHandle _Handle, TSBHTTPSessionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnAuthenticationSucceed(TElHTTPSServerHandle _Handle, TSBHTTPSessionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnAuthenticationSucceed(TElHTTPSServerHandle _Handle, TSBHTTPSessionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnOAuth2PasswordGrantTypeRequested(TElHTTPSServerHandle _Handle, TSBOAuth2GrantTypeRequestedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnOAuth2PasswordGrantTypeRequested(TElHTTPSServerHandle _Handle, TSBOAuth2GrantTypeRequestedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_get_OnOAuth2ClientCredentialsGrantTypeRequested(TElHTTPSServerHandle _Handle, TSBOAuth2GrantTypeRequestedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_set_OnOAuth2ClientCredentialsGrantTypeRequested(TElHTTPSServerHandle _Handle, TSBOAuth2GrantTypeRequestedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSServer_Create(TComponentHandle AOwner, TElHTTPSServerHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPSSERVER */

#ifdef SB_USE_CLASS_TELDIGESTAUTH
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_Init(TElDigestAuthHandle _Handle, const char * pcUserParams, int32_t szUserParams);
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_CalcHash(TElDigestAuthHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_get_Nonce(TElDigestAuthHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_set_Nonce(TElDigestAuthHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_get_Password(TElDigestAuthHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_set_Password(TElDigestAuthHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_get_RequestMethod(TElDigestAuthHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_set_RequestMethod(TElDigestAuthHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_get_RequestURI(TElDigestAuthHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_set_RequestURI(TElDigestAuthHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_get_Response(TElDigestAuthHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_set_Response(TElDigestAuthHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_get_UserName(TElDigestAuthHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_set_UserName(TElDigestAuthHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDigestAuth_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELDIGESTAUTH */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElHTTPSession_ce_ptr;
extern zend_class_entry *TElHTTPServerRequestParams_ce_ptr;
extern zend_class_entry *TElHTTPOAuth2ApplicationInfo_ce_ptr;
extern zend_class_entry *TElHTTPOAuth2CustomApplicationStorage_ce_ptr;
extern zend_class_entry *TElHTTPOAuth2MemoryApplicationStorage_ce_ptr;
extern zend_class_entry *TElHTTPCustomSessionManager_ce_ptr;
extern zend_class_entry *TElHTTPMemorySessionManager_ce_ptr;
extern zend_class_entry *TElHTTPServerResponseParams_ce_ptr;
extern zend_class_entry *TElMultipartFormData_ce_ptr;
extern zend_class_entry *TElMultipartFormList_ce_ptr;
extern zend_class_entry *TElHTTPSServer_ce_ptr;
extern zend_class_entry *TElDigestAuth_ce_ptr;

void SB_CALLBACK TSBHTTPRequestHeadersEventRaw(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle RequestInfo, int8_t * Accepted);
void SB_CALLBACK TSBHTTPAfterAuthorizationEventRaw(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle RequestInfo, int8_t * Accepted);
void SB_CALLBACK TSBHTTPRequestBodyEventRaw(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle RequestInfo);
void SB_CALLBACK TSBHTTPBeforeWebSocketServerUsedEventRaw(void * _ObjectData, TObjectHandle Sender, TElWebSocketServerHandle WSServer);
void SB_CALLBACK SBHTTPSServer_TSBHTTPWebSocketConnectionEstablishedEventRaw(void * _ObjectData, TObjectHandle Sender, TElWebSocketServerHandle WSServer);
void SB_CALLBACK TSBHTTPSessionCreateEventRaw(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle RequestInfo, TElHTTPSessionHandle Session, const char * pcCookie, int32_t szCookie);
void SB_CALLBACK TSBHTTPSessionEventRaw(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle RequestInfo, TElHTTPSessionHandle Session);
void SB_CALLBACK TSBOnGetUserPasswordEventRaw(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle ReqParams, char * pcPassword, int32_t * szPassword, int8_t * Accept);
void SB_CALLBACK TSBOAuth2GrantTypeRequestedEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcID, int32_t szID, const char * pcScope, int32_t szScope, int8_t * Allow);
void Register_TElHTTPSession(TSRMLS_D);
void Register_TElHTTPServerRequestParams(TSRMLS_D);
void Register_TElHTTPOAuth2ApplicationInfo(TSRMLS_D);
void Register_TElHTTPOAuth2CustomApplicationStorage(TSRMLS_D);
void Register_TElHTTPOAuth2MemoryApplicationStorage(TSRMLS_D);
void Register_TElHTTPCustomSessionManager(TSRMLS_D);
void Register_TElHTTPMemorySessionManager(TSRMLS_D);
void Register_TElHTTPServerResponseParams(TSRMLS_D);
void Register_TElMultipartFormData(TSRMLS_D);
void Register_TElMultipartFormList(TSRMLS_D);
void Register_TElHTTPSServer(TSRMLS_D);
void Register_TElDigestAuth(TSRMLS_D);
SB_PHP_FUNCTION(SBHTTPSServer, GetDefaultReasonPhrase);
void Register_SBHTTPSServer_Enum_Flags(TSRMLS_D);
void Register_SBHTTPSServer_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_HTTPSSERVER
SB_IMPORT uint32_t SB_APIENTRY SBHTTPSServer_GetDefaultReasonPhrase(int32_t ResponseCode, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_HTTPSSERVER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBHTTPSSERVER */
