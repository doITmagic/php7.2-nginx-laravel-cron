#ifndef __INC_SBHTTPSWEBDAVCLIENT
#define __INC_SBHTTPSWEBDAVCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbxmldefs.h"
#include "sbxmlutils.h"
#include "sbxmlcore.h"
#include "sbxmlcharsets.h"
#include "sbstringlist.h"
#include "sbhttpscommon.h"
#include "sbhttpsconstants.h"
#include "sbhttpsclient.h"
#include "sbwebdavcommon.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElHTTPSWebDAVClientHandle;

typedef TElHTTPSWebDAVClientHandle ElHTTPSWebDAVClientHandle;

#ifdef SB_USE_CLASS_TELHTTPSWEBDAVCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_PropFind(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TSBWebDAVDepthRaw Depth, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_PropFind_1(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle Properties, int8_t All, TSBWebDAVDepthRaw Depth, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_AddressBookReport(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle Properties, TElStringListHandle AddressDataProps, TElCardDavFilterHandle Filter, int32_t Limit, TElStringListHandle Hrefs, int8_t All, TSBWebDAVDepthRaw Depth, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_AclPrincipalPropSetReport(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle Properties, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_AclPrincipalMatchReport(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoHandle PrincipalProperty, TElWebDAVPropertyInfoListHandle Properties, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_PrincipalSearchPropertySetReport(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_PrincipalPropertySearchReport(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle MatchProperties, TElStringListHandle Matches, TElWebDAVPropertyInfoListHandle Properties, int8_t ApplyToPrincipalCollectionSet, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Acl(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVACLHandle NewAcl, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_PropPatch(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle SetProperties, TElWebDAVPropertyInfoListHandle RemoveProperties, const char * pcIfHeader, int32_t szIfHeader, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_MkCol(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcIfHeader, int32_t szIfHeader, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_MkColEx(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcDisplayName, int32_t szDisplayName, const char * pcDescription, int32_t szDescription, const char * pcLang, int32_t szLang, const char * pcIfHeader, int32_t szIfHeader, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Copy(TElHTTPSWebDAVClientHandle _Handle, const char * pcSrcURL, int32_t szSrcURL, const char * pcDestURL, int32_t szDestURL, TSBWebDAVDepthRaw Depth, int8_t Overwrite, int8_t IncludeDepth, const char * pcIfHeader, int32_t szIfHeader, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Move(TElHTTPSWebDAVClientHandle _Handle, const char * pcSrcURL, int32_t szSrcURL, const char * pcDestURL, int32_t szDestURL, TSBWebDAVDepthRaw Depth, int8_t Overwrite, const char * pcIfHeader, int32_t szIfHeader, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Lock(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcIfHeader, int32_t szIfHeader, const char * pcOwner, int32_t szOwner, TSBWebDAVLockScopeRaw Scope, TSBWebDAVDepthRaw Depth, int32_t Timeout, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Unlock(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcToken, int32_t szToken, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Delete(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcIfHeader, int32_t szIfHeader, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Delete_1(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Put(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcContent, int32_t szContent, const char * pcIfHeader, int32_t szIfHeader, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Put_1(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const uint8_t pContent[], int32_t szContent, const char * pcIfHeader, int32_t szIfHeader, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Put_2(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const uint8_t pContent[], int32_t szContent, int32_t StartIndex, int32_t Count, const char * pcIfHeader, int32_t szIfHeader, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Put_3(TElHTTPSWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TStreamHandle Content, int8_t CloseStream, const char * pcIfHeader, int32_t szIfHeader, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Put_4(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Put_5(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, int64_t ContentLength, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Put_6(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcContent, int32_t szContent, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Put_7(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, const uint8_t pContent[], int32_t szContent, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Put_8(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, const uint8_t pContent[], int32_t szContent, int32_t StartIndex, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Put_9(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, TStreamHandle Content, int8_t CloseStream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHTTPSWebDAVClient_Create(TComponentHandle AOwner, TElHTTPSWebDAVClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELHTTPSWEBDAVCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElHTTPSWebDAVClient_ce_ptr;

void Register_TElHTTPSWebDAVClient(TSRMLS_D);
void Register_SBHTTPSWebDAVClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBHTTPSWEBDAVCLIENT */

