#ifndef __INC_SBIMAPCLIENT
#define __INC_SBIMAPCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbsimplessl.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbmime.h"
#include "sbsimplemime.h"
#include "sbsslcommon.h"
#include "sbsslconstants.h"
#include "sbsslclient.h"
#include "sbx509.h"
#include "sbsasl.h"
#include "sbstringlist.h"
#include "sbencoding.h"
#include "sbchsconv.h"
#include "sbimaputils.h"
#include "sbdnssectypes.h"
#include "sbsocket.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_IMAP 	90112
#define SB_ERROR_IMAP_PROTOCOL_ERROR_FLAG 	2048
#define SB_IMAP_ERROR_NOT_CONNECTED 	92161
#define SB_IMAP_ERROR_ALREADY_CONNECTED 	92162
#define SB_IMAP_ERROR_NO_ADDRESS 	92163
#define SB_IMAP_ERROR_FAILURE 	92164
#define SB_IMAP_ERROR_PROTOCOL 	92165
#define SB_IMAP_ERROR_NO_REPLY 	92166
#define SB_IMAP_ERROR_BAD_REPLY 	92167
#define SB_IMAP_ERROR_INVALID_LENGTH 	92168
#define SB_IMAP_ERROR_SMALL_LENGTH 	92169
#define SB_IMAP_ERROR_TOO_LONG_LINE 	92170
#define SB_IMAP_ERROR_TLSNOTSUPPORTED 	92171
#define SB_IMAP_ERROR_INVALID_STATE 	92172
#define SB_IMAP_ERROR_NO_SALS_MECHANISM 	92173
#define SB_IMAP_ERROR_AUTHORIZATION_FAILED 	92174
#define SB_imapLastMessage 	2147483647
#define SB_imapSendBufferSize 	65536

typedef TElClassHandle TElIMAPLiteralContextHandle;

typedef TElClassHandle TElIMAPMailBoxStateHandle;

typedef TElClassHandle TElIMAPMailBoxInfoHandle;

typedef TElClassHandle TElIMAPMailBoxesListHandle;

typedef TElClassHandle TElIMAPFetchResponseItemHandle;

typedef TElClassHandle TElIMAPFetchResponseLineHandle;

typedef TElClassHandle TElIMAPFetchResponseHandle;

typedef TElClassHandle TElIMAPAppendResultHandle;

typedef TElClassHandle TElIMAPCopyResultHandle;

typedef TElClassHandle TElIMAPIdleUpdateHandle;

typedef TElClassHandle TElIMAPIdleThreadHandle;

typedef TElClassHandle TElIMAPTimeoutThreadHandle;

typedef TElClassHandle TElIMAPClientHandle;

typedef TElIMAPClientHandle ElIMAPClientHandle;

typedef uint8_t TSBIMAPLogDirectionRaw;

typedef enum
{
	imapSent = 0,
	imapReceived = 1
} TSBIMAPLogDirection;

typedef void (SB_CALLBACK *TSBIMAPLogEvent)(void * _ObjectData, TObjectHandle Sender, TSBIMAPLogDirectionRaw Direction, const char * pcInfo, int32_t szInfo);

typedef uint8_t TSBIMAPAutoCAPAModeRaw;

typedef enum
{
	_capaNone = 0,
	_capaOnConnect = 1,
	_capaOnLogin = 2,
	_capaBoth = 3
} TSBIMAPAutoCAPAMode;

typedef uint8_t TSBIMAPStateRaw;

typedef enum
{
	imapNotAuthenticated = 0,
	imapAuthenticated = 1,
	imapSelected = 2
} TSBIMAPState;

typedef uint8_t TSBIMAPTokenRaw;

typedef enum
{
	imapUnknownToken = 0,
	imapOkToken = 1,
	imapOkFinalToken = 2,
	imapBadToken = 3,
	imapBadFinalToken = 4,
	imapNoToken = 5,
	imapNoFinalToken = 6,
	imapPreAuthToken = 7,
	imapByeToken = 8,
	imapContinueToken = 9,
	imapCapabilityToken = 10,
	imapListToken = 11,
	imapLSubToken = 12,
	imapStatusToken = 13,
	imapSearchToken = 14,
	imapFlagsToken = 15,
	imapExistsToken = 16,
	imapRecentToken = 17,
	imapExpungeToken = 18,
	imapFetchToken = 19,
	imapUidNextToken = 20,
	imapUidNotSticky = 21,
	imapUidValidToken = 22,
	imapUnseenToken = 23,
	imapReadOnlyToken = 24,
	imapReadWriteToken = 25,
	imapPermanentFlagsToken = 26,
	imapTrycreateToken = 27,
	imapAppendUidToken = 28,
	imapCopyUidToken = 29,
	imapAlertToken = 30,
	imapBadcharsetToken = 31,
	imapParseToken = 32
} TSBIMAPToken;

typedef uint8_t TElIMAPFetchResponseItemTypeRaw;

typedef enum
{
	imapFetchUunknown = 0,
	imapFetchUid = 1,
	imapFetchEnvelope = 2,
	imapFetchFlags = 3,
	imapFetchInternaldate = 4,
	imapFetchRfc822 = 5,
	imapFetchRfc822Header = 6,
	imapFetchRfc822Size = 7,
	imapFetchRfc822Text = 8
} TElIMAPFetchResponseItemType;

typedef uint8_t TSBIMAPStoreFlagsOperationRaw;

typedef enum
{
	imapReplaceFlags = 0,
	imapAddFlags = 1,
	imapRemoveFlags = 2
} TSBIMAPStoreFlagsOperation;

typedef uint8_t TSBIMAPMailBoxAttributeRaw;

typedef enum
{
	imapNoSelect = 0,
	imapNoInferiors = 1,
	imapMarked = 2,
	imapUnmarked = 3,
	imapHasChildren = 4,
	imapHasNoChildren = 5
} TSBIMAPMailBoxAttribute;

typedef uint32_t TSBIMAPMailBoxAttributesRaw;

typedef enum 
{
	f_imapNoSelect = 1,
	f_imapNoInferiors = 2,
	f_imapMarked = 4,
	f_imapUnmarked = 8,
	f_imapHasChildren = 16,
	f_imapHasNoChildren = 32
} TSBIMAPMailBoxAttributes;

typedef uint8_t TSBIMAPMessageFlagRaw;

typedef enum
{
	imapUnknownFlag = 0,
	imapAnsweredFlag = 1,
	imapFlaggedFlag = 2,
	imapDeletedFlag = 3,
	imapSeenFlag = 4,
	imapDraftFlag = 5,
	imapSpecialFlag = 6
} TSBIMAPMessageFlag;

typedef uint32_t TSBIMAPMessageFlagsRaw;

typedef enum 
{
	f_imapUnknownFlag = 1,
	f_imapAnsweredFlag = 2,
	f_imapFlaggedFlag = 4,
	f_imapDeletedFlag = 8,
	f_imapSeenFlag = 16,
	f_imapDraftFlag = 32,
	f_imapSpecialFlag = 64
} TSBIMAPMessageFlags;

typedef uint8_t TSBIMAPStatusItemRaw;

typedef enum
{
	imapStatusMessages = 0,
	imapStatusUnseen = 1,
	imapStatusRecent = 2,
	imapStatusUidNext = 3,
	imapStatusUidValidity = 4
} TSBIMAPStatusItem;

typedef uint32_t TSBIMAPStatusItemsRaw;

typedef enum 
{
	f_imapStatusMessages = 1,
	f_imapStatusUnseen = 2,
	f_imapStatusRecent = 4,
	f_imapStatusUidNext = 8,
	f_imapStatusUidValidity = 16
} TSBIMAPStatusItems;

typedef void (SB_CALLBACK *TSBIMAPTextLineEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcInfo, int32_t szInfo);

typedef void (SB_CALLBACK *TSBIMAPIdleEvent)(void * _ObjectData, TObjectHandle Sender, TElIMAPIdleUpdateHandle Update);

#ifdef SB_USE_CLASS_TELIMAPLITERALCONTEXT
SB_IMPORT uint32_t SB_APIENTRY TElIMAPLiteralContext_get_Line(TElIMAPLiteralContextHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPLiteralContext_set_Line(TElIMAPLiteralContextHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPLiteralContext_get_IsLiteral(TElIMAPLiteralContextHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPLiteralContext_set_IsLiteral(TElIMAPLiteralContextHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPLiteralContext_Create(const char * pcLine, int32_t szLine, TElIMAPLiteralContextHandle * OutResult);
#endif /* SB_USE_CLASS_TELIMAPLITERALCONTEXT */

#ifdef SB_USE_CLASS_TELIMAPMAILBOXSTATE
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_Clear(TElIMAPMailBoxStateHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_CopyFrom(TElIMAPMailBoxStateHandle _Handle, TElIMAPMailBoxStateHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_get_ReadWrite(TElIMAPMailBoxStateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_set_ReadWrite(TElIMAPMailBoxStateHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_get_TotalMessages(TElIMAPMailBoxStateHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_set_TotalMessages(TElIMAPMailBoxStateHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_get_RecentMessages(TElIMAPMailBoxStateHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_set_RecentMessages(TElIMAPMailBoxStateHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_get_UnseenMessages(TElIMAPMailBoxStateHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_set_UnseenMessages(TElIMAPMailBoxStateHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_get_Flags(TElIMAPMailBoxStateHandle _Handle, TSBIMAPMessageFlagsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_set_Flags(TElIMAPMailBoxStateHandle _Handle, TSBIMAPMessageFlagsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_get_PermanentFlags(TElIMAPMailBoxStateHandle _Handle, TSBIMAPMessageFlagsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_set_PermanentFlags(TElIMAPMailBoxStateHandle _Handle, TSBIMAPMessageFlagsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_get_NextUID(TElIMAPMailBoxStateHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_set_NextUID(TElIMAPMailBoxStateHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_get_UIDNotSticky(TElIMAPMailBoxStateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_set_UIDNotSticky(TElIMAPMailBoxStateHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_get_UIDValidity(TElIMAPMailBoxStateHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_set_UIDValidity(TElIMAPMailBoxStateHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxState_Create(TElIMAPMailBoxStateHandle * OutResult);
#endif /* SB_USE_CLASS_TELIMAPMAILBOXSTATE */

#ifdef SB_USE_CLASS_TELIMAPMAILBOXINFO
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxInfo_get_Attributes(TElIMAPMailBoxInfoHandle _Handle, TSBIMAPMailBoxAttributesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxInfo_get_Delimiter(TElIMAPMailBoxInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxInfo_get_Name(TElIMAPMailBoxInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxInfo_Create(TSBIMAPMailBoxAttributesRaw AAttributes, const char * pcADelimiter, int32_t szADelimiter, const char * pcAName, int32_t szAName, TElIMAPMailBoxInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELIMAPMAILBOXINFO */

#ifdef SB_USE_CLASS_TELIMAPMAILBOXESLIST
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxesList_Add(TElIMAPMailBoxesListHandle _Handle, TElIMAPMailBoxInfoHandle Item);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxesList_Get(TElIMAPMailBoxesListHandle _Handle, int32_t Index, TElIMAPMailBoxInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxesList_Clear(TElIMAPMailBoxesListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxesList_get_Count(TElIMAPMailBoxesListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPMailBoxesList_Create(TElIMAPMailBoxesListHandle * OutResult);
#endif /* SB_USE_CLASS_TELIMAPMAILBOXESLIST */

#ifdef SB_USE_CLASS_TELIMAPFETCHRESPONSEITEM
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseItem_SetData(TElIMAPFetchResponseItemHandle _Handle, const char * pcAName, int32_t szAName, const char * pcAValue, int32_t szAValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseItem_get_ItemType(TElIMAPFetchResponseItemHandle _Handle, TElIMAPFetchResponseItemTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseItem_get_Name(TElIMAPFetchResponseItemHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseItem_get_RawValue(TElIMAPFetchResponseItemHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseItem_get_Value(TElIMAPFetchResponseItemHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseItem_get_DateTime(TElIMAPFetchResponseItemHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseItem_get_Flags(TElIMAPFetchResponseItemHandle _Handle, TSBIMAPMessageFlagsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseItem_get_Number(TElIMAPFetchResponseItemHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseItem_get_Streamed(TElIMAPFetchResponseItemHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseItem_Create(const char * pcAName, int32_t szAName, const char * pcAValue, int32_t szAValue, TElIMAPFetchResponseItemHandle * OutResult);
#endif /* SB_USE_CLASS_TELIMAPFETCHRESPONSEITEM */

#ifdef SB_USE_CLASS_TELIMAPFETCHRESPONSELINE
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseLine_Add(TElIMAPFetchResponseLineHandle _Handle, TElIMAPFetchResponseItemHandle Item);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseLine_Get(TElIMAPFetchResponseLineHandle _Handle, int32_t Index, TElIMAPFetchResponseItemHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseLine_GetByName(TElIMAPFetchResponseLineHandle _Handle, const char * pcName, int32_t szName, TElIMAPFetchResponseItemHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseLine_CopyFrom(TElIMAPFetchResponseLineHandle _Handle, TElIMAPFetchResponseLineHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseLine_Clear(TElIMAPFetchResponseLineHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseLine_get_Count(TElIMAPFetchResponseLineHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseLine_get_ID(TElIMAPFetchResponseLineHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseLine_get_Items(TElIMAPFetchResponseLineHandle _Handle, const char * pcName, int32_t szName, TElIMAPFetchResponseItemHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponseLine_Create(int32_t ID, TElIMAPFetchResponseLineHandle * OutResult);
#endif /* SB_USE_CLASS_TELIMAPFETCHRESPONSELINE */

#ifdef SB_USE_CLASS_TELIMAPFETCHRESPONSE
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponse_Add(TElIMAPFetchResponseHandle _Handle, TElIMAPFetchResponseLineHandle Line);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponse_AddID(TElIMAPFetchResponseHandle _Handle, int32_t ID);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponse_Get(TElIMAPFetchResponseHandle _Handle, int32_t Index, TElIMAPFetchResponseLineHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponse_GetByID(TElIMAPFetchResponseHandle _Handle, int32_t ID, TElIMAPFetchResponseLineHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponse_Append(TElIMAPFetchResponseHandle _Handle, TElIMAPFetchResponseHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponse_Clear(TElIMAPFetchResponseHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponse_get_Count(TElIMAPFetchResponseHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponse_get_UID(TElIMAPFetchResponseHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponse_get_Lines(TElIMAPFetchResponseHandle _Handle, int32_t Index, TElIMAPFetchResponseLineHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPFetchResponse_Create(int8_t UID, TElIMAPFetchResponseHandle * OutResult);
#endif /* SB_USE_CLASS_TELIMAPFETCHRESPONSE */

#ifdef SB_USE_CLASS_TELIMAPAPPENDRESULT
SB_IMPORT uint32_t SB_APIENTRY TElIMAPAppendResult_Clear(TElIMAPAppendResultHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPAppendResult_CopyFrom(TElIMAPAppendResultHandle _Handle, TElIMAPAppendResultHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPAppendResult_get_UIDValidity(TElIMAPAppendResultHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPAppendResult_set_UIDValidity(TElIMAPAppendResultHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPAppendResult_get_UIDs(TElIMAPAppendResultHandle _Handle, TElIMAPFetchResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPAppendResult_Create(TElIMAPAppendResultHandle * OutResult);
#endif /* SB_USE_CLASS_TELIMAPAPPENDRESULT */

#ifdef SB_USE_CLASS_TELIMAPCOPYRESULT
SB_IMPORT uint32_t SB_APIENTRY TElIMAPCopyResult_Clear(TElIMAPCopyResultHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPCopyResult_CopyFrom(TElIMAPCopyResultHandle _Handle, TElIMAPCopyResultHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPCopyResult_get_UIDValidity(TElIMAPCopyResultHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPCopyResult_set_UIDValidity(TElIMAPCopyResultHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPCopyResult_get_SourceUIDs(TElIMAPCopyResultHandle _Handle, TElIMAPFetchResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPCopyResult_get_DestinationUIDs(TElIMAPCopyResultHandle _Handle, TElIMAPFetchResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPCopyResult_Create(TElIMAPCopyResultHandle * OutResult);
#endif /* SB_USE_CLASS_TELIMAPCOPYRESULT */

#ifdef SB_USE_CLASS_TELIMAPIDLEUPDATE
SB_IMPORT uint32_t SB_APIENTRY TElIMAPIdleUpdate_Add(TElIMAPIdleUpdateHandle _Handle, TElIMAPIdleUpdateHandle Update);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPIdleUpdate_Clear(TElIMAPIdleUpdateHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPIdleUpdate_get_Token(TElIMAPIdleUpdateHandle _Handle, TSBIMAPTokenRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPIdleUpdate_set_Token(TElIMAPIdleUpdateHandle _Handle, TSBIMAPTokenRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPIdleUpdate_get_MailBoxState(TElIMAPIdleUpdateHandle _Handle, TElIMAPMailBoxStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPIdleUpdate_get_ChangedMessages(TElIMAPIdleUpdateHandle _Handle, TElIMAPFetchResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPIdleUpdate_get_ExpungedMessages(TElIMAPIdleUpdateHandle _Handle, TElIMAPFetchResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPIdleUpdate_Create(TElIMAPIdleUpdateHandle * OutResult);
#endif /* SB_USE_CLASS_TELIMAPIDLEUPDATE */

#ifdef SB_USE_CLASS_TELIMAPIDLETHREAD
SB_IMPORT uint32_t SB_APIENTRY TElIMAPIdleThread_Execute(TElIMAPIdleThreadHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPIdleThread_Start(TElIMAPIdleThreadHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPIdleThread_WaitStop(TElIMAPIdleThreadHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPIdleThread_TryCallEvents(TElIMAPIdleThreadHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPIdleThread_Create(TElIMAPClientHandle Client, TElIMAPIdleThreadHandle * OutResult);
#endif /* SB_USE_CLASS_TELIMAPIDLETHREAD */

#ifdef SB_USE_CLASS_TELIMAPTIMEOUTTHREAD
SB_IMPORT uint32_t SB_APIENTRY TElIMAPTimeoutThread_Execute(TElIMAPTimeoutThreadHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPTimeoutThread_Start(TElIMAPTimeoutThreadHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPTimeoutThread_Stop(TElIMAPTimeoutThreadHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPTimeoutThread_Create(TElIMAPClientHandle Client, TElIMAPTimeoutThreadHandle * OutResult);
#endif /* SB_USE_CLASS_TELIMAPTIMEOUTTHREAD */

#ifdef SB_USE_CLASS_TELIMAPCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Open(TElIMAPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_ObtainCapabilities(TElIMAPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Login(TElIMAPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Close(TElIMAPClientHandle _Handle, int8_t Silent);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Noop(TElIMAPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_List(TElIMAPClientHandle _Handle, const char * pcRefName, int32_t szRefName, const char * pcMailBox, int32_t szMailBox, TElIMAPMailBoxesListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_LSub(TElIMAPClientHandle _Handle, const char * pcRefName, int32_t szRefName, const char * pcMailBox, int32_t szMailBox, TElIMAPMailBoxesListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_SelectBox(TElIMAPClientHandle _Handle, const char * pcMailBox, int32_t szMailBox, TElIMAPMailBoxStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_ExamineBox(TElIMAPClientHandle _Handle, const char * pcMailBox, int32_t szMailBox, TElIMAPMailBoxStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_StatusBox(TElIMAPClientHandle _Handle, const char * pcMailBox, int32_t szMailBox, TSBIMAPStatusItemsRaw Items, TElIMAPMailBoxStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_CloseBox(TElIMAPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Fetch(TElIMAPClientHandle _Handle, int32_t First, int32_t Last, int8_t UID, const char * pcDataItemNames, int32_t szDataItemNames, TElIMAPFetchResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Fetch_1(TElIMAPClientHandle _Handle, TElIMAPFetchResponseHandle Sequence, const char * pcDataItemNames, int32_t szDataItemNames, TElIMAPFetchResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Store(TElIMAPClientHandle _Handle, int32_t First, int32_t Last, int8_t UID, TSBIMAPStoreFlagsOperationRaw Operation, TSBIMAPMessageFlagsRaw Flags, int8_t Silent, TElIMAPFetchResponseHandle Response);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Store_1(TElIMAPClientHandle _Handle, TElIMAPFetchResponseHandle Sequence, TSBIMAPStoreFlagsOperationRaw Operation, TSBIMAPMessageFlagsRaw Flags, int8_t Silent, TElIMAPFetchResponseHandle Response);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Expunge(TElIMAPClientHandle _Handle, TElIMAPFetchResponseHandle Response);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Append(TElIMAPClientHandle _Handle, const char * pcMailBox, int32_t szMailBox, TSBIMAPMessageFlagsRaw Flags, TElMessageHandle Message, TElIMAPAppendResultHandle AppendResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Append_1(TElIMAPClientHandle _Handle, const char * pcMailBox, int32_t szMailBox, TSBIMAPMessageFlagsRaw Flags, int64_t DateTime, TElMessageHandle Message, TElIMAPAppendResultHandle AppendResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Append_2(TElIMAPClientHandle _Handle, const char * pcMailBox, int32_t szMailBox, TSBIMAPMessageFlagsRaw Flags, TElSimpleMIMEMessageHandle Message, TElIMAPAppendResultHandle AppendResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Append_3(TElIMAPClientHandle _Handle, const char * pcMailBox, int32_t szMailBox, TSBIMAPMessageFlagsRaw Flags, int64_t DateTime, TElSimpleMIMEMessageHandle Message, TElIMAPAppendResultHandle AppendResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Append_4(TElIMAPClientHandle _Handle, const char * pcMailBox, int32_t szMailBox, TSBIMAPMessageFlagsRaw Flags, TStreamHandle Stream, TElIMAPAppendResultHandle AppendResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Append_5(TElIMAPClientHandle _Handle, const char * pcMailBox, int32_t szMailBox, TSBIMAPMessageFlagsRaw Flags, int64_t DateTime, TStreamHandle Stream, TElIMAPAppendResultHandle AppendResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Copy(TElIMAPClientHandle _Handle, int32_t First, int32_t Last, int8_t UID, const char * pcMailBox, int32_t szMailBox, TElIMAPCopyResultHandle CopyResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Copy_1(TElIMAPClientHandle _Handle, TElIMAPFetchResponseHandle Sequence, const char * pcMailBox, int32_t szMailBox, TElIMAPCopyResultHandle CopyResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_FetchMessage(TElIMAPClientHandle _Handle, int32_t ID, int8_t UID, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_FetchMessage_1(TElIMAPClientHandle _Handle, int32_t ID, int8_t UID, const char * pcHeaderCharset, int32_t szHeaderCharset, const char * pcBodyCharset, int32_t szBodyCharset, TElMessageParsingOptionsRaw Options, int8_t IgnoreHeaderNativeCharset, int8_t IgnoreBodyNativeCharset, int8_t ActivatePartHandlers, TElMessageHandle * Message, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_CreateBox(TElIMAPClientHandle _Handle, const char * pcMailBox, int32_t szMailBox);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_RenameBox(TElIMAPClientHandle _Handle, const char * pcMailBox, int32_t szMailBox, const char * pcNewName, int32_t szNewName);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_DeleteBox(TElIMAPClientHandle _Handle, const char * pcMailBox, int32_t szMailBox);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Check(TElIMAPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_SubscribeBox(TElIMAPClientHandle _Handle, const char * pcMailBox, int32_t szMailBox);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_UnsubscribeBox(TElIMAPClientHandle _Handle, const char * pcMailBox, int32_t szMailBox);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Search(TElIMAPClientHandle _Handle, int8_t UID, const char * pcCriteria, int32_t szCriteria, TElIMAPFetchResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Search_1(TElIMAPClientHandle _Handle, int8_t UID, const char * pcCriteria, int32_t szCriteria, const char * pcCharset, int32_t szCharset, TElIMAPFetchResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Idle(TElIMAPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_IdleDone(TElIMAPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_Capabilities(TElIMAPClientHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_LoginDisabled(TElIMAPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_PlainLoginPriority(TElIMAPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_PlainLoginPriority(TElIMAPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_SASLLoginPriority(TElIMAPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_SASLLoginPriority(TElIMAPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_SASLMechanism(TElIMAPClientHandle _Handle, const char * pcName, int32_t szName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_SASLMechanism(TElIMAPClientHandle _Handle, const char * pcName, int32_t szName, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_SASLMechanismPriorities(TElIMAPClientHandle _Handle, const char * pcName, int32_t szName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_SASLMechanismPriorities(TElIMAPClientHandle _Handle, const char * pcName, int32_t szName, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_MailBox(TElIMAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_MailBoxState(TElIMAPClientHandle _Handle, TElIMAPMailBoxStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_IdleSupported(TElIMAPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_IdleActive(TElIMAPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_Address(TElIMAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_Address(TElIMAPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_MaxLineLength(TElIMAPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_MaxLineLength(TElIMAPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_Port(TElIMAPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_Port(TElIMAPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_SSLMode(TElIMAPClientHandle _Handle, TSBSSLModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_SSLMode(TElIMAPClientHandle _Handle, TSBSSLModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_AutoCAPA(TElIMAPClientHandle _Handle, TSBIMAPAutoCAPAModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_AutoCAPA(TElIMAPClientHandle _Handle, TSBIMAPAutoCAPAModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_UseIPv6(TElIMAPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_UseIPv6(TElIMAPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_UseSSL(TElIMAPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_UseSSL(TElIMAPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_Username(TElIMAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_Username(TElIMAPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_Password(TElIMAPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_Password(TElIMAPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_IdleAuto(TElIMAPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_IdleAuto(TElIMAPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_IdleTimeout(TElIMAPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_IdleTimeout(TElIMAPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnCapability(TElIMAPClientHandle _Handle, TSBIMAPTextLineEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnCapability(TElIMAPClientHandle _Handle, TSBIMAPTextLineEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnLog(TElIMAPClientHandle _Handle, TSBIMAPLogEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnLog(TElIMAPClientHandle _Handle, TSBIMAPLogEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnProgress(TElIMAPClientHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnProgress(TElIMAPClientHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnIdle(TElIMAPClientHandle _Handle, TSBIMAPIdleEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnIdle(TElIMAPClientHandle _Handle, TSBIMAPIdleEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnCertificateChoose(TElIMAPClientHandle _Handle, TSBChooseCertificateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnCertificateChoose(TElIMAPClientHandle _Handle, TSBChooseCertificateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnCertificateNeededEx(TElIMAPClientHandle _Handle, TSBCertificateNeededExEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnCertificateNeededEx(TElIMAPClientHandle _Handle, TSBCertificateNeededExEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnCertificateValidate(TElIMAPClientHandle _Handle, TSBCertificateValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnCertificateValidate(TElIMAPClientHandle _Handle, TSBCertificateValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnCiphersNegotiated(TElIMAPClientHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnCiphersNegotiated(TElIMAPClientHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnCloseConnection(TElIMAPClientHandle _Handle, TSBCloseConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnCloseConnection(TElIMAPClientHandle _Handle, TSBCloseConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnError(TElIMAPClientHandle _Handle, TSBErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnError(TElIMAPClientHandle _Handle, TSBErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnExtensionsReceived(TElIMAPClientHandle _Handle, TSBExtensionsReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnExtensionsReceived(TElIMAPClientHandle _Handle, TSBExtensionsReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnCertificateStatus(TElIMAPClientHandle _Handle, TSBCertificateStatusEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnCertificateStatus(TElIMAPClientHandle _Handle, TSBCertificateStatusEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnKeyNeeded(TElIMAPClientHandle _Handle, TSBClientKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnKeyNeeded(TElIMAPClientHandle _Handle, TSBClientKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnRenegotiationRequest(TElIMAPClientHandle _Handle, TSBRenegotiationRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnRenegotiationRequest(TElIMAPClientHandle _Handle, TSBRenegotiationRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnDNSKeyNeeded(TElIMAPClientHandle _Handle, TSBDNSKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnDNSKeyNeeded(TElIMAPClientHandle _Handle, TSBDNSKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnDNSKeyValidate(TElIMAPClientHandle _Handle, TSBDNSKeyValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnDNSKeyValidate(TElIMAPClientHandle _Handle, TSBDNSKeyValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_get_OnDNSResolve(TElIMAPClientHandle _Handle, TSBDNSResolveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_set_OnDNSResolve(TElIMAPClientHandle _Handle, TSBDNSResolveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPClient_Create(TComponentHandle AOwner, TElIMAPClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELIMAPCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElIMAPLiteralContext_ce_ptr;
extern zend_class_entry *TElIMAPMailBoxState_ce_ptr;
extern zend_class_entry *TElIMAPMailBoxInfo_ce_ptr;
extern zend_class_entry *TElIMAPMailBoxesList_ce_ptr;
extern zend_class_entry *TElIMAPFetchResponseItem_ce_ptr;
extern zend_class_entry *TElIMAPFetchResponseLine_ce_ptr;
extern zend_class_entry *TElIMAPFetchResponse_ce_ptr;
extern zend_class_entry *TElIMAPAppendResult_ce_ptr;
extern zend_class_entry *TElIMAPCopyResult_ce_ptr;
extern zend_class_entry *TElIMAPIdleUpdate_ce_ptr;
extern zend_class_entry *TElIMAPIdleThread_ce_ptr;
extern zend_class_entry *TElIMAPTimeoutThread_ce_ptr;
extern zend_class_entry *TElIMAPClient_ce_ptr;

void SB_CALLBACK TSBIMAPLogEventRaw(void * _ObjectData, TObjectHandle Sender, TSBIMAPLogDirectionRaw Direction, const char * pcInfo, int32_t szInfo);
void SB_CALLBACK TSBIMAPTextLineEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcInfo, int32_t szInfo);
void SB_CALLBACK TSBIMAPIdleEventRaw(void * _ObjectData, TObjectHandle Sender, TElIMAPIdleUpdateHandle Update);
void Register_TElIMAPLiteralContext(TSRMLS_D);
void Register_TElIMAPMailBoxState(TSRMLS_D);
void Register_TElIMAPMailBoxInfo(TSRMLS_D);
void Register_TElIMAPMailBoxesList(TSRMLS_D);
void Register_TElIMAPFetchResponseItem(TSRMLS_D);
void Register_TElIMAPFetchResponseLine(TSRMLS_D);
void Register_TElIMAPFetchResponse(TSRMLS_D);
void Register_TElIMAPAppendResult(TSRMLS_D);
void Register_TElIMAPCopyResult(TSRMLS_D);
void Register_TElIMAPIdleUpdate(TSRMLS_D);
void Register_TElIMAPIdleThread(TSRMLS_D);
void Register_TElIMAPTimeoutThread(TSRMLS_D);
void Register_TElIMAPClient(TSRMLS_D);
void Register_SBIMAPClient_Constants(int module_number TSRMLS_DC);
void Register_SBIMAPClient_Enum_Flags(TSRMLS_D);
void Register_SBIMAPClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBIMAPCLIENT */

