#ifndef __INC_SBIMAPUTILS
#define __INC_SBIMAPUTILS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbstreams.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElIMAPParserHandle;

#ifdef SB_USE_CLASS_TELIMAPPARSER
SB_IMPORT uint32_t SB_APIENTRY TElIMAPParser_HasMoreTokens(TElIMAPParserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPParser_NextToken(TElIMAPParserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPParser_GetRemainderString(TElIMAPParserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPParser_get_Source(TElIMAPParserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPParser_set_Source(TElIMAPParserHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPParser_get_CurrentToken(TElIMAPParserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPParser_get_IsParenthesized(TElIMAPParserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPParser_get_IsSection(TElIMAPParserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPParser_get_CurrentPosition(TElIMAPParserHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPParser_Create(const char * pcSource, int32_t szSource, TElIMAPParserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIMAPParser_Create_1(TElIMAPParserHandle * OutResult);
#endif /* SB_USE_CLASS_TELIMAPPARSER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElIMAPParser_ce_ptr;

void Register_TElIMAPParser(TSRMLS_D);
SB_PHP_FUNCTION(SBIMAPUtils, QuoteString);
SB_PHP_FUNCTION(SBIMAPUtils, QuoteStringIfNeed);
SB_PHP_FUNCTION(SBIMAPUtils, UnQuoteString);
SB_PHP_FUNCTION(SBIMAPUtils, IsLiteralToken);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_IMAPUTILS
SB_IMPORT uint32_t SB_APIENTRY SBIMAPUtils_QuoteString(const char * pcValue, int32_t szValue, char Quote, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBIMAPUtils_QuoteStringIfNeed(const char * pcValue, int32_t szValue, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBIMAPUtils_UnQuoteString(const char * pcValue, int32_t szValue, int8_t QuotesRemoved, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBIMAPUtils_IsLiteralToken(const char * pcToken, int32_t szToken, int32_t * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_IMAPUTILS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBIMAPUTILS */

