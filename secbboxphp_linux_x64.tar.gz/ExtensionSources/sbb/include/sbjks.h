#ifndef __INC_SBJKS
#define __INC_SBJKS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbx509.h"
#include "sbrandom.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_E_JKS_FORMAT_ERROR 	1
#define SB_E_JKS_READ_ERROR 	2
#define SB_E_JKS_WRITE_ERROR 	3
#define SB_E_JKS_VERSION_ERROR 	4
#define SB_E_JKS_KEY_FORMAT_ERROR 	5
#define SB_E_JKS_UNKNOWN_CERT 	6
#define SB_E_JKS_CHECKSUM 	7
#define SB_E_JKS_SIGNATURE 	8
#define SB_E_JKS_NO_SPACE 	9

typedef TElClassHandle TElJKSHandle;

typedef TElJKSHandle ElJKSHandle;

#pragma pack(8)
typedef struct 
{
	void * Alias;
	int32_t _dummy0;
	double CreationDate;
#ifdef CPU64
	int32_t _dummy1;
#endif
	void * EncodedKey;
	void * Certificate_Chain;
} TJKSEntry;

typedef void (SB_CALLBACK *TElJKSPasswordEvent)(void * _ObjectData, const char * pcAlias, int32_t szAlias, char * pcPassword, int32_t * szPassword, int8_t * OutResult);

typedef void (SB_CALLBACK *TElJKSAliasNeededEvent)(void * _ObjectData, TElX509CertificateHandle Cert, char * pcAlias, int32_t * szAlias, int8_t * OutResult);

#ifdef SB_USE_CLASS_TELJKS
SB_IMPORT uint32_t SB_APIENTRY TElJKS_LoadFromStream(TElJKSHandle _Handle, TStreamHandle Stream, const char * pcJKS_Pass, int32_t szJKS_Pass, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_LoadFromBuffer(TElJKSHandle _Handle, void * Src_Ptr, int32_t BufferSize, int32_t * BufferPos, const char * pcJKS_Pass, int32_t szJKS_Pass, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_GetSaveBufferSize(TElJKSHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_SaveToStream(TElJKSHandle _Handle, TStreamHandle Stream, const char * pcJKS_Pass, int32_t szJKS_Pass, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_SaveToBuffer(TElJKSHandle _Handle, uint8_t pDstBuffer[], int32_t * szDstBuffer, int32_t BufferSize, int32_t * BufferPos, const char * pcJKS_Pass, int32_t szJKS_Pass, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_GetPrivateKey(TElJKSHandle _Handle, int32_t Index, const char * pcPass, int32_t szPass, uint8_t pKey[], int32_t * szKey, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_SetPrivateKey(TElJKSHandle _Handle, int32_t Index, const char * pcPass, int32_t szPass, const uint8_t pKey[], int32_t szKey, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_AddPrivateKey(TElJKSHandle _Handle, const char * pcPass, int32_t szPass, const uint8_t pKey[], int32_t szKey, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_GetKeyCertificate(TElJKSHandle _Handle, int32_t Index, int32_t Cert_Index, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_AddKeyCertificate(TElJKSHandle _Handle, int32_t Index, TElX509CertificateHandle Cert, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_DelKeyCertificate(TElJKSHandle _Handle, int32_t Index, int32_t Cert_Index);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_GetTrustedCertificate(TElJKSHandle _Handle, int32_t Index, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_AddTrustedCertificate(TElJKSHandle _Handle, TElX509CertificateHandle Cert, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_DelTrustedCertificate(TElJKSHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_GetAlias(TElJKSHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_SetAlias(TElJKSHandle _Handle, int32_t Index, const char * pcAlias, int32_t szAlias);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_get_Entries_Count(TElJKSHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_get_PrivateKeyCert_Count(TElJKSHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_get_IsPrivateKey(TElJKSHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_get_IgnoreBadStorageSignature(TElJKSHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_set_IgnoreBadStorageSignature(TElJKSHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJKS_Create(TElJKSHandle * OutResult);
#endif /* SB_USE_CLASS_TELJKS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TJKSEntry_ce_ptr;
extern zend_class_entry *TElJKS_ce_ptr;

void Register_TJKSEntry(TSRMLS_D);
void SB_CALLBACK TElJKSPasswordEventRaw(void * _ObjectData, const char * pcAlias, int32_t szAlias, char * pcPassword, int32_t * szPassword, int8_t * OutResult);
void SB_CALLBACK TElJKSAliasNeededEventRaw(void * _ObjectData, TElX509CertificateHandle Cert, char * pcAlias, int32_t * szAlias, int8_t * OutResult);
void Register_TElJKS(TSRMLS_D);
void Register_SBJKS_Constants(int module_number TSRMLS_DC);
void Register_SBJKS_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBJKS */
