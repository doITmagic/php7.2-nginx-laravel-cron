#ifndef __INC_SBJNLP
#define __INC_SBJNLP

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbxmlcore.h"
#include "sbxmlcharsets.h"
#include "sbxmldefs.h"
#include "sbutils.h"
#include "sbtypes.h"
#include "sbstreams.h"
#include "sbstrutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_JLNP 	225280
#define SB_JLNP_ERROR_NODE_NOT_FOUND 	225281
#define SB_SNodeNotFound 	"<jnlp> node not found"

typedef TElClassHandle TElJNLPFileHandle;

typedef uint8_t TSBJNLPSecurityValueRaw;

typedef enum
{
	jsvSandbox = 0,
	jsvAllPermissions = 1
} TSBJNLPSecurityValue;

#ifdef SB_USE_CLASS_TELJNLPFILE
SB_IMPORT uint32_t SB_APIENTRY TElJNLPFile_LoadFromStream(TElJNLPFileHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElJNLPFile_SaveToStream(TElJNLPFileHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElJNLPFile_SetSecurity(TElJNLPFileHandle _Handle, TSBJNLPSecurityValueRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElJNLPFile_SetAppletDescParameter(TElJNLPFileHandle _Handle, const char * pcName, int32_t szName, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJNLPFile_get_JnlpElement(TElJNLPFileHandle _Handle, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJNLPFile_get_JnlpCodebase(TElJNLPFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJNLPFile_set_JnlpCodebase(TElJNLPFileHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJNLPFile_get_JnlpHref(TElJNLPFileHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJNLPFile_set_JnlpHref(TElJNLPFileHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJNLPFile_Create(TElJNLPFileHandle * OutResult);
#endif /* SB_USE_CLASS_TELJNLPFILE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElJNLPFile_ce_ptr;

void Register_TElJNLPFile(TSRMLS_D);
void Register_SBJNLP_Constants(int module_number TSRMLS_DC);
void Register_SBJNLP_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBJNLP */

