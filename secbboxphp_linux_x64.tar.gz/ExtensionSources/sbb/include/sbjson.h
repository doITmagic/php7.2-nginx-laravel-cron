#ifndef __INC_SBJSON
#define __INC_SBJSON

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstreams.h"
#include "sbstringlist.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElJsonValueHandle;

typedef TElClassHandle TElJsonArrayHandle;

typedef TElClassHandle TElJsonObjectHandle;

typedef TElClassHandle TElJsonEntityHandle;

typedef uint8_t TSBJsonTypeRaw;

typedef enum
{
	jsonNull = 0,
	jsonBoolean = 1,
	jsonString = 2,
	jsonNumber = 3
} TSBJsonType;

#ifdef SB_USE_CLASS_TELJSONENTITY
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Read(const char * pcText, int32_t szText, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Read_1(TElJsonEntityHandle _Handle, const char * pcText, int32_t szText, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Read_2(const uint8_t pBuffer[], int32_t szBuffer, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Read_3(TElJsonEntityHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Read_4(const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Length, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Read_5(TElJsonEntityHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Length, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Write(TElJsonEntityHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Write_1(TElJsonEntityHandle _Handle, char IndentChar, int32_t CharsPerIndentLevel, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Write_2(TElJsonEntityHandle _Handle, uint8_t pBuffer[], int32_t * szBuffer, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Write_3(TElJsonEntityHandle _Handle, char IndentChar, int32_t CharsPerIndentLevel, uint8_t pBuffer[], int32_t * szBuffer, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Write_4(TElJsonEntityHandle _Handle, TStreamHandle Stream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Write_5(TElJsonEntityHandle _Handle, char IndentChar, int32_t CharsPerIndentLevel, TStreamHandle Stream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Assign(TElJsonEntityHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Clone(TElJsonEntityHandle _Handle, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonEntity_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELJSONENTITY */

#ifdef SB_USE_CLASS_TELJSONARRAY
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Read(const char * pcText, int32_t szText, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Read_1(TElJsonEntityHandle _Handle, const char * pcText, int32_t szText, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Read_2(const uint8_t pBuffer[], int32_t szBuffer, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Read_3(TElJsonEntityHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Read_4(const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Length, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Read_5(TElJsonEntityHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Length, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Write(TElJsonEntityHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Write_1(TElJsonEntityHandle _Handle, char IndentChar, int32_t CharsPerIndentLevel, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Write_2(TElJsonEntityHandle _Handle, uint8_t pBuffer[], int32_t * szBuffer, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Write_3(TElJsonEntityHandle _Handle, char IndentChar, int32_t CharsPerIndentLevel, uint8_t pBuffer[], int32_t * szBuffer, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Write_4(TElJsonEntityHandle _Handle, TStreamHandle Stream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Write_5(TElJsonEntityHandle _Handle, char IndentChar, int32_t CharsPerIndentLevel, TStreamHandle Stream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Assign(TElJsonArrayHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Clone(TElJsonArrayHandle _Handle, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_AssignStringList(TElJsonArrayHandle _Handle, TElStringListHandle Values);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Append(TElJsonArrayHandle _Handle, TElJsonEntityHandle Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Append_1(TElJsonArrayHandle _Handle, int32_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Append_2(TElJsonArrayHandle _Handle, double Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Append_3(TElJsonArrayHandle _Handle, int8_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Append_4(TElJsonArrayHandle _Handle, const char * pcValue, int32_t szValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Append_5(TElJsonArrayHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Clear(TElJsonArrayHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Delete(TElJsonArrayHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_GetArray(TElJsonArrayHandle _Handle, int32_t Index, TElJsonArrayHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_GetArrayIfExists(TElJsonArrayHandle _Handle, int32_t Index, TElJsonArrayHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_GetBooleanValue(TElJsonArrayHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_GetBooleanValue_1(TElJsonArrayHandle _Handle, int32_t Index, int8_t Default, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_GetDoubleValue(TElJsonArrayHandle _Handle, int32_t Index, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_GetDoubleValue_1(TElJsonArrayHandle _Handle, int32_t Index, double Default, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_GetIntegerValue(TElJsonArrayHandle _Handle, int32_t Index, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_GetIntegerValue_1(TElJsonArrayHandle _Handle, int32_t Index, int64_t Default, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_GetObject(TElJsonArrayHandle _Handle, int32_t Index, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_GetObjectIfExists(TElJsonArrayHandle _Handle, int32_t Index, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_GetStringValue(TElJsonArrayHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_GetStringValue_1(TElJsonArrayHandle _Handle, int32_t Index, const char * pcDefault, int32_t szDefault, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Insert(TElJsonArrayHandle _Handle, int32_t Index, TElJsonEntityHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Insert_1(TElJsonArrayHandle _Handle, int32_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Insert_2(TElJsonArrayHandle _Handle, int32_t Index, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Insert_3(TElJsonArrayHandle _Handle, int32_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Insert_4(TElJsonArrayHandle _Handle, int32_t Index, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Insert_5(TElJsonArrayHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_IsNullValue(TElJsonArrayHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_SetBooleanValue(TElJsonArrayHandle _Handle, int32_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_SetDoubleValue(TElJsonArrayHandle _Handle, int32_t Index, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_SetIntegerValue(TElJsonArrayHandle _Handle, int32_t Index, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_SetNullValue(TElJsonArrayHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_SetStringValue(TElJsonArrayHandle _Handle, int32_t Index, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_get_Item(TElJsonArrayHandle _Handle, int32_t Index, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_set_Item(TElJsonArrayHandle _Handle, int32_t Index, const TElJsonEntityHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_get_Length(TElJsonArrayHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_set_Length(TElJsonArrayHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_get_OwnsItems(TElJsonArrayHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Create(int8_t OwnsItems, TElJsonArrayHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Create_1(TElJsonArrayHandle Original, TElJsonArrayHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonArray_Create_2(TElStringListHandle Values, TElJsonArrayHandle * OutResult);
#endif /* SB_USE_CLASS_TELJSONARRAY */

#ifdef SB_USE_CLASS_TELJSONOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Read(const char * pcText, int32_t szText, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Read_1(TElJsonEntityHandle _Handle, const char * pcText, int32_t szText, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Read_2(const uint8_t pBuffer[], int32_t szBuffer, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Read_3(TElJsonEntityHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Read_4(const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Length, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Read_5(TElJsonEntityHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Length, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Write(TElJsonEntityHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Write_1(TElJsonEntityHandle _Handle, char IndentChar, int32_t CharsPerIndentLevel, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Write_2(TElJsonEntityHandle _Handle, uint8_t pBuffer[], int32_t * szBuffer, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Write_3(TElJsonEntityHandle _Handle, char IndentChar, int32_t CharsPerIndentLevel, uint8_t pBuffer[], int32_t * szBuffer, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Write_4(TElJsonEntityHandle _Handle, TStreamHandle Stream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Write_5(TElJsonEntityHandle _Handle, char IndentChar, int32_t CharsPerIndentLevel, TStreamHandle Stream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Assign(TElJsonObjectHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Clone(TElJsonObjectHandle _Handle, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Append(TElJsonObjectHandle _Handle, TElJsonObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_AppendWithFilter(TElJsonObjectHandle _Handle, TElJsonObjectHandle Source, TElStringListHandle Filter);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Clear(TElJsonObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Delete(TElJsonObjectHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_DeleteValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetArray(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, TElJsonArrayHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetArrayIfExists(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, TElJsonArrayHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetBooleanValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetBooleanValue_1(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, int8_t Default, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetDoubleValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetDoubleValue_1(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, double Default, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetIntegerValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetIntegerValue_1(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, int64_t Default, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetObject(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetObjectIfExists(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetNumericDateValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetNumericDateValue_1(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, int64_t Default, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetStringValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetStringValue_1(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, const char * pcDefault, int32_t szDefault, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetValueIfExists(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_IndexOf(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_IsNullValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Remove(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_NameAtIndex(TElJsonObjectHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_ValueAtIndex(TElJsonObjectHandle _Handle, int32_t Index, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_ValueExists(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_SetArray(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, TElJsonArrayHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_SetArray_1(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_SetBooleanValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_SetDoubleValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_SetNullValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_SetIntegerValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_SetNumericDateValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_SetObject(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, TElJsonObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_SetStringValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_SetValue(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, TElJsonEntityHandle AValue);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_GetText(TElJsonObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_SetText(TElJsonObjectHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_get_Count(TElJsonObjectHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_get_SortValues(TElJsonObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_set_SortValues(TElJsonObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_get_OwnsValues(TElJsonObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_get_Text(TElJsonObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_set_Text(TElJsonObjectHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_get_Value(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_set_Value(TElJsonObjectHandle _Handle, const char * pcName, int32_t szName, TElJsonEntityHandle AValue);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Create(int8_t OwnsValues, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonObject_Create_1(TElJsonObjectHandle Original, TElJsonObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELJSONOBJECT */

#ifdef SB_USE_CLASS_TELJSONVALUE
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Read(const char * pcText, int32_t szText, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Read_1(TElJsonEntityHandle _Handle, const char * pcText, int32_t szText, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Read_2(const uint8_t pBuffer[], int32_t szBuffer, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Read_3(TElJsonEntityHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Read_4(const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Length, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Read_5(TElJsonEntityHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Length, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Write(TElJsonEntityHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Write_1(TElJsonEntityHandle _Handle, char IndentChar, int32_t CharsPerIndentLevel, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Write_2(TElJsonEntityHandle _Handle, uint8_t pBuffer[], int32_t * szBuffer, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Write_3(TElJsonEntityHandle _Handle, char IndentChar, int32_t CharsPerIndentLevel, uint8_t pBuffer[], int32_t * szBuffer, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Write_4(TElJsonEntityHandle _Handle, TStreamHandle Stream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Write_5(TElJsonEntityHandle _Handle, char IndentChar, int32_t CharsPerIndentLevel, TStreamHandle Stream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Assign(TElJsonValueHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Clone(TElJsonValueHandle _Handle, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_get_AsBoolean(TElJsonValueHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_set_AsBoolean(TElJsonValueHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_get_AsInteger(TElJsonValueHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_set_AsInteger(TElJsonValueHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_get_AsNumber(TElJsonValueHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_set_AsNumber(TElJsonValueHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_get_AsString(TElJsonValueHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_set_AsString(TElJsonValueHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_get_AsNumericDate(TElJsonValueHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_set_AsNumericDate(TElJsonValueHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_get_IsBoolean(TElJsonValueHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_get_IsNull(TElJsonValueHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_set_IsNull(TElJsonValueHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_get_IsNumber(TElJsonValueHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_get_IsString(TElJsonValueHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_get_Value(TElJsonValueHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_get_ValueType(TElJsonValueHandle _Handle, TSBJsonTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Create(TElJsonValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Create_1(TElJsonValueHandle Original, TElJsonValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Create_2(int8_t Value, TElJsonValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Create_3(double Value, TElJsonValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Create_4(int64_t Value, TElJsonValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJsonValue_Create_5(const char * pcValue, int32_t szValue, TElJsonValueHandle * OutResult);
#endif /* SB_USE_CLASS_TELJSONVALUE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElJsonEntity_ce_ptr;
extern zend_class_entry *TElJsonArray_ce_ptr;
extern zend_class_entry *TElJsonObject_ce_ptr;
extern zend_class_entry *TElJsonValue_ce_ptr;

void Register_TElJsonEntity(TSRMLS_D);
void Register_TElJsonArray(TSRMLS_D);
void Register_TElJsonObject(TSRMLS_D);
void Register_TElJsonValue(TSRMLS_D);
void Register_SBJSON_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBJSON */

