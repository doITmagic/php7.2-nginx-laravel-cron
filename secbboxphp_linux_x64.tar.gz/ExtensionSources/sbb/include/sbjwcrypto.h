#ifndef __INC_SBJWCRYPTO
#define __INC_SBJWCRYPTO

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstringlist.h"
#include "sbconstants.h"
#include "sbencoding.h"
#include "sbjson.h"
#include "sbx509.h"
#include "sbcryptoprov.h"
#include "sbcustomcrypto.h"
#include "sbpublickeycrypto.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElJWTokenHandle;

typedef TElClassHandle TElJWKeyHandle;

typedef TElClassHandle TElJWKeySetHandle;

typedef TElClassHandle TElJWCryptoBaseHandle;

typedef TElClassHandle TElJWTokenClaimsHandle;

typedef TElClassHandle TElJWSignatureHandle;

typedef TElClassHandle TElJWEncryptionHandle;

typedef uint8_t TSBJWKeyUseRaw;

typedef enum
{
	jwuseUnknown = 0,
	jwuseSignature = 1,
	jwuseEncryption = 2
} TSBJWKeyUse;

typedef uint8_t TSBJWKeyTypeRaw;

typedef enum
{
	jwkUnknown = 0,
	jwkEllipticCurve = 1,
	jwkOctetSequence = 2,
	jwkRSA = 3
} TSBJWKeyType;

typedef uint8_t TSBJWECCurveRaw;

typedef enum
{
	jwecUnknown = 0,
	jwecP256 = 1,
	jwecP384 = 2,
	jwecP521 = 3
} TSBJWECCurve;

typedef uint8_t TSBJWSignAlgorithmRaw;

typedef enum
{
	jwsalUnknown = 0,
	jwsalHS256 = 1,
	jwsalHS384 = 2,
	jwsalHS512 = 3,
	jwsalRS256 = 4,
	jwsalRS384 = 5,
	jwsalRS512 = 6,
	jwsalES256 = 7,
	jwsalES384 = 8,
	jwsalES512 = 9,
	jwsalPS256 = 10,
	jwsalPS384 = 11,
	jwsalPS512 = 12,
	jwsalNone = 13
} TSBJWSignAlgorithm;

typedef uint8_t TSBJWEncAlgorithmRaw;

typedef enum
{
	jwealA128CBC_HS256 = 0,
	jwealA192CBC_HS384 = 1,
	jwealA256CBC_HS512 = 2,
	jwealA128GCM = 3,
	jwealA192GCM = 4,
	jwealA256GCM = 5
} TSBJWEncAlgorithm;

typedef uint8_t TSBJWKeyAlgorithmRaw;

typedef enum
{
	jwkalUnknown = 0,
	jwkalDirect = 1,
	jwkalRSA1_5 = 2,
	jwkalRSA_OAEP = 3,
	jwkalRSA_OAEP_256 = 4,
	jwkalA128KW = 5,
	jwkalA192KW = 6,
	jwkalA256KW = 7,
	jwkalECDH_ES = 8,
	jwkalECDH_ES_A128KW = 9,
	jwkalECDH_ES_A192KW = 10,
	jwkalECDH_ES_A256KW = 11,
	jwkalA128GCMKW = 12,
	jwkalA192GCMKW = 13,
	jwkalA256GCMKW = 14,
	jwkalPBES2_HS256_A128KW = 15,
	jwkalPBES2_HS384_A192KW = 16,
	jwkalPBES2_HS512_A256KW = 17
} TSBJWKeyAlgorithm;

typedef uint8_t TSBJWCompressionRaw;

typedef enum
{
	jwcNone = 0,
	jwcDeflate = 1
} TSBJWCompression;

typedef uint8_t TSBJWValidationResultRaw;

typedef enum
{
	jwvrSuccess = 0,
	jwvrInvalidInput = 1,
	jwvrNotSigned = 2,
	jwvrKeyNotFound = 3,
	jwvrInvalidSignature = 4,
	jwvrFailure = 5
} TSBJWValidationResult;

typedef uint8_t TSBJWDecryptionResultRaw;

typedef enum
{
	jwdrSuccess = 0,
	jwdrInvalidInput = 1,
	jwdrKeyNotFound = 2,
	jwdrInvalidAuthTag = 3,
	jwdrInvalidCompression = 4,
	jwdrFailure = 5
} TSBJWDecryptionResult;

#ifdef SB_USE_CLASS_TELJWTOKEN
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_IsValid(TElJWTokenHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_LoadFromJSON(TElJWTokenHandle _Handle, TElJsonObjectHandle AHeader, TElJsonObjectHandle AClaims);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_SaveToJSON(TElJWTokenHandle _Handle, TElJsonObjectHandle AHeader, TElJsonObjectHandle AClaims);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_get_Header(TElJWTokenHandle _Handle, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_get_Claims(TElJWTokenHandle _Handle, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_get_Audience(TElJWTokenHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_set_Audience(TElJWTokenHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_get_Issuer(TElJWTokenHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_set_Issuer(TElJWTokenHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_get_Subject(TElJWTokenHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_set_Subject(TElJWTokenHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_get_ClaimsInHeader(TElJWTokenHandle _Handle, TElJWTokenClaimsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_set_ClaimsInHeader(TElJWTokenHandle _Handle, TElJWTokenClaimsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_get_ID(TElJWTokenHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_set_ID(TElJWTokenHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_get_Expiration(TElJWTokenHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_set_Expiration(TElJWTokenHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_get_IssuedAt(TElJWTokenHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_set_IssuedAt(TElJWTokenHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_get_NotBefore(TElJWTokenHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_set_NotBefore(TElJWTokenHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_get_UseValidity(TElJWTokenHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_set_UseValidity(TElJWTokenHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_get_ValidityBegin(TElJWTokenHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_set_ValidityBegin(TElJWTokenHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_get_ValidityEnd(TElJWTokenHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_set_ValidityEnd(TElJWTokenHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_get_CompactEncoded(TElJWTokenHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWToken_Create(TComponentHandle AOwner, TElJWTokenHandle * OutResult);
#endif /* SB_USE_CLASS_TELJWTOKEN */

#ifdef SB_USE_CLASS_TELJWKEY
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_Assign(TElJWKeyHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_Clear(TElJWKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_Generate(TElJWKeyHandle _Handle, TSBJWKeyTypeRaw KeyType, int32_t Bits);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_GetKeyAlgorithm(TElJWKeyHandle _Handle, TSBJWKeyAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_GetSignAlgorithm(TElJWKeyHandle _Handle, TSBJWSignAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_IsCompatible(TElJWKeyHandle _Handle, TSBJWKeyUseRaw KeyUse, TSBJWKeyTypeRaw KeyType, int32_t Bits, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_LoadFromJSON(TElJWKeyHandle _Handle, TElJsonObjectHandle JSON, TSBJWKeyUseRaw KeyUse, TSBJWKeyTypeRaw KeyType);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_SaveToJSON(TElJWKeyHandle _Handle, int8_t OnlyPublic, int8_t Minimal, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_LoadFromKeyMaterial(TElJWKeyHandle _Handle, TElKeyMaterialHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_SaveToKeyMaterial(TElJWKeyHandle _Handle, TElKeyMaterialHandle Key, int8_t OnlyPublic);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_LoadFromString(TElJWKeyHandle _Handle, const char * pcValue, int32_t szValue, const char * pcPassword, int32_t szPassword, TSBJWKeyUseRaw KeyUse, TSBJWKeyTypeRaw KeyType);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_SaveToString(TElJWKeyHandle _Handle, const char * pcPassword, int32_t szPassword, int8_t OnlyPublic, int8_t Minimal, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_SetOctetSequence(TElJWKeyHandle _Handle, const uint8_t pValue[], int32_t szValue, TSBJWKeyUseRaw KeyUse);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_KeyID(TElJWKeyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_set_KeyID(TElJWKeyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_KeyUse(TElJWKeyHandle _Handle, TSBJWKeyUseRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_set_KeyUse(TElJWKeyHandle _Handle, TSBJWKeyUseRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_KeyType(TElJWKeyHandle _Handle, TSBJWKeyTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_Bits(TElJWKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_IsPublic(TElJWKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_IsSecret(TElJWKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_ECCurve(TElJWKeyHandle _Handle, TSBJWECCurveRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_ECX(TElJWKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_ECY(TElJWKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_ECD(TElJWKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_KeyValue(TElJWKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_Modulus(TElJWKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_Exponent(TElJWKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_PrivateExponent(TElJWKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_FirstPrimeFactor(TElJWKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_SecondPrimeFactor(TElJWKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_FirstFactorCRTExponent(TElJWKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_SecondFactorCRTExponent(TElJWKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_get_FirstCRTCoefficient(TElJWKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKey_Create(TElJWCryptoBaseHandle Crypto, TElJWKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELJWKEY */

#ifdef SB_USE_CLASS_TELJWKEYSET
SB_IMPORT uint32_t SB_APIENTRY TElJWKeySet_Clear(TElJWKeySetHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElJWKeySet_LoadFromJSON(TElJWKeySetHandle _Handle, TElJsonObjectHandle JSON, TSBJWKeyUseRaw KeyUse);
SB_IMPORT uint32_t SB_APIENTRY TElJWKeySet_SaveToJSON(TElJWKeySetHandle _Handle, int8_t OnlyPublic, int8_t Minimal, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKeySet_LoadFromString(TElJWKeySetHandle _Handle, const char * pcValue, int32_t szValue, const char * pcPassword, int32_t szPassword, TSBJWKeyUseRaw KeyUse);
SB_IMPORT uint32_t SB_APIENTRY TElJWKeySet_AddKey(TElJWKeySetHandle _Handle, TElJWKeyHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElJWKeySet_DeleteKey(TElJWKeySetHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElJWKeySet_GetBetterKey(TElJWKeySetHandle _Handle, const char * pcKeyID, int32_t szKeyID, TSBJWKeyUseRaw KeyUse, TSBJWKeyTypeRaw KeyType, int32_t Bits, int32_t Index, TElJWKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKeySet_GetKey(TElJWKeySetHandle _Handle, int32_t Index, TElJWKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKeySet_get_Count(TElJWKeySetHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKeySet_get_Key(TElJWKeySetHandle _Handle, int32_t Index, TElJWKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWKeySet_Create(TElJWCryptoBaseHandle Crypto, TElJWKeySetHandle * OutResult);
#endif /* SB_USE_CLASS_TELJWKEYSET */

#ifdef SB_USE_CLASS_TELJWCRYPTOBASE
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CalcHMACSHA(TElJWCryptoBaseHandle _Handle, int32_t HashAlgID, const uint8_t pKey[], int32_t szKey, const uint8_t pHashInput[], int32_t szHashInput, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CreateKey(TElJWCryptoBaseHandle _Handle, TElJWKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CreateKey_1(TElJWCryptoBaseHandle _Handle, const char * pcValue, int32_t szValue, TElJWKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CreateKey_2(TElJWCryptoBaseHandle _Handle, const char * pcValue, int32_t szValue, int8_t IgnoreKeyUse, TElJWKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CreateKey_3(TElJWCryptoBaseHandle _Handle, const char * pcValue, int32_t szValue, const char * pcPassword, int32_t szPassword, int8_t IgnoreKeyUse, TElJWKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CreateKeyFromJSON(TElJWCryptoBaseHandle _Handle, const TElJsonObjectHandle JSON, TElJWKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CreateKeyFromJSON_1(TElJWCryptoBaseHandle _Handle, const TElJsonObjectHandle JSON, int8_t IgnoreKeyUse, TElJWKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CreateKeySet(TElJWCryptoBaseHandle _Handle, TElJWKeySetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CreateKeySet_1(TElJWCryptoBaseHandle _Handle, const char * pcValue, int32_t szValue, TElJWKeySetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CreateKeySet_2(TElJWCryptoBaseHandle _Handle, const char * pcValue, int32_t szValue, int8_t IgnoreKeyUse, TElJWKeySetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CreateKeySet_3(TElJWCryptoBaseHandle _Handle, const char * pcValue, int32_t szValue, const char * pcPassword, int32_t szPassword, int8_t IgnoreKeyUse, TElJWKeySetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CreateKeySetFromJSON(TElJWCryptoBaseHandle _Handle, const TElJsonObjectHandle JSON, TElJWKeySetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CreateKeySetFromJSON_1(TElJWCryptoBaseHandle _Handle, const TElJsonObjectHandle JSON, int8_t IgnoreKeyUse, TElJWKeySetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CreatePasswordKey(TElJWCryptoBaseHandle _Handle, const uint8_t pPassword[], int32_t szPassword, TElJWKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_CreatePasswordKey_1(TElJWCryptoBaseHandle _Handle, const char * pcPassword, int32_t szPassword, TElJWKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_GetToken(TElJWCryptoBaseHandle _Handle, TElJWTokenHandle Token);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_SetToken(TElJWCryptoBaseHandle _Handle, TElJWTokenHandle Token, int8_t ProtectHeader);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_get_CryptoProviderManager(TElJWCryptoBaseHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_set_CryptoProviderManager(TElJWCryptoBaseHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_get_KeyHeaderParams(TElJWCryptoBaseHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_set_KeyHeaderParams(TElJWCryptoBaseHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_get_ProtectedHeader(TElJWCryptoBaseHandle _Handle, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_set_ProtectedHeader(TElJWCryptoBaseHandle _Handle, TElJsonObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_get_UnprotectedHeader(TElJWCryptoBaseHandle _Handle, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_set_UnprotectedHeader(TElJWCryptoBaseHandle _Handle, TElJsonObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_get_UnprotectedHeaderParams(TElJWCryptoBaseHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_set_UnprotectedHeaderParams(TElJWCryptoBaseHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWCryptoBase_Create(TComponentHandle AOwner, TElJWCryptoBaseHandle * OutResult);
#endif /* SB_USE_CLASS_TELJWCRYPTOBASE */

#ifdef SB_USE_CLASS_TELJWTOKENCLAIMS
SB_IMPORT uint32_t SB_APIENTRY TElJWTokenClaims_get_Audience(TElJWTokenClaimsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWTokenClaims_set_Audience(TElJWTokenClaimsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWTokenClaims_get_Issuer(TElJWTokenClaimsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWTokenClaims_set_Issuer(TElJWTokenClaimsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWTokenClaims_get_Subject(TElJWTokenClaimsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWTokenClaims_set_Subject(TElJWTokenClaimsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWTokenClaims_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELJWTOKENCLAIMS */

#ifdef SB_USE_CLASS_TELJWSIGNATURE
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_SignToCompact(TElJWSignatureHandle _Handle, TElJWKeyHandle Key, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_SignToJSON(TElJWSignatureHandle _Handle, TElJWKeyHandle Key, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_SignToJSON_1(TElJWSignatureHandle _Handle, TElJWKeySetHandle KeySet, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_SignToJSONString(TElJWSignatureHandle _Handle, TElJWKeyHandle Key, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_SignToJSONString_1(TElJWSignatureHandle _Handle, TElJWKeySetHandle KeySet, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_Validate(TElJWSignatureHandle _Handle, const char * pcSource, int32_t szSource, TElJWKeyHandle Key, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_Validate_1(TElJWSignatureHandle _Handle, const char * pcSource, int32_t szSource, TElJWKeySetHandle KeySet, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_Validate_2(TElJWSignatureHandle _Handle, TElJsonObjectHandle Source, TElJWKeyHandle Key, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_Validate_3(TElJWSignatureHandle _Handle, TElJsonObjectHandle Source, TElJWKeySetHandle KeySet, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_get_Payload(TElJWSignatureHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_set_Payload(TElJWSignatureHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_get_PayloadAsJSON(TElJWSignatureHandle _Handle, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_set_PayloadAsJSON(TElJWSignatureHandle _Handle, TElJsonObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_get_PayloadAsString(TElJWSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_set_PayloadAsString(TElJWSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_get_ProtectedHeaders(TElJWSignatureHandle _Handle, TElJsonArrayHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_set_ProtectedHeaders(TElJWSignatureHandle _Handle, TElJsonArrayHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_get_UnprotectedHeaders(TElJWSignatureHandle _Handle, TElJsonArrayHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_set_UnprotectedHeaders(TElJWSignatureHandle _Handle, TElJsonArrayHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_get_ValidationResults(TElJWSignatureHandle _Handle, TSBJWValidationResultRaw pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_get_Algorithm(TElJWSignatureHandle _Handle, TSBJWSignAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_set_Algorithm(TElJWSignatureHandle _Handle, TSBJWSignAlgorithmRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_get_DetachedContent(TElJWSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_set_DetachedContent(TElJWSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_get_AcceptNotSigned(TElJWSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_set_AcceptNotSigned(TElJWSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWSignature_Create(TComponentHandle AOwner, TElJWSignatureHandle * OutResult);
#endif /* SB_USE_CLASS_TELJWSIGNATURE */

#ifdef SB_USE_CLASS_TELJWENCRYPTION
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_Decrypt(TElJWEncryptionHandle _Handle, const char * pcSource, int32_t szSource, TElJWKeyHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_Decrypt_1(TElJWEncryptionHandle _Handle, const char * pcSource, int32_t szSource, TElJWKeySetHandle KeySet);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_Decrypt_2(TElJWEncryptionHandle _Handle, TElJsonObjectHandle Source, TElJWKeyHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_Decrypt_3(TElJWEncryptionHandle _Handle, TElJsonObjectHandle Source, TElJWKeySetHandle KeySet);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_EncryptToCompact(TElJWEncryptionHandle _Handle, TElJWKeyHandle Key, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_EncryptToCompact_1(TElJWEncryptionHandle _Handle, const char * pcPassword, int32_t szPassword, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_EncryptToJSON(TElJWEncryptionHandle _Handle, TElJWKeyHandle Key, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_EncryptToJSON_1(TElJWEncryptionHandle _Handle, TElJWKeySetHandle KeySet, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_EncryptToJSON_2(TElJWEncryptionHandle _Handle, TElJWKeySetHandle KeySet, const TSBJWKeyAlgorithmRaw pKeyAlgorithms[], int32_t szKeyAlgorithms, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_TryDecrypt(TElJWEncryptionHandle _Handle, const char * pcSource, int32_t szSource, TElJWKeyHandle Key, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_TryDecrypt_1(TElJWEncryptionHandle _Handle, const char * pcSource, int32_t szSource, TElJWKeySetHandle KeySet, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_TryDecrypt_2(TElJWEncryptionHandle _Handle, TElJsonObjectHandle Source, TElJWKeyHandle Key, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_TryDecrypt_3(TElJWEncryptionHandle _Handle, TElJsonObjectHandle Source, TElJWKeySetHandle KeySet, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_ActualCompression(TElJWEncryptionHandle _Handle, TSBJWCompressionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_ActualEncAlgorithm(TElJWEncryptionHandle _Handle, TSBJWEncAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_ActualKeyAlgorithm(TElJWEncryptionHandle _Handle, TSBJWKeyAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_AddAuthData(TElJWEncryptionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_AddAuthData(TElJWEncryptionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_AddAuthDataAsJSON(TElJWEncryptionHandle _Handle, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_AddAuthDataAsJSON(TElJWEncryptionHandle _Handle, TElJsonObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_AddAuthDataAsString(TElJWEncryptionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_AddAuthDataAsString(TElJWEncryptionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_ECDH_PartyUInfo(TElJWEncryptionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_ECDH_PartyUInfo(TElJWEncryptionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_ECDH_PartyUInfoAsString(TElJWEncryptionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_ECDH_PartyUInfoAsString(TElJWEncryptionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_ECDH_PartyVInfo(TElJWEncryptionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_ECDH_PartyVInfo(TElJWEncryptionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_ECDH_PartyVInfoAsString(TElJWEncryptionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_ECDH_PartyVInfoAsString(TElJWEncryptionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_PBES2_IterationCount(TElJWEncryptionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_PBES2_IterationCount(TElJWEncryptionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_PBES2_SaltSize(TElJWEncryptionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_PBES2_SaltSize(TElJWEncryptionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_PerRecipientHeaders(TElJWEncryptionHandle _Handle, TElJsonArrayHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_PerRecipientHeaders(TElJWEncryptionHandle _Handle, TElJsonArrayHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_PerRecipientHeaderParams(TElJWEncryptionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_PerRecipientHeaderParams(TElJWEncryptionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_Plaintext(TElJWEncryptionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_Plaintext(TElJWEncryptionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_PlaintextAsJSON(TElJWEncryptionHandle _Handle, TElJsonObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_PlaintextAsJSON(TElJWEncryptionHandle _Handle, TElJsonObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_PlaintextAsString(TElJWEncryptionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_PlaintextAsString(TElJWEncryptionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_Results(TElJWEncryptionHandle _Handle, TSBJWDecryptionResultRaw pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_Compression(TElJWEncryptionHandle _Handle, TSBJWCompressionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_Compression(TElJWEncryptionHandle _Handle, TSBJWCompressionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_EncAlgorithm(TElJWEncryptionHandle _Handle, TSBJWEncAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_EncAlgorithm(TElJWEncryptionHandle _Handle, TSBJWEncAlgorithmRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_get_KeyAlgorithm(TElJWEncryptionHandle _Handle, TSBJWKeyAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_set_KeyAlgorithm(TElJWEncryptionHandle _Handle, TSBJWKeyAlgorithmRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElJWEncryption_Create(TComponentHandle AOwner, TElJWEncryptionHandle * OutResult);
#endif /* SB_USE_CLASS_TELJWENCRYPTION */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElJWToken_ce_ptr;
extern zend_class_entry *TElJWKey_ce_ptr;
extern zend_class_entry *TElJWKeySet_ce_ptr;
extern zend_class_entry *TElJWCryptoBase_ce_ptr;
extern zend_class_entry *TElJWTokenClaims_ce_ptr;
extern zend_class_entry *TElJWSignature_ce_ptr;
extern zend_class_entry *TElJWEncryption_ce_ptr;

void Register_TElJWToken(TSRMLS_D);
void Register_TElJWKey(TSRMLS_D);
void Register_TElJWKeySet(TSRMLS_D);
void Register_TElJWCryptoBase(TSRMLS_D);
void Register_TElJWTokenClaims(TSRMLS_D);
void Register_TElJWSignature(TSRMLS_D);
void Register_TElJWEncryption(TSRMLS_D);
SB_PHP_FUNCTION(SBJWCrypto, Base64UrlEncode);
SB_PHP_FUNCTION(SBJWCrypto, Base64UrlDecode);
void Register_SBJWCrypto_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_JWCRYPTO
SB_IMPORT uint32_t SB_APIENTRY SBJWCrypto_Base64UrlEncode(const char * pcValue, int32_t szValue, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBJWCrypto_Base64UrlDecode(const char * pcValue, int32_t szValue, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_JWCRYPTO */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBJWCRYPTO */

