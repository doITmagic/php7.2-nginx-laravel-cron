#ifndef __INC_SBLDAPCERTRETRIEVER
#define __INC_SBLDAPCERTRETRIEVER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbx509.h"
#include "sbx509ext.h"
#include "sbcertretriever.h"
#include "sbldapscore.h"
#include "sbldapsclient.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElLDAPCertificateRetrieverHandle;

typedef TElLDAPCertificateRetrieverHandle ElLDAPCertificateRetrieverHandle;

typedef TElClassHandle TElLDAPCertificateRetrieverFactoryHandle;

#ifdef SB_USE_CLASS_TELLDAPCERTIFICATERETRIEVER
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertificateRetriever_SupportsLocation(TElLDAPCertificateRetrieverHandle _Handle, TSBGeneralNameRaw NameType, const char * pcURI, int32_t szURI, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertificateRetriever_RetrieveCertificate(TElLDAPCertificateRetrieverHandle _Handle, TElX509CertificateHandle Certificate, TSBGeneralNameRaw NameType, const char * pcURL, int32_t szURL, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertificateRetriever_get_LDAPSClient(TElLDAPCertificateRetrieverHandle _Handle, TElLDAPSClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertificateRetriever_get_ServerList(TElLDAPCertificateRetrieverHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertificateRetriever_Create(TComponentHandle AOwner, TElLDAPCertificateRetrieverHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPCERTIFICATERETRIEVER */

#ifdef SB_USE_CLASS_TELLDAPCERTIFICATERETRIEVERFACTORY
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertificateRetrieverFactory_SupportsLocation(TElLDAPCertificateRetrieverFactoryHandle _Handle, TSBGeneralNameRaw NameType, const char * pcURI, int32_t szURI, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertificateRetrieverFactory_GetClientInstance(TElLDAPCertificateRetrieverFactoryHandle _Handle, TObjectHandle Validator, TElCustomCertificateRetrieverHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertificateRetrieverFactory_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPCERTIFICATERETRIEVERFACTORY */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElLDAPCertificateRetriever_ce_ptr;
extern zend_class_entry *TElLDAPCertificateRetrieverFactory_ce_ptr;

void Register_TElLDAPCertificateRetriever(TSRMLS_D);
void Register_TElLDAPCertificateRetrieverFactory(TSRMLS_D);
SB_PHP_FUNCTION(SBLDAPCertRetriever, RegisterLDAPCertificateRetrieverFactory);
SB_PHP_FUNCTION(SBLDAPCertRetriever, UnregisterLDAPCertificateRetrieverFactory);
void Register_SBLDAPCertRetriever_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_LDAPCERTRETRIEVER
SB_IMPORT uint32_t SB_APIENTRY SBLDAPCertRetriever_RegisterLDAPCertificateRetrieverFactory(void);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPCertRetriever_UnregisterLDAPCertificateRetrieverFactory(void);
#endif /* SB_USE_GLOBAL_PROCS_LDAPCERTRETRIEVER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBLDAPCERTRETRIEVER */

