#ifndef __INC_SBLDAPCERTSTORAGE
#define __INC_SBLDAPCERTSTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcustomcertstorage.h"
#include "sbstringlist.h"
#include "sbstreams.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbx509.h"
#include "sbldapscore.h"
#include "sbldapsclient.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SLDAPSClientNotAssigned 	"You must set LDAPSClient property first"

typedef TElClassHandle TElLDAPCertStorageHandle;

typedef TElLDAPCertStorageHandle ElLDAPCertStorageHandle;

#ifdef SB_USE_CLASS_TELLDAPCERTSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertStorage_Validate(TElLDAPCertStorageHandle _Handle, TElX509CertificateHandle Certificate, TSBCertificateValidityReasonRaw * Reason, int8_t CheckCACertDates, int64_t ValidityMoment, TSBCertificateValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertStorage_Validate_1(TElCustomCertStorageHandle _Handle, TElX509CertificateHandle Certificate, TSBCertificateValidityReasonRaw * Reason, int64_t ValidityMoment, TSBCertificateValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertStorage_Add(TElLDAPCertStorageHandle _Handle, TElX509CertificateHandle X509Certificate, int8_t CopyPrivateKey);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertStorage_Remove(TElLDAPCertStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertStorage_get_LDAPSClient(TElLDAPCertStorageHandle _Handle, TElLDAPSClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertStorage_set_LDAPSClient(TElLDAPCertStorageHandle _Handle, TElLDAPSClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertStorage_get_CertAttributeName(TElLDAPCertStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertStorage_set_CertAttributeName(TElLDAPCertStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCertStorage_Create(TComponentHandle Owner, TElLDAPCertStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPCERTSTORAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElLDAPCertStorage_ce_ptr;

void Register_TElLDAPCertStorage(TSRMLS_D);
void Register_SBLDAPCertStorage_Constants(int module_number TSRMLS_DC);
void Register_SBLDAPCertStorage_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBLDAPCERTSTORAGE */

