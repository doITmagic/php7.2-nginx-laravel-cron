#ifndef __INC_SBLDAPCRL
#define __INC_SBLDAPCRL

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstringlist.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbcrl.h"
#include "sbcrlstorage.h"
#include "sbx509.h"
#include "sbx509ext.h"
#include "sbldapscore.h"
#include "sbldapsclient.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElLDAPCRLRetrieverHandle;

typedef TElClassHandle TElLDAPCRLRetrieverFactoryHandle;

#ifdef SB_USE_CLASS_TELLDAPCRLRETRIEVER
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCRLRetriever_Supports(TElLDAPCRLRetrieverHandle _Handle, TSBGeneralNameRaw NameType, const char * pcLocation, int32_t szLocation, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCRLRetriever_GetCRL(TElLDAPCRLRetrieverHandle _Handle, TElX509CertificateHandle Certificate, TElX509CertificateHandle CACertificate, TSBGeneralNameRaw NameType, const char * pcLocation, int32_t szLocation, TElAbstractCRLHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCRLRetriever_get_LDAPSClient(TElLDAPCRLRetrieverHandle _Handle, TElLDAPSClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCRLRetriever_get_ServerList(TElLDAPCRLRetrieverHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCRLRetriever_set_ServerList(TElLDAPCRLRetrieverHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCRLRetriever_Create(TComponentHandle AOwner, TElLDAPCRLRetrieverHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPCRLRETRIEVER */

#ifdef SB_USE_CLASS_TELLDAPCRLRETRIEVERFACTORY
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCRLRetrieverFactory_Supports(TElLDAPCRLRetrieverFactoryHandle _Handle, TSBGeneralNameRaw NameType, const char * pcLocation, int32_t szLocation, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCRLRetrieverFactory_GetRetrieverInstance(TElLDAPCRLRetrieverFactoryHandle _Handle, TObjectHandle Validator, TElCustomCRLRetrieverHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPCRLRetrieverFactory_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPCRLRETRIEVERFACTORY */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElLDAPCRLRetriever_ce_ptr;
extern zend_class_entry *TElLDAPCRLRetrieverFactory_ce_ptr;

void Register_TElLDAPCRLRetriever(TSRMLS_D);
void Register_TElLDAPCRLRetrieverFactory(TSRMLS_D);
SB_PHP_FUNCTION(SBLDAPCRL, RegisterLDAPCRLRetrieverFactory);
SB_PHP_FUNCTION(SBLDAPCRL, UnregisterLDAPCRLRetrieverFactory);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_LDAPCRL
SB_IMPORT uint32_t SB_APIENTRY SBLDAPCRL_RegisterLDAPCRLRetrieverFactory(void);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPCRL_UnregisterLDAPCRLRetrieverFactory(void);
#endif /* SB_USE_GLOBAL_PROCS_LDAPCRL */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBLDAPCRL */

