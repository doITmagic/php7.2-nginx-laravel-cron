#ifndef __INC_SBLDAPSCLIENT
#define __INC_SBLDAPSCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbsslcommon.h"
#include "sbsimplessl.h"
#include "sbcustomcertstorage.h"
#include "sbsslconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbstringlist.h"
#include "sbencoding.h"
#include "sbsocket.h"
#include "sbsasl.h"
#include "sbldapscore.h"
#include "sbx509.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_LDAP_PORT 	389

typedef TElClassHandle TElLDAPSSearchFilterHandle;

typedef TElLDAPSSearchFilterHandle ElLDAPSSearchFilterHandle;

typedef TElClassHandle TElLDAPResponseHandle;

typedef TElLDAPResponseHandle ElLDAPResponseHandle;

typedef TElClassHandle TElLDAPURLHandle;

typedef TElLDAPURLHandle ElLDAPURLHandle;

typedef TElClassHandle TElLDAPSClientHandle;

typedef TElLDAPSClientHandle ElLDAPSClientHandle;

typedef uint8_t TSBLDAPAuthenticationTypeRaw;

typedef enum
{
	autSimple = 0,
	autSASL = 1
} TSBLDAPAuthenticationType;

typedef uint8_t TSBLDAPSEqualityRaw;

typedef enum
{
	leEqual = 0,
	leNotEqual = 1,
	leAny = 2,
	leContains = 3,
	leDoesNotContain = 4,
	leLessOrEqual = 5,
	leGreaterOrEqual = 6,
	leApproximately = 7
} TSBLDAPSEquality;

typedef uint8_t TSBLDAPSLogicalOperatorRaw;

typedef enum
{
	loAnd = 0,
	loOr = 1
} TSBLDAPSLogicalOperator;

#ifdef SB_USE_CLASS_TELLDAPSSEARCHFILTER
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSSearchFilter_ToString(TElLDAPSSearchFilterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSSearchFilter_AddCondition(TElLDAPSSearchFilterHandle _Handle, TSBLDAPSLogicalOperatorRaw LogicalOperator, const char * pcAttribute, int32_t szAttribute, TSBLDAPSEqualityRaw Equality, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSSearchFilter_get_IsEmpty(TElLDAPSSearchFilterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSSearchFilter_Create(TElLDAPSSearchFilterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSSearchFilter_Create_1(TSBLDAPSLogicalOperatorRaw LogicalOperator, const char * pcAttribute, int32_t szAttribute, TSBLDAPSEqualityRaw Equality, const char * pcValue, int32_t szValue, TElLDAPSSearchFilterHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPSSEARCHFILTER */

#ifdef SB_USE_CLASS_TELLDAPRESPONSE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResponse_Add(TElLDAPResponseHandle _Handle, TElLDAPMessageHandle * Msg);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResponse_Remove(TElLDAPResponseHandle _Handle, TElLDAPMessageHandle * Msg);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResponse_get_Messages(TElLDAPResponseHandle _Handle, int32_t Index, TElLDAPMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResponse_get_Count(TElLDAPResponseHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResponse_Create(TElLDAPResponseHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPRESPONSE */

#ifdef SB_USE_CLASS_TELLDAPURL
SB_IMPORT uint32_t SB_APIENTRY TElLDAPURL_get_URL(TElLDAPURLHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPURL_get_Host(TElLDAPURLHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPURL_get_Port(TElLDAPURLHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPURL_get_DN(TElLDAPURLHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPURL_get_Attributes(TElLDAPURLHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPURL_get_Scope(TElLDAPURLHandle _Handle, TSBLDAPScopeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPURL_get_Filter(TElLDAPURLHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPURL_get_Extensions(TElLDAPURLHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPURL_Create(const char * pcURL, int32_t szURL, TElLDAPURLHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPURL */

#ifdef SB_USE_CLASS_TELLDAPSCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_Bind(TElLDAPSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_Unbind(TElLDAPSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_Search(TElLDAPSClientHandle _Handle, const char * pcBaseDN, int32_t szBaseDN, TSBLDAPScopeRaw Scope, const char * pcFilter, int32_t szFilter, const TStringListHandle Attrs, int8_t AttrsOnly, TElLDAPResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_Search_1(TElLDAPSClientHandle _Handle, const char * pcBaseDN, int32_t szBaseDN, TSBLDAPScopeRaw Scope, const TElLDAPSSearchFilterHandle Filter, const TStringListHandle Attrs, int8_t AttrsOnly, TElLDAPResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_Search_2(TElLDAPSClientHandle _Handle, TElLDAPResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_SearchURL(const char * pcURL, int32_t szURL, TElLDAPResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_SearchURL_1(TElLDAPSClientHandle _Handle, const char * pcURL, int32_t szURL, TElLDAPResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_Remove(TElLDAPSClientHandle _Handle, const char * pcDN, int32_t szDN);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_Add(TElLDAPSClientHandle _Handle, const char * pcDN, int32_t szDN, const TElLDAPPartialAttributeHandle pAttrs[], int32_t szAttrs);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_Modify(TElLDAPSClientHandle _Handle, const char * pcDN, int32_t szDN, const TElLDAPPartialAttributeHandle pAttrs[], int32_t szAttrs);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_get_ReceiveTimeout(TElLDAPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_set_ReceiveTimeout(TElLDAPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_get_LDAPDN(TElLDAPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_set_LDAPDN(TElLDAPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_get_Password(TElLDAPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_set_Password(TElLDAPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_get_AuthType(TElLDAPSClientHandle _Handle, TSBLDAPAuthenticationTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_set_AuthType(TElLDAPSClientHandle _Handle, TSBLDAPAuthenticationTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_get_SASLMechanism(TElLDAPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_set_SASLMechanism(TElLDAPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_get_BaseDN(TElLDAPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_set_BaseDN(TElLDAPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_get_Scope(TElLDAPSClientHandle _Handle, TSBLDAPScopeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_set_Scope(TElLDAPSClientHandle _Handle, TSBLDAPScopeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_get_Filter(TElLDAPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_set_Filter(TElLDAPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_get_Attributes(TElLDAPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_set_Attributes(TElLDAPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_get_AttributesOnly(TElLDAPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_set_AttributesOnly(TElLDAPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSClient_Create(TComponentHandle AOwner, TElLDAPSClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPSCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElLDAPSSearchFilter_ce_ptr;
extern zend_class_entry *TElLDAPResponse_ce_ptr;
extern zend_class_entry *TElLDAPURL_ce_ptr;
extern zend_class_entry *TElLDAPSClient_ce_ptr;

void Register_TElLDAPSSearchFilter(TSRMLS_D);
void Register_TElLDAPResponse(TSRMLS_D);
void Register_TElLDAPURL(TSRMLS_D);
void Register_TElLDAPSClient(TSRMLS_D);
void Register_SBLDAPSClient_Constants(int module_number TSRMLS_DC);
void Register_SBLDAPSClient_Enum_Flags(TSRMLS_D);
void Register_SBLDAPSClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBLDAPSCLIENT */

