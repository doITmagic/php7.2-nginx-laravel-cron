#ifndef __INC_SBLDAPSCORE
#define __INC_SBLDAPSCORE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbsslcommon.h"
#include "sbsimplessl.h"
#include "sbcustomcertstorage.h"
#include "sbsslconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbsocket.h"
#include "sbstringlist.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifndef SB_SInternalError
#define SB_SInternalError 	"Internal error: %s"
#endif
#define SB_SWrongMessageError 	"Wrong message content"
#define SB_SBindError 	"Bind operation failed"
#define SB_SSASLError 	"SASL error"
#define SB_SWrongResponse 	"Wrong server response message"
#define SB_SServerError 	"Server returned error %d"
#define SB_SNotImplemented 	"Not implemented"
#define SB_SInvalidFilterString 	"Invalid filter string"
#define SB_SInvalidFilterSequence 	"Invalid filters sequence"
#define SB_SInvalidLdapUrl 	"Invalid LDAP URL %s"
#define SB_SWrongParameter 	"Invalid function parameter"
#define SB_LDAP_VERSION 	3
#define SB_LDAP_UNKNOWN 	-1
#define SB_LDAP_REQ_BIND 	96
#define SB_LDAP_REQ_UNBIND 	66
#define SB_LDAP_REQ_SEARCH 	99
#define SB_LDAP_REQ_MODIFY 	102
#define SB_LDAP_REQ_ADD 	104
#define SB_LDAP_REQ_DELETE 	74
#define SB_LDAP_REQ_MODDN 	108
#define SB_LDAP_REQ_MODRDN 	108
#define SB_LDAP_REQ_RENAME 	108
#define SB_LDAP_REQ_COMPARE 	110
#define SB_LDAP_REQ_ABANDON 	80
#define SB_LDAP_REQ_EXTENDED 	119
#define SB_LDAP_RES_BIND 	97
#define SB_LDAP_RES_SEARCH_ENTRY 	100
#define SB_LDAP_RES_SEARCH_REFERENCE 	115
#define SB_LDAP_RES_SEARCH_RESULT 	101
#define SB_LDAP_RES_MODIFY 	103
#define SB_LDAP_RES_ADD 	105
#define SB_LDAP_RES_DELETE 	107
#define SB_LDAP_RES_MODDN 	109
#define SB_LDAP_RES_MODRDN 	109
#define SB_LDAP_RES_RENAME 	109
#define SB_LDAP_RES_COMPARE 	111
#define SB_LDAP_RES_EXTENDED 	120
#define SB_LDAP_RES_INTERMEDIATE 	121
#define SB_LDAP_FILTER_AND 	160
#define SB_LDAP_FILTER_OR 	161
#define SB_LDAP_FILTER_NOT 	162
#define SB_LDAP_FILTER_EQUALITY 	163
#define SB_LDAP_FILTER_SUBSTRINGS 	164
#define SB_LDAP_FILTER_GE 	165
#define SB_LDAP_FILTER_LE 	166
#define SB_LDAP_FILTER_PRESENT 	135
#define SB_LDAP_FILTER_APPROX 	168
#define SB_LDAP_FILTER_EXT 	169
#define SB_LDAP_FILTER_EXT_OID 	129
#define SB_LDAP_FILTER_EXT_TYPE 	130
#define SB_LDAP_FILTER_EXT_VALUE 	131
#define SB_LDAP_FILTER_EXT_DNATTRS 	132
#define SB_LDAP_SUBSTRING_INITIAL 	128
#define SB_LDAP_SUBSTRING_ANY 	129
#define SB_LDAP_SUBSTRING_FINAL 	130
#define SB_LDAP_RESULT_SUCCESS 	0
#define SB_LDAP_RESULT_OPERATIONS_ERROR 	1
#define SB_LDAP_RESULT_PROTOCOL_ERROR 	2
#define SB_LDAP_RESULT_TIME_LIMIT 	3
#define SB_LDAP_RESULT_SIZE_LIMIT 	4
#define SB_LDAP_RESULT_COMPARE_FALSE 	5
#define SB_LDAP_RESULT_COMPARE_TRUE 	6
#define SB_LDAP_RESULT_AUTH_METHOD_NOT_SUPPORTED 	7
#define SB_LDAP_RESULT_STRONGER_AUTH_REQUIRED 	8
#define SB_LDAP_RESULT_REFERRAL 	10
#define SB_LDAP_RESULT_ADMIN_LIMIT 	11
#define SB_LDAP_RESULT_UNAVALIABLE_CRITICAL_EXTENSION 	12
#define SB_LDAP_RESULT_CONFIDENTIALITY_REQUIRED 	13
#define SB_LDAP_RESULT_SASL_BIND_IN_PROGRESS 	14
#define SB_LDAP_RESULT_NO_SUCH_ATTRIBUTE 	16
#define SB_LDAP_RESULT_UNDEFINED_ATTRIBUTE_TYPE 	17
#define SB_LDAP_RESULT_INAPPROPRIATE_MATCHING 	18
#define SB_LDAP_RESULT_CONSTRAINT_VIOLATION 	19
#define SB_LDAP_RESULT_ATTRIBUTE_OR_VALUE_EXISTS 	20
#define SB_LDAP_RESULT_INVALID_ATTRIBUTE_SYNTAX 	21
#define SB_LDAP_RESULT_NO_SUCH_OBJECT 	32
#define SB_LDAP_RESULT_ALIAS_PROBLEM 	33
#define SB_LDAP_RESULT_INVALID_DN_SYNTAX 	34
#define SB_LDAP_RESULT_ALIAS_DEREFERENCING_PROBLEM 	36
#define SB_LDAP_RESULT_INAPPROPRIATE_AUTHENTICATION 	48
#define SB_LDAP_RESULT_INVALID_CREDENTIALS 	49
#define SB_LDAP_RESULT_INSUFFICIENT_ACCESS_RIGHTS 	50
#define SB_LDAP_RESULT_BUSY 	51
#define SB_LDAP_RESULT_UNAVAILABLE 	52
#define SB_LDAP_RESULT_UNWILLING_TO_PERFORM 	53
#define SB_LDAP_RESULT_LOOP_DETECT 	54
#define SB_LDAP_RESULT_NAMING_VIOLATION 	64
#define SB_LDAP_RESULT_OBJECT_CLASS_VIOLATION 	65
#define SB_LDAP_RESULT_NOT_ALLOWED_ON_NON_LEAF 	66
#define SB_LDAP_RESULT_NOT_ALLOWED_ON_RDN 	67
#define SB_LDAP_RESULT_ENTRY_ALREADY_EXISTS 	68
#define SB_LDAP_RESULT_OBJECT_CLASS_MODS_PROHIBITED 	69
#define SB_LDAP_RESULT_AFFECTS_MULTIPLE_DSAS 	71
#define SB_LDAP_RESULT_OTHER 	80
#define SB_LDAP_ERROR_INTERNAL 	81
#define SB_LDAP_ERROR_WRONG_MESSAGE 	82
#define SB_LDAP_ERROR_WRONG_RESPONSE 	83
#define SB_LDAP_ERROR_WRONG_LDAP_URL 	84
#define SB_LDAP_ERROR_SERVER_ERROR 	85
#define SB_LDAP_ERROR_AUTH_ERROR 	86
#define SB_LDAP_SOURCE_BIND 	1
#define SB_LDAP_SOURCE_SEARCH 	2
#define SB_LDAP_SOURCE_SEARCH_FILTER 	3
#define SB_LDAP_SOURCE_FILTER_SEQUENCE 	4
#define SB_LDAP_SOURCE_GET_RESPONSE 	5
#define SB_LDAP_SOURCE_SASL 	6
#define SB_LDAP_SOURCE_DELETE 	8
#define SB_LDAP_SOURCE_ADD 	9
#define SB_LDAP_SOURCE_MODIFY 	10

typedef TElClassHandle TElLDAPMessageHandle;

typedef TElLDAPMessageHandle ElLDAPMessageHandle;

typedef TElClassHandle TElLDAPSimpleBindMessageHandle;

typedef TElLDAPSimpleBindMessageHandle ElLDAPSimpleBindMessageHandle;

typedef TElClassHandle TElLDAPSASLBindMessageHandle;

typedef TElLDAPSASLBindMessageHandle ElLDAPSASLBindMessageHandle;

typedef TElClassHandle TElLDAPUnbindMessageHandle;

typedef TElLDAPUnbindMessageHandle ElLDAPUnbindMessageHandle;

typedef TElClassHandle TElLDAPResultHandle;

typedef TElLDAPResultHandle ElLDAPResultHandle;

typedef TElClassHandle TElLDAPResultMessageHandle;

typedef TElLDAPResultMessageHandle ElLDAPResultMessageHandle;

typedef TElLDAPResultMessageHandle TElLDAPSearchResultDoneMessageHandle;

typedef TElLDAPResultMessageHandle ElLDAPSearchResultDoneMessageHandle;

typedef TElClassHandle TElLDAPBindResponseMessageHandle;

typedef TElLDAPBindResponseMessageHandle ElLDAPBindResponseMessageHandle;

typedef TElClassHandle TElLDAPSearchMessageHandle;

typedef TElLDAPSearchMessageHandle ElLDAPSearchMessageHandle;

typedef TElClassHandle TElLDAPAttributeValueHandle;

typedef TElLDAPAttributeValueHandle ElLDAPAttributeValueHandle;

typedef TElClassHandle TElLDAPPartialAttributeHandle;

typedef TElLDAPPartialAttributeHandle ElLDAPPartialAttributeHandle;

typedef TElLDAPPartialAttributeHandle TElLDAPAttributeHandle;

typedef TElLDAPPartialAttributeHandle ElLDAPAttributeHandle;

typedef TElClassHandle TElLDAPSearchEntryMessageHandle;

typedef TElLDAPSearchEntryMessageHandle ElLDAPSearchEntryMessageHandle;

typedef TElClassHandle TElLDAPSearchReferenceMessageHandle;

typedef TElLDAPSearchReferenceMessageHandle ElLDAPSearchReferenceMessageHandle;

typedef TElClassHandle TElLDAPDeleteMessageHandle;

typedef TElLDAPDeleteMessageHandle ElLDAPDeleteMessageHandle;

typedef TElLDAPResultMessageHandle TElLDAPDeleteResponseMessageHandle;

typedef TElLDAPResultMessageHandle ElLDAPDeleteResponseMessageHandle;

typedef TElClassHandle TElLDAPModifyMessageHandle;

typedef TElLDAPModifyMessageHandle ElLDAPModifyMessageHandle;

typedef TElLDAPModifyMessageHandle TElLDAPAddMessageHandle;

typedef TElLDAPModifyMessageHandle ElLDAPAddMessageHandle;

typedef TElLDAPResultMessageHandle TElLDAPAddResponseMessageHandle;

typedef TElLDAPResultMessageHandle ElLDAPAddResponseMessageHandle;

typedef TElLDAPResultMessageHandle TElLDAPModifyResponseMessageHandle;

typedef TElLDAPResultMessageHandle ElLDAPModifyResponseMessageHandle;

typedef uint8_t TSBLDAPScopeRaw;

typedef enum
{
	scBase = 0,
	scOneLevel = 1,
	scSubTree = 2
} TSBLDAPScope;

typedef uint8_t TSBLDAPModifyOperationRaw;

typedef enum
{
	moNone = 0,
	moAdd = 1,
	moDelete = 2,
	moReplace = 3
} TSBLDAPModifyOperation;

#ifdef SB_USE_CLASS_TELLDAPMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPMessage_SaveToBuffer(TElLDAPMessageHandle _Handle, void * Buf, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPMessage_get_Code(TElLDAPMessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPMessage_get_ID(TElLDAPMessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPMessage_Create(TElLDAPMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPMessage_Create_1(int32_t MessageID, int32_t Code, TElLDAPMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPMESSAGE */

#ifdef SB_USE_CLASS_TELLDAPSIMPLEBINDMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSimpleBindMessage_Create(int32_t MessageID, const char * pcLDAPDN, int32_t szLDAPDN, const char * pcPassword, int32_t szPassword, TElLDAPSimpleBindMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPSIMPLEBINDMESSAGE */

#ifdef SB_USE_CLASS_TELLDAPSASLBINDMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSASLBindMessage_Create(int32_t MessageID, const char * pcLDAPDN, int32_t szLDAPDN, const char * pcPassword, int32_t szPassword, const char * pcMechanism, int32_t szMechanism, const uint8_t pCredentials[], int32_t szCredentials, int32_t CredLen, TElLDAPSASLBindMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPSASLBINDMESSAGE */

#ifdef SB_USE_CLASS_TELLDAPUNBINDMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPUnbindMessage_Create(int32_t MessageID, TElLDAPUnbindMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPUNBINDMESSAGE */

#ifdef SB_USE_CLASS_TELLDAPRESULT
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResult_get_ResultCode(TElLDAPResultHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResult_get_MatchedDN(TElLDAPResultHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResult_get_DiagnosticMessage(TElLDAPResultHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResult_get_Referal(TElLDAPResultHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResult_get_HasReferal(TElLDAPResultHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResult_get_Success(TElLDAPResultHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResult_Create(TElASN1ConstrainedTagHandle * Tag, TElLDAPResultHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPRESULT */

#ifdef SB_USE_CLASS_TELLDAPRESULTMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResultMessage_get_ResultCode(TElLDAPResultMessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResultMessage_get_MatchedDN(TElLDAPResultMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResultMessage_get_DiagnosticMessage(TElLDAPResultMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResultMessage_get_Referal(TElLDAPResultMessageHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResultMessage_get_HasReferal(TElLDAPResultMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResultMessage_get_Success(TElLDAPResultMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPResultMessage_Create(void * Buf, int32_t Size, TElLDAPResultMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPRESULTMESSAGE */

#ifdef SB_USE_CLASS_TELLDAPBINDRESPONSEMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPBindResponseMessage_get_ResultCode(TElLDAPBindResponseMessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPBindResponseMessage_get_MatchedDN(TElLDAPBindResponseMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPBindResponseMessage_get_DiagnosticMessage(TElLDAPBindResponseMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPBindResponseMessage_get_Referal(TElLDAPBindResponseMessageHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPBindResponseMessage_get_HasReferal(TElLDAPBindResponseMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPBindResponseMessage_get_Success(TElLDAPBindResponseMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPBindResponseMessage_get_ServerSaslCreds(TElLDAPBindResponseMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPBindResponseMessage_Create(void * Buf, int32_t Size, TElLDAPBindResponseMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPBINDRESPONSEMESSAGE */

#ifdef SB_USE_CLASS_TELLDAPSEARCHMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSearchMessage_Create(int32_t MessageID, const char * pcBaseDN, int32_t szBaseDN, TSBLDAPScopeRaw Scope, const char * pcFilter, int32_t szFilter, const TStringListHandle Attrs, int8_t AttrsOnly, TElLDAPSearchMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPSEARCHMESSAGE */

#ifdef SB_USE_CLASS_TELLDAPATTRIBUTEVALUE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPAttributeValue_ToString(TElLDAPAttributeValueHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPAttributeValue_get_Value(TElLDAPAttributeValueHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPAttributeValue_set_Value(TElLDAPAttributeValueHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPAttributeValue_Create(const uint8_t pValue[], int32_t szValue, TElLDAPAttributeValueHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPATTRIBUTEVALUE */

#ifdef SB_USE_CLASS_TELLDAPPARTIALATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPPartialAttribute_Add(TElLDAPPartialAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPPartialAttribute_Add_1(TElLDAPPartialAttributeHandle _Handle, const TElLDAPAttributeValueHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPPartialAttribute_Save(TElLDAPPartialAttributeHandle _Handle, TElASN1ConstrainedTagHandle * Tag);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPPartialAttribute_get_Operation(TElLDAPPartialAttributeHandle _Handle, TSBLDAPModifyOperationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPPartialAttribute_get_Binary(TElLDAPPartialAttributeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPPartialAttribute_get_Type_(TElLDAPPartialAttributeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPPartialAttribute_get_Count(TElLDAPPartialAttributeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPPartialAttribute_get_Values(TElLDAPPartialAttributeHandle _Handle, int32_t Index, TElLDAPAttributeValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPPartialAttribute_Create(const char * pcType_, int32_t szType_, TSBLDAPModifyOperationRaw Operation, TElLDAPPartialAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPPartialAttribute_Create_1(TElASN1ConstrainedTagHandle * Tag, TElLDAPPartialAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPPARTIALATTRIBUTE */

#ifdef SB_USE_CLASS_TELLDAPSEARCHENTRYMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSearchEntryMessage_get_ObjectName(TElLDAPSearchEntryMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSearchEntryMessage_get_Count(TElLDAPSearchEntryMessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSearchEntryMessage_get_Attributes(TElLDAPSearchEntryMessageHandle _Handle, int32_t Index, TElLDAPPartialAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSearchEntryMessage_get_ByType(TElLDAPSearchEntryMessageHandle _Handle, const char * pcIndex, int32_t szIndex, TElLDAPPartialAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSearchEntryMessage_Create(void * Buf, int32_t Size, TElLDAPSearchEntryMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPSEARCHENTRYMESSAGE */

#ifdef SB_USE_CLASS_TELLDAPSEARCHREFERENCEMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSearchReferenceMessage_get_URIs(TElLDAPSearchReferenceMessageHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSearchReferenceMessage_Create(void * Buf, int32_t Size, TElLDAPSearchReferenceMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPSEARCHREFERENCEMESSAGE */

#ifdef SB_USE_CLASS_TELLDAPDELETEMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPDeleteMessage_Create(int32_t MessageID, const char * pcLDAPDN, int32_t szLDAPDN, TElLDAPDeleteMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPDELETEMESSAGE */

#ifdef SB_USE_CLASS_TELLDAPMODIFYMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElLDAPModifyMessage_Create(int32_t MessageID, const char * pcDN, int32_t szDN, const TElLDAPPartialAttributeHandle pAttributes[], int32_t szAttributes, TElLDAPModifyMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPMODIFYMESSAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElLDAPMessage_ce_ptr;
extern zend_class_entry *TElLDAPSimpleBindMessage_ce_ptr;
extern zend_class_entry *TElLDAPSASLBindMessage_ce_ptr;
extern zend_class_entry *TElLDAPUnbindMessage_ce_ptr;
extern zend_class_entry *TElLDAPResult_ce_ptr;
extern zend_class_entry *TElLDAPResultMessage_ce_ptr;
extern zend_class_entry *TElLDAPBindResponseMessage_ce_ptr;
extern zend_class_entry *TElLDAPSearchMessage_ce_ptr;
extern zend_class_entry *TElLDAPAttributeValue_ce_ptr;
extern zend_class_entry *TElLDAPPartialAttribute_ce_ptr;
extern zend_class_entry *TElLDAPSearchEntryMessage_ce_ptr;
extern zend_class_entry *TElLDAPSearchReferenceMessage_ce_ptr;
extern zend_class_entry *TElLDAPDeleteMessage_ce_ptr;
extern zend_class_entry *TElLDAPModifyMessage_ce_ptr;

void Register_TElLDAPMessage(TSRMLS_D);
void Register_TElLDAPSimpleBindMessage(TSRMLS_D);
void Register_TElLDAPSASLBindMessage(TSRMLS_D);
void Register_TElLDAPUnbindMessage(TSRMLS_D);
void Register_TElLDAPResult(TSRMLS_D);
void Register_TElLDAPResultMessage(TSRMLS_D);
void Register_TElLDAPBindResponseMessage(TSRMLS_D);
void Register_TElLDAPSearchMessage(TSRMLS_D);
void Register_TElLDAPAttributeValue(TSRMLS_D);
void Register_TElLDAPPartialAttribute(TSRMLS_D);
void Register_TElLDAPSearchEntryMessage(TSRMLS_D);
void Register_TElLDAPSearchReferenceMessage(TSRMLS_D);
void Register_TElLDAPDeleteMessage(TSRMLS_D);
void Register_TElLDAPModifyMessage(TSRMLS_D);
SB_PHP_FUNCTION(SBLDAPSCore, AttrFromString);
SB_PHP_FUNCTION(SBLDAPSCore, AttrFromBuffer);
SB_PHP_FUNCTION(SBLDAPSCore, PutSimpleFilter);
SB_PHP_FUNCTION(SBLDAPSCore, PutSubstringFilter);
SB_PHP_FUNCTION(SBLDAPSCore, SplitValue);
SB_PHP_FUNCTION(SBLDAPSCore, PutFilterList);
SB_PHP_FUNCTION(SBLDAPSCore, IsDigit);
SB_PHP_FUNCTION(SBLDAPSCore, IsHexLower);
SB_PHP_FUNCTION(SBLDAPSCore, IsHexUpper);
SB_PHP_FUNCTION(SBLDAPSCore, IsHex);
SB_PHP_FUNCTION(SBLDAPSCore, IsLower);
SB_PHP_FUNCTION(SBLDAPSCore, IsUpper);
SB_PHP_FUNCTION(SBLDAPSCore, IsAlpha);
SB_PHP_FUNCTION(SBLDAPSCore, IsAlnum);
SB_PHP_FUNCTION(SBLDAPSCore, IsLdh);
SB_PHP_FUNCTION(SBLDAPSCore, IsSpace);
SB_PHP_FUNCTION(SBLDAPSCore, Hex2Value);
SB_PHP_FUNCTION(SBLDAPSCore, GetMessageLenSize);
SB_PHP_FUNCTION(SBLDAPSCore, GetMessageLen);
SB_PHP_FUNCTION(SBLDAPSCore, GetMessageType);
void Register_SBLDAPSCore_Constants(int module_number TSRMLS_DC);
void Register_SBLDAPSCore_Enum_Flags(TSRMLS_D);
void Register_SBLDAPSCore_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_LDAPSCORE
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_AttrFromString(const char * pcType_, int32_t szType_, const char * pcValue, int32_t szValue, TSBLDAPModifyOperationRaw Operation, TElLDAPPartialAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_AttrFromBuffer(const char * pcType_, int32_t szType_, const uint8_t pValue[], int32_t szValue, TSBLDAPModifyOperationRaw Operation, TElLDAPPartialAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_PutSimpleFilter(TElASN1ConstrainedTagHandle * Tag, const char * pcs, int32_t szs);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_PutSubstringFilter(TElASN1ConstrainedTagHandle * Tag, int32_t TagId, const char * pcType_, int32_t szType_, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_SplitValue(TElStringListHandle * List, const char * pcs, int32_t szs);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_PutFilterList(TElASN1ConstrainedTagHandle * Tag, const char * pcs, int32_t szs);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_IsDigit(char c, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_IsHexLower(char c, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_IsHexUpper(char c, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_IsHex(char c, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_IsLower(char c, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_IsUpper(char c, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_IsAlpha(char c, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_IsAlnum(char c, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_IsLdh(char c, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_IsSpace(char c, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_Hex2Value(char c, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_GetMessageLenSize(uint8_t pBuf[], int32_t * szBuf, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_GetMessageLen(uint8_t pBuf[], int32_t * szBuf, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBLDAPSCore_GetMessageType(uint8_t pBuf[], int32_t * szBuf, int32_t Size, int32_t * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_LDAPSCORE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBLDAPSCORE */

