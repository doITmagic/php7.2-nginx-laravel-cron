#ifndef __INC_SBLDAPSKEYSERVERCLIENT
#define __INC_SBLDAPSKEYSERVERCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbsslcommon.h"
#include "sbsimplessl.h"
#include "sbcustomcertstorage.h"
#include "sbsslconstants.h"
#include "sbstringlist.h"
#include "sbstreams.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbsocket.h"
#include "sbpgpkeys.h"
#include "sbpgpconstants.h"
#include "sbpgputils.h"
#include "sbsasl.h"
#include "sbldapscore.h"
#include "sbldapsclient.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SUnknownBaseKeyspaceDN 	"Can not get base keyspace DN"
#define SB_SWrongSearchParam 	"Wrong search parameter (%s)"
#define SB_SNoSearchConditions 	"Can not use search filter without conditions"
#define SB_LDAP_KEYSERVER_CLIENT_ERROR_BASE 	0
#define SB_LDAP_KEYSERVER_CLIENT_NO_BASE_DN 	1
#define SB_LDAP_KEYSERVER_WRONG_SEARCH_PARAM 	2
#define SB_LDAP_KEYSERVER_NO_SEARCH_CONDITIONS 	3

typedef TElClassHandle TElLDAPSKeyserverSearchFilterHandle;

typedef TElLDAPSKeyserverSearchFilterHandle ElLDAPSKeyserverSearchFilterHandle;

typedef TElClassHandle TElLDAPSKeyserverClientHandle;

typedef TElLDAPSKeyserverClientHandle ElLDAPSKeyserverClientHandle;

typedef uint8_t TSBLDAPSKeyserverAttributeRaw;

typedef enum
{
	lkaCertID = 0,
	lkaDisabled = 1,
	lkaKeyID = 2,
	lkaKeyType = 3,
	lkaUserID = 4,
	lkaKeyCreateTime = 5,
	lkaSignerID = 6,
	lkaRevoked = 7,
	lkaSubKeyID = 8,
	lkaSubKeyID32 = 9,
	lkaKeySize = 10,
	lkaKeyExpireTime = 11
} TSBLDAPSKeyserverAttribute;

typedef uint8_t TSBSearchRequestTypeRaw;

typedef enum
{
	srtEmail = 0,
	srtShortID = 1,
	srtLongID = 2
} TSBSearchRequestType;

#ifdef SB_USE_CLASS_TELLDAPSKEYSERVERSEARCHFILTER
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverSearchFilter_AddCondition(TElLDAPSKeyserverSearchFilterHandle _Handle, TSBLDAPSLogicalOperatorRaw LogicalOperator, TSBLDAPSKeyserverAttributeRaw Attribute, TSBLDAPSEqualityRaw Equality, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverSearchFilter_AddCondition_1(TElLDAPSSearchFilterHandle _Handle, TSBLDAPSLogicalOperatorRaw LogicalOperator, const char * pcAttribute, int32_t szAttribute, TSBLDAPSEqualityRaw Equality, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverSearchFilter_Create(TElLDAPSKeyserverSearchFilterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverSearchFilter_Create_1(TSBLDAPSLogicalOperatorRaw LogicalOperator, TSBLDAPSKeyserverAttributeRaw Attribute, TSBLDAPSEqualityRaw Equality, const char * pcValue, int32_t szValue, TElLDAPSKeyserverSearchFilterHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPSKEYSERVERSEARCHFILTER */

#ifdef SB_USE_CLASS_TELLDAPSKEYSERVERCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_Search(TElLDAPSKeyserverClientHandle _Handle, const char * pcID, int32_t szID, TElPGPKeyringHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_Search_1(TElLDAPSKeyserverClientHandle _Handle, TElPGPKeyringHandle * KeyRing, const char * pcID, int32_t szID);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_Search_2(TElLDAPSKeyserverClientHandle _Handle, const TElLDAPSKeyserverSearchFilterHandle Filter, TElPGPKeyringHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_Search_3(TElLDAPSKeyserverClientHandle _Handle, TElPGPKeyringHandle * KeyRing, const TElLDAPSKeyserverSearchFilterHandle Filter);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_Search_4(TElLDAPSClientHandle _Handle, const char * pcBaseDN, int32_t szBaseDN, TSBLDAPScopeRaw Scope, const char * pcFilter, int32_t szFilter, const TStringListHandle Attrs, int8_t AttrsOnly, TElLDAPResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_Search_5(TElLDAPSClientHandle _Handle, const char * pcBaseDN, int32_t szBaseDN, TSBLDAPScopeRaw Scope, const TElLDAPSSearchFilterHandle Filter, const TStringListHandle Attrs, int8_t AttrsOnly, TElLDAPResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_Search_6(TElLDAPSClientHandle _Handle, TElLDAPResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_Remove(TElLDAPSKeyserverClientHandle _Handle, const TElPGPPublicKeyHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_Remove_1(TElLDAPSKeyserverClientHandle _Handle, const char * pcKeyID, int32_t szKeyID);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_Add(TElLDAPSKeyserverClientHandle _Handle, const TElPGPPublicKeyHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_Add_1(TElLDAPSClientHandle _Handle, const char * pcDN, int32_t szDN, const TElLDAPPartialAttributeHandle pAttrs[], int32_t szAttrs);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_get_ServerSoftwareName(TElLDAPSKeyserverClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_get_ServerSoftwareVersion(TElLDAPSKeyserverClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_get_KeySearchRetryCount(TElLDAPSKeyserverClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_set_KeySearchRetryCount(TElLDAPSKeyserverClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_get_IncludeSubkeys(TElLDAPSKeyserverClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_set_IncludeSubkeys(TElLDAPSKeyserverClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_get_IncludeDisabledKeys(TElLDAPSKeyserverClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_set_IncludeDisabledKeys(TElLDAPSKeyserverClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_get_IncludeRevokedKeys(TElLDAPSKeyserverClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_set_IncludeRevokedKeys(TElLDAPSKeyserverClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElLDAPSKeyserverClient_Create(TComponentHandle AOwner, TElLDAPSKeyserverClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELLDAPSKEYSERVERCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElLDAPSKeyserverSearchFilter_ce_ptr;
extern zend_class_entry *TElLDAPSKeyserverClient_ce_ptr;

void Register_TElLDAPSKeyserverSearchFilter(TSRMLS_D);
void Register_TElLDAPSKeyserverClient(TSRMLS_D);
void Register_SBLDAPSKeyserverClient_Constants(int module_number TSRMLS_DC);
void Register_SBLDAPSKeyserverClient_Enum_Flags(TSRMLS_D);
void Register_SBLDAPSKeyserverClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBLDAPSKEYSERVERCLIENT */

