#ifndef __INC_SBLICENSEMANAGER
#define __INC_SBLICENSEMANAGER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbconstants.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSBLicenseManagerHandle;

typedef TElSBLicenseManagerHandle ElSBLicenseManagerHandle;

typedef uint8_t TSBLicenseKeyRegKeyRaw;

typedef enum
{
	rkHK = 0
} TSBLicenseKeyRegKey;

#ifdef SB_USE_CLASS_TELSBLICENSEMANAGER
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElSBLicenseManager_get_RegistryKey(TElSBLicenseManagerHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSBLicenseManager_set_RegistryKey(TElSBLicenseManagerHandle _Handle, uint32_t Value);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElSBLicenseManager_get_LicenseKey(TElSBLicenseManagerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSBLicenseManager_set_LicenseKey(TElSBLicenseManagerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSBLicenseManager_get_LicenseKeyFile(TElSBLicenseManagerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSBLicenseManager_set_LicenseKeyFile(TElSBLicenseManagerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSBLicenseManager_Create(TComponentHandle AOwner, TElSBLicenseManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSBLICENSEMANAGER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSBLicenseManager_ce_ptr;

void Register_TElSBLicenseManager(TSRMLS_D);
void Register_SBLicenseManager_Enum_Flags(TSRMLS_D);
void Register_SBLicenseManager_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBLICENSEMANAGER */
