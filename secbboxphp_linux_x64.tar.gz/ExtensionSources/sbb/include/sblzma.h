#ifndef __INC_SBLZMA
#define __INC_SBLZMA

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#ifdef SB_WINDOWS
#include "sbstrutils.h"
#include "sbtypes.h"
#include "sbutils.h"
#endif

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_WINDOWS
typedef void (SB_CALLBACK *TSBLzmaOutputFunc)(void * _ObjectData, const uint8_t pBuffer[], int32_t szBuffer, int32_t index, int32_t Size);

typedef void (SB_CALLBACK *TSBLzmaInputFunc)(void * _ObjectData, void * Buffer, int32_t index, int32_t Size, int32_t * OutResult);
#endif

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef SB_WINDOWS
void SB_CALLBACK TSBLzmaOutputFuncRaw(void * _ObjectData, const uint8_t pBuffer[], int32_t szBuffer, int32_t index, int32_t Size);
void SB_CALLBACK TSBLzmaInputFuncRaw(void * _ObjectData, void * Buffer, int32_t index, int32_t Size, int32_t * OutResult);
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBLZMA */
