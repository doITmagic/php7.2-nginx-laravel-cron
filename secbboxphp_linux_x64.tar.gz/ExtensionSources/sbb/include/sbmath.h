#ifndef __INC_SBMATH
#define __INC_SBMATH

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif

#pragma pack(8)
typedef struct 
{
	int32_t Length;
	uint32_t Digits[768];
	int8_t Sign;
	int8_t Disposed;
} TLInt, * PLInt;

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TLInt_ce_ptr;

void Register_TLInt(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBMATH */

