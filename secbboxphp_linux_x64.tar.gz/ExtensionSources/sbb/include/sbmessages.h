#ifndef __INC_SBMESSAGES
#define __INC_SBMESSAGES

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbrdn.h"
#include "sbx509.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbcryptoprov.h"
#include "sbcustomcertstorage.h"
#include "sbcrlstorage.h"
#include "sbpkcs7.h"
#include "sbpkcs7utils.h"
#include "sbasn1tree.h"
#include "sbalgorithmidentifier.h"
#include "sbcustomcrypto.h"
#include "sbsymmetriccrypto.h"
#include "sbpublickeycrypto.h"
#include "sbeccommon.h"
#include "sbtspclient.h"
#include "sbhashfunction.h"
#include "sbstreams.h"
#include "sbdc.h"
#include "sbdcdef.h"
#include "sbdcsec.h"
#include "sbdcpkiconstants.h"
#include "sbrandom.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_CMSBASE 	8192
#define SB_MESSAGE_ERROR_NO_ENCRYPTED_DATA 	8193
#define SB_MESSAGE_ERROR_NO_CERTIFICATE 	8194
#define SB_MESSAGE_ERROR_KEY_DECRYPTION_FAILED 	8195
#define SB_MESSAGE_ERROR_BUFFER_TOO_SMALL 	8196
#define SB_MESSAGE_ERROR_CONTENT_DECRYPTION_FAILED 	8197
#define SB_MESSAGE_ERROR_INVALID_FORMAT 	8198
#define SB_MESSAGE_ERROR_NO_RECIPIENTS 	8199
#define SB_MESSAGE_ERROR_UNSUPPORTED_ALGORITHM 	8200
#define SB_MESSAGE_ERROR_ENCRYPTION_FAILED 	8201
#define SB_MESSAGE_ERROR_INVALID_KEY_LENGTH 	8202
#define SB_MESSAGE_ERROR_NO_SIGNED_DATA 	8203
#define SB_MESSAGE_ERROR_INVALID_SIGNATURE 	8204
#define SB_MESSAGE_ERROR_INVALID_DIGEST 	8205
#define SB_MESSAGE_ERROR_SIGNING_FAILED 	8206
#define SB_MESSAGE_ERROR_INTERNAL_ERROR 	8207
#define SB_MESSAGE_ERROR_INVALID_MAC 	8208
#define SB_MESSAGE_ERROR_UNSUPPORTED_SIGNATURE_TYPE 	8209
#define SB_MESSAGE_ERROR_INVALID_COUNTERSIGNATURE 	8210
#define SB_MESSAGE_ERROR_DIGEST_NOT_FOUND 	8211
#define SB_MESSAGE_ERROR_UNSUPPORTED_DIGEST_ALGORITHM 	8212
#define SB_MESSAGE_ERROR_CANCELLED_BY_USER 	8213
#define SB_MESSAGE_ERROR_VERIFICATION_FAILED 	8214
#define SB_MESSAGE_ERROR_DIGEST_CALCULATION_FAILED 	8215
#define SB_MESSAGE_ERROR_MAC_CALCULATION_FAILED 	8216
#define SB_MESSAGE_ERROR_TSPCLIENT_NOT_FOUND 	8217
#define SB_MESSAGE_ERROR_BAD_TIMESTAMP 	8218
#define SB_MESSAGE_ERROR_KEYOP_FAILED_RSA 	8219
#define SB_MESSAGE_ERROR_KEYOP_FAILED_DSA 	8220
#define SB_MESSAGE_ERROR_KEYOP_FAILED_RSA_PSS 	8221
#define SB_MESSAGE_ERROR_NO_COMPRESSED_DATA 	8222
#define SB_MESSAGE_ERROR_KEYOP_FAILED_EC 	8223
#define SB_MESSAGE_ERROR_DC_BAD_ASYNC_STATE 	8224
#define SB_MESSAGE_ERROR_DC_SERVER_ERROR 	8225
#define SB_MESSAGE_ERROR_DC_MODULE_UNAVAILABLE 	8226
#define SB_MESSAGE_ERROR_KEYOP_FAILED_GOST 	8227
#define SB_MESSAGE_ERROR_NO_CONTENT_OR_DATA_URI 	8228
#define SB_MESSAGE_ERROR_TIMESTAMPING_FAILED 	8229
#define SB_MESSAGE_ERROR_NO_TIMESTAMPED_DATA 	8230
#define SB_MESSAGE_ERROR_ASN_LIMIT_EXCEEDED 	8231
#define SB_MESSAGE_ERROR_DATA_NOT_AVAILABLE 	8232
#define SB_MESSAGE_ERROR_DC_ASYNC_STATE_UNVERIFIED 	8233
#define SB_MESSAGE_ERROR_DC_NO_STATE_STORAGE 	8234
#define SB_MESSAGE_ERROR_DC_FAILED_TO_CREATE_STREAM 	8235
#define SB_MESSAGE_ERROR_DC_NO_PRESIGNED_DATA 	8236
#define SB_MESSAGE_ERROR_INVALID_ENCRYPTION_CIPHER_MODE 	8237

typedef TElClassHandle TElMessageProcessorHandle;

typedef TElMessageProcessorHandle ElMessageProcessorHandle;

typedef TElClassHandle TElMessageEncryptorHandle;

typedef TElMessageEncryptorHandle ElMessageEncryptorHandle;

typedef TElClassHandle TElMessageDecryptorHandle;

typedef TElMessageDecryptorHandle ElMessageDecryptorHandle;

typedef TElClassHandle TElMessageVerifierHandle;

typedef TElMessageVerifierHandle ElMessageVerifierHandle;

typedef TElClassHandle TElMessageSignerHandle;

typedef TElMessageSignerHandle ElMessageSignerHandle;

typedef TElClassHandle TElMessageDecompressorHandle;

typedef TElClassHandle TElMessageCompressorHandle;

typedef TElClassHandle TElMessageTimestamperHandle;

typedef TElClassHandle TElMessageTimestampVerifierHandle;

typedef uint8_t TSBEncryptionOptionRaw;

typedef enum
{
	eoIgnoreSupportedWin32Algorithms = 0,
	eoNoOuterContentInfo = 1
} TSBEncryptionOption;

typedef uint32_t TSBEncryptionOptionsRaw;

typedef enum 
{
	f_eoIgnoreSupportedWin32Algorithms = 1,
	f_eoNoOuterContentInfo = 2
} TSBEncryptionOptions;

typedef void (SB_CALLBACK *TSBCertIDsEvent)(void * _ObjectData, TObjectHandle Sender, TListHandle CertIDs);

typedef uint8_t TSBDecryptionOptionRaw;

typedef enum
{
	doNoOuterContentInfo = 0
} TSBDecryptionOption;

typedef uint32_t TSBDecryptionOptionsRaw;

typedef enum 
{
	f_doNoOuterContentInfo = 1
} TSBDecryptionOptions;

typedef uint8_t TSBMessageSignatureTypeRaw;

typedef enum
{
	mstPublicKey = 0,
	mstMAC = 1
} TSBMessageSignatureType;

typedef uint8_t TSBVerificationOptionRaw;

typedef enum
{
	voUseEmbeddedCerts = 0,
	voUseLocalCerts = 1,
	voVerifyMessageDigests = 2,
	voVerifyTimestamps = 3,
	voNoOuterContentInfo = 4,
	voLiberalMode = 5
} TSBVerificationOption;

typedef uint32_t TSBVerificationOptionsRaw;

typedef enum 
{
	f_voUseEmbeddedCerts = 1,
	f_voUseLocalCerts = 2,
	f_voVerifyMessageDigests = 4,
	f_voVerifyTimestamps = 8,
	f_voNoOuterContentInfo = 16,
	f_voLiberalMode = 32
} TSBVerificationOptions;

typedef uint8_t TSBSigningOptionRaw;

typedef enum
{
	soInsertMessageDigests = 0,
	soIgnoreTimestampFailure = 1,
	soNoOuterContentInfo = 2,
	soRawCountersign = 3,
	soInsertSigningTime = 4,
	soUseGeneralizedTimeFormat = 5,
	soIgnoreBadCountersignatures = 6,
	soUseImplicitContent = 7
} TSBSigningOption;

typedef uint32_t TSBSigningOptionsRaw;

typedef enum 
{
	f_soInsertMessageDigests = 1,
	f_soIgnoreTimestampFailure = 2,
	f_soNoOuterContentInfo = 4,
	f_soRawCountersign = 8,
	f_soInsertSigningTime = 16,
	f_soUseGeneralizedTimeFormat = 32,
	f_soIgnoreBadCountersignatures = 64,
	f_soUseImplicitContent = 128
} TSBSigningOptions;

typedef uint8_t TSBSignOperationTypeRaw;

typedef enum
{
	sotGeneric = 0,
	sotAsyncPrepare = 1,
	sotAsyncComplete = 2
} TSBSignOperationType;

#ifdef SB_USE_CLASS_TELMESSAGEPROCESSOR
SB_IMPORT uint32_t SB_APIENTRY TElMessageProcessor_get_ErrorInfo(TElMessageProcessorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageProcessor_get_CryptoProviderManager(TElMessageProcessorHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageProcessor_set_CryptoProviderManager(TElMessageProcessorHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageProcessor_get_AlignEncryptedKey(TElMessageProcessorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageProcessor_set_AlignEncryptedKey(TElMessageProcessorHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageProcessor_get_OAEPHashAlgorithm(TElMessageProcessorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageProcessor_set_OAEPHashAlgorithm(TElMessageProcessorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageProcessor_get_OnProgress(TElMessageProcessorHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageProcessor_set_OnProgress(TElMessageProcessorHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessageProcessor_Create(TComponentHandle AOwner, TElMessageProcessorHandle * OutResult);
#endif /* SB_USE_CLASS_TELMESSAGEPROCESSOR */

#ifdef SB_USE_CLASS_TELMESSAGEENCRYPTOR
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_Encrypt(TElMessageEncryptorHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_Encrypt_1(TElMessageEncryptorHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, void * Key, int32_t KeySize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_Encrypt_2(TElMessageEncryptorHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_Encrypt_3(TElMessageEncryptorHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, void * Key, int32_t KeySize, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_get_GOSTParamSet(TElMessageEncryptorHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_set_GOSTParamSet(TElMessageEncryptorHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_get_CertStorage(TElMessageEncryptorHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_set_CertStorage(TElMessageEncryptorHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_get_Algorithm(TElMessageEncryptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_set_Algorithm(TElMessageEncryptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_get_BitsInKey(TElMessageEncryptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_set_BitsInKey(TElMessageEncryptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_get_UseUndefSize(TElMessageEncryptorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_set_UseUndefSize(TElMessageEncryptorHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_get_UseOAEP(TElMessageEncryptorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_set_UseOAEP(TElMessageEncryptorHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_get_EncryptionOptions(TElMessageEncryptorHandle _Handle, TSBEncryptionOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_set_EncryptionOptions(TElMessageEncryptorHandle _Handle, TSBEncryptionOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_get_UseImplicitContentEncoding(TElMessageEncryptorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_set_UseImplicitContentEncoding(TElMessageEncryptorHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_get_OriginatorCertificates(TElMessageEncryptorHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_set_OriginatorCertificates(TElMessageEncryptorHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_get_OriginatorCRLs(TElMessageEncryptorHandle _Handle, TElCustomCRLStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_set_OriginatorCRLs(TElMessageEncryptorHandle _Handle, TElCustomCRLStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_get_UnprotectedAttributes(TElMessageEncryptorHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_get_AuthenticatedAttributes(TElMessageEncryptorHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_get_UnauthenticatedAttributes(TElMessageEncryptorHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageEncryptor_Create(TComponentHandle AOwner, TElMessageEncryptorHandle * OutResult);
#endif /* SB_USE_CLASS_TELMESSAGEENCRYPTOR */

#ifdef SB_USE_CLASS_TELMESSAGEDECRYPTOR
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_Decrypt(TElMessageDecryptorHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_Decrypt_1(TElMessageDecryptorHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, void * Key, int32_t KeySize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_Decrypt_2(TElMessageDecryptorHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_Decrypt_3(TElMessageDecryptorHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, void * Key, int32_t KeySize, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_IsConventionallyEncrypted(void * Buffer, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_IsConventionallyEncrypted_1(TElMessageDecryptorHandle _Handle, void * Buffer, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_get_Algorithm(TElMessageDecryptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_get_BitsInKey(TElMessageDecryptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_get_CertIDs(TElMessageDecryptorHandle _Handle, int32_t Index, TElPKCS7IssuerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_get_CertIDCount(TElMessageDecryptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_get_UsedCertificate(TElMessageDecryptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_get_UseOAEP(TElMessageDecryptorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_get_OriginatorCertificates(TElMessageDecryptorHandle _Handle, TElMemoryCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_get_OriginatorCRLs(TElMessageDecryptorHandle _Handle, TElMemoryCRLStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_get_UnprotectedAttributes(TElMessageDecryptorHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_get_AuthenticatedAttributes(TElMessageDecryptorHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_get_UnauthenticatedAttributes(TElMessageDecryptorHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_get_CertStorage(TElMessageDecryptorHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_set_CertStorage(TElMessageDecryptorHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_get_DecryptionOptions(TElMessageDecryptorHandle _Handle, TSBDecryptionOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_set_DecryptionOptions(TElMessageDecryptorHandle _Handle, TSBDecryptionOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_get_OnCertIDs(TElMessageDecryptorHandle _Handle, TSBCertIDsEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_set_OnCertIDs(TElMessageDecryptorHandle _Handle, TSBCertIDsEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecryptor_Create(TComponentHandle AOwner, TElMessageDecryptorHandle * OutResult);
#endif /* SB_USE_CLASS_TELMESSAGEDECRYPTOR */

#ifdef SB_USE_CLASS_TELMESSAGEVERIFIER
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_Verify(TElMessageVerifierHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_Verify_1(TElMessageVerifierHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_VerifyDetached(TElMessageVerifierHandle _Handle, void * Buffer, int32_t Size, void * Signature, int32_t SignatureSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_VerifyDetached_1(TElMessageVerifierHandle _Handle, TStreamHandle InStream, TStreamHandle SigStream, int64_t InCount, int64_t SigCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_IsSignatureDetached(void * Signature, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_IsSignatureDetached_1(TElMessageVerifierHandle _Handle, void * Signature, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_IsSignatureDetached_2(TStreamHandle Signature, int64_t Count, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_IsSignatureDetached_3(TElMessageVerifierHandle _Handle, TStreamHandle Signature, int64_t Count, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_Certificates(TElMessageVerifierHandle _Handle, TElMemoryCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_Attributes(TElMessageVerifierHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_HashAlgorithm(TElMessageVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_MacAlgorithm(TElMessageVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_CertIDs(TElMessageVerifierHandle _Handle, int32_t Index, TElPKCS7IssuerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_CountersignatureCertIDs(TElMessageVerifierHandle _Handle, int32_t Index, TElPKCS7IssuerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_CountersignatureVerificationResults(TElMessageVerifierHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_CountersignatureAttributes(TElMessageVerifierHandle _Handle, int32_t Index, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_CertIDCount(TElMessageVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_CountersignatureCertIDCount(TElMessageVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_SignatureType(TElMessageVerifierHandle _Handle, TSBMessageSignatureTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_UsePSS(TElMessageVerifierHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_InputIsDigest(TElMessageVerifierHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_set_InputIsDigest(TElMessageVerifierHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_Timestamps(TElMessageVerifierHandle _Handle, int32_t Index, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_TimestampCount(TElMessageVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_SigningTime(TElMessageVerifierHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_CertStorage(TElMessageVerifierHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_set_CertStorage(TElMessageVerifierHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_VerifyCountersignatures(TElMessageVerifierHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_set_VerifyCountersignatures(TElMessageVerifierHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_VerificationOptions(TElMessageVerifierHandle _Handle, TSBVerificationOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_set_VerificationOptions(TElMessageVerifierHandle _Handle, TSBVerificationOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_get_OnCertIDs(TElMessageVerifierHandle _Handle, TSBCertIDsEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_set_OnCertIDs(TElMessageVerifierHandle _Handle, TSBCertIDsEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessageVerifier_Create(TComponentHandle AOwner, TElMessageVerifierHandle * OutResult);
#endif /* SB_USE_CLASS_TELMESSAGEVERIFIER */

#ifdef SB_USE_CLASS_TELMESSAGESIGNER
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_Sign(TElMessageSignerHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int8_t Detached, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_Sign_1(TElMessageSignerHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int8_t Detached, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign(TElMessageSignerHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int8_t Detached, TElDCAsyncStateHandle * State, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_1(TElMessageSignerHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int8_t Detached, TSBDCAsyncSignMethodRaw AsyncSignMethod, TElDCAsyncStateHandle * State, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_2(TElMessageSignerHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int8_t Detached, TElDCParametersHandle Pars, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * State, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_3(TElMessageSignerHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int8_t Detached, TElDCParametersHandle Pars, TSBDCAsyncSignMethodRaw AsyncSignMethod, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * State, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_4(TElMessageSignerHandle _Handle, void * InBuffer, int32_t InSize, int8_t Detached, TElDCAsyncStateHandle * State, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_5(TElMessageSignerHandle _Handle, void * InBuffer, int32_t InSize, int8_t Detached, TSBDCAsyncSignMethodRaw AsyncSignMethod, TElDCAsyncStateHandle * State, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_6(TElMessageSignerHandle _Handle, void * InBuffer, int32_t InSize, int8_t Detached, TElDCParametersHandle Pars, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * State, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_7(TElMessageSignerHandle _Handle, void * InBuffer, int32_t InSize, int8_t Detached, TElDCParametersHandle Pars, TSBDCAsyncSignMethodRaw AsyncSignMethod, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * State, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_8(TElMessageSignerHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int8_t Detached, TElDCAsyncStateHandle * State, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_9(TElMessageSignerHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int8_t Detached, TSBDCAsyncSignMethodRaw AsyncSignMethod, TElDCAsyncStateHandle * State, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_10(TElMessageSignerHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int8_t Detached, TElDCParametersHandle Pars, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * State, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_11(TElMessageSignerHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int8_t Detached, TElDCParametersHandle Pars, TSBDCAsyncSignMethodRaw AsyncSignMethod, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * State, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_12(TElMessageSignerHandle _Handle, TStreamHandle InStream, int8_t Detached, TElDCAsyncStateHandle * State, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_13(TElMessageSignerHandle _Handle, TStreamHandle InStream, int8_t Detached, TSBDCAsyncSignMethodRaw AsyncSignMethod, TElDCAsyncStateHandle * State, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_14(TElMessageSignerHandle _Handle, TStreamHandle InStream, int8_t Detached, TElDCParametersHandle Pars, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * State, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_InitiateAsyncSign_15(TElMessageSignerHandle _Handle, TStreamHandle InStream, int8_t Detached, TElDCParametersHandle Pars, TSBDCAsyncSignMethodRaw AsyncSignMethod, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * State, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_CompleteAsyncSign(TElMessageSignerHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, TElDCAsyncStateHandle AsyncState, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_CompleteAsyncSign_1(TElMessageSignerHandle _Handle, void * OutBuffer, int32_t * OutSize, TElDCAsyncStateHandle AsyncState, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_CompleteAsyncSign_2(TElMessageSignerHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, TElDCAsyncStateHandle AsyncState, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_CompleteAsyncSign_3(TElMessageSignerHandle _Handle, TStreamHandle OutStream, TElDCAsyncStateHandle AsyncState, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_ExtractAdditionalDataFromAsyncState(TElDCAsyncStateHandle State, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_ExtractAdditionalDataFromAsyncState_1(TElMessageSignerHandle _Handle, TElDCAsyncStateHandle State, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_Countersign(TElMessageSignerHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_Countersign_1(TElMessageSignerHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_Timestamp(TElMessageSignerHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_Timestamp_1(TElMessageSignerHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_TimestampCountersignature(TElMessageSignerHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int32_t SigIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_TimestampCountersignature_1(TElMessageSignerHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int32_t SigIndex, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_AuthenticatedAttributes(TElMessageSignerHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_UnauthenticatedAttributes(TElMessageSignerHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_HashAlgorithm(TElMessageSignerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_HashAlgorithm(TElMessageSignerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_MacAlgorithm(TElMessageSignerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_MacAlgorithm(TElMessageSignerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_ContentType(TElMessageSignerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_ContentType(TElMessageSignerHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_DataHash(TElMessageSignerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_DigestEncryptionAlgorithm(TElMessageSignerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_DigestEncryptionAlgorithm(TElMessageSignerHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_SigningTime(TElMessageSignerHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_SigningTime(TElMessageSignerHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_SignatureType(TElMessageSignerHandle _Handle, TSBMessageSignatureTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_SignatureType(TElMessageSignerHandle _Handle, TSBMessageSignatureTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_CertStorage(TElMessageSignerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_CertStorage(TElMessageSignerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_IncludeCertificates(TElMessageSignerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_IncludeCertificates(TElMessageSignerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_IncludeChain(TElMessageSignerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_IncludeChain(TElMessageSignerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_RecipientCerts(TElMessageSignerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_RecipientCerts(TElMessageSignerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_UseUndefSize(TElMessageSignerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_UseUndefSize(TElMessageSignerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_UsePSS(TElMessageSignerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_UsePSS(TElMessageSignerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_SigningOptions(TElMessageSignerHandle _Handle, TSBSigningOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_SigningOptions(TElMessageSignerHandle _Handle, TSBSigningOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_ExtraSpace(TElMessageSignerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_ExtraSpace(TElMessageSignerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_InputIsHash(TElMessageSignerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_InputIsHash(TElMessageSignerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_get_TSPClient(TElMessageSignerHandle _Handle, TElCustomTSPClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_set_TSPClient(TElMessageSignerHandle _Handle, TElCustomTSPClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageSigner_Create(TComponentHandle AOwner, TElMessageSignerHandle * OutResult);
#endif /* SB_USE_CLASS_TELMESSAGESIGNER */

#ifdef SB_USE_CLASS_TELMESSAGEDECOMPRESSOR
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecompressor_Decompress(TElMessageDecompressorHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecompressor_Decompress_1(TElMessageDecompressorHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecompressor_get_ContentType(TElMessageDecompressorHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageDecompressor_Create(TComponentHandle AOwner, TElMessageDecompressorHandle * OutResult);
#endif /* SB_USE_CLASS_TELMESSAGEDECOMPRESSOR */

#ifdef SB_USE_CLASS_TELMESSAGECOMPRESSOR
SB_IMPORT uint32_t SB_APIENTRY TElMessageCompressor_Compress(TElMessageCompressorHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageCompressor_Compress_1(TElMessageCompressorHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageCompressor_get_ContentType(TElMessageCompressorHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageCompressor_set_ContentType(TElMessageCompressorHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessageCompressor_get_CompressionLevel(TElMessageCompressorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageCompressor_set_CompressionLevel(TElMessageCompressorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageCompressor_get_FragmentSize(TElMessageCompressorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageCompressor_set_FragmentSize(TElMessageCompressorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageCompressor_get_UseUndefSize(TElMessageCompressorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageCompressor_set_UseUndefSize(TElMessageCompressorHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageCompressor_Create(TComponentHandle AOwner, TElMessageCompressorHandle * OutResult);
#endif /* SB_USE_CLASS_TELMESSAGECOMPRESSOR */

#ifdef SB_USE_CLASS_TELMESSAGETIMESTAMPER
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_Timestamp(TElMessageTimestamperHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_Timestamp_1(TElMessageTimestamperHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_AddTSPClient(TElMessageTimestamperHandle _Handle, TElCustomTSPClientHandle Client, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_RemoveTSPClient(TElMessageTimestamperHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_RemoveTSPClient_1(TElMessageTimestamperHandle _Handle, TElCustomTSPClientHandle Client);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_get_TSPClients(TElMessageTimestamperHandle _Handle, int32_t Index, TElCustomTSPClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_get_TSPClientsCount(TElMessageTimestamperHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_get_TSPClient(TElMessageTimestamperHandle _Handle, TElCustomTSPClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_set_TSPClient(TElMessageTimestamperHandle _Handle, TElCustomTSPClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_get_IncludeContent(TElMessageTimestamperHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_set_IncludeContent(TElMessageTimestamperHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_get_ProtectMetadata(TElMessageTimestamperHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_set_ProtectMetadata(TElMessageTimestamperHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_get_DataURI(TElMessageTimestamperHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_set_DataURI(TElMessageTimestamperHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_get_FileName(TElMessageTimestamperHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_set_FileName(TElMessageTimestamperHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_get_MediaType(TElMessageTimestamperHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_set_MediaType(TElMessageTimestamperHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_get_UseUndefSize(TElMessageTimestamperHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_set_UseUndefSize(TElMessageTimestamperHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestamper_Create(TComponentHandle AOwner, TElMessageTimestamperHandle * OutResult);
#endif /* SB_USE_CLASS_TELMESSAGETIMESTAMPER */

#ifdef SB_USE_CLASS_TELMESSAGETIMESTAMPVERIFIER
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestampVerifier_Verify(TElMessageTimestampVerifierHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestampVerifier_Verify_1(TElMessageTimestampVerifierHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestampVerifier_VerifyDetached(TElMessageTimestampVerifierHandle _Handle, void * Buffer, int32_t Size, void * Data, int32_t DataSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestampVerifier_VerifyDetached_1(TElMessageTimestampVerifierHandle _Handle, TStreamHandle InStream, TStreamHandle DataStream, int64_t InCount, int64_t DataCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestampVerifier_IsTimestampDetached(void * Timestamp, int32_t Size, char * pcDataURI, int32_t * szDataURI, char * pcFileName, int32_t * szFileName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestampVerifier_IsTimestampDetached_1(TElMessageTimestampVerifierHandle _Handle, void * Timestamp, int32_t Size, char * pcDataURI, int32_t * szDataURI, char * pcFileName, int32_t * szFileName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestampVerifier_IsTimestampDetached_2(TStreamHandle Timestamp, char * pcDataURI, int32_t * szDataURI, char * pcFileName, int32_t * szFileName, int64_t Count, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestampVerifier_IsTimestampDetached_3(TElMessageTimestampVerifierHandle _Handle, TStreamHandle Timestamp, char * pcDataURI, int32_t * szDataURI, char * pcFileName, int32_t * szFileName, int64_t Count, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestampVerifier_get_Timestamps(TElMessageTimestampVerifierHandle _Handle, int32_t Index, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestampVerifier_get_TimestampCount(TElMessageTimestampVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestampVerifier_get_DataURI(TElMessageTimestampVerifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestampVerifier_get_FileName(TElMessageTimestampVerifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestampVerifier_get_MediaType(TElMessageTimestampVerifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessageTimestampVerifier_Create(TComponentHandle AOwner, TElMessageTimestampVerifierHandle * OutResult);
#endif /* SB_USE_CLASS_TELMESSAGETIMESTAMPVERIFIER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElMessageProcessor_ce_ptr;
extern zend_class_entry *TElMessageEncryptor_ce_ptr;
extern zend_class_entry *TElMessageDecryptor_ce_ptr;
extern zend_class_entry *TElMessageVerifier_ce_ptr;
extern zend_class_entry *TElMessageSigner_ce_ptr;
extern zend_class_entry *TElMessageDecompressor_ce_ptr;
extern zend_class_entry *TElMessageCompressor_ce_ptr;
extern zend_class_entry *TElMessageTimestamper_ce_ptr;
extern zend_class_entry *TElMessageTimestampVerifier_ce_ptr;

void SB_CALLBACK TSBCertIDsEventRaw(void * _ObjectData, TObjectHandle Sender, TListHandle CertIDs);
void Register_TElMessageProcessor(TSRMLS_D);
void Register_TElMessageEncryptor(TSRMLS_D);
void Register_TElMessageDecryptor(TSRMLS_D);
void Register_TElMessageVerifier(TSRMLS_D);
void Register_TElMessageSigner(TSRMLS_D);
void Register_TElMessageDecompressor(TSRMLS_D);
void Register_TElMessageCompressor(TSRMLS_D);
void Register_TElMessageTimestamper(TSRMLS_D);
void Register_TElMessageTimestampVerifier(TSRMLS_D);
void Register_SBMessages_Constants(int module_number TSRMLS_DC);
void Register_SBMessages_Enum_Flags(TSRMLS_D);
void Register_SBMessages_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBMESSAGES */

