#ifndef __INC_SBMIMEENC
#define __INC_SBMIMEENC

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstreams.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbencoding.h"
#include "sbmimestream.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_cSplitOutLenDef 	70
#define SB_cMinusOne 	-1

typedef TElClassHandle TElMimeEncodingStreamHandle;

typedef TElClassHandle TElBase64StreamHandle;

typedef TElClassHandle TElQuotedPrintableStreamHandle;

typedef TElClassHandle TEl7BitStreamHandle;

typedef TElClassHandle TEl8BitStreamHandle;

typedef TElClassHandle TElBinaryStreamHandle;

typedef TElMimeEncodingStreamHandle ElMimeEncodingStreamHandle;

typedef TElBase64StreamHandle ElBase64StreamHandle;

typedef TElQuotedPrintableStreamHandle ElQuotedPrintableStreamHandle;

typedef TEl7BitStreamHandle El7BitStreamHandle;

typedef TEl8BitStreamHandle El8BitStreamHandle;

typedef TElBinaryStreamHandle ElBinaryStreamHandle;

typedef TElClassHandle TElMimeEncodingStreamClassHandle;

typedef TElMimeEncodingStreamClassHandle ElMimeEncodingStreamClassHandle;

typedef uint8_t TElEncodingTypeRaw;

typedef enum
{
	etNotEncoded = 0,
	etQuotedPrintable = 1,
	etBase64 = 2
} TElEncodingType;

typedef TElEncodingType ElEncodingType;

#ifdef SB_USE_CLASS_TELMIMEENCODINGSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_ReInit(TElMimeEncodingStreamHandle _Handle, TStreamHandle Stream, int32_t StreamLen, int32_t SplitOnLen);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream__CopyTo(TElMimeEncodingStreamHandle _Handle, TStreamHandle DestStream, int64_t Count, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_Seek(TElMimeEncodingStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_Seek_1(TElMimeEncodingStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_GetEncodingName(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_GetEncodingName_1(TElMimeEncodingStreamHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_GetEncodedSize(TElMimeEncodingStreamHandle _Handle, int32_t SourceSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_GetDecodedSize(TElMimeEncodingStreamHandle _Handle, int32_t SourceSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_get_IsErrorOccured(TElMimeEncodingStreamHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_get_Stream(TElMimeEncodingStreamHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_set_Stream(TElMimeEncodingStreamHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_get_SplitOnLen(TElMimeEncodingStreamHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_set_SplitOnLen(TElMimeEncodingStreamHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_Create(TElMimeEncodingStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMimeEncodingStream_Create_1(TStreamHandle Stream, int32_t StreamLen, int32_t SplitOnLen, TElMimeEncodingStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELMIMEENCODINGSTREAM */

#ifdef SB_USE_CLASS_TELBASE64STREAM
SB_IMPORT uint32_t SB_APIENTRY TElBase64Stream_ReInit(TElBase64StreamHandle _Handle, TStreamHandle Stream, int32_t StreamLen, int32_t SplitOnLen);
SB_IMPORT uint32_t SB_APIENTRY TElBase64Stream_Read(TElBase64StreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBase64Stream_Write(TElBase64StreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBase64Stream_Flush(TElBase64StreamHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElBase64Stream_GetEncodedSize(TElBase64StreamHandle _Handle, int32_t SourceSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBase64Stream_GetDecodedSize(TElBase64StreamHandle _Handle, int32_t SourceSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBase64Stream_GetEncodingName(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBase64Stream_GetEncodingName_1(TElBase64StreamHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBase64Stream_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBase64Stream_Create(TElBase64StreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBase64Stream_Create_1(TStreamHandle Stream, int32_t StreamLen, int32_t SplitOnLen, TElBase64StreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELBASE64STREAM */

#ifdef SB_USE_CLASS_TELQUOTEDPRINTABLESTREAM
SB_IMPORT uint32_t SB_APIENTRY TElQuotedPrintableStream_Read(TElQuotedPrintableStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElQuotedPrintableStream_Write(TElQuotedPrintableStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElQuotedPrintableStream_GetEncodedSize(TElQuotedPrintableStreamHandle _Handle, int32_t SourceSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElQuotedPrintableStream_GetDecodedSize(TElQuotedPrintableStreamHandle _Handle, int32_t SourceSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElQuotedPrintableStream_GetEncodingName(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElQuotedPrintableStream_GetEncodingName_1(TElQuotedPrintableStreamHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElQuotedPrintableStream_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElQuotedPrintableStream_Create(TElMimeEncodingStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElQuotedPrintableStream_Create_1(TStreamHandle Stream, int32_t StreamLen, int32_t SplitOnLen, TElMimeEncodingStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELQUOTEDPRINTABLESTREAM */

#ifdef SB_USE_CLASS_TEL7BITSTREAM
SB_IMPORT uint32_t SB_APIENTRY TEl7BitStream_Read(TEl7BitStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl7BitStream_Write(TEl7BitStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl7BitStream_GetEncodingName(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl7BitStream_GetEncodingName_1(TEl7BitStreamHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl7BitStream_ReInit(TEl7BitStreamHandle _Handle, TStreamHandle Stream, int32_t StreamLen, int32_t SplitOnLen);
SB_IMPORT uint32_t SB_APIENTRY TEl7BitStream_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl7BitStream_get_Passthrough(TEl7BitStreamHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl7BitStream_set_Passthrough(TEl7BitStreamHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TEl7BitStream_Create(TElMimeEncodingStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl7BitStream_Create_1(TStreamHandle Stream, int32_t StreamLen, int32_t SplitOnLen, TElMimeEncodingStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TEL7BITSTREAM */

#ifdef SB_USE_CLASS_TEL8BITSTREAM
SB_IMPORT uint32_t SB_APIENTRY TEl8BitStream_Read(TEl8BitStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl8BitStream_Write(TEl8BitStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl8BitStream_GetEncodingName(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl8BitStream_GetEncodingName_1(TEl8BitStreamHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl8BitStream_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl8BitStream_Create(TElMimeEncodingStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl8BitStream_Create_1(TStreamHandle Stream, int32_t StreamLen, int32_t SplitOnLen, TElMimeEncodingStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TEL8BITSTREAM */

#ifdef SB_USE_CLASS_TELBINARYSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElBinaryStream_GetEncodingName(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBinaryStream_GetEncodingName_1(TElBinaryStreamHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBinaryStream_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBinaryStream_Create(TElMimeEncodingStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBinaryStream_Create_1(TStreamHandle Stream, int32_t StreamLen, int32_t SplitOnLen, TElMimeEncodingStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELBINARYSTREAM */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElMimeEncodingStreamClass_ce_ptr;
extern zend_class_entry *TElMimeEncodingStream_ce_ptr;
extern zend_class_entry *TElBase64Stream_ce_ptr;
extern zend_class_entry *TElQuotedPrintableStream_ce_ptr;
extern zend_class_entry *TEl7BitStream_ce_ptr;
extern zend_class_entry *TEl8BitStream_ce_ptr;
extern zend_class_entry *TElBinaryStream_ce_ptr;

void Register_TElMimeEncodingStream(TSRMLS_D);
void Register_TElBase64Stream(TSRMLS_D);
void Register_TElQuotedPrintableStream(TSRMLS_D);
void Register_TEl7BitStream(TSRMLS_D);
void Register_TEl8BitStream(TSRMLS_D);
void Register_TElBinaryStream(TSRMLS_D);
SB_PHP_FUNCTION(SBMIMEEnc, DecodeHeader);
SB_PHP_FUNCTION(SBMIMEEnc, EncodeQuotedPrintableBodyForHeader);
void Register_SBMIMEEnc_Constants(int module_number TSRMLS_DC);
void Register_SBMIMEEnc_Enum_Flags(TSRMLS_D);
void Register_SBMIMEEnc_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_MIMEENC
SB_IMPORT uint32_t SB_APIENTRY SBMIMEEnc_DecodeHeader(const char * pcEncoded, int32_t szEncoded, TElEncodingTypeRaw Encoding, char * pcCharset, int32_t * szCharset, char * pcDecoded, int32_t * szDecoded);
SB_IMPORT uint32_t SB_APIENTRY SBMIMEEnc_EncodeQuotedPrintableBodyForHeader(const char * pcSource, int32_t szSource, int32_t * Offset, int32_t Max, char * pcDest, int32_t * szDest);
#endif /* SB_USE_GLOBAL_PROCS_MIMEENC */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBMIMEENC */

