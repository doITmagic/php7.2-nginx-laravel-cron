#ifndef __INC_SBOAUTH2
#define __INC_SBOAUTH2

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstringlist.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbjson.h"
#include "sbsocket.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_OAUTH2 	172032
#define SB_ERROR_OAUTH2_ERROR_FLAG 	2048
#define SB_OAUTH2_ERROR_INVALID_HTTP_CODE 	174081
#define SB_OAUTH2_ERROR_INVALID_RESPONSE_FORMAT 	174082
#define SB_OAUTH2_ERROR_INVALID_STATE_PARAMETER 	174083
#define SB_OAUTH2_ERROR_NO_CODE_RECEIVED 	174084
#define SB_OAUTH2_ERROR_NO_REFRESH_TOKEN 	174085
#define SB_OAUTH2_ERROR_INVALID_PARAMETER 	174086
#define SB_OAUTH2_ERROR_INVALID_HTTP_HEADER 	174087
#define SB_OAUTH2_ERROR_SOCKET_ERROR 	174088
#define SB_ERROR_OAUTH2_SERVER_ERROR_FLAG 	2304
#define SB_OAUTH2_SERVER_ERROR_UNKNOWN 	174336
#define SB_OAUTH2_SERVER_ERROR_ACCESS_DENIED 	174337
#define SB_OAUTH2_SERVER_ERROR_INVALID_CLIENT 	174338
#define SB_OAUTH2_SERVER_ERROR_INVALID_GRANT 	174339
#define SB_OAUTH2_SERVER_ERROR_INVALID_REQUEST 	174340
#define SB_OAUTH2_SERVER_ERROR_INVALID_SCOPE 	174341
#define SB_OAUTH2_SERVER_ERROR_SERVER_FAILURE 	174342
#define SB_OAUTH2_SERVER_ERROR_TEMPORARILY 	174343
#define SB_OAUTH2_SERVER_ERROR_UNAUTH_CLIENT 	174344
#define SB_OAUTH2_SERVER_ERROR_UNSUPPORTED_GRANT 	174345
#define SB_OAUTH2_SERVER_ERROR_UNSUPPORTED_RESPONSE 	174346

typedef TElClassHandle TElOAuth2RequestHandle;

typedef TElClassHandle TElOAuth2ClientHandle;

typedef TElClassHandle TElOAuth2RedirectReceiverHandle;

typedef uint8_t TSBOAuth2GrantTypeRaw;

typedef enum
{
	oauthAuthorizationCode = 0,
	oauthImplicit = 1,
	oauthResourceOwnerPassword = 2,
	oauthClientCredentials = 3
} TSBOAuth2GrantType;

#ifdef SB_USE_CLASS_TELOAUTH2REQUEST
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Request_Assign(TElOAuth2RequestHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Request_Clear(TElOAuth2RequestHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Request_get_Body(TElOAuth2RequestHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Request_get_Header(TElOAuth2RequestHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Request_get_Method(TElOAuth2RequestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Request_get_URL(TElOAuth2RequestHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Request_Create(TElOAuth2RequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELOAUTH2REQUEST */

#ifdef SB_USE_CLASS_TELOAUTH2CLIENT
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_Process(TElOAuth2ClientHandle _Handle, TElStringListHandle ResponseHeader, const uint8_t pResponseBody[], int32_t szResponseBody, int32_t * Method, char * pcURL, int32_t * szURL, TElStringListHandle RequestHeader, uint8_t pRequestBody[], int32_t * szRequestBody, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_Process_1(TElOAuth2ClientHandle _Handle, TElStringListHandle ResponseHeader, const uint8_t pResponseBody[], int32_t szResponseBody, TElOAuth2RequestHandle NewRequest, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_Refresh(TElOAuth2ClientHandle _Handle, int32_t * Method, char * pcURL, int32_t * szURL, TElStringListHandle RequestHeader, uint8_t pRequestBody[], int32_t * szRequestBody);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_Refresh_1(TElOAuth2ClientHandle _Handle, TElOAuth2RequestHandle Request);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_Start(TElOAuth2ClientHandle _Handle, int32_t * Method, char * pcURL, int32_t * szURL, TElStringListHandle RequestHeader, uint8_t pRequestBody[], int32_t * szRequestBody);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_Start_1(TElOAuth2ClientHandle _Handle, TElOAuth2RequestHandle Request);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_ApplyCustomParams(TElOAuth2ClientHandle _Handle, TElStringListHandle Params);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_ClearCustomParams(TElOAuth2ClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_AccessToken(TElOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_AuthURL(TElOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_set_AuthURL(TElOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_ClientID(TElOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_set_ClientID(TElOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_ClientSecret(TElOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_set_ClientSecret(TElOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_Complete(TElOAuth2ClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_CustomParam(TElOAuth2ClientHandle _Handle, const char * pcName, int32_t szName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_set_CustomParam(TElOAuth2ClientHandle _Handle, const char * pcName, int32_t szName, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_ExpiresAt(TElOAuth2ClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_ExpiresIn(TElOAuth2ClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_GrantType(TElOAuth2ClientHandle _Handle, TSBOAuth2GrantTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_set_GrantType(TElOAuth2ClientHandle _Handle, TSBOAuth2GrantTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_Password(TElOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_set_Password(TElOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_RedirectURL(TElOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_set_RedirectURL(TElOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_RefreshToken(TElOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_set_RefreshToken(TElOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_Scope(TElOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_set_Scope(TElOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_State(TElOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_set_State(TElOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_TokenType(TElOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_TokenURL(TElOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_set_TokenURL(TElOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_UseURLParams(TElOAuth2ClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_set_UseURLParams(TElOAuth2ClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_get_UserName(TElOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_set_UserName(TElOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2Client_Create(TElOAuth2ClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELOAUTH2CLIENT */

#ifdef SB_USE_CLASS_TELOAUTH2REDIRECTRECEIVER
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_Activate(TElOAuth2RedirectReceiverHandle _Handle, const char * pcURL, int32_t szURL);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_Activate_1(TElOAuth2RedirectReceiverHandle _Handle, const char * pcLocalAddress, int32_t szLocalAddress, uint16_t LocalPort);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_Deactivate(TElOAuth2RedirectReceiverHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_Receive(TElOAuth2RedirectReceiverHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_Reset(TElOAuth2RedirectReceiverHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_get_Active(TElOAuth2RedirectReceiverHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_get_AuthorizationCode(TElOAuth2RedirectReceiverHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_get_Done(TElOAuth2RedirectReceiverHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_get_ReceivedHeaders(TElOAuth2RedirectReceiverHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_get_BufferSize(TElOAuth2RedirectReceiverHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_set_BufferSize(TElOAuth2RedirectReceiverHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_get_ResponsePage(TElOAuth2RedirectReceiverHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_set_ResponsePage(TElOAuth2RedirectReceiverHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_get_UseIPv6(TElOAuth2RedirectReceiverHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_set_UseIPv6(TElOAuth2RedirectReceiverHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_get_SocketTimeout(TElOAuth2RedirectReceiverHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_set_SocketTimeout(TElOAuth2RedirectReceiverHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_get_OnComplete(TElOAuth2RedirectReceiverHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_set_OnComplete(TElOAuth2RedirectReceiverHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElOAuth2RedirectReceiver_Create(TComponentHandle AOwner, TElOAuth2RedirectReceiverHandle * OutResult);
#endif /* SB_USE_CLASS_TELOAUTH2REDIRECTRECEIVER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElOAuth2Request_ce_ptr;
extern zend_class_entry *TElOAuth2Client_ce_ptr;
extern zend_class_entry *TElOAuth2RedirectReceiver_ce_ptr;

void Register_TElOAuth2Request(TSRMLS_D);
void Register_TElOAuth2Client(TSRMLS_D);
void Register_TElOAuth2RedirectReceiver(TSRMLS_D);
void Register_SBOAuth2_Constants(int module_number TSRMLS_DC);
void Register_SBOAuth2_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBOAUTH2 */

