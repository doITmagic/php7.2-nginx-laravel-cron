#ifndef __INC_SBOCSPCLIENT
#define __INC_SBOCSPCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbencoding.h"
#include "sbpem.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbx509.h"
#include "sbx509ext.h"
#include "sbrdn.h"
#include "sbocspcommon.h"
#include "sbpublickeycrypto.h"
#include "sbpkcs7utils.h"
#include "sbpkicommon.h"
#include "sbcmsutils.h"
#include "sbhashfunction.h"
#include "sbcustomcertstorage.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElOCSPClientHandle;

typedef TElOCSPClientHandle ElOCSPClientHandle;

typedef TElClassHandle TElOCSPResponderIDHandle;

typedef TElClassHandle TElOCSPSingleResponseHandle;

typedef TElClassHandle TElOCSPResponseHandle;

typedef TElClassHandle TElFileOCSPClientHandle;

typedef TElFileOCSPClientHandle ElFileOCSPClientHandle;

typedef TElClassHandle TElCustomOCSPClientFactoryHandle;

typedef TElCustomOCSPClientFactoryHandle ElCustomOCSPClientFactoryHandle;

typedef TElClassHandle TElOCSPClientManagerHandle;

typedef TElOCSPClientManagerHandle ElOCSPClientManagerHandle;

typedef uint8_t TSBOCSPClientOptionRaw;

typedef enum
{
	ocoIncludeVersion = 0,
	ocoIncludeSupportedResponseTypes = 1
} TSBOCSPClientOption;

typedef uint32_t TSBOCSPClientOptionsRaw;

typedef enum 
{
	f_ocoIncludeVersion = 1,
	f_ocoIncludeSupportedResponseTypes = 2
} TSBOCSPClientOptions;

typedef void (SB_CALLBACK *TSBOCSPValidationNeededEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, TStreamHandle RequestStream, TStreamHandle ReplyStream, int8_t * Succeeded);

#ifdef SB_USE_CLASS_TELOCSPCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_CreateRequest(TElOCSPClientHandle _Handle, uint8_t pRequest[], int32_t * szRequest, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_ProcessReply(TElOCSPClientHandle _Handle, const uint8_t pReply[], int32_t szReply, TElOCSPServerErrorRaw * ServerResult, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_PerformRequest(TElOCSPClientHandle _Handle, TElOCSPServerErrorRaw * ServerResult, uint8_t pReply[], int32_t * szReply, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_SupportsLocation(TElOCSPClientHandle _Handle, const char * pcURI, int32_t szURI, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_ReplyProducedAt(TElOCSPClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_ReplyNonce(TElOCSPClientHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_ReplyCertificates(TElOCSPClientHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_ServerName(TElOCSPClientHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_ServerCertKeyHash(TElOCSPClientHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_set_ServerCertKeyHash(TElOCSPClientHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_CertStatus(TElOCSPClientHandle _Handle, int32_t Index, TElOCSPCertificateStatusRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_RevocationTime(TElOCSPClientHandle _Handle, int32_t Index, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_RevocationReason(TElOCSPClientHandle _Handle, int32_t Index, TSBCRLReasonFlagRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_ThisUpdate(TElOCSPClientHandle _Handle, int32_t Index, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_NextUpdate(TElOCSPClientHandle _Handle, int32_t Index, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_Response(TElOCSPClientHandle _Handle, TElOCSPResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_Nonce(TElOCSPClientHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_set_Nonce(TElOCSPClientHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_CertStorage(TElOCSPClientHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_set_CertStorage(TElOCSPClientHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_IssuerCertStorage(TElOCSPClientHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_set_IssuerCertStorage(TElOCSPClientHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_IncludeSignature(TElOCSPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_set_IncludeSignature(TElOCSPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_SignatureAlgorithm(TElOCSPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_set_SignatureAlgorithm(TElOCSPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_Options(TElOCSPClientHandle _Handle, TSBOCSPClientOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_set_Options(TElOCSPClientHandle _Handle, TSBOCSPClientOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_URL(TElOCSPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_set_URL(TElOCSPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_get_OnCertificateNeeded(TElOCSPClientHandle _Handle, TSBOCSPCertificateNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_set_OnCertificateNeeded(TElOCSPClientHandle _Handle, TSBOCSPCertificateNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClient_Create(TComponentHandle Owner, TElOCSPClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELOCSPCLIENT */

#ifdef SB_USE_CLASS_TELOCSPRESPONDERID
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponderID_Clear(TElOCSPResponderIDHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponderID_get_Name(TElOCSPResponderIDHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponderID_get_SHA1KeyHash(TElOCSPResponderIDHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponderID_set_SHA1KeyHash(TElOCSPResponderIDHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponderID_Create(TElOCSPResponderIDHandle * OutResult);
#endif /* SB_USE_CLASS_TELOCSPRESPONDERID */

#ifdef SB_USE_CLASS_TELOCSPSINGLERESPONSE
SB_IMPORT uint32_t SB_APIENTRY TElOCSPSingleResponse_LoadFromTag(TElOCSPSingleResponseHandle _Handle, TElASN1ConstrainedTagHandle Tag);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPSingleResponse_CertMatches(TElOCSPSingleResponseHandle _Handle, TElX509CertificateHandle Cert, TElX509CertificateHandle Issuer, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPSingleResponse_SignerMatches(TElOCSPSingleResponseHandle _Handle, TElPKCS7IssuerHandle Signer, TElX509CertificateHandle Issuer, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPSingleResponse_get_HashAlgorithm(TElOCSPSingleResponseHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPSingleResponse_get_IssuerNameHash(TElOCSPSingleResponseHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPSingleResponse_get_IssuerKeyHash(TElOCSPSingleResponseHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPSingleResponse_get_SerialNumber(TElOCSPSingleResponseHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPSingleResponse_get_CertStatus(TElOCSPSingleResponseHandle _Handle, TElOCSPCertificateStatusRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPSingleResponse_get_ThisUpdate(TElOCSPSingleResponseHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPSingleResponse_get_NextUpdate(TElOCSPSingleResponseHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPSingleResponse_get_RevocationTime(TElOCSPSingleResponseHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPSingleResponse_get_RevocationReasons(TElOCSPSingleResponseHandle _Handle, TSBCRLReasonFlagsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPSingleResponse_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELOCSPSINGLERESPONSE */

#ifdef SB_USE_CLASS_TELOCSPRESPONSE
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_Clear(TElOCSPResponseHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_Assign(TElOCSPResponseHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_Load(TElOCSPResponseHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_Save(TElOCSPResponseHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_SaveBasic(TElOCSPResponseHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_SaveFull(TElOCSPResponseHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_EqualsTo(TElOCSPResponseHandle _Handle, TElOCSPResponseHandle OtherResponse, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_FindResponse(TElOCSPResponseHandle _Handle, TElX509CertificateHandle Cert, TElX509CertificateHandle Issuer, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_FindResponse_1(TElOCSPResponseHandle _Handle, TElPKCS7IssuerHandle Signer, TElX509CertificateHandle Issuer, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_GetSignerCertificate(TElOCSPResponseHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_IsSignerCertificate(TElOCSPResponseHandle _Handle, TElX509CertificateHandle Certificate, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_Validate(TElOCSPResponseHandle _Handle, TSBCMSSignatureValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_Validate_1(TElOCSPResponseHandle _Handle, TElX509CertificateHandle CACertificate, TSBCMSSignatureValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_GetOCSPResponseHash(TElOCSPResponseHandle _Handle, int32_t Alg, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_get_SignatureAlgorithm(TElOCSPResponseHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_get_Certificates(TElOCSPResponseHandle _Handle, TElMemoryCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_get_ResponderID(TElOCSPResponseHandle _Handle, TElOCSPResponderIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_get_ProducedAt(TElOCSPResponseHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_get_Responses(TElOCSPResponseHandle _Handle, int32_t Index, TElOCSPSingleResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_get_ResponseCount(TElOCSPResponseHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_get_OnCertificateNeeded(TElOCSPResponseHandle _Handle, TSBCMSCertificateNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_set_OnCertificateNeeded(TElOCSPResponseHandle _Handle, TSBCMSCertificateNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPResponse_Create(TElOCSPResponseHandle * OutResult);
#endif /* SB_USE_CLASS_TELOCSPRESPONSE */

#ifdef SB_USE_CLASS_TELFILEOCSPCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElFileOCSPClient_SupportsLocation(TElFileOCSPClientHandle _Handle, const char * pcURI, int32_t szURI, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileOCSPClient_PerformRequest(TElFileOCSPClientHandle _Handle, TElOCSPServerErrorRaw * ServerResult, uint8_t pReply[], int32_t * szReply, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileOCSPClient_get_OnOCSPValidationNeeded(TElFileOCSPClientHandle _Handle, TSBOCSPValidationNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileOCSPClient_set_OnOCSPValidationNeeded(TElFileOCSPClientHandle _Handle, TSBOCSPValidationNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElFileOCSPClient_Create(TComponentHandle Owner, TElOCSPClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELFILEOCSPCLIENT */

#ifdef SB_USE_CLASS_TELCUSTOMOCSPCLIENTFACTORY
SB_IMPORT uint32_t SB_APIENTRY TElCustomOCSPClientFactory_SupportsLocation(TElCustomOCSPClientFactoryHandle _Handle, const char * pcURI, int32_t szURI, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomOCSPClientFactory_GetClientInstance(TElCustomOCSPClientFactoryHandle _Handle, TObjectHandle Validator, TElOCSPClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomOCSPClientFactory_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMOCSPCLIENTFACTORY */

#ifdef SB_USE_CLASS_TELOCSPCLIENTMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClientManager_FindOCSPClientByLocation(TElOCSPClientManagerHandle _Handle, const char * pcLocation, int32_t szLocation, TObjectHandle Validator, TElOCSPClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClientManager_RegisterOCSPClientFactory(TElOCSPClientManagerHandle _Handle, TElCustomOCSPClientFactoryHandle Factory);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClientManager_UnregisterOCSPClientFactory(TElOCSPClientManagerHandle _Handle, TElCustomOCSPClientFactoryHandle Factory);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPClientManager_Create(TElOCSPClientManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELOCSPCLIENTMANAGER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElOCSPClient_ce_ptr;
extern zend_class_entry *TElOCSPResponderID_ce_ptr;
extern zend_class_entry *TElOCSPSingleResponse_ce_ptr;
extern zend_class_entry *TElOCSPResponse_ce_ptr;
extern zend_class_entry *TElFileOCSPClient_ce_ptr;
extern zend_class_entry *TElCustomOCSPClientFactory_ce_ptr;
extern zend_class_entry *TElOCSPClientManager_ce_ptr;

void SB_CALLBACK TSBOCSPValidationNeededEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, TStreamHandle RequestStream, TStreamHandle ReplyStream, int8_t * Succeeded);
void Register_TElOCSPClient(TSRMLS_D);
void Register_TElOCSPResponderID(TSRMLS_D);
void Register_TElOCSPSingleResponse(TSRMLS_D);
void Register_TElOCSPResponse(TSRMLS_D);
void Register_TElFileOCSPClient(TSRMLS_D);
void Register_TElCustomOCSPClientFactory(TSRMLS_D);
void Register_TElOCSPClientManager(TSRMLS_D);
SB_PHP_FUNCTION(SBOCSPClient, OCSPClientManagerAddRef);
SB_PHP_FUNCTION(SBOCSPClient, OCSPClientManagerRelease);
SB_PHP_FUNCTION(SBOCSPClient, GetOCSPCertID);
void Register_SBOCSPClient_Enum_Flags(TSRMLS_D);
void Register_SBOCSPClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_OCSPCLIENT
SB_IMPORT uint32_t SB_APIENTRY SBOCSPClient_OCSPClientManagerAddRef(TElOCSPClientManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOCSPClient_OCSPClientManagerRelease(void);
SB_IMPORT uint32_t SB_APIENTRY SBOCSPClient_GetOCSPCertID(TElX509CertificateHandle Cert, TElX509CertificateHandle Issuer, int32_t DigestAlg, uint8_t paIssuerNameHash[], int32_t * szaIssuerNameHash, uint8_t pIssuerKeyHash[], int32_t * szIssuerKeyHash);
SB_IMPORT uint32_t SB_APIENTRY SBOCSPClient_GetOCSPCertID_1(TElPKCS7IssuerHandle Signer, TElX509CertificateHandle Issuer, int32_t DigestAlg, uint8_t paIssuerNameHash[], int32_t * szaIssuerNameHash, uint8_t pIssuerKeyHash[], int32_t * szIssuerKeyHash);
#endif /* SB_USE_GLOBAL_PROCS_OCSPCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBOCSPCLIENT */

