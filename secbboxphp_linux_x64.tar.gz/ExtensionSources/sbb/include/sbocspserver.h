#ifndef __INC_SBOCSPSERVER
#define __INC_SBOCSPSERVER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbencoding.h"
#include "sbpem.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbrdn.h"
#include "sbx509.h"
#include "sbx509ext.h"
#include "sbpkcs7.h"
#include "sbpkcs7utils.h"
#include "sbocspcommon.h"
#include "sbpublickeycrypto.h"
#include "sbconstants.h"
#include "sbcustomcertstorage.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElOCSPServerHandle;

typedef TElOCSPServerHandle ElOCSPServerHandle;

typedef uint8_t TSBOCSPServerOptionRaw;

typedef enum
{
	osoIncludeVersion = 0
} TSBOCSPServerOption;

typedef uint32_t TSBOCSPServerOptionsRaw;

typedef enum 
{
	f_osoIncludeVersion = 1
} TSBOCSPServerOptions;

typedef void (SB_CALLBACK *TSBOCSPSigningCertificatesNeededEvent)(void * _ObjectData, TObjectHandle Sender, TElCustomCertStorageHandle * Certificates);

#ifdef SB_USE_CLASS_TELOCSPSERVER
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_ProcessRequest(TElOCSPServerHandle _Handle, const uint8_t pRequest[], int32_t szRequest, uint8_t pReply[], int32_t * szReply, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_get_ResponderIdType(TElOCSPServerHandle _Handle, TElResponderIDTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_set_ResponderIdType(TElOCSPServerHandle _Handle, TElResponderIDTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_get_RequestCertificates(TElOCSPServerHandle _Handle, TElMemoryCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_get_SignatureAlgorithm(TElOCSPServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_set_SignatureAlgorithm(TElOCSPServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_get_ProducedAt(TElOCSPServerHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_set_ProducedAt(TElOCSPServerHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_get_SignatureRequired(TElOCSPServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_set_SignatureRequired(TElOCSPServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_get_Options(TElOCSPServerHandle _Handle, TSBOCSPServerOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_set_Options(TElOCSPServerHandle _Handle, TSBOCSPServerOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_get_IssuerHashAlgorithm(TElOCSPServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_set_IssuerHashAlgorithm(TElOCSPServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_get_OnCertificateCheck(TElOCSPServerHandle _Handle, TSBCertificateOCSPCheckEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_set_OnCertificateCheck(TElOCSPServerHandle _Handle, TSBCertificateOCSPCheckEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_get_OnSignatureValidate(TElOCSPServerHandle _Handle, TSBOCSPSignatureValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_set_OnSignatureValidate(TElOCSPServerHandle _Handle, TSBOCSPSignatureValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_get_OnSigningCertificatesNeeded(TElOCSPServerHandle _Handle, TSBOCSPSigningCertificatesNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_set_OnSigningCertificatesNeeded(TElOCSPServerHandle _Handle, TSBOCSPSigningCertificatesNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElOCSPServer_Create(TComponentHandle Owner, TElOCSPServerHandle * OutResult);
#endif /* SB_USE_CLASS_TELOCSPSERVER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElOCSPServer_ce_ptr;

void SB_CALLBACK TSBOCSPSigningCertificatesNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomCertStorageHandle * Certificates);
void Register_TElOCSPServer(TSRMLS_D);
void Register_SBOCSPServer_Enum_Flags(TSRMLS_D);
void Register_SBOCSPServer_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBOCSPSERVER */

