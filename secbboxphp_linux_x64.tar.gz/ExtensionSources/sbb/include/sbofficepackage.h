#ifndef __INC_SBOFFICEPACKAGE
#define __INC_SBOFFICEPACKAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbofficecommon.h"
#include "sbofficexmlcore.h"
#include "sbarczip.h"
#include "sbziputils.h"
#include "sbxmlcore.h"
#include "sbxmldefs.h"
#include "sbxmlsec.h"
#include "sbstreams.h"
#include "sbtypes.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElOfficePackagePartHandle;

typedef TElClassHandle TElOfficePackageHandle;

typedef TElClassHandle TElOfficeZipPackageHandle;

typedef TElClassHandle TElOpenOfficePackageHandle;

typedef void (SB_CALLBACK *TSBOfficeGetDataStreamEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TStreamHandle * Stream);

typedef void (SB_CALLBACK *TSBOfficeCloseDataStreamEvent)(void * _ObjectData, TObjectHandle Sender, TStreamHandle Stream);

#ifdef SB_USE_CLASS_TELOFFICEPACKAGEPART
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackagePart_GetStream(TElOfficePackagePartHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackagePart_GetStream_1(TElOfficePackagePartHandle _Handle, int8_t ReadOnly, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackagePart_CloseStream(TElOfficePackagePartHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackagePart_GetRelationshipsStream(TElOfficePackagePartHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackagePart_CloseRelationshipsStream(TElOfficePackagePartHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackagePart_get_Package(TElOfficePackagePartHandle _Handle, TElOfficePackageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackagePart_get_Relationships(TElOfficePackagePartHandle _Handle, TElOfficeOpenXMLRelationshipsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackagePart_get_ContentType(TElOfficePackagePartHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackagePart_get_URI(TElOfficePackagePartHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackagePart_get_IsInterleavedPart(TElOfficePackagePartHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackagePart_get_PieceCount(TElOfficePackagePartHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackagePart_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEPACKAGEPART */

#ifdef SB_USE_CLASS_TELOFFICEPACKAGE
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_Close(TElOfficePackageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_Flush(TElOfficePackageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_FlushCoreProperties(TElOfficePackageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_CreatePart(TElOfficePackageHandle _Handle, const char * pcURI, int32_t szURI, const char * pcContentType, int32_t szContentType, TElOfficePackagePartHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_CreatePart_1(TElOfficePackageHandle _Handle, const char * pcURI, int32_t szURI, const char * pcContentType, int32_t szContentType, uint64_t ExpectedStreamSize, TElOfficePackagePartHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_DeletePart(TElOfficePackageHandle _Handle, const char * pcURI, int32_t szURI);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_GetPart(TElOfficePackageHandle _Handle, const char * pcURI, int32_t szURI, TElOfficePackagePartHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_GetPackageRelatedPartByType(TElOfficePackageHandle _Handle, const char * pcRelType, int32_t szRelType, TElOfficePackagePartHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_GetRelatedPartByType(TElOfficePackageHandle _Handle, TElOfficePackagePartHandle Part, const char * pcRelType, int32_t szRelType, TElOfficePackagePartHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_GetZipPackageStream(TElOfficePackageHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_CloseZipPackageStream(TElOfficePackageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_GetPackageRelationshipsStream(TElOfficePackageHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_ClosePackageRelationshipsStream(TElOfficePackageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_get_IsReadOnly(TElOfficePackageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_get_ContentTypes(TElOfficePackageHandle _Handle, TElOfficeOpenXMLContentTypesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_get_CoreProperties(TElOfficePackageHandle _Handle, TElOfficeOpenXMLCorePropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_get_Relationships(TElOfficePackageHandle _Handle, TElOfficeOpenXMLRelationshipsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_get_PartCount(TElOfficePackageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_get_Parts(TElOfficePackageHandle _Handle, int32_t Index, TElOfficePackagePartHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_get_OnCreateTemporaryStream(TElOfficePackageHandle _Handle, TSBOfficeCreateTemporaryStreamEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_set_OnCreateTemporaryStream(TElOfficePackageHandle _Handle, TSBOfficeCreateTemporaryStreamEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_get_OnCloseTemporaryStream(TElOfficePackageHandle _Handle, TSBOfficeCloseTemporaryStreamEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_set_OnCloseTemporaryStream(TElOfficePackageHandle _Handle, TSBOfficeCloseTemporaryStreamEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficePackage_Create(TElOfficePackageHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEPACKAGE */

#ifdef SB_USE_CLASS_TELOFFICEZIPPACKAGE
SB_IMPORT uint32_t SB_APIENTRY TElOfficeZipPackage_Open(TElOfficeZipPackageHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeZipPackage_Open_1(TElOfficeZipPackageHandle _Handle, TStreamHandle Stream, int8_t OwnStream);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeZipPackage_Open_2(TElOfficeZipPackageHandle _Handle, TStreamHandle Stream, int8_t OwnStream, int8_t ReadOnly);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeZipPackage_Open_3(TElOfficeZipPackageHandle _Handle, TStreamHandle Stream, int64_t StreamOffset, int8_t OwnStream, int8_t ReadOnly, TElZipReaderHandle ZipReader);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeZipPackage_Flush(TElOfficeZipPackageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeZipPackage_Close(TElOfficeZipPackageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeZipPackage_GetZipPackageStream(TElOfficeZipPackageHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeZipPackage_CloseZipPackageStream(TElOfficeZipPackageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeZipPackage_get_CompressionLevel(TElOfficeZipPackageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeZipPackage_set_CompressionLevel(TElOfficeZipPackageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeZipPackage_get_ZipReader(TElOfficeZipPackageHandle _Handle, TElZipReaderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeZipPackage_Create(TElOfficeZipPackageHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEZIPPACKAGE */

#ifdef SB_USE_CLASS_TELOPENOFFICEPACKAGE
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_CreateNew(TElOpenOfficePackageHandle _Handle, TStreamHandle Stream, int8_t OwnStream);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_Open(TElOpenOfficePackageHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_Open_1(TElOpenOfficePackageHandle _Handle, TStreamHandle Stream, int8_t OwnStream);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_Open_2(TElOpenOfficePackageHandle _Handle, TStreamHandle Stream, int8_t OwnStream, int8_t ReadOnly);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_Open_3(TElOpenOfficePackageHandle _Handle, TStreamHandle Stream, int64_t StreamOffset, int8_t OwnStream, int8_t ReadOnly, TElZipReaderHandle ZipReader);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_Flush(TElOpenOfficePackageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_FlushManifest(TElOpenOfficePackageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_Close(TElOpenOfficePackageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_CreateEntry(TElOpenOfficePackageHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_CreateStream(TElOpenOfficePackageHandle _Handle, const char * pcPath, int32_t szPath, uint64_t ExpectedStreamSize, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_GetStream(TElOpenOfficePackageHandle _Handle, const char * pcPath, int32_t szPath, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_GetStream_1(TElOpenOfficePackageHandle _Handle, const char * pcPath, int32_t szPath, int8_t ReadOnly, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_CloseStream(TElOpenOfficePackageHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_CloseStream_1(TElOpenOfficePackageHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_DeleteStream(TElOpenOfficePackageHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_StreamExists(TElOpenOfficePackageHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_get_IsReadOnly(TElOpenOfficePackageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_get_MimeType(TElOpenOfficePackageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_set_MimeType(TElOpenOfficePackageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_get_Manifest(TElOpenOfficePackageHandle _Handle, TElOpenOfficeXMLManifestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_get_CompressionLevel(TElOpenOfficePackageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_set_CompressionLevel(TElOpenOfficePackageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_get_ZipReader(TElOpenOfficePackageHandle _Handle, TElZipReaderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_get_OnCreateTemporaryStream(TElOpenOfficePackageHandle _Handle, TSBOfficeCreateTemporaryStreamEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_set_OnCreateTemporaryStream(TElOpenOfficePackageHandle _Handle, TSBOfficeCreateTemporaryStreamEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_get_OnCloseTemporaryStream(TElOpenOfficePackageHandle _Handle, TSBOfficeCloseTemporaryStreamEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_set_OnCloseTemporaryStream(TElOpenOfficePackageHandle _Handle, TSBOfficeCloseTemporaryStreamEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_get_OnGetDataStream(TElOpenOfficePackageHandle _Handle, TSBOfficeGetDataStreamEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_set_OnGetDataStream(TElOpenOfficePackageHandle _Handle, TSBOfficeGetDataStreamEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_get_OnCloseDataStream(TElOpenOfficePackageHandle _Handle, TSBOfficeCloseDataStreamEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_set_OnCloseDataStream(TElOpenOfficePackageHandle _Handle, TSBOfficeCloseDataStreamEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficePackage_Create(TElOpenOfficePackageHandle * OutResult);
#endif /* SB_USE_CLASS_TELOPENOFFICEPACKAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElOfficePackagePart_ce_ptr;
extern zend_class_entry *TElOfficePackage_ce_ptr;
extern zend_class_entry *TElOfficeZipPackage_ce_ptr;
extern zend_class_entry *TElOpenOfficePackage_ce_ptr;

void SB_CALLBACK TSBOfficeGetDataStreamEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TStreamHandle * Stream);
void SB_CALLBACK TSBOfficeCloseDataStreamEventRaw(void * _ObjectData, TObjectHandle Sender, TStreamHandle Stream);
void Register_TElOfficePackagePart(TSRMLS_D);
void Register_TElOfficePackage(TSRMLS_D);
void Register_TElOfficeZipPackage(TSRMLS_D);
void Register_TElOpenOfficePackage(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBOFFICEPACKAGE */

