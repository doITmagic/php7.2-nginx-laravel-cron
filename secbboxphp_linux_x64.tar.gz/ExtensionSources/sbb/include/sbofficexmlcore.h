#ifndef __INC_SBOFFICEXMLCORE
#define __INC_SBOFFICEXMLCORE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbofficeconstants.h"
#include "sbofficecommon.h"
#include "sbofficeresources.h"
#include "sbxmlcore.h"
#include "sbxmldefs.h"
#include "sbxmlsec.h"
#include "sbxmlsig.h"
#include "sbxmltransform.h"
#include "sbxmlutils.h"
#include "sbtypes.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ooxmlRelationshipsNamespace 	"http://schemas.openxmlformats.org/package/2006/relationships"
#define SB_ooxmlOfficeRelationshipsNamespace 	"http://schemas.openxmlformats.org/officeDocument/2006/relationships"
#define SB_ooxmlContentTypesNamespace 	"http://schemas.openxmlformats.org/package/2006/content-types"
#define SB_ooxmlCorePropertiesNamespace 	"http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
#define SB_ooxmlDigitalSignatureNamespace 	"http://schemas.openxmlformats.org/package/2006/digital-signature"
#define SB_ooxmlMarkupCompatibilityNamespace 	"http://schemas.openxmlformats.org/markup-compatibility/2006"
#define SB_ooxmlDublinCoreTermsNamespace 	"http://purl.org/dc/terms/"
#define SB_ooxmlDublinCoreNamespace 	"http://purl.org/dc/elements/1.1/"
#define SB_ooxmlOfficeEncryptionNamespace 	"http://schemas.microsoft.com/office/2006/encryption"
#define SB_ooxmlKeyEncryptorPasswordNamespace 	"http://schemas.microsoft.com/office/2006/keyEncryptor/password"
#define SB_ooxmlOfficeDigitalSignatureNamespace 	"http://schemas.microsoft.com/office/2006/digsig"
#define SB_oxpsNamespace_200506 	"http://schemas.microsoft.com/xps/2005/06"
#define SB_oxpsNamespace_V1 	"http://schemas.openxps.org/oxps/v1.0"
#define SB_oxpsNamespace_Latest 	"http://schemas.microsoft.com/xps/2005/06"
#define SB_oxpsSignatureDefinitionsNamespace_200506 	"http://schemas.microsoft.com/xps/2005/06/signature-definitions"
#define SB_oxpsSignatureDefinitionsNamespace_V1 	"http://schemas.openxps.org/oxps/v1.0/signature-definitions"
#define SB_oxpsSignatureDefinitionsNamespace_Latest 	"http://schemas.microsoft.com/xps/2005/06/signature-definitions"
#define SB_ooxmlMSVMLNamespace 	"urn:schemas-microsoft-com:vml"
#define SB_ooxmlMSOfficeNamespace 	"urn:schemas-microsoft-com:office:office"
#define SB_ooxmlMSOfficeWordNamespace 	"urn:schemas-microsoft-com:office:word"
#define SB_ooxmlMSOfficeExcelNamespace 	"urn:schemas-microsoft-com:office:excel"
#define SB_ooxmlMSOfficePowerpointNamespace 	"urn:schemas-microsoft-com:office:powerpoint"
#define SB_ooxmlMSOfficeSpreadSheetMLNamespace 	"http://schemas.openxmlformats.org/spreadsheetml/2006/main"
#define SB_odfManifestNamespace 	"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0"
#define SB_odfSignatureNamespace 	"urn:oasis:names:tc:opendocument:xmlns:digitalsignature:1.0"
#define SB_odfPackageNamespace 	"http://docs.oasis-open.org/ns/office/1.2/meta/pkg#"
#define SB_ooxmlDublinCoreTermsPrefix 	"dcterms"
#define SB_ooxmlDublinCorePrefix 	"dc"
#define SB_ooxmlKeyEncryptorPasswordPrefix 	'p'
#define SB_odfManifestPrefix 	"manifest"
#define SB_ooxmlOfficeDocumentRelationshipType 	"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"
#define SB_ooxmlCorePropertiesRelationshipType 	"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties"
#define SB_ooxmlDigitalSignatureRelationshipType 	"http://schemas.openxmlformats.org/package/2006/relationships/digital-signature/signature"
#define SB_ooxmlDigitalSignatureOriginRelationshipType 	"http://schemas.openxmlformats.org/package/2006/relationships/digital-signature/origin"
#define SB_ooxmlDigitalSignatureCertificateRelationshipType 	"http://schemas.openxmlformats.org/package/2006/relationships/digital-signature/certificate"
#define SB_ooxmlThumbnailRelationshipType 	"http://schemas.openxmlformats.org/package/2006/relationships/metadata/thumbnail"
#define SB_ooxmlApplicationPropertiesRelationshipType 	"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties"
#define SB_ooxmlCustomXMLPropertiesRelationshipType 	"http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXmlProps"
#define SB_ooxmlCustomXMLRelationshipType 	"http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml"
#define SB_ooxmlCorePropertiesContentType 	"application/vnd.openxmlformats-package.core-properties+xml"
#define SB_ooxmlApplicationPropertiesContentType 	"application/vnd.openxmlformats-officedocument.extended-properties+xml"
#define SB_ooxmlDigitalSignatureCertificateContentType 	"application/vnd.openxmlformats-package.digital-signature-certificate"
#define SB_ooxmlDigitalSignatureOriginContentType 	"application/vnd.openxmlformats-package.digital-signature-origin"
#define SB_ooxmlDigitalSignatureXMLSignatureContentType 	"application/vnd.openxmlformats-package.digital-signature-xmlsignature+xml"
#define SB_ooxmlRelationshipsContentType 	"application/vnd.openxmlformats-package.relationships+xml"
#define SB_ooxmlCustomXMLPropertiesContentType 	"application/vnd.openxmlformats-officedocument.customXmlProperties+xml"
#define SB_ooxmlWordprocessingMLContentType 	"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"
#define SB_ooxmlWordMacroEnabledContentType 	"application/vnd.ms-word.document.macroEnabled.main+xml"
#define SB_ooxmlWordprocessingMLTemplateContentType 	"application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml"
#define SB_ooxmlWordTemplateMacroEnabledContentType 	"application/vnd.ms-word.template.macroEnabledTemplate.main+xml"
#define SB_ooxmlSpreadsheetMLContentType 	"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"
#define SB_ooxmlSpreadsheetMLWorksheetContentType 	"application/vnd.openxmlformatsofficedocument.spreadsheetml.worksheet+xml"
#define SB_ooxmlExcelMacroEnabledContentType 	"application/vnd.ms-excel.sheet.macroEnabled.main+xml"
#define SB_ooxmlSpreadsheetMLTemplateContentType 	"application/vnd.openxmlformats-officedocument.spreadsheetml.template.main+xml"
#define SB_ooxmlExcelTemplateMacroEnabledContentType 	"application/vnd.ms-excel.template.macroEnabled.main+xml"
#define SB_ooxmlExcelBinaryMacroEnabledContentType 	"application/vnd.ms-excel.sheet.binary.macroEnabled.main"
#define SB_ooxmlExcelAddInMacroEnabledContentType 	"application/vnd.ms-excel.addin.macroEnabled.main+xml"
#define SB_ooxmlPresentationMLContentType 	"application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"
#define SB_ooxmlPowerPointMacroEnabledContentType 	"application/vnd.ms-powerpoint.presentation.macroEnabled.main+xml"
#define SB_ooxmlPresentationMLTemplateContentType 	"application/vnd.openxmlformats-officedocument.presentationml.template.main+xml"
#define SB_ooxmlPowerPointTemplateMacroEnabledContentType 	"application/vnd.ms-powerpoint.template.macroEnabled.main+xml"
#define SB_ooxmlPresentationMLSlideshowContentType 	"application/vnd.openxmlformats-officedocument.presentationml.slideshow.main+xml"
#define SB_ooxmlPowerPointSlideshowMacroEnabledContentType 	"application/vnd.ms-powerpoint.slideshow.macroEnabled.main+xml"
#define SB_ooxmlPowerPointAddInMacroEnabledContentType 	"application/vnd.ms-powerpoint.addin.macroEnabled.main+xml"
#define SB_oxpsSignatureDefinitionsContentType 	"application/vnd.ms-package.xpssignaturedefinitions+xml"
#define SB_oxpsFixedDocumentContentType 	"application/vnd.ms-package.xps-fixeddocument+xml"
#define SB_oxpsFixedDocumentSequenceContentType 	"application/vnd.ms-package.xpsfixeddocumentsequence+xml"
#define SB_oxpsFixedPageContentType 	"application/vnd.ms-package.xps-fixedpage+xml"
#define SB_oxpsDiscardControlContentType 	"application/vnd.ms-package.xps-discard-control+xml"
#define SB_oxpsDocumentStructureContentType 	"application/vnd.ms-package.xpsdocumentstructure+xml"
#define SB_oxpsFontContentType 	"application/vnd.ms-opentype"
#define SB_oxpsICCProfileContentType 	"application/vnd.ms-color.iccprofile"
#define SB_oxpsObfuscatedFontContentType 	"application/vnd.ms-package.obfuscated-opentype"
#define SB_oxpsStoryFragmentsContentType 	"application/vnd.ms-package.xps-storyfragments+xml"
#define SB_oxpsPrintTicketContentType 	"application/vnd.ms-printing.printticket+xml"
#define SB_oxpsDigitalSignatureDefinitionsRelationshipType 	"http://schemas.microsoft.com/xps/2005/06/signature-definitions"
#define SB_oxpsDiscardControlRelationshipType 	"http://schemas.microsoft.com/xps/2005/06/discard-control"
#define SB_oxpsDocumentStructureRelationshipType 	"http://schemas.microsoft.com/xps/2005/06/documentstructure"
#define SB_oxpsPrintTicketRelationshipType 	"http://schemas.microsoft.com/xps/2005/06/printticket"
#define SB_oxpsRequiredResourceRelationshipType 	"http://schemas.microsoft.com/xps/2005/06/required-resource"
#define SB_oxpsRestrictedFontRelationshipType 	"http://schemas.microsoft.com/xps/2005/06/restricted-font"
#define SB_oxpsStartPartRelationshipType 	"http://schemas.microsoft.com/xps/2005/06/fixedrepresentation"
#define SB_oxpsStoryFragmentsRelationshipType 	"http://schemas.microsoft.com/xps/2005/06/storyfragments"
#define SB_ooxmlTransformRelationship_2006 	"http://schemas.openxmlformats.org/package/2006/RelationshipTransform"
#define SB_ooxmlTransformRelationship_200506 	"http://schemas.openxmlformats.org/package/2005/06/RelationshipTransform"
#define SB_ooxmlTransformRelationship_Latest 	"http://schemas.openxmlformats.org/package/2006/RelationshipTransform"
#define SB_oxJPEGImageContentType 	"image/jpeg"
#define SB_oxPNGImageContentType 	"image/png"
#define SB_oxTIFFImageContentType 	"image/tiff"
#define SB_odfOpenDocumentTextMimeType 	"application/vnd.oasis.opendocument.text"
#define SB_odfOpenDocumentTextTemplateMimeType 	"application/vnd.oasis.opendocument.text-template"
#define SB_odfOpenDocumentTextMasterMimeType 	"application/vnd.oasis.opendocument.text-master"
#define SB_odfOpenDocumentTextWebMimeType 	"application/vnd.oasis.opendocument.text-web"
#define SB_odfOpenDocumentSpreadsheetMimeType 	"application/vnd.oasis.opendocument.spreadsheet"
#define SB_odfOpenDocumentSpreadsheetTemplateMimeType 	"application/vnd.oasis.opendocument.spreadsheet-template"
#define SB_odfOpenDocumentDrawingMimeType 	"application.vnd.oasis.opendocument.graphics"
#define SB_odfOpenDocumentDrawingTemplateMimeType 	"application/vnd.oasis.opendocument.graphic-template"
#define SB_odfOpenDocumentPresentationMimeType 	"application/vnd.oasis.opendocument.presentation"
#define SB_odfOpenDocumentPresentationTemplateMimeType 	"application/vnd.oasis.opendocument.presentation-template"
#define SB_odfOpenDocumentChartMimeType 	"application/vnd.oasis.opendocument.chart"
#define SB_odfOpenDocumentChartTemplateMimeType 	"application/vnd.oasis.opendocument.chart-template"
#define SB_odfOpenDocumentImageMimeType 	"application/vnd.oasis.opendocument.image"
#define SB_odfOpenDocumentImageTemplateMimeType 	"application/vnd.oasis.opendocument.image-template"
#define SB_odfOpenDocumentFormulaMimeType 	"application/vnd.oasis.opendocument.formula"
#define SB_odfOpenDocumentFormulaTemplateMimeType 	"application/vnd.oasis.opendocument.formula-template"
#define SB_odfOpenDocumentDatabaseMimeType 	"application/vnd.oasis.opendocument.base"
#define SB_odfEncryptionMethodBlowfish 	"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0#blowfish"
#define SB_odfDigestMethodSHA1 	"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0#sha1"
#define SB_odfDigestMethodSHA1_1K 	"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0#sha1-1k"
#define SB_odfDigestMethodSHA256_1K 	"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0#sha256-1k"
#define SB_odfDerivationMethodPBKDF2 	"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0#pbkdf2"

typedef TElClassHandle TElOfficeOpenXMLElementHandle;

typedef TElClassHandle TElOfficeOpenXMLRelationshipHandle;

typedef TElClassHandle TElOfficeOpenXMLRelationshipsHandle;

typedef TElClassHandle TElOfficeOpenXMLDefaultHandle;

typedef TElClassHandle TElOfficeOpenXMLDefaultListHandle;

typedef TElClassHandle TElOfficeOpenXMLOverrideHandle;

typedef TElClassHandle TElOfficeOpenXMLOverrideListHandle;

typedef TElClassHandle TElOfficeOpenXMLContentTypesHandle;

typedef TElClassHandle TElOfficeXMLDCSimpleLiteralHandle;

typedef TElClassHandle TElOfficeXMLDCDateHandle;

typedef TElClassHandle TElOfficeOpenXMLCorePropertiesHandle;

typedef TElClassHandle TElOfficeXMLKeyDataHandle;

typedef TElClassHandle TElOfficeXMLDataIntegrityHandle;

typedef TElClassHandle TElOfficeXMLKeyEncryptorHandle;

typedef TElClassHandle TElOfficeXMLKeyEncryptorsHandle;

typedef TElClassHandle TElOfficeXMLPasswordKeyEncryptorHandle;

typedef TElClassHandle TElOfficeXMLEncryptionHandle;

typedef TElClassHandle TElOfficeXMLSignatureTimeHandle;

typedef TElClassHandle TElOfficeOpenXMLRelationshipTransformHandle;

typedef TElClassHandle TElOfficeXMLSignatureInfoV1Handle;

typedef TElClassHandle TElOfficeXMLSpotLocationHandle;

typedef TElClassHandle TElOfficeXMLSignatureDefinitionHandle;

typedef TElClassHandle TElOfficeXMLFixedDocumentSequenceHandle;

typedef TElClassHandle TElOfficeXMLPageContentHandle;

typedef TElClassHandle TElOfficeXMLFixedDocumentHandle;

typedef TElClassHandle TElOpenOfficeXMLManifestAlgorithmHandle;

typedef TElClassHandle TElOpenOfficeXMLManifestKeyDerivationHandle;

typedef TElClassHandle TElOpenOfficeXMLManifestStartKeyGenerationHandle;

typedef TElClassHandle TElOpenOfficeXMLManifestEncryptionDataHandle;

typedef TElClassHandle TElOpenOfficeXMLManifestFileEntryHandle;

typedef TElClassHandle TElOpenOfficeXMLManifestHandle;

typedef uint8_t TSBOfficeOpenXMLTargetModeRaw;

typedef enum
{
	tmInternal = 0,
	tmExternal = 1
} TSBOfficeOpenXMLTargetMode;

#ifdef SB_USE_CLASS_TELOFFICEOPENXMLELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLElement_Clear(TElOfficeOpenXMLElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLElement_get_IsModified(TElOfficeOpenXMLElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLElement_set_IsModified(TElOfficeOpenXMLElementHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEOPENXMLELEMENT */

#ifdef SB_USE_CLASS_TELOFFICEOPENXMLRELATIONSHIP
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationship_Clear(TElOfficeOpenXMLRelationshipHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationship_LoadFromXML(TElOfficeOpenXMLRelationshipHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationship_SaveToXML(TElOfficeOpenXMLRelationshipHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationship_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationship_get_ID(TElOfficeOpenXMLRelationshipHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationship_set_ID(TElOfficeOpenXMLRelationshipHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationship_get_RelationshipType(TElOfficeOpenXMLRelationshipHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationship_set_RelationshipType(TElOfficeOpenXMLRelationshipHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationship_get_Target(TElOfficeOpenXMLRelationshipHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationship_set_Target(TElOfficeOpenXMLRelationshipHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationship_get_TargetMode(TElOfficeOpenXMLRelationshipHandle _Handle, TSBOfficeOpenXMLTargetModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationship_set_TargetMode(TElOfficeOpenXMLRelationshipHandle _Handle, TSBOfficeOpenXMLTargetModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationship_Create(TElOfficeOpenXMLRelationshipHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEOPENXMLRELATIONSHIP */

#ifdef SB_USE_CLASS_TELOFFICEOPENXMLRELATIONSHIPS
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_Add(TElOfficeOpenXMLRelationshipsHandle _Handle, TElOfficeOpenXMLRelationshipHandle ARelationship, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_Add_1(TElOfficeOpenXMLRelationshipsHandle _Handle, const char * pcID, int32_t szID, const char * pcTarget, int32_t szTarget, const char * pcRelationshipType, int32_t szRelationshipType, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_Insert(TElOfficeOpenXMLRelationshipsHandle _Handle, int32_t Index, TElOfficeOpenXMLRelationshipHandle ARelationship);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_Delete(TElOfficeOpenXMLRelationshipsHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_Clear(TElOfficeOpenXMLRelationshipsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_CreateRelationship(TElOfficeOpenXMLRelationshipsHandle _Handle, const char * pcTarget, int32_t szTarget, TSBOfficeOpenXMLTargetModeRaw TargetMode, const char * pcRelationshipType, int32_t szRelationshipType, const char * pcID, int32_t szID, TElOfficeOpenXMLRelationshipHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_GetRelationshipById(TElOfficeOpenXMLRelationshipsHandle _Handle, const char * pcID, int32_t szID, TElOfficeOpenXMLRelationshipHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_GetRelationshipByType(TElOfficeOpenXMLRelationshipsHandle _Handle, const char * pcRelType, int32_t szRelType, TElOfficeOpenXMLRelationshipHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_SortRelationshipsById(TElOfficeOpenXMLRelationshipsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_LoadFromXML(TElOfficeOpenXMLRelationshipsHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_SaveToXML(TElOfficeOpenXMLRelationshipsHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_get_Count(TElOfficeOpenXMLRelationshipsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_get_Relationships(TElOfficeOpenXMLRelationshipsHandle _Handle, int32_t Index, TElOfficeOpenXMLRelationshipHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationships_Create(TElOfficeOpenXMLRelationshipsHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEOPENXMLRELATIONSHIPS */

#ifdef SB_USE_CLASS_TELOFFICEOPENXMLDEFAULT
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefault_Clear(TElOfficeOpenXMLDefaultHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefault_LoadFromXML(TElOfficeOpenXMLDefaultHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefault_SaveToXML(TElOfficeOpenXMLDefaultHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefault_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefault_get_ContentType(TElOfficeOpenXMLDefaultHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefault_set_ContentType(TElOfficeOpenXMLDefaultHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefault_get_Extension(TElOfficeOpenXMLDefaultHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefault_set_Extension(TElOfficeOpenXMLDefaultHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefault_Create(TElOfficeOpenXMLDefaultHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEOPENXMLDEFAULT */

#ifdef SB_USE_CLASS_TELOFFICEOPENXMLDEFAULTLIST
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefaultList_Add(TElOfficeOpenXMLDefaultListHandle _Handle, TElOfficeOpenXMLDefaultHandle ADefault, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefaultList_Insert(TElOfficeOpenXMLDefaultListHandle _Handle, int32_t Index, TElOfficeOpenXMLDefaultHandle ADefault);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefaultList_Delete(TElOfficeOpenXMLDefaultListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefaultList_Clear(TElOfficeOpenXMLDefaultListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefaultList_get_Count(TElOfficeOpenXMLDefaultListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefaultList_get_DefaultItems(TElOfficeOpenXMLDefaultListHandle _Handle, int32_t Index, TElOfficeOpenXMLDefaultHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLDefaultList_Create(TElOfficeOpenXMLDefaultListHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEOPENXMLDEFAULTLIST */

#ifdef SB_USE_CLASS_TELOFFICEOPENXMLOVERRIDE
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverride_Clear(TElOfficeOpenXMLOverrideHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverride_LoadFromXML(TElOfficeOpenXMLOverrideHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverride_SaveToXML(TElOfficeOpenXMLOverrideHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverride_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverride_get_ContentType(TElOfficeOpenXMLOverrideHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverride_set_ContentType(TElOfficeOpenXMLOverrideHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverride_get_PartName(TElOfficeOpenXMLOverrideHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverride_set_PartName(TElOfficeOpenXMLOverrideHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverride_Create(TElOfficeOpenXMLOverrideHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEOPENXMLOVERRIDE */

#ifdef SB_USE_CLASS_TELOFFICEOPENXMLOVERRIDELIST
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverrideList_Add(TElOfficeOpenXMLOverrideListHandle _Handle, TElOfficeOpenXMLOverrideHandle AOverride, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverrideList_Insert(TElOfficeOpenXMLOverrideListHandle _Handle, int32_t Index, TElOfficeOpenXMLOverrideHandle AOverride);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverrideList_Delete(TElOfficeOpenXMLOverrideListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverrideList_Clear(TElOfficeOpenXMLOverrideListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverrideList_get_Count(TElOfficeOpenXMLOverrideListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverrideList_get_OverrideItems(TElOfficeOpenXMLOverrideListHandle _Handle, int32_t Index, TElOfficeOpenXMLOverrideHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLOverrideList_Create(TElOfficeOpenXMLOverrideListHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEOPENXMLOVERRIDELIST */

#ifdef SB_USE_CLASS_TELOFFICEOPENXMLCONTENTTYPES
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLContentTypes_Clear(TElOfficeOpenXMLContentTypesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLContentTypes_LoadFromXML(TElOfficeOpenXMLContentTypesHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLContentTypes_SaveToXML(TElOfficeOpenXMLContentTypesHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLContentTypes_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLContentTypes_get_Defaults(TElOfficeOpenXMLContentTypesHandle _Handle, TElOfficeOpenXMLDefaultListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLContentTypes_get_Overrides(TElOfficeOpenXMLContentTypesHandle _Handle, TElOfficeOpenXMLOverrideListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLContentTypes_Create(TElOfficeOpenXMLContentTypesHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEOPENXMLCONTENTTYPES */

#ifdef SB_USE_CLASS_TELOFFICEXMLDCSIMPLELITERAL
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCSimpleLiteral_Clear(TElOfficeXMLDCSimpleLiteralHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCSimpleLiteral_IsEmpty(TElOfficeXMLDCSimpleLiteralHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCSimpleLiteral_LoadFromXML(TElOfficeXMLDCSimpleLiteralHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCSimpleLiteral_SaveToXML(TElOfficeXMLDCSimpleLiteralHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCSimpleLiteral_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCSimpleLiteral_get_Language(TElOfficeXMLDCSimpleLiteralHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCSimpleLiteral_set_Language(TElOfficeXMLDCSimpleLiteralHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCSimpleLiteral_get_Value(TElOfficeXMLDCSimpleLiteralHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCSimpleLiteral_set_Value(TElOfficeXMLDCSimpleLiteralHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCSimpleLiteral_Create(const char * pcAName, int32_t szAName, TElOfficeXMLDCSimpleLiteralHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLDCSIMPLELITERAL */

#ifdef SB_USE_CLASS_TELOFFICEXMLDCDATE
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCDate_Clear(TElOfficeXMLDCDateHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCDate_IsEmpty(TElOfficeXMLDCDateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCDate_LoadFromXML(TElOfficeXMLDCDateHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCDate_SaveToXML(TElOfficeXMLDCDateHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCDate_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCDate_get_Value(TElOfficeXMLDCDateHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCDate_set_Value(TElOfficeXMLDCDateHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCDate_get_ValueUTC(TElOfficeXMLDCDateHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCDate_set_ValueUTC(TElOfficeXMLDCDateHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCDate_get_DateTimeFormat(TElOfficeXMLDCDateHandle _Handle, TSBXMLDateTimeFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCDate_set_DateTimeFormat(TElOfficeXMLDCDateHandle _Handle, TSBXMLDateTimeFormatRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCDate_get_IncludeTimeZone(TElOfficeXMLDCDateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCDate_set_IncludeTimeZone(TElOfficeXMLDCDateHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDCDate_Create(TElOfficeXMLDCDateHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLDCDATE */

#ifdef SB_USE_CLASS_TELOFFICEOPENXMLCOREPROPERTIES
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_Clear(TElOfficeOpenXMLCorePropertiesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_LoadFromXML(TElOfficeOpenXMLCorePropertiesHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_SaveToXML(TElOfficeOpenXMLCorePropertiesHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_get_Category(TElOfficeOpenXMLCorePropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_set_Category(TElOfficeOpenXMLCorePropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_get_ContentStatus(TElOfficeOpenXMLCorePropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_set_ContentStatus(TElOfficeOpenXMLCorePropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_get_Creator(TElOfficeOpenXMLCorePropertiesHandle _Handle, TElOfficeXMLDCSimpleLiteralHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_get_Description(TElOfficeOpenXMLCorePropertiesHandle _Handle, TElOfficeXMLDCSimpleLiteralHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_get_Identifier(TElOfficeOpenXMLCorePropertiesHandle _Handle, TElOfficeXMLDCSimpleLiteralHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_get_Language(TElOfficeOpenXMLCorePropertiesHandle _Handle, TElOfficeXMLDCSimpleLiteralHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_get_LastModifiedBy(TElOfficeOpenXMLCorePropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_set_LastModifiedBy(TElOfficeOpenXMLCorePropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_get_Revision(TElOfficeOpenXMLCorePropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_set_Revision(TElOfficeOpenXMLCorePropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_get_Subject(TElOfficeOpenXMLCorePropertiesHandle _Handle, TElOfficeXMLDCSimpleLiteralHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_get_Title(TElOfficeOpenXMLCorePropertiesHandle _Handle, TElOfficeXMLDCSimpleLiteralHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_get_Version(TElOfficeOpenXMLCorePropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_set_Version(TElOfficeOpenXMLCorePropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLCoreProperties_Create(TElOfficeOpenXMLCorePropertiesHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEOPENXMLCOREPROPERTIES */

#ifdef SB_USE_CLASS_TELOFFICEXMLKEYDATA
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_Clear(TElOfficeXMLKeyDataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_LoadFromXML(TElOfficeXMLKeyDataHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_SaveToXML(TElOfficeXMLKeyDataHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_get_SaltSize(TElOfficeXMLKeyDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_set_SaltSize(TElOfficeXMLKeyDataHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_get_BlockSize(TElOfficeXMLKeyDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_set_BlockSize(TElOfficeXMLKeyDataHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_get_KeyBits(TElOfficeXMLKeyDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_set_KeyBits(TElOfficeXMLKeyDataHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_get_HashSize(TElOfficeXMLKeyDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_set_HashSize(TElOfficeXMLKeyDataHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_get_CipherAlgorithm(TElOfficeXMLKeyDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_set_CipherAlgorithm(TElOfficeXMLKeyDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_get_CipherChaining(TElOfficeXMLKeyDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_set_CipherChaining(TElOfficeXMLKeyDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_get_HashAlgorithm(TElOfficeXMLKeyDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_set_HashAlgorithm(TElOfficeXMLKeyDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_get_SaltValue(TElOfficeXMLKeyDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_set_SaltValue(TElOfficeXMLKeyDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyData_Create(TElOfficeXMLKeyDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLKEYDATA */

#ifdef SB_USE_CLASS_TELOFFICEXMLDATAINTEGRITY
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDataIntegrity_Clear(TElOfficeXMLDataIntegrityHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDataIntegrity_LoadFromXML(TElOfficeXMLDataIntegrityHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDataIntegrity_SaveToXML(TElOfficeXMLDataIntegrityHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDataIntegrity_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDataIntegrity_get_EncryptedHmacKey(TElOfficeXMLDataIntegrityHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDataIntegrity_set_EncryptedHmacKey(TElOfficeXMLDataIntegrityHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDataIntegrity_get_EncryptedHmacValue(TElOfficeXMLDataIntegrityHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDataIntegrity_set_EncryptedHmacValue(TElOfficeXMLDataIntegrityHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLDataIntegrity_Create(TElOfficeXMLDataIntegrityHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLDATAINTEGRITY */

#ifdef SB_USE_CLASS_TELOFFICEXMLKEYENCRYPTOR
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyEncryptor_get_URI(TElOfficeXMLKeyEncryptorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyEncryptor_Create(TElOfficeXMLKeyEncryptorHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLKEYENCRYPTOR */

#ifdef SB_USE_CLASS_TELOFFICEXMLKEYENCRYPTORS
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyEncryptors_Add(TElOfficeXMLKeyEncryptorsHandle _Handle, TElOfficeXMLKeyEncryptorHandle AKeyEncryptor, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyEncryptors_Insert(TElOfficeXMLKeyEncryptorsHandle _Handle, int32_t Index, TElOfficeXMLKeyEncryptorHandle AKeyEncryptor);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyEncryptors_Delete(TElOfficeXMLKeyEncryptorsHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyEncryptors_Clear(TElOfficeXMLKeyEncryptorsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyEncryptors_LoadFromXML(TElOfficeXMLKeyEncryptorsHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyEncryptors_SaveToXML(TElOfficeXMLKeyEncryptorsHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyEncryptors_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyEncryptors_get_Count(TElOfficeXMLKeyEncryptorsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyEncryptors_get_KeyEncryptors(TElOfficeXMLKeyEncryptorsHandle _Handle, int32_t Index, TElOfficeXMLKeyEncryptorHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLKeyEncryptors_Create(TElOfficeXMLKeyEncryptorsHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLKEYENCRYPTORS */

#ifdef SB_USE_CLASS_TELOFFICEXMLPASSWORDKEYENCRYPTOR
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_Clear(TElOfficeXMLPasswordKeyEncryptorHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_LoadFromXML(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_SaveToXML(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_get_SaltSize(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_set_SaltSize(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_get_BlockSize(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_set_BlockSize(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_get_KeyBits(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_set_KeyBits(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_get_HashSize(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_set_HashSize(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_get_CipherAlgorithm(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_set_CipherAlgorithm(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_get_CipherChaining(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_set_CipherChaining(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_get_HashAlgorithm(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_set_HashAlgorithm(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_get_SaltValue(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_set_SaltValue(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_get_SpinCount(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_set_SpinCount(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_get_EncryptedVerifierHashInput(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_set_EncryptedVerifierHashInput(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_get_EncryptedVerifierHashValue(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_set_EncryptedVerifierHashValue(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_get_EncryptedKeyValue(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_set_EncryptedKeyValue(TElOfficeXMLPasswordKeyEncryptorHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPasswordKeyEncryptor_Create(TElOfficeXMLPasswordKeyEncryptorHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLPASSWORDKEYENCRYPTOR */

#ifdef SB_USE_CLASS_TELOFFICEXMLENCRYPTION
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLEncryption_Clear(TElOfficeXMLEncryptionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLEncryption_LoadFromXML(TElOfficeXMLEncryptionHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLEncryption_SaveToXML(TElOfficeXMLEncryptionHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLEncryption_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLEncryption_get_DataIntegrity(TElOfficeXMLEncryptionHandle _Handle, TElOfficeXMLDataIntegrityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLEncryption_get_KeyData(TElOfficeXMLEncryptionHandle _Handle, TElOfficeXMLKeyDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLEncryption_get_KeyEncryptors(TElOfficeXMLEncryptionHandle _Handle, TElOfficeXMLKeyEncryptorsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLEncryption_Create(TElOfficeXMLEncryptionHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLENCRYPTION */

#ifdef SB_USE_CLASS_TELOFFICEXMLSIGNATURETIME
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureTime_Clear(TElOfficeXMLSignatureTimeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureTime_LoadFromXML(TElOfficeXMLSignatureTimeHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureTime_SaveToXML(TElOfficeXMLSignatureTimeHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureTime_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureTime_get_Format(TElOfficeXMLSignatureTimeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureTime_set_Format(TElOfficeXMLSignatureTimeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureTime_get_Value(TElOfficeXMLSignatureTimeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureTime_set_Value(TElOfficeXMLSignatureTimeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureTime_get_ValueUTC(TElOfficeXMLSignatureTimeHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureTime_set_ValueUTC(TElOfficeXMLSignatureTimeHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureTime_Create(TElOfficeXMLSignatureTimeHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLSIGNATURETIME */

#ifdef SB_USE_CLASS_TELOFFICEOPENXMLRELATIONSHIPTRANSFORM
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_GetDefaultTransformAlgorithmURI(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_GetDefaultTransformAlgorithmURI_1(TElOfficeOpenXMLRelationshipTransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_IsTransformAlgorithmSupported(const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_IsTransformAlgorithmSupported_1(TElOfficeOpenXMLRelationshipTransformHandle _Handle, const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_Clear(TElOfficeOpenXMLRelationshipTransformHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_AddSourceId(TElOfficeOpenXMLRelationshipTransformHandle _Handle, const char * pcSourceId, int32_t szSourceId, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_AddSourceType(TElOfficeOpenXMLRelationshipTransformHandle _Handle, const char * pcSourceType, int32_t szSourceType, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_DeleteSourceId(TElOfficeOpenXMLRelationshipTransformHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_DeleteSourceType(TElOfficeOpenXMLRelationshipTransformHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_LoadFromXML(TElOfficeOpenXMLRelationshipTransformHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_SaveToXML(TElOfficeOpenXMLRelationshipTransformHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_TransformData(TElOfficeOpenXMLRelationshipTransformHandle _Handle, const uint8_t pData[], int32_t szData, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_TransformData_1(TElOfficeOpenXMLRelationshipTransformHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLDOMNodeHandle Reference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_TransformData_2(TElOfficeOpenXMLRelationshipTransformHandle _Handle, TElXMLDOMNodeListHandle Nodes, const TElXMLDOMNodeHandle pReference[], int32_t szReference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_TransformNode(TElOfficeOpenXMLRelationshipTransformHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_get_SourceIdCount(TElOfficeOpenXMLRelationshipTransformHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_get_SourceTypeCount(TElOfficeOpenXMLRelationshipTransformHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_get_SourceIds(TElOfficeOpenXMLRelationshipTransformHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_get_SourceTypes(TElOfficeOpenXMLRelationshipTransformHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeOpenXMLRelationshipTransform_Create(TElOfficeOpenXMLRelationshipTransformHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEOPENXMLRELATIONSHIPTRANSFORM */

#ifdef SB_USE_CLASS_TELOFFICEXMLSIGNATUREINFOV1
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_Clear(TElOfficeXMLSignatureInfoV1Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_CheckReferences(TElOfficeXMLSignatureInfoV1Handle _Handle, TElXMLReferenceListHandle Refs, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_CreateReferences(TElOfficeXMLSignatureInfoV1Handle _Handle, TElXMLReferenceListHandle Refs, TElXMLDigestMethodRaw DigestMethod);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_CreateObjects(TElOfficeXMLSignatureInfoV1Handle _Handle, TElXMLObjectListHandle Objects, const char * pcTarget, int32_t szTarget, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_LoadFromObjectList(TElOfficeXMLSignatureInfoV1Handle _Handle, TElXMLObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_Included(TElOfficeXMLSignatureInfoV1Handle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_Included(TElOfficeXMLSignatureInfoV1Handle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_ApplicationVersion(TElOfficeXMLSignatureInfoV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_ApplicationVersion(TElOfficeXMLSignatureInfoV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_ColorDepth(TElOfficeXMLSignatureInfoV1Handle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_ColorDepth(TElOfficeXMLSignatureInfoV1Handle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_DelegateSuggestedSigner(TElOfficeXMLSignatureInfoV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_DelegateSuggestedSigner(TElOfficeXMLSignatureInfoV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_DelegateSuggestedSigner2(TElOfficeXMLSignatureInfoV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_DelegateSuggestedSigner2(TElOfficeXMLSignatureInfoV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_DelegateSuggestedSignerEmail(TElOfficeXMLSignatureInfoV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_DelegateSuggestedSignerEmail(TElOfficeXMLSignatureInfoV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_HorizontalResolution(TElOfficeXMLSignatureInfoV1Handle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_HorizontalResolution(TElOfficeXMLSignatureInfoV1Handle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_ManifestHashAlgorithm(TElOfficeXMLSignatureInfoV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_ManifestHashAlgorithm(TElOfficeXMLSignatureInfoV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_Monitors(TElOfficeXMLSignatureInfoV1Handle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_Monitors(TElOfficeXMLSignatureInfoV1Handle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_OfficeVersion(TElOfficeXMLSignatureInfoV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_OfficeVersion(TElOfficeXMLSignatureInfoV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_SetupID(TElOfficeXMLSignatureInfoV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_SetupID(TElOfficeXMLSignatureInfoV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_SignatureComments(TElOfficeXMLSignatureInfoV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_SignatureComments(TElOfficeXMLSignatureInfoV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_SignatureImage(TElOfficeXMLSignatureInfoV1Handle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_SignatureImage(TElOfficeXMLSignatureInfoV1Handle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_SignatureProviderDetails(TElOfficeXMLSignatureInfoV1Handle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_SignatureProviderDetails(TElOfficeXMLSignatureInfoV1Handle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_SignatureProviderId(TElOfficeXMLSignatureInfoV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_SignatureProviderId(TElOfficeXMLSignatureInfoV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_SignatureProviderUrl(TElOfficeXMLSignatureInfoV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_SignatureProviderUrl(TElOfficeXMLSignatureInfoV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_SignatureText(TElOfficeXMLSignatureInfoV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_SignatureText(TElOfficeXMLSignatureInfoV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_SignatureType(TElOfficeXMLSignatureInfoV1Handle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_SignatureType(TElOfficeXMLSignatureInfoV1Handle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_VerticalResolution(TElOfficeXMLSignatureInfoV1Handle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_VerticalResolution(TElOfficeXMLSignatureInfoV1Handle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_WindowsVersion(TElOfficeXMLSignatureInfoV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_WindowsVersion(TElOfficeXMLSignatureInfoV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_ValidSignatureLnImage(TElOfficeXMLSignatureInfoV1Handle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_ValidSignatureLnImage(TElOfficeXMLSignatureInfoV1Handle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_get_InvalidSignatureLnImage(TElOfficeXMLSignatureInfoV1Handle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_set_InvalidSignatureLnImage(TElOfficeXMLSignatureInfoV1Handle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureInfoV1_Create(TElOfficeXMLSignatureInfoV1Handle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLSIGNATUREINFOV1 */

#ifdef SB_USE_CLASS_TELOFFICEXMLSPOTLOCATION
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSpotLocation_Clear(TElOfficeXMLSpotLocationHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSpotLocation_LoadFromXML(TElOfficeXMLSpotLocationHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSpotLocation_SaveToXML(TElOfficeXMLSpotLocationHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSpotLocation_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSpotLocation_get_PageURI(TElOfficeXMLSpotLocationHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSpotLocation_set_PageURI(TElOfficeXMLSpotLocationHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSpotLocation_get_StartX(TElOfficeXMLSpotLocationHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSpotLocation_set_StartX(TElOfficeXMLSpotLocationHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSpotLocation_get_StartY(TElOfficeXMLSpotLocationHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSpotLocation_set_StartY(TElOfficeXMLSpotLocationHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSpotLocation_Create(TElOfficeXMLSpotLocationHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLSPOTLOCATION */

#ifdef SB_USE_CLASS_TELOFFICEXMLSIGNATUREDEFINITION
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_Clear(TElOfficeXMLSignatureDefinitionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_LoadFromXML(TElOfficeXMLSignatureDefinitionHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_SaveToXML(TElOfficeXMLSignatureDefinitionHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_get_Intent(TElOfficeXMLSignatureDefinitionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_set_Intent(TElOfficeXMLSignatureDefinitionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_get_SignBy(TElOfficeXMLSignatureDefinitionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_set_SignBy(TElOfficeXMLSignatureDefinitionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_get_SignByUTC(TElOfficeXMLSignatureDefinitionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_set_SignByUTC(TElOfficeXMLSignatureDefinitionHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_get_SigningLocation(TElOfficeXMLSignatureDefinitionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_set_SigningLocation(TElOfficeXMLSignatureDefinitionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_get_SignerName(TElOfficeXMLSignatureDefinitionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_set_SignerName(TElOfficeXMLSignatureDefinitionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_get_SpotID(TElOfficeXMLSignatureDefinitionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_set_SpotID(TElOfficeXMLSignatureDefinitionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_get_SpotLocation(TElOfficeXMLSignatureDefinitionHandle _Handle, TElOfficeXMLSpotLocationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLSignatureDefinition_Create(TElOfficeXMLSignatureDefinitionHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLSIGNATUREDEFINITION */

#ifdef SB_USE_CLASS_TELOFFICEXMLFIXEDDOCUMENTSEQUENCE
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocumentSequence_Add(TElOfficeXMLFixedDocumentSequenceHandle _Handle, const char * pcDocRef, int32_t szDocRef, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocumentSequence_Delete(TElOfficeXMLFixedDocumentSequenceHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocumentSequence_Clear(TElOfficeXMLFixedDocumentSequenceHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocumentSequence_LoadFromXML(TElOfficeXMLFixedDocumentSequenceHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocumentSequence_SaveToXML(TElOfficeXMLFixedDocumentSequenceHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocumentSequence_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocumentSequence_get_Count(TElOfficeXMLFixedDocumentSequenceHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocumentSequence_get_DocumentReferences(TElOfficeXMLFixedDocumentSequenceHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocumentSequence_Create(TElOfficeXMLFixedDocumentSequenceHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLFIXEDDOCUMENTSEQUENCE */

#ifdef SB_USE_CLASS_TELOFFICEXMLPAGECONTENT
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_AddLinkTarget(TElOfficeXMLPageContentHandle _Handle, const char * pcName, int32_t szName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_DeleteLinkTarget(TElOfficeXMLPageContentHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_Clear(TElOfficeXMLPageContentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_LoadFromXML(TElOfficeXMLPageContentHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_SaveToXML(TElOfficeXMLPageContentHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_get_Source(TElOfficeXMLPageContentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_set_Source(TElOfficeXMLPageContentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_get_Width(TElOfficeXMLPageContentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_set_Width(TElOfficeXMLPageContentHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_get_Height(TElOfficeXMLPageContentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_set_Height(TElOfficeXMLPageContentHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_get_LinkTargetCount(TElOfficeXMLPageContentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_get_LinkTargets(TElOfficeXMLPageContentHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLPageContent_Create(TElOfficeXMLPageContentHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLPAGECONTENT */

#ifdef SB_USE_CLASS_TELOFFICEXMLFIXEDDOCUMENT
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocument_Add(TElOfficeXMLFixedDocumentHandle _Handle, TElOfficeXMLPageContentHandle PageContent, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocument_Delete(TElOfficeXMLFixedDocumentHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocument_Clear(TElOfficeXMLFixedDocumentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocument_LoadFromXML(TElOfficeXMLFixedDocumentHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocument_SaveToXML(TElOfficeXMLFixedDocumentHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocument_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocument_get_Count(TElOfficeXMLFixedDocumentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocument_get_PageContents(TElOfficeXMLFixedDocumentHandle _Handle, int32_t Index, TElOfficeXMLPageContentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOfficeXMLFixedDocument_Create(TElOfficeXMLFixedDocumentHandle * OutResult);
#endif /* SB_USE_CLASS_TELOFFICEXMLFIXEDDOCUMENT */

#ifdef SB_USE_CLASS_TELOPENOFFICEXMLMANIFESTALGORITHM
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestAlgorithm_Clear(TElOpenOfficeXMLManifestAlgorithmHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestAlgorithm_LoadFromXML(TElOpenOfficeXMLManifestAlgorithmHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestAlgorithm_SaveToXML(TElOpenOfficeXMLManifestAlgorithmHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestAlgorithm_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestAlgorithm_get_AlgorithmName(TElOpenOfficeXMLManifestAlgorithmHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestAlgorithm_set_AlgorithmName(TElOpenOfficeXMLManifestAlgorithmHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestAlgorithm_get_IV(TElOpenOfficeXMLManifestAlgorithmHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestAlgorithm_set_IV(TElOpenOfficeXMLManifestAlgorithmHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestAlgorithm_Create(TElOpenOfficeXMLManifestAlgorithmHandle * OutResult);
#endif /* SB_USE_CLASS_TELOPENOFFICEXMLMANIFESTALGORITHM */

#ifdef SB_USE_CLASS_TELOPENOFFICEXMLMANIFESTKEYDERIVATION
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestKeyDerivation_Clear(TElOpenOfficeXMLManifestKeyDerivationHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestKeyDerivation_LoadFromXML(TElOpenOfficeXMLManifestKeyDerivationHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestKeyDerivation_SaveToXML(TElOpenOfficeXMLManifestKeyDerivationHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestKeyDerivation_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestKeyDerivation_get_IterationCount(TElOpenOfficeXMLManifestKeyDerivationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestKeyDerivation_set_IterationCount(TElOpenOfficeXMLManifestKeyDerivationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestKeyDerivation_get_KeyDerivationName(TElOpenOfficeXMLManifestKeyDerivationHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestKeyDerivation_set_KeyDerivationName(TElOpenOfficeXMLManifestKeyDerivationHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestKeyDerivation_get_KeySize(TElOpenOfficeXMLManifestKeyDerivationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestKeyDerivation_set_KeySize(TElOpenOfficeXMLManifestKeyDerivationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestKeyDerivation_get_Salt(TElOpenOfficeXMLManifestKeyDerivationHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestKeyDerivation_set_Salt(TElOpenOfficeXMLManifestKeyDerivationHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestKeyDerivation_Create(TElOpenOfficeXMLManifestKeyDerivationHandle * OutResult);
#endif /* SB_USE_CLASS_TELOPENOFFICEXMLMANIFESTKEYDERIVATION */

#ifdef SB_USE_CLASS_TELOPENOFFICEXMLMANIFESTSTARTKEYGENERATION
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestStartKeyGeneration_Clear(TElOpenOfficeXMLManifestStartKeyGenerationHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestStartKeyGeneration_LoadFromXML(TElOpenOfficeXMLManifestStartKeyGenerationHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestStartKeyGeneration_SaveToXML(TElOpenOfficeXMLManifestStartKeyGenerationHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestStartKeyGeneration_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestStartKeyGeneration_get_KeySize(TElOpenOfficeXMLManifestStartKeyGenerationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestStartKeyGeneration_set_KeySize(TElOpenOfficeXMLManifestStartKeyGenerationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestStartKeyGeneration_get_StartKeyGenerationName(TElOpenOfficeXMLManifestStartKeyGenerationHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestStartKeyGeneration_set_StartKeyGenerationName(TElOpenOfficeXMLManifestStartKeyGenerationHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestStartKeyGeneration_Create(TElOpenOfficeXMLManifestStartKeyGenerationHandle * OutResult);
#endif /* SB_USE_CLASS_TELOPENOFFICEXMLMANIFESTSTARTKEYGENERATION */

#ifdef SB_USE_CLASS_TELOPENOFFICEXMLMANIFESTENCRYPTIONDATA
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestEncryptionData_Clear(TElOpenOfficeXMLManifestEncryptionDataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestEncryptionData_LoadFromXML(TElOpenOfficeXMLManifestEncryptionDataHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestEncryptionData_SaveToXML(TElOpenOfficeXMLManifestEncryptionDataHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestEncryptionData_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestEncryptionData_get_Checksum(TElOpenOfficeXMLManifestEncryptionDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestEncryptionData_set_Checksum(TElOpenOfficeXMLManifestEncryptionDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestEncryptionData_get_ChecksumType(TElOpenOfficeXMLManifestEncryptionDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestEncryptionData_set_ChecksumType(TElOpenOfficeXMLManifestEncryptionDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestEncryptionData_get_Algorithm(TElOpenOfficeXMLManifestEncryptionDataHandle _Handle, TElOpenOfficeXMLManifestAlgorithmHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestEncryptionData_get_KeyDerivation(TElOpenOfficeXMLManifestEncryptionDataHandle _Handle, TElOpenOfficeXMLManifestKeyDerivationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestEncryptionData_get_StartKeyGeneration(TElOpenOfficeXMLManifestEncryptionDataHandle _Handle, TElOpenOfficeXMLManifestStartKeyGenerationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestEncryptionData_Create(TElOpenOfficeXMLManifestEncryptionDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELOPENOFFICEXMLMANIFESTENCRYPTIONDATA */

#ifdef SB_USE_CLASS_TELOPENOFFICEXMLMANIFESTFILEENTRY
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_Clear(TElOpenOfficeXMLManifestFileEntryHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_LoadFromXML(TElOpenOfficeXMLManifestFileEntryHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_SaveToXML(TElOpenOfficeXMLManifestFileEntryHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_get_IsEncrypted(TElOpenOfficeXMLManifestFileEntryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_get_EncryptionData(TElOpenOfficeXMLManifestFileEntryHandle _Handle, TElOpenOfficeXMLManifestEncryptionDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_get_FullPath(TElOpenOfficeXMLManifestFileEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_set_FullPath(TElOpenOfficeXMLManifestFileEntryHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_get_MediaType(TElOpenOfficeXMLManifestFileEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_set_MediaType(TElOpenOfficeXMLManifestFileEntryHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_get_PreferredViewMode(TElOpenOfficeXMLManifestFileEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_set_PreferredViewMode(TElOpenOfficeXMLManifestFileEntryHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_get_Size(TElOpenOfficeXMLManifestFileEntryHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_set_Size(TElOpenOfficeXMLManifestFileEntryHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_get_Version(TElOpenOfficeXMLManifestFileEntryHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_set_Version(TElOpenOfficeXMLManifestFileEntryHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifestFileEntry_Create(TElOpenOfficeXMLManifestFileEntryHandle * OutResult);
#endif /* SB_USE_CLASS_TELOPENOFFICEXMLMANIFESTFILEENTRY */

#ifdef SB_USE_CLASS_TELOPENOFFICEXMLMANIFEST
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifest_Add(TElOpenOfficeXMLManifestHandle _Handle, TElOpenOfficeXMLManifestFileEntryHandle AFileEntry, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifest_Add_1(TElOpenOfficeXMLManifestHandle _Handle, const char * pcFullPath, int32_t szFullPath, const char * pcMediaType, int32_t szMediaType, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifest_Insert(TElOpenOfficeXMLManifestHandle _Handle, int32_t Index, TElOpenOfficeXMLManifestFileEntryHandle AFileEntry);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifest_Delete(TElOpenOfficeXMLManifestHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifest_Clear(TElOpenOfficeXMLManifestHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifest_GetFileEntryByFullPath(TElOpenOfficeXMLManifestHandle _Handle, const char * pcFullPath, int32_t szFullPath, TElOpenOfficeXMLManifestFileEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifest_LoadFromXML(TElOpenOfficeXMLManifestHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifest_SaveToXML(TElOpenOfficeXMLManifestHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifest_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifest_get_Count(TElOpenOfficeXMLManifestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifest_get_FileEntries(TElOpenOfficeXMLManifestHandle _Handle, int32_t Index, TElOpenOfficeXMLManifestFileEntryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOpenOfficeXMLManifest_Create(TElOpenOfficeXMLManifestHandle * OutResult);
#endif /* SB_USE_CLASS_TELOPENOFFICEXMLMANIFEST */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElOfficeOpenXMLElement_ce_ptr;
extern zend_class_entry *TElOfficeOpenXMLRelationship_ce_ptr;
extern zend_class_entry *TElOfficeOpenXMLRelationships_ce_ptr;
extern zend_class_entry *TElOfficeOpenXMLDefault_ce_ptr;
extern zend_class_entry *TElOfficeOpenXMLDefaultList_ce_ptr;
extern zend_class_entry *TElOfficeOpenXMLOverride_ce_ptr;
extern zend_class_entry *TElOfficeOpenXMLOverrideList_ce_ptr;
extern zend_class_entry *TElOfficeOpenXMLContentTypes_ce_ptr;
extern zend_class_entry *TElOfficeXMLDCSimpleLiteral_ce_ptr;
extern zend_class_entry *TElOfficeXMLDCDate_ce_ptr;
extern zend_class_entry *TElOfficeOpenXMLCoreProperties_ce_ptr;
extern zend_class_entry *TElOfficeXMLKeyData_ce_ptr;
extern zend_class_entry *TElOfficeXMLDataIntegrity_ce_ptr;
extern zend_class_entry *TElOfficeXMLKeyEncryptor_ce_ptr;
extern zend_class_entry *TElOfficeXMLKeyEncryptors_ce_ptr;
extern zend_class_entry *TElOfficeXMLPasswordKeyEncryptor_ce_ptr;
extern zend_class_entry *TElOfficeXMLEncryption_ce_ptr;
extern zend_class_entry *TElOfficeXMLSignatureTime_ce_ptr;
extern zend_class_entry *TElOfficeOpenXMLRelationshipTransform_ce_ptr;
extern zend_class_entry *TElOfficeXMLSignatureInfoV1_ce_ptr;
extern zend_class_entry *TElOfficeXMLSpotLocation_ce_ptr;
extern zend_class_entry *TElOfficeXMLSignatureDefinition_ce_ptr;
extern zend_class_entry *TElOfficeXMLFixedDocumentSequence_ce_ptr;
extern zend_class_entry *TElOfficeXMLPageContent_ce_ptr;
extern zend_class_entry *TElOfficeXMLFixedDocument_ce_ptr;
extern zend_class_entry *TElOpenOfficeXMLManifestAlgorithm_ce_ptr;
extern zend_class_entry *TElOpenOfficeXMLManifestKeyDerivation_ce_ptr;
extern zend_class_entry *TElOpenOfficeXMLManifestStartKeyGeneration_ce_ptr;
extern zend_class_entry *TElOpenOfficeXMLManifestEncryptionData_ce_ptr;
extern zend_class_entry *TElOpenOfficeXMLManifestFileEntry_ce_ptr;
extern zend_class_entry *TElOpenOfficeXMLManifest_ce_ptr;

void Register_TElOfficeOpenXMLElement(TSRMLS_D);
void Register_TElOfficeOpenXMLRelationship(TSRMLS_D);
void Register_TElOfficeOpenXMLRelationships(TSRMLS_D);
void Register_TElOfficeOpenXMLDefault(TSRMLS_D);
void Register_TElOfficeOpenXMLDefaultList(TSRMLS_D);
void Register_TElOfficeOpenXMLOverride(TSRMLS_D);
void Register_TElOfficeOpenXMLOverrideList(TSRMLS_D);
void Register_TElOfficeOpenXMLContentTypes(TSRMLS_D);
void Register_TElOfficeXMLDCSimpleLiteral(TSRMLS_D);
void Register_TElOfficeXMLDCDate(TSRMLS_D);
void Register_TElOfficeOpenXMLCoreProperties(TSRMLS_D);
void Register_TElOfficeXMLKeyData(TSRMLS_D);
void Register_TElOfficeXMLDataIntegrity(TSRMLS_D);
void Register_TElOfficeXMLKeyEncryptor(TSRMLS_D);
void Register_TElOfficeXMLKeyEncryptors(TSRMLS_D);
void Register_TElOfficeXMLPasswordKeyEncryptor(TSRMLS_D);
void Register_TElOfficeXMLEncryption(TSRMLS_D);
void Register_TElOfficeXMLSignatureTime(TSRMLS_D);
void Register_TElOfficeOpenXMLRelationshipTransform(TSRMLS_D);
void Register_TElOfficeXMLSignatureInfoV1(TSRMLS_D);
void Register_TElOfficeXMLSpotLocation(TSRMLS_D);
void Register_TElOfficeXMLSignatureDefinition(TSRMLS_D);
void Register_TElOfficeXMLFixedDocumentSequence(TSRMLS_D);
void Register_TElOfficeXMLPageContent(TSRMLS_D);
void Register_TElOfficeXMLFixedDocument(TSRMLS_D);
void Register_TElOpenOfficeXMLManifestAlgorithm(TSRMLS_D);
void Register_TElOpenOfficeXMLManifestKeyDerivation(TSRMLS_D);
void Register_TElOpenOfficeXMLManifestStartKeyGeneration(TSRMLS_D);
void Register_TElOpenOfficeXMLManifestEncryptionData(TSRMLS_D);
void Register_TElOpenOfficeXMLManifestFileEntry(TSRMLS_D);
void Register_TElOpenOfficeXMLManifest(TSRMLS_D);
SB_PHP_FUNCTION(SBOfficeXMLCore, IsValidPartIRI);
SB_PHP_FUNCTION(SBOfficeXMLCore, IsValidPartURI);
SB_PHP_FUNCTION(SBOfficeXMLCore, ConvertPartIRIToURI);
SB_PHP_FUNCTION(SBOfficeXMLCore, ConvertPartURIToIRI);
SB_PHP_FUNCTION(SBOfficeXMLCore, ComparePartIRI);
SB_PHP_FUNCTION(SBOfficeXMLCore, ComparePartURI);
SB_PHP_FUNCTION(SBOfficeXMLCore, NormalizePartIRI);
SB_PHP_FUNCTION(SBOfficeXMLCore, NormalizePartURI);
SB_PHP_FUNCTION(SBOfficeXMLCore, ResolveRelativePartIRI);
SB_PHP_FUNCTION(SBOfficeXMLCore, ResolveRelativePartURI);
SB_PHP_FUNCTION(SBOfficeXMLCore, GetRelativePartURI);
SB_PHP_FUNCTION(SBOfficeXMLCore, GetRelationshipURI);
SB_PHP_FUNCTION(SBOfficeXMLCore, GetPartURIExtension);
SB_PHP_FUNCTION(SBOfficeXMLCore, GetPartURIPath);
SB_PHP_FUNCTION(SBOfficeXMLCore, GetPartURIName);
SB_PHP_FUNCTION(SBOfficeXMLCore, GetPartURIQueryComponent);
SB_PHP_FUNCTION(SBOfficeXMLCore, RemovePartURIExtension);
SB_PHP_FUNCTION(SBOfficeXMLCore, RemovePartIRIQueryComponent);
SB_PHP_FUNCTION(SBOfficeXMLCore, RemovePartURIQueryComponent);
SB_PHP_FUNCTION(SBOfficeXMLCore, GetValueFromQueryComponent);
SB_PHP_FUNCTION(SBOfficeXMLCore, IsLogicalItemSuffixName);
SB_PHP_FUNCTION(SBOfficeXMLCore, ParseLogicalItemSuffixName);
SB_PHP_FUNCTION(SBOfficeXMLCore, FormatLogicalItemSuffixName);
SB_PHP_FUNCTION(SBOfficeXMLCore, DecodeXMLName);
SB_PHP_FUNCTION(SBOfficeXMLCore, EncodeXMLNameSimple);
SB_PHP_FUNCTION(SBOfficeXMLCore, GenerateUniqueIdForRelationship);
SB_PHP_FUNCTION(SBOfficeXMLCore, GetOpenXMLDocumentTypeFromContentType);
SB_PHP_FUNCTION(SBOfficeXMLCore, GetOpenDocumentTypeFromMimeType);
SB_PHP_FUNCTION(SBOfficeXMLCore, WideCompareStrOrdinal);
void Register_SBOfficeXMLCore_Constants(int module_number TSRMLS_DC);
void Register_SBOfficeXMLCore_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_OFFICEXMLCORE
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_IsValidPartIRI(const char * pcIRI, int32_t szIRI, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_IsValidPartURI(const char * pcURI, int32_t szURI, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_ConvertPartIRIToURI(const char * pcIRI, int32_t szIRI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_ConvertPartURIToIRI(const char * pcURI, int32_t szURI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_ComparePartIRI(const char * pcX, int32_t szX, const char * pcY, int32_t szY, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_ComparePartURI(const char * pcX, int32_t szX, const char * pcY, int32_t szY, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_NormalizePartIRI(const char * pcIRI, int32_t szIRI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_NormalizePartURI(const char * pcURI, int32_t szURI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_ResolveRelativePartIRI(const char * pcBaseIRI, int32_t szBaseIRI, const char * pcTargetIRI, int32_t szTargetIRI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_ResolveRelativePartURI(const char * pcBaseURI, int32_t szBaseURI, const char * pcTargetURI, int32_t szTargetURI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_GetRelativePartURI(const char * pcURI, int32_t szURI, const char * pcBaseURI, int32_t szBaseURI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_GetRelationshipURI(const char * pcPartURI, int32_t szPartURI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_GetPartURIExtension(const char * pcURI, int32_t szURI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_GetPartURIPath(const char * pcURI, int32_t szURI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_GetPartURIName(const char * pcURI, int32_t szURI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_GetPartURIQueryComponent(const char * pcURI, int32_t szURI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_RemovePartURIExtension(const char * pcURI, int32_t szURI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_RemovePartIRIQueryComponent(const char * pcIRI, int32_t szIRI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_RemovePartURIQueryComponent(const char * pcURI, int32_t szURI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_GetValueFromQueryComponent(const char * pcQuery, int32_t szQuery, const char * pcKey, int32_t szKey, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_IsLogicalItemSuffixName(const char * pcSuffixName, int32_t szSuffixName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_ParseLogicalItemSuffixName(const char * pcSuffixName, int32_t szSuffixName, int8_t * IsLast, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_FormatLogicalItemSuffixName(int32_t PieceNumber, int8_t IsLast, int8_t SkipSlash, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_DecodeXMLName(const char * pcStr, int32_t szStr, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_EncodeXMLNameSimple(const char * pcStr, int32_t szStr, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_GenerateUniqueIdForRelationship(TElOfficeOpenXMLRelationshipsHandle Relationships, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_GetOpenXMLDocumentTypeFromContentType(const char * pcContentType, int32_t szContentType, TSBOfficeOpenXMLDocumentTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_GetOpenDocumentTypeFromMimeType(const char * pcMimeType, int32_t szMimeType, TSBOpenOfficeDocumentTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBOfficeXMLCore_WideCompareStrOrdinal(const char * pcS1, int32_t szS1, const char * pcS2, int32_t szS2, int32_t * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_OFFICEXMLCORE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBOFFICEXMLCORE */

