#ifndef __INC_SBONEDRIVEDATASTORAGE
#define __INC_SBONEDRIVEDATASTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbencoding.h"
#include "sbstringlist.h"
#include "sbdatastorage.h"
#include "sbdatastorageutils.h"
#include "sbstrutils.h"
#include "sbjson.h"
#include "sboauth2.h"
#include "sbhttpsconstants.h"
#include "sbhttpscommon.h"
#include "sbhttpsclient.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElOneDriveDataStorageHandle;

typedef TElClassHandle TElOneDriveDataStorageObjectHandle;

typedef TElClassHandle TElOneDriveFolderHandle;

typedef TElClassHandle TElOneDriveDriveHandle;

typedef TElClassHandle TElOneDriveFileHandle;

typedef uint8_t TSBOneDriveDriveTypeRaw;

typedef enum
{
	odtUnknown = 0,
	odtPersonal = 1,
	odtBusiness = 2,
	odtDocumentLibrary = 3
} TSBOneDriveDriveType;

typedef uint8_t TSBOneDriveQuotaStateRaw;

typedef enum
{
	odqUnknown = 0,
	odqNormal = 1,
	odqNearing = 2,
	odqCritical = 3,
	odqExceeded = 4
} TSBOneDriveQuotaState;

typedef uint8_t TSBOneDriveDrivesUsageRaw;

typedef enum
{
	oduNone = 0,
	oduDefault = 1,
	oduAll = 2
} TSBOneDriveDrivesUsage;

#ifdef SB_USE_CLASS_TELONEDRIVEDATASTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_AcquireObject(TElOneDriveDataStorageHandle _Handle, const char * pcObjectIDorPath, int32_t szObjectIDorPath, TElOneDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_AcquireObject_1(TElOneDriveDataStorageHandle _Handle, const char * pcDriveID, int32_t szDriveID, const char * pcObjectIDorPath, int32_t szObjectIDorPath, TElOneDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_AcquireObject_2(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_CopyObject(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_StartAuthorization(TElOneDriveDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_CompleteAuthorization(TElOneDriveDataStorageHandle _Handle, const char * pcAuthorizationCode, int32_t szAuthorizationCode);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_CloseSession(TElOneDriveDataStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_RefreshDrives(TElOneDriveDataStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_AccessToken(TElOneDriveDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_AccessTokenExpiration(TElOneDriveDataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_DefaultDrive(TElOneDriveDataStorageHandle _Handle, TElOneDriveDriveHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_DriveCount(TElOneDriveDataStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_Drives(TElOneDriveDataStorageHandle _Handle, int32_t Index, TElOneDriveDriveHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_ChunkedUploadChunkSize(TElOneDriveDataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_set_ChunkedUploadChunkSize(TElOneDriveDataStorageHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_ChunkedUploadThreshold(TElOneDriveDataStorageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_set_ChunkedUploadThreshold(TElOneDriveDataStorageHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_ClientID(TElOneDriveDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_set_ClientID(TElOneDriveDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_ClientSecret(TElOneDriveDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_set_ClientSecret(TElOneDriveDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_HTTPClient(TElOneDriveDataStorageHandle _Handle, TElHTTPSClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_set_HTTPClient(TElOneDriveDataStorageHandle _Handle, TElHTTPSClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_Overwrite(TElOneDriveDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_set_Overwrite(TElOneDriveDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_PassthroughMode(TElOneDriveDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_set_PassthroughMode(TElOneDriveDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_ReadOnly(TElOneDriveDataStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_set_ReadOnly(TElOneDriveDataStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_RedirectURL(TElOneDriveDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_set_RedirectURL(TElOneDriveDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_RefreshToken(TElOneDriveDataStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_set_RefreshToken(TElOneDriveDataStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_UseCompanyDrives(TElOneDriveDataStorageHandle _Handle, TSBOneDriveDrivesUsageRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_set_UseCompanyDrives(TElOneDriveDataStorageHandle _Handle, TSBOneDriveDrivesUsageRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_UseGroupsDrives(TElOneDriveDataStorageHandle _Handle, TSBOneDriveDrivesUsageRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_set_UseGroupsDrives(TElOneDriveDataStorageHandle _Handle, TSBOneDriveDrivesUsageRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_get_UseUserDrives(TElOneDriveDataStorageHandle _Handle, TSBOneDriveDrivesUsageRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_set_UseUserDrives(TElOneDriveDataStorageHandle _Handle, TSBOneDriveDrivesUsageRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorage_Create(TComponentHandle AOwner, TElOneDriveDataStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEDATASTORAGE */

#ifdef SB_USE_CLASS_TELONEDRIVEDATASTORAGEOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_Assign(TElOneDriveDataStorageObjectHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_Clone(TElOneDriveDataStorageObjectHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_Copy(TElOneDriveDataStorageObjectHandle _Handle, const char * pcNewName, int32_t szNewName);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_Copy_1(TElOneDriveDataStorageObjectHandle _Handle, TElOneDriveFolderHandle Destination);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_Copy_2(TElOneDriveDataStorageObjectHandle _Handle, TElOneDriveFolderHandle Destination, const char * pcNewName, int32_t szNewName);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_Delete(TElOneDriveDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_Move(TElOneDriveDataStorageObjectHandle _Handle, TElOneDriveFolderHandle Destination);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_Refresh(TElOneDriveDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_Release(TElOneDriveDataStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_Rename(TElOneDriveDataStorageObjectHandle _Handle, const char * pcNewName, int32_t szNewName);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_Created(TElOneDriveDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_CreatedBy(TElOneDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_CreatedOnClient(TElOneDriveDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_set_CreatedOnClient(TElOneDriveDataStorageObjectHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_CTag(TElOneDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_Description(TElOneDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_set_Description(TElOneDriveDataStorageObjectHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_Drive(TElOneDriveDataStorageObjectHandle _Handle, TElOneDriveDriveHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_DriveID(TElOneDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_ETag(TElOneDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_ID(TElOneDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_LastModified(TElOneDriveDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_LastModifiedBy(TElOneDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_LastModifiedOnClient(TElOneDriveDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_set_LastModifiedOnClient(TElOneDriveDataStorageObjectHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_ParentID(TElOneDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_Size(TElOneDriveDataStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_get_WebURL(TElOneDriveDataStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObject_Create(TElOneDriveDataStorageHandle Storage, const char * pcDriveID, int32_t szDriveID, TElOneDriveDataStorageObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEDATASTORAGEOBJECT */

#ifdef SB_USE_CLASS_TELONEDRIVEFOLDER
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolder_AcquireObject(TElOneDriveFolderHandle _Handle, const char * pcName, int32_t szName, TElOneDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolder_Assign(TElOneDriveFolderHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolder_Clone(TElOneDriveFolderHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolder_CreateFolder(TElOneDriveFolderHandle _Handle, const char * pcName, int32_t szName, TElOneDriveFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolder_CreateFolder_1(TElOneDriveFolderHandle _Handle, const char * pcName, int32_t szName, const char * pcDescription, int32_t szDescription, TElOneDriveFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolder_CreateObject(TElOneDriveFolderHandle _Handle, const char * pcName, int32_t szName, TElOneDriveFileHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolder_CreateObject_1(TElOneDriveFolderHandle _Handle, const char * pcName, int32_t szName, TElCustomDataStorageSecurityHandlerHandle Handler, TElOneDriveFileHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolder_List(TElOneDriveFolderHandle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolder_ListFolders(TElOneDriveFolderHandle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolder_get_ChildCount(TElOneDriveFolderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolder_get_Root(TElOneDriveFolderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolder_get_Special(TElOneDriveFolderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolder_Create(TElOneDriveDataStorageHandle Storage, const char * pcDriveID, int32_t szDriveID, TElOneDriveFolderHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEFOLDER */

#ifdef SB_USE_CLASS_TELONEDRIVEDRIVE
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_AcquireObject(TElOneDriveDriveHandle _Handle, const char * pcObjectIDorPath, int32_t szObjectIDorPath, TElOneDriveDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_Refresh(TElOneDriveDriveHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_AppRoot(TElOneDriveDriveHandle _Handle, TElOneDriveFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_CameraRoll(TElOneDriveDriveHandle _Handle, TElOneDriveFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_Created(TElOneDriveDriveHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_CreatedBy(TElOneDriveDriveHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_Description(TElOneDriveDriveHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_Documents(TElOneDriveDriveHandle _Handle, TElOneDriveFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_DriveType(TElOneDriveDriveHandle _Handle, TSBOneDriveDriveTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_ID(TElOneDriveDriveHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_LastModified(TElOneDriveDriveHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_LastModifiedBy(TElOneDriveDriveHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_Name(TElOneDriveDriveHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_Music(TElOneDriveDriveHandle _Handle, TElOneDriveFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_Owner(TElOneDriveDriveHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_Photos(TElOneDriveDriveHandle _Handle, TElOneDriveFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_Root(TElOneDriveDriveHandle _Handle, TElOneDriveFolderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_QuotaDeleted(TElOneDriveDriveHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_QuotaRemaining(TElOneDriveDriveHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_QuotaState(TElOneDriveDriveHandle _Handle, TSBOneDriveQuotaStateRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_QuotaTotal(TElOneDriveDriveHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_QuotaUsed(TElOneDriveDriveHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_get_WebURL(TElOneDriveDriveHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDrive_Create(TElOneDriveDataStorageHandle AStorage, TElOneDriveDriveHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEDRIVE */

#ifdef SB_USE_CLASS_TELONEDRIVEFILE
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFile_Assign(TElOneDriveFileHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFile_CancelUpload(TElOneDriveFileHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFile_Clone(TElOneDriveFileHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFile_Read(TElOneDriveFileHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFile_Write(TElOneDriveFileHandle _Handle, TStreamHandle Data);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFile_Write_1(TElOneDriveFileHandle _Handle, TStreamHandle Data, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFile_Create(TElOneDriveDataStorageHandle Storage, const char * pcDriveID, int32_t szDriveID, TElOneDriveFileHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEFILE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElOneDriveDataStorage_ce_ptr;
extern zend_class_entry *TElOneDriveDataStorageObject_ce_ptr;
extern zend_class_entry *TElOneDriveFolder_ce_ptr;
extern zend_class_entry *TElOneDriveDrive_ce_ptr;
extern zend_class_entry *TElOneDriveFile_ce_ptr;

void Register_TElOneDriveDataStorage(TSRMLS_D);
void Register_TElOneDriveDataStorageObject(TSRMLS_D);
void Register_TElOneDriveFolder(TSRMLS_D);
void Register_TElOneDriveDrive(TSRMLS_D);
void Register_TElOneDriveFile(TSRMLS_D);
void Register_SBOneDriveDataStorage_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBONEDRIVEDATASTORAGE */

