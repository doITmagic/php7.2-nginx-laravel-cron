#ifndef __INC_SBONEDRIVEDATASTORAGEV1
#define __INC_SBONEDRIVEDATASTORAGEV1

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbencoding.h"
#include "sbstringlist.h"
#include "sbdatastorage.h"
#include "sbdatastorageutils.h"
#include "sbstrutils.h"
#include "sbjson.h"
#include "sboauth2.h"
#include "sbhttpsconstants.h"
#include "sbhttpscommon.h"
#include "sbhttpsclient.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElOneDriveDataStorageV1Handle;

typedef TElClassHandle TElOneDriveDataStorageObjectV1Handle;

typedef TElClassHandle TElOneDriveFolderV1Handle;

typedef TElClassHandle TElOneDriveCommentsHandle;

typedef TElClassHandle TElOneDriveTagsHandle;

typedef TElClassHandle TElOneDriveTaggedObjectHandle;

typedef TElClassHandle TElOneDriveFriendHandle;

typedef TElClassHandle TElOneDriveCommentHandle;

typedef TElClassHandle TElOneDriveFileV1Handle;

typedef TElClassHandle TElOneDriveTagHandle;

typedef TElClassHandle TElOneDriveNotebookHandle;

typedef TElClassHandle TElOneDriveAudioHandle;

typedef TElClassHandle TElOneDrivePhotoHandle;

typedef TElClassHandle TElOneDrivePhotoImageHandle;

typedef TElClassHandle TElOneDrivePhotoImagesHandle;

typedef TElClassHandle TElOneDriveVideoHandle;

typedef TElClassHandle TElOneDriveAlbumHandle;

typedef TElClassHandle TElOneDriveUserInfoHandle;

#ifdef SB_USE_CLASS_TELONEDRIVEDATASTORAGEV1
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_StartAuthorization(TElOneDriveDataStorageV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_CompleteAuthorization(TElOneDriveDataStorageV1Handle _Handle, const char * pcAuthorizationCode, int32_t szAuthorizationCode);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_CloseSession(TElOneDriveDataStorageV1Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_AcquireObject(TElOneDriveDataStorageV1Handle _Handle, const char * pcObjectID, int32_t szObjectID, TElOneDriveDataStorageObjectV1Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_AcquireObject_1(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_CopyObject(TElOneDriveDataStorageV1Handle _Handle, TElOneDriveDataStorageObjectV1Handle Obj, TElOneDriveFolderV1Handle Destination, TElOneDriveDataStorageObjectV1Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_CopyObject_1(TElCustomDataStorageHandle _Handle, TElCustomDataStorageObjectHandle Obj, TElCustomDataStorageSecurityHandlerHandle NewHandler, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_CreateFolder(TElOneDriveDataStorageV1Handle _Handle, TElOneDriveFolderV1Handle Parent, const char * pcName, int32_t szName, const char * pcDescription, int32_t szDescription, TElOneDriveFolderV1Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_CreateObject(TElOneDriveDataStorageV1Handle _Handle, TElOneDriveFolderV1Handle Parent, const char * pcName, int32_t szName, int8_t OverwriteIfExists, TElOneDriveFileV1Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_CreateObject_1(TElOneDriveDataStorageV1Handle _Handle, TElOneDriveFolderV1Handle Parent, const char * pcName, int32_t szName, int8_t OverwriteIfExists, TElCustomDataStorageSecurityHandlerHandle Handler, TElOneDriveFileV1Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_GetQuota(TElOneDriveDataStorageV1Handle _Handle, int64_t * Total, int64_t * Free);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_GetUserInfo(TElOneDriveDataStorageV1Handle _Handle, TElOneDriveUserInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_GetUserInfo_1(TElOneDriveDataStorageV1Handle _Handle, const char * pcUserID, int32_t szUserID, TElOneDriveUserInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_List(TElOneDriveDataStorageV1Handle _Handle, TElOneDriveFolderV1Handle Dir, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_List_1(TElCustomDataStorageHandle _Handle, TElDataStorageObjectListHandle Objs);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_ListFriendly(TElOneDriveDataStorageV1Handle _Handle, const char * pcFriendlyName, int32_t szFriendlyName, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_ListRecent(TElOneDriveDataStorageV1Handle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_ListShared(TElOneDriveDataStorageV1Handle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_MoveObject(TElOneDriveDataStorageV1Handle _Handle, TElOneDriveDataStorageObjectV1Handle Obj, TElOneDriveFolderV1Handle Destination);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_RefreshObject(TElOneDriveDataStorageV1Handle _Handle, TElOneDriveDataStorageObjectV1Handle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_RenameObject(TElOneDriveDataStorageV1Handle _Handle, TElOneDriveDataStorageObjectV1Handle Obj, const char * pcNewName, int32_t szNewName);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_Search(TElOneDriveDataStorageV1Handle _Handle, const char * pcQuery, int32_t szQuery, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_get_AccessToken(TElOneDriveDataStorageV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_get_AccessTokenExpiration(TElOneDriveDataStorageV1Handle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_get_ClientID(TElOneDriveDataStorageV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_set_ClientID(TElOneDriveDataStorageV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_get_ClientSecret(TElOneDriveDataStorageV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_set_ClientSecret(TElOneDriveDataStorageV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_get_HTTPClient(TElOneDriveDataStorageV1Handle _Handle, TElHTTPSClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_set_HTTPClient(TElOneDriveDataStorageV1Handle _Handle, TElHTTPSClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_get_ListLimit(TElOneDriveDataStorageV1Handle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_set_ListLimit(TElOneDriveDataStorageV1Handle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_get_Locale(TElOneDriveDataStorageV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_set_Locale(TElOneDriveDataStorageV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_get_Overwrite(TElOneDriveDataStorageV1Handle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_set_Overwrite(TElOneDriveDataStorageV1Handle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_get_PassthroughMode(TElOneDriveDataStorageV1Handle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_set_PassthroughMode(TElOneDriveDataStorageV1Handle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_get_ReadOnly(TElOneDriveDataStorageV1Handle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_set_ReadOnly(TElOneDriveDataStorageV1Handle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_get_RedirectURL(TElOneDriveDataStorageV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_set_RedirectURL(TElOneDriveDataStorageV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_get_RefreshToken(TElOneDriveDataStorageV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_set_RefreshToken(TElOneDriveDataStorageV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_get_ChunkedUploadChunkSize(TElOneDriveDataStorageV1Handle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_set_ChunkedUploadChunkSize(TElOneDriveDataStorageV1Handle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_get_ChunkedUploadThreshold(TElOneDriveDataStorageV1Handle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_set_ChunkedUploadThreshold(TElOneDriveDataStorageV1Handle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageV1_Create(TComponentHandle AOwner, TElOneDriveDataStorageV1Handle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEDATASTORAGEV1 */

#ifdef SB_USE_CLASS_TELONEDRIVEDATASTORAGEOBJECTV1
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_Assign(TElOneDriveDataStorageObjectV1Handle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_Clear(TElOneDriveDataStorageObjectV1Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_Clone(TElOneDriveDataStorageObjectV1Handle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_Copy(TElOneDriveDataStorageObjectV1Handle _Handle, TElOneDriveFolderV1Handle Destination, TElOneDriveDataStorageObjectV1Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_Delete(TElOneDriveDataStorageObjectV1Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_Move(TElOneDriveDataStorageObjectV1Handle _Handle, TElOneDriveFolderV1Handle Destination);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_Refresh(TElOneDriveDataStorageObjectV1Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_Release(TElOneDriveDataStorageObjectV1Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_Rename(TElOneDriveDataStorageObjectV1Handle _Handle, const char * pcNewName, int32_t szNewName);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_ClientUpdatedTime(TElOneDriveDataStorageObjectV1Handle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_Comments(TElOneDriveDataStorageObjectV1Handle _Handle, TElOneDriveCommentsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_CreatedTime(TElOneDriveDataStorageObjectV1Handle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_Description(TElOneDriveDataStorageObjectV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_set_Description(TElOneDriveDataStorageObjectV1Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_From(TElOneDriveDataStorageObjectV1Handle _Handle, TElOneDriveFriendHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_ID(TElOneDriveDataStorageObjectV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_IsEmbeddable(TElOneDriveDataStorageObjectV1Handle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_Link(TElOneDriveDataStorageObjectV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_ObjectType(TElOneDriveDataStorageObjectV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_ParentID(TElOneDriveDataStorageObjectV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_SharedWith(TElOneDriveDataStorageObjectV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_Size(TElOneDriveDataStorageObjectV1Handle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_Storage(TElOneDriveDataStorageObjectV1Handle _Handle, TElOneDriveDataStorageV1Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_UpdatedTime(TElOneDriveDataStorageObjectV1Handle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_get_UploadLocation(TElOneDriveDataStorageObjectV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveDataStorageObjectV1_Create(TElOneDriveDataStorageV1Handle AStorage, TElOneDriveDataStorageObjectV1Handle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEDATASTORAGEOBJECTV1 */

#ifdef SB_USE_CLASS_TELONEDRIVEFOLDERV1
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolderV1_Assign(TElOneDriveFolderV1Handle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolderV1_Clear(TElOneDriveFolderV1Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolderV1_Clone(TElOneDriveFolderV1Handle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolderV1_CreateFolder(TElOneDriveFolderV1Handle _Handle, const char * pcName, int32_t szName, TElOneDriveFolderV1Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolderV1_CreateFolder_1(TElOneDriveFolderV1Handle _Handle, const char * pcName, int32_t szName, const char * pcDescription, int32_t szDescription, TElOneDriveFolderV1Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolderV1_CreateObject(TElOneDriveFolderV1Handle _Handle, const char * pcName, int32_t szName, int8_t OverwriteIfExists, TElOneDriveFileV1Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolderV1_CreateObject_1(TElOneDriveFolderV1Handle _Handle, const char * pcName, int32_t szName, int8_t OverwriteIfExists, TElCustomDataStorageSecurityHandlerHandle Handler, TElOneDriveFileV1Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolderV1_List(TElOneDriveFolderV1Handle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolderV1_ListFolders(TElOneDriveFolderV1Handle _Handle, TElDataStorageObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolderV1_get_Count(TElOneDriveFolderV1Handle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFolderV1_Create(TElOneDriveDataStorageV1Handle Storage, TElOneDriveFolderV1Handle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEFOLDERV1 */

#ifdef SB_USE_CLASS_TELONEDRIVECOMMENTS
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComments_Add(TElOneDriveCommentsHandle _Handle, const char * pcMessage, int32_t szMessage, TElOneDriveCommentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComments_Assign(TElOneDriveCommentsHandle _Handle, TElOneDriveCommentsHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComments_Clear(TElOneDriveCommentsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComments_Refresh(TElOneDriveCommentsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComments_get_Count(TElOneDriveCommentsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComments_get_Enabled(TElOneDriveCommentsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComments_get_Items(TElOneDriveCommentsHandle _Handle, int32_t Index, TElOneDriveCommentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComments_get_Owner(TElOneDriveCommentsHandle _Handle, TElOneDriveDataStorageObjectV1Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComments_Create(TElOneDriveDataStorageObjectV1Handle AOwner, TElOneDriveCommentsHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVECOMMENTS */

#ifdef SB_USE_CLASS_TELONEDRIVETAGS
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTags_Assign(TElOneDriveTagsHandle _Handle, TElOneDriveTagsHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTags_Clear(TElOneDriveTagsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTags_Refresh(TElOneDriveTagsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTags_get_Count(TElOneDriveTagsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTags_get_Enabled(TElOneDriveTagsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTags_get_Items(TElOneDriveTagsHandle _Handle, int32_t Index, TElOneDriveTagHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTags_get_Owner(TElOneDriveTagsHandle _Handle, TElOneDriveTaggedObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTags_Create(TElOneDriveTaggedObjectHandle AOwner, TElOneDriveTagsHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVETAGS */

#ifdef SB_USE_CLASS_TELONEDRIVEFILEV1
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFileV1_Assign(TElOneDriveFileV1Handle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFileV1_CancelUpload(TElOneDriveFileV1Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFileV1_Clear(TElOneDriveFileV1Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFileV1_Clone(TElOneDriveFileV1Handle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFileV1_Read(TElOneDriveFileV1Handle _Handle, TStreamHandle Target);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFileV1_Read_1(TElOneDriveFileV1Handle _Handle, int64_t Offset, int64_t Size, TStreamHandle Target, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFileV1_Write(TElOneDriveFileV1Handle _Handle, TStreamHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFileV1_Write_1(TElOneDriveFileV1Handle _Handle, TStreamHandle Source, TElCustomDataStorageSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFileV1_get_Source(TElOneDriveFileV1Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFileV1_Create(TElOneDriveDataStorageV1Handle AStorage, TElOneDriveFileV1Handle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEFILEV1 */

#ifdef SB_USE_CLASS_TELONEDRIVEFRIEND
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFriend_Assign(TElOneDriveFriendHandle _Handle, TElOneDriveFriendHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFriend_Clear(TElOneDriveFriendHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFriend_Clone(TElOneDriveFriendHandle _Handle, TElOneDriveFriendHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFriend_get_ID(TElOneDriveFriendHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFriend_get_Name(TElOneDriveFriendHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveFriend_Create(TElOneDriveFriendHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEFRIEND */

#ifdef SB_USE_CLASS_TELONEDRIVECOMMENT
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComment_Clone(TElOneDriveCommentHandle _Handle, TElOneDriveCommentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComment_Delete(TElOneDriveCommentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComment_get_CreatedTime(TElOneDriveCommentHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComment_get_From(TElOneDriveCommentHandle _Handle, TElOneDriveFriendHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComment_get_ID(TElOneDriveCommentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComment_get_Message(TElOneDriveCommentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveComment_Create(TElOneDriveCommentsHandle AOwner, TElOneDriveCommentHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVECOMMENT */

#ifdef SB_USE_CLASS_TELONEDRIVETAGGEDOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTaggedObject_Assign(TElOneDriveTaggedObjectHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTaggedObject_Clear(TElOneDriveTaggedObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTaggedObject_get_Tags(TElOneDriveTaggedObjectHandle _Handle, TElOneDriveTagsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTaggedObject_Create(TElOneDriveDataStorageV1Handle AStorage, TElOneDriveTaggedObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVETAGGEDOBJECT */

#ifdef SB_USE_CLASS_TELONEDRIVETAG
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTag_Clone(TElOneDriveTagHandle _Handle, TElOneDriveTagHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTag_get_CreatedTime(TElOneDriveTagHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTag_get_ID(TElOneDriveTagHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTag_get_User(TElOneDriveTagHandle _Handle, TElOneDriveFriendHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTag_get_X(TElOneDriveTagHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTag_get_Y(TElOneDriveTagHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveTag_Create(TElOneDriveTagsHandle AOwner, TElOneDriveTagHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVETAG */

#ifdef SB_USE_CLASS_TELONEDRIVENOTEBOOK
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveNotebook_Create(TElOneDriveDataStorageV1Handle AStorage, TElOneDriveFileV1Handle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVENOTEBOOK */

#ifdef SB_USE_CLASS_TELONEDRIVEAUDIO
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_Assign(TElOneDriveAudioHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_Clear(TElOneDriveAudioHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_Clone(TElOneDriveAudioHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_get_Album(TElOneDriveAudioHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_set_Album(TElOneDriveAudioHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_get_AlbumArtist(TElOneDriveAudioHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_set_AlbumArtist(TElOneDriveAudioHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_get_Artist(TElOneDriveAudioHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_set_Artist(TElOneDriveAudioHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_get_Duration(TElOneDriveAudioHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_get_Genre(TElOneDriveAudioHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_set_Genre(TElOneDriveAudioHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_get_Picture(TElOneDriveAudioHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_get_Title(TElOneDriveAudioHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_set_Title(TElOneDriveAudioHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAudio_Create(TElOneDriveDataStorageV1Handle AStorage, TElOneDriveAudioHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEAUDIO */

#ifdef SB_USE_CLASS_TELONEDRIVEPHOTO
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_Assign(TElOneDrivePhotoHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_Clear(TElOneDrivePhotoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_Clone(TElOneDrivePhotoHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_get_Altitude(TElOneDrivePhotoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_get_CameraMaker(TElOneDrivePhotoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_get_CameraModel(TElOneDrivePhotoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_get_ExposureDenominator(TElOneDrivePhotoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_get_ExposureNumerator(TElOneDrivePhotoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_get_FocalLength(TElOneDrivePhotoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_get_FocalRatio(TElOneDrivePhotoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_get_Height(TElOneDrivePhotoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_get_Images(TElOneDrivePhotoHandle _Handle, TElOneDrivePhotoImagesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_get_Latitude(TElOneDrivePhotoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_get_Longitude(TElOneDrivePhotoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_get_Picture(TElOneDrivePhotoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_get_WhenTaken(TElOneDrivePhotoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_get_Width(TElOneDrivePhotoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhoto_Create(TElOneDriveDataStorageV1Handle Storage, TElOneDrivePhotoHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEPHOTO */

#ifdef SB_USE_CLASS_TELONEDRIVEPHOTOIMAGE
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImage_Clear(TElOneDrivePhotoImageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImage_Clone(TElOneDrivePhotoImageHandle _Handle, TElOneDrivePhotoImageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImage_get_Height(TElOneDrivePhotoImageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImage_get_ImageType(TElOneDrivePhotoImageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImage_get_Source(TElOneDrivePhotoImageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImage_get_Width(TElOneDrivePhotoImageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImage_Create(TElOneDrivePhotoImageHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEPHOTOIMAGE */

#ifdef SB_USE_CLASS_TELONEDRIVEPHOTOIMAGES
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImages_Assign(TElOneDrivePhotoImagesHandle _Handle, TElOneDrivePhotoImagesHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImages_Clear(TElOneDrivePhotoImagesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImages_get_Album(TElOneDrivePhotoImagesHandle _Handle, TElOneDrivePhotoImageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImages_get_Count(TElOneDrivePhotoImagesHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImages_get_Full(TElOneDrivePhotoImagesHandle _Handle, TElOneDrivePhotoImageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImages_get_Items(TElOneDrivePhotoImagesHandle _Handle, int32_t Index, TElOneDrivePhotoImageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImages_get_Normal(TElOneDrivePhotoImagesHandle _Handle, TElOneDrivePhotoImageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImages_get_Small(TElOneDrivePhotoImagesHandle _Handle, TElOneDrivePhotoImageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDrivePhotoImages_Create(TElOneDrivePhotoImagesHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEPHOTOIMAGES */

#ifdef SB_USE_CLASS_TELONEDRIVEVIDEO
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveVideo_Assign(TElOneDriveVideoHandle _Handle, TElCustomDataStorageObjectHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveVideo_Clear(TElOneDriveVideoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveVideo_Clone(TElOneDriveVideoHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveVideo_get_Bitrate(TElOneDriveVideoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveVideo_get_Duration(TElOneDriveVideoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveVideo_get_Height(TElOneDriveVideoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveVideo_get_Picture(TElOneDriveVideoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveVideo_get_Width(TElOneDriveVideoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveVideo_Create(TElOneDriveDataStorageV1Handle Storage, TElOneDriveVideoHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEVIDEO */

#ifdef SB_USE_CLASS_TELONEDRIVEALBUM
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAlbum_Clone(TElOneDriveAlbumHandle _Handle, TElCustomDataStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveAlbum_Create(TElOneDriveDataStorageV1Handle Storage, TElOneDriveFolderV1Handle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEALBUM */

#ifdef SB_USE_CLASS_TELONEDRIVEUSERINFO
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_Assign(TElOneDriveUserInfoHandle _Handle, TElOneDriveUserInfoHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_Clear(TElOneDriveUserInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_Clone(TElOneDriveUserInfoHandle _Handle, TElOneDriveUserInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_Refresh(TElOneDriveUserInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_get_FirstName(TElOneDriveUserInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_set_FirstName(TElOneDriveUserInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_get_Gender(TElOneDriveUserInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_set_Gender(TElOneDriveUserInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_get_ID(TElOneDriveUserInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_set_ID(TElOneDriveUserInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_get_LastName(TElOneDriveUserInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_set_LastName(TElOneDriveUserInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_get_Link(TElOneDriveUserInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_set_Link(TElOneDriveUserInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_get_Locale(TElOneDriveUserInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_set_Locale(TElOneDriveUserInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_get_Name(TElOneDriveUserInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_set_Name(TElOneDriveUserInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_get_UpdatedTime(TElOneDriveUserInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_set_UpdatedTime(TElOneDriveUserInfoHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOneDriveUserInfo_Create(TElOneDriveDataStorageV1Handle AStorage, TElOneDriveUserInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELONEDRIVEUSERINFO */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElOneDriveDataStorageV1_ce_ptr;
extern zend_class_entry *TElOneDriveDataStorageObjectV1_ce_ptr;
extern zend_class_entry *TElOneDriveFolderV1_ce_ptr;
extern zend_class_entry *TElOneDriveComments_ce_ptr;
extern zend_class_entry *TElOneDriveTags_ce_ptr;
extern zend_class_entry *TElOneDriveFileV1_ce_ptr;
extern zend_class_entry *TElOneDriveFriend_ce_ptr;
extern zend_class_entry *TElOneDriveComment_ce_ptr;
extern zend_class_entry *TElOneDriveTaggedObject_ce_ptr;
extern zend_class_entry *TElOneDriveTag_ce_ptr;
extern zend_class_entry *TElOneDriveNotebook_ce_ptr;
extern zend_class_entry *TElOneDriveAudio_ce_ptr;
extern zend_class_entry *TElOneDrivePhoto_ce_ptr;
extern zend_class_entry *TElOneDrivePhotoImage_ce_ptr;
extern zend_class_entry *TElOneDrivePhotoImages_ce_ptr;
extern zend_class_entry *TElOneDriveVideo_ce_ptr;
extern zend_class_entry *TElOneDriveAlbum_ce_ptr;
extern zend_class_entry *TElOneDriveUserInfo_ce_ptr;

void Register_TElOneDriveDataStorageV1(TSRMLS_D);
void Register_TElOneDriveDataStorageObjectV1(TSRMLS_D);
void Register_TElOneDriveFolderV1(TSRMLS_D);
void Register_TElOneDriveComments(TSRMLS_D);
void Register_TElOneDriveTags(TSRMLS_D);
void Register_TElOneDriveFileV1(TSRMLS_D);
void Register_TElOneDriveFriend(TSRMLS_D);
void Register_TElOneDriveComment(TSRMLS_D);
void Register_TElOneDriveTaggedObject(TSRMLS_D);
void Register_TElOneDriveTag(TSRMLS_D);
void Register_TElOneDriveNotebook(TSRMLS_D);
void Register_TElOneDriveAudio(TSRMLS_D);
void Register_TElOneDrivePhoto(TSRMLS_D);
void Register_TElOneDrivePhotoImage(TSRMLS_D);
void Register_TElOneDrivePhotoImages(TSRMLS_D);
void Register_TElOneDriveVideo(TSRMLS_D);
void Register_TElOneDriveAlbum(TSRMLS_D);
void Register_TElOneDriveUserInfo(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBONEDRIVEDATASTORAGEV1 */

