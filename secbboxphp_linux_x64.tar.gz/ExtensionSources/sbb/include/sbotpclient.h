#ifndef __INC_SBOTPCLIENT
#define __INC_SBOTPCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbotpcommon.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElOTPClientHandle;

typedef TElOTPClientHandle ElOTPClientHandle;

typedef TElClassHandle TElHOTPClientHandle;

typedef TElHOTPClientHandle ElHOTPClientHandle;

typedef TElClassHandle TElTOTPClientHandle;

typedef TElTOTPClientHandle ElTOTPClientHandle;

#ifdef SB_USE_CLASS_TELOTPCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElOTPClient_get_KeySecret(TElOTPClientHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOTPClient_set_KeySecret(TElOTPClientHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElOTPClient_get_PasswordLen(TElOTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOTPClient_set_PasswordLen(TElOTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElOTPClient_Create(const uint8_t pKeySecret[], int32_t szKeySecret, int32_t PasswordLength, TElOTPClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELOTPCLIENT */

#ifdef SB_USE_CLASS_TELHOTPCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElHOTPClient_GetPassword(TElHOTPClientHandle _Handle, int32_t Counter, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHOTPClient_Create(const uint8_t pKeySecret[], int32_t szKeySecret, int32_t PasswordLength, TElHOTPClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELHOTPCLIENT */

#ifdef SB_USE_CLASS_TELTOTPCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElTOTPClient_GetPassword(TElTOTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTOTPClient_GetPassword_1(TElTOTPClientHandle _Handle, int64_t Time, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTOTPClient_get_TimeInterval(TElTOTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTOTPClient_set_TimeInterval(TElTOTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTOTPClient_get_HashAlgorithm(TElTOTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTOTPClient_set_HashAlgorithm(TElTOTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTOTPClient_Create(const uint8_t pKeySecret[], int32_t szKeySecret, int32_t PasswordLength, TElTOTPClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELTOTPCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElOTPClient_ce_ptr;
extern zend_class_entry *TElHOTPClient_ce_ptr;
extern zend_class_entry *TElTOTPClient_ce_ptr;

void Register_TElOTPClient(TSRMLS_D);
void Register_TElHOTPClient(TSRMLS_D);
void Register_TElTOTPClient(TSRMLS_D);
void Register_SBOTPClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBOTPCLIENT */

