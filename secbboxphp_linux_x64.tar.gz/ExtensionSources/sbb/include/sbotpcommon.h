#ifndef __INC_SBOTPCOMMON
#define __INC_SBOTPCOMMON

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbstrutils.h"
#include "sbutils.h"
#include "sbhashfunction.h"
#include "sbconstants.h"
#include "sbencoding.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_OTP_ERROR_NOT_SUPPORTED_ALGORITHM 	"Algorithm is not supported"
#define SB_OTP_ERROR_KEY_EMPTY 	"Key secret is not set"
#define SB_OTP_ERROR_NO_PASSWORD_LENGTH 	"Password length is not set"
#define SB_OTP_ERROR_DATA_TOO_LONG 	"Hashed data is too long"
#define SB_OTP_ERROR_DATA_EMPTY 	"Hashed data is empty"
#define SB_OTP_ERROR_COUNTER_INCORRECT 	"Counter value is incorrect"
#define SB_OTP_NO_USER_STORAGE 	"User storage is not set"
#define SB_OTP_EMPTY_USER_STORAGE 	"User storage is empty"
#define SB_OTP_NO_FIND_USER 	"User is not found in storage"
#define SB_OTP_NOT_IMPLEMENTED 	"Not implemented"
#define SB_OTP_INVALID_TYPE_CAST 	"Invalid type cast"
#define SB_ALGORITHM_OTP_BASE 	30464
#define SB_ALGORITHM_OTP_HMAC_BASED 	30465
#define SB_ALGORITHM_OTP_TIME_BASED 	30466

typedef TElClassHandle TElOTPClassHandle;

typedef TElOTPClassHandle ElOTPClassHandle;

typedef TElClassHandle TElHOTPPasswordGeneratorHandle;

typedef TElHOTPPasswordGeneratorHandle ElHOTPPasswordGeneratorHandle;

typedef TElClassHandle TElTOTPPasswordGeneratorHandle;

typedef TElTOTPPasswordGeneratorHandle ElTOTPPasswordGeneratorHandle;

#ifdef SB_USE_CLASS_TELOTPCLASS
SB_IMPORT uint32_t SB_APIENTRY TElOTPClass_Create(TComponentHandle Owner, TElOTPClassHandle * OutResult);
#endif /* SB_USE_CLASS_TELOTPCLASS */

#ifdef SB_USE_CLASS_TELHOTPPASSWORDGENERATOR
SB_IMPORT uint32_t SB_APIENTRY TElHOTPPasswordGenerator_GeneratePassword(TElHOTPPasswordGeneratorHandle _Handle, const uint8_t pHashedData[], int32_t szHashedData, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHOTPPasswordGenerator_GeneratePassword_1(TElHOTPPasswordGeneratorHandle _Handle, int32_t Counter, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHOTPPasswordGenerator_get_KeySecret(TElHOTPPasswordGeneratorHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHOTPPasswordGenerator_set_KeySecret(TElHOTPPasswordGeneratorHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElHOTPPasswordGenerator_get_PasswordLen(TElHOTPPasswordGeneratorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHOTPPasswordGenerator_set_PasswordLen(TElHOTPPasswordGeneratorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHOTPPasswordGenerator_Create(const uint8_t pKeySecret[], int32_t szKeySecret, int32_t PasswordLength, TElHOTPPasswordGeneratorHandle * OutResult);
#endif /* SB_USE_CLASS_TELHOTPPASSWORDGENERATOR */

#ifdef SB_USE_CLASS_TELTOTPPASSWORDGENERATOR
SB_IMPORT uint32_t SB_APIENTRY TElTOTPPasswordGenerator_GeneratePassword(TElTOTPPasswordGeneratorHandle _Handle, int64_t Time, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTOTPPasswordGenerator_GeneratePassword_1(TElHOTPPasswordGeneratorHandle _Handle, const uint8_t pHashedData[], int32_t szHashedData, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTOTPPasswordGenerator_GeneratePassword_2(TElHOTPPasswordGeneratorHandle _Handle, int32_t Counter, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTOTPPasswordGenerator_get_HashAlgorithm(TElTOTPPasswordGeneratorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTOTPPasswordGenerator_set_HashAlgorithm(TElTOTPPasswordGeneratorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTOTPPasswordGenerator_get_TimeInterval(TElTOTPPasswordGeneratorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTOTPPasswordGenerator_set_TimeInterval(TElTOTPPasswordGeneratorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTOTPPasswordGenerator_Create(const uint8_t pKeySecret[], int32_t szKeySecret, int32_t PasswordLength, TElTOTPPasswordGeneratorHandle * OutResult);
#endif /* SB_USE_CLASS_TELTOTPPASSWORDGENERATOR */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElOTPClass_ce_ptr;
extern zend_class_entry *TElHOTPPasswordGenerator_ce_ptr;
extern zend_class_entry *TElTOTPPasswordGenerator_ce_ptr;

void Register_TElOTPClass(TSRMLS_D);
void Register_TElHOTPPasswordGenerator(TSRMLS_D);
void Register_TElTOTPPasswordGenerator(TSRMLS_D);
void Register_SBOTPCommon_Constants(int module_number TSRMLS_DC);
void Register_SBOTPCommon_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBOTPCOMMON */

