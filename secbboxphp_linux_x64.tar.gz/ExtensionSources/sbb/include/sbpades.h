#ifndef __INC_SBPADES
#define __INC_SBPADES

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbdc.h"
#include "sbdcdef.h"
#include "sbdcsec.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbpkicommon.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbrdn.h"
#include "sbpdf.h"
#include "sbpdfcore.h"
#include "sbpdfsecurity.h"
#include "sbcmsutils.h"
#include "sbcms.h"
#include "sbpkcs7.h"
#include "sbpkcs7utils.h"
#include "sbhashfunction.h"
#include "sbtspcommon.h"
#include "sbtspclient.h"
#include "sbx509.h"
#include "sbx509ext.h"
#include "sbcustomcertstorage.h"
#include "sbcrlstorage.h"
#include "sbocspcommon.h"
#include "sbocspclient.h"
#include "sbcertvalidator.h"
#include "sbpublickeycrypto.h"
#include "sbcrl.h"
#include "sbstreams.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElPDFAdvancedPublicKeySecurityHandlerHandle;

typedef uint8_t TSBPAdESSignatureTypeRaw;

typedef enum
{
	pastBasic = 0,
	pastEnhanced = 1,
	pastDocumentTimestamp = 2
} TSBPAdESSignatureType;

typedef void (SB_CALLBACK *TSBPDFSignEvent)(void * _ObjectData, TObjectHandle Sender, TElSignedCMSMessageHandle CMS);

typedef void (SB_CALLBACK *TSBPDFCertValidatorPreparedEvent)(void * _ObjectData, TObjectHandle Sender, TElX509CertificateValidatorHandle * CertValidator, TElX509CertificateHandle Cert);

typedef void (SB_CALLBACK *TSBPDFCertValidatorFinishedEvent)(void * _ObjectData, TObjectHandle Sender, TElX509CertificateValidatorHandle CertValidator, TElX509CertificateHandle Cert, TSBCertificateValidityRaw Validity, TSBCertificateValidityReasonRaw Reason);

typedef void (SB_CALLBACK *TSBPDFRemoteSignEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pHash[], int32_t szHash, uint8_t pSignedHash[], int32_t * szSignedHash);

typedef uint8_t TSBPAdESOptionRaw;

typedef enum
{
	poUseSigningCertificateV2 = 0,
	poIncludeAllRevInfoToDSS = 1,
	poCreateVRIDictionaries = 2,
	poUseUndefBEREncoding = 3,
	poTolerateMissingSigningCertificate = 4,
	poCompressDSS = 5
} TSBPAdESOption;

typedef uint32_t TSBPAdESOptionsRaw;

typedef enum 
{
	f_poUseSigningCertificateV2 = 1,
	f_poIncludeAllRevInfoToDSS = 2,
	f_poCreateVRIDictionaries = 4,
	f_poUseUndefBEREncoding = 8,
	f_poTolerateMissingSigningCertificate = 16,
	f_poCompressDSS = 32
} TSBPAdESOptions;

typedef uint8_t TSBPAdESSignatureSizeEstimationStrategyRaw;

typedef enum
{
	psesBasic = 0,
	psesSmart = 1,
	psesSmartAndTrialTimestamp = 2,
	psesPredefinedSize = 3
} TSBPAdESSignatureSizeEstimationStrategy;

typedef uint8_t TSBPAdESExtensionIdentifierModeRaw;

typedef enum
{
	peimNoExtensionIdentifier = 0,
	peimESIC = 1,
	peimADBE = 2,
	peimADBEIfNotPresent = 3,
	peimBoth = 4
} TSBPAdESExtensionIdentifierMode;

#ifdef SB_USE_CLASS_TELPDFADVANCEDPUBLICKEYSECURITYHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_GetName(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_GetName_1(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_GetDescription(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_GetDescription_1(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_GetSignerCertificate(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_Reset(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_DSSRevocationInfo(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TElPDFPublicKeyRevocationInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_CustomRevocationInfo(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TElPDFPublicKeyRevocationInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_CMS(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TElSignedCMSMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_ValidationDetails(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBCMSAdvancedSignatureValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_ValidationMessage(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_DocumentTimestamp(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_PAdESSignatureType(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPAdESSignatureTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_PAdESSignatureType(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPAdESSignatureTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_DeepValidation(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_DeepValidation(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_AutoCollectRevocationInfo(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_AutoCollectRevocationInfo(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_IgnoreChainValidationErrors(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_IgnoreChainValidationErrors(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_ForceCompleteChainValidation(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_ForceCompleteChainValidation(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_IncludeRevocationInfoToAdbeAttribute(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_IncludeRevocationInfoToAdbeAttribute(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_ValidationMoment(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_ValidationMoment(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_PAdESOptions(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPAdESOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_PAdESOptions(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPAdESOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_SignatureSizeEstimationStrategy(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPAdESSignatureSizeEstimationStrategyRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_SignatureSizeEstimationStrategy(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPAdESSignatureSizeEstimationStrategyRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_PredefinedSignatureSize(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_PredefinedSignatureSize(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_RemoteSigningMode(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_RemoteSigningMode(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_RemoteSigningParams(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TElRemoteSigningParamsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_RemoteSigningCertIndex(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_RemoteSigningCertIndex(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_ExtensionIdentifierMode(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPAdESExtensionIdentifierModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_ExtensionIdentifierMode(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPAdESExtensionIdentifierModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_ReuseCollectedRevocationInfo(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_ReuseCollectedRevocationInfo(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_OfflineMode(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_OfflineMode(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_OnBeforeSign(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPDFSignEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_OnBeforeSign(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPDFSignEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_OnAfterSign(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPDFSignEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_OnAfterSign(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPDFSignEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_OnCertValidatorPrepared(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPDFCertValidatorPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_OnCertValidatorPrepared(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPDFCertValidatorPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_OnCertValidatorFinished(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPDFCertValidatorFinishedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_OnCertValidatorFinished(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPDFCertValidatorFinishedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_get_OnRemoteSign(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPDFRemoteSignEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_set_OnRemoteSign(TElPDFAdvancedPublicKeySecurityHandlerHandle _Handle, TSBPDFRemoteSignEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFAdvancedPublicKeySecurityHandler_Create(TComponentHandle Owner, TElPDFSecurityHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFADVANCEDPUBLICKEYSECURITYHANDLER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPDFAdvancedPublicKeySecurityHandler_ce_ptr;

void SB_CALLBACK TSBPDFSignEventRaw(void * _ObjectData, TObjectHandle Sender, TElSignedCMSMessageHandle CMS);
void SB_CALLBACK TSBPDFCertValidatorPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateValidatorHandle * CertValidator, TElX509CertificateHandle Cert);
void SB_CALLBACK TSBPDFCertValidatorFinishedEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateValidatorHandle CertValidator, TElX509CertificateHandle Cert, TSBCertificateValidityRaw Validity, TSBCertificateValidityReasonRaw Reason);
void SB_CALLBACK TSBPDFRemoteSignEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pHash[], int32_t szHash, uint8_t pSignedHash[], int32_t * szSignedHash);
void Register_TElPDFAdvancedPublicKeySecurityHandler(TSRMLS_D);
void Register_SBPAdES_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPADES */

