#ifndef __INC_SBPDF
#define __INC_SBPDF

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbpdfcore.h"
#include "sbpdfutils.h"
#include "sbcryptoprov.h"
#include "sbconstants.h"
#include "sbsharedresource.h"
#include "sbrdn.h"
#include "sbx509.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbcustomcertstorage.h"
#include "sbsymmetriccrypto.h"
#include "sbpkcs7.h"
#include "sbhashfunction.h"
#include "sbcrl.h"
#include "sbdc.h"
#include "sbdcsec.h"
#include "sbencoding.h"
#include "sbrandom.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SPDFNotImplemented 	"Not implemented"
#define SB_SPDFInvalidSecurityHandlerInformation 	"Invalid security handler information"
#define SB_SPDFInvalidPassword 	"Invalid password"
#define SB_SPDFNoDecryptionKeyFound 	"No decryption key found"
#define SB_SPDFCannotTimestampEncryptedDocument 	"Cannot timestamp encrypted document"
#define SB_SPDFCannotModifyDocumentAfterSignatureUpdate 	"Cannot modify document after signature update"
#define SB_SPDFCannotUpdateSignatureInEncryptedDocument 	"Cannot update signature in encrypted document"
#define SB_SPDFUnsupportedTimestampType 	"Unsupported timestamp type"
#define SB_SPDFBadAsyncState 	"Bad asynchronous operation state"
#define SB_SPDFSecurityHandlerNotFound 	"Security handler not found"
#define SB_SPDFDCModuleUnavailable 	"Distributed Cryptography module is not available"
#define SB_SPDFSignatureSizeEstimatedIncorrectly 	"Signature is too large to fit in the allocated window. Please consider extending the window by assigning the number of bytes to add to the TElPDFSignature.ExtraSpace property before closing the document."
#define SB_SPDFCannotChangeDecryptionModePropertyForOpenedDocument 	"Cannot change DecryptionMode property for opened document"
#define SB_SFPDFUnsupportedSecurityHandlerSubfilter 	"Unsupported security handler subfilter (%s)"
#define SB_SFPDFInternalError 	"Internal error %s"
#define SB_SFPDFIndexOutOfBounds 	"Index out of bounds (%d)"

typedef TElClassHandle TElPDFDocumentHandle;

typedef TElPDFDocumentHandle ElPDFDocumentHandle;

typedef TElClassHandle TElPDFSignatureHandle;

typedef TElPDFSignatureHandle ElPDFSignatureHandle;

typedef TElClassHandle TElPDFURPropertiesHandle;

typedef TElPDFURPropertiesHandle ElPDFURPropertiesHandle;

typedef TElClassHandle TElPDFSigRefEntryHandle;

typedef TElPDFSigRefEntryHandle ElPDFSigRefEntryHandle;

typedef TElClassHandle TElPDFSecurityHandlerHandle;

typedef TElPDFSecurityHandlerHandle ElPDFSecurityHandlerHandle;

typedef TElClassHandle TElPDFByteRangeHandle;

typedef TElPDFByteRangeHandle ElPDFByteRangeHandle;

typedef TElClassHandle TElPDFImageHandle;

typedef TElPDFImageHandle ElPDFImageHandle;

typedef TElClassHandle TElPDFCustomFontObjectHandle;

typedef TElPDFCustomFontObjectHandle ElPDFCustomFontObjectHandle;

typedef TElClassHandle TElPDFEncodingHandle;

typedef TElPDFEncodingHandle ElPDFEncodingHandle;

typedef TElClassHandle TElPDFFontDescriptorHandle;

typedef TElPDFFontDescriptorHandle ElPDFFontDescriptorHandle;

typedef TElClassHandle TElPDFCIDFontDescriptorHandle;

typedef TElPDFCIDFontDescriptorHandle ElPDFCIDFontDescriptorHandle;

typedef TElClassHandle TElPDFCIDSystemInfoHandle;

typedef TElPDFCIDSystemInfoHandle ElPDFCIDSystemInfoHandle;

typedef TElClassHandle TElPDFCustomFontHandle;

typedef TElPDFCustomFontHandle ElPDFCustomFontHandle;

typedef TElClassHandle TElPDFSimpleFontHandle;

typedef TElPDFSimpleFontHandle ElPDFSimpleFontHandle;

typedef TElClassHandle TElPDFCompositeFontHandle;

typedef TElPDFCompositeFontHandle ElPDFCompositeFontHandle;

typedef TElClassHandle TElPDFMetricWHandle;

typedef TElPDFMetricWHandle ElPDFMetricWHandle;

typedef TElClassHandle TElPDFMetricW2Handle;

typedef TElPDFMetricW2Handle ElPDFMetricW2Handle;

typedef TElClassHandle TElPDFCIDFontHandle;

typedef TElPDFCIDFontHandle ElPDFCIDFontHandle;

typedef TElClassHandle TElPDFSignatureWidgetTextHandle;

typedef TElPDFSignatureWidgetTextHandle ElPDFSignatureWidgetTextHandle;

typedef TElClassHandle TElPDFSignatureWidgetTextListHandle;

typedef TElPDFSignatureWidgetTextListHandle ElPDFSignatureWidgetTextListHandle;

typedef TElClassHandle TElPDFSignatureWidgetPropsHandle;

typedef TElPDFSignatureWidgetPropsHandle ElPDFSignatureWidgetPropsHandle;

typedef TElClassHandle TElPDFSignatureInfoHandle;

typedef TElPDFSignatureInfoHandle ElPDFSignatureInfoHandle;

typedef TElClassHandle TElPDFEncodingHandlerHandle;

typedef TElPDFEncodingHandlerHandle ElPDFEncodingHandlerHandle;

typedef TElClassHandle TElPDFRequirementHandlerHandle;

typedef TElPDFRequirementHandlerHandle ElPDFRequirementHandlerHandle;

typedef TElClassHandle TElPDFRequirementHandle;

typedef TElPDFRequirementHandle ElPDFRequirementHandle;

typedef TElClassHandle TElPDFPageInfoHandle;

typedef TElPDFPageInfoHandle ElPDFPageInfoHandle;

typedef TElClassHandle TElPDFFileAttachmentHandle;

typedef TElClassHandle TElPDFLegalContentAttestationHandle;

typedef TElClassHandle TElPDFPublicKeyRevocationInfoHandle;

typedef uint8_t TSBPDFSignatureTypeRaw;

typedef enum
{
	stDocument = 0,
	stMDP = 1,
	stUsageRights = 2,
	stObject = 3,
	stUnknown = 4
} TSBPDFSignatureType;

typedef uint8_t TSBPDFTransformMethodRaw;

typedef enum
{
	tmDocMDP = 0,
	tmUR = 1,
	tmUR3 = 2,
	tmFieldMDP = 3,
	tmIdentity = 4,
	tmObject = 5,
	tmUnknown = 6
} TSBPDFTransformMethod;

typedef uint8_t TSBPDFDigestMethodRaw;

typedef enum
{
	dmMD5 = 0,
	dmSHA1 = 1,
	dmUnknown = 2
} TSBPDFDigestMethod;

typedef uint8_t TSBPDFFieldMDPActionRaw;

typedef enum
{
	fmaAll = 0,
	fmaInclude = 1,
	fmaExclude = 2,
	fmaUnknown = 3
} TSBPDFFieldMDPAction;

typedef uint8_t TSBPDFDecryptionModeRaw;

typedef enum
{
	dmFull = 0,
	dmOnDemand = 1,
	dmSign = 2
} TSBPDFDecryptionMode;

typedef uint8_t TSBPDFSignatureRemoveOptionRaw;

typedef enum
{
	sroFull = 0,
	sroKeepField = 1,
	sroKeepAppearance = 2
} TSBPDFSignatureRemoveOption;

typedef uint8_t TSBPDFImageTypeRaw;

typedef enum
{
	pitJPEG2000 = 0,
	pitJPEG = 1,
	pitMask = 2,
	pitMaskInverted = 3,
	pitCustom = 4
} TSBPDFImageType;

typedef uint8_t TSBPDFColorSpaceTypeRaw;

typedef enum
{
	pcstNone = 0,
	pcstGray = 1,
	pcstRGB = 2,
	pcstCMYK = 3
} TSBPDFColorSpaceType;

typedef uint8_t TSBPDFStandardType1FontRaw;

typedef enum
{
	psfUnknown = 0,
	psfHelvetica = 1,
	psfTimesRoman = 2,
	psfCourier = 3,
	psfHelveticaBold = 4,
	psfTimesBold = 5,
	psfCourierBold = 6,
	psfHelveticaOblique = 7,
	psfTimesItalic = 8,
	psfCourierOblique = 9,
	psfHelveticaBoldOblique = 10,
	psfTimesBoldItalic = 11,
	psfCourierBoldOblique = 12,
	psfSymbol = 13,
	psfZapfDingbats = 14
} TSBPDFStandardType1Font;

typedef uint8_t TSBPDFWidgetBackgroundStyleRaw;

typedef enum
{
	pbsDefault = 0,
	pbsNoBackground = 1,
	pbsCustom = 2
} TSBPDFWidgetBackgroundStyle;

typedef void (SB_CALLBACK *TSBPDFConvertStringToAnsiEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcStr, int32_t szStr, uint8_t pOutResult[], int32_t * szOutResult);

typedef void (SB_CALLBACK *TSBPDFLookupGlyphNameEvent)(void * _ObjectData, TObjectHandle Sender, int32_t UCS, char * pcOutResult, int32_t * szOutResult);

typedef void (SB_CALLBACK *TSBPDFLookupGlyphWidthEvent)(void * _ObjectData, TObjectHandle Sender, int32_t UCS, int32_t * Width);

typedef uint8_t TSBPDFSignatureAllowedChangeRaw;

typedef enum
{
	sacFillInForms = 0,
	sacComment = 1
} TSBPDFSignatureAllowedChange;

typedef uint32_t TSBPDFSignatureAllowedChangesRaw;

typedef enum 
{
	f_sacFillInForms = 1,
	f_sacComment = 2
} TSBPDFSignatureAllowedChanges;

typedef uint8_t TSBPDFSignatureOptionRaw;

typedef enum
{
	psoSuppressEmptyAuthorName = 0,
	psoAddAnnotationForInvisibleSignature = 1
} TSBPDFSignatureOption;

typedef uint32_t TSBPDFSignatureOptionsRaw;

typedef enum 
{
	f_psoSuppressEmptyAuthorName = 1,
	f_psoAddAnnotationForInvisibleSignature = 2
} TSBPDFSignatureOptions;

typedef uint8_t TSBSVDConstraintRaw;

typedef enum
{
	svdcFilter = 0,
	svdcSubFilter = 1,
	svdcV = 2,
	svdcReasons = 3,
	svdcLegalAttestation = 4,
	svdcAddRevInfo = 5,
	svdcDigestMethod = 6,
	svdcLockDocument = 7,
	svdcAppearanceFilter = 8
} TSBSVDConstraint;

typedef uint32_t TSBSVDConstraintsRaw;

typedef enum 
{
	f_svdcFilter = 1,
	f_svdcSubFilter = 2,
	f_svdcV = 4,
	f_svdcReasons = 8,
	f_svdcLegalAttestation = 16,
	f_svdcAddRevInfo = 32,
	f_svdcDigestMethod = 64,
	f_svdcLockDocument = 128,
	f_svdcAppearanceFilter = 256
} TSBSVDConstraints;

typedef uint8_t TSBPDFFieldFlagRaw;

typedef enum
{
	ffReadOnly = 0,
	ffRequired = 1,
	ffNoExport = 2
} TSBPDFFieldFlag;

typedef uint32_t TSBPDFFieldFlagsRaw;

typedef enum 
{
	f_ffReadOnly = 1,
	f_ffRequired = 2,
	f_ffNoExport = 4
} TSBPDFFieldFlags;

typedef uint8_t TSBPDFSecurityHandlerEncryptionMethodRaw;

typedef enum
{
	_emNone = 0,
	emV2 = 1,
	emAESV2 = 2,
	emAESV3 = 3,
	emUnknown = 4
} TSBPDFSecurityHandlerEncryptionMethod;

typedef uint8_t TSBPDFEncryptionSubjectRaw;

typedef enum
{
	esStream = 0,
	esString = 1
} TSBPDFEncryptionSubject;

typedef TElClassHandle TElPDFSecurityHandlerClassHandle;

typedef TElClassHandle TElPDFEncodingHandlerClassHandle;

typedef TElPDFEncodingHandlerClassHandle ElPDFEncodingHandlerClassHandle;

typedef uint8_t TSBPDFAssociatedFileRelationshipRaw;

typedef enum
{
	afrNone = 0,
	afrSource = 1,
	afrData = 2,
	afrAlternative = 3,
	afrSupplement = 4,
	afrCustom = 5
} TSBPDFAssociatedFileRelationship;

typedef uint8_t TSBPDFAssemblyOptionRaw;

typedef enum
{
	aoAcrobatFriendlyAcroForm = 0,
	aoAdjustTimesToUTC = 1
} TSBPDFAssemblyOption;

typedef uint32_t TSBPDFAssemblyOptionsRaw;

typedef enum 
{
	f_aoAcrobatFriendlyAcroForm = 1,
	f_aoAdjustTimesToUTC = 2
} TSBPDFAssemblyOptions;

typedef void (SB_CALLBACK *TSBPDFBeforeSignEvent)(void * _ObjectData, TObjectHandle Sender, TElPDFSignatureHandle Signature);

#ifdef SB_USE_CLASS_TELPDFDOCUMENT
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_ExtractAdditionalDataFromAsyncState(TElPDFSecurityHandlerHandle Handler, TElDCAsyncStateHandle State, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_ExtractAdditionalDataFromAsyncState_1(TElPDFDocumentHandle _Handle, TElPDFSecurityHandlerHandle Handler, TElDCAsyncStateHandle State, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_Open(TElPDFDocumentHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_Close(TElPDFDocumentHandle _Handle, int8_t Save);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_Encrypt(TElPDFDocumentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_SignAndEncrypt(TElPDFDocumentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_Decrypt(TElPDFDocumentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_AddSignature(TElPDFDocumentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_AddSignature_1(TElPDFDocumentHandle _Handle, int32_t EmptySignatureField, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_InsertSignature(TElPDFDocumentHandle _Handle, int32_t Index, TElPDFSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_ClearSignatures(TElPDFDocumentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_RemoveSignature(TElPDFDocumentHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_RemoveSignature_1(TElPDFDocumentHandle _Handle, int32_t Index, TSBPDFSignatureRemoveOptionRaw SigRemoveOption);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_RemoveEmptySignatureField(TElPDFDocumentHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_RemoveEmptySignatureField_1(TElPDFDocumentHandle _Handle, int32_t Index, TSBPDFSignatureRemoveOptionRaw SigRemoveOption);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_AddAttachedFile(TElPDFDocumentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_RemoveAttachedFile(TElPDFDocumentHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_InitiateAsyncOperation(TElPDFDocumentHandle _Handle, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_InitiateAsyncOperation_1(TElPDFDocumentHandle _Handle, TSBDCAsyncSignMethodRaw AsyncSignMethod, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_InitiateAsyncOperation_2(TElPDFDocumentHandle _Handle, TElDCParametersHandle Pars, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_InitiateAsyncOperation_3(TElPDFDocumentHandle _Handle, const uint8_t pUserData[], int32_t szUserData, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_InitiateAsyncOperation_4(TElPDFDocumentHandle _Handle, TSBDCAsyncSignMethodRaw AsyncSignMethod, const uint8_t pUserData[], int32_t szUserData, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_InitiateAsyncOperation_5(TElPDFDocumentHandle _Handle, TElDCParametersHandle Pars, const uint8_t pUserData[], int32_t szUserData, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_CompleteAsyncOperation(TElPDFDocumentHandle _Handle, TStreamHandle Stream, TElDCAsyncStateHandle AsyncState, TElPDFSecurityHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_ReloadRevocationInfoFromDSS(TElPDFDocumentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_PageInfos(TElPDFDocumentHandle _Handle, int32_t Index, TElPDFPageInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_Signatures(TElPDFDocumentHandle _Handle, int32_t Index, TElPDFSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_AttachedFiles(TElPDFDocumentHandle _Handle, int32_t Index, TElPDFFileAttachmentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_EmptySignatureFields(TElPDFDocumentHandle _Handle, int32_t Index, TElPDFSignatureInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_DocumentRequirements(TElPDFDocumentHandle _Handle, int32_t Index, TElPDFRequirementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_DocumentID(TElPDFDocumentHandle _Handle, TElPDFArrayHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_DocumentVersion(TElPDFDocumentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_set_DocumentVersion(TElPDFDocumentHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_EmptySignatureFieldCount(TElPDFDocumentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_Decrypted(TElPDFDocumentHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_Encrypted(TElPDFDocumentHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_EncryptionHandler(TElPDFDocumentHandle _Handle, TElPDFSecurityHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_set_EncryptionHandler(TElPDFDocumentHandle _Handle, TElPDFSecurityHandlerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_Opened(TElPDFDocumentHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_DocumentRequirementCount(TElPDFDocumentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_PageInfoCount(TElPDFDocumentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_SignatureCount(TElPDFDocumentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_Signed(TElPDFDocumentHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_AttachedFileCount(TElPDFDocumentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_AssemblyOptions(TElPDFDocumentHandle _Handle, TSBPDFAssemblyOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_set_AssemblyOptions(TElPDFDocumentHandle _Handle, TSBPDFAssemblyOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_DocumentRoot(TElPDFDocumentHandle _Handle, TElPDFArrayHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_DocumentCatalog(TElPDFDocumentHandle _Handle, TElPDFDictionaryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_PDFFile(TElPDFDocumentHandle _Handle, TElPDFFileHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_DecryptionMode(TElPDFDocumentHandle _Handle, TSBPDFDecryptionModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_set_DecryptionMode(TElPDFDocumentHandle _Handle, TSBPDFDecryptionModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_Adobe8Compatibility(TElPDFDocumentHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_set_Adobe8Compatibility(TElPDFDocumentHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_ExtractSignaturesFromPages(TElPDFDocumentHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_set_ExtractSignaturesFromPages(TElPDFDocumentHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_SignatureCustomDataName(TElPDFDocumentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_set_SignatureCustomDataName(TElPDFDocumentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_LegalContentAttestation(TElPDFDocumentHandle _Handle, TElPDFLegalContentAttestationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_DSSRevocationInfo(TElPDFDocumentHandle _Handle, TElPDFPublicKeyRevocationInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_ActivateSecurityHandlers(TElPDFDocumentHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_set_ActivateSecurityHandlers(TElPDFDocumentHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_OwnActivatedSecurityHandlers(TElPDFDocumentHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_set_OwnActivatedSecurityHandlers(TElPDFDocumentHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_Compress(TElPDFDocumentHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_set_Compress(TElPDFDocumentHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_OnProgress(TElPDFDocumentHandle _Handle, TSBPDFProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_set_OnProgress(TElPDFDocumentHandle _Handle, TSBPDFProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_OnCreateTemporaryStream(TElPDFDocumentHandle _Handle, TSBPDFCreateTemporaryStreamEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_set_OnCreateTemporaryStream(TElPDFDocumentHandle _Handle, TSBPDFCreateTemporaryStreamEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_OnDecryptionInfoNeeded(TElPDFDocumentHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_set_OnDecryptionInfoNeeded(TElPDFDocumentHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_get_OnBeforeSign(TElPDFDocumentHandle _Handle, TSBPDFBeforeSignEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_set_OnBeforeSign(TElPDFDocumentHandle _Handle, TSBPDFBeforeSignEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFDocument_Create(TComponentHandle AOwner, TElPDFDocumentHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFDOCUMENT */

#ifdef SB_USE_CLASS_TELPDFSIGNATURE
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_Validate(TElPDFSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_Validate_1(TElPDFSignatureHandle _Handle, int8_t MDPLiberalMode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_GetSignedVersion(TElPDFSignatureHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_IsDocumentSigned(TElPDFSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_Update(TElPDFSignatureHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_Timestamp(TElPDFSignatureHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_SignatureType(TElPDFSignatureHandle _Handle, TSBPDFSignatureTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_SignatureType(TElPDFSignatureHandle _Handle, TSBPDFSignatureTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_AllowedChanges(TElPDFSignatureHandle _Handle, TSBPDFSignatureAllowedChangesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_AllowedChanges(TElPDFSignatureHandle _Handle, TSBPDFSignatureAllowedChangesRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_Handler(TElPDFSignatureHandle _Handle, TElPDFSecurityHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_Handler(TElPDFSignatureHandle _Handle, TElPDFSecurityHandlerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_SignatureName(TElPDFSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_SignatureName(TElPDFSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_AuthorName(TElPDFSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_AuthorName(TElPDFSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_ContactInfo(TElPDFSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_ContactInfo(TElPDFSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_Location(TElPDFSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_Location(TElPDFSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_Reason(TElPDFSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_Reason(TElPDFSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_SigningTime(TElPDFSignatureHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_SigningTime(TElPDFSignatureHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_WidgetProps(TElPDFSignatureHandle _Handle, TElPDFSignatureWidgetPropsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_Invisible(TElPDFSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_Invisible(TElPDFSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_Page(TElPDFSignatureHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_Page(TElPDFSignatureHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_UseHexEncoding(TElPDFSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_UseHexEncoding(TElPDFSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_MDPHashAlgorithm(TElPDFSignatureHandle _Handle, TSBPDFDigestMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_MDPHashAlgorithm(TElPDFSignatureHandle _Handle, TSBPDFDigestMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_DisableDocMDPTransformDigestValue(TElPDFSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_DisableDocMDPTransformDigestValue(TElPDFSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_DisableFieldMDPTransformDigestValue(TElPDFSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_DisableFieldMDPTransformDigestValue(TElPDFSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_ExtraSpace(TElPDFSignatureHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_ExtraSpace(TElPDFSignatureHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_EmptyField(TElPDFSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_EmptyField(TElPDFSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_ExplicitElementSignature(TElPDFSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_ExplicitElementSignature(TElPDFSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_ExplicitElement(TElPDFSignatureHandle _Handle, TElPDFObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_ExplicitElement(TElPDFSignatureHandle _Handle, TElPDFObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_CustomData(TElPDFSignatureHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_CustomData(TElPDFSignatureHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_CustomDataEncoding(TElPDFSignatureHandle _Handle, TPDFStringEncodingRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_CustomDataEncoding(TElPDFSignatureHandle _Handle, TPDFStringEncodingRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_Options(TElPDFSignatureHandle _Handle, TSBPDFSignatureOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_Options(TElPDFSignatureHandle _Handle, TSBPDFSignatureOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_PDFObject(TElPDFSignatureHandle _Handle, TElPDFObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_LockAction(TElPDFSignatureHandle _Handle, TSBPDFFieldMDPActionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_LockAction(TElPDFSignatureHandle _Handle, TSBPDFFieldMDPActionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_LockFields(TElPDFSignatureHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_get_LockAllowedChanges(TElPDFSignatureHandle _Handle, TSBPDFSignatureAllowedChangesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_set_LockAllowedChanges(TElPDFSignatureHandle _Handle, TSBPDFSignatureAllowedChangesRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignature_Create(TElPDFDocumentHandle Owner, TElPDFSignatureHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFSIGNATURE */

#ifdef SB_USE_CLASS_TELPDFURPROPERTIES
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_get_AnnotationRights(TElPDFURPropertiesHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_set_AnnotationRights(TElPDFURPropertiesHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_get_DocumentRights(TElPDFURPropertiesHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_set_DocumentRights(TElPDFURPropertiesHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_get_EmbeddedFileRights(TElPDFURPropertiesHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_set_EmbeddedFileRights(TElPDFURPropertiesHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_get_FormExRights(TElPDFURPropertiesHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_set_FormExRights(TElPDFURPropertiesHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_get_FormRights(TElPDFURPropertiesHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_set_FormRights(TElPDFURPropertiesHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_get_Message(TElPDFURPropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_set_Message(TElPDFURPropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_get_P(TElPDFURPropertiesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_set_P(TElPDFURPropertiesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_get_SignatureRights(TElPDFURPropertiesHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_set_SignatureRights(TElPDFURPropertiesHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFURProperties_Create(TElPDFURPropertiesHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFURPROPERTIES */

#ifdef SB_USE_CLASS_TELPDFSIGREFENTRY
SB_IMPORT uint32_t SB_APIENTRY TElPDFSigRefEntry_get_Valid(TElPDFSigRefEntryHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSigRefEntry_get_DocMDPAccessPermissions(TElPDFSigRefEntryHandle _Handle, int16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSigRefEntry_set_DocMDPAccessPermissions(TElPDFSigRefEntryHandle _Handle, int16_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSigRefEntry_get_FieldMDPAction(TElPDFSigRefEntryHandle _Handle, TSBPDFFieldMDPActionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSigRefEntry_set_FieldMDPAction(TElPDFSigRefEntryHandle _Handle, TSBPDFFieldMDPActionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSigRefEntry_get_FieldMDPFields(TElPDFSigRefEntryHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSigRefEntry_get_DigestMethod(TElPDFSigRefEntryHandle _Handle, TSBPDFDigestMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSigRefEntry_set_DigestMethod(TElPDFSigRefEntryHandle _Handle, TSBPDFDigestMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSigRefEntry_get_TransformMethod(TElPDFSigRefEntryHandle _Handle, TSBPDFTransformMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSigRefEntry_set_TransformMethod(TElPDFSigRefEntryHandle _Handle, TSBPDFTransformMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSigRefEntry_get_URProperties(TElPDFSigRefEntryHandle _Handle, TElPDFURPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSigRefEntry_Create(TElPDFSigRefEntryHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFSIGREFENTRY */

#ifdef SB_USE_CLASS_TELPDFSECURITYHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_Reset(TElPDFSecurityHandlerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_GetName(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_GetName_1(TElPDFSecurityHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_GetDescription(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_GetDescription_1(TElPDFSecurityHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_get_StreamEncryptionAlgorithm(TElPDFSecurityHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_set_StreamEncryptionAlgorithm(TElPDFSecurityHandlerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_get_StringEncryptionAlgorithm(TElPDFSecurityHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_set_StringEncryptionAlgorithm(TElPDFSecurityHandlerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_get_StreamEncryptionKeyBits(TElPDFSecurityHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_set_StreamEncryptionKeyBits(TElPDFSecurityHandlerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_get_StringEncryptionKeyBits(TElPDFSecurityHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_set_StringEncryptionKeyBits(TElPDFSecurityHandlerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_get_EncryptMetadata(TElPDFSecurityHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_set_EncryptMetadata(TElPDFSecurityHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_get_CustomName(TElPDFSecurityHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_set_CustomName(TElPDFSecurityHandlerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_get_CryptoProviderManager(TElPDFSecurityHandlerHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_set_CryptoProviderManager(TElPDFSecurityHandlerHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSecurityHandler_Create(TComponentHandle Owner, TElPDFSecurityHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFSECURITYHANDLER */

#ifdef SB_USE_CLASS_TELPDFBYTERANGE
SB_IMPORT uint32_t SB_APIENTRY TElPDFByteRange_get_StartOffset(TElPDFByteRangeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFByteRange_set_StartOffset(TElPDFByteRangeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFByteRange_get_Count(TElPDFByteRangeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFByteRange_set_Count(TElPDFByteRangeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFByteRange_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFBYTERANGE */

#ifdef SB_USE_CLASS_TELPDFIMAGE
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_AddMaskColorComponent(TElPDFImageHandle _Handle, int32_t MinCC, int32_t MaxCC, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_DeleteMaskColorComponent(TElPDFImageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_get_ImageType(TElPDFImageHandle _Handle, TSBPDFImageTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_set_ImageType(TElPDFImageHandle _Handle, TSBPDFImageTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_get_Data(TElPDFImageHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_set_Data(TElPDFImageHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_get_Width(TElPDFImageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_set_Width(TElPDFImageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_get_Height(TElPDFImageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_set_Height(TElPDFImageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_get_MaskImage(TElPDFImageHandle _Handle, TElPDFImageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_get_MaskColorComponentCount(TElPDFImageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_get_MaskColorComponentsMin(TElPDFImageHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_get_MaskColorComponentsMax(TElPDFImageHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_get_BitsPerComponent(TElPDFImageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_set_BitsPerComponent(TElPDFImageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_get_ColorSpaceType(TElPDFImageHandle _Handle, TSBPDFColorSpaceTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_set_ColorSpaceType(TElPDFImageHandle _Handle, TSBPDFColorSpaceTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_get_Interpolate(TElPDFImageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_set_Interpolate(TElPDFImageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_get_ResourceName(TElPDFImageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_set_ResourceName(TElPDFImageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFImage_Create(TElPDFImageHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFIMAGE */

#ifdef SB_USE_CLASS_TELPDFCUSTOMFONTOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElPDFCustomFontObject_Create(TElPDFCustomFontObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFCUSTOMFONTOBJECT */

#ifdef SB_USE_CLASS_TELPDFENCODING
SB_IMPORT uint32_t SB_APIENTRY TElPDFEncoding_get_BaseEncoding(TElPDFEncodingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFEncoding_set_BaseEncoding(TElPDFEncodingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFEncoding_get_Differences(TElPDFEncodingHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFEncoding_set_Differences(TElPDFEncodingHandle _Handle, int32_t Index, const char * pcName, int32_t szName);
SB_IMPORT uint32_t SB_APIENTRY TElPDFEncoding_Create(TElPDFEncodingHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFENCODING */

#ifdef SB_USE_CLASS_TELPDFFONTDESCRIPTOR
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_FontName(TElPDFFontDescriptorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_FontName(TElPDFFontDescriptorHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_FontFamily(TElPDFFontDescriptorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_FontFamily(TElPDFFontDescriptorHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_FontStretch(TElPDFFontDescriptorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_FontStretch(TElPDFFontDescriptorHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_FontWeight(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_FontWeight(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_Flags(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_Flags(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_FontBBoxX1(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_FontBBoxX1(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_FontBBoxX2(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_FontBBoxX2(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_FontBBoxY1(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_FontBBoxY1(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_FontBBoxY2(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_FontBBoxY2(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_ItalicAngle(TElPDFFontDescriptorHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_ItalicAngle(TElPDFFontDescriptorHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_Ascent(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_Ascent(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_Descent(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_Descent(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_Leading(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_Leading(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_CapHeight(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_CapHeight(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_XHeight(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_XHeight(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_StemV(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_StemV(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_StemH(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_StemH(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_AvgWidth(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_AvgWidth(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_MaxWidth(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_MaxWidth(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_MissingWidth(TElPDFFontDescriptorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_MissingWidth(TElPDFFontDescriptorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_FontFile(TElPDFFontDescriptorHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_FontFile(TElPDFFontDescriptorHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_FontFile2(TElPDFFontDescriptorHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_FontFile2(TElPDFFontDescriptorHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_FontFile3(TElPDFFontDescriptorHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_FontFile3(TElPDFFontDescriptorHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_get_CharSet(TElPDFFontDescriptorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_set_CharSet(TElPDFFontDescriptorHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFontDescriptor_Create(TElPDFFontDescriptorHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFFONTDESCRIPTOR */

#ifdef SB_USE_CLASS_TELPDFCIDFONTDESCRIPTOR
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFontDescriptor_get_Lang(TElPDFCIDFontDescriptorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFontDescriptor_set_Lang(TElPDFCIDFontDescriptorHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFontDescriptor_get_CIDSet(TElPDFCIDFontDescriptorHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFontDescriptor_set_CIDSet(TElPDFCIDFontDescriptorHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFontDescriptor_Create(TElPDFCIDFontDescriptorHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFCIDFONTDESCRIPTOR */

#ifdef SB_USE_CLASS_TELPDFCIDSYSTEMINFO
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDSystemInfo_get_Registry(TElPDFCIDSystemInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDSystemInfo_set_Registry(TElPDFCIDSystemInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDSystemInfo_get_Ordering(TElPDFCIDSystemInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDSystemInfo_set_Ordering(TElPDFCIDSystemInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDSystemInfo_get_Supplement(TElPDFCIDSystemInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDSystemInfo_set_Supplement(TElPDFCIDSystemInfoHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDSystemInfo_Create(TElPDFCIDSystemInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFCIDSYSTEMINFO */

#ifdef SB_USE_CLASS_TELPDFCUSTOMFONT
SB_IMPORT uint32_t SB_APIENTRY TElPDFCustomFont_get_Subtype(TElPDFCustomFontHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCustomFont_set_Subtype(TElPDFCustomFontHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCustomFont_get_BaseFont(TElPDFCustomFontHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCustomFont_set_BaseFont(TElPDFCustomFontHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCustomFont_get_ResourceName(TElPDFCustomFontHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCustomFont_set_ResourceName(TElPDFCustomFontHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCustomFont_get_ToUnicode(TElPDFCustomFontHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCustomFont_set_ToUnicode(TElPDFCustomFontHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCustomFont_Create(TElPDFCustomFontHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFCUSTOMFONT */

#ifdef SB_USE_CLASS_TELPDFSIMPLEFONT
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_get_Encoding(TElPDFSimpleFontHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_set_Encoding(TElPDFSimpleFontHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_get_EncodingObject(TElPDFSimpleFontHandle _Handle, TElPDFEncodingHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_set_EncodingObject(TElPDFSimpleFontHandle _Handle, TElPDFEncodingHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_get_FontDescriptor(TElPDFSimpleFontHandle _Handle, TElPDFFontDescriptorHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_set_FontDescriptor(TElPDFSimpleFontHandle _Handle, TElPDFFontDescriptorHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_get_FontName(TElPDFSimpleFontHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_set_FontName(TElPDFSimpleFontHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_get_FirstChar(TElPDFSimpleFontHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_set_FirstChar(TElPDFSimpleFontHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_get_LastChar(TElPDFSimpleFontHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_set_LastChar(TElPDFSimpleFontHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_get_Widths(TElPDFSimpleFontHandle _Handle, int32_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_set_Widths(TElPDFSimpleFontHandle _Handle, const int32_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSimpleFont_Create(TElPDFSimpleFontHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFSIMPLEFONT */

#ifdef SB_USE_CLASS_TELPDFCOMPOSITEFONT
SB_IMPORT uint32_t SB_APIENTRY TElPDFCompositeFont_get_DescendantFonts(TElPDFCompositeFontHandle _Handle, TElPDFCustomFontHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCompositeFont_set_DescendantFonts(TElPDFCompositeFontHandle _Handle, TElPDFCustomFontHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCompositeFont_get_Encoding(TElPDFCompositeFontHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCompositeFont_set_Encoding(TElPDFCompositeFontHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCompositeFont_get_EncodingData(TElPDFCompositeFontHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCompositeFont_set_EncodingData(TElPDFCompositeFontHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCompositeFont_Create(TElPDFCompositeFontHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFCOMPOSITEFONT */

#ifdef SB_USE_CLASS_TELPDFMETRICW
SB_IMPORT uint32_t SB_APIENTRY TElPDFMetricW_Add(TElPDFMetricWHandle _Handle, int32_t CID, int32_t Width);
SB_IMPORT uint32_t SB_APIENTRY TElPDFMetricW_AddRange(TElPDFMetricWHandle _Handle, int32_t First, int32_t Last, int32_t Width);
SB_IMPORT uint32_t SB_APIENTRY TElPDFMetricW_Create(TElPDFMetricWHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFMETRICW */

#ifdef SB_USE_CLASS_TELPDFMETRICW2
SB_IMPORT uint32_t SB_APIENTRY TElPDFMetricW2_Add(TElPDFMetricW2Handle _Handle, int32_t CID, int32_t Width, int32_t VX, int32_t VY);
SB_IMPORT uint32_t SB_APIENTRY TElPDFMetricW2_AddRange(TElPDFMetricW2Handle _Handle, int32_t First, int32_t Last, int32_t Width, int32_t VX, int32_t VY);
SB_IMPORT uint32_t SB_APIENTRY TElPDFMetricW2_Create(TElPDFMetricW2Handle * OutResult);
#endif /* SB_USE_CLASS_TELPDFMETRICW2 */

#ifdef SB_USE_CLASS_TELPDFCIDFONT
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_get_CIDSystemInfo(TElPDFCIDFontHandle _Handle, TElPDFCIDSystemInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_set_CIDSystemInfo(TElPDFCIDFontHandle _Handle, TElPDFCIDSystemInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_get_FontDescriptor(TElPDFCIDFontHandle _Handle, TElPDFCIDFontDescriptorHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_set_FontDescriptor(TElPDFCIDFontHandle _Handle, TElPDFCIDFontDescriptorHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_get_DW(TElPDFCIDFontHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_set_DW(TElPDFCIDFontHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_get_W(TElPDFCIDFontHandle _Handle, TElPDFMetricWHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_get_DW2(TElPDFCIDFontHandle _Handle, int32_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_set_DW2(TElPDFCIDFontHandle _Handle, const int32_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_get_W2(TElPDFCIDFontHandle _Handle, TElPDFMetricW2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_set_W2(TElPDFCIDFontHandle _Handle, TElPDFMetricW2Handle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_get_CIDToGIDMap(TElPDFCIDFontHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_set_CIDToGIDMap(TElPDFCIDFontHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_get_CIDToGIDMapData(TElPDFCIDFontHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_set_CIDToGIDMapData(TElPDFCIDFontHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFCIDFont_Create(TElPDFCIDFontHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFCIDFONT */

#ifdef SB_USE_CLASS_TELPDFSIGNATUREWIDGETTEXT
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_get_Text(TElPDFSignatureWidgetTextHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_set_Text(TElPDFSignatureWidgetTextHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_get_FontSizeX(TElPDFSignatureWidgetTextHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_set_FontSizeX(TElPDFSignatureWidgetTextHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_get_FontSizeY(TElPDFSignatureWidgetTextHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_set_FontSizeY(TElPDFSignatureWidgetTextHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_get_X(TElPDFSignatureWidgetTextHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_set_X(TElPDFSignatureWidgetTextHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_get_Y(TElPDFSignatureWidgetTextHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_set_Y(TElPDFSignatureWidgetTextHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_get_FontResourceName(TElPDFSignatureWidgetTextHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_set_FontResourceName(TElPDFSignatureWidgetTextHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_get_CustomData(TElPDFSignatureWidgetTextHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_set_CustomData(TElPDFSignatureWidgetTextHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetText_Create(TElPDFSignatureWidgetTextHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFSIGNATUREWIDGETTEXT */

#ifdef SB_USE_CLASS_TELPDFSIGNATUREWIDGETTEXTLIST
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetTextList_Add(TElPDFSignatureWidgetTextListHandle _Handle, const char * pcText, int32_t szText, double X, double Y, double FontSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetTextList_Add_1(TElPDFSignatureWidgetTextListHandle _Handle, const char * pcText, int32_t szText, double X, double Y, double FontSizeX, double FontSizeY, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetTextList_Add_2(TElPDFSignatureWidgetTextListHandle _Handle, TElPDFSignatureWidgetTextHandle ATextData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetTextList_Add_3(TElPDFSignatureWidgetTextListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetTextList_Delete(TElPDFSignatureWidgetTextListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetTextList_Clear(TElPDFSignatureWidgetTextListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetTextList_get_Count(TElPDFSignatureWidgetTextListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetTextList_get_TextData(TElPDFSignatureWidgetTextListHandle _Handle, int32_t Index, TElPDFSignatureWidgetTextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetTextList_Create(TElPDFSignatureWidgetTextListHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFSIGNATUREWIDGETTEXTLIST */

#ifdef SB_USE_CLASS_TELPDFSIGNATUREWIDGETPROPS
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_AddFont(TElPDFSignatureWidgetPropsHandle _Handle, TElPDFCustomFontHandle Font);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_AddFontObject(TElPDFSignatureWidgetPropsHandle _Handle, TElPDFCustomFontObjectHandle FontObject);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_AddImage(TElPDFSignatureWidgetPropsHandle _Handle, TElPDFImageHandle Image);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_AddImage_1(TElPDFSignatureWidgetPropsHandle _Handle, TElPDFImageHandle Image, double X, double Y, double SizeX, double SizeY);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_ClearFonts(TElPDFSignatureWidgetPropsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_ClearFontObjects(TElPDFSignatureWidgetPropsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_ClearImages(TElPDFSignatureWidgetPropsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_AlgorithmInfo(TElPDFSignatureWidgetPropsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_AlgorithmInfo(TElPDFSignatureWidgetPropsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_AutoAdjustEncoding(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_AutoAdjustEncoding(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_AutoText(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_AutoText(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_AutoFontSize(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_AutoFontSize(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_AutoSize(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_AutoSize(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_AutoPos(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_AutoPos(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_AutoStretchBackground(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_AutoStretchBackground(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_Header(TElPDFSignatureWidgetPropsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_Header(TElPDFSignatureWidgetPropsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_Height(TElPDFSignatureWidgetPropsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_Height(TElPDFSignatureWidgetPropsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_Locked(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_Locked(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_LockedContents(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_LockedContents(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_NoRotate(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_NoRotate(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_NoView(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_NoView(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_NoZoom(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_NoZoom(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_Print(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_Print(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_ReadOnly(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_ReadOnly(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_ToggleNoView(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_ToggleNoView(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_ShowTimestamp(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_ShowTimestamp(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_SignerInfo(TElPDFSignatureWidgetPropsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_SignerInfo(TElPDFSignatureWidgetPropsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_Width(TElPDFSignatureWidgetPropsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_Width(TElPDFSignatureWidgetPropsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_OffsetX(TElPDFSignatureWidgetPropsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_OffsetX(TElPDFSignatureWidgetPropsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_OffsetY(TElPDFSignatureWidgetPropsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_OffsetY(TElPDFSignatureWidgetPropsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_TitleFontSize(TElPDFSignatureWidgetPropsHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_TitleFontSize(TElPDFSignatureWidgetPropsHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_TimestampFontSize(TElPDFSignatureWidgetPropsHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_TimestampFontSize(TElPDFSignatureWidgetPropsHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_SectionTitleFontSize(TElPDFSignatureWidgetPropsHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_SectionTitleFontSize(TElPDFSignatureWidgetPropsHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_SectionTextFontSize(TElPDFSignatureWidgetPropsHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_SectionTextFontSize(TElPDFSignatureWidgetPropsHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_Background(TElPDFSignatureWidgetPropsHandle _Handle, TElPDFImageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_BackgroundStyle(TElPDFSignatureWidgetPropsHandle _Handle, TSBPDFWidgetBackgroundStyleRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_BackgroundStyle(TElPDFSignatureWidgetPropsHandle _Handle, TSBPDFWidgetBackgroundStyleRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_StretchX(TElPDFSignatureWidgetPropsHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_StretchX(TElPDFSignatureWidgetPropsHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_StretchY(TElPDFSignatureWidgetPropsHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_StretchY(TElPDFSignatureWidgetPropsHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_Rotate(TElPDFSignatureWidgetPropsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_Rotate(TElPDFSignatureWidgetPropsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_SignerCaption(TElPDFSignatureWidgetPropsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_SignerCaption(TElPDFSignatureWidgetPropsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_AlgorithmCaption(TElPDFSignatureWidgetPropsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_AlgorithmCaption(TElPDFSignatureWidgetPropsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_DateCaptionFormat(TElPDFSignatureWidgetPropsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_DateCaptionFormat(TElPDFSignatureWidgetPropsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_CustomAppearance(TElPDFSignatureWidgetPropsHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_CustomAppearance(TElPDFSignatureWidgetPropsHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_CustomText(TElPDFSignatureWidgetPropsHandle _Handle, TElPDFSignatureWidgetTextListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_HideDefaultText(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_HideDefaultText(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_CompressWidgetData(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_CompressWidgetData(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_CustomBackgroundContentStream(TElPDFSignatureWidgetPropsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_CustomBackgroundContentStream(TElPDFSignatureWidgetPropsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_ShowVisualStatus(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_ShowVisualStatus(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_CustomVisualStatusMatrix(TElPDFSignatureWidgetPropsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_CustomVisualStatusMatrix(TElPDFSignatureWidgetPropsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_SigningTime(TElPDFSignatureWidgetPropsHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_SigningTime(TElPDFSignatureWidgetPropsHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_IgnoreExistingAppearance(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_IgnoreExistingAppearance(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_ShowOnAllPages(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_ShowOnAllPages(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_PagesToPlaceOn(TElPDFSignatureWidgetPropsHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_PagesToPlaceOn(TElPDFSignatureWidgetPropsHandle _Handle, int32_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_SaveStringsInUnicodeEncoding(TElPDFSignatureWidgetPropsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_SaveStringsInUnicodeEncoding(TElPDFSignatureWidgetPropsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_OnConvertStringToAnsi(TElPDFSignatureWidgetPropsHandle _Handle, TSBPDFConvertStringToAnsiEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_OnConvertStringToAnsi(TElPDFSignatureWidgetPropsHandle _Handle, TSBPDFConvertStringToAnsiEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_OnLookupGlyphName(TElPDFSignatureWidgetPropsHandle _Handle, TSBPDFLookupGlyphNameEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_OnLookupGlyphName(TElPDFSignatureWidgetPropsHandle _Handle, TSBPDFLookupGlyphNameEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_get_OnLookupGlyphWidth(TElPDFSignatureWidgetPropsHandle _Handle, TSBPDFLookupGlyphWidthEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_set_OnLookupGlyphWidth(TElPDFSignatureWidgetPropsHandle _Handle, TSBPDFLookupGlyphWidthEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureWidgetProps_Create(TElPDFSignatureHandle Owner, TElPDFSignatureWidgetPropsHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFSIGNATUREWIDGETPROPS */

#ifdef SB_USE_CLASS_TELPDFSIGNATUREINFO
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_FieldName(TElPDFSignatureInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_FieldFlags(TElPDFSignatureInfoHandle _Handle, TSBPDFFieldFlagsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_MappingName(TElPDFSignatureInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_AlternateName(TElPDFSignatureInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_RequiredConstraints(TElPDFSignatureInfoHandle _Handle, TSBSVDConstraintsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_RequiredFilter(TElPDFSignatureInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_RequiredSubfilters(TElPDFSignatureInfoHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_RequiredDigestAlgorithms(TElPDFSignatureInfoHandle _Handle, int32_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_RequiredReasons(TElPDFSignatureInfoHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_RequiredLockAction(TElPDFSignatureInfoHandle _Handle, TSBPDFFieldMDPActionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_RequiredLockFields(TElPDFSignatureInfoHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_RequiredAllowedChanges(TElPDFSignatureInfoHandle _Handle, TSBPDFSignatureAllowedChangesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_TSPURL(TElPDFSignatureInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_TimestampRequired(TElPDFSignatureInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_LegalAttestations(TElPDFSignatureInfoHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_AddRevInfo(TElPDFSignatureInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_Height(TElPDFSignatureInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_Width(TElPDFSignatureInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_OffsetX(TElPDFSignatureInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_OffsetY(TElPDFSignatureInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_Page(TElPDFSignatureInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_get_Invisible(TElPDFSignatureInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFSignatureInfo_Create(TElPDFSignatureInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFSIGNATUREINFO */

#ifdef SB_USE_CLASS_TELPDFENCODINGHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElPDFEncodingHandler_GetName(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFEncodingHandler_GetName_1(TElPDFEncodingHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFEncodingHandler_GetDescription(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFEncodingHandler_GetDescription_1(TElPDFEncodingHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFEncodingHandler_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFEncodingHandler_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFENCODINGHANDLER */

#ifdef SB_USE_CLASS_TELPDFREQUIREMENTHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElPDFRequirementHandler_get_HandlerType(TElPDFRequirementHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFRequirementHandler_get_ScriptName(TElPDFRequirementHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFRequirementHandler_Create(TElPDFRequirementHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFREQUIREMENTHANDLER */

#ifdef SB_USE_CLASS_TELPDFREQUIREMENT
SB_IMPORT uint32_t SB_APIENTRY TElPDFRequirement_get_RequirementType(TElPDFRequirementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFRequirement_get_HandlerCount(TElPDFRequirementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFRequirement_get_Handlers(TElPDFRequirementHandle _Handle, int32_t Index, TElPDFRequirementHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFRequirement_Create(TElPDFRequirementHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFREQUIREMENT */

#ifdef SB_USE_CLASS_TELPDFPAGEINFO
SB_IMPORT uint32_t SB_APIENTRY TElPDFPageInfo_CropBoxEmpty(TElPDFPageInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPageInfo_get_Width(TElPDFPageInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPageInfo_get_Height(TElPDFPageInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPageInfo_get_Rotate(TElPDFPageInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPageInfo_get_CropLLX(TElPDFPageInfoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPageInfo_get_CropLLY(TElPDFPageInfoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPageInfo_get_CropURX(TElPDFPageInfoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPageInfo_get_CropURY(TElPDFPageInfoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPageInfo_get_MediaLLX(TElPDFPageInfoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPageInfo_get_MediaLLY(TElPDFPageInfoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPageInfo_get_MediaURX(TElPDFPageInfoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPageInfo_get_MediaURY(TElPDFPageInfoHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPageInfo_get_PageObject(TElPDFPageInfoHandle _Handle, TElPDFDictionaryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPageInfo_Create(TElPDFPageInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFPAGEINFO */

#ifdef SB_USE_CLASS_TELPDFFILEATTACHMENT
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_Init(TElPDFFileAttachmentHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_Save(TElPDFFileAttachmentHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_get_ObjectName(TElPDFFileAttachmentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_set_ObjectName(TElPDFFileAttachmentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_get_Filename(TElPDFFileAttachmentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_set_Filename(TElPDFFileAttachmentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_get_UnicodeFilename(TElPDFFileAttachmentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_set_UnicodeFilename(TElPDFFileAttachmentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_get_Description(TElPDFFileAttachmentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_set_Description(TElPDFFileAttachmentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_get_SubType(TElPDFFileAttachmentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_set_SubType(TElPDFFileAttachmentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_get_Size(TElPDFFileAttachmentHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_get_CreationDate(TElPDFFileAttachmentHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_set_CreationDate(TElPDFFileAttachmentHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_get_ModificationDate(TElPDFFileAttachmentHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_set_ModificationDate(TElPDFFileAttachmentHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_get_MD5Checksum(TElPDFFileAttachmentHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_get_AssociatedFilePDFObject(TElPDFFileAttachmentHandle _Handle, TElPDFDictionaryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_set_AssociatedFilePDFObject(TElPDFFileAttachmentHandle _Handle, TElPDFDictionaryHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_get_AssociatedFileRelationship(TElPDFFileAttachmentHandle _Handle, TSBPDFAssociatedFileRelationshipRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_set_AssociatedFileRelationship(TElPDFFileAttachmentHandle _Handle, TSBPDFAssociatedFileRelationshipRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_get_AssociatedFileRelationshipName(TElPDFFileAttachmentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_set_AssociatedFileRelationshipName(TElPDFFileAttachmentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFFileAttachment_Create(TElPDFFileAttachmentHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFFILEATTACHMENT */

#ifdef SB_USE_CLASS_TELPDFLEGALCONTENTATTESTATION
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_JavascriptActions(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_JavascriptActions(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_LaunchActions(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_LaunchActions(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_URIActions(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_URIActions(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_MovieActions(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_MovieActions(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_SoundActions(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_SoundActions(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_HideAnnotationActions(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_HideAnnotationActions(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_GoToRemoteActions(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_GoToRemoteActions(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_AlternateImages(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_AlternateImages(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_ExternalStreams(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_ExternalStreams(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_TrueTypeFonts(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_TrueTypeFonts(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_ExternalRefXObjects(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_ExternalRefXObjects(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_ExternalOPIDicts(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_ExternalOPIDicts(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_NonEmbeddedFonts(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_NonEmbeddedFonts(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_DevDepGSOP(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_DevDepGSOP(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_DevDepGSHT(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_DevDepGSHT(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_DevDepGSTR(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_DevDepGSTR(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_DevDepGSUCR(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_DevDepGSUCR(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_DevDepGSBG(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_DevDepGSBG(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_DevDepGSFL(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_DevDepGSFL(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_Annotations(TElPDFLegalContentAttestationHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_Annotations(TElPDFLegalContentAttestationHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_OptionalContent(TElPDFLegalContentAttestationHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_OptionalContent(TElPDFLegalContentAttestationHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_Attestation(TElPDFLegalContentAttestationHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_Attestation(TElPDFLegalContentAttestationHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_get_Include(TElPDFLegalContentAttestationHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_set_Include(TElPDFLegalContentAttestationHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFLegalContentAttestation_Create(TElPDFLegalContentAttestationHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFLEGALCONTENTATTESTATION */

#ifdef SB_USE_CLASS_TELPDFPUBLICKEYREVOCATIONINFO
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_Assign(TElPDFPublicKeyRevocationInfoHandle _Handle, TElPDFPublicKeyRevocationInfoHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_Assign_1(TElPDFPublicKeyRevocationInfoHandle _Handle, TElPDFPublicKeyRevocationInfoHandle Source, int8_t Clear);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_AddCRL(TElPDFPublicKeyRevocationInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_RemoveCRL(TElPDFPublicKeyRevocationInfoHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_ClearCRLs(TElPDFPublicKeyRevocationInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_ContainsCRL(TElPDFPublicKeyRevocationInfoHandle _Handle, TElAbstractCRLHandle Crl, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_AddOCSPResponse(TElPDFPublicKeyRevocationInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_RemoveOCSPResponse(TElPDFPublicKeyRevocationInfoHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_ClearOCSPResponses(TElPDFPublicKeyRevocationInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_ContainsOCSPResponse(TElPDFPublicKeyRevocationInfoHandle _Handle, const uint8_t pResponse[], int32_t szResponse, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_Clear(TElPDFPublicKeyRevocationInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_IsEmpty(TElPDFPublicKeyRevocationInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_get_CRLs(TElPDFPublicKeyRevocationInfoHandle _Handle, int32_t Index, TElAbstractCRLHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_get_OCSPResponses(TElPDFPublicKeyRevocationInfoHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_set_OCSPResponses(TElPDFPublicKeyRevocationInfoHandle _Handle, int32_t Index, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_get_CRLCount(TElPDFPublicKeyRevocationInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_get_OCSPResponseCount(TElPDFPublicKeyRevocationInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_get_Certificates(TElPDFPublicKeyRevocationInfoHandle _Handle, TElMemoryCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_get_OtherInfo(TElPDFPublicKeyRevocationInfoHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRevocationInfo_Create(TElPDFPublicKeyRevocationInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFPUBLICKEYREVOCATIONINFO */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPDFSecurityHandlerClass_ce_ptr;
extern zend_class_entry *TElPDFEncodingHandlerClass_ce_ptr;
extern zend_class_entry *TElPDFDocument_ce_ptr;
extern zend_class_entry *TElPDFSignature_ce_ptr;
extern zend_class_entry *TElPDFURProperties_ce_ptr;
extern zend_class_entry *TElPDFSigRefEntry_ce_ptr;
extern zend_class_entry *TElPDFSecurityHandler_ce_ptr;
extern zend_class_entry *TElPDFByteRange_ce_ptr;
extern zend_class_entry *TElPDFImage_ce_ptr;
extern zend_class_entry *TElPDFCustomFontObject_ce_ptr;
extern zend_class_entry *TElPDFEncoding_ce_ptr;
extern zend_class_entry *TElPDFFontDescriptor_ce_ptr;
extern zend_class_entry *TElPDFCIDFontDescriptor_ce_ptr;
extern zend_class_entry *TElPDFCIDSystemInfo_ce_ptr;
extern zend_class_entry *TElPDFCustomFont_ce_ptr;
extern zend_class_entry *TElPDFSimpleFont_ce_ptr;
extern zend_class_entry *TElPDFCompositeFont_ce_ptr;
extern zend_class_entry *TElPDFMetricW_ce_ptr;
extern zend_class_entry *TElPDFMetricW2_ce_ptr;
extern zend_class_entry *TElPDFCIDFont_ce_ptr;
extern zend_class_entry *TElPDFSignatureWidgetText_ce_ptr;
extern zend_class_entry *TElPDFSignatureWidgetTextList_ce_ptr;
extern zend_class_entry *TElPDFSignatureWidgetProps_ce_ptr;
extern zend_class_entry *TElPDFSignatureInfo_ce_ptr;
extern zend_class_entry *TElPDFEncodingHandler_ce_ptr;
extern zend_class_entry *TElPDFRequirementHandler_ce_ptr;
extern zend_class_entry *TElPDFRequirement_ce_ptr;
extern zend_class_entry *TElPDFPageInfo_ce_ptr;
extern zend_class_entry *TElPDFFileAttachment_ce_ptr;
extern zend_class_entry *TElPDFLegalContentAttestation_ce_ptr;
extern zend_class_entry *TElPDFPublicKeyRevocationInfo_ce_ptr;

void SB_CALLBACK TSBPDFConvertStringToAnsiEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcStr, int32_t szStr, uint8_t pOutResult[], int32_t * szOutResult);
void SB_CALLBACK TSBPDFLookupGlyphNameEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t UCS, char * pcOutResult, int32_t * szOutResult);
void SB_CALLBACK TSBPDFLookupGlyphWidthEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t UCS, int32_t * Width);
void SB_CALLBACK TSBPDFBeforeSignEventRaw(void * _ObjectData, TObjectHandle Sender, TElPDFSignatureHandle Signature);
void Register_TElPDFDocument(TSRMLS_D);
void Register_TElPDFSignature(TSRMLS_D);
void Register_TElPDFURProperties(TSRMLS_D);
void Register_TElPDFSigRefEntry(TSRMLS_D);
void Register_TElPDFSecurityHandler(TSRMLS_D);
void Register_TElPDFByteRange(TSRMLS_D);
void Register_TElPDFImage(TSRMLS_D);
void Register_TElPDFCustomFontObject(TSRMLS_D);
void Register_TElPDFEncoding(TSRMLS_D);
void Register_TElPDFFontDescriptor(TSRMLS_D);
void Register_TElPDFCIDFontDescriptor(TSRMLS_D);
void Register_TElPDFCIDSystemInfo(TSRMLS_D);
void Register_TElPDFCustomFont(TSRMLS_D);
void Register_TElPDFSimpleFont(TSRMLS_D);
void Register_TElPDFCompositeFont(TSRMLS_D);
void Register_TElPDFMetricW(TSRMLS_D);
void Register_TElPDFMetricW2(TSRMLS_D);
void Register_TElPDFCIDFont(TSRMLS_D);
void Register_TElPDFSignatureWidgetText(TSRMLS_D);
void Register_TElPDFSignatureWidgetTextList(TSRMLS_D);
void Register_TElPDFSignatureWidgetProps(TSRMLS_D);
void Register_TElPDFSignatureInfo(TSRMLS_D);
void Register_TElPDFEncodingHandler(TSRMLS_D);
void Register_TElPDFRequirementHandler(TSRMLS_D);
void Register_TElPDFRequirement(TSRMLS_D);
void Register_TElPDFPageInfo(TSRMLS_D);
void Register_TElPDFFileAttachment(TSRMLS_D);
void Register_TElPDFLegalContentAttestation(TSRMLS_D);
void Register_TElPDFPublicKeyRevocationInfo(TSRMLS_D);
SB_PHP_FUNCTION(SBPDF, RegisterSecurityHandler);
SB_PHP_FUNCTION(SBPDF, UnregisterSecurityHandler);
SB_PHP_FUNCTION(SBPDF, GetPDFStandardType1FontName);
void Register_SBPDF_Constants(int module_number TSRMLS_DC);
void Register_SBPDF_Enum_Flags(TSRMLS_D);
void Register_SBPDF_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_PDF
SB_IMPORT uint32_t SB_APIENTRY SBPDF_RegisterSecurityHandler(TElPDFSecurityHandlerClassHandle HandlerClass);
SB_IMPORT uint32_t SB_APIENTRY SBPDF_UnregisterSecurityHandler(TElPDFSecurityHandlerClassHandle HandlerClass);
SB_IMPORT uint32_t SB_APIENTRY SBPDF_GetPDFStandardType1FontName(TSBPDFStandardType1FontRaw Font, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_PDF */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPDF */

