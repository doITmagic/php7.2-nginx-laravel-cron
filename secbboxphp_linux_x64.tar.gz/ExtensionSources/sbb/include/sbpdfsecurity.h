#ifndef __INC_SBPDFSECURITY
#define __INC_SBPDFSECURITY

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbcryptoprov.h"
#include "sbpdfcore.h"
#include "sbpdf.h"
#include "sbhashfunction.h"
#include "sbpkcs7.h"
#include "sbpkcs7utils.h"
#include "sbcustomcertstorage.h"
#include "sbx509.h"
#include "sbcrl.h"
#include "sbcustomcrypto.h"
#include "sbpublickeycrypto.h"
#include "sbmessages.h"
#include "sbdc.h"
#include "sbdcdef.h"
#include "sbdcsec.h"
#include "sbtspcommon.h"
#include "sbtspclient.h"
#include "sbconstants.h"
#include "sbasn1tree.h"
#include "sbrdn.h"
#include "sbpdfutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SPDFNoSigningCertificate 	"No signing certificate found"
#define SB_SPDFInvalidPKCS7Data 	"Invalid PKCS#7 data"
#define SB_SPDFTSPClientNotFound 	"TSP client component not found"

typedef TElClassHandle TElPDFPasswordSecurityHandlerHandle;

typedef TElPDFPasswordSecurityHandlerHandle ElPDFPasswordSecurityHandlerHandle;

typedef TElClassHandle TElPDFPublicKeySecurityHandlerHandle;

typedef TElPDFPublicKeySecurityHandlerHandle ElPDFPublicKeySecurityHandlerHandle;

typedef TElClassHandle TElPDFPublicKeyRecipientGroupHandle;

typedef TElPDFPublicKeyRecipientGroupHandle ElPDFPublicKeyRecipientGroupHandle;

typedef uint8_t TSBPDFPublicKeySignatureTypeRaw;

typedef enum
{
	pstX509RSASHA1 = 0,
	pstPKCS7SHA1 = 1
} TSBPDFPublicKeySignatureType;

#ifdef SB_USE_CLASS_TELPDFPASSWORDSECURITYHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_Reset(TElPDFPasswordSecurityHandlerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_IsUserPasswordValid(TElPDFPasswordSecurityHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_IsOwnerPasswordValid(TElPDFPasswordSecurityHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_GetName(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_GetName_1(TElPDFPasswordSecurityHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_GetDescription(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_GetDescription_1(TElPDFPasswordSecurityHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_get_UserPassword(TElPDFPasswordSecurityHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_set_UserPassword(TElPDFPasswordSecurityHandlerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_get_OwnerPassword(TElPDFPasswordSecurityHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_set_OwnerPassword(TElPDFPasswordSecurityHandlerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_get_Permissions(TElPDFPasswordSecurityHandlerHandle _Handle, TElPDFPermissionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_get_RevisionNumber(TElPDFPasswordSecurityHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_set_RevisionNumber(TElPDFPasswordSecurityHandlerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPasswordSecurityHandler_Create(TComponentHandle Owner, TElPDFSecurityHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFPASSWORDSECURITYHANDLER */

#ifdef SB_USE_CLASS_TELPDFPUBLICKEYSECURITYHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_Reset(TElPDFPublicKeySecurityHandlerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_AddRecipientGroup(TElPDFPublicKeySecurityHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_RemoveRecipientGroup(TElPDFPublicKeySecurityHandlerHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_ClearRecipientGroups(TElPDFPublicKeySecurityHandlerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_GetName(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_GetName_1(TElPDFPublicKeySecurityHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_GetDescription(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_GetDescription_1(TElPDFPublicKeySecurityHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_GetSignerCertificate(TElPDFPublicKeySecurityHandlerHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_RecipientGroups(TElPDFPublicKeySecurityHandlerHandle _Handle, int32_t Index, TElPDFPublicKeyRecipientGroupHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_CertIDs(TElPDFPublicKeySecurityHandlerHandle _Handle, int32_t Index, TElPKCS7IssuerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_Timestamps(TElPDFPublicKeySecurityHandlerHandle _Handle, int32_t Index, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_RecipientGroupCount(TElPDFPublicKeySecurityHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_CertStorage(TElPDFPublicKeySecurityHandlerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_set_CertStorage(TElPDFPublicKeySecurityHandlerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_Certificates(TElPDFPublicKeySecurityHandlerHandle _Handle, TElMemoryCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_SignatureType(TElPDFPublicKeySecurityHandlerHandle _Handle, TSBPDFPublicKeySignatureTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_set_SignatureType(TElPDFPublicKeySecurityHandlerHandle _Handle, TSBPDFPublicKeySignatureTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_HashAlgorithm(TElPDFPublicKeySecurityHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_set_HashAlgorithm(TElPDFPublicKeySecurityHandlerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_Detached(TElPDFPublicKeySecurityHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_set_Detached(TElPDFPublicKeySecurityHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_CertIDCount(TElPDFPublicKeySecurityHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_TimestampCount(TElPDFPublicKeySecurityHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_RevocationInfo(TElPDFPublicKeySecurityHandlerHandle _Handle, TElPDFPublicKeyRevocationInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_LastValidationResult(TElPDFPublicKeySecurityHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_SignatureContents(TElPDFPublicKeySecurityHandlerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_TSPClient(TElPDFPublicKeySecurityHandlerHandle _Handle, TElCustomTSPClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_set_TSPClient(TElPDFPublicKeySecurityHandlerHandle _Handle, TElCustomTSPClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_get_IgnoreTimestampFailure(TElPDFPublicKeySecurityHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_set_IgnoreTimestampFailure(TElPDFPublicKeySecurityHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeySecurityHandler_Create(TComponentHandle Owner, TElPDFSecurityHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFPUBLICKEYSECURITYHANDLER */

#ifdef SB_USE_CLASS_TELPDFPUBLICKEYRECIPIENTGROUP
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRecipientGroup_AddRecipient(TElPDFPublicKeyRecipientGroupHandle _Handle, TElX509CertificateHandle Cert, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRecipientGroup_RemoveRecipient(TElPDFPublicKeyRecipientGroupHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRecipientGroup_ClearRecipients(TElPDFPublicKeyRecipientGroupHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRecipientGroup_get_Recipients(TElPDFPublicKeyRecipientGroupHandle _Handle, int32_t Index, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRecipientGroup_get_RecipientInfos(TElPDFPublicKeyRecipientGroupHandle _Handle, int32_t Index, TElPKCS7IssuerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRecipientGroup_get_RecipientCount(TElPDFPublicKeyRecipientGroupHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRecipientGroup_get_RecipientInfoCount(TElPDFPublicKeyRecipientGroupHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRecipientGroup_get_KeyEncryptionAlgorithm(TElPDFPublicKeyRecipientGroupHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRecipientGroup_set_KeyEncryptionAlgorithm(TElPDFPublicKeyRecipientGroupHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRecipientGroup_get_Permissions(TElPDFPublicKeyRecipientGroupHandle _Handle, TElPDFPermissionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRecipientGroup_Create(TElPDFPublicKeyRecipientGroupHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPublicKeyRecipientGroup_Create_1(TElPKCS7MessageHandle Msg, TElPDFPublicKeySecurityHandlerHandle Owner, TElPDFPublicKeyRecipientGroupHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFPUBLICKEYRECIPIENTGROUP */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPDFPasswordSecurityHandler_ce_ptr;
extern zend_class_entry *TElPDFPublicKeySecurityHandler_ce_ptr;
extern zend_class_entry *TElPDFPublicKeyRecipientGroup_ce_ptr;

void Register_TElPDFPasswordSecurityHandler(TSRMLS_D);
void Register_TElPDFPublicKeySecurityHandler(TSRMLS_D);
void Register_TElPDFPublicKeyRecipientGroup(TSRMLS_D);
void Register_SBPDFSecurity_Constants(int module_number TSRMLS_DC);
void Register_SBPDFSecurity_Enum_Flags(TSRMLS_D);
void Register_SBPDFSecurity_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPDFSECURITY */

