#ifndef __INC_SBPDFUTILS
#define __INC_SBPDFUTILS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_PREDICTOR_NONE 	1
#define SB_PREDICTOR_PNG_UP 	12

typedef TElClassHandle TElPDFPermissionsHandle;

typedef TElPDFPermissionsHandle ElPDFPermissionsHandle;

#ifdef SB_USE_CLASS_TELPDFPERMISSIONS
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_Load(TElPDFPermissionsHandle _Handle, uint32_t Value, int32_t Revision);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_Save(TElPDFPermissionsHandle _Handle, int32_t Revision, int8_t PubKeyHandler, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_DisableAll(TElPDFPermissionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_EnableAll(TElPDFPermissionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_get_Modify(TElPDFPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_set_Modify(TElPDFPermissionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_get_Extract(TElPDFPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_set_Extract(TElPDFPermissionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_get_Annotations(TElPDFPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_set_Annotations(TElPDFPermissionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_get_FillInForms(TElPDFPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_set_FillInForms(TElPDFPermissionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_get_ExtractAcc(TElPDFPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_set_ExtractAcc(TElPDFPermissionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_get_Assemble(TElPDFPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_set_Assemble(TElPDFPermissionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_get_LowQualityPrint(TElPDFPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_set_LowQualityPrint(TElPDFPermissionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_get_HighQualityPrint(TElPDFPermissionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_set_HighQualityPrint(TElPDFPermissionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPDFPermissions_Create(TElPDFPermissionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELPDFPERMISSIONS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPDFPermissions_ce_ptr;

void Register_TElPDFPermissions(TSRMLS_D);
SB_PHP_FUNCTION(SBPDFUtils, IntToByteArray);
SB_PHP_FUNCTION(SBPDFUtils, UIntToByteArray);
SB_PHP_FUNCTION(SBPDFUtils, IsPNGPredictor);
SB_PHP_FUNCTION(SBPDFUtils, DecodePNG);
SB_PHP_FUNCTION(SBPDFUtils, TrimArray);
void Register_SBPDFUtils_Constants(int module_number TSRMLS_DC);
void Register_SBPDFUtils_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_PDFUTILS
SB_IMPORT uint32_t SB_APIENTRY SBPDFUtils_IntToByteArray(int32_t Value, int8_t LittleEndian, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPDFUtils_UIntToByteArray(uint32_t Value, int8_t LittleEndian, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPDFUtils_IsPNGPredictor(int32_t Value, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPDFUtils_DecodePNG(const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, int32_t Cols, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPDFUtils_TrimArray(uint8_t pa[], int32_t * sza);
#endif /* SB_USE_GLOBAL_PROCS_PDFUTILS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPDFUTILS */

