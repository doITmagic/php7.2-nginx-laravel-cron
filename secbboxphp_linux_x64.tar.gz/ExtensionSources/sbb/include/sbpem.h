#ifndef __INC_SBPEM
#define __INC_SBPEM

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbencoding.h"
#include "sbsymmetriccrypto.h"
#include "sbhashfunction.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_PEM_DECODE_RESULT_OK 	0
#define SB_PEM_DECODE_RESULT_INVALID_FORMAT 	7425
#define SB_PEM_DECODE_RESULT_INVALID_PASSPHRASE 	7426
#define SB_PEM_DECODE_RESULT_NOT_ENOUGH_SPACE 	7427
#define SB_PEM_DECODE_RESULT_UNKNOWN_CIPHER 	7428

typedef TElClassHandle TElPEMProcessorHandle;

#ifdef SB_USE_CLASS_TELPEMPROCESSOR
SB_IMPORT uint32_t SB_APIENTRY TElPEMProcessor_PEMEncode(TElPEMProcessorHandle _Handle, const uint8_t pInBuffer[], int32_t szInBuffer, uint8_t pOutBuffer[], int32_t * szOutBuffer, int8_t Encrypt, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPEMProcessor_PEMEncode_1(TElPEMProcessorHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int8_t Encrypt, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPEMProcessor_PEMDecode(TElPEMProcessorHandle _Handle, const uint8_t pInBuffer[], int32_t szInBuffer, uint8_t pOutBuffer[], int32_t * szOutBuffer, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPEMProcessor_PEMDecode_1(TElPEMProcessorHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPEMProcessor_get_Header(TElPEMProcessorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPEMProcessor_set_Header(TElPEMProcessorHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPEMProcessor_get_Passphrase(TElPEMProcessorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPEMProcessor_set_Passphrase(TElPEMProcessorHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPEMProcessor_get_EncryptionAlgorithm(TElPEMProcessorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPEMProcessor_set_EncryptionAlgorithm(TElPEMProcessorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPEMProcessor_get_EncryptionMode(TElPEMProcessorHandle _Handle, TSBSymmetricCryptoModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPEMProcessor_set_EncryptionMode(TElPEMProcessorHandle _Handle, TSBSymmetricCryptoModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPEMProcessor_Create(TComponentHandle AOwner, TElPEMProcessorHandle * OutResult);
#endif /* SB_USE_CLASS_TELPEMPROCESSOR */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPEMProcessor_ce_ptr;

void Register_TElPEMProcessor(TSRMLS_D);
SB_PHP_FUNCTION(SBPEM, Encode);
SB_PHP_FUNCTION(SBPEM, EncodeEx);
SB_PHP_FUNCTION(SBPEM, Decode);
SB_PHP_FUNCTION(SBPEM, IsBase64UnicodeSequence);
SB_PHP_FUNCTION(SBPEM, IsBase64Sequence);
SB_PHP_FUNCTION(SBPEM, IsPEMSequence);
SB_PHP_FUNCTION(SBPEM, RaisePEMError);
void Register_SBPEM_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_PEM
SB_IMPORT uint32_t SB_APIENTRY SBPEM_Encode(void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, const char * pcHeader, int32_t szHeader, int8_t Encrypt, const char * pcPassPhrase, int32_t szPassPhrase, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPEM_EncodeEx(void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, const char * pcHeader, int32_t szHeader, int32_t EncryptionAlgorithm, const char * pcPassPhrase, int32_t szPassPhrase, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPEM_EncodeEx_1(void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, const char * pcHeader, int32_t szHeader, int32_t EncryptionAlgorithm, TSBSymmetricCryptoModeRaw EncryptionMode, const char * pcPassPhrase, int32_t szPassPhrase, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPEM_Decode(void * InBuffer, int32_t InSize, void * OutBuffer, const char * pcPassPhrase, int32_t szPassPhrase, int32_t * OutSize, char * pcHeader, int32_t * szHeader, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPEM_IsBase64UnicodeSequence(void * Buffer, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPEM_IsBase64Sequence(void * Buffer, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPEM_IsPEMSequence(void * Buffer, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPEM_RaisePEMError(int32_t ErrorCode);
#endif /* SB_USE_GLOBAL_PROCS_PEM */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPEM */

