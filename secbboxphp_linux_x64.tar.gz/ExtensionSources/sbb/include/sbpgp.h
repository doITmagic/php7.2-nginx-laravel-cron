#ifndef __INC_SBPGP
#define __INC_SBPGP

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbpgpkeys.h"
#include "sbpgpstreams.h"
#include "sbpgpconstants.h"
#include "sbpgpentities.h"
#include "sbpgputils.h"
#include "sbpgpmd.h"
#include "sbhashfunction.h"
#include "sbdiskfsadapter.h"
#include "sbcustomfsadapter.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElPGPWriterHandle;

typedef TElPGPWriterHandle ElPGPWriterHandle;

typedef TElClassHandle TElPGPProcessingUnitHandle;

typedef TElPGPProcessingUnitHandle ElPGPProcessingUnitHandle;

typedef TElClassHandle TElPGPReaderHandle;

typedef TElPGPReaderHandle ElPGPReaderHandle;

typedef uint8_t TSBPGPEncryptionTypeRaw;

typedef enum
{
	etPublicKey = 0,
	etPassphrase = 1,
	etBoth = 2
} TSBPGPEncryptionType;

typedef uint8_t TSBPGPProcessingUnitStateRaw;

typedef enum
{
	usPreSignaturePackets = 0,
	usData = 1,
	usPostSignaturePackets = 2
} TSBPGPProcessingUnitState;

typedef void (SB_CALLBACK *TSBPGPProgressEvent)(void * _ObjectData, TObjectHandle Sender, int64_t Processed, int64_t Total, int8_t * Cancel);

typedef uint8_t TSBPGPSignBufferingMethodRaw;

typedef enum
{
	sbmTemporaryStream = 0,
	sbmRewind = 1
} TSBPGPSignBufferingMethod;

typedef uint8_t TSBPGPMemoryConsumptionStrategyRaw;

typedef enum
{
	mcsDefault = 0,
	mcsGreedy = 1
} TSBPGPMemoryConsumptionStrategy;

#ifdef SB_WINDOWS
typedef uint8_t TSBPGPStubSourceRaw;

typedef enum
{
	ssStream = 0,
	ssFile = 1,
	ssResource = 2
} TSBPGPStubSource;
#endif

typedef void (SB_CALLBACK *TSBPGPNewStreamEvent)(void * _ObjectData, TObjectHandle Sender, TElPGPStreamHandle Stream, int8_t * Atomic);

typedef void (SB_CALLBACK *TSBPGPSignatureEntityEvent)(void * _ObjectData, TObjectHandle Sender, TElPGPSignatureEntityHandle Sig);

typedef void (SB_CALLBACK *TSBPGPHashAlgorithmEvent)(void * _ObjectData, TObjectHandle Sender, int32_t HashAlg, int32_t SigClass);

#ifdef SB_WINDOWS
typedef void (SB_CALLBACK *TSBPGPGetStubStreamEvent)(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream, int8_t * FreeStub);
#endif

typedef void (SB_CALLBACK *TSBPGPMultipleFilesFoundEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcTarFilename, int32_t szTarFilename, int8_t * ExtractFiles);

typedef void (SB_CALLBACK *TSBPGPRequestOutputFileEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcFilename, int32_t szFilename, int64_t TimeStamp, char * pcPath, int32_t * szPath);

typedef void (SB_CALLBACK *TSBPGPCreateOutputStreamEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcFilename, int32_t szFilename, int64_t TimeStamp, TStreamHandle * Stream, int8_t * FreeOnExit);

typedef void (SB_CALLBACK *TSBPGPFileExtractionStartEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcFilename, int32_t szFilename, int64_t TimeStamp);

typedef void (SB_CALLBACK *TSBPGPEncryptedEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pKeyIDs[][8], int32_t szKeyIDs, int8_t IntegrityProtected, int8_t PassphraseUsed);

typedef TNotifyEvent TSBPGPCompressedEvent;

typedef void (SB_CALLBACK *TSBPGPArmoredEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcBoundary, int32_t szBoundary, TStringListHandle Headers);

typedef void (SB_CALLBACK *TSBPGPSignedEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pKeyIDs[][8], int32_t szKeyIDs, TSBPGPSignatureTypeRaw SignatureType);

#ifdef SB_USE_CLASS_TELPGPWRITER
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_EncryptFile(TElPGPWriterHandle _Handle, const char * pcASourceFile, int32_t szASourceFile, const char * pcADestFile, int32_t szADestFile);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_SignFile(TElPGPWriterHandle _Handle, const char * pcASourceFile, int32_t szASourceFile, const char * pcADestFile, int32_t szADestFile, int8_t Detached);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_EncryptAndSignFile(TElPGPWriterHandle _Handle, const char * pcASourceFile, int32_t szASourceFile, const char * pcADestFile, int32_t szADestFile);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_ClearTextSignFile(TElPGPWriterHandle _Handle, const char * pcASourceFile, int32_t szASourceFile, const char * pcADestFile, int32_t szADestFile);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_Encrypt(TElPGPWriterHandle _Handle, TStreamHandle ASourceStream, TStreamHandle ADestStream, int64_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_Sign(TElPGPWriterHandle _Handle, TStreamHandle ASourceStream, TStreamHandle ADestStream, int8_t Detached, int64_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_EncryptAndSign(TElPGPWriterHandle _Handle, TStreamHandle ASourceStream, TStreamHandle ADestStream, int64_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_ClearTextSign(TElPGPWriterHandle _Handle, TStreamHandle ASourceStream, TStreamHandle ADestStream, int64_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_EncryptFiles(TElPGPWriterHandle _Handle, TStringListHandle SourceFileNames, TListHandle SourceStreams, const char * pcADestFileName, int32_t szADestFileName, TStreamHandle ADestStream);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_SignFiles(TElPGPWriterHandle _Handle, TStringListHandle SourceFileNames, TListHandle SourceStreams, const char * pcADestFileName, int32_t szADestFileName, TStreamHandle ADestStream);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_EncryptAndSignFiles(TElPGPWriterHandle _Handle, TStringListHandle SourceFileNames, TListHandle SourceStreams, const char * pcADestFileName, int32_t szADestFileName, TStreamHandle ADestStream);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_Timestamp(TElPGPWriterHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_Timestamp(TElPGPWriterHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_Armor(TElPGPWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_Armor(TElPGPWriterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_EncryptionType(TElPGPWriterHandle _Handle, TSBPGPEncryptionTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_EncryptionType(TElPGPWriterHandle _Handle, TSBPGPEncryptionTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_Compress(TElPGPWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_Compress(TElPGPWriterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_CompressionAlgorithm(TElPGPWriterHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_CompressionAlgorithm(TElPGPWriterHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_CompressionLevel(TElPGPWriterHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_CompressionLevel(TElPGPWriterHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_ArmorBoundary(TElPGPWriterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_ArmorBoundary(TElPGPWriterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_ArmorHeaders(TElPGPWriterHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_Filename(TElPGPWriterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_Filename(TElPGPWriterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_SigningKeys(TElPGPWriterHandle _Handle, TElPGPKeyringHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_SigningKeys(TElPGPWriterHandle _Handle, TElPGPKeyringHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_EncryptingKeys(TElPGPWriterHandle _Handle, TElPGPKeyringHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_EncryptingKeys(TElPGPWriterHandle _Handle, TElPGPKeyringHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_HashAlgorithm(TElPGPWriterHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_HashAlgorithm(TElPGPWriterHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_Passphrases(TElPGPWriterHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_Protection(TElPGPWriterHandle _Handle, TSBPGPProtectionTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_Protection(TElPGPWriterHandle _Handle, TSBPGPProtectionTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_SymmetricKeyAlgorithm(TElPGPWriterHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_SymmetricKeyAlgorithm(TElPGPWriterHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_SignBufferingMethod(TElPGPWriterHandle _Handle, TSBPGPSignBufferingMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_SignBufferingMethod(TElPGPWriterHandle _Handle, TSBPGPSignBufferingMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_UseOldPackets(TElPGPWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_UseOldPackets(TElPGPWriterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_UseNewFeatures(TElPGPWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_UseNewFeatures(TElPGPWriterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_InputIsText(TElPGPWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_InputIsText(TElPGPWriterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_TextCompatibilityMode(TElPGPWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_TextCompatibilityMode(TElPGPWriterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_UndefInputLength(TElPGPWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_UndefInputLength(TElPGPWriterHandle _Handle, int8_t Value);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_SFXCopyright(TElPGPWriterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_SFXCopyright(TElPGPWriterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_SFXEnabled(TElPGPWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_SFXEnabled(TElPGPWriterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_SFXTitle(TElPGPWriterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_SFXTitle(TElPGPWriterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_StubName(TElPGPWriterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_StubName(TElPGPWriterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_StubSource(TElPGPWriterHandle _Handle, TSBPGPStubSourceRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_StubSource(TElPGPWriterHandle _Handle, TSBPGPStubSourceRaw Value);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_PreserveFilePaths(TElPGPWriterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_PreserveFilePaths(TElPGPWriterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_FileSystemAdapter(TElPGPWriterHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_FileSystemAdapter(TElPGPWriterHandle _Handle, TElCustomFileSystemAdapterHandle Value);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_OnGetStubStream(TElPGPWriterHandle _Handle, TSBPGPGetStubStreamEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_OnGetStubStream(TElPGPWriterHandle _Handle, TSBPGPGetStubStreamEvent pMethodValue, void * pDataValue);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_OnKeyPassphrase(TElPGPWriterHandle _Handle, TSBPGPKeyPassphraseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_OnKeyPassphrase(TElPGPWriterHandle _Handle, TSBPGPKeyPassphraseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_OnProgress(TElPGPWriterHandle _Handle, TSBPGPProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_OnProgress(TElPGPWriterHandle _Handle, TSBPGPProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_get_OnTemporaryStream(TElPGPWriterHandle _Handle, TSBPGPTemporaryStreamEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_set_OnTemporaryStream(TElPGPWriterHandle _Handle, TSBPGPTemporaryStreamEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPWriter_Create(TComponentHandle AOwner, TElPGPWriterHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPWRITER */

#ifdef SB_USE_CLASS_TELPGPPROCESSINGUNIT
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_Read(TElPGPProcessingUnitHandle _Handle, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_Write(TElPGPProcessingUnitHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_NFinalize(TElPGPProcessingUnitHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_get_Atomic(TElPGPProcessingUnitHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_get_Finished(TElPGPProcessingUnitHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_get_Stream(TElPGPProcessingUnitHandle _Handle, TElPGPStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_get_Prev(TElPGPProcessingUnitHandle _Handle, TElPGPProcessingUnitHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_get_SkippedLength(TElPGPProcessingUnitHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_get_ProcessedLength(TElPGPProcessingUnitHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_get_InputEncoding(TElPGPProcessingUnitHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_set_InputEncoding(TElPGPProcessingUnitHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_get_IgnoreDataPacketLengths(TElPGPProcessingUnitHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_set_IgnoreDataPacketLengths(TElPGPProcessingUnitHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_get_OnNewStream(TElPGPProcessingUnitHandle _Handle, TSBPGPNewStreamEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_set_OnNewStream(TElPGPProcessingUnitHandle _Handle, TSBPGPNewStreamEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_get_OnFinish(TElPGPProcessingUnitHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_set_OnFinish(TElPGPProcessingUnitHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_get_OnSignature(TElPGPProcessingUnitHandle _Handle, TSBPGPSignatureEntityEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_set_OnSignature(TElPGPProcessingUnitHandle _Handle, TSBPGPSignatureEntityEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_get_OnHashAlgorithm(TElPGPProcessingUnitHandle _Handle, TSBPGPHashAlgorithmEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_set_OnHashAlgorithm(TElPGPProcessingUnitHandle _Handle, TSBPGPHashAlgorithmEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPProcessingUnit_Create(TElPGPProcessingUnitHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPPROCESSINGUNIT */

#ifdef SB_USE_CLASS_TELPGPREADER
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_DecryptAndVerifyFile(TElPGPReaderHandle _Handle, const char * pcASourceFile, int32_t szASourceFile);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_VerifyDetachedFile(TElPGPReaderHandle _Handle, const char * pcASourceFile, int32_t szASourceFile, const char * pcASignatureFile, int32_t szASignatureFile);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_DecryptAndVerify(TElPGPReaderHandle _Handle, TStreamHandle ASourceStream, int64_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_VerifyDetached(TElPGPReaderHandle _Handle, TStreamHandle ASourceStream, TStreamHandle ASignatureStream, int64_t SourceStreamCount, int64_t SignatureStreamCount);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_EncryptionAlgorithm(TElPGPReaderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_CompressionAlgorithm(TElPGPReaderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_Protection(TElPGPReaderHandle _Handle, TSBPGPProtectionTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_ProcessedLength(TElPGPReaderHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OutputStream(TElPGPReaderHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OutputStream(TElPGPReaderHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_DecryptingKeys(TElPGPReaderHandle _Handle, TElPGPKeyringHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_DecryptingKeys(TElPGPReaderHandle _Handle, TElPGPKeyringHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_VerifyingKeys(TElPGPReaderHandle _Handle, TElPGPKeyringHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_VerifyingKeys(TElPGPReaderHandle _Handle, TElPGPKeyringHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OutputFile(TElPGPReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OutputFile(TElPGPReaderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_Passphrase(TElPGPReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_Passphrase(TElPGPReaderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_KeyPassphrase(TElPGPReaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_KeyPassphrase(TElPGPReaderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_MemoryConsumptionStrategy(TElPGPReaderHandle _Handle, TSBPGPMemoryConsumptionStrategyRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_MemoryConsumptionStrategy(TElPGPReaderHandle _Handle, TSBPGPMemoryConsumptionStrategyRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_FileSystemAdapter(TElPGPReaderHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_FileSystemAdapter(TElPGPReaderHandle _Handle, TElCustomFileSystemAdapterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_IgnoreDataPacketLengths(TElPGPReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_IgnoreDataPacketLengths(TElPGPReaderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_UndefInputLength(TElPGPReaderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_UndefInputLength(TElPGPReaderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OnArmored(TElPGPReaderHandle _Handle, TSBPGPArmoredEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OnArmored(TElPGPReaderHandle _Handle, TSBPGPArmoredEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OnCompressed(TElPGPReaderHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OnCompressed(TElPGPReaderHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OnEncrypted(TElPGPReaderHandle _Handle, TSBPGPEncryptedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OnEncrypted(TElPGPReaderHandle _Handle, TSBPGPEncryptedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OnCreateOutputStream(TElPGPReaderHandle _Handle, TSBPGPCreateOutputStreamEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OnCreateOutputStream(TElPGPReaderHandle _Handle, TSBPGPCreateOutputStreamEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OnRequestOutputFile(TElPGPReaderHandle _Handle, TSBPGPRequestOutputFileEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OnRequestOutputFile(TElPGPReaderHandle _Handle, TSBPGPRequestOutputFileEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OnKeyPassphrase(TElPGPReaderHandle _Handle, TSBPGPKeyPassphraseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OnKeyPassphrase(TElPGPReaderHandle _Handle, TSBPGPKeyPassphraseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OnPassphrase(TElPGPReaderHandle _Handle, TSBPGPPassphraseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OnPassphrase(TElPGPReaderHandle _Handle, TSBPGPPassphraseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OnProgress(TElPGPReaderHandle _Handle, TSBPGPProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OnProgress(TElPGPReaderHandle _Handle, TSBPGPProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OnSigned(TElPGPReaderHandle _Handle, TSBPGPSignedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OnSigned(TElPGPReaderHandle _Handle, TSBPGPSignedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OnSignatures(TElPGPReaderHandle _Handle, TSBPGPSignaturesEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OnSignatures(TElPGPReaderHandle _Handle, TSBPGPSignaturesEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OnFileExtractionStart(TElPGPReaderHandle _Handle, TSBPGPFileExtractionStartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OnFileExtractionStart(TElPGPReaderHandle _Handle, TSBPGPFileExtractionStartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OnMultipleFilesFound(TElPGPReaderHandle _Handle, TSBPGPMultipleFilesFoundEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OnMultipleFilesFound(TElPGPReaderHandle _Handle, TSBPGPMultipleFilesFoundEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_get_OnTemporaryStream(TElPGPReaderHandle _Handle, TSBPGPTemporaryStreamEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_set_OnTemporaryStream(TElPGPReaderHandle _Handle, TSBPGPTemporaryStreamEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPReader_Create(TComponentHandle AOwner, TElPGPReaderHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPREADER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPGPWriter_ce_ptr;
extern zend_class_entry *TElPGPProcessingUnit_ce_ptr;
extern zend_class_entry *TElPGPReader_ce_ptr;

void SB_CALLBACK TSBPGPProgressEventRaw(void * _ObjectData, TObjectHandle Sender, int64_t Processed, int64_t Total, int8_t * Cancel);
void SB_CALLBACK TSBPGPNewStreamEventRaw(void * _ObjectData, TObjectHandle Sender, TElPGPStreamHandle Stream, int8_t * Atomic);
void SB_CALLBACK TSBPGPSignatureEntityEventRaw(void * _ObjectData, TObjectHandle Sender, TElPGPSignatureEntityHandle Sig);
void SB_CALLBACK TSBPGPHashAlgorithmEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t HashAlg, int32_t SigClass);
#ifdef SB_WINDOWS
void SB_CALLBACK TSBPGPGetStubStreamEventRaw(void * _ObjectData, TObjectHandle Sender, TStreamHandle * Stream, int8_t * FreeStub);
#endif
void SB_CALLBACK TSBPGPMultipleFilesFoundEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcTarFilename, int32_t szTarFilename, int8_t * ExtractFiles);
void SB_CALLBACK TSBPGPRequestOutputFileEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcFilename, int32_t szFilename, int64_t TimeStamp, char * pcPath, int32_t * szPath);
void SB_CALLBACK TSBPGPCreateOutputStreamEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcFilename, int32_t szFilename, int64_t TimeStamp, TStreamHandle * Stream, int8_t * FreeOnExit);
void SB_CALLBACK TSBPGPFileExtractionStartEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcFilename, int32_t szFilename, int64_t TimeStamp);
void SB_CALLBACK TSBPGPEncryptedEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pKeyIDs[][8], int32_t szKeyIDs, int8_t IntegrityProtected, int8_t PassphraseUsed);
void SB_CALLBACK TSBPGPArmoredEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcBoundary, int32_t szBoundary, TStringListHandle Headers);
void SB_CALLBACK TSBPGPSignedEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pKeyIDs[][8], int32_t szKeyIDs, TSBPGPSignatureTypeRaw SignatureType);
void Register_TElPGPWriter(TSRMLS_D);
void Register_TElPGPProcessingUnit(TSRMLS_D);
void Register_TElPGPReader(TSRMLS_D);
void Register_SBPGP_Enum_Flags(TSRMLS_D);
void Register_SBPGP_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPGP */
