#ifndef __INC_SBPGPKEYS
#define __INC_SBPGPKEYS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbpgpentities.h"
#include "sbpgpexceptions.h"
#include "sbpgpconstants.h"
#include "sbpgputils.h"
#include "sbsharedresource.h"
#include "sbpgpmd.h"
#include "sbmath.h"
#include "sbrandom.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbencoding.h"
#include "sbsymmetriccrypto.h"
#include "sbx509.h"
#include "sbpublickeycrypto.h"
#include "sbhashfunction.h"
#include "sbstreams.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElPGPCustomPublicKeyHandle;

typedef TElPGPCustomPublicKeyHandle ElPGPCustomPublicKeyHandle;

typedef TElClassHandle TElPGPPublicSubkeyHandle;

typedef TElPGPPublicSubkeyHandle ElPGPPublicSubkeyHandle;

typedef TElClassHandle TElPGPPublicKeyHandle;

typedef TElPGPPublicKeyHandle ElPGPPublicKeyHandle;

typedef TElClassHandle TElPGPCustomSecretKeyHandle;

typedef TElPGPCustomSecretKeyHandle ElPGPCustomSecretKeyHandle;

typedef TElClassHandle TElPGPSecretSubkeyHandle;

typedef TElPGPSecretSubkeyHandle ElPGPSecretSubkeyHandle;

typedef TElClassHandle TElPGPSecretKeyHandle;

typedef TElPGPSecretKeyHandle ElPGPSecretKeyHandle;

typedef TElClassHandle TElPGPTrustHandle;

typedef TElPGPTrustHandle ElPGPTrustHandle;

typedef TElClassHandle TElPGPSignatureHandle;

typedef TElPGPSignatureHandle ElPGPSignatureHandle;

typedef TElClassHandle TElPGPCustomUserHandle;

typedef TElPGPCustomUserHandle ElPGPCustomUserHandle;

typedef TElClassHandle TElPGPUserIDHandle;

typedef TElPGPUserIDHandle ElPGPUserIDHandle;

typedef TElClassHandle TElPGPUserAttrHandle;

typedef TElPGPUserAttrHandle ElPGPUserAttrHandle;

typedef TElClassHandle TElPGPKeyringHandle;

typedef TElPGPKeyringHandle ElPGPKeyringHandle;

typedef TElClassHandle TElPGPJpegImageHandle;

typedef uint8_t TSBPGPUserCertificationTypeRaw;

typedef enum
{
	ctGeneric = 0,
	ctPersona = 1,
	ctCasual = 2,
	ctPositive = 3
} TSBPGPUserCertificationType;

typedef uint8_t TSBPGPKeyTrustRaw;

typedef enum
{
	ktUndefined = 0,
	ktNone = 1,
	ktMarginal = 2,
	ktTrusted = 3,
	ktImplicit = 4
} TSBPGPKeyTrust;

typedef void (SB_CALLBACK *TSBPGPPasswordEvent)(void * _ObjectData, TObjectHandle Sender, void * UserData, char * pcRes, int32_t * szRes);

typedef void (SB_CALLBACK *TSBPGPBeforeSignEvent)(void * _ObjectData, TObjectHandle Sender, TElPGPSignatureHandle Signature, TObjectHandle Subject);

#ifdef SB_USE_CLASS_TELPGPCUSTOMPUBLICKEY
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_Assign(TElPGPCustomPublicKeyHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_AssignTo(TElPGPCustomPublicKeyHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_AddSignature(TElPGPCustomPublicKeyHandle _Handle, TElPGPSignatureHandle Signature, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_RemoveSignature(TElPGPCustomPublicKeyHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_RemoveSignature_1(TElPGPCustomPublicKeyHandle _Handle, TElPGPSignatureHandle Signature, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_ClearSignatures(TElPGPCustomPublicKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_Verify(TElPGPCustomPublicKeyHandle _Handle, TElPGPCustomPublicKeyHandle PublicKey, TElPGPCustomUserHandle User, TElPGPSignatureHandle Signature, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_Verify_1(TElPGPCustomPublicKeyHandle _Handle, TElPGPCustomPublicKeyHandle Key, TElPGPSignatureHandle Signature, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_Verify_2(TElPGPCustomPublicKeyHandle _Handle, TElHashFunctionHandle HashFunction, TElPGPSignatureHandle Signature, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_Verify_3(TElPGPCustomPublicKeyHandle _Handle, TElPGPSignatureHandle Signature, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_Verify_4(TElPGPCustomPublicKeyHandle _Handle, TElPGPSignatureHandle SubjectSignature, TElPGPSignatureHandle Signature, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_DirectVerify(TElPGPCustomPublicKeyHandle _Handle, TElPGPCustomPublicKeyHandle Key, TElPGPSignatureHandle Signature, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_RevocationVerify(TElPGPCustomPublicKeyHandle _Handle, TElPGPCustomPublicKeyHandle Key, TElPGPSignatureHandle Signature, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_RevocationVerify_1(TElPGPCustomPublicKeyHandle _Handle, TElPGPCustomPublicKeyHandle Key, TElPGPCustomUserHandle User, TElPGPSignatureHandle Signature, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_DirectRevocationVerify(TElPGPCustomPublicKeyHandle _Handle, TElPGPCustomPublicKeyHandle Key, TElPGPSignatureHandle Signature, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_ExportKeyMaterial(TElPGPCustomPublicKeyHandle _Handle, TElPublicKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_ImportKeyMaterial(TElPGPCustomPublicKeyHandle _Handle, TElPublicKeyMaterialHandle KeyMaterial);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_ImportKeyMaterial_1(TElPGPCustomPublicKeyHandle _Handle, TElPublicKeyMaterialHandle KeyMaterial, int64_t Timestamp, int32_t KeyVersion, int32_t Expires);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_Encrypt(TElPGPCustomPublicKeyHandle _Handle, const uint8_t pData[], int32_t szData, TSBPGPEncryptedSymmetricKey * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_IsSigningKey(TElPGPCustomPublicKeyHandle _Handle, int8_t WithSubkeys, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_IsEncryptingKey(TElPGPCustomPublicKeyHandle _Handle, int8_t WithSubkeys, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_PrepareForEncryption(TElPGPCustomPublicKeyHandle _Handle, int8_t MultiUse);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_CancelPreparation(TElPGPCustomPublicKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_AsyncOperationFinished(TElPGPCustomPublicKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_AcquireLock(TElPGPCustomPublicKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_ReleaseLock(TElPGPCustomPublicKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_KeyID(TElPGPCustomPublicKeyHandle _Handle, TSBKeyID * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_KeyFP(TElPGPCustomPublicKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_get_Timestamp(TElPGPCustomPublicKeyHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_set_Timestamp(TElPGPCustomPublicKeyHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_get_Expires(TElPGPCustomPublicKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_set_Expires(TElPGPCustomPublicKeyHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_get_PublicKeyAlgorithm(TElPGPCustomPublicKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_get_BitsInKey(TElPGPCustomPublicKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_get_KeyHashAlgorithm(TElPGPCustomPublicKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_set_KeyHashAlgorithm(TElPGPCustomPublicKeyHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_get_QBits(TElPGPCustomPublicKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_get_Curve(TElPGPCustomPublicKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_get_Version(TElPGPCustomPublicKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_get_UseOldPackets(TElPGPCustomPublicKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_set_UseOldPackets(TElPGPCustomPublicKeyHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_get_Signatures(TElPGPCustomPublicKeyHandle _Handle, int32_t Index, TElPGPSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_get_SignatureCount(TElPGPCustomPublicKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_get_Revoked(TElPGPCustomPublicKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_get_Enabled(TElPGPCustomPublicKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_set_Enabled(TElPGPCustomPublicKeyHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomPublicKey_Create(TElPGPCustomPublicKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPCUSTOMPUBLICKEY */

#ifdef SB_USE_CLASS_TELPGPPUBLICSUBKEY
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicSubkey_Assign(TElPGPPublicSubkeyHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicSubkey_AssignTo(TElPGPPublicSubkeyHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicSubkey_get_SecretKey(TElPGPPublicSubkeyHandle _Handle, TElPGPSecretSubkeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicSubkey_get_Supkey(TElPGPPublicSubkeyHandle _Handle, TElPGPPublicKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicSubkey_get_Trust(TElPGPPublicSubkeyHandle _Handle, TElPGPTrustHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicSubkey_Create(TElPGPPublicSubkeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPPUBLICSUBKEY */

#ifdef SB_USE_CLASS_TELPGPPUBLICKEY
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_RemoveSubkey(TElPGPPublicKeyHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_RemoveSubkey_1(TElPGPPublicKeyHandle _Handle, TElPGPPublicSubkeyHandle Subkey, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_Assign(TElPGPPublicKeyHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_AssignTo(TElPGPPublicKeyHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_AssignFromX509(TElPGPPublicKeyHandle _Handle, TElX509CertificateHandle Certificate);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_LoadFromStream(TElPGPPublicKeyHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_LoadFromFile(TElPGPPublicKeyHandle _Handle, const char * pcFilename, int32_t szFilename);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_SaveToStream(TElPGPPublicKeyHandle _Handle, TStreamHandle Stream, int8_t Armor);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_SaveToFile(TElPGPPublicKeyHandle _Handle, const char * pcFilename, int32_t szFilename, int8_t Armor);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_AddSubkey(TElPGPPublicKeyHandle _Handle, TElPGPPublicSubkeyHandle Subkey, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_ClearSubkeys(TElPGPPublicKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_AddUserID(TElPGPPublicKeyHandle _Handle, TElPGPUserIDHandle User, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_AddUserAttr(TElPGPPublicKeyHandle _Handle, TElPGPUserAttrHandle User, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_RemoveUserID(TElPGPPublicKeyHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_RemoveUserID_1(TElPGPPublicKeyHandle _Handle, TElPGPUserIDHandle User, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_RemoveUserAttr(TElPGPPublicKeyHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_RemoveUserAttr_1(TElPGPPublicKeyHandle _Handle, TElPGPUserAttrHandle UserAttr, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_ClearUserIDs(TElPGPPublicKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_ClearUserAttrs(TElPGPPublicKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_PrepareForEncryption(TElPGPPublicKeyHandle _Handle, int8_t MultiUse);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_CancelPreparation(TElPGPPublicKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_AsyncOperationFinished(TElPGPPublicKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_ArmorBoundary(TElPGPPublicKeyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_set_ArmorBoundary(TElPGPPublicKeyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_ArmorHeaders(TElPGPPublicKeyHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_Subkeys(TElPGPPublicKeyHandle _Handle, int32_t Index, TElPGPPublicSubkeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_UserIDs(TElPGPPublicKeyHandle _Handle, int32_t Index, TElPGPUserIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_UserAttrs(TElPGPPublicKeyHandle _Handle, int32_t Index, TElPGPUserAttrHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_PreferredSymAlgs(TElPGPPublicKeyHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_PreferredHashAlgs(TElPGPPublicKeyHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_PreferredComprAlgs(TElPGPPublicKeyHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_SubkeyCount(TElPGPPublicKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_UserIDCount(TElPGPPublicKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_UserAttrCount(TElPGPPublicKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_Trust(TElPGPPublicKeyHandle _Handle, TElPGPTrustHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_KeyTrust(TElPGPPublicKeyHandle _Handle, TSBPGPKeyTrustRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_set_KeyTrust(TElPGPPublicKeyHandle _Handle, TSBPGPKeyTrustRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_SecretKey(TElPGPPublicKeyHandle _Handle, TElPGPSecretKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_WriteOldPrefix(TElPGPPublicKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_set_WriteOldPrefix(TElPGPPublicKeyHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_PreferredSymAlgCount(TElPGPPublicKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_PreferredHashAlgCount(TElPGPPublicKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_get_PreferredComprAlgCount(TElPGPPublicKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPPublicKey_Create(TElPGPPublicKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPPUBLICKEY */

#ifdef SB_USE_CLASS_TELPGPCUSTOMSECRETKEY
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_Assign(TElPGPCustomSecretKeyHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_AssignTo(TElPGPCustomSecretKeyHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_Generate(TElPGPCustomSecretKeyHandle _Handle, const char * pcPassword, int32_t szPassword, int32_t Bits, int32_t Algorithm, int8_t UseOldFormat, int32_t Expires);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_BeginGenerate(TElPGPCustomSecretKeyHandle _Handle, int32_t Bits, int32_t Algorithm);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_EndGenerate(TElPGPCustomSecretKeyHandle _Handle, const char * pcPassword, int32_t szPassword, int8_t UseOldFormat, int32_t Expires);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_CancelGeneration(TElPGPCustomSecretKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_ChangePassphrase(TElPGPCustomSecretKeyHandle _Handle, const char * pcNewPassphrase, int32_t szNewPassphrase, TSBPGPProtectionTypeRaw ProtectionType);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_ChangeProtection(TElPGPCustomSecretKeyHandle _Handle, const char * pcNewPassphrase, int32_t szNewPassphrase, TSBPGPProtectionTypeRaw PrType, int32_t EncAlgorithm, int32_t HshAlgorithm);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_Sign(TElPGPCustomSecretKeyHandle _Handle, TElPGPPublicKeyHandle PublicKey, TElPGPCustomUserHandle User, TElPGPSignatureHandle Signature, TSBPGPUserCertificationTypeRaw CertType);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_Sign_1(TElPGPCustomSecretKeyHandle _Handle, TElPGPCustomPublicKeyHandle Key, TElPGPSignatureHandle Signature, TElPGPSignatureHandle EmbeddedSignature);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_Sign_2(TElPGPCustomSecretKeyHandle _Handle, int64_t TimeStamp, TElPGPSignatureHandle Signature);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_Sign_3(TElPGPCustomSecretKeyHandle _Handle, TElPGPSignatureHandle SubjectSignature, TElPGPSignatureHandle Signature);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_Sign_4(TElPGPCustomSecretKeyHandle _Handle, TElHashFunctionHandle HashFunction, TElPGPSignatureHandle Signature, int32_t SignatureClass);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_DirectSign(TElPGPCustomSecretKeyHandle _Handle, TElPGPCustomPublicKeyHandle Key, TElPGPSignatureHandle Signature);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_Revoke(TElPGPCustomSecretKeyHandle _Handle, TElPGPCustomPublicKeyHandle Key, TElPGPSignatureHandle Signature);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_Revoke_1(TElPGPCustomSecretKeyHandle _Handle, TElPGPPublicKeyHandle Key, TElPGPCustomUserHandle User, TElPGPSignatureHandle Signature, TElPGPSignatureHandle RevokedSignature);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_DirectRevoke(TElPGPCustomSecretKeyHandle _Handle, TElPGPCustomPublicKeyHandle Key, TElPGPSignatureHandle Signature, TElPGPSignatureHandle RevokedSignature);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_Decrypt(TElPGPCustomSecretKeyHandle _Handle, const TSBPGPEncryptedSymmetricKey * EncrData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_PassphraseValid(TElPGPCustomSecretKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_IsSigningKey(TElPGPCustomSecretKeyHandle _Handle, int8_t WithSubkeys, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_IsEncryptingKey(TElPGPCustomSecretKeyHandle _Handle, int8_t WithSubkeys, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_ExportKeyMaterial(TElPGPCustomSecretKeyHandle _Handle, int8_t PublicOnly, TElPublicKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_ExportSecretKeyMaterial(TElPGPCustomSecretKeyHandle _Handle, TElPublicKeyMaterialHandle KeyMaterial);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_ImportKeyMaterial(TElPGPCustomSecretKeyHandle _Handle, TElPublicKeyMaterialHandle KeyMaterial);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_ImportKeyMaterial_1(TElPGPCustomSecretKeyHandle _Handle, TElPublicKeyMaterialHandle SecKeyMaterial, TElPublicKeyMaterialHandle PubKeyMaterial);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_ImportKeyMaterial_2(TElPGPCustomSecretKeyHandle _Handle, TElPublicKeyMaterialHandle KeyMaterial, int64_t Timestamp, int32_t KeyVersion, int32_t Expires);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_ImportKeyMaterial_3(TElPGPCustomSecretKeyHandle _Handle, TElPublicKeyMaterialHandle SecKeyMaterial, TElPublicKeyMaterialHandle PubKeyMaterial, int64_t Timestamp, int32_t KeyVersion, int32_t Expires);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_KeyID(TElPGPCustomSecretKeyHandle _Handle, TSBKeyID * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_KeyFP(TElPGPCustomSecretKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_PrepareForSigning(TElPGPCustomSecretKeyHandle _Handle, int8_t MultiUse);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_CancelPreparation(TElPGPCustomSecretKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_AsyncOperationFinished(TElPGPCustomSecretKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_AcquireLock(TElPGPCustomSecretKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_ReleaseLock(TElPGPCustomSecretKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_UseOldPackets(TElPGPCustomSecretKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_set_UseOldPackets(TElPGPCustomSecretKeyHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_Timestamp(TElPGPCustomSecretKeyHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_set_Timestamp(TElPGPCustomSecretKeyHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_Version(TElPGPCustomSecretKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_Expires(TElPGPCustomSecretKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_set_Expires(TElPGPCustomSecretKeyHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_BitsInKey(TElPGPCustomSecretKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_PublicKeyAlgorithm(TElPGPCustomSecretKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_EncryptionAlgorithm(TElPGPCustomSecretKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_HashAlgorithm(TElPGPCustomSecretKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_KeyHashAlgorithm(TElPGPCustomSecretKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_set_KeyHashAlgorithm(TElPGPCustomSecretKeyHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_QBits(TElPGPCustomSecretKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_set_QBits(TElPGPCustomSecretKeyHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_Curve(TElPGPCustomSecretKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_set_Curve(TElPGPCustomSecretKeyHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_Protection(TElPGPCustomSecretKeyHandle _Handle, TSBPGPProtectionTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_Passphrase(TElPGPCustomSecretKeyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_set_Passphrase(TElPGPCustomSecretKeyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_Trust(TElPGPCustomSecretKeyHandle _Handle, TElPGPTrustHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_get_Enabled(TElPGPCustomSecretKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_set_Enabled(TElPGPCustomSecretKeyHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomSecretKey_Create(TElPGPCustomSecretKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPCUSTOMSECRETKEY */

#ifdef SB_USE_CLASS_TELPGPSECRETSUBKEY
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretSubkey_Assign(TElPGPSecretSubkeyHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretSubkey_AssignTo(TElPGPSecretSubkeyHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretSubkey_get_Supkey(TElPGPSecretSubkeyHandle _Handle, TElPGPSecretKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretSubkey_get_PublicKey(TElPGPSecretSubkeyHandle _Handle, TElPGPPublicSubkeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretSubkey_Create(TElPGPSecretSubkeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPSECRETSUBKEY */

#ifdef SB_USE_CLASS_TELPGPSECRETKEY
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_RemoveSubkey(TElPGPSecretKeyHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_RemoveSubkey_1(TElPGPSecretKeyHandle _Handle, TElPGPSecretSubkeyHandle Subkey, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_Assign(TElPGPSecretKeyHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_AssignTo(TElPGPSecretKeyHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_AssignFromX509(TElPGPSecretKeyHandle _Handle, TElX509CertificateHandle Certificate);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_LoadFromStream(TElPGPSecretKeyHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_LoadFromFile(TElPGPSecretKeyHandle _Handle, const char * pcFilename, int32_t szFilename);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_SaveToStream(TElPGPSecretKeyHandle _Handle, TStreamHandle Stream, int8_t Armor);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_SaveToFile(TElPGPSecretKeyHandle _Handle, const char * pcFilename, int32_t szFilename, int8_t Armor);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_BindUser(TElPGPSecretKeyHandle _Handle, TElPGPCustomUserHandle User);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_Generate(TElPGPSecretKeyHandle _Handle, const char * pcPassword, int32_t szPassword, int32_t KeyBits, int32_t KeyAlgorithm, int32_t SubkeyBits, int32_t SubkeyAlgorithm, const char * pcUserName, int32_t szUserName, int32_t Expires);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_Generate_1(TElPGPSecretKeyHandle _Handle, const char * pcPassword, int32_t szPassword, int32_t KeyBits, int32_t KeyAlgorithm, const char * pcUserName, int32_t szUserName, int8_t UseOldStyle, int32_t Expires);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_Generate_2(TElPGPCustomSecretKeyHandle _Handle, const char * pcPassword, int32_t szPassword, int32_t Bits, int32_t Algorithm, int8_t UseOldFormat, int32_t Expires);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_BeginGenerate(TElPGPSecretKeyHandle _Handle, int32_t KeyBits, int32_t KeyAlgorithm, int32_t SubkeyBits, int32_t SubkeyAlgorithm);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_BeginGenerate_1(TElPGPCustomSecretKeyHandle _Handle, int32_t Bits, int32_t Algorithm);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_EndGenerate(TElPGPSecretKeyHandle _Handle, const char * pcPassword, int32_t szPassword, const char * pcUserName, int32_t szUserName, int32_t Expires, int8_t UseOldFormat);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_EndGenerate_1(TElPGPCustomSecretKeyHandle _Handle, const char * pcPassword, int32_t szPassword, int8_t UseOldFormat, int32_t Expires);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_AddSubkey(TElPGPSecretKeyHandle _Handle, TElPGPSecretSubkeyHandle Subkey, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_PrepareForSigning(TElPGPSecretKeyHandle _Handle, int8_t MultiUse);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_CancelPreparation(TElPGPSecretKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_AsyncOperationFinished(TElPGPSecretKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_get_ArmorBoundary(TElPGPSecretKeyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_set_ArmorBoundary(TElPGPSecretKeyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_get_ArmorHeaders(TElPGPSecretKeyHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_get_Subkeys(TElPGPSecretKeyHandle _Handle, int32_t Index, TElPGPSecretSubkeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_get_SubkeyCount(TElPGPSecretKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_get_PublicKey(TElPGPSecretKeyHandle _Handle, TElPGPPublicKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_get_WriteFlags(TElPGPSecretKeyHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_set_WriteFlags(TElPGPSecretKeyHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_get_WriteOldPrefix(TElPGPSecretKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_set_WriteOldPrefix(TElPGPSecretKeyHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_get_OnBeforeSign(TElPGPSecretKeyHandle _Handle, TSBPGPBeforeSignEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_set_OnBeforeSign(TElPGPSecretKeyHandle _Handle, TSBPGPBeforeSignEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSecretKey_Create(TElPGPSecretKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPSECRETKEY */

#ifdef SB_USE_CLASS_TELPGPTRUST
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_Assign(TElPGPTrustHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_AssignTo(TElPGPTrustHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_get_OwnerTrust(TElPGPTrustHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_set_OwnerTrust(TElPGPTrustHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_get_Disabled(TElPGPTrustHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_set_Disabled(TElPGPTrustHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_get_BuckStop(TElPGPTrustHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_set_BuckStop(TElPGPTrustHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_get_KeyLegit(TElPGPTrustHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_set_KeyLegit(TElPGPTrustHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_get_WarnOnly(TElPGPTrustHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_set_WarnOnly(TElPGPTrustHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_get_SigTrust(TElPGPTrustHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_set_SigTrust(TElPGPTrustHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_get_Checked(TElPGPTrustHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_set_Checked(TElPGPTrustHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_get_Contiguous(TElPGPTrustHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_set_Contiguous(TElPGPTrustHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_get_Flags(TElPGPTrustHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_set_Flags(TElPGPTrustHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPTrust_Create(TElPGPTrustHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPTRUST */

#ifdef SB_USE_CLASS_TELPGPSIGNATURE
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_Assign(TElPGPSignatureHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_AssignTo(TElPGPSignatureHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_LoadFromStream(TElPGPSignatureHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_SaveToStream(TElPGPSignatureHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_SaveOnePass(TElPGPSignatureHandle _Handle, int8_t Nested);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_SaveOnePassToStream(TElPGPSignatureHandle _Handle, TStreamHandle Stream, int8_t Nested);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_IsKeyRevocation(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_IsSubkeyRevocation(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_IsUserRevocation(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_IsDocumentSignature(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_IsStandalone(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_IsUserCertification(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_IsSubkeyBinding(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_IsDirectKeySignature(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_IsTimestampSignature(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_SignerKeyID(TElPGPSignatureHandle _Handle, TSBKeyID * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_AddExtension(TElPGPSignatureHandle _Handle, TSBPGPSignatureExtensionRaw ExtType, int8_t Hashed, int8_t Critical, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_RemoveExtension(TElPGPSignatureHandle _Handle, TSBPGPSignatureExtensionRaw ExtType, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_RemoveExtension_1(TElPGPSignatureHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_GetExtensionByType(TElPGPSignatureHandle _Handle, TSBPGPSignatureExtensionRaw ExtType, int32_t Index, TElPGPSignatureSubpacketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_GetExtensionCount(TElPGPSignatureHandle _Handle, TSBPGPSignatureExtensionRaw ExtType, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_ClearExtensions(TElPGPSignatureHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_IsX509Certificate(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_Extensions(TElPGPSignatureHandle _Handle, int32_t Index, TElPGPSignatureSubpacketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_RegularExpression(TElPGPSignatureHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_RegularExpression(TElPGPSignatureHandle _Handle, int32_t Index, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_Version(TElPGPSignatureHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_Version(TElPGPSignatureHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_HashAlgorithm(TElPGPSignatureHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_HashAlgorithm(TElPGPSignatureHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_UseOldPackets(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_UseOldPackets(TElPGPSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_X509Certificate(TElPGPSignatureHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_Validated(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_Validated(TElPGPSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_StrictlyValid(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_StrictlyValid(TElPGPSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_CreationTime(TElPGPSignatureHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_CreationTime(TElPGPSignatureHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_KeyExpirationTime(TElPGPSignatureHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_KeyExpirationTime(TElPGPSignatureHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_ExpirationTime(TElPGPSignatureHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_ExpirationTime(TElPGPSignatureHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_Exportable(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_Exportable(TElPGPSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_Revocable(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_Revocable(TElPGPSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_TrustLevel(TElPGPSignatureHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_TrustLevel(TElPGPSignatureHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_TrustAmount(TElPGPSignatureHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_TrustAmount(TElPGPSignatureHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_Trust(TElPGPSignatureHandle _Handle, TElPGPTrustHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_RegularExpressionCount(TElPGPSignatureHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_RegularExpressionCount(TElPGPSignatureHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_PrimaryUserID(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_PrimaryUserID(TElPGPSignatureHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_PolicyURL(TElPGPSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_PolicyURL(TElPGPSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_SignerUserID(TElPGPSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_SignerUserID(TElPGPSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_ReasonForRevocation(TElPGPSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_ReasonForRevocation(TElPGPSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_SignatureClass(TElPGPSignatureHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_CertificationType(TElPGPSignatureHandle _Handle, TSBPGPUserCertificationTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_set_CertificationType(TElPGPSignatureHandle _Handle, TSBPGPUserCertificationTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_Revocation(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_get_IsTextSignature(TElPGPSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_Create(TElPGPSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_Create_1(TElPGPSignatureEntityHandle Entity, TElPGPSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPSignature_Create_2(TElPGPSignatureHandle Source, int8_t CopySigMaterial, TElPGPSignatureHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPSIGNATURE */

#ifdef SB_USE_CLASS_TELPGPCUSTOMUSER
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomUser_Assign(TElPGPCustomUserHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomUser_AssignTo(TElPGPCustomUserHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomUser_AddSignature(TElPGPCustomUserHandle _Handle, TElPGPSignatureHandle Signature, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomUser_ClearSignatures(TElPGPCustomUserHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomUser_RemoveSignature(TElPGPCustomUserHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomUser_RemoveSignature_1(TElPGPCustomUserHandle _Handle, TElPGPSignatureHandle Signature, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomUser_get_Signatures(TElPGPCustomUserHandle _Handle, int32_t Index, TElPGPSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomUser_get_SignatureCount(TElPGPCustomUserHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomUser_get_Revoked(TElPGPCustomUserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPCustomUser_Create(TElPGPCustomUserHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPCUSTOMUSER */

#ifdef SB_USE_CLASS_TELPGPUSERID
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserID_Assign(TElPGPUserIDHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserID_AssignTo(TElPGPUserIDHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserID_get_Name(TElPGPUserIDHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserID_set_Name(TElPGPUserIDHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserID_get_Trust(TElPGPUserIDHandle _Handle, TElPGPTrustHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserID_Create(TElPGPUserIDHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPUSERID */

#ifdef SB_USE_CLASS_TELPGPUSERATTR
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserAttr_Assign(TElPGPUserAttrHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserAttr_AssignTo(TElPGPUserAttrHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserAttr_AddImage(TElPGPUserAttrHandle _Handle, TElPGPJpegImageHandle Image, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserAttr_RemoveImage(TElPGPUserAttrHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserAttr_ClearImages(TElPGPUserAttrHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserAttr_ImageCount(TElPGPUserAttrHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserAttr_get_Trust(TElPGPUserAttrHandle _Handle, TElPGPTrustHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserAttr_get_Images(TElPGPUserAttrHandle _Handle, int32_t Index, TElPGPJpegImageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserAttr_set_Images(TElPGPUserAttrHandle _Handle, int32_t Index, TElPGPJpegImageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPUserAttr_Create(TElPGPUserAttrHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPUSERATTR */

#ifdef SB_USE_CLASS_TELPGPKEYRING
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_Load(TElPGPKeyringHandle _Handle, TStreamHandle APublic, TStreamHandle ASecret, int8_t Clear);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_Load_1(TElPGPKeyringHandle _Handle, const char * pcPublicKeysFile, int32_t szPublicKeysFile, const char * pcSecretKeysFile, int32_t szSecretKeysFile, int8_t Clear);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_AddX509Certificate(TElPGPKeyringHandle _Handle, TElX509CertificateHandle Certificate, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_AddPublicKey(TElPGPKeyringHandle _Handle, TElPGPPublicKeyHandle Key, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_AddSecretKey(TElPGPKeyringHandle _Handle, TElPGPSecretKeyHandle Key, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_RemovePublicKey(TElPGPKeyringHandle _Handle, TElPGPPublicKeyHandle Key, int8_t RemoveSecretKeyIfExists, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_RemovePublicKey_1(TElPGPKeyringHandle _Handle, int32_t Index, int8_t RemoveSecretKeyIfExists, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_RemoveSecretKey(TElPGPKeyringHandle _Handle, TElPGPSecretKeyHandle Key, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_RemoveSecretKey_1(TElPGPKeyringHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_Clear(TElPGPKeyringHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_Save(TElPGPKeyringHandle _Handle, TStreamHandle APublic, TStreamHandle ASecret, int8_t Armor);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_Save_1(TElPGPKeyringHandle _Handle, const char * pcPublicKeysFile, int32_t szPublicKeysFile, const char * pcSecretKeysFile, int32_t szSecretKeysFile, int8_t Armor);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_ExportTo(TElPGPKeyringHandle _Handle, TElPGPKeyringHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_FindPublicKeyByID(TElPGPKeyringHandle _Handle, const TSBKeyID * KeyID, TElPGPCustomPublicKeyHandle * Res, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_FindPublicKeyByID_1(TElPGPKeyringHandle _Handle, const char * pcKeyID, int32_t szKeyID, TElPGPCustomPublicKeyHandle * Res, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_FindSecretKeyByID(TElPGPKeyringHandle _Handle, const TSBKeyID * KeyID, TElPGPCustomSecretKeyHandle * Res, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_FindSecretKeyByID_1(TElPGPKeyringHandle _Handle, const char * pcKeyID, int32_t szKeyID, TElPGPCustomSecretKeyHandle * Res, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_InternalFindPublicKeyByID(TElPGPKeyringHandle _Handle, const uint8_t pKeyID[], int32_t szKeyID, TElPGPCustomPublicKeyHandle * Res, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_InternalFindSecretKeyByID(TElPGPKeyringHandle _Handle, const uint8_t pKeyID[], int32_t szKeyID, TElPGPCustomSecretKeyHandle * Res, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_FindPublicKeyByFP(TElPGPKeyringHandle _Handle, const uint8_t pFP[], int32_t szFP, TElPGPCustomPublicKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_FindSecretKeyByFP(TElPGPKeyringHandle _Handle, const uint8_t pFP[], int32_t szFP, TElPGPCustomSecretKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_FindPublicKeyByEmailAddress(TElPGPKeyringHandle _Handle, const char * pcAddress, int32_t szAddress, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_FindSecretKeyByEmailAddress(TElPGPKeyringHandle _Handle, const char * pcAddress, int32_t szAddress, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_ListKeys(TElPGPKeyringHandle _Handle, int8_t PublicOnly, const char * pcTemplate, int32_t szTemplate, TListHandle * ListOfKeys);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_ListKeys_1(TElPGPKeyringHandle _Handle, int8_t PublicOnly, const char * pcTemplate, int32_t szTemplate, int8_t IncludeSubkeysMatchingUserIDTemplateInResult, TListHandle * ListOfKeys);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_ListKeys_2(TElPGPKeyringHandle _Handle, int8_t PublicOnly, const TStringListHandle Templates, int8_t IsAndCondition, TListHandle * ListOfKeys);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_ListKeys_3(TElPGPKeyringHandle _Handle, int8_t PublicOnly, const TStringListHandle Templates, int8_t IsAndCondition, int8_t IncludeSubkeysMatchingUserIDTemplateInResult, TListHandle * ListOfKeys);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_PrepareForEncryption(TElPGPKeyringHandle _Handle, int8_t MultiUse);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_PrepareForSigning(TElPGPKeyringHandle _Handle, int8_t MultiUse);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_CancelPreparation(TElPGPKeyringHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_AsyncOperationFinished(TElPGPKeyringHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_get_ArmorBoundary(TElPGPKeyringHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_set_ArmorBoundary(TElPGPKeyringHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_get_ArmorHeaders(TElPGPKeyringHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_get_PublicKeys(TElPGPKeyringHandle _Handle, int32_t Index, TElPGPPublicKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_get_SecretKeys(TElPGPKeyringHandle _Handle, int32_t Index, TElPGPSecretKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_get_PublicCount(TElPGPKeyringHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_get_SecretCount(TElPGPKeyringHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_get_SaveSecretKeySignatures(TElPGPKeyringHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_set_SaveSecretKeySignatures(TElPGPKeyringHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_get_WriteTrust(TElPGPKeyringHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_set_WriteTrust(TElPGPKeyringHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPKeyring_Create(TComponentHandle AOwner, TElPGPKeyringHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPKEYRING */

#ifdef SB_USE_CLASS_TELPGPJPEGIMAGE
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_Assign(TElPGPJpegImageHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_AssignTo(TElPGPJpegImageHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_Save(TElPGPJpegImageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_Load(TElPGPJpegImageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_SaveToStream(TElPGPJpegImageHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_LoadFromStream(TElPGPJpegImageHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_SaveToFile(TElPGPJpegImageHandle _Handle, const char * pcFileName, int32_t szFileName);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_LoadFromFile(TElPGPJpegImageHandle _Handle, const char * pcFileName, int32_t szFileName);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_get_JpegData(TElPGPJpegImageHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_set_JpegData(TElPGPJpegImageHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_get_OnRead(TElPGPJpegImageHandle _Handle, TSBPGPReadEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_set_OnRead(TElPGPJpegImageHandle _Handle, TSBPGPReadEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_get_OnWrite(TElPGPJpegImageHandle _Handle, TSBPGPWriteEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_set_OnWrite(TElPGPJpegImageHandle _Handle, TSBPGPWriteEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_Create(TElPGPJpegImageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPJpegImage_Create_1(TElPGPUserAttrImageSubpacketHandle Source, TElPGPJpegImageHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPJPEGIMAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPGPCustomPublicKey_ce_ptr;
extern zend_class_entry *TElPGPPublicSubkey_ce_ptr;
extern zend_class_entry *TElPGPPublicKey_ce_ptr;
extern zend_class_entry *TElPGPCustomSecretKey_ce_ptr;
extern zend_class_entry *TElPGPSecretSubkey_ce_ptr;
extern zend_class_entry *TElPGPSecretKey_ce_ptr;
extern zend_class_entry *TElPGPTrust_ce_ptr;
extern zend_class_entry *TElPGPSignature_ce_ptr;
extern zend_class_entry *TElPGPCustomUser_ce_ptr;
extern zend_class_entry *TElPGPUserID_ce_ptr;
extern zend_class_entry *TElPGPUserAttr_ce_ptr;
extern zend_class_entry *TElPGPKeyring_ce_ptr;
extern zend_class_entry *TElPGPJpegImage_ce_ptr;

void SB_CALLBACK TSBPGPPasswordEventRaw(void * _ObjectData, TObjectHandle Sender, void * UserData, char * pcRes, int32_t * szRes);
void SB_CALLBACK TSBPGPBeforeSignEventRaw(void * _ObjectData, TObjectHandle Sender, TElPGPSignatureHandle Signature, TObjectHandle Subject);
void Register_TElPGPCustomPublicKey(TSRMLS_D);
void Register_TElPGPPublicSubkey(TSRMLS_D);
void Register_TElPGPPublicKey(TSRMLS_D);
void Register_TElPGPCustomSecretKey(TSRMLS_D);
void Register_TElPGPSecretSubkey(TSRMLS_D);
void Register_TElPGPSecretKey(TSRMLS_D);
void Register_TElPGPTrust(TSRMLS_D);
void Register_TElPGPSignature(TSRMLS_D);
void Register_TElPGPCustomUser(TSRMLS_D);
void Register_TElPGPUserID(TSRMLS_D);
void Register_TElPGPUserAttr(TSRMLS_D);
void Register_TElPGPKeyring(TSRMLS_D);
void Register_TElPGPJpegImage(TSRMLS_D);
void Register_SBPGPKeys_Enum_Flags(TSRMLS_D);
void Register_SBPGPKeys_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPGPKEYS */

