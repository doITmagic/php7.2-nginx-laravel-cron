#ifndef __INC_SBPGPMD
#define __INC_SBPGPMD

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbhashfunction.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElPGPHashingPoolHandle;

#ifdef SB_USE_CLASS_TELPGPHASHINGPOOL
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_Add(TElPGPHashingPoolHandle _Handle, int32_t Algorithm, int8_t SkipIfExists, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_Clear(TElPGPHashingPoolHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_Remove(TElPGPHashingPoolHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_Reset(TElPGPHashingPoolHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_NFinalize(TElPGPHashingPoolHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_Update(TElPGPHashingPoolHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_Update_1(TElPGPHashingPoolHandle _Handle, TStreamHandle Stream, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_GetContextByAlgorithm(TElPGPHashingPoolHandle _Handle, int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_get_HashFunctions(TElPGPHashingPoolHandle _Handle, int32_t Index, TElHashFunctionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_get_Count(TElPGPHashingPoolHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_get_DataIsText(TElPGPHashingPoolHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_set_DataIsText(TElPGPHashingPoolHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_get_CompMode(TElPGPHashingPoolHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_set_CompMode(TElPGPHashingPoolHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPGPHashingPool_Create(TElPGPHashingPoolHandle * OutResult);
#endif /* SB_USE_CLASS_TELPGPHASHINGPOOL */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPGPHashingPool_ce_ptr;

void Register_TElPGPHashingPool(TSRMLS_D);
SB_PHP_FUNCTION(SBPGPMD, MDGetDigestSize);
SB_PHP_FUNCTION(SBPGPMD, MDInitialize);
SB_PHP_FUNCTION(SBPGPMD, MDHash);
SB_PHP_FUNCTION(SBPGPMD, MDFinalize);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_PGPMD
SB_IMPORT uint32_t SB_APIENTRY SBPGPMD_MDGetDigestSize(int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPMD_MDInitialize(TElHashFunctionHandle * HashFunction, int32_t Algorithm);
SB_IMPORT uint32_t SB_APIENTRY SBPGPMD_MDHash(int32_t Algorithm, const uint8_t pData[], int32_t szData, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPMD_MDFinalize(TElHashFunctionHandle * HashFunction, uint8_t pOutResult[], int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_PGPMD */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPGPMD */

