#ifndef __INC_SBPGPMIME
#define __INC_SBPGPMIME

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbmime.h"
#include "sbmimestream.h"
#include "sbsimplemime.h"
#include "sbpgpconstants.h"
#include "sbpgpkeys.h"
#include "sbpgp.h"
#include "sbpgpentities.h"
#include "sbpgputils.h"
#include "sbpgpstreams.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElMessagePartHandlerPGPMimeHandle;

typedef TElClassHandle TElMessagePartHandlerPGPKeysHandle;

typedef TElClassHandle TElSimplePGPMIMEOptionsHandle;

typedef TElClassHandle TElSimplePGPMIMEMessageHandle;

typedef TElMessagePartHandlerPGPMimeHandle ElMessagePartHandlerPGPMimeHandle;

typedef TElMessagePartHandlerPGPKeysHandle ElMessagePartHandlerPGPKeysHandle;

typedef TElSimplePGPMIMEOptionsHandle ElSimplePGPMIMEOptionsHandle;

typedef TElSimplePGPMIMEMessageHandle ElSimplePGPMIMEMessageHandle;

typedef uint8_t TSBPGPMIMETypeRaw;

typedef enum
{
	pmtUnknown = 0,
	pmtSigned = 1,
	pmtEncrypted = 2,
	pmtSignedEncrypted = 3
} TSBPGPMIMEType;

typedef uint8_t TSBPGPMIMEErrorRaw;

typedef enum
{
	pmeUnknown = 0,
	pmePGPPartNotFound = 1,
	pmeInvalidSignature = 2,
	pmeUnverifiableSignature = 3,
	pmeRecipientKeyNotFound = 4,
	pmeSenderKeyNotFound = 5,
	pmeNoRecipients = 6,
	pmeNoSigners = 7,
	pmeActionNotSelected = 8
} TSBPGPMIMEError;

typedef uint32_t TSBPGPMIMEErrorsRaw;

typedef enum 
{
	f_pmeUnknown = 1,
	f_pmePGPPartNotFound = 2,
	f_pmeInvalidSignature = 4,
	f_pmeUnverifiableSignature = 8,
	f_pmeRecipientKeyNotFound = 16,
	f_pmeSenderKeyNotFound = 32,
	f_pmeNoRecipients = 64,
	f_pmeNoSigners = 128,
	f_pmeActionNotSelected = 256
} TSBPGPMIMEErrors;

typedef uint8_t TSBPGPKeysErrorRaw;

typedef enum
{
	pkeUnknown = 0,
	pkeKeysPartNotFound = 1,
	pkeNoPublicKeys = 2
} TSBPGPKeysError;

typedef uint32_t TSBPGPKeysErrorsRaw;

typedef enum 
{
	f_pkeUnknown = 1,
	f_pkeKeysPartNotFound = 2,
	f_pkeNoPublicKeys = 4
} TSBPGPKeysErrors;

typedef void (SB_CALLBACK *TSBPGPKeyNotFoundEvent)(void * _ObjectData, TObjectHandle Sender, TElMailAddressHandle Address, int8_t * ExcludeFromList);

#ifdef SB_USE_CLASS_TELMESSAGEPARTHANDLERPGPMIME
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_GetDescription(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_GetDescription_1(TElMessagePartHandlerPGPMimeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_IsSigned(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_IsEncrypted(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_Errors(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPMIMEErrorsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_Encrypt(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_Encrypt(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_Sign(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_Sign(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_Compress(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_Compress(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_IgnoreHeaderRecipients(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_IgnoreHeaderRecipients(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_IgnoreHeaderSigners(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_IgnoreHeaderSigners(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_DecryptingKeys(TElMessagePartHandlerPGPMimeHandle _Handle, TElPGPKeyringHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_DecryptingKeys(TElMessagePartHandlerPGPMimeHandle _Handle, TElPGPKeyringHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_VerifyingKeys(TElMessagePartHandlerPGPMimeHandle _Handle, TElPGPKeyringHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_VerifyingKeys(TElMessagePartHandlerPGPMimeHandle _Handle, TElPGPKeyringHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_EncryptingKeys(TElMessagePartHandlerPGPMimeHandle _Handle, TElPGPKeyringHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_EncryptingKeys(TElMessagePartHandlerPGPMimeHandle _Handle, TElPGPKeyringHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_SigningKeys(TElMessagePartHandlerPGPMimeHandle _Handle, TElPGPKeyringHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_SigningKeys(TElMessagePartHandlerPGPMimeHandle _Handle, TElPGPKeyringHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_EncryptionType(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPEncryptionTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_EncryptionType(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPEncryptionTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_Passphrases(TElMessagePartHandlerPGPMimeHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_Passphrases(TElMessagePartHandlerPGPMimeHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_Protection(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPProtectionTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_Protection(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPProtectionTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_CompressionAlgorithm(TElMessagePartHandlerPGPMimeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_CompressionAlgorithm(TElMessagePartHandlerPGPMimeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_CompressionLevel(TElMessagePartHandlerPGPMimeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_CompressionLevel(TElMessagePartHandlerPGPMimeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_HashAlgorithm(TElMessagePartHandlerPGPMimeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_HashAlgorithm(TElMessagePartHandlerPGPMimeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_SymmetricKeyAlgorithm(TElMessagePartHandlerPGPMimeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_SymmetricKeyAlgorithm(TElMessagePartHandlerPGPMimeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_UseNewFeatures(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_UseNewFeatures(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_UseOldPackets(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_UseOldPackets(TElMessagePartHandlerPGPMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_ArmorHeaders(TElMessagePartHandlerPGPMimeHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_ArmorHeaders(TElMessagePartHandlerPGPMimeHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_OnEncrypted(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPEncryptedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_OnEncrypted(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPEncryptedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_OnSigned(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPSignedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_OnSigned(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPSignedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_OnKeyPassphrase(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPKeyPassphraseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_OnKeyPassphrase(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPKeyPassphraseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_OnPassphrase(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPPassphraseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_OnPassphrase(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPPassphraseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_OnSignatures(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPSignaturesEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_OnSignatures(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPSignaturesEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_OnEncryptingKeyNotFound(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPKeyNotFoundEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_OnEncryptingKeyNotFound(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPKeyNotFoundEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_get_OnSigningKeyNotFound(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPKeyNotFoundEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_set_OnSigningKeyNotFound(TElMessagePartHandlerPGPMimeHandle _Handle, TSBPGPKeyNotFoundEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPMime_Create(TObjectHandle aParams, TElMessagePartHandlerPGPMimeHandle * OutResult);
#endif /* SB_USE_CLASS_TELMESSAGEPARTHANDLERPGPMIME */

#ifdef SB_USE_CLASS_TELMESSAGEPARTHANDLERPGPKEYS
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPKeys_GetDescription(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPKeys_GetDescription_1(TElMessagePartHandlerPGPKeysHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPKeys_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPKeys_get_Keys(TElMessagePartHandlerPGPKeysHandle _Handle, TElPGPKeyringHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerPGPKeys_Create(TObjectHandle aParams, TElMessagePartHandlerPGPKeysHandle * OutResult);
#endif /* SB_USE_CLASS_TELMESSAGEPARTHANDLERPGPKEYS */

#ifdef SB_USE_CLASS_TELSIMPLEPGPMIMEOPTIONS
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_Assign(TElSimplePGPMIMEOptionsHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_EncryptionType(TElSimplePGPMIMEOptionsHandle _Handle, TSBPGPEncryptionTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_EncryptionType(TElSimplePGPMIMEOptionsHandle _Handle, TSBPGPEncryptionTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_Passphrases(TElSimplePGPMIMEOptionsHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_Passphrases(TElSimplePGPMIMEOptionsHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_Protection(TElSimplePGPMIMEOptionsHandle _Handle, TSBPGPProtectionTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_Protection(TElSimplePGPMIMEOptionsHandle _Handle, TSBPGPProtectionTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_HashAlgorithm(TElSimplePGPMIMEOptionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_HashAlgorithm(TElSimplePGPMIMEOptionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_CompressionAlgorithm(TElSimplePGPMIMEOptionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_CompressionAlgorithm(TElSimplePGPMIMEOptionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_CompressionLevel(TElSimplePGPMIMEOptionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_CompressionLevel(TElSimplePGPMIMEOptionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_SymmetricKeyAlgorithm(TElSimplePGPMIMEOptionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_SymmetricKeyAlgorithm(TElSimplePGPMIMEOptionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_UseOldPackets(TElSimplePGPMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_UseOldPackets(TElSimplePGPMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_UseNewFeatures(TElSimplePGPMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_UseNewFeatures(TElSimplePGPMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_CompressMessage(TElSimplePGPMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_CompressMessage(TElSimplePGPMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_EncryptMessage(TElSimplePGPMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_EncryptMessage(TElSimplePGPMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_IgnoreHeaderRecipients(TElSimplePGPMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_IgnoreHeaderRecipients(TElSimplePGPMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_IgnoreHeaderSigners(TElSimplePGPMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_IgnoreHeaderSigners(TElSimplePGPMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_SignMessage(TElSimplePGPMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_SignMessage(TElSimplePGPMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_get_ArmorHeaders(TElSimplePGPMIMEOptionsHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_set_ArmorHeaders(TElSimplePGPMIMEOptionsHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEOptions_Create(TElSimplePGPMIMEOptionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLEPGPMIMEOPTIONS */

#ifdef SB_USE_CLASS_TELSIMPLEPGPMIMEMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEMessage_get_EncryptingKeys(TElSimplePGPMIMEMessageHandle _Handle, TElPGPKeyringHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEMessage_set_EncryptingKeys(TElSimplePGPMIMEMessageHandle _Handle, TElPGPKeyringHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEMessage_get_PGPMIMEOptions(TElSimplePGPMIMEMessageHandle _Handle, TElSimplePGPMIMEOptionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEMessage_set_PGPMIMEOptions(TElSimplePGPMIMEMessageHandle _Handle, TElSimplePGPMIMEOptionsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEMessage_get_SigningKeys(TElSimplePGPMIMEMessageHandle _Handle, TElPGPKeyringHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEMessage_set_SigningKeys(TElSimplePGPMIMEMessageHandle _Handle, TElPGPKeyringHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEMessage_get_OnEncryptingKeyNotFound(TElSimplePGPMIMEMessageHandle _Handle, TSBPGPKeyNotFoundEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEMessage_set_OnEncryptingKeyNotFound(TElSimplePGPMIMEMessageHandle _Handle, TSBPGPKeyNotFoundEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEMessage_get_OnKeyPassphrase(TElSimplePGPMIMEMessageHandle _Handle, TSBPGPKeyPassphraseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEMessage_set_OnKeyPassphrase(TElSimplePGPMIMEMessageHandle _Handle, TSBPGPKeyPassphraseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEMessage_get_OnSigningKeyNotFound(TElSimplePGPMIMEMessageHandle _Handle, TSBPGPKeyNotFoundEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEMessage_set_OnSigningKeyNotFound(TElSimplePGPMIMEMessageHandle _Handle, TSBPGPKeyNotFoundEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimplePGPMIMEMessage_Create(TComponentHandle AOwner, TElSimplePGPMIMEMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLEPGPMIMEMESSAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElMessagePartHandlerPGPMime_ce_ptr;
extern zend_class_entry *TElMessagePartHandlerPGPKeys_ce_ptr;
extern zend_class_entry *TElSimplePGPMIMEOptions_ce_ptr;
extern zend_class_entry *TElSimplePGPMIMEMessage_ce_ptr;

void SB_CALLBACK TSBPGPKeyNotFoundEventRaw(void * _ObjectData, TObjectHandle Sender, TElMailAddressHandle Address, int8_t * ExcludeFromList);
void Register_TElMessagePartHandlerPGPMime(TSRMLS_D);
void Register_TElMessagePartHandlerPGPKeys(TSRMLS_D);
void Register_TElSimplePGPMIMEOptions(TSRMLS_D);
void Register_TElSimplePGPMIMEMessage(TSRMLS_D);
SB_PHP_FUNCTION(SBPGPMIME, Initialize);
void Register_SBPGPMIME_Enum_Flags(TSRMLS_D);
void Register_SBPGPMIME_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_PGPMIME
SB_IMPORT uint32_t SB_APIENTRY SBPGPMIME_Initialize(void);
#endif /* SB_USE_GLOBAL_PROCS_PGPMIME */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPGPMIME */

