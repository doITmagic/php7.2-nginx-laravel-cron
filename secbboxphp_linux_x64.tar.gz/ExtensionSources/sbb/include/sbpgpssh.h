#ifndef __INC_SBPGPSSH
#define __INC_SBPGPSSH

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbhashfunction.h"
#include "sbsshcommon.h"
#include "sbsshconstants.h"
#include "sbsshkeystorage.h"
#include "sbsshutils.h"
#include "sbpgputils.h"
#include "sbpgpstreams.h"
#include "sbpgpkeys.h"
#include "sbx509.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbpublickeycrypto.h"
#include "sbcustomcrypto.h"
#include "sbpgpconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSSHPGPKeyHandle;

typedef TElSSHPGPKeyHandle ElSSHPGPKeyHandle;

typedef TElClassHandle TElSSHPGPAuthHandlerHandle;

typedef TElSSHPGPAuthHandlerHandle ElSSHPGPAuthHandlerHandle;

#ifdef SB_USE_CLASS_TELSSHPGPKEY
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPKey_Copy(TElSSHPGPKeyHandle _Handle, TElSSHKeyHandle * Dest);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPKey_Clear(TElSSHPGPKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPKey_Import(TElSSHPGPKeyHandle _Handle, TElPGPPublicKeyHandle PubKey);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPKey_Import_1(TElSSHPGPKeyHandle _Handle, TElPGPSecretKeyHandle SecKey);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPKey_Import_2(TElSSHKeyHandle _Handle, TElX509CertificateHandle Certificate);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPKey_get_PGPPublicKey(TElSSHPGPKeyHandle _Handle, TElPGPPublicKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPKey_get_PGPSecretKey(TElSSHPGPKeyHandle _Handle, TElPGPSecretKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPKey_Create(TElSSHKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHPGPKEY */

#ifdef SB_USE_CLASS_TELSSHPGPAUTHHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPAuthHandler_GetAlgorithmFromClientKexDHReply(TElSSHPGPAuthHandlerHandle _Handle, const uint8_t pHostAlg[], int32_t szHostAlg, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPAuthHandler_ValidateServerSignature(TElSSHPGPAuthHandlerHandle _Handle, int32_t Algorithm, const uint8_t pPubKeyStr[], int32_t szPubKeyStr, const uint8_t pSignature[], int32_t szSignature, const uint8_t pHash[], int32_t szHash, int32_t HashAlg, int32_t * ErrCode, char * pcErrMessage, int32_t * szErrMessage, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPAuthHandler_FindKeyByAlgorithm(TElSSHPGPAuthHandlerHandle _Handle, TElSSHCustomKeyStorageHandle Storage, int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPAuthHandler_GetKeyBlob(TElSSHPGPAuthHandlerHandle _Handle, TElSSHKeyHandle Key, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPAuthHandler_KeyBlobToKey(TElSSHPGPAuthHandlerHandle _Handle, const char * pcAlgName, int32_t szAlgName, const uint8_t pBlob[], int32_t szBlob, TElSSHKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPAuthHandler_HashAlgFromKey(TElSSHPGPAuthHandlerHandle _Handle, TElSSHKeyHandle Key, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPAuthHandler_CalculateServerSignature(TElSSHPGPAuthHandlerHandle _Handle, TElSSHKeyHandle Key, const uint8_t paHash[], int32_t szaHash, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPAuthHandler_ServerValidateClientSignature(TElSSHPGPAuthHandlerHandle _Handle, const uint8_t pAlgName[], int32_t szAlgName, const uint8_t pKeyBlob[], int32_t szKeyBlob, const uint8_t pSignature[], int32_t szSignature, const uint8_t pHash[], int32_t szHash, int8_t * Valid, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPGPAuthHandler_Create(TComponentHandle AOwner, TComponentHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHPGPAUTHHANDLER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSSHPGPKey_ce_ptr;
extern zend_class_entry *TElSSHPGPAuthHandler_ce_ptr;

void Register_TElSSHPGPKey(TSRMLS_D);
void Register_TElSSHPGPAuthHandler(TSRMLS_D);
void Register_SBPGPSSH_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPGPSSH */

