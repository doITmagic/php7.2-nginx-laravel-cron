#ifndef __INC_SBPGPUTILS
#define __INC_SBPGPUTILS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbchsconv.h"
#include "sbchsconvcharsets.h"
#include "sbchscjk.h"
#include "sbmath.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbrandom.h"
#include "sbsymmetriccrypto.h"
#include "sbpgpconstants.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_PGP_FILE_CREATE 	1
#define SB_PGP_FILE_READ 	2
#define SB_PGP_FILE_WRITE 	4

typedef uint8_t TSBKeyID[8];

#pragma pack(8)
typedef struct 
{
	void * Value0;
	void * Value1;
} TSBPGPSignatureMaterial;

#pragma pack(8)
typedef struct 
{
	void * Value0;
	void * Value1;
} TSBPGPEncryptedSymmetricKey;

typedef uint8_t TSBPGPSignatureTypeRaw;

typedef enum
{
	stNormal = 0,
	stOnePass = 1,
	stDetached = 2,
	stCleartext = 3
} TSBPGPSignatureType;

typedef uint8_t TSBPGPSignatureExtensionRaw;

typedef enum
{
	seUndefined = 0,
	seCreationTime = 1,
	seExpirationTime = 2,
	seExportable = 3,
	seTrust = 4,
	seRegExp = 5,
	seRevocable = 6,
	seKeyExpirationTime = 7,
	sePreferredSymAlg = 8,
	seRevocationKey = 9,
	seIssuerKeyID = 10,
	seNotationData = 11,
	sePreferredHashAlg = 12,
	sePreferredComprAlg = 13,
	seKeyServerPreferences = 14,
	sePreferredKeyServer = 15,
	sePrimaryUserID = 16,
	sePolicyURL = 17,
	seKeyFlags = 18,
	seSignerUserID = 19,
	seReasonForRevocation = 20,
	seFeatures = 21,
	seTarget = 22,
	seEmbeddedSig = 23,
	seX509Certificate = 24
} TSBPGPSignatureExtension;

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TSBKeyID_ce_ptr;
extern zend_class_entry *TSBPGPSignatureMaterial_ce_ptr;
extern zend_class_entry *TSBPGPEncryptedSymmetricKey_ce_ptr;

void Register_TSBKeyID(TSRMLS_D);
void Register_TSBPGPSignatureMaterial(TSRMLS_D);
void Register_TSBPGPEncryptedSymmetricKey(TSRMLS_D);
SB_PHP_FUNCTION(SBPGPUtils, UTCTime);
SB_PHP_FUNCTION(SBPGPUtils, TimestampToDateTime);
SB_PHP_FUNCTION(SBPGPUtils, DateTimeToTimestamp);
SB_PHP_FUNCTION(SBPGPUtils, ReadMPInt);
SB_PHP_FUNCTION(SBPGPUtils, WriteMPInt);
#ifdef SB_DEFINE_FPC_SPECIFIC_METHODS
SB_PHP_FUNCTION(SBPGPUtils, WriteMPInt2);
#endif /* SB_DEFINE_FPC_SPECIFIC_METHODS */
SB_PHP_FUNCTION(SBPGPUtils, GetPGPPacketHeaderSize);
SB_PHP_FUNCTION(SBPGPUtils, GetSigSubpktTypeByExtension);
SB_PHP_FUNCTION(SBPGPUtils, WriteSizeInt);
SB_PHP_FUNCTION(SBPGPUtils, MPIntToByteArray);
SB_PHP_FUNCTION(SBPGPUtils, IsCorrectHashAlgorithm);
SB_PHP_FUNCTION(SBPGPUtils, IsCorrectSymmetricAlgorithm);
SB_PHP_FUNCTION(SBPGPUtils, AlgorithmCanSign);
SB_PHP_FUNCTION(SBPGPUtils, AlgorithmCanEncrypt);
SB_PHP_FUNCTION(SBPGPUtils, TranslateMDAlgorithmFromPGP);
SB_PHP_FUNCTION(SBPGPUtils, TranslateMDAlgorithmToPGP);
SB_PHP_FUNCTION(SBPGPUtils, TranslateSKAlgorithmFromPGP);
SB_PHP_FUNCTION(SBPGPUtils, TranslateSKAlgorithmToPGP);
SB_PHP_FUNCTION(SBPGPUtils, TranslateMDAlgorithmToECDSA);
SB_PHP_FUNCTION(SBPGPUtils, AddPKCS1Prefix);
SB_PHP_FUNCTION(SBPGPUtils, SymmetricInitialize);
SB_PHP_FUNCTION(SBPGPUtils, SymmetricFinalize);
SB_PHP_FUNCTION(SBPGPUtils, MPIntSize);
SB_PHP_FUNCTION(SBPGPUtils, MPIntBitCount);
SB_PHP_FUNCTION(SBPGPUtils, CRC24);
SB_PHP_FUNCTION(SBPGPUtils, CalculateChecksum);
#ifdef SB_DEFINE_FPC_SPECIFIC_METHODS
SB_PHP_FUNCTION(SBPGPUtils, ToBase64_32);
#endif /* SB_DEFINE_FPC_SPECIFIC_METHODS */
SB_PHP_FUNCTION(SBPGPUtils, ToBase64_2);
SB_PHP_FUNCTION(SBPGPUtils, ToBase64_1);
SB_PHP_FUNCTION(SBPGPUtils, SKGetBlockSize);
SB_PHP_FUNCTION(SBPGPUtils, SKGetKeySize);
SB_PHP_FUNCTION(SBPGPUtils, CreateAndInitRandom);
SB_PHP_FUNCTION(SBPGPUtils, Max64);
SB_PHP_FUNCTION(SBPGPUtils, Min64);
SB_PHP_FUNCTION(SBPGPUtils, IsPublicKeyEncryptionAlgorithm);
SB_PHP_FUNCTION(SBPGPUtils, IsPublicKeySigningAlgorithm);
SB_PHP_FUNCTION(SBPGPUtils, AlgorithmMPIntsPublic);
SB_PHP_FUNCTION(SBPGPUtils, AlgorithmMPIntsSecret);
SB_PHP_FUNCTION(SBPGPUtils, CompareKeyID);
SB_PHP_FUNCTION(SBPGPUtils, CompareKeyFP);
SB_PHP_FUNCTION(SBPGPUtils, CompareKeyIDArrays);
SB_PHP_FUNCTION(SBPGPUtils, GetSymmetricKeyAlgorithmName);
SB_PHP_FUNCTION(SBPGPUtils, GetSymmetricKeyAlgorithmByName);
SB_PHP_FUNCTION(SBPGPUtils, FormatPKCS1);
SB_PHP_FUNCTION(SBPGPUtils, UnformatPKCS1);
SB_PHP_FUNCTION(SBPGPUtils, PGPCurveByOID);
SB_PHP_FUNCTION(SBPGPUtils, OIDByPGPCurve);
SB_PHP_FUNCTION(SBPGPUtils, PGPCurveByBits);
SB_PHP_FUNCTION(SBPGPUtils, BitsInPGPCurve);
SB_PHP_FUNCTION(SBPGPUtils, HashAlgorithmByPGPCurve);
SB_PHP_FUNCTION(SBPGPUtils, SymmetricAlgorithmByPGPCurve);
SB_PHP_FUNCTION(SBPGPUtils, DetectMessageEncoding);
SB_PHP_FUNCTION(SBPGPUtils, BytesInEncoding);
SB_PHP_FUNCTION(SBPGPUtils, UnicodeMessageToUtf8);
SB_PHP_FUNCTION(SBPGPUtils, IsCleartextMessage);
SB_PHP_FUNCTION(SBPGPUtils, SizeOfMessageInEncoding);
SB_PHP_FUNCTION(SBPGPUtils, IsWhitespace);
SB_PHP_FUNCTION(SBPGPUtils, IsEOL);
SB_PHP_FUNCTION(SBPGPUtils, IsEmailChar);
SB_PHP_FUNCTION(SBPGPUtils, UserIDCorrespondsToEmail);
SB_PHP_FUNCTION(SBPGPUtils, KeyID2Str);
SB_PHP_FUNCTION(SBPGPUtils, KeyID2Array);
SB_PHP_FUNCTION(SBPGPUtils, KeyFP2Str);
SB_PHP_FUNCTION(SBPGPUtils, PKAlg2Str);
SB_PHP_FUNCTION(SBPGPUtils, HashAlg2Str);
SB_PHP_FUNCTION(SBPGPUtils, Str2HashAlg);
SB_PHP_FUNCTION(SBPGPUtils, ComprAlg2Str);
SB_PHP_FUNCTION(SBPGPUtils, ConvertDaysToSeconds);
SB_PHP_FUNCTION(SBPGPUtils, ConvertSecondsToDays);
SB_PHP_FUNCTION(SBPGPUtils, EncodePassword);
SB_PHP_FUNCTION(SBPGPUtils, GetOpenPGPPasswordCharset);
SB_PHP_FUNCTION(SBPGPUtils, SetOpenPGPPasswordCharset);
void Register_SBPGPUtils_Constants(int module_number TSRMLS_DC);
void Register_SBPGPUtils_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_PGPUTILS
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_UTCTime(int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_TimestampToDateTime(uint32_t Timestamp, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_DateTimeToTimestamp(int64_t DateTime, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_ReadMPInt(const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t Size, PLInt * Dest, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_WriteMPInt(PLInt Src, uint8_t pOutResult[], int32_t * szOutResult);
#ifdef SB_DEFINE_FPC_SPECIFIC_METHODS
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_WriteMPInt2(const uint8_t pSrc[], int32_t szSrc, uint8_t pOutResult[], int32_t * szOutResult);
#endif /* SB_DEFINE_FPC_SPECIFIC_METHODS */
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_GetPGPPacketHeaderSize(const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_GetSigSubpktTypeByExtension(TSBPGPSignatureExtensionRaw ExtType, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_WriteSizeInt(uint32_t Size, void * Buffer, int32_t * ResSize);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_MPIntToByteArray(const uint8_t pSrc[], int32_t szSrc, uint8_t pDest[], int32_t * szDest, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_IsCorrectHashAlgorithm(int32_t Algorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_IsCorrectSymmetricAlgorithm(int32_t Algorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_AlgorithmCanSign(int32_t Algorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_AlgorithmCanEncrypt(int32_t Algorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_TranslateMDAlgorithmFromPGP(int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_TranslateMDAlgorithmToPGP(int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_TranslateSKAlgorithmFromPGP(int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_TranslateSKAlgorithmToPGP(int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_TranslateMDAlgorithmToECDSA(int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_AddPKCS1Prefix(const uint8_t pHash[], int32_t szHash, int32_t Algorithm, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_SymmetricInitialize(int32_t Algorithm, TElSymmetricCryptoHandle * Crypto, const uint8_t pKey[], int32_t szKey, const uint8_t pInitialVector[], int32_t szInitialVector);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_SymmetricFinalize(TElSymmetricCryptoHandle * Crypto);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_MPIntSize(const uint8_t pBuffer[], int32_t szBuffer, int32_t Index, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_MPIntBitCount(const uint8_t pMPInt[], int32_t szMPInt, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_CRC24(void * Buffer, int32_t Size, uint32_t Init, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_CalculateChecksum(const uint8_t pBuffer[], int32_t szBuffer, uint16_t * OutResult);
#ifdef SB_DEFINE_FPC_SPECIFIC_METHODS
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_ToBase64_32(const uint8_t pInBuffer[], int32_t szInBuffer, int32_t Index, uint8_t pOutBuffer[], int32_t * szOutBuffer);
#endif /* SB_DEFINE_FPC_SPECIFIC_METHODS */
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_ToBase64_2(const uint8_t pInBuffer[], int32_t szInBuffer, int32_t Index, uint8_t pOutBuffer[], int32_t * szOutBuffer);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_ToBase64_1(const uint8_t pInBuffer[], int32_t szInBuffer, int32_t Index, uint8_t pOutBuffer[], int32_t * szOutBuffer);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_SKGetBlockSize(int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_SKGetKeySize(int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_CreateAndInitRandom(TElRandomHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_Max64(int64_t X, int64_t Y, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_Min64(int64_t X, int64_t Y, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_IsPublicKeyEncryptionAlgorithm(int32_t Alg, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_IsPublicKeySigningAlgorithm(int32_t Alg, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_AlgorithmMPIntsPublic(int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_AlgorithmMPIntsSecret(int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_CompareKeyID(const TSBKeyID * ID1, const TSBKeyID * ID2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_CompareKeyFP(const uint8_t pFP1[], int32_t szFP1, const uint8_t pFP2[], int32_t szFP2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_CompareKeyIDArrays(const uint8_t pID1[], int32_t szID1, const uint8_t pID2[], int32_t szID2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_GetSymmetricKeyAlgorithmName(int32_t Alg, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_GetSymmetricKeyAlgorithmByName(const char * pcName, int32_t szName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_FormatPKCS1(const uint8_t pModulus[], int32_t szModulus, const uint8_t pData[], int32_t szData, uint8_t BlockType, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_FormatPKCS1_1(PLInt Modulus, const uint8_t pData[], int32_t szData, uint8_t BlockType, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_UnformatPKCS1(const uint8_t pData[], int32_t szData, uint8_t * BlockType, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_UnformatPKCS1_1(PLInt Data, uint8_t * BlockType, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_PGPCurveByOID(const uint8_t pOID[], int32_t szOID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_OIDByPGPCurve(int32_t Curve, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_PGPCurveByBits(int32_t Bits, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_BitsInPGPCurve(int32_t Curve, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_HashAlgorithmByPGPCurve(int32_t Curve, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_SymmetricAlgorithmByPGPCurve(int32_t Curve, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_DetectMessageEncoding(const uint8_t pMsg[], int32_t szMsg, int32_t Index, int32_t Size, int32_t * BOMSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_BytesInEncoding(int32_t Encoding, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_UnicodeMessageToUtf8(int32_t Encoding, const uint8_t pMsg[], int32_t szMsg, int32_t Index, int32_t * Size, const uint8_t pOutBuf[], int32_t szOutBuf, int32_t OutIndex, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_IsCleartextMessage(int32_t Encoding, const uint8_t pMsg[], int32_t szMsg, int32_t Index, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_SizeOfMessageInEncoding(int32_t Encoding, const uint8_t pMsg[], int32_t szMsg, int32_t Index, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_IsWhitespace(uint8_t B, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_IsEOL(uint8_t B, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_IsEmailChar(uint8_t B, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_UserIDCorrespondsToEmail(const char * pcUserID, int32_t szUserID, const char * pcEmail, int32_t szEmail, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_KeyID2Str(const TSBKeyID * KeyID, int8_t OnlyLowBytes, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_KeyID2Array(const TSBKeyID * KeyID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_KeyFP2Str(const uint8_t pKeyFP[], int32_t szKeyFP, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_PKAlg2Str(int32_t Alg, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_HashAlg2Str(int32_t Alg, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_Str2HashAlg(const char * pcAlg, int32_t szAlg, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_ComprAlg2Str(int32_t Alg, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_ConvertDaysToSeconds(int32_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_ConvertSecondsToDays(int32_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_EncodePassword(const char * pcPassword, int32_t szPassword, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_GetOpenPGPPasswordCharset(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPGPUtils_SetOpenPGPPasswordCharset(const char * pcValue, int32_t szValue);
#endif /* SB_USE_GLOBAL_PROCS_PGPUTILS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPGPUTILS */

