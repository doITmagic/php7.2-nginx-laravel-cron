#ifndef __INC_SBPHPCORE
#define __INC_SBPHPCORE

#if _MSC_VER > 1000
#  pragma once
#endif

#include "sbdefs.h"

#include "php.h"

#ifdef PHP_WIN32
# include "win32/php_stdint.h"
#else
// GNU C++ Compiler
# include <inttypes.h>
#endif


#include "php_ini.h"
#include "ext/standard/info.h"
#include "Zend/zend_exceptions.h"
#include "Zend/zend_interfaces.h"

#include "ext/date/php_date.h"


typedef uint16_t sb_char16_t;

#if defined(LINUX) || defined(MACOS)
#  define SB_APIENTRY
#  define SB_CALLBACK
#else
#  define SB_APIENTRY __stdcall
#  define SB_CALLBACK __stdcall
#endif

#pragma pack(push, 1)

#ifndef SB_IMPORT
#  ifndef __DECLSPEC_SUPPORTED
#    define SB_IMPORT
#  else
#    define SB_IMPORT
//#    define SB_IMPORT __declspec(dllimport)
#  endif
#endif

#ifndef SB_INLINE
#  ifndef SB_USE_INLINE
#    define SB_INLINE  /* do not inline for static library */
#  else
#    ifdef _MSC_VER
#      define SB_INLINE __forceinline /* use __forceinline (VC++ specific) */
#    else
#      define SB_INLINE inline        /* use standard inline */
#    endif
#  endif
#endif

#if PHP_VERSION_ID < 70000L
// for PHP older than 7.0
#  define Z_REFVAL_P(z)  z

#  define sb_str_size  int
#  define sb_zend_long  long

#  define SB_ISREF_DATETIME_P(z)  Z_ISREF_P(z)
#  define SB_ISREF_STRUCT_P(z)  Z_ISREF_P(z)
#  define SB_ISREF_OBJECT_P(z)  Z_ISREF_P(z)

#  define SB_RETURN_STRINGL(s, l)  RETURN_STRINGL(s, l, 0)
#  define SB_RETURN_STRINGL_DUP(s, l)  RETURN_STRINGL(s, l, 1)

#  define SB_ZVAL_STRINGL(z, s, l)   ZVAL_STRINGL(z, s, l, 0)
#  define SB_ZVAL_STRINGL_UPDATE(z, s, l)   ZVAL_STRINGL(z, s, l, 0)
#  define SB_ZVAL_STRINGL_DUP(z, s, l)   ZVAL_STRINGL(z, s, l, 1)

#  define SB_REGISTER_INTERNAL_CLASS_EX(class_entry, parent_ce)  zend_register_internal_class_ex(class_entry, parent_ce, NULL TSRMLS_CC)
#  define SB_ACC_FINAL_CLASS  ZEND_ACC_FINAL_CLASS

#  define SB_IS_BOOL_TYPE_P(z)  (IS_BOOL == Z_TYPE_P(z))
#  define SB_BVAL_P(z)  Z_BVAL_P(z)

#  define SB_EVENT_INIT_PARAMS(n)  zval **params[n]
#  define SB_EVENT_INIT_ZVAL_REF(z, k)	SB_EVENT_INIT_ZVAL(z, k)
#  define SB_EVENT_INIT_ZVAL(z, k)			\
	do {									\
		MAKE_STD_ZVAL(z);					\
		params[k] = &z;						\
	} while (0)
#  define SB_EVENT_CLEAR_ZVAL(z)  zval_ptr_dtor(&z)
#  define SB_EVENT_DECL_RETVAL  
#  define SB_EVENT_DECL_RETVAL_PTR(z)  zval *z = NULL
#  define SB_EVENT_GET_RETVAL(z)  &z

#  define SB_IS_NULL_TYPE_RP(z)  (IS_NULL == Z_TYPE_P(z))
#  define SB_IS_BOOL_TYPE_RP(z)  (SB_IS_BOOL_TYPE_P(z))
#  define SB_IS_LONG_TYPE_RP(z)  (IS_LONG == Z_TYPE_P(z))
#  define SB_IS_DOUBLE_TYPE_RP(z)  (IS_DOUBLE == Z_TYPE_P(z))
#  define SB_IS_ARRAY_TYPE_RP(z)  (IS_ARRAY == Z_TYPE_P(z))
#  define SB_IS_STRING_TYPE_RP(z)  (IS_STRING == Z_TYPE_P(z))
#  define SB_IS_OBJECT_TYPE_RP(z)  (IS_OBJECT == Z_TYPE_P(z))
#  define SB_IS_CALLABLE_TYPE_RP(z)  (IS_CALLABLE == Z_TYPE_P(z))
#else
// for PHP 7.0 and later
#  define sb_str_size  size_t
#  define sb_zend_long  zend_long
#  define zend_uint  uint32_t

#  define SB_ISREF_DATETIME_P(z)  1
#  define SB_ISREF_STRUCT_P(z)  1
#  define SB_ISREF_OBJECT_P(z)  1

#  define SB_RETURN_STRINGL(s, l)				\
	do {										\
		RETVAL_STRINGL(s, l);					\
		efree(s);								\
		return;									\
	} while (0)
#  define SB_RETURN_STRINGL_DUP(s, l)  RETURN_STRINGL(s, l)

#  define SB_ZVAL_STRINGL(z, s, l)				\
	do {										\
		ZVAL_STRINGL(z, s, l);					\
		efree(s);								\
	} while (0)
#  define SB_ZVAL_STRINGL_UPDATE(z, s, l)	    \
	do {										\
		if (Z_STRVAL_P(z) == s)					\
			Z_STRLEN_P(z) = l;					\
		else {									\
			ZVAL_STRINGL(z, s, l);				\
			efree(s);							\
		}										\
	} while (0)
#  define SB_ZVAL_STRINGL_DUP(z, s, l)  ZVAL_STRINGL(z, s, l)

#  define SB_REGISTER_INTERNAL_CLASS_EX(class_entry, parent_ce)  zend_register_internal_class_ex(class_entry, parent_ce)
#  define SB_ACC_FINAL_CLASS  ZEND_ACC_FINAL

#  define SB_IS_BOOL_TYPE_P(z)  ((IS_FALSE == Z_TYPE_P(z)) || (IS_TRUE == Z_TYPE_P(z)))
#  define SB_BVAL_P(z)  (IS_TRUE == Z_TYPE_P(z))

#  define SB_EVENT_INIT_PARAMS(n)  zval params[n]
#  define SB_EVENT_INIT_ZVAL(z, k)  z = &params[k]
#  define SB_EVENT_INIT_ZVAL_REF(z, k)		\
	do {									\
		z = &params[k];						\
		ZVAL_NEW_REF(z, z);					\
  	} while (0)
#  define SB_EVENT_CLEAR_ZVAL(z)  zval_ptr_dtor(z)
#  define SB_EVENT_DECL_RETVAL  zval retval;
#  define SB_EVENT_DECL_RETVAL_PTR(z)  zval *z = &retval
#  define SB_EVENT_GET_RETVAL(z)  z

#  define SB_IS_NULL_TYPE_RP(z)  (Z_ISREF_P(z) ? (IS_NULL == Z_TYPE_P(Z_REFVAL_P(z))) : (IS_NULL == Z_TYPE_P(z)) )
#  define SB_IS_BOOL_TYPE_RP(z)  (Z_ISREF_P(z) ? SB_IS_BOOL_TYPE_P(Z_REFVAL_P(z)) : SB_IS_BOOL_TYPE_P(z) )
#  define SB_IS_LONG_TYPE_RP(z)  (Z_ISREF_P(z) ? (IS_LONG == Z_TYPE_P(Z_REFVAL_P(z))) : (IS_LONG == Z_TYPE_P(z)) )
#  define SB_IS_DOUBLE_TYPE_RP(z)  (Z_ISREF_P(z) ? (IS_DOUBLE == Z_TYPE_P(Z_REFVAL_P(z))) : (IS_DOUBLE == Z_TYPE_P(z)) )
#  define SB_IS_ARRAY_TYPE_RP(z)  (Z_ISREF_P(z) ? (IS_ARRAY == Z_TYPE_P(Z_REFVAL_P(z))) : (IS_ARRAY == Z_TYPE_P(z)) )
#  define SB_IS_STRING_TYPE_RP(z)  (Z_ISREF_P(z) ? (IS_STRING == Z_TYPE_P(Z_REFVAL_P(z))) : (IS_STRING == Z_TYPE_P(z)) )
#  define SB_IS_OBJECT_TYPE_RP(z)  (Z_ISREF_P(z) ? (IS_OBJECT == Z_TYPE_P(Z_REFVAL_P(z))) : (IS_OBJECT == Z_TYPE_P(z)) )
#  define SB_IS_CALLABLE_TYPE_RP(z)  (Z_ISREF_P(z) ? (IS_CALLABLE == Z_TYPE_P(Z_REFVAL_P(z))) : (IS_CALLABLE == Z_TYPE_P(z)) )
#endif

#if PHP_VERSION_ID < 50600L
// from zend_constants.h v5.6
#define REGISTER_NULL_CONSTANT(name, flags)  zend_register_null_constant((name), sizeof(name), (flags), module_number TSRMLS_CC)
#define REGISTER_NS_NULL_CONSTANT(ns, name, flags)  zend_register_null_constant(ZEND_NS_NAME(ns, name), sizeof(ZEND_NS_NAME(ns, name)), (flags), module_number TSRMLS_CC)

void zend_register_null_constant(const char *name, uint name_len, int flags, int module_number TSRMLS_DC);

// from zend_API.h v5.6
#define RETVAL_ZVAL_FAST(z) do {      \
	zval *_z = (z);                   \
	if (Z_ISREF_P(_z)) {              \
		RETVAL_ZVAL(_z, 1, 0);        \
	} else {                          \
		zval_ptr_dtor(&return_value); \
		Z_ADDREF_P(_z);               \
		*return_value_ptr = _z;       \
	}                                 \
} while (0)
#endif

#if PHP_VERSION_ID < 50400L
// from zend.h v5.4
#define IS_CALLABLE	10

#define ZVAL_COPY_VALUE(z, v)					\
	do {										\
		(z)->value = (v)->value;				\
		Z_TYPE_P(z) = Z_TYPE_P(v);				\
	} while (0)

#define INIT_PZVAL_COPY(z, v)					\
	do {										\
		ZVAL_COPY_VALUE(z, v);					\
		Z_SET_REFCOUNT_P(z, 1);					\
		Z_UNSET_ISREF_P(z);						\
	} while (0)

// from zend_API.h v5.4
#define ZEND_ARG_TYPE_INFO(pass_by_ref, name, type_hint, allow_null) { #name, sizeof(#name)-1, NULL, 0, type_hint, allow_null, pass_by_ref},
#endif

#if PHP_VERSION_ID < 50307L
#ifndef PHP_FE_END
#define PHP_FE_END      { NULL, NULL, NULL, 0, 0 }
#endif
#endif

// #define SB_DEFINE_FPC_SPECIFIC_METHODS

#define SB_USE_NS_FOR_CONSTANTS
#define SB_USE_NS_FOR_FUNCTIONS
// #define SB_USE_NS_FOR_CLASSES

// #define SB_DEBUG

#ifdef SB_DEBUG
#	define SB_OUTPUT_DEBUG(...) SBOutputDebugString("SBB: " ##__VA_ARGS__);
#else
#	define SB_OUTPUT_DEBUG(...)
#endif

#ifdef SB_USE_NS_FOR_CONSTANTS

#	define SB_REGISTER_NULL_CONSTANT(unitname, name, sbname)  REGISTER_NS_NULL_CONSTANT(#unitname, #name, CONST_CS | CONST_PERSISTENT)
#	define SB_REGISTER_BOOL_CONSTANT(unitname, name, sbname, bval)  REGISTER_NS_BOOL_CONSTANT(#unitname, #name, bval, CONST_CS | CONST_PERSISTENT)
#	define SB_REGISTER_LONG_CONSTANT(unitname, name, sbname, lval)  REGISTER_NS_LONG_CONSTANT(#unitname, #name, lval, CONST_CS | CONST_PERSISTENT)
#	define SB_REGISTER_DOUBLE_CONSTANT(unitname, name, sbname, dval)  REGISTER_NS_DOUBLE_CONSTANT(#unitname, #name, dval, CONST_CS | CONST_PERSISTENT)
#	define SB_REGISTER_STRING_CONSTANT(unitname, name, sbname, str)  REGISTER_NS_STRING_CONSTANT(#unitname, #name, str, CONST_CS | CONST_PERSISTENT)
#	define SB_REGISTER_STRINGL_CONSTANT(unitname, name, sbname, str, len)  REGISTER_NS_STRINGL_CONSTANT(#unitname, #name, str, len, CONST_CS | CONST_PERSISTENT)

#else

#	define SB_REGISTER_NULL_CONSTANT(unitname, name, sbname)  REGISTER_NULL_CONSTANT(#sbname, CONST_CS | CONST_PERSISTENT)
#	define SB_REGISTER_BOOL_CONSTANT(unitname, name, sbname, bval)  REGISTER_BOOL_CONSTANT(#sbname, bval, CONST_CS | CONST_PERSISTENT)
#	define SB_REGISTER_LONG_CONSTANT(unitname, name, sbname, lval)  REGISTER_LONG_CONSTANT(#sbname, lval, CONST_CS | CONST_PERSISTENT)
#	define SB_REGISTER_DOUBLE_CONSTANT(unitname, name, sbname, dval)  REGISTER_DOUBLE_CONSTANT(#sbname, dval, CONST_CS | CONST_PERSISTENT)
#	define SB_REGISTER_STRING_CONSTANT(unitname, name, sbname, str)  REGISTER_STRING_CONSTANT(#sbname, str, CONST_CS | CONST_PERSISTENT)
#	define SB_REGISTER_STRINGL_CONSTANT(unitname, name, sbname, str, len)  REGISTER_STRINGL_CONSTANT(#sbname, str, len, CONST_CS | CONST_PERSISTENT)

#endif

#define SB_DECLARE_CLASS_LONG_CONST(ce, name, value) zend_declare_class_constant_long( ce, name, sizeof(name) - 1, value TSRMLS_CC );

#ifdef SB_USE_NS_FOR_FUNCTIONS
#	define SB_PHP_FUNCTION(unitname, name)  PHP_FUNCTION(unitname##_##name)
#	define SB_PHP_FE(unitname, name, arg_info)  ZEND_NS_FALIAS(#unitname, name, unitname##_##name, arg_info)
#else
#	define SB_PHP_FUNCTION(unitname, name)  PHP_FUNCTION(#name)
#	define SB_PHP_FE(unitname, name, arg_info)  ZEND_FALIAS(name, #name, arg_info)
#endif

#ifdef SB_USE_NS_FOR_CLASSES
#	define SB_PHP_METHOD(classname, name)  PHP_METHOD(ZEND_NS_NAME("SecureBlackbox", classname), name)
#else
#	define SB_PHP_METHOD(classname, name)  ZEND_NAMED_FUNCTION(ZEND_MN(classname##_##name))
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define SB_ERROR_OK							0
#define SB_ERROR_RUNTIME					1
#define SB_ERROR_LIBRARY					2
#define SB_ERROR_INSUFFICIENT_BUFFER_SIZE	3
#define SB_ERROR_INVALID_BUFFER_SIZE		4
#define SB_ERROR_INVALID_PARAMETER			5
#define SB_ERROR_INTERNAL					6

#pragma pack(1)
typedef struct 
{
    void * dummy;
} TElClassHandleValue, *TElClassHandle;
//typedef uint32_t TElClassHandle;

typedef TElClassHandle TElCallbackStreamHandle;

#define SB_NULL_HANDLE	(TElClassHandle)NULL

typedef int32_t (SB_CALLBACK * TSBCallbackStreamReadFunc)(void * Buffer, int32_t Count, void * Data);
typedef int32_t (SB_CALLBACK * TSBCallbackStreamWriteFunc)(void * Buffer, int32_t Count, void * Data);
typedef int64_t (SB_CALLBACK * TSBCallbackStreamSeekFunc)(int64_t Offset, uint16_t Origin, void * Data);

typedef void (SB_CALLBACK * TSBEventFreeDataFunc)(void * Data);

#ifdef SB_DEBUG
void SBOutputDebugString(const char *format, ...);
#endif

SB_IMPORT uint32_t SB_APIENTRY SBGetLastError();
SB_IMPORT int32_t SB_APIENTRY SBGetLastErrorCode();
SB_IMPORT int32_t SB_APIENTRY SBGetLastSupplErrorCode();
SB_IMPORT uint32_t SB_APIENTRY SBGetLastErrorNameA(char * pstrBuffer, int32_t * nSize);
SB_IMPORT uint32_t SB_APIENTRY SBGetLastErrorMessageA(char * pstrBuffer, int32_t * nSize);
SB_IMPORT uint32_t SB_APIENTRY SBGetLastErrorStackTraceA(char * pstrBuffer, int32_t * nSize);

SB_IMPORT uint32_t SB_APIENTRY SBGetReturnStringA(int32_t index, char * pstrBuffer, int32_t * nSize);
SB_IMPORT uint32_t SB_APIENTRY SBGetReturnBuffer(int32_t index, void * pBuffer, int32_t * nSize);

SB_IMPORT uint32_t SB_APIENTRY SBSetEventReturnStringA(int32_t index, const char * pstrBuffer, int32_t nSize);
SB_IMPORT uint32_t SB_APIENTRY SBSetEventReturnBuffer(int32_t index, const void * pBuffer, int32_t nSize);

SB_IMPORT uint32_t SB_APIENTRY SBSetEventFirstReturnStringA(const char * pstrBuffer, int32_t nSize);
SB_IMPORT uint32_t SB_APIENTRY SBSetEventFirstReturnBuffer(const void * pBuffer, int32_t nSize);

SB_IMPORT uint32_t SB_APIENTRY SBCleanupEvents(void);
SB_IMPORT uint32_t SB_APIENTRY SBSetEventFreeDataCallback(TSBEventFreeDataFunc Func);

// For internal use:
SB_IMPORT uint32_t SB_APIENTRY SBGetLastReturnStringA(int32_t idProc, int32_t index, char * pstrBuffer, int32_t * nSize);
SB_IMPORT uint32_t SB_APIENTRY SBGetLastReturnBuffer(int32_t idProc, int32_t index, void * pBuffer, int32_t * nSize);

SB_IMPORT uint32_t SB_APIENTRY TElCallbackStream_Create(void * Data, TSBCallbackStreamReadFunc ReadFunc, TSBCallbackStreamWriteFunc WriteFunc, TSBCallbackStreamSeekFunc SeekFunc, TElCallbackStreamHandle * OutResult);

SB_IMPORT uint32_t SB_APIENTRY SBGetVCLStringA(void * pStr, char * pBuffer, int32_t * szBuffer);
SB_IMPORT uint32_t SB_APIENTRY SBSetVCLStringA(void ** pStr, char * pBuffer, int32_t szBuffer);

typedef int TElOwnHandle;

#define ohFalse 0
#define ohTrue 1
#define SB_OWN_HANDLE 1

#ifdef __cplusplus
};	/* extern "C" */
#endif

typedef struct _SBArrayZValInfo
{
	void * data;
	int len;
	int ownData;
	int dataType;
} SBArrayZValInfo, SBPointerZValInfo;

typedef struct _php_sbb_object
{
#if PHP_VERSION_ID < 70000L
    zend_object zo;
    TElClassHandle _Handle;
    TElOwnHandle _OwnHandle;
#else
	TElClassHandle _Handle;
	TElOwnHandle _OwnHandle;
	HashTable    *props;
	zend_object   std;
#endif
} php_sbb_object;

typedef struct _php_sbb_pointer
{
#if PHP_VERSION_ID < 70000L
	zend_object zo;
	void *data;
	size_t len;
	int ownData;
#else
	void *data;
	size_t len;
	int ownData;
	HashTable    *props;
	zend_object   std;
#endif
} php_sbb_pointer;

typedef struct _php_sbb_struct
{
#if PHP_VERSION_ID < 70000L
	zend_object zo;
	void *data;
	size_t len;
	int ownData;
#else
	void *data;
	size_t len;
	int ownData;
	HashTable    *props;
	zend_object   std;
#endif
} php_sbb_struct;

extern zend_class_entry *TSBPointer_ce_ptr;
extern zend_class_entry *TSBBaseStruct_ce_ptr;

extern zend_class_entry *TObject_ce_ptr;
extern zend_object_handlers TObject_handlers;
#if PHP_VERSION_ID < 70000L
zend_object_value PHP_TObject_New(zend_class_entry *class_type TSRMLS_DC);
#else
zend_object *PHP_TObject_New(zend_class_entry *class_type);
#endif

extern zend_class_entry *TSBBaseEnum_ce_ptr;
extern zend_class_entry *TSBBaseFlags_ce_ptr;

#if PHP_VERSION_ID < 70000L
#  define Z_SBOBJECT_P(zv)  (php_sbb_object *)zend_object_store_get_object(zv TSRMLS_CC)
#  define Z_SBPOINTER_P(zv)  (php_sbb_pointer *)zend_object_store_get_object(zv TSRMLS_CC)
#  define Z_SBSTRUCT_P(zv)  (php_sbb_struct *)zend_object_store_get_object(zv TSRMLS_CC)
#else

static inline php_sbb_object *php_sbb_object_obj_from_obj(zend_object *obj) {
	return (php_sbb_object*)((char*)(obj)-XtOffsetOf(php_sbb_object, std));
}

static inline php_sbb_pointer *php_sbb_pointer_obj_from_obj(zend_object *obj) {
	return (php_sbb_pointer*)((char*)(obj)-XtOffsetOf(php_sbb_pointer, std));
}

static inline php_sbb_struct *php_sbb_struct_obj_from_obj(zend_object *obj) {
	return (php_sbb_struct*)((char*)(obj)-XtOffsetOf(php_sbb_struct, std));
}

#  define Z_SBOBJECT_P(zv)  php_sbb_object_obj_from_obj(Z_OBJ_P((zv)))
#  define Z_SBPOINTER_P(zv)  php_sbb_pointer_obj_from_obj(Z_OBJ_P((zv)))
#  define Z_SBSTRUCT_P(zv)  php_sbb_struct_obj_from_obj(Z_OBJ_P((zv)))

#endif

SB_PHP_METHOD(TObject, __clone);
SB_PHP_METHOD(TObject, __get);
SB_PHP_METHOD(TObject, __set);
SB_PHP_METHOD(TObject, __isset);
SB_PHP_METHOD(TObject, detachHandle);
SB_PHP_METHOD(TObject, getOwnHandle);
SB_PHP_METHOD(TObject, setOwnHandle);
SB_PHP_METHOD(TObject, castTo);

SB_PHP_FUNCTION(SBUtils, BytesOfString);
SB_PHP_FUNCTION(SBUtils, StringOfBytes);

void SBInitArrayZValInfo(SBArrayZValInfo *info);
void SBClearArrayZValInfo(SBArrayZValInfo *info);
void SBFreeArrayZValInfo(SBArrayZValInfo *info);
void SBDetachDataFromZValAndResize(zval *arr, SBArrayZValInfo *info TSRMLS_DC);
void SBResizeArrayZVal(SBArrayZValInfo *info TSRMLS_DC);
int SBGetByteArrayFromZVal(zval *arr, SBArrayZValInfo *info TSRMLS_DC);
void SBSetByteArrayToZVal(SBArrayZValInfo *info, zval *arr);
void SBSetByteArrayToZValP(uint8_t * data, int32_t len, zval *arr);

int SBGetInt16ArrayFromZVal(zval *arr, SBArrayZValInfo *info TSRMLS_DC);
void SBSetInt16ArrayToZValP(int16_t * data, int32_t len, zval *arr);
void SBSetInt16ArrayToZVal(SBArrayZValInfo *info, zval *arr);
int SBGetInt32ArrayFromZVal(zval *arr, SBArrayZValInfo *info TSRMLS_DC);
void SBSetInt32ArrayToZVal(SBArrayZValInfo *info, zval *arr);
void SBSetInt32ArrayToZValP(int32_t * data, int32_t len, zval *arr);
int SBGetUInt32ArrayFromZVal(zval *arr, SBArrayZValInfo *info TSRMLS_DC);
void SBSetUInt32ArrayToZVal(SBArrayZValInfo *info, zval *arr);
void SBSetUInt32ArrayToZValP(uint32_t * data, int32_t len, zval *arr);
int SBGetInt64ArrayFromZVal(zval *arr, SBArrayZValInfo *info TSRMLS_DC);
void SBSetInt64ArrayToZValP(int64_t * data, int32_t len, zval *arr);
void SBSetInt64ArrayToZVal(SBArrayZValInfo *info, zval *arr);

int SBGetObjectArrayFromZVal(zval *arr, zend_class_entry *obj_ce, SBArrayZValInfo *info TSRMLS_DC);
void SBSetObjectArrayToZValP(TElClassHandle * data, int32_t len, zend_class_entry *obj_ce, zval *arr TSRMLS_DC);
void SBSetObjectArrayToZVal(SBArrayZValInfo *info, zend_class_entry *obj_ce, zval *arr TSRMLS_DC);
void SBSetStructArrayToZValP(void * data, int32_t len, size_t size, zend_class_entry *obj_ce, zval *arr TSRMLS_DC);

void * SBGetPointerValue(zval *ptr TSRMLS_DC);
int SBGetPointerFromZVal(zval *ptr, SBPointerZValInfo *info TSRMLS_DC);
void SBSetPointerToZVal(SBPointerZValInfo *info, zval *ptr);
void SBInitPointerObject(zval *ptr, void * data TSRMLS_DC);
void SBInitPointerZValInfo(zval *ptr, SBPointerZValInfo *info TSRMLS_DC);
void SBFreePointerZValInfo(SBPointerZValInfo *info);
void SBSetPointer(zval *obj, void *ptr TSRMLS_DC);

TElClassHandle SBGetObjectHandle(zval *obj TSRMLS_DC);
TElClassHandle SBGetObjectHandleCE(zval *obj, zend_class_entry *obj_ce TSRMLS_DC);
void SBSetObjectHandle(zval *obj, const TElClassHandle handle, const TElOwnHandle ownHandle TSRMLS_DC);
void SBInitObject(zval *obj, zend_class_entry *obj_ce, const TElClassHandle handle TSRMLS_DC);
void SBUpdateObjectHandle(zval *obj, const TElClassHandle handle TSRMLS_DC);
void SBDetachObjectHandle(zval *obj TSRMLS_DC);
void SBDetachObjectHandleIfUniqueZVal(zval *obj TSRMLS_DC);

int SBClassEntryIsPointerOrObject(zend_class_entry *ce);
void * SBGetStructPointer(zval *obj TSRMLS_DC);
void SBGetStructPointerValueTo(zval *obj, zend_class_entry *struct_ce, void * dst_data TSRMLS_DC);
void SBSetStruct(zval *obj, void *data, size_t size TSRMLS_DC);
void SBSetStructPointer(zval *obj, void *data, size_t size TSRMLS_DC);
void SBInitStructObject(zval *obj, zend_class_entry *struct_ce, void * data, size_t size TSRMLS_DC);

void SBStuctGetFieldInt8(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctGetFieldUInt8(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctGetFieldInt16(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctGetFieldUInt16(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctGetFieldInt32(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctGetFieldUInt32(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctGetFieldInt64(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctGetFieldUInt64(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctSetFieldInt8(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctSetFieldUInt8(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctSetFieldInt16(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctSetFieldUInt16(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctSetFieldInt32(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctSetFieldUInt32(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctSetFieldInt64(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctSetFieldUInt64(INTERNAL_FUNCTION_PARAMETERS, int field_offset);

void SBStuctGetFieldStringA(INTERNAL_FUNCTION_PARAMETERS, int field_offset);
void SBStuctSetFieldStringA(INTERNAL_FUNCTION_PARAMETERS, int field_offset);

int64_t SBGetDateTime(zval *obj TSRMLS_DC);
void SBSetDateTime(zval *obj, int64_t dt TSRMLS_DC);

void * SBSetEventData(zval * func /*, zend_class_entry * intf_ce */ TSRMLS_DC);
void SB_CALLBACK SBEventFreeData(void * data);
#if PHP_VERSION_ID < 70000L
int SBCallEvent(zval * func, zval **retval_ptr_ptr, zend_uint param_count, zval **params[] TSRMLS_DC);
#else
void SBCallEvent(zval * func, zval *retval, int param_count, zval *params);
#endif

void SBCheckError(uint32_t error TSRMLS_DC);
void SBThrowException(uint32_t error TSRMLS_DC);
void SBErrorExpectsArguments(const char *str TSRMLS_DC);

void Register_Core(TSRMLS_D);

#pragma pack(pop)

#endif  /* __INC_SBPHPCORE */
