#ifndef __INC_SBPIVKEY
#define __INC_SBPIVKEY

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#ifdef SB_WINDOWS
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbx509.h"
#include "sbconstants.h"
#include "sbscwin.h"
#endif

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef SB_WINDOWS
typedef SCARD_READERSTATE TElReaderState;

#ifdef __cplusplus
};	/* extern "C" */
#endif

SB_PHP_FUNCTION(SBPIVKey, PivECDSASignature);
SB_PHP_FUNCTION(SBPIVKey, PivRSASignature);
SB_PHP_FUNCTION(SBPIVKey, PivEncryptAES128);
SB_PHP_FUNCTION(SBPIVKey, PivEncryptAES192);
SB_PHP_FUNCTION(SBPIVKey, PivEncryptAES256);
SB_PHP_FUNCTION(SBPIVKey, PivEncrypt3DES);
SB_PHP_FUNCTION(SBPIVKey, PivDecryptAES128);
SB_PHP_FUNCTION(SBPIVKey, PivDecryptAES192);
SB_PHP_FUNCTION(SBPIVKey, PivDecryptAES256);
SB_PHP_FUNCTION(SBPIVKey, PivDecrypt3DES);
SB_PHP_FUNCTION(SBPIVKey, PivGetAuthX509Cert);
SB_PHP_FUNCTION(SBPIVKey, SCCardGetCardHandle);
SB_PHP_FUNCTION(SBPIVKey, PivTestKeyByHandle);
SB_PHP_FUNCTION(SBPIVKey, PivIsVerifyNeeded);
SB_PHP_FUNCTION(SBPIVKey, GetPIVKeyErrorNameByCode);
SB_PHP_FUNCTION(SBPIVKey, PivGetStatus);
SB_PHP_FUNCTION(SBPIVKey, PivGetCardCapabilityContainer);
SB_PHP_FUNCTION(SBPIVKey, PivSelectCardManager);
SB_PHP_FUNCTION(SBPIVKey, PivSelectGlobalPlatformPackage);
SB_PHP_FUNCTION(SBPIVKey, PivMutualAuth);
SB_PHP_FUNCTION(SBPIVKey, PivUnblockApplicationPin);
SB_PHP_FUNCTION(SBPIVKey, PivGenerateECDSA256KeyPair);
SB_PHP_FUNCTION(SBPIVKey, PivGenerateECDSA384KeyPair);
SB_PHP_FUNCTION(SBPIVKey, PivGenerateRSAKeyPair);
SB_PHP_FUNCTION(SBPIVKey, PivApplicationAdminAuth);
SB_PHP_FUNCTION(SBPIVKey, SCEstablishContext);
SB_PHP_FUNCTION(SBPIVKey, SCReleaseContext);
SB_PHP_FUNCTION(SBPIVKey, SCListReaders);
SB_PHP_FUNCTION(SBPIVKey, SCGetReaderStatus);
SB_PHP_FUNCTION(SBPIVKey, SCIsCardInserted);
SB_PHP_FUNCTION(SBPIVKey, SCCardConnect);
SB_PHP_FUNCTION(SBPIVKey, SCCardReconnect);
SB_PHP_FUNCTION(SBPIVKey, SCCardDisconnect);
SB_PHP_FUNCTION(SBPIVKey, SCGetIFDSerialNumber);
SB_PHP_FUNCTION(SBPIVKey, SCSuccess);
SB_PHP_FUNCTION(SBPIVKey, PivVerifyGlobal);
SB_PHP_FUNCTION(SBPIVKey, PivVerifyCardApp);
SB_PHP_FUNCTION(SBPIVKey, PivSelectDefaultApplication);
SB_PHP_FUNCTION(SBPIVKey, PivGetSMkey);
SB_PHP_FUNCTION(SBPIVKey, PivGetPairingCodeRefData);
SB_PHP_FUNCTION(SBPIVKey, PivGetDiscoveryObject);
SB_PHP_FUNCTION(SBPIVKey, PivGetCHUID);
SB_PHP_FUNCTION(SBPIVKey, PivTestAuthCert9A);
SB_PHP_FUNCTION(SBPIVKey, PivTestAuthCert9C);
SB_PHP_FUNCTION(SBPIVKey, PivTestAuthCert9D);
SB_PHP_FUNCTION(SBPIVKey, PivTestAuthCert9E);
SB_PHP_FUNCTION(SBPIVKey, PivCardHolderAuthVCI);
SB_PHP_FUNCTION(SBPIVKey, PivPutPairingCodeRefData);
void Register_SBPIVKey_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_PIVKEY
#ifndef CPU64
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivECDSASignature(uint32_t hCard, uint32_t hKey, void * inbuf, int32_t size, const uint8_t poutbuf[], int32_t szoutbuf, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivRSASignature(uint32_t hCard, uint32_t hKey, void * inbuf, int32_t size, const uint8_t poutbuf[], int32_t szoutbuf, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivEncryptAES128(uint32_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivEncryptAES192(uint32_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivEncryptAES256(uint32_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivEncrypt3DES(uint32_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivDecryptAES128(uint32_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivDecryptAES192(uint32_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivDecryptAES256(uint32_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivDecrypt3DES(uint32_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGetAuthX509Cert(uint32_t hCard, uint32_t hKey, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCCardGetCardHandle(const char * pcReader, int32_t szReader, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivTestKeyByHandle(uint32_t hCard, uint32_t hKey, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivIsVerifyNeeded(uint32_t hCard, uint8_t * VerifyCounterLeft, int8_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivECDSASignature(uint64_t hCard, uint32_t hKey, void * inbuf, int32_t size, const uint8_t poutbuf[], int32_t szoutbuf, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivRSASignature(uint64_t hCard, uint32_t hKey, void * inbuf, int32_t size, const uint8_t poutbuf[], int32_t szoutbuf, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivEncryptAES128(uint64_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivEncryptAES192(uint64_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivEncryptAES256(uint64_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivEncrypt3DES(uint64_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivDecryptAES128(uint64_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivDecryptAES192(uint64_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivDecryptAES256(uint64_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivDecrypt3DES(uint64_t hCard, void * inbuf, int32_t size, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGetAuthX509Cert(uint64_t hCard, uint32_t hKey, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCCardGetCardHandle(const char * pcReader, int32_t szReader, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivTestKeyByHandle(uint64_t hCard, uint32_t hKey, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivIsVerifyNeeded(uint64_t hCard, uint8_t * VerifyCounterLeft, int8_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_GetPIVKeyErrorNameByCode(uint32_t Code, char * pcOutResult, int32_t * szOutResult);
#ifndef CPU64
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGetStatus(uint32_t hCard, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGetCardCapabilityContainer(uint32_t hCard, uint8_t pData[], int32_t * szData, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivSelectCardManager(uint32_t hCard, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivSelectGlobalPlatformPackage(uint32_t hCard, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivMutualAuth(uint32_t hCard, uint8_t Key, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivUnblockApplicationPin(uint32_t hCard, const char * pcPUK, int32_t szPUK, const char * pcnewPin, int32_t sznewPin, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGenerateECDSA256KeyPair(uint32_t hCard, uint32_t hKey, uint8_t ppublickey[], int32_t * szpublickey, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGenerateECDSA384KeyPair(uint32_t hCard, uint32_t hKey, uint8_t ppublickey[], int32_t * szpublickey, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGenerateRSAKeyPair(uint32_t hCard, uint32_t hKey, uint8_t pmodulus[], int32_t * szmodulus, uint8_t pexponent[], int32_t * szexponent, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivApplicationAdminAuth(uint32_t hCard, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCEstablishContext(uint32_t * Ctx, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCReleaseContext(uint32_t Ctx);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCListReaders(uint32_t Ctx, TStringListHandle ReaderList, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCGetReaderStatus(uint32_t Ctx, const char * pcReader, int32_t szReader, SCARD_READERSTATE * ReaderState, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGetStatus(uint64_t hCard, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGetCardCapabilityContainer(uint64_t hCard, uint8_t pData[], int32_t * szData, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivSelectCardManager(uint64_t hCard, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivSelectGlobalPlatformPackage(uint64_t hCard, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivMutualAuth(uint64_t hCard, uint8_t Key, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivUnblockApplicationPin(uint64_t hCard, const char * pcPUK, int32_t szPUK, const char * pcnewPin, int32_t sznewPin, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGenerateECDSA256KeyPair(uint64_t hCard, uint32_t hKey, uint8_t ppublickey[], int32_t * szpublickey, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGenerateECDSA384KeyPair(uint64_t hCard, uint32_t hKey, uint8_t ppublickey[], int32_t * szpublickey, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGenerateRSAKeyPair(uint64_t hCard, uint32_t hKey, uint8_t pmodulus[], int32_t * szmodulus, uint8_t pexponent[], int32_t * szexponent, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivApplicationAdminAuth(uint64_t hCard, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCEstablishContext(uint64_t * Ctx, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCReleaseContext(uint64_t Ctx);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCListReaders(uint64_t Ctx, TStringListHandle ReaderList, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCGetReaderStatus(uint64_t Ctx, const char * pcReader, int32_t szReader, SCARD_READERSTATE * ReaderState, uint32_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCIsCardInserted(SCARD_READERSTATE * Reader, int8_t * OutResult);
#ifndef CPU64
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCCardConnect(uint32_t Ctx, SCARD_READERSTATE * Reader, uint32_t * hCardHandle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCCardReconnect(uint32_t hCardHandle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCCardDisconnect(uint32_t hCardHandle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCGetIFDSerialNumber(uint32_t Ctx, uint32_t hCard, uint8_t pSerialNo[], int32_t * szSerialNo, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCCardConnect(uint64_t Ctx, SCARD_READERSTATE * Reader, uint64_t * hCardHandle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCCardReconnect(uint64_t hCardHandle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCCardDisconnect(uint64_t hCardHandle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCGetIFDSerialNumber(uint64_t Ctx, uint64_t hCard, uint8_t pSerialNo[], int32_t * szSerialNo, uint32_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_SCSuccess(uint32_t status, int8_t * OutResult);
#ifndef CPU64
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivVerifyGlobal(uint32_t hCard, const char * pcPinCode, int32_t szPinCode, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivVerifyCardApp(uint32_t hCard, const char * pcPinCode, int32_t szPinCode, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivSelectDefaultApplication(uint32_t hCard, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGetSMkey(uint32_t hCard, uint8_t poutbuf[], int32_t * szoutbuf, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGetPairingCodeRefData(uint32_t hCard, uint8_t poutbuf[], int32_t * szoutbuf, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGetDiscoveryObject(uint32_t hCard, uint8_t poutbuf[], int32_t * szoutbuf, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGetCHUID(uint32_t hCard, uint8_t pGuid[], int32_t * szGuid, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivTestAuthCert9A(uint32_t hCard, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivTestAuthCert9C(uint32_t hCard, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivTestAuthCert9D(uint32_t hCard, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivTestAuthCert9E(uint32_t hCard, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivCardHolderAuthVCI(uint32_t hCard, uint8_t pinbuf[], int32_t * szinbuf, uint8_t poutbuf[], int32_t * szoutbuf, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivPutPairingCodeRefData(uint32_t hCard, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivVerifyGlobal(uint64_t hCard, const char * pcPinCode, int32_t szPinCode, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivVerifyCardApp(uint64_t hCard, const char * pcPinCode, int32_t szPinCode, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivSelectDefaultApplication(uint64_t hCard, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGetSMkey(uint64_t hCard, uint8_t poutbuf[], int32_t * szoutbuf, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGetPairingCodeRefData(uint64_t hCard, uint8_t poutbuf[], int32_t * szoutbuf, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGetDiscoveryObject(uint64_t hCard, uint8_t poutbuf[], int32_t * szoutbuf, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivGetCHUID(uint64_t hCard, uint8_t pGuid[], int32_t * szGuid, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivTestAuthCert9A(uint64_t hCard, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivTestAuthCert9C(uint64_t hCard, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivTestAuthCert9D(uint64_t hCard, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivTestAuthCert9E(uint64_t hCard, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivCardHolderAuthVCI(uint64_t hCard, uint8_t pinbuf[], int32_t * szinbuf, uint8_t poutbuf[], int32_t * szoutbuf, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPIVKey_PivPutPairingCodeRefData(uint64_t hCard, uint32_t * OutResult);
#endif
#endif /* SB_USE_GLOBAL_PROCS_PIVKEY */
#endif

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPIVKEY */
