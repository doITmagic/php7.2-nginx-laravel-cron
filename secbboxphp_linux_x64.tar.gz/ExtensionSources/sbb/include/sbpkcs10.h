#ifndef __INC_SBPKCS10
#define __INC_SBPKCS10

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbcustomcrypto.h"
#include "sbpublickeycrypto.h"
#include "sbalgorithmidentifier.h"
#include "sbmath.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbsymmetriccrypto.h"
#include "sbencoding.h"
#include "sbconstants.h"
#include "sbrdn.h"
#include "sbpkcs7utils.h"
#include "sbstreams.h"
#include "sbx509ext.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElCertificateRequestHandle;

typedef TElCertificateRequestHandle ElCertificateRequestHandle;

typedef uint8_t TSBCertReqFileFormatRaw;

typedef enum
{
	crfUnknown = 0,
	crfDER = 1,
	crfPEM = 2
} TSBCertReqFileFormat;

typedef uint8_t TSBCertificateRequestOptionRaw;

typedef enum
{
	croGenerateKeyIdentifier = 0,
	croUseMSExtensionIdentifier = 1,
	croAutoAdjustTagTypes = 2
} TSBCertificateRequestOption;

typedef uint32_t TSBCertificateRequestOptionsRaw;

typedef enum 
{
	f_croGenerateKeyIdentifier = 1,
	f_croUseMSExtensionIdentifier = 2,
	f_croAutoAdjustTagTypes = 4
} TSBCertificateRequestOptions;

#ifdef SB_USE_CLASS_TELCERTIFICATEREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_DetectCertReqFileFormat(const char * pcFileName, int32_t szFileName, TSBCertReqFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_DetectCertReqFileFormat_1(TElCertificateRequestHandle _Handle, const char * pcFileName, int32_t szFileName, TSBCertReqFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_DetectCertReqFileFormat_2(TStreamHandle Stream, TSBCertReqFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_DetectCertReqFileFormat_3(TElCertificateRequestHandle _Handle, TStreamHandle Stream, TSBCertReqFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_LoadFromBuffer(TElCertificateRequestHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_LoadFromBufferPEM(TElCertificateRequestHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_LoadFromStream(TElCertificateRequestHandle _Handle, TStreamHandle Stream, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_LoadFromStreamPEM(TElCertificateRequestHandle _Handle, TStreamHandle Stream, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_Generate(TElCertificateRequestHandle _Handle, int32_t PublicKeyAlgorithm, int32_t Bits, int32_t SignatureAlgorithm);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_Generate_1(TElCertificateRequestHandle _Handle, TElAlgorithmIdentifierHandle PublicKeyAlgorithm, int32_t Bits, TElAlgorithmIdentifierHandle SignatureAlgorithm);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_SaveToStream(TElCertificateRequestHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_SaveKeyToStream(TElCertificateRequestHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_SaveToBuffer(TElCertificateRequestHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_SaveToBufferPEM(TElCertificateRequestHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_SaveToStreamPEM(TElCertificateRequestHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_SaveKeyToStreamPEM(TElCertificateRequestHandle _Handle, TStreamHandle Stream, const char * pcPassphrase, int32_t szPassphrase);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_SaveKeyToStreamPEM_1(TElCertificateRequestHandle _Handle, TStreamHandle Stream, int32_t EncryptionAlgorithm, TSBSymmetricCryptoModeRaw EncryptionMode, const char * pcPassphrase, int32_t szPassphrase);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_SaveKeyToBufferPEM(TElCertificateRequestHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassphrase, int32_t szPassphrase, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_SaveKeyToBufferPEM_1(TElCertificateRequestHandle _Handle, void * Buffer, int32_t EncryptionAlgorithm, TSBSymmetricCryptoModeRaw EncryptionMode, int32_t * Size, const char * pcPassphrase, int32_t szPassphrase, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_SaveKeyToBufferPVK(TElCertificateRequestHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassword, int32_t szPassword, int8_t UseStrongEncryption, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_SaveKeyToStreamPVK(TElCertificateRequestHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int8_t UseStrongEncryption, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_LoadKeyFromBuffer(TElCertificateRequestHandle _Handle, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_LoadKeyFromBufferPEM(TElCertificateRequestHandle _Handle, void * Buffer, int32_t Size, const char * pcPassphrase, int32_t szPassphrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_LoadKeyFromStream(TElCertificateRequestHandle _Handle, TStreamHandle Stream, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_LoadKeyFromStreamPEM(TElCertificateRequestHandle _Handle, TStreamHandle Stream, const char * pcPassphrase, int32_t szPassphrase, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_ValidateSignature(TElCertificateRequestHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_GetRSAParams(TElCertificateRequestHandle _Handle, void * PublicModulus, int32_t * PublicModulusSize, void * PublicExponent, int32_t * PublicExponentSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_GetDSAParams(TElCertificateRequestHandle _Handle, void * P, int32_t * PSize, void * Q, int32_t * QSize, void * G, int32_t * GSize, void * Y, int32_t * YSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_SaveKeyToBuffer(TElCertificateRequestHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_GetPrivateKey(TElCertificateRequestHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_SetKeyMaterial(TElCertificateRequestHandle _Handle, TElPublicKeyMaterialHandle KeyMaterial);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_get_Subject(TElCertificateRequestHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_get_Attributes(TElCertificateRequestHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_get_Version(TElCertificateRequestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_set_Version(TElCertificateRequestHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_get_PublicKeyAlgorithm(TElCertificateRequestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_get_SignatureAlgorithm(TElCertificateRequestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_get_PublicKeyAlgorithmIdentifier(TElCertificateRequestHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_get_SignatureAlgorithmIdentifier(TElCertificateRequestHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_get_Extensions(TElCertificateRequestHandle _Handle, TElCertificateExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_get_PublicKeySize(TElCertificateRequestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_get_Options(TElCertificateRequestHandle _Handle, TSBCertificateRequestOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_set_Options(TElCertificateRequestHandle _Handle, TSBCertificateRequestOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_get_PreserveKeyMaterial(TElCertificateRequestHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_set_PreserveKeyMaterial(TElCertificateRequestHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_get_KeyMaterial(TElCertificateRequestHandle _Handle, TElPublicKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateRequest_Create(TComponentHandle Owner, TElCertificateRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELCERTIFICATEREQUEST */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElCertificateRequest_ce_ptr;

void Register_TElCertificateRequest(TSRMLS_D);
void Register_SBPKCS10_Enum_Flags(TSRMLS_D);
void Register_SBPKCS10_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPKCS10 */

