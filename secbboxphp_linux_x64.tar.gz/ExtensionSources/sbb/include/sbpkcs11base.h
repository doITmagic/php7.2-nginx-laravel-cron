#ifndef __INC_SBPKCS11BASE
#define __INC_SBPKCS11BASE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbdynstruct.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbrandom.h"
#include "sbconstants.h"
#include "sbpkcs11common.h"
#include "sbcustomcrypto.h"
#include "sbcryptoprov.h"
#include "sbcryptoprovutils.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbrdn.h"
#include "sbsharedresource.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_TOKEN_PROP_FIRST 	0
#define SB_TOKEN_PROP_TOKEN_ATTR_UNSUPPORTED 	0
#define SB_TOKEN_PROP_REQUIRES_KEYS_TO_BE_ADDED_PRIOR_TO_CERTS 	1
#define SB_TOKEN_PROP_REQUIRES_SENSITIVE_FLAG_FOR_PRIVATE_KEY 	2
#define SB_TOKEN_PROP_REQUIRES_EXTRACTABLE_FLAG_FOR_PRIVATE_KEY 	3
#define SB_TOKEN_PROP_SUPPORTS_MODIFIABLE_FLAG_FOR_OBJECTS 	4
#define SB_TOKEN_PROP_REQUIRES_PUBLIC_KEYS_TO_BE_ADDED_PRIOR_TO_PRIVATE_KEYS 	5
#define SB_TOKEN_PROP_LAST 	5
#define SB_PROCACCESS_FLG_AUTO 	0
#define SB_PROCACCESS_FLG_AUTO_RELAXED 	1
#define SB_PROCACCESS_FLG_GETFUNCTIONLIST 	2
#define SB_PROCACCESS_FLG_GETPROCADDRESS 	3
#define SB_PKCS11_ON_DEMAND_SESSION_HANDLE_START 	251658241
#define SB_SPKCS11ProviderNotOpened 	"PKCS#11 storage is not opened"
#define SB_SNoPKCS11ProviderSpecified 	"No PKCS#11 provider DLL has been specified"
#define SB_SPKCS11ProviderNoFunctions 	"PKCS#11 provider DLL doesn\'t export all required functions"
#define SB_SPKCS11ProviderNotFound 	"PKCS#11 provider DLL could not be found or loaded"
#define SB_SPKCS11ProviderError 	"PKCS#11 provider DLL function returned fatal error"
#ifndef SB_SIndexOutOfBounds
#define SB_SIndexOutOfBounds 	"Index out of bounds"
#endif
#define SB_SPKCS11Error 	"PKCS#11 error"
#ifndef SB_SInvalidAttributeValue
#define SB_SInvalidAttributeValue 	"Invalid object attribute value"
#endif
#define SB_SPKCS11FunctionError 	"PKCS#11 error in function #%d"
#define SB_SPKCS11FunctionErrorStr 	"PKCS#11 error %s in function %s"
#define SB_SAlgorithmDoesNotSupportEncryption 	"Certificate algorithm (%d) does not support encryption"
#define SB_SAlgorithmDoesNotSupportSigning 	"Certificate algorithm (%d) does not support signing"
#ifndef SB_SInternalError
#define SB_SInternalError 	"Internal error"
#endif
#define SB_SNotPKCS11Certificate 	"Not a PKCS#11 certificate"
#define SB_SObjectDoesNotBelongToSession 	"Object does not belong to any PKCS #11 session"
#define SB_SUnsupportedObjectType 	"Unsupported object type"
#ifndef SB_SBufferTooSmall
#define SB_SBufferTooSmall 	"Buffer is too small"
#endif
#define SB_SObjectNotFound 	"Object not found"
#define SB_SNumberOfSlotsChanged 	"Number of available slots changed"
#define SB_SNotInOnDemandMode 	"The session is running in non on-demand mode"
#define SB_SOnlyOneSessionAllowedInOnDemandMode 	"Only one session is allowed in on-demand mode"
#define SB_SAlreadyLoggedIn 	"Already logged in"
#define SB_SNotLoggedIn 	"Not logged in"
#define SB_SReadOnlySessionsOnlyAllowedInOnDemandMode 	"Read-only sessions are only allowed in on-demand mode"
#define SB_SUpdateFailedObjectsChanged 	"Update failed (one or more objects have been modified outside the application)"
#define SB_SNotImplemented 	"Not implemented"
#define SB_SPKCS11AutoDetectFailed 	"PKCS#11 structures alignment autodetection failed"

typedef TElClassHandle TElPKCS11ModuleHandle;

typedef TElClassHandle TElPKCS11SlotInfoHandle;

typedef TElClassHandle TElPKCS11SessionInfoHandle;

typedef TElClassHandle TElPKCS11ConsumerHandle;

typedef TElPKCS11ConsumerHandle ElPKCS11ConsumerHandle;

typedef TElClassHandle TElPKCS11AttributeListHandle;

typedef TElClassHandle TElPKCS11ObjectHandle;

typedef TElClassHandle TElPKCS11DataObjectHandle;

typedef TElClassHandle TElPKCS11CertificateObjectHandle;

typedef TElClassHandle TElPKCS11X509CertificateObjectHandle;

typedef TElClassHandle TElPKCS11WTLSCertificateObjectHandle;

typedef TElClassHandle TElPKCS11X509AttributeCertificateObjectHandle;

typedef TElClassHandle TElPKCS11KeyObjectHandle;

typedef TElClassHandle TElPKCS11PublicKeyObjectHandle;

typedef TElClassHandle TElPKCS11PrivateKeyObjectHandle;

typedef TElClassHandle TElPKCS11SecretKeyObjectHandle;

typedef TElClassHandle TElPKCS11DomainParametersObjectHandle;

typedef TElClassHandle TElPKCS11UtilsHandle;

typedef TElClassHandle TElPKCS11NSSParamsHandle;

typedef TElClassHandle TElPKCS11ModuleListHandle;

typedef TElPKCS11ModuleListHandle ElPKCS11ModuleListHandle;

typedef TElClassHandle TElPKCS11AlgorithmInfoHandle;

typedef TElClassHandle TElPKCS11AlgorithmConverterHandle;

typedef TElClassHandle TElSlotEventMonitoringThreadHandle;

typedef TElClassHandle TElAttributesHandle;

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GetFunctionListFunc)(void * (* FunctionList), uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GetFunctionListFunc)(void * (* FunctionList), uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11NotifyCallbackFunc)(uint32_t hSession, uint32_t event, void * pApplication, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11NotifyCallbackFunc)(uint64_t hSession, uint64_t event, void * pApplication, uint64_t * OutResult);
#endif

typedef TPKCS11NotifyCallbackFunc * SB_CK_NOTIFY;

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11InitializeFunc)(TPKCS11InitializeArgsHandle pArgs, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11InitializeFunc)(TPKCS11InitializeArgsHandle pArgs, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11FinalizeFunc)(void * pReserved, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11FinalizeFunc)(void * pReserved, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GetInfoFunc)(void * pInfo, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GetInfoFunc)(void * pInfo, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GetSlotListFunc)(uint8_t tokenPresent, uint32_t * pSlotList, uint32_t * pulCount, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GetSlotListFunc)(uint8_t tokenPresent, uint64_t * pSlotList, uint64_t * pulCount, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GetSlotInfoFunc)(uint32_t slotID, void * pInfo, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GetSlotInfoFunc)(uint64_t slotID, void * pInfo, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GetTokenInfoFunc)(uint32_t slotID, void * pInfo, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GetTokenInfoFunc)(uint64_t slotID, void * pInfo, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11OpenSessionFunc)(uint32_t slotID, uint32_t flags, void * CallbackData, void * NotifyProc, uint32_t * SessionHandle, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11OpenSessionFunc)(uint64_t slotID, uint64_t flags, void * CallbackData, void * NotifyProc, uint64_t * SessionHandle, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GetSessionInfoFunc)(uint32_t hSession, void * pInfo, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GetSessionInfoFunc)(uint64_t hSession, void * pInfo, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11CloseSessionFunc)(uint32_t hSession, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11CloseSessionFunc)(uint64_t hSession, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11LoginFunc)(uint32_t hSession, uint32_t userType, char * pPin, uint32_t ulPinLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11LoginFunc)(uint64_t hSession, uint64_t userType, char * pPin, uint64_t ulPinLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11LogoutFunc)(uint32_t hSession, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11LogoutFunc)(uint64_t hSession, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11FindObjectsInitFunc)(uint32_t hSession, TPKCS11AttributeHandle pAttributes, uint32_t ulCount, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11FindObjectsInitFunc)(uint64_t hSession, TPKCS11AttributeHandle pAttributes, uint64_t ulCount, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11FindObjectsFunc)(uint32_t hSession, uint32_t * phObject, uint32_t ulMaxObjectCount, uint32_t * pulObjectCount, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11FindObjectsFunc)(uint64_t hSession, uint64_t * phObject, uint64_t ulMaxObjectCount, uint64_t * pulObjectCount, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11FindObjectsFinalFunc)(uint32_t hSession, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11FindObjectsFinalFunc)(uint64_t hSession, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GetAttributeValueFunc)(uint32_t hSession, uint32_t hObject, void * pTemplate, uint32_t ulCount, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GetAttributeValueFunc)(uint64_t hSession, uint64_t hObject, void * pTemplate, uint64_t ulCount, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11DestroyObjectFunc)(uint32_t hSession, uint32_t hObject, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11DestroyObjectFunc)(uint64_t hSession, uint64_t hObject, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11CreateObjectFunc)(uint32_t hSession, TPKCS11AttributeHandle pTemplate, uint32_t ulCount, uint32_t * hObject, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11CreateObjectFunc)(uint64_t hSession, TPKCS11AttributeHandle pTemplate, uint64_t ulCount, uint64_t * hObject, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11SignInitFunc)(uint32_t hSession, SB_CK_MECHANISMHandle pMechanism, uint32_t hKey, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11SignInitFunc)(uint64_t hSession, SB_CK_MECHANISMHandle pMechanism, uint64_t hKey, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11SignFunc)(uint32_t hSession, uint8_t * pData, uint32_t ulDataLen, uint8_t * pSignature, uint32_t * pulSignatureLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11SignFunc)(uint64_t hSession, uint8_t * pData, uint64_t ulDataLen, uint8_t * pSignature, uint64_t * pulSignatureLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11DecryptInitFunc)(uint32_t hSession, SB_CK_MECHANISMHandle pMechanism, uint32_t hKey, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11DecryptInitFunc)(uint64_t hSession, SB_CK_MECHANISMHandle pMechanism, uint64_t hKey, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11DecryptFunc)(uint32_t hSession, uint8_t * pEncryptedData, uint32_t ulEncryptedDataLen, uint8_t * pData, uint32_t * pulDataLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11DecryptFunc)(uint64_t hSession, uint8_t * pEncryptedData, uint64_t ulEncryptedDataLen, uint8_t * pData, uint64_t * pulDataLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11WaitForSlotEventFunc)(uint32_t flags, uint32_t * pSlot, void * pReserved, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11WaitForSlotEventFunc)(uint64_t flags, uint64_t * pSlot, void * pReserved, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GetMechanismListFunc)(uint32_t slotID, uint32_t * pMechanismList, uint32_t * pulCount, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GetMechanismListFunc)(uint64_t slotID, uint64_t * pMechanismList, uint64_t * pulCount, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GetMechanismInfoFunc)(uint32_t slotID, uint32_t mechanism_type, void * pInfo, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GetMechanismInfoFunc)(uint64_t slotID, uint64_t mechanism_type, void * pInfo, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11InitTokenFunc)(uint32_t slotID, char * pPin, uint32_t ulPinLen, char * pLabel, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11InitTokenFunc)(uint64_t slotID, char * pPin, uint64_t ulPinLen, char * pLabel, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11InitPINFunc)(uint32_t hSession, char * pPin, uint32_t ulPinLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11InitPINFunc)(uint64_t hSession, char * pPin, uint64_t ulPinLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11SetPINFunc)(uint32_t hSession, char * pOldPin, uint32_t ulOldLen, char * pNewPin, uint32_t ulNewLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11SetPINFunc)(uint64_t hSession, char * pOldPin, uint64_t ulOldLen, char * pNewPin, uint64_t ulNewLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11CloseAllSessionsFunc)(uint32_t slotID, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11CloseAllSessionsFunc)(uint64_t slotID, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GetOperationStateFunc)(uint32_t hSession, uint8_t * pOperationState, uint32_t * pulOperationStateLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GetOperationStateFunc)(uint64_t hSession, uint8_t * pOperationState, uint64_t * pulOperationStateLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11SetOperationStateFunc)(uint32_t hSession, uint8_t * pOperationState, uint32_t ulOperationStateLen, uint32_t hEncryptionKey, uint32_t hAuthenticationKey, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11SetOperationStateFunc)(uint64_t hSession, uint8_t * pOperationState, uint64_t ulOperationStateLen, uint64_t hEncryptionKey, uint64_t hAuthenticationKey, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11CopyObjectFunc)(uint32_t hSession, uint32_t hObject, TPKCS11AttributeHandle pTemplate, uint32_t ulCount, uint32_t * phNewObject, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11CopyObjectFunc)(uint64_t hSession, uint64_t hObject, TPKCS11AttributeHandle pTemplate, uint64_t ulCount, uint64_t * phNewObject, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GetObjectSizeFunc)(uint32_t hSession, uint32_t hObject, uint32_t * pulSize, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GetObjectSizeFunc)(uint64_t hSession, uint64_t hObject, uint64_t * pulSize, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11SetAttributeValueFunc)(uint32_t hSession, uint32_t hObject, TPKCS11AttributeHandle pTemplate, uint32_t ulCount, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11SetAttributeValueFunc)(uint64_t hSession, uint64_t hObject, TPKCS11AttributeHandle pTemplate, uint64_t ulCount, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11EncryptInitFunc)(uint32_t hSession, SB_CK_MECHANISMHandle pMechanism, uint32_t hKey, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11EncryptInitFunc)(uint64_t hSession, SB_CK_MECHANISMHandle pMechanism, uint64_t hKey, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11EncryptFunc)(uint32_t hSession, uint8_t * pData, uint32_t ulDataLen, uint8_t * pEncryptedData, uint32_t * pulEncryptedDataLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11EncryptFunc)(uint64_t hSession, uint8_t * pData, uint64_t ulDataLen, uint8_t * pEncryptedData, uint64_t * pulEncryptedDataLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11EncryptUpdateFunc)(uint32_t hSession, uint8_t * pPart, uint32_t ulPartLen, uint8_t * pEncryptedPart, uint32_t * pulEncryptedPartLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11EncryptUpdateFunc)(uint64_t hSession, uint8_t * pPart, uint64_t ulPartLen, uint8_t * pEncryptedPart, uint64_t * pulEncryptedPartLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11EncryptFinalFunc)(uint32_t hSession, uint8_t * pLastEncryptedPart, uint32_t * pulLastEncryptedPartLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11EncryptFinalFunc)(uint64_t hSession, uint8_t * pLastEncryptedPart, uint64_t * pulLastEncryptedPartLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11DecryptUpdateFunc)(uint32_t hSession, uint8_t * pEncryptedPart, uint32_t ulEncryptedPartLen, uint8_t * pPart, uint32_t * pulPartLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11DecryptUpdateFunc)(uint64_t hSession, uint8_t * pEncryptedPart, uint64_t ulEncryptedPartLen, uint8_t * pPart, uint64_t * pulPartLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11DecryptFinalFunc)(uint32_t hSession, uint8_t * pLastPart, uint32_t * pulLastPartLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11DecryptFinalFunc)(uint64_t hSession, uint8_t * pLastPart, uint64_t * pulLastPartLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11DigestInitFunc)(uint32_t hSession, SB_CK_MECHANISMHandle pMechanism, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11DigestInitFunc)(uint64_t hSession, SB_CK_MECHANISMHandle pMechanism, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11DigestFunc)(uint32_t hSession, uint8_t * pData, uint32_t ulDataLen, uint8_t * pDigest, uint32_t * pulDigestLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11DigestFunc)(uint64_t hSession, uint8_t * pData, uint64_t ulDataLen, uint8_t * pDigest, uint64_t * pulDigestLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11DigestUpdateFunc)(uint32_t hSession, uint8_t * pPart, uint32_t ulPartLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11DigestUpdateFunc)(uint64_t hSession, uint8_t * pPart, uint64_t ulPartLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11DigestKeyFunc)(uint32_t hSession, uint32_t hKey, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11DigestKeyFunc)(uint64_t hSession, uint64_t hKey, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11DigestFinalFunc)(uint32_t hSession, uint8_t * pDigest, uint32_t * pulDigestLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11DigestFinalFunc)(uint64_t hSession, uint8_t * pDigest, uint64_t * pulDigestLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11SignUpdateFunc)(uint32_t hSession, uint8_t * pPart, uint32_t ulPartLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11SignUpdateFunc)(uint64_t hSession, uint8_t * pPart, uint64_t ulPartLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11SignFinalFunc)(uint32_t hSession, uint8_t * pSignature, uint32_t * pulSignatureLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11SignFinalFunc)(uint64_t hSession, uint8_t * pSignature, uint64_t * pulSignatureLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11SignRecoverInitFunc)(uint32_t hSession, SB_CK_MECHANISMHandle pMechanism, uint32_t hKey, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11SignRecoverInitFunc)(uint64_t hSession, SB_CK_MECHANISMHandle pMechanism, uint64_t hKey, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11SignRecoverFunc)(uint32_t hSession, uint8_t * pData, uint32_t ulDataLen, uint8_t * pSignature, uint32_t * pulSignatureLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11SignRecoverFunc)(uint64_t hSession, uint8_t * pData, uint64_t ulDataLen, uint8_t * pSignature, uint64_t * pulSignatureLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11VerifyInitFunc)(uint32_t hSession, SB_CK_MECHANISMHandle pMechanism, uint32_t hKey, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11VerifyInitFunc)(uint64_t hSession, SB_CK_MECHANISMHandle pMechanism, uint64_t hKey, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11VerifyFunc)(uint32_t hSession, uint8_t * pData, uint32_t ulDataLen, uint8_t * pSignature, uint32_t ulSignatureLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11VerifyFunc)(uint64_t hSession, uint8_t * pData, uint64_t ulDataLen, uint8_t * pSignature, uint64_t ulSignatureLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11VerifyUpdateFunc)(uint32_t hSession, uint8_t * pPart, uint32_t ulPartLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11VerifyUpdateFunc)(uint64_t hSession, uint8_t * pPart, uint64_t ulPartLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11VerifyFinalFunc)(uint32_t hSession, uint8_t * pSignature, uint32_t ulSignatureLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11VerifyFinalFunc)(uint64_t hSession, uint8_t * pSignature, uint64_t ulSignatureLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11VerifyRecoverInitFunc)(uint32_t hSession, SB_CK_MECHANISMHandle pMechanism, uint32_t hKey, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11VerifyRecoverInitFunc)(uint64_t hSession, SB_CK_MECHANISMHandle pMechanism, uint64_t hKey, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11VerifyRecoverFunc)(uint32_t hSession, uint8_t * pSignature, uint32_t ulSignatureLen, uint8_t * pData, uint32_t * pulDataLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11VerifyRecoverFunc)(uint64_t hSession, uint8_t * pSignature, uint64_t ulSignatureLen, uint8_t * pData, uint64_t * pulDataLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11DigestEncryptUpdateFunc)(uint32_t hSession, uint8_t * pPart, uint32_t ulPartLen, uint8_t * pEncryptedPart, uint32_t * pulEncryptedPartLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11DigestEncryptUpdateFunc)(uint64_t hSession, uint8_t * pPart, uint64_t ulPartLen, uint8_t * pEncryptedPart, uint64_t * pulEncryptedPartLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11DecryptDigestUpdateFunc)(uint32_t hSession, uint8_t * pEncryptedPart, uint32_t ulEncryptedPartLen, uint8_t * pPart, uint32_t * pulPartLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11DecryptDigestUpdateFunc)(uint64_t hSession, uint8_t * pEncryptedPart, uint64_t ulEncryptedPartLen, uint8_t * pPart, uint64_t * pulPartLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11SignEncryptUpdateFunc)(uint32_t hSession, uint8_t * pPart, uint32_t ulPartLen, uint8_t * pEncryptedPart, uint32_t * pulEncryptedPartLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11SignEncryptUpdateFunc)(uint64_t hSession, uint8_t * pPart, uint64_t ulPartLen, uint8_t * pEncryptedPart, uint64_t * pulEncryptedPartLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11DecryptVerifyUpdateFunc)(uint32_t hSession, uint8_t * pEncryptedPart, uint32_t ulEncryptedPartLen, uint8_t * pPart, uint32_t * pulPartLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11DecryptVerifyUpdateFunc)(uint64_t hSession, uint8_t * pEncryptedPart, uint64_t ulEncryptedPartLen, uint8_t * pPart, uint64_t * pulPartLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GenerateKeyFunc)(uint32_t hSession, SB_CK_MECHANISMHandle pMechanism, TPKCS11AttributeHandle pTemplate, uint32_t ulCount, uint32_t * phKey, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GenerateKeyFunc)(uint64_t hSession, SB_CK_MECHANISMHandle pMechanism, TPKCS11AttributeHandle pTemplate, uint64_t ulCount, uint64_t * phKey, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GenerateKeyPairFunc)(uint32_t hSession, SB_CK_MECHANISMHandle pMechanism, TPKCS11AttributeHandle pPublicKeyTemplate, uint32_t ulPublicKeyAttributeCount, TPKCS11AttributeHandle pPrivateKeyTemplate, uint32_t ulPrivateKeyAttributeCount, uint32_t * phPublicKey, uint32_t * phPrivateKey, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GenerateKeyPairFunc)(uint64_t hSession, SB_CK_MECHANISMHandle pMechanism, TPKCS11AttributeHandle pPublicKeyTemplate, uint64_t ulPublicKeyAttributeCount, TPKCS11AttributeHandle pPrivateKeyTemplate, uint64_t ulPrivateKeyAttributeCount, uint64_t * phPublicKey, uint64_t * phPrivateKey, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11WrapKeyFunc)(uint32_t hSession, SB_CK_MECHANISMHandle pMechanism, uint32_t hWrappingKey, uint32_t hKey, uint8_t * pWrappedKey, uint32_t * pulWrappedKeyLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11WrapKeyFunc)(uint64_t hSession, SB_CK_MECHANISMHandle pMechanism, uint64_t hWrappingKey, uint64_t hKey, uint8_t * pWrappedKey, uint64_t * pulWrappedKeyLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11UnwrapKeyFunc)(uint32_t hSession, SB_CK_MECHANISMHandle pMechanism, uint32_t hUnwrappingKey, uint8_t * pWrappedKey, uint32_t ulWrappedKeyLen, TPKCS11AttributeHandle pTemplate, uint32_t ulAttributeCount, uint32_t * phKey, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11UnwrapKeyFunc)(uint64_t hSession, SB_CK_MECHANISMHandle pMechanism, uint64_t hUnwrappingKey, uint8_t * pWrappedKey, uint64_t ulWrappedKeyLen, TPKCS11AttributeHandle pTemplate, uint64_t ulAttributeCount, uint64_t * phKey, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11DeriveKeyFunc)(uint32_t hSession, SB_CK_MECHANISMHandle pMechanism, uint32_t hBaseKey, TPKCS11AttributeHandle pTemplate, uint32_t ulAttributeCount, uint32_t * phKey, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11DeriveKeyFunc)(uint64_t hSession, SB_CK_MECHANISMHandle pMechanism, uint64_t hBaseKey, TPKCS11AttributeHandle pTemplate, uint64_t ulAttributeCount, uint64_t * phKey, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11SeedRandomFunc)(uint32_t hSession, uint8_t * pSeed, uint32_t ulSeedLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11SeedRandomFunc)(uint64_t hSession, uint8_t * pSeed, uint64_t ulSeedLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GenerateRandomFunc)(uint32_t hSession, uint8_t * pRandomData, uint32_t ulRandomLen, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GenerateRandomFunc)(uint64_t hSession, uint8_t * pRandomData, uint64_t ulRandomLen, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11GetFunctionStatusFunc)(uint32_t hSession, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11GetFunctionStatusFunc)(uint64_t hSession, uint64_t * OutResult);
#endif

#ifdef SB_NOT_CPU64_OR_WINDOWS
typedef void (SB_CALLBACK *TPKCS11CancelFunctionFunc)(uint32_t hSession, uint32_t * OutResult);
#else
typedef void (SB_CALLBACK *TPKCS11CancelFunctionFunc)(uint64_t hSession, uint64_t * OutResult);
#endif

typedef uint8_t TElPKCS11CertificateTypeRaw;

typedef enum
{
	pctX509 = 0,
	pctWTLS = 1,
	pctAttribute = 2,
	pctVendorDefined = 3
} TElPKCS11CertificateType;

typedef uint8_t TElPKCS11CertificateCategoryRaw;

typedef enum
{
	pccUnspecified = 0,
	pccTokenUser = 1,
	pccAuthority = 2,
	pccOtherEntity = 3
} TElPKCS11CertificateCategory;

typedef uint8_t TElPKCS11NotificationFlagRaw;

typedef enum
{
	nfNone = 0,
	nfSurrender = 1
} TElPKCS11NotificationFlag;

typedef uint8_t TElPKCS11UserTypeRaw;

typedef enum
{
	utSecurityOfficer = 0,
	utUser = 1
} TElPKCS11UserType;

typedef uint8_t TElPKCS11KeyTypeRaw;

typedef enum
{
	ktRSA = 0,
	ktDSA = 1,
	ktDH = 2,
	ktEC = 3
} TElPKCS11KeyType;

typedef uint8_t TElPKCS11SessionStateRaw;

typedef enum
{
	stROPublicSession = 0,
	stROUserFunctions = 1,
	stRWPublicSession = 2,
	stRWUserFunctions = 3,
	stRWSOFunctions = 4
} TElPKCS11SessionState;

typedef uint8_t TSBPKCS11StorageOptionRaw;

typedef enum
{
	pcsoAutoRefreshSlotInfo = 0,
	pcsoCreatePublicKeyObjects = 1,
	pcsoOnDemandMode = 2,
	pcsoUniqueIDs = 3,
	pcsoNoSessionLevelNotifications = 4,
	pcsoWeakenedKeySearchCriteria = 5,
	pcsoNoImplicitSlotInfoUpdates = 6,
	pcsoInitTemplateForFind = 7,
	pcsoUseSystemProcAddresses = 8,
	pcsoAutoDetectStructAlignment = 9
} TSBPKCS11StorageOption;

typedef uint32_t TSBPKCS11StorageOptionsRaw;

typedef enum 
{
	f_pcsoAutoRefreshSlotInfo = 1,
	f_pcsoCreatePublicKeyObjects = 2,
	f_pcsoOnDemandMode = 4,
	f_pcsoUniqueIDs = 8,
	f_pcsoNoSessionLevelNotifications = 16,
	f_pcsoWeakenedKeySearchCriteria = 32,
	f_pcsoNoImplicitSlotInfoUpdates = 64,
	f_pcsoInitTemplateForFind = 128,
	f_pcsoUseSystemProcAddresses = 256,
	f_pcsoAutoDetectStructAlignment = 512
} TSBPKCS11StorageOptions;

typedef void (SB_CALLBACK *TElPKCSNotifyEvent)(void * _ObjectData, TObjectHandle Sender, TElPKCS11SessionInfoHandle SessionInfo, TElPKCS11NotificationFlagRaw NotificationFlag, int8_t * AbortOperation);

typedef void (SB_CALLBACK *TElPKCSSlotEventEvent)(void * _ObjectData, TObjectHandle Sender, TElPKCS11SlotInfoHandle Slot);

typedef uint8_t TSBPKCS11SlotEventMonitoringModeRaw;

typedef enum
{
	semNoMonitoring = 0,
	semStandard = 1,
	semSynchronous = 2
} TSBPKCS11SlotEventMonitoringMode;

typedef uint8_t TSBPKCS11ProcAccessRaw;

typedef enum
{
	ppaAuto = 0,
	ppaAutoRelaxed = 1,
	ppaGetFunctionList = 2,
	ppaGetProcAddress = 3
} TSBPKCS11ProcAccess;

typedef uint8_t TSBPKCS11ObjectTypeRaw;

typedef enum
{
	otUnknown = 0,
	otData = 1,
	otCertificate = 2,
	otX509Certificate = 3,
	otWTLSCertificate = 4,
	otX509AttributeCertificate = 5,
	otPublicKey = 6,
	otPrivateKey = 7,
	otSecretKey = 8,
	otHardwareFeature = 9,
	otDomainParameters = 10,
	otMechanism = 11,
	otVendorDefined = 12
} TSBPKCS11ObjectType;

typedef TElClassHandle TElPKCS11ObjectClassHandle;

typedef uint8_t TSBPKCS11CertCategoryRaw;

typedef enum
{
	ccUnspecified = 0,
	ccTokenUser = 1,
	ccAuthority = 2,
	ccOtherEntity = 3
} TSBPKCS11CertCategory;

typedef uint8_t TSBPKCS11CertTypeRaw;

typedef enum
{
	ctX509 = 0,
	ctWTLS = 1,
	ctAttribute = 2
} TSBPKCS11CertType;

typedef uint8_t TSBPKCS11MIDPSecurityDomainRaw;

typedef enum
{
	msdUnspecified = 0,
	msdManufacturer = 1,
	msdOperator = 2,
	msdThirdParty = 3
} TSBPKCS11MIDPSecurityDomain;

typedef uint8_t TSBPKCS11TokenAccessModeRaw;

typedef enum
{
	tamCompatible = 0,
	tamFull = 1
} TSBPKCS11TokenAccessMode;

typedef void (SB_CALLBACK *TElSlotEventMonitoringThreadEvent)(void * _ObjectData, TObjectHandle Sender, uint32_t SlotID);

#ifdef SB_USE_CLASS_TELPKCS11MODULE
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_CloseSession(TElPKCS11ModuleHandle _Handle, TElPKCS11SessionInfoHandle SessionInfo, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_GetFunctionList(TElPKCS11ModuleHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_OpenSession(TElPKCS11ModuleHandle _Handle, int32_t SlotIndex, int8_t ReadOnly, TElPKCS11ConsumerHandle Consumer, TElPKCS11SessionInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_OpenSessionEx(TElPKCS11ModuleHandle _Handle, int32_t SlotIndex, int8_t ReadOnly, TElPKCS11ConsumerHandle Consumer, int8_t RequestNotifications, TElPKCS11SessionInfoHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_GetSessionByHandle(TElPKCS11ModuleHandle _Handle, uint32_t Handle, TElPKCS11SessionInfoHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_GetSessionByHandle(TElPKCS11ModuleHandle _Handle, uint64_t Handle, TElPKCS11SessionInfoHandle * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_InitToken(TElPKCS11ModuleHandle _Handle, int32_t SlotIndex, const char * pcPin, int32_t szPin, const char * pcTokenLabel, int32_t szTokenLabel);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_get_ProviderDescription(TElPKCS11ModuleHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_set_ProviderDescription(TElPKCS11ModuleHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_get_Session(TElPKCS11ModuleHandle _Handle, int32_t Index, TElPKCS11SessionInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_get_SessionCount(TElPKCS11ModuleHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_get_Slot(TElPKCS11ModuleHandle _Handle, int32_t Index, TElPKCS11SlotInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_get_SlotCount(TElPKCS11ModuleHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_get_UniqueID(TElPKCS11ModuleHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
#ifndef CPU64
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_get_HLib(TElPKCS11ModuleHandle _Handle, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_get_HLib(TElPKCS11ModuleHandle _Handle, uint64_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_get_UseGetFunctionList(TElPKCS11ModuleHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_set_UseGetFunctionList(TElPKCS11ModuleHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_get_ProcAccess(TElPKCS11ModuleHandle _Handle, TSBPKCS11ProcAccessRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_set_ProcAccess(TElPKCS11ModuleHandle _Handle, TSBPKCS11ProcAccessRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_get_AutoDetectStructAlignment(TElPKCS11ModuleHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_set_AutoDetectStructAlignment(TElPKCS11ModuleHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_get_PlatformPointerSize(TElPKCS11ModuleHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_set_PlatformPointerSize(TElPKCS11ModuleHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_get_PlatformLongIntSize(TElPKCS11ModuleHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_set_PlatformLongIntSize(TElPKCS11ModuleHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_get_PlatformAlignment(TElPKCS11ModuleHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_set_PlatformAlignment(TElPKCS11ModuleHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Module_Create(TElPKCS11ModuleHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11MODULE */

#ifdef SB_USE_CLASS_TELPKCS11SLOTINFO
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_AddConsumer(TElPKCS11SlotInfoHandle _Handle, TElPKCS11ConsumerHandle Consumer);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_PinNeeded(TElPKCS11SlotInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_Refresh(TElPKCS11SlotInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_RefreshSlot(TElPKCS11SlotInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_RefreshSupportedAlgorithms(TElPKCS11SlotInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_RemoveConsumer(TElPKCS11SlotInfoHandle _Handle, TElPKCS11ConsumerHandle Consumer);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_ConsumerCount(TElPKCS11SlotInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_LoggedIn(TElPKCS11SlotInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_ReadOnly(TElPKCS11SlotInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_SlotManufacturerID(TElPKCS11SlotInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_SlotDescription(TElPKCS11SlotInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_SlotHardwareVersionHi(TElPKCS11SlotInfoHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_SlotFirmwareVersionHi(TElPKCS11SlotInfoHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_SlotHardwareVersionLo(TElPKCS11SlotInfoHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_SlotFirmwareVersionLo(TElPKCS11SlotInfoHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_TokenPresent(TElPKCS11SlotInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_TokenHardwareVersionHi(TElPKCS11SlotInfoHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_TokenFirmwareVersionHi(TElPKCS11SlotInfoHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_TokenHardwareVersionLo(TElPKCS11SlotInfoHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_TokenFirmwareVersionLo(TElPKCS11SlotInfoHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_TokenManufacturerID(TElPKCS11SlotInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_TokenLabel(TElPKCS11SlotInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_TokenModel(TElPKCS11SlotInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_TokenSerial(TElPKCS11SlotInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_TokenFlags(TElPKCS11SlotInfoHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_Module(TElPKCS11SlotInfoHandle _Handle, TElPKCS11ModuleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_Consumers(TElPKCS11SlotInfoHandle _Handle, int32_t Index, TElPKCS11ConsumerHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_SupportedPKCS11Mechanisms(TElPKCS11SlotInfoHandle _Handle, int32_t Index, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_SlotID(TElPKCS11SlotInfoHandle _Handle, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_SupportedPKCS11Mechanisms(TElPKCS11SlotInfoHandle _Handle, int32_t Index, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_SlotID(TElPKCS11SlotInfoHandle _Handle, uint64_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_get_SupportedPKCS11MechanismCount(TElPKCS11SlotInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SlotInfo_Create(TElPKCS11SlotInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11SLOTINFO */

#ifdef SB_USE_CLASS_TELPKCS11SESSIONINFO
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_AddObject(TElPKCS11SessionInfoHandle _Handle, TSBPKCS11ObjectTypeRaw ObjectType, int8_t Token, int8_t Private, int8_t Modifiable, TElPKCS11AttributeListHandle Attributes, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_AddObject_1(TElPKCS11SessionInfoHandle _Handle, TSBPKCS11ObjectTypeRaw ObjectType, int8_t Token, TElPKCS11AttributeListHandle Attributes, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_AddObject_2(TElPKCS11SessionInfoHandle _Handle, TSBPKCS11ObjectTypeRaw ObjectType, int8_t Token, int8_t Private, int8_t Modifiable, TElPKCS11AttributeListHandle Attributes, TElPKCS11ObjectHandle * NewObj);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_AddObject_3(TElPKCS11SessionInfoHandle _Handle, TSBPKCS11ObjectTypeRaw ObjectType, int8_t Token, TElPKCS11AttributeListHandle Attributes, TElPKCS11ObjectHandle * NewObj);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_AddGeneratedObject(TElPKCS11SessionInfoHandle _Handle, uint32_t Handle, int32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_AddGeneratedObject(TElPKCS11SessionInfoHandle _Handle, uint64_t Handle, int32_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_RemoveObject(TElPKCS11SessionInfoHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_RemoveObject_1(TElPKCS11SessionInfoHandle _Handle, TElPKCS11ObjectHandle Obj);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_RemoveObjectByHandle(TElPKCS11SessionInfoHandle _Handle, uint32_t Handle);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_RemoveObjectByHandle(TElPKCS11SessionInfoHandle _Handle, uint64_t Handle);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_ClearObjects(TElPKCS11SessionInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_CopyObject(TElPKCS11SessionInfoHandle _Handle, int32_t Index, int8_t Token, int8_t Private, int8_t Modifiable, TElPKCS11AttributeListHandle Attributes, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_CopyObject_1(TElPKCS11SessionInfoHandle _Handle, TElPKCS11ObjectHandle Obj, int8_t Token, int8_t Private, int8_t Modifiable, TElPKCS11AttributeListHandle Attributes, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_CopyObject_2(TElPKCS11SessionInfoHandle _Handle, TElPKCS11ObjectHandle Obj, int8_t Token, int8_t Private, int8_t Modifiable, TElPKCS11AttributeListHandle Attributes, TElPKCS11ObjectHandle * NewObj);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_GetObjectByHandle(TElPKCS11SessionInfoHandle _Handle, uint32_t Handle, TElPKCS11ObjectHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_GetObjectByHandle(TElPKCS11SessionInfoHandle _Handle, uint64_t Handle, TElPKCS11ObjectHandle * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_GetObjectBySubjectOrID(TElPKCS11SessionInfoHandle _Handle, TSBPKCS11ObjectTypeRaw ObjectType, const uint8_t pSubject[], int32_t szSubject, const uint8_t pID[], int32_t szID, TElPKCS11ObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_GetObjectBySubjectOrID_1(TElPKCS11SessionInfoHandle _Handle, TSBPKCS11ObjectTypeRaw ObjectType, const uint8_t pSubject[], int32_t szSubject, const uint8_t pID[], int32_t szID, int8_t SubjectMustMatch, int8_t IDMustMatch, TElPKCS11ObjectHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_AcquireObject(TElPKCS11SessionInfoHandle _Handle, uint32_t Handle, TElPKCS11ObjectHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_AcquireObject(TElPKCS11SessionInfoHandle _Handle, uint64_t Handle, TElPKCS11ObjectHandle * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_ReleaseObject(TElPKCS11SessionInfoHandle _Handle, TElPKCS11ObjectHandle * Obj);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_AcquireObjectBySubjectOrID(TElPKCS11SessionInfoHandle _Handle, TSBPKCS11ObjectTypeRaw ObjectType, const uint8_t pSubject[], int32_t szSubject, const uint8_t pID[], int32_t szID, TElPKCS11ObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_AcquireObjectBySubjectOrID_1(TElPKCS11SessionInfoHandle _Handle, TSBPKCS11ObjectTypeRaw ObjectType, const uint8_t pSubject[], int32_t szSubject, const uint8_t pID[], int32_t szID, int8_t SubjectMustMatch, int8_t IDMustMatch, TElPKCS11ObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_Close(TElPKCS11SessionInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_Login(TElPKCS11SessionInfoHandle _Handle, TElPKCS11UserTypeRaw UserType, const char * pcPIN, int32_t szPIN);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_Logout(TElPKCS11SessionInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_ClearObjectInstances(TElPKCS11SessionInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_RefreshObjectList(TElPKCS11SessionInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_RefreshObjectList_1(TElPKCS11SessionInfoHandle _Handle, TListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_UpdateObjectList(TElPKCS11SessionInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_AcquireSession(TElPKCS11SessionInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_ReleaseSession(TElPKCS11SessionInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_InitPIN(TElPKCS11SessionInfoHandle _Handle, const char * pcPin, int32_t szPin);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_SetPIN(TElPKCS11SessionInfoHandle _Handle, const char * pcOldPin, int32_t szOldPin, const char * pcNewPin, int32_t szNewPin);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_get_Consumer(TElPKCS11SessionInfoHandle _Handle, TElPKCS11ConsumerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_get_Slot(TElPKCS11SessionInfoHandle _Handle, TElPKCS11SlotInfoHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_get_Handle(TElPKCS11SessionInfoHandle _Handle, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_get_Handle(TElPKCS11SessionInfoHandle _Handle, uint64_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_get_CryptoProvider(TElPKCS11SessionInfoHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_set_CryptoProvider(TElPKCS11SessionInfoHandle _Handle, TElCustomCryptoProviderHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_get_ObjectCount(TElPKCS11SessionInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_get_TokenAccessMode(TElPKCS11SessionInfoHandle _Handle, TSBPKCS11TokenAccessModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_set_TokenAccessMode(TElPKCS11SessionInfoHandle _Handle, TSBPKCS11TokenAccessModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_get_IsOnDemandSession(TElPKCS11SessionInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_get_Objects(TElPKCS11SessionInfoHandle _Handle, int32_t Index, TElPKCS11ObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_get_TokenProps(TElPKCS11SessionInfoHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SessionInfo_Create(TElPKCS11SessionInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11SESSIONINFO */

#ifdef SB_USE_CLASS_TELPKCS11CONSUMER
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Consumer_get_UniqueID(TElPKCS11ConsumerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Consumer_Create(TElPKCS11ConsumerHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11CONSUMER */

#ifdef SB_USE_CLASS_TELPKCS11ATTRIBUTELIST
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Assign(TElPKCS11AttributeListHandle _Handle, TElPKCS11AttributeListHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Add(TElPKCS11AttributeListHandle _Handle, int32_t * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Add_1(TElPKCS11AttributeListHandle _Handle, uint32_t Attribute, const uint8_t pValue[], int32_t szValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Add_2(TElPKCS11AttributeListHandle _Handle, uint32_t Attribute, uint32_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Add_3(TElPKCS11AttributeListHandle _Handle, uint32_t Attribute, int8_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_AddByte(TElPKCS11AttributeListHandle _Handle, uint32_t Attribute, uint8_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_AddWord(TElPKCS11AttributeListHandle _Handle, uint32_t Attribute, uint16_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_AddThreeByteInteger(TElPKCS11AttributeListHandle _Handle, uint32_t Attribute, uint32_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_AddIntegerOptEnc(TElPKCS11AttributeListHandle _Handle, uint32_t Attribute, uint32_t Value, int32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Add_1(TElPKCS11AttributeListHandle _Handle, uint64_t Attribute, const uint8_t pValue[], int32_t szValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Add_2(TElPKCS11AttributeListHandle _Handle, uint64_t Attribute, uint64_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Add_3(TElPKCS11AttributeListHandle _Handle, uint64_t Attribute, int8_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_AddByte(TElPKCS11AttributeListHandle _Handle, uint64_t Attribute, uint8_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_AddWord(TElPKCS11AttributeListHandle _Handle, uint64_t Attribute, uint16_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_AddThreeByteInteger(TElPKCS11AttributeListHandle _Handle, uint64_t Attribute, uint64_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_AddIntegerOptEnc(TElPKCS11AttributeListHandle _Handle, uint64_t Attribute, uint64_t Value, int32_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Insert(TElPKCS11AttributeListHandle _Handle, int32_t Index);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Insert_1(TElPKCS11AttributeListHandle _Handle, int32_t Index, uint32_t Attribute, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Insert_2(TElPKCS11AttributeListHandle _Handle, int32_t Index, uint32_t Attribute, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Insert_3(TElPKCS11AttributeListHandle _Handle, int32_t Index, uint32_t Attribute, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_IndexOf(TElPKCS11AttributeListHandle _Handle, uint32_t Attribute, int32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Insert_1(TElPKCS11AttributeListHandle _Handle, int32_t Index, uint64_t Attribute, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Insert_2(TElPKCS11AttributeListHandle _Handle, int32_t Index, uint64_t Attribute, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Insert_3(TElPKCS11AttributeListHandle _Handle, int32_t Index, uint64_t Attribute, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_IndexOf(TElPKCS11AttributeListHandle _Handle, uint64_t Attribute, int32_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Remove(TElPKCS11AttributeListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Clear(TElPKCS11AttributeListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Serialize(TElPKCS11AttributeListHandle _Handle, void * Buffer, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_ToString(TElPKCS11AttributeListHandle _Handle, char * pcOutResult, int32_t * szOutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_get_Attributes(TElPKCS11AttributeListHandle _Handle, int32_t Index, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_set_Attributes(TElPKCS11AttributeListHandle _Handle, int32_t Index, uint32_t Value);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_get_Attributes(TElPKCS11AttributeListHandle _Handle, int32_t Index, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_set_Attributes(TElPKCS11AttributeListHandle _Handle, int32_t Index, uint64_t Value);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_get_Values(TElPKCS11AttributeListHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_set_Values(TElPKCS11AttributeListHandle _Handle, int32_t Index, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_get_Count(TElPKCS11AttributeListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_set_Count(TElPKCS11AttributeListHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AttributeList_Create(int32_t PlatformAlignment, int32_t PlatformPointerSize, int32_t PlatformLongIntSize, TElPKCS11AttributeListHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11ATTRIBUTELIST */

#ifdef SB_USE_CLASS_TELPKCS11OBJECT
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_SetAttribute(TElPKCS11ObjectHandle _Handle, uint32_t Attribute, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_SetAttribute_1(TElPKCS11ObjectHandle _Handle, uint32_t Attribute, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_SetAttribute_2(TElPKCS11ObjectHandle _Handle, uint32_t Attribute, int8_t Value);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_SetAttribute(TElPKCS11ObjectHandle _Handle, uint64_t Attribute, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_SetAttribute_1(TElPKCS11ObjectHandle _Handle, uint64_t Attribute, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_SetAttribute_2(TElPKCS11ObjectHandle _Handle, uint64_t Attribute, int8_t Value);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_SetAttributes(TElPKCS11ObjectHandle _Handle, TElPKCS11AttributeListHandle Attributes);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_GetAttribute(TElPKCS11ObjectHandle _Handle, uint32_t Attribute, uint8_t pOutResult[], int32_t * szOutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_GetAttribute(TElPKCS11ObjectHandle _Handle, uint64_t Attribute, uint8_t pOutResult[], int32_t * szOutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_ReadProperties(TElPKCS11ObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_get_ObjectType(TElPKCS11ObjectHandle _Handle, TSBPKCS11ObjectTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_get_Token(TElPKCS11ObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_get_Private(TElPKCS11ObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_get_Modifiable(TElPKCS11ObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_get_ObjectLabel(TElPKCS11ObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_set_ObjectLabel(TElPKCS11ObjectHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_get_ObjectSize(TElPKCS11ObjectHandle _Handle, int32_t * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_get_Handle(TElPKCS11ObjectHandle _Handle, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_get_Handle(TElPKCS11ObjectHandle _Handle, uint64_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_get_Session(TElPKCS11ObjectHandle _Handle, TElPKCS11SessionInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_get_CryptoProvider(TElPKCS11ObjectHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_set_CryptoProvider(TElPKCS11ObjectHandle _Handle, TElCustomCryptoProviderHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_Create(TElPKCS11ObjectHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint32_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Object_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint64_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#endif
#endif /* SB_USE_CLASS_TELPKCS11OBJECT */

#ifdef SB_USE_CLASS_TELPKCS11DATAOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DataObject_ReadProperties(TElPKCS11DataObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DataObject_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DataObject_get_Application(TElPKCS11DataObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DataObject_set_Application(TElPKCS11DataObjectHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DataObject_get_ObjectID(TElPKCS11DataObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DataObject_set_ObjectID(TElPKCS11DataObjectHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DataObject_get_Value(TElPKCS11DataObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DataObject_set_Value(TElPKCS11DataObjectHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DataObject_Create(TElPKCS11ObjectHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DataObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint32_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DataObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint64_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#endif
#endif /* SB_USE_CLASS_TELPKCS11DATAOBJECT */

#ifdef SB_USE_CLASS_TELPKCS11CERTIFICATEOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertificateObject_ReadProperties(TElPKCS11CertificateObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertificateObject_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertificateObject_get_CertType(TElPKCS11CertificateObjectHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertificateObject_get_Trusted(TElPKCS11CertificateObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertificateObject_set_Trusted(TElPKCS11CertificateObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertificateObject_get_CertCategory(TElPKCS11CertificateObjectHandle _Handle, TSBPKCS11CertCategoryRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertificateObject_get_Checksum(TElPKCS11CertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertificateObject_get_StartDate(TElPKCS11CertificateObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertificateObject_set_StartDate(TElPKCS11CertificateObjectHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertificateObject_get_EndDate(TElPKCS11CertificateObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertificateObject_set_EndDate(TElPKCS11CertificateObjectHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertificateObject_Create(TElPKCS11ObjectHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertificateObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint32_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertificateObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint64_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#endif
#endif /* SB_USE_CLASS_TELPKCS11CERTIFICATEOBJECT */

#ifdef SB_USE_CLASS_TELPKCS11X509CERTIFICATEOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_ReadProperties(TElPKCS11X509CertificateObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_get_Subject(TElPKCS11X509CertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_get_KeyID(TElPKCS11X509CertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_set_KeyID(TElPKCS11X509CertificateObjectHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_get_Issuer(TElPKCS11X509CertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_set_Issuer(TElPKCS11X509CertificateObjectHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_get_SerialNumber(TElPKCS11X509CertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_set_SerialNumber(TElPKCS11X509CertificateObjectHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_get_Value(TElPKCS11X509CertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_get_URL(TElPKCS11X509CertificateObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_get_SubjectPublicKeyHash(TElPKCS11X509CertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_get_IssuerPublicKeyHash(TElPKCS11X509CertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_get_MIDPSecurityDomain(TElPKCS11X509CertificateObjectHandle _Handle, TSBPKCS11MIDPSecurityDomainRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_Create(TElPKCS11ObjectHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint32_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509CertificateObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint64_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#endif
#endif /* SB_USE_CLASS_TELPKCS11X509CERTIFICATEOBJECT */

#ifdef SB_USE_CLASS_TELPKCS11WTLSCERTIFICATEOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11WTLSCertificateObject_ReadProperties(TElPKCS11WTLSCertificateObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11WTLSCertificateObject_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11WTLSCertificateObject_get_Subject(TElPKCS11WTLSCertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11WTLSCertificateObject_get_Issuer(TElPKCS11WTLSCertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11WTLSCertificateObject_set_Issuer(TElPKCS11WTLSCertificateObjectHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11WTLSCertificateObject_get_Value(TElPKCS11WTLSCertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11WTLSCertificateObject_get_URL(TElPKCS11WTLSCertificateObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11WTLSCertificateObject_get_SubjectPublicKeyHash(TElPKCS11WTLSCertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11WTLSCertificateObject_get_IssuerPublicKeyHash(TElPKCS11WTLSCertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11WTLSCertificateObject_Create(TElPKCS11ObjectHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11WTLSCertificateObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint32_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11WTLSCertificateObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint64_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#endif
#endif /* SB_USE_CLASS_TELPKCS11WTLSCERTIFICATEOBJECT */

#ifdef SB_USE_CLASS_TELPKCS11X509ATTRIBUTECERTIFICATEOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509AttributeCertificateObject_ReadProperties(TElPKCS11X509AttributeCertificateObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509AttributeCertificateObject_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509AttributeCertificateObject_get_Owner(TElPKCS11X509AttributeCertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509AttributeCertificateObject_get_ACIssuer(TElPKCS11X509AttributeCertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509AttributeCertificateObject_set_ACIssuer(TElPKCS11X509AttributeCertificateObjectHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509AttributeCertificateObject_get_SerialNumber(TElPKCS11X509AttributeCertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509AttributeCertificateObject_set_SerialNumber(TElPKCS11X509AttributeCertificateObjectHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509AttributeCertificateObject_get_AttrTypes(TElPKCS11X509AttributeCertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509AttributeCertificateObject_set_AttrTypes(TElPKCS11X509AttributeCertificateObjectHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509AttributeCertificateObject_get_Value(TElPKCS11X509AttributeCertificateObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509AttributeCertificateObject_Create(TElPKCS11ObjectHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509AttributeCertificateObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint32_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11X509AttributeCertificateObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint64_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#endif
#endif /* SB_USE_CLASS_TELPKCS11X509ATTRIBUTECERTIFICATEOBJECT */

#ifdef SB_USE_CLASS_TELPKCS11KEYOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_ReadProperties(TElPKCS11KeyObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_get_KeyType(TElPKCS11KeyObjectHandle _Handle, int32_t * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_get_PKCS11KeyType(TElPKCS11KeyObjectHandle _Handle, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_get_PKCS11KeyType(TElPKCS11KeyObjectHandle _Handle, uint64_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_get_KeyID(TElPKCS11KeyObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_set_KeyID(TElPKCS11KeyObjectHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_get_StartDate(TElPKCS11KeyObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_set_StartDate(TElPKCS11KeyObjectHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_get_EndDate(TElPKCS11KeyObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_set_EndDate(TElPKCS11KeyObjectHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_get_Derive(TElPKCS11KeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_set_Derive(TElPKCS11KeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_get_Local(TElPKCS11KeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_get_KeyMaterial(TElPKCS11KeyObjectHandle _Handle, TElKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_Create(TElPKCS11ObjectHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint32_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11KeyObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint64_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#endif
#endif /* SB_USE_CLASS_TELPKCS11KEYOBJECT */

#ifdef SB_USE_CLASS_TELPKCS11PUBLICKEYOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_ReadProperties(TElPKCS11PublicKeyObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_get_Subject(TElPKCS11PublicKeyObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_set_Subject(TElPKCS11PublicKeyObjectHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_get_CanEncrypt(TElPKCS11PublicKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_set_CanEncrypt(TElPKCS11PublicKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_get_CanVerify(TElPKCS11PublicKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_set_CanVerify(TElPKCS11PublicKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_get_CanVerifyDetached(TElPKCS11PublicKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_set_CanVerifyDetached(TElPKCS11PublicKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_get_CanWrap(TElPKCS11PublicKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_set_CanWrap(TElPKCS11PublicKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_get_Trusted(TElPKCS11PublicKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_set_Trusted(TElPKCS11PublicKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_Create(TElPKCS11ObjectHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint32_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PublicKeyObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint64_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#endif
#endif /* SB_USE_CLASS_TELPKCS11PUBLICKEYOBJECT */

#ifdef SB_USE_CLASS_TELPKCS11PRIVATEKEYOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_ReadProperties(TElPKCS11PrivateKeyObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_get_Subject(TElPKCS11PrivateKeyObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_set_Subject(TElPKCS11PrivateKeyObjectHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_get_Sensitive(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_set_Sensitive(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_get_CanDecrypt(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_set_CanDecrypt(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_get_CanSign(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_set_CanSign(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_get_CanSignDetached(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_set_CanSignDetached(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_get_CanUnwrap(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_set_CanUnwrap(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_get_Extractable(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_set_Extractable(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_get_AlwaysSensitive(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_get_NeverExtractable(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_get_WrapWithTrusted(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_set_WrapWithTrusted(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_get_AlwaysAuthenticate(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_set_AlwaysAuthenticate(TElPKCS11PrivateKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_Create(TElPKCS11ObjectHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint32_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11PrivateKeyObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint64_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#endif
#endif /* SB_USE_CLASS_TELPKCS11PRIVATEKEYOBJECT */

#ifdef SB_USE_CLASS_TELPKCS11SECRETKEYOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_ReadProperties(TElPKCS11SecretKeyObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_get_Sensitive(TElPKCS11SecretKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_set_Sensitive(TElPKCS11SecretKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_get_CanEncrypt(TElPKCS11SecretKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_set_CanEncrypt(TElPKCS11SecretKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_get_CanDecrypt(TElPKCS11SecretKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_set_CanDecrypt(TElPKCS11SecretKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_get_CanSign(TElPKCS11SecretKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_set_CanSign(TElPKCS11SecretKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_get_CanVerify(TElPKCS11SecretKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_set_CanVerify(TElPKCS11SecretKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_get_CanWrap(TElPKCS11SecretKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_set_CanWrap(TElPKCS11SecretKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_get_CanUnwrap(TElPKCS11SecretKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_set_CanUnwrap(TElPKCS11SecretKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_get_Extractable(TElPKCS11SecretKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_set_Extractable(TElPKCS11SecretKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_get_AlwaysSensitive(TElPKCS11SecretKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_get_NeverExtractable(TElPKCS11SecretKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_get_Checksum(TElPKCS11SecretKeyObjectHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_get_WrapWithTrusted(TElPKCS11SecretKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_set_WrapWithTrusted(TElPKCS11SecretKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_get_Trusted(TElPKCS11SecretKeyObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_set_Trusted(TElPKCS11SecretKeyObjectHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_Create(TElPKCS11ObjectHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint32_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SecretKeyObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint64_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#endif
#endif /* SB_USE_CLASS_TELPKCS11SECRETKEYOBJECT */

#ifdef SB_USE_CLASS_TELPKCS11DOMAINPARAMETERSOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DomainParametersObject_ReadProperties(TElPKCS11DomainParametersObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DomainParametersObject_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DomainParametersObject_get_KeyType(TElPKCS11DomainParametersObjectHandle _Handle, int32_t * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DomainParametersObject_get_PKCS11KeyType(TElPKCS11DomainParametersObjectHandle _Handle, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DomainParametersObject_get_PKCS11KeyType(TElPKCS11DomainParametersObjectHandle _Handle, uint64_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DomainParametersObject_Create(TElPKCS11ObjectHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DomainParametersObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint32_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11DomainParametersObject_Create_1(TElPKCS11ModuleHandle Module, TElPKCS11SessionInfoHandle Session, TElPKCS11SlotInfoHandle Slot, uint64_t Handle, int8_t CompatibleMode, TElCustomCryptoProviderHandle CryptoProvider, TElPKCS11ObjectHandle * OutResult);
#endif
#endif /* SB_USE_CLASS_TELPKCS11DOMAINPARAMETERSOBJECT */

#ifdef SB_USE_CLASS_TELPKCS11UTILS
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetObjectAttribute(TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetObjectAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetBufferTypeAttribute(TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, const uint8_t pDef[], int32_t szDef, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetBufferTypeAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, const uint8_t pDef[], int32_t szDef, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetBooleanAttribute(TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, int8_t Def, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetBooleanAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, int8_t Def, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetULongAttribute(TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, uint32_t Def, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetULongAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, uint32_t Def, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetDateAttribute(TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, int64_t Def, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetDateAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, int64_t Def, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetObjectAttribute(TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetObjectAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetBufferTypeAttribute(TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetBufferTypeAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetBooleanAttribute(TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetBooleanAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetULongAttribute(TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetULongAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetDateAttribute(TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetDateAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint32_t hSession, uint32_t hObject, uint32_t Attribute, int64_t Value);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetObjectAttribute(TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetObjectAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetBufferTypeAttribute(TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, const uint8_t pDef[], int32_t szDef, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetBufferTypeAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, const uint8_t pDef[], int32_t szDef, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetBooleanAttribute(TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, int8_t Def, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetBooleanAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, int8_t Def, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetULongAttribute(TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, uint64_t Def, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetULongAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, uint64_t Def, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetDateAttribute(TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, int64_t Def, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_GetDateAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, int64_t Def, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetObjectAttribute(TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetObjectAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetBufferTypeAttribute(TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetBufferTypeAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetBooleanAttribute(TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetBooleanAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetULongAttribute(TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetULongAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetDateAttribute(TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_SetDateAttribute_1(TElPKCS11UtilsHandle _Handle, TElPKCS11ModuleHandle Module, uint64_t hSession, uint64_t hObject, uint64_t Attribute, int64_t Value);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_ConvertPKCS11KeyTypeToSBBKeyType(int32_t KeyType, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_ConvertPKCS11KeyTypeToSBBKeyType_1(TElPKCS11UtilsHandle _Handle, int32_t KeyType, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11Utils_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11UTILS */

#ifdef SB_USE_CLASS_TELPKCS11NSSPARAMS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_Load(TElPKCS11NSSParamsHandle _Handle, const uint8_t pData[], int32_t szData, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_Save(TElPKCS11NSSParamsHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_get_ConfigDir(TElPKCS11NSSParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_set_ConfigDir(TElPKCS11NSSParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_get_CertPrefix(TElPKCS11NSSParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_set_CertPrefix(TElPKCS11NSSParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_get_KeyPrefix(TElPKCS11NSSParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_set_KeyPrefix(TElPKCS11NSSParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_get_SecMod(TElPKCS11NSSParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_set_SecMod(TElPKCS11NSSParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_get_Flags(TElPKCS11NSSParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_set_Flags(TElPKCS11NSSParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_get_UseNSSMode(TElPKCS11NSSParamsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_set_UseNSSMode(TElPKCS11NSSParamsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_get_RawParamsStr(TElPKCS11NSSParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_set_RawParamsStr(TElPKCS11NSSParamsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11NSSParams_Create(TElPKCS11NSSParamsHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11NSSPARAMS */

#ifdef SB_USE_CLASS_TELPKCS11MODULELIST
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11ModuleList_LoadModule(TElPKCS11ModuleListHandle _Handle, const char * pcModuleName, int32_t szModuleName, TSBPKCS11ProcAccessRaw ProcAccess, int8_t TrySingleThreadedMode, int8_t AutoRefreshSlotInfo, int8_t AutoDetectStructAlignment, TElPKCS11ModuleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11ModuleList_LoadModule_1(TElPKCS11ModuleListHandle _Handle, const char * pcModuleName, int32_t szModuleName, TSBPKCS11ProcAccessRaw ProcAccess, int8_t TrySingleThreadedMode, int8_t AutoRefreshSlotInfo, int8_t PreserveSettingsIfExists, int8_t AutoDetectStructAlignment, TElPKCS11ModuleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11ModuleList_LoadModule_2(TElPKCS11ModuleListHandle _Handle, const char * pcModuleName, int32_t szModuleName, TSBPKCS11ProcAccessRaw ProcAccess, int8_t TrySingleThreadedMode, int8_t AutoRefreshSlotInfo, int8_t PreserveSettingsIfExists, int8_t OnDemandMode, int8_t AutoDetectStructAlignment, TElPKCS11ModuleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11ModuleList_LoadModule_3(TElPKCS11ModuleListHandle _Handle, const char * pcModuleName, int32_t szModuleName, TSBPKCS11ProcAccessRaw ProcAccess, int8_t TrySingleThreadedMode, int8_t AutoRefreshSlotInfo, int8_t PreserveSettingsIfExists, int8_t OnDemandMode, TElPKCS11NSSParamsHandle NSSParams, int8_t NoImplicitSlotInfoUpdates, int32_t PlatformPointerSize, int32_t PlatformLongIntSize, int32_t PlatformAlignment, int8_t AutoDetectStructAlignment, TElPKCS11ModuleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11ModuleList_UnloadModule(TElPKCS11ModuleListHandle _Handle, TElPKCS11ModuleHandle aModule);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11ModuleList_get_ModuleCount(TElPKCS11ModuleListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11ModuleList_get_Modules(TElPKCS11ModuleListHandle _Handle, int32_t Index, TElPKCS11ModuleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11ModuleList_Create(TElPKCS11ModuleListHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11MODULELIST */

#ifdef SB_USE_CLASS_TELPKCS11ALGORITHMINFO
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_Algorithm(TElPKCS11AlgorithmInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_Mode(TElPKCS11AlgorithmInfoHandle _Handle, int32_t * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_Mechanism(TElPKCS11AlgorithmInfoHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_KeyMechanism(TElPKCS11AlgorithmInfoHandle _Handle, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_Mechanism(TElPKCS11AlgorithmInfoHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_KeyMechanism(TElPKCS11AlgorithmInfoHandle _Handle, uint64_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_PaddingUsed(TElPKCS11AlgorithmInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_CanGenerate(TElPKCS11AlgorithmInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_CanEncrypt(TElPKCS11AlgorithmInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_CanSign(TElPKCS11AlgorithmInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_CanSignRecover(TElPKCS11AlgorithmInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_CanDigest(TElPKCS11AlgorithmInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_CanWrap(TElPKCS11AlgorithmInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_CanDerive(TElPKCS11AlgorithmInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_get_SignHashAlgorithm(TElPKCS11AlgorithmInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmInfo_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11ALGORITHMINFO */

#ifdef SB_USE_CLASS_TELPKCS11ALGORITHMCONVERTER
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmConverter_Find(TElPKCS11AlgorithmConverterHandle _Handle, int32_t Algorithm, int32_t Mode, int32_t Operation, int8_t PaddingUsed, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmConverter_Find_1(TElPKCS11AlgorithmConverterHandle _Handle, int32_t Algorithm, int32_t Mode, TListHandle Infos);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmConverter_FindSignatureAlgorithmInfo(TElPKCS11AlgorithmConverterHandle _Handle, int32_t Algorithm, int32_t HashAlgorithm, int32_t * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmConverter_GetAlgorithmByPKCS11Mechanism(TElPKCS11AlgorithmConverterHandle _Handle, uint32_t Mech, int32_t * Mode, int8_t * Gen, int32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmConverter_GetAlgorithmByPKCS11Mechanism(TElPKCS11AlgorithmConverterHandle _Handle, uint64_t Mech, int32_t * Mode, int8_t * Gen, int32_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmConverter_GetPKCS11MechanismByAlgorithm(TElPKCS11AlgorithmConverterHandle _Handle, int32_t Algorithm, int32_t Mode, SB_CK_MECHANISMHandle * Mech, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmConverter_get_AlgorithmInfos(TElPKCS11AlgorithmConverterHandle _Handle, int32_t Index, TElPKCS11AlgorithmInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmConverter_get_AlgorithmInfoCount(TElPKCS11AlgorithmConverterHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11AlgorithmConverter_Create(TElPKCS11AlgorithmConverterHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11ALGORITHMCONVERTER */

#ifdef SB_USE_CLASS_TELSLOTEVENTMONITORINGTHREAD
SB_IMPORT uint32_t SB_APIENTRY TElSlotEventMonitoringThread_get_OnSlotEvent(TElSlotEventMonitoringThreadHandle _Handle, TElSlotEventMonitoringThreadEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSlotEventMonitoringThread_set_OnSlotEvent(TElSlotEventMonitoringThreadHandle _Handle, TElSlotEventMonitoringThreadEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSlotEventMonitoringThread_Create(TElPKCS11ModuleHandle PKCS11Module, int8_t SynchronizeGUI, int8_t UseGetSlotInfo, int32_t Delay, TElSlotEventMonitoringThreadHandle * OutResult);
#endif /* SB_USE_CLASS_TELSLOTEVENTMONITORINGTHREAD */

#ifdef SB_USE_CLASS_TELATTRIBUTES
SB_IMPORT uint32_t SB_APIENTRY TElAttributes_Create(int32_t Alignment, int32_t PointerSize, int32_t LongIntSize, const TPKCS11AttributeHandle pValue[], int32_t szValue, TElAttributesHandle * OutResult);
#endif /* SB_USE_CLASS_TELATTRIBUTES */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPKCS11ObjectClass_ce_ptr;
extern zend_class_entry *TElPKCS11Module_ce_ptr;
extern zend_class_entry *TElPKCS11SlotInfo_ce_ptr;
extern zend_class_entry *TElPKCS11SessionInfo_ce_ptr;
extern zend_class_entry *TElPKCS11Consumer_ce_ptr;
extern zend_class_entry *TElPKCS11AttributeList_ce_ptr;
extern zend_class_entry *TElPKCS11Object_ce_ptr;
extern zend_class_entry *TElPKCS11DataObject_ce_ptr;
extern zend_class_entry *TElPKCS11CertificateObject_ce_ptr;
extern zend_class_entry *TElPKCS11X509CertificateObject_ce_ptr;
extern zend_class_entry *TElPKCS11WTLSCertificateObject_ce_ptr;
extern zend_class_entry *TElPKCS11X509AttributeCertificateObject_ce_ptr;
extern zend_class_entry *TElPKCS11KeyObject_ce_ptr;
extern zend_class_entry *TElPKCS11PublicKeyObject_ce_ptr;
extern zend_class_entry *TElPKCS11PrivateKeyObject_ce_ptr;
extern zend_class_entry *TElPKCS11SecretKeyObject_ce_ptr;
extern zend_class_entry *TElPKCS11DomainParametersObject_ce_ptr;
extern zend_class_entry *TElPKCS11Utils_ce_ptr;
extern zend_class_entry *TElPKCS11NSSParams_ce_ptr;
extern zend_class_entry *TElPKCS11ModuleList_ce_ptr;
extern zend_class_entry *TElPKCS11AlgorithmInfo_ce_ptr;
extern zend_class_entry *TElPKCS11AlgorithmConverter_ce_ptr;
extern zend_class_entry *TElSlotEventMonitoringThread_ce_ptr;
extern zend_class_entry *TElAttributes_ce_ptr;

void SB_CALLBACK TElPKCSNotifyEventRaw(void * _ObjectData, TObjectHandle Sender, TElPKCS11SessionInfoHandle SessionInfo, TElPKCS11NotificationFlagRaw NotificationFlag, int8_t * AbortOperation);
void SB_CALLBACK TElPKCSSlotEventEventRaw(void * _ObjectData, TObjectHandle Sender, TElPKCS11SlotInfoHandle Slot);
void SB_CALLBACK TElSlotEventMonitoringThreadEventRaw(void * _ObjectData, TObjectHandle Sender, uint32_t SlotID);
void Register_TElPKCS11Module(TSRMLS_D);
void Register_TElPKCS11SlotInfo(TSRMLS_D);
void Register_TElPKCS11SessionInfo(TSRMLS_D);
void Register_TElPKCS11Consumer(TSRMLS_D);
void Register_TElPKCS11AttributeList(TSRMLS_D);
void Register_TElPKCS11Object(TSRMLS_D);
void Register_TElPKCS11DataObject(TSRMLS_D);
void Register_TElPKCS11CertificateObject(TSRMLS_D);
void Register_TElPKCS11X509CertificateObject(TSRMLS_D);
void Register_TElPKCS11WTLSCertificateObject(TSRMLS_D);
void Register_TElPKCS11X509AttributeCertificateObject(TSRMLS_D);
void Register_TElPKCS11KeyObject(TSRMLS_D);
void Register_TElPKCS11PublicKeyObject(TSRMLS_D);
void Register_TElPKCS11PrivateKeyObject(TSRMLS_D);
void Register_TElPKCS11SecretKeyObject(TSRMLS_D);
void Register_TElPKCS11DomainParametersObject(TSRMLS_D);
void Register_TElPKCS11Utils(TSRMLS_D);
void Register_TElPKCS11NSSParams(TSRMLS_D);
void Register_TElPKCS11ModuleList(TSRMLS_D);
void Register_TElPKCS11AlgorithmInfo(TSRMLS_D);
void Register_TElPKCS11AlgorithmConverter(TSRMLS_D);
void Register_TElSlotEventMonitoringThread(TSRMLS_D);
void Register_TElAttributes(TSRMLS_D);
SB_PHP_FUNCTION(SBPKCS11Base, PKCS11AlgorithmConverter);
SB_PHP_FUNCTION(SBPKCS11Base, CreateMutexCallback);
SB_PHP_FUNCTION(SBPKCS11Base, DestroyMutexCallback);
SB_PHP_FUNCTION(SBPKCS11Base, LockMutexCallback);
SB_PHP_FUNCTION(SBPKCS11Base, UnlockMutexCallback);
SB_PHP_FUNCTION(SBPKCS11Base, GetPKCS11String);
SB_PHP_FUNCTION(SBPKCS11Base, PKCS11CheckError);
SB_PHP_FUNCTION(SBPKCS11Base, GetPKCS11ErrorNameByCode);
SB_PHP_FUNCTION(SBPKCS11Base, EncodeErrorInfo);
SB_PHP_FUNCTION(SBPKCS11Base, GetPKCS11ModuleList);
SB_PHP_FUNCTION(SBPKCS11Base, UnloadPKCS11Modules);
void Register_SBPKCS11Base_Constants(int module_number TSRMLS_DC);
void Register_SBPKCS11Base_Enum_Flags(TSRMLS_D);
void Register_SBPKCS11Base_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_PKCS11BASE
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_PKCS11AlgorithmConverter(TElPKCS11AlgorithmConverterHandle * OutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_CreateMutexCallback(void * * MutexPtr, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_DestroyMutexCallback(void * MutexPtr, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_LockMutexCallback(void * MutexPtr, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_UnlockMutexCallback(void * MutexPtr, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_CreateMutexCallback(void * * MutexPtr, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_DestroyMutexCallback(void * MutexPtr, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_LockMutexCallback(void * MutexPtr, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_UnlockMutexCallback(void * MutexPtr, uint64_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_GetPKCS11String(const uint8_t pBuffer[], int32_t szBuffer, int32_t MaxLength, char * pcOutResult, int32_t * szOutResult);
#ifdef SB_NOT_CPU64_OR_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_PKCS11CheckError(int32_t FunctionCode, uint32_t ResultCode);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_GetPKCS11ErrorNameByCode(uint32_t Code, char * pcOutResult, int32_t * szOutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_PKCS11CheckError(int32_t FunctionCode, uint64_t ResultCode);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_GetPKCS11ErrorNameByCode(uint64_t Code, char * pcOutResult, int32_t * szOutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_EncodeErrorInfo(const char * pcMethodName, int32_t szMethodName, const char * pcErrorStr, int32_t szErrorStr, const char * pcErrorClassName, int32_t szErrorClassName, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_GetPKCS11ModuleList(TElPKCS11ModuleListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11Base_UnloadPKCS11Modules(void);
#endif /* SB_USE_GLOBAL_PROCS_PKCS11BASE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPKCS11BASE */
