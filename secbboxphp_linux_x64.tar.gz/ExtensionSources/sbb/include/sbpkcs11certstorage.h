#ifndef __INC_SBPKCS11CERTSTORAGE
#define __INC_SBPKCS11CERTSTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbasn1.h"
#include "sbpkcs11common.h"
#include "sbpkcs11base.h"
#include "sbpkcs8.h"
#include "sbcustomcertstorage.h"
#include "sbcustomcrypto.h"
#include "sbcryptoprov.h"
#include "sbcryptoprovutils.h"
#include "sbrdn.h"
#include "sbx509.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbrandom.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbsharedresource.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElPKCS11CertStorageHandle;

typedef TElPKCS11CertStorageHandle ElPKCS11CertStorageHandle;

typedef TElClassHandle TElPKCS11StgCtxHandle;

typedef TElPKCS11StgCtxHandle ElPKCS11StgCtxHandle;

typedef TElClassHandle TElPKCS11ConsumerCertStorageHandle;

typedef TElPKCS11ConsumerCertStorageHandle ElPKCS11ConsumerCertStorageHandle;

typedef uint8_t TSBPKCS11StgCtxTypeRaw;

typedef enum
{
	sctCertificate = 0,
	sctKey = 1
} TSBPKCS11StgCtxType;

typedef uint8_t TSBPKCS11CertStorageImportOrderRaw;

typedef enum
{
	csioAuto = 0,
	csioCertificateFirst = 1,
	csioKeyFirst = 2,
	csioPublicKeyFirst = 3
} TSBPKCS11CertStorageImportOrder;

#ifdef SB_USE_CLASS_TELPKCS11CERTSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_Add(TElPKCS11CertStorageHandle _Handle, TElX509CertificateHandle X509Certificate, int8_t CopyPrivateKey);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_Add_1(TElPKCS11CertStorageHandle _Handle, int32_t SessionIndex, TElX509CertificateHandle X509Certificate, int8_t CopyPrivateKey, int8_t Exportable);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_Add_2(TElPKCS11CertStorageHandle _Handle, int32_t SessionIndex, TElX509CertificateHandle X509Certificate, int8_t CopyPrivateKey, int8_t Exportable, const uint8_t pID[], int32_t szID, const uint8_t pKeyLabel[], int32_t szKeyLabel);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_AddKey(TElPKCS11CertStorageHandle _Handle, int32_t SessionIndex, TElKeyMaterialHandle KeyMaterial, int8_t CopyPrivateKey, int8_t Exportable, const uint8_t pID[], int32_t szID, const uint8_t pKeyLabel[], int32_t szKeyLabel, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_AddKey_1(TElPKCS11CertStorageHandle _Handle, TElKeyMaterialHandle KeyMaterial, int8_t CopyPrivateKey, int8_t Exportable, const uint8_t pID[], int32_t szID, const uint8_t pKeyLabel[], int32_t szKeyLabel, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_Close(TElPKCS11CertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_CloseAllSessions(TElPKCS11CertStorageHandle _Handle, TElPKCS11SlotInfoHandle SlotInfo);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_Open(TElPKCS11CertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_CloseSession(TElPKCS11CertStorageHandle _Handle, int32_t SessionIndex);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_CloseSession_1(TElPKCS11CertStorageHandle _Handle, TElPKCS11SessionInfoHandle Session);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_OpenSession(TElPKCS11CertStorageHandle _Handle, int32_t SlotIndex, int8_t ReadOnly, TElPKCS11SessionInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_RefreshObjectList(TElPKCS11CertStorageHandle _Handle, int32_t SessionIndex);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_RefreshCertificateContexts(TElPKCS11CertStorageHandle _Handle, TElPKCS11SessionInfoHandle SessionInfo);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_UpdateCertificateContexts(TElPKCS11CertStorageHandle _Handle, TElPKCS11SessionInfoHandle SessionInfo);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_Remove(TElPKCS11CertStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_RemoveKey(TElPKCS11CertStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_AddObject(TElPKCS11CertStorageHandle _Handle, TSBPKCS11ObjectTypeRaw ObjectType, int8_t Token, int8_t Private, int8_t Modifiable, TElPKCS11AttributeListHandle Attributes, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_AddObject_1(TElPKCS11CertStorageHandle _Handle, int32_t SessionIndex, TSBPKCS11ObjectTypeRaw ObjectType, int8_t Token, int8_t Private, int8_t Modifiable, TElPKCS11AttributeListHandle Attributes, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_RemoveObject(TElPKCS11CertStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_RemoveObject_1(TElPKCS11CertStorageHandle _Handle, TElPKCS11ObjectHandle Obj);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_ClearObjects(TElPKCS11CertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_CopyObject(TElPKCS11CertStorageHandle _Handle, int32_t Index, int8_t Token, int8_t Private, int8_t Modifiable, TElPKCS11AttributeListHandle Attributes, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_CopyObject_1(TElPKCS11CertStorageHandle _Handle, TElPKCS11ObjectHandle Obj, int8_t Token, int8_t Private, int8_t Modifiable, TElPKCS11AttributeListHandle Attributes, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_GetObjects(TElPKCS11CertStorageHandle _Handle, int32_t CertIndex, TElPKCS11X509CertificateObjectHandle * CertObject, TElPKCS11PrivateKeyObjectHandle * PrivKeyObject, TElPKCS11PublicKeyObjectHandle * PubKeyObject);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_Certificates(TElPKCS11CertStorageHandle _Handle, int32_t Index, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_Keys(TElPKCS11CertStorageHandle _Handle, int32_t Index, TElKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_KeyIDs(TElPKCS11CertStorageHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_KeyIDs(TElPKCS11CertStorageHandle _Handle, int32_t Index, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_Session(TElPKCS11CertStorageHandle _Handle, int32_t Index, TElPKCS11SessionInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_Objects(TElPKCS11CertStorageHandle _Handle, int32_t Index, TElPKCS11ObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_Count(TElPKCS11CertStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_KeyCount(TElPKCS11CertStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_ObjectCount(TElPKCS11CertStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_SessionCount(TElPKCS11CertStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_UniqueID(TElPKCS11CertStorageHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_Module(TElPKCS11CertStorageHandle _Handle, TElPKCS11ModuleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_Opened(TElPKCS11CertStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_TrySingleThreadedMode(TElPKCS11CertStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_TrySingleThreadedMode(TElPKCS11CertStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_MonitorSlotEvents(TElPKCS11CertStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_MonitorSlotEvents(TElPKCS11CertStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_SlotEventMonitoringMode(TElPKCS11CertStorageHandle _Handle, TSBPKCS11SlotEventMonitoringModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_SlotEventMonitoringMode(TElPKCS11CertStorageHandle _Handle, TSBPKCS11SlotEventMonitoringModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_SlotEventMonitoringDelay(TElPKCS11CertStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_SlotEventMonitoringDelay(TElPKCS11CertStorageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_SynchronizeGUI(TElPKCS11CertStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_SynchronizeGUI(TElPKCS11CertStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_DLLName(TElPKCS11CertStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_DLLName(TElPKCS11CertStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_CryptoProvider(TElPKCS11CertStorageHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_CryptoProvider(TElPKCS11CertStorageHandle _Handle, TElCustomCryptoProviderHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_PKCS11Options(TElPKCS11CertStorageHandle _Handle, TSBPKCS11StorageOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_PKCS11Options(TElPKCS11CertStorageHandle _Handle, TSBPKCS11StorageOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_TokenAccessMode(TElPKCS11CertStorageHandle _Handle, TSBPKCS11TokenAccessModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_TokenAccessMode(TElPKCS11CertStorageHandle _Handle, TSBPKCS11TokenAccessModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_ImportOrder(TElPKCS11CertStorageHandle _Handle, TSBPKCS11CertStorageImportOrderRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_ImportOrder(TElPKCS11CertStorageHandle _Handle, TSBPKCS11CertStorageImportOrderRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_NSSParams(TElPKCS11CertStorageHandle _Handle, TElPKCS11NSSParamsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_PlatformPointerSize(TElPKCS11CertStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_PlatformPointerSize(TElPKCS11CertStorageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_PlatformLongIntSize(TElPKCS11CertStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_PlatformLongIntSize(TElPKCS11CertStorageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_PlatformAlignment(TElPKCS11CertStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_PlatformAlignment(TElPKCS11CertStorageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_OnNotification(TElPKCS11CertStorageHandle _Handle, TElPKCSNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_OnNotification(TElPKCS11CertStorageHandle _Handle, TElPKCSNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_get_OnSlotEvent(TElPKCS11CertStorageHandle _Handle, TElPKCSSlotEventEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_set_OnSlotEvent(TElPKCS11CertStorageHandle _Handle, TElPKCSSlotEventEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11CertStorage_Create(TComponentHandle Owner, TElPKCS11CertStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11CERTSTORAGE */

#ifdef SB_USE_CLASS_TELPKCS11STGCTX
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11StgCtx_SetCertStorageName(TElPKCS11StgCtxHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11StgCtx_Create(TElPKCS11StgCtxHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11STGCTX */

#ifdef SB_USE_CLASS_TELPKCS11CONSUMERCERTSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11ConsumerCertStorage_Create(TElPKCS11ConsumerHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11CONSUMERCERTSTORAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPKCS11CertStorage_ce_ptr;
extern zend_class_entry *TElPKCS11StgCtx_ce_ptr;
extern zend_class_entry *TElPKCS11ConsumerCertStorage_ce_ptr;

void Register_TElPKCS11CertStorage(TSRMLS_D);
void Register_TElPKCS11StgCtx(TSRMLS_D);
void Register_TElPKCS11ConsumerCertStorage(TSRMLS_D);
SB_PHP_FUNCTION(SBPKCS11CertStorage, GetContextByCertificate);
void Register_SBPKCS11CertStorage_Enum_Flags(TSRMLS_D);
void Register_SBPKCS11CertStorage_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_PKCS11CERTSTORAGE
SB_IMPORT uint32_t SB_APIENTRY SBPKCS11CertStorage_GetContextByCertificate(TElX509CertificateHandle Cert, TElPKCS11StgCtxHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_PKCS11CERTSTORAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPKCS11CERTSTORAGE */

