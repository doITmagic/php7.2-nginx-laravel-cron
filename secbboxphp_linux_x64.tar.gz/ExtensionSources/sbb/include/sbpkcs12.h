#ifndef __INC_SBPKCS12
#define __INC_SBPKCS12

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbpkcs7.h"
#include "sbcrl.h"
#include "sbpkcs7utils.h"
#include "sbasn1tree.h"
#include "sbasn1.h"
#include "sbx509.h"
#include "sbrandom.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbmath.h"
#include "sbcryptoprov.h"
#include "sbhashfunction.h"
#include "sbcrlstorage.h"
#include "sbcustomcertstorage.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_PKCS12 	7936
#define SB_PKCS12_ERROR_INVALID_ASN_DATA 	7937
#define SB_PKCS12_ERROR_NO_DATA 	7938
#define SB_PKCS12_ERROR_INVALID_DATA 	7939
#define SB_PKCS12_ERROR_INVALID_VERSION 	7940
#define SB_PKCS12_ERROR_INVALID_CONTENT 	7941
#define SB_PKCS12_ERROR_INVALID_AUTHENTICATED_SAFE_DATA 	7942
#define SB_PKCS12_ERROR_INVALID_MAC_DATA 	7943
#define SB_PKCS12_ERROR_INVALID_SAFE_CONTENTS 	7944
#define SB_PKCS12_ERROR_INVALID_SAFE_BAG 	7945
#define SB_PKCS12_ERROR_INVALID_SHROUDED_KEY_BAG 	7946
#define SB_PKCS12_ERROR_UNKNOWN_PBE_ALGORITHM 	7947
#define SB_PKCS12_ERROR_INTERNAL_ERROR 	7948
#define SB_PKCS12_ERROR_INVALID_PBE_ALGORITHM_PARAMS 	7949
#define SB_PKCS12_ERROR_INVALID_CERT_BAG 	7950
#define SB_PKCS12_ERROR_UNSUPPORTED_CERTIFICATE_TYPE 	7951
#define SB_PKCS12_ERROR_INVALID_PRIVATE_KEY 	7952
#define SB_PKCS12_ERROR_INVALID_MAC 	7953
#define SB_PKCS12_ERROR_NO_CERTIFICATES 	7954
#define SB_PKCS12_ERROR_INVALID_PASSWORD 	7955
#define SB_PKCS12_ERROR_BUFFER_TOO_SMALL 	7956
#define SB_PKCS12_ERROR_INVALID_CRL_BAG 	7957
#define SB_PKCS12_ERROR_UNSUPPORTED_CRL_TYPE 	7958

typedef TElClassHandle TElPKCS12MessageHandle;

typedef TElPKCS12MessageHandle ElPKCS12MessageHandle;

#ifdef SB_USE_CLASS_TELPKCS12MESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_LoadFromBuffer(TElPKCS12MessageHandle _Handle, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_SaveToBuffer(TElPKCS12MessageHandle _Handle, void * Buffer, int32_t * Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_get_Iterations(TElPKCS12MessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_set_Iterations(TElPKCS12MessageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_get_Password(TElPKCS12MessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_set_Password(TElPKCS12MessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_get_Certificates(TElPKCS12MessageHandle _Handle, TElMemoryCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_get_CRLs(TElPKCS12MessageHandle _Handle, TElMemoryCRLStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_get_KeyEncryptionAlgorithm(TElPKCS12MessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_set_KeyEncryptionAlgorithm(TElPKCS12MessageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_get_CertEncryptionAlgorithm(TElPKCS12MessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_set_CertEncryptionAlgorithm(TElPKCS12MessageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_get_CRLEncryptionAlgorithm(TElPKCS12MessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_set_CRLEncryptionAlgorithm(TElPKCS12MessageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_get_UseEmptyPasswordWorkaround(TElPKCS12MessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_set_UseEmptyPasswordWorkaround(TElPKCS12MessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_get_CryptoProviderManager(TElPKCS12MessageHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_set_CryptoProviderManager(TElPKCS12MessageHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS12Message_Create(TElPKCS12MessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS12MESSAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPKCS12Message_ce_ptr;

void Register_TElPKCS12Message(TSRMLS_D);
SB_PHP_FUNCTION(SBPKCS12, BufToInt);
SB_PHP_FUNCTION(SBPKCS12, IntToBuf);
SB_PHP_FUNCTION(SBPKCS12, RaisePKCS12Error);
void Register_SBPKCS12_Constants(int module_number TSRMLS_DC);
void Register_SBPKCS12_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_PKCS12
SB_IMPORT uint32_t SB_APIENTRY SBPKCS12_BufToInt(void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS12_IntToBuf(int32_t Number, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS12_RaisePKCS12Error(int32_t ErrorCode);
#endif /* SB_USE_GLOBAL_PROCS_PKCS12 */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPKCS12 */

