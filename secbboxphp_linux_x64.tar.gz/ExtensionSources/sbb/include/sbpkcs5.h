#ifndef __INC_SBPKCS5
#define __INC_SBPKCS5

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbconstants.h"
#include "sbhashfunction.h"
#include "sbsymmetriccrypto.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_PKCS5 	7168
#define SB_PKCS5_ERROR_UNSUPPORTED_ALGORITHM 	7169

typedef TElClassHandle TElPKCS5PBEHandle;

typedef uint8_t TSBPKCS5VersionRaw;

typedef enum
{
	sbP5v1 = 0,
	sbP5v2 = 1
} TSBPKCS5Version;

#ifdef SB_USE_CLASS_TELPKCS5PBE
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_Decrypt(TElPKCS5PBEHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, const char * pcPassword, int32_t szPassword);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_Encrypt(TElPKCS5PBEHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, const char * pcPassword, int32_t szPassword);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_DeriveKey(TElPKCS5PBEHandle _Handle, const char * pcPassword, int32_t szPassword, int32_t Bits, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_DeriveKey_1(TElPKCS5PBEHandle _Handle, const uint8_t pPassword[], int32_t szPassword, int32_t Bits, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_IsPRFSupported(TElPKCS5PBEHandle _Handle, int32_t Alg, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_IsAlgorithmSupported(int32_t Alg, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_IsAlgorithmSupported_1(TElPKCS5PBEHandle _Handle, int32_t Alg, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_IsAlgorithmSupported_2(const uint8_t pOID[], int32_t szOID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_IsAlgorithmSupported_3(TElPKCS5PBEHandle _Handle, const uint8_t pOID[], int32_t szOID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_GetAlgorithmByOID(const uint8_t pOID[], int32_t szOID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_GetAlgorithmByOID_1(TElPKCS5PBEHandle _Handle, const uint8_t pOID[], int32_t szOID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_get_Algorithm(TElPKCS5PBEHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_get_Version(TElPKCS5PBEHandle _Handle, TSBPKCS5VersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_get_EncryptionAlgorithmOID(TElPKCS5PBEHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_get_EncryptionAlgorithmParams(TElPKCS5PBEHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_get_Salt(TElPKCS5PBEHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_set_Salt(TElPKCS5PBEHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_get_IterationCount(TElPKCS5PBEHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_set_IterationCount(TElPKCS5PBEHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_get_PseudoRandomFunction(TElPKCS5PBEHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_set_PseudoRandomFunction(TElPKCS5PBEHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_Create(const uint8_t pOID[], int32_t szOID, const uint8_t pParams[], int32_t szParams, TElPKCS5PBEHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS5PBE_Create_1(int32_t StreamAlg, int32_t HashAlg, int8_t UseNewVersion, TElPKCS5PBEHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS5PBE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPKCS5PBE_ce_ptr;

void Register_TElPKCS5PBE(TSRMLS_D);
SB_PHP_FUNCTION(SBPKCS5, DeriveRouteOneOTP);
void Register_SBPKCS5_Constants(int module_number TSRMLS_DC);
void Register_SBPKCS5_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_PKCS5
SB_IMPORT uint32_t SB_APIENTRY SBPKCS5_DeriveRouteOneOTP(const char * pcInput, int32_t szInput, const char * pcPassword, int32_t szPassword, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_PKCS5 */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPKCS5 */

