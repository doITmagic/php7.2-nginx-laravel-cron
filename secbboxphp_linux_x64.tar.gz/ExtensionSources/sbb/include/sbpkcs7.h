#ifndef __INC_SBPKCS7
#define __INC_SBPKCS7

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbasn1tree.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbrdn.h"
#include "sbpkcs7utils.h"
#include "sbstreams.h"
#include "sbalgorithmidentifier.h"
#include "sbcrl.h"
#include "sbcrlstorage.h"
#include "sbocspcommon.h"
#include "sbocspclient.h"
#include "sbocspstorage.h"
#include "sbcustomcertstorage.h"
#include "sbpem.h"
#include "sbencoding.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SBPKCS7_SB_OID_PKCS7_DATA 	"*\x86""H\x86""\xF7""\r\x01""\a\x01"
#define SB_OID_PKCS7_SIGNED_DATA 	"*\x86""H\x86""\xF7""\r\x01""\a\x02"
#define SB_OID_PKCS7_ENVELOPED_DATA 	"*\x86""H\x86""\xF7""\r\x01""\a\x03"
#define SB_OID_PKCS7_SIGNED_AND_ENVELOPED_DATA 	"*\x86""H\x86""\xF7""\r\x01""\a\x04"
#define SB_OID_PKCS7_DIGESTED_DATA 	"*\x86""H\x86""\xF7""\r\x01""\a\x05"
#define SB_OID_PKCS7_ENCRYPTED_DATA 	"*\x86""H\x86""\xF7""\r\x01""\a\x06"
#define SB_OID_PKCS7_AUTHENTICATED_DATA 	"*\x86""H\x86""\xF7""\r\x01""\t\x10""\x01""\x02"
#define SB_OID_PKCS7_COMPRESSED_DATA 	"*\x86""H\x86""\xF7""\r\x01""\t\x10""\x01""\t"
#define SB_OID_PKCS7_AUTH_ENVELOPED_DATA 	"*\x86""H\x86""\xF7""\r\x01""\t\x10""\x01""\x17"
#define SB_OID_PKCS7_TIMESTAMPED_DATA 	"*\x86""H\x86""\xF7""\r\x01""\t\x10""\x01""\x1F"
#define SB_OID_PKCS7_COMPRESSION_ZLIB 	"*\x86""H\x86""\xF7""\r\x01""\t\x10""\x03""\b"

typedef TElClassHandle TElPKCS7RecipientHandle;

typedef TElClassHandle TElPKCS7ContentPartHandle;

typedef TElClassHandle TElPKCS7EncryptedContentHandle;

typedef TElClassHandle TElPKCS7MessageHandle;

typedef TElClassHandle TElPKCS7EnvelopedDataHandle;

typedef TElClassHandle TElPKCS7CompressedDataHandle;

typedef TElClassHandle TElPKCS7SignerHandle;

typedef TElClassHandle TElPKCS7SignedDataHandle;

typedef TElClassHandle TElPKCS7DigestedDataHandle;

typedef TElClassHandle TElPKCS7EncryptedDataHandle;

typedef TElClassHandle TElPKCS7SignedAndEnvelopedDataHandle;

typedef TElClassHandle TElPKCS7AuthenticatedDataHandle;

typedef TElClassHandle TElPKCS7TimestampAndCRLHandle;

typedef TElClassHandle TElPKCS7TimestampedDataHandle;

typedef TElClassHandle TElPKCS7AuthEnvelopedDataHandle;

typedef uint8_t TSBPKCS7ContentTypeRaw;

typedef enum
{
	ctData = 0,
	ctSignedData = 1,
	ctEnvelopedData = 2,
	ctSignedAndEnvelopedData = 3,
	ctDigestedData = 4,
	ctEncryptedData = 5,
	ctAuthenticatedData = 6,
	ctCompressedData = 7,
	ctTimestampedData = 8,
	ctAuthEnvelopedData = 9,
	ctUnknown = 10
} TSBPKCS7ContentType;

typedef TElClassHandle IElPKCS7SignedDataCommonHandle;

#ifdef SB_USE_CLASS_TELPKCS7RECIPIENT
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Recipient_get_Version(TElPKCS7RecipientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Recipient_set_Version(TElPKCS7RecipientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Recipient_get_Issuer(TElPKCS7RecipientHandle _Handle, TElPKCS7IssuerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Recipient_get_KeyEncryptionAlgorithm(TElPKCS7RecipientHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Recipient_set_KeyEncryptionAlgorithm(TElPKCS7RecipientHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Recipient_get_KeyEncryptionAlgorithmParams(TElPKCS7RecipientHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Recipient_set_KeyEncryptionAlgorithmParams(TElPKCS7RecipientHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Recipient_get_KeyEncryptionAlgorithmIdentifier(TElPKCS7RecipientHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Recipient_set_KeyEncryptionAlgorithmIdentifier(TElPKCS7RecipientHandle _Handle, TElAlgorithmIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Recipient_get_EncryptedKey(TElPKCS7RecipientHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Recipient_set_EncryptedKey(TElPKCS7RecipientHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Recipient_Create(TElPKCS7RecipientHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7RECIPIENT */

#ifdef SB_USE_CLASS_TELPKCS7CONTENTPART
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7ContentPart_Read(TElPKCS7ContentPartHandle _Handle, void * Buffer, int32_t Size, int32_t StartOffset, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7ContentPart_get_Size(TElPKCS7ContentPartHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7ContentPart_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7CONTENTPART */

#ifdef SB_USE_CLASS_TELPKCS7ENCRYPTEDCONTENT
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_AddContentPart(TElPKCS7EncryptedContentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_ClearContentParts(TElPKCS7EncryptedContentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_get_ContentType(TElPKCS7EncryptedContentHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_set_ContentType(TElPKCS7EncryptedContentHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_get_ContentEncryptionAlgorithm(TElPKCS7EncryptedContentHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_set_ContentEncryptionAlgorithm(TElPKCS7EncryptedContentHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_get_ContentEncryptionAlgorithmParams(TElPKCS7EncryptedContentHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_set_ContentEncryptionAlgorithmParams(TElPKCS7EncryptedContentHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_get_EncryptedContent(TElPKCS7EncryptedContentHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_set_EncryptedContent(TElPKCS7EncryptedContentHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_get_EncryptedContentParts(TElPKCS7EncryptedContentHandle _Handle, int32_t Index, TElASN1DataSourceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_get_EncryptedContentPartCount(TElPKCS7EncryptedContentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_get_DataSource(TElPKCS7EncryptedContentHandle _Handle, TElASN1DataSourceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_get_UseImplicitContentEncoding(TElPKCS7EncryptedContentHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_set_UseImplicitContentEncoding(TElPKCS7EncryptedContentHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedContent_Create(TElPKCS7EncryptedContentHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7ENCRYPTEDCONTENT */

#ifdef SB_USE_CLASS_TELPKCS7MESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_Reset(TElPKCS7MessageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_LoadFromBuffer(TElPKCS7MessageHandle _Handle, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_SaveToBuffer(TElPKCS7MessageHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_LoadFromStream(TElPKCS7MessageHandle _Handle, TStreamHandle Stream, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_LoadFromStream_1(TElPKCS7MessageHandle _Handle, TStreamHandle Stream, int8_t ReadOnly, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_SaveToStream(TElPKCS7MessageHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_ContentType(TElPKCS7MessageHandle _Handle, TSBPKCS7ContentTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_set_ContentType(TElPKCS7MessageHandle _Handle, TSBPKCS7ContentTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_Data(TElPKCS7MessageHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_set_Data(TElPKCS7MessageHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_EnvelopedData(TElPKCS7MessageHandle _Handle, TElPKCS7EnvelopedDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_CompressedData(TElPKCS7MessageHandle _Handle, TElPKCS7CompressedDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_SignedData(TElPKCS7MessageHandle _Handle, TElPKCS7SignedDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_DigestedData(TElPKCS7MessageHandle _Handle, TElPKCS7DigestedDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_EncryptedData(TElPKCS7MessageHandle _Handle, TElPKCS7EncryptedDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_SignedAndEnvelopedData(TElPKCS7MessageHandle _Handle, TElPKCS7SignedAndEnvelopedDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_AuthenticatedData(TElPKCS7MessageHandle _Handle, TElPKCS7AuthenticatedDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_TimestampedData(TElPKCS7MessageHandle _Handle, TElPKCS7TimestampedDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_AuthEnvelopedData(TElPKCS7MessageHandle _Handle, TElPKCS7AuthEnvelopedDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_UseImplicitContent(TElPKCS7MessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_set_UseImplicitContent(TElPKCS7MessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_UseUndefSize(TElPKCS7MessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_set_UseUndefSize(TElPKCS7MessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_NoOuterContentInfo(TElPKCS7MessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_set_NoOuterContentInfo(TElPKCS7MessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_AllowUnknownContentTypes(TElPKCS7MessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_set_AllowUnknownContentTypes(TElPKCS7MessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_get_CustomContentType(TElPKCS7MessageHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_set_CustomContentType(TElPKCS7MessageHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Message_Create(TElPKCS7MessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7MESSAGE */

#ifdef SB_USE_CLASS_TELPKCS7ENVELOPEDDATA
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EnvelopedData_AddRecipient(TElPKCS7EnvelopedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EnvelopedData_RemoveRecipient(TElPKCS7EnvelopedDataHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EnvelopedData_SaveToBuffer(TElPKCS7EnvelopedDataHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EnvelopedData_get_Version(TElPKCS7EnvelopedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EnvelopedData_set_Version(TElPKCS7EnvelopedDataHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EnvelopedData_get_Recipients(TElPKCS7EnvelopedDataHandle _Handle, int32_t Index, TElPKCS7RecipientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EnvelopedData_get_RecipientCount(TElPKCS7EnvelopedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EnvelopedData_get_EncryptedContent(TElPKCS7EnvelopedDataHandle _Handle, TElPKCS7EncryptedContentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EnvelopedData_get_OriginatorCertificates(TElPKCS7EnvelopedDataHandle _Handle, TElMemoryCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EnvelopedData_get_OriginatorCRLs(TElPKCS7EnvelopedDataHandle _Handle, TElMemoryCRLStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EnvelopedData_get_UnprotectedAttributes(TElPKCS7EnvelopedDataHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EnvelopedData_Create(TElPKCS7EnvelopedDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7ENVELOPEDDATA */

#ifdef SB_USE_CLASS_TELPKCS7COMPRESSEDDATA
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7CompressedData_SaveToBuffer(TElPKCS7CompressedDataHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7CompressedData_get_Version(TElPKCS7CompressedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7CompressedData_set_Version(TElPKCS7CompressedDataHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7CompressedData_get_ContentType(TElPKCS7CompressedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7CompressedData_set_ContentType(TElPKCS7CompressedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7CompressedData_get_CompressedContent(TElPKCS7CompressedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7CompressedData_set_CompressedContent(TElPKCS7CompressedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7CompressedData_get_CompressedContentParts(TElPKCS7CompressedDataHandle _Handle, int32_t Index, TElASN1DataSourceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7CompressedData_get_CompressedContentPartCount(TElPKCS7CompressedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7CompressedData_get_FragmentSize(TElPKCS7CompressedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7CompressedData_set_FragmentSize(TElPKCS7CompressedDataHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7CompressedData_get_DataSource(TElPKCS7CompressedDataHandle _Handle, TElASN1DataSourceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7CompressedData_Create(TElPKCS7CompressedDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7COMPRESSEDDATA */

#ifdef SB_USE_CLASS_TELPKCS7SIGNER
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_RecalculateAuthenticatedAttributes(TElPKCS7SignerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_RecalculateAuthenticatedAttributes_1(TElPKCS7SignerHandle _Handle, int8_t Reorder);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_Recalculate(TElPKCS7SignerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_Reset(TElPKCS7SignerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_Assign(TElPKCS7SignerHandle _Handle, TElPKCS7SignerHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_get_Version(TElPKCS7SignerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_set_Version(TElPKCS7SignerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_get_Issuer(TElPKCS7SignerHandle _Handle, TElPKCS7IssuerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_get_DigestAlgorithm(TElPKCS7SignerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_set_DigestAlgorithm(TElPKCS7SignerHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_get_DigestAlgorithmParams(TElPKCS7SignerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_set_DigestAlgorithmParams(TElPKCS7SignerHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_get_DigestEncryptionAlgorithm(TElPKCS7SignerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_set_DigestEncryptionAlgorithm(TElPKCS7SignerHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_get_DigestEncryptionAlgorithmParams(TElPKCS7SignerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_set_DigestEncryptionAlgorithmParams(TElPKCS7SignerHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_get_AuthenticatedAttributes(TElPKCS7SignerHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_get_UnauthenticatedAttributes(TElPKCS7SignerHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_get_EncryptedDigest(TElPKCS7SignerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_set_EncryptedDigest(TElPKCS7SignerHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_get_AuthenticatedAttributesPlain(TElPKCS7SignerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_get_Content(TElPKCS7SignerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_get_EncodedValue(TElPKCS7SignerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_get_ArchivalEncodedValue(TElPKCS7SignerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7Signer_Create(TElPKCS7SignerHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7SIGNER */

#ifdef SB_USE_CLASS_TELPKCS7SIGNEDDATA
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_AddContentPart(TElPKCS7SignedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_ClearContentParts(TElPKCS7SignedDataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_AddSigner(TElPKCS7SignedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_RemoveSigner(TElPKCS7SignedDataHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_SaveToBuffer(TElPKCS7SignedDataHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_SaveToStream(TElPKCS7SignedDataHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_PreSerialize(TElPKCS7SignedDataHandle _Handle, int8_t SerializeContent, int8_t SerializeCertsAndCrls);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_Version(TElPKCS7SignedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_set_Version(TElPKCS7SignedDataHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_Signers(TElPKCS7SignedDataHandle _Handle, int32_t Index, TElPKCS7SignerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_ContentParts(TElPKCS7SignedDataHandle _Handle, int32_t Index, TElASN1DataSourceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_SignerCount(TElPKCS7SignedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_Certificates(TElPKCS7SignedDataHandle _Handle, TElMemoryCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_CRLs(TElPKCS7SignedDataHandle _Handle, TElMemoryCRLStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_OCSPs(TElPKCS7SignedDataHandle _Handle, TElOCSPResponseStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_Content(TElPKCS7SignedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_set_Content(TElPKCS7SignedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_ContentType(TElPKCS7SignedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_set_ContentType(TElPKCS7SignedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_ContentPartCount(TElPKCS7SignedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_DataSource(TElPKCS7SignedDataHandle _Handle, TElASN1DataSourceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_EncodedCertificates(TElPKCS7SignedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_EncodedCRLs(TElPKCS7SignedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_EnvelopedContentPrefix(TElPKCS7SignedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_EnvelopedContentPostfix(TElPKCS7SignedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_IsMultipart(TElPKCS7SignedDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_RawMultipartContent(TElPKCS7SignedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_PreserveCachedContent(TElPKCS7SignedDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_set_PreserveCachedContent(TElPKCS7SignedDataHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_get_PreserveCachedElements(TElPKCS7SignedDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_set_PreserveCachedElements(TElPKCS7SignedDataHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedData_Create(TElPKCS7SignedDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7SIGNEDDATA */

#ifdef SB_USE_CLASS_TELPKCS7DIGESTEDDATA
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7DigestedData_get_DigestAlgorithm(TElPKCS7DigestedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7DigestedData_set_DigestAlgorithm(TElPKCS7DigestedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7DigestedData_get_DigestAlgorithmParams(TElPKCS7DigestedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7DigestedData_set_DigestAlgorithmParams(TElPKCS7DigestedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7DigestedData_get_Content(TElPKCS7DigestedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7DigestedData_set_Content(TElPKCS7DigestedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7DigestedData_get_Digest(TElPKCS7DigestedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7DigestedData_set_Digest(TElPKCS7DigestedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7DigestedData_get_Version(TElPKCS7DigestedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7DigestedData_set_Version(TElPKCS7DigestedDataHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7DigestedData_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7DIGESTEDDATA */

#ifdef SB_USE_CLASS_TELPKCS7ENCRYPTEDDATA
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedData_SaveToBuffer(TElPKCS7EncryptedDataHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedData_get_Version(TElPKCS7EncryptedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedData_set_Version(TElPKCS7EncryptedDataHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedData_get_EncryptedContent(TElPKCS7EncryptedDataHandle _Handle, TElPKCS7EncryptedContentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7EncryptedData_Create(TElPKCS7EncryptedDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7ENCRYPTEDDATA */

#ifdef SB_USE_CLASS_TELPKCS7SIGNEDANDENVELOPEDDATA
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_GetRecipient(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int32_t Index, TElPKCS7RecipientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_GetSigner(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int32_t Index, TElPKCS7SignerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_AddRecipient(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_AddSigner(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_RemoveRecipient(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_RemoveSigner(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_PreSerialize(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int8_t SerializeContent, int8_t SerializeCertsAndCrls);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_Version(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_set_Version(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_ContentType(TElPKCS7SignedAndEnvelopedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_set_ContentType(TElPKCS7SignedAndEnvelopedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_Recipients(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int32_t Index, TElPKCS7RecipientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_Signers(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int32_t Index, TElPKCS7SignerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_RecipientCount(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_EncryptedContent(TElPKCS7SignedAndEnvelopedDataHandle _Handle, TElPKCS7EncryptedContentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_Certificates(TElPKCS7SignedAndEnvelopedDataHandle _Handle, TElMemoryCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_CRLs(TElPKCS7SignedAndEnvelopedDataHandle _Handle, TElMemoryCRLStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_OCSPs(TElPKCS7SignedAndEnvelopedDataHandle _Handle, TElOCSPResponseStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_EncodedCertificates(TElPKCS7SignedAndEnvelopedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_EncodedCRLs(TElPKCS7SignedAndEnvelopedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_EnvelopedContentPrefix(TElPKCS7SignedAndEnvelopedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_EnvelopedContentPostfix(TElPKCS7SignedAndEnvelopedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_SignerCount(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_get_PreserveCachedElements(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_set_PreserveCachedElements(TElPKCS7SignedAndEnvelopedDataHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7SignedAndEnvelopedData_Create(TElPKCS7SignedAndEnvelopedDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7SIGNEDANDENVELOPEDDATA */

#ifdef SB_USE_CLASS_TELPKCS7AUTHENTICATEDDATA
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_AddRecipient(TElPKCS7AuthenticatedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_RemoveRecipient(TElPKCS7AuthenticatedDataHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_RecalculateAuthenticatedAttributes(TElPKCS7AuthenticatedDataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_Version(TElPKCS7AuthenticatedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_set_Version(TElPKCS7AuthenticatedDataHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_OriginatorCertificates(TElPKCS7AuthenticatedDataHandle _Handle, TElMemoryCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_OriginatorCRLs(TElPKCS7AuthenticatedDataHandle _Handle, TElMemoryCRLStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_Recipients(TElPKCS7AuthenticatedDataHandle _Handle, int32_t Index, TElPKCS7RecipientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_ContentParts(TElPKCS7AuthenticatedDataHandle _Handle, int32_t Index, TElASN1DataSourceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_RecipientCount(TElPKCS7AuthenticatedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_MacAlgorithm(TElPKCS7AuthenticatedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_set_MacAlgorithm(TElPKCS7AuthenticatedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_DigestAlgorithm(TElPKCS7AuthenticatedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_set_DigestAlgorithm(TElPKCS7AuthenticatedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_ContentType(TElPKCS7AuthenticatedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_set_ContentType(TElPKCS7AuthenticatedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_Content(TElPKCS7AuthenticatedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_set_Content(TElPKCS7AuthenticatedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_AuthenticatedAttributes(TElPKCS7AuthenticatedDataHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_UnauthenticatedAttributes(TElPKCS7AuthenticatedDataHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_Mac(TElPKCS7AuthenticatedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_set_Mac(TElPKCS7AuthenticatedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_AuthenticatedAttributesPlain(TElPKCS7AuthenticatedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_ContentPartCount(TElPKCS7AuthenticatedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_get_DataSource(TElPKCS7AuthenticatedDataHandle _Handle, TElASN1DataSourceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthenticatedData_Create(TElPKCS7AuthenticatedDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7AUTHENTICATEDDATA */

#ifdef SB_USE_CLASS_TELPKCS7TIMESTAMPANDCRL
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampAndCRL_SetEncodedTimestamp(TElPKCS7TimestampAndCRLHandle _Handle, const uint8_t pV[], int32_t szV);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampAndCRL_SetEncodedCRL(TElPKCS7TimestampAndCRLHandle _Handle, const uint8_t pV[], int32_t szV);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampAndCRL_SetEncodedValue(TElPKCS7TimestampAndCRLHandle _Handle, const uint8_t pV[], int32_t szV);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampAndCRL_get_EncodedTimestamp(TElPKCS7TimestampAndCRLHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampAndCRL_set_EncodedTimestamp(TElPKCS7TimestampAndCRLHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampAndCRL_get_EncodedCRL(TElPKCS7TimestampAndCRLHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampAndCRL_set_EncodedCRL(TElPKCS7TimestampAndCRLHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampAndCRL_get_EncodedValue(TElPKCS7TimestampAndCRLHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampAndCRL_set_EncodedValue(TElPKCS7TimestampAndCRLHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampAndCRL_Create(TElPKCS7TimestampAndCRLHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7TIMESTAMPANDCRL */

#ifdef SB_USE_CLASS_TELPKCS7TIMESTAMPEDDATA
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_AddTimestamp(TElPKCS7TimestampedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_RemoveTimestamp(TElPKCS7TimestampedDataHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_ClearTimestamps(TElPKCS7TimestampedDataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_WriteMetadata(TElPKCS7TimestampedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_WriteTimestampAndCRL(TElPKCS7TimestampedDataHandle _Handle, TElPKCS7TimestampAndCRLHandle Ts, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_get_DataURI(TElPKCS7TimestampedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_set_DataURI(TElPKCS7TimestampedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_get_HashProtected(TElPKCS7TimestampedDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_set_HashProtected(TElPKCS7TimestampedDataHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_get_FileName(TElPKCS7TimestampedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_set_FileName(TElPKCS7TimestampedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_get_MediaType(TElPKCS7TimestampedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_set_MediaType(TElPKCS7TimestampedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_get_MetaDataAvailable(TElPKCS7TimestampedDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_set_MetaDataAvailable(TElPKCS7TimestampedDataHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_get_Timestamps(TElPKCS7TimestampedDataHandle _Handle, int32_t Index, TElPKCS7TimestampAndCRLHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_get_TimestampCount(TElPKCS7TimestampedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_get_Content(TElPKCS7TimestampedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_set_Content(TElPKCS7TimestampedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_get_ContentParts(TElPKCS7TimestampedDataHandle _Handle, int32_t Index, TElASN1DataSourceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_get_ContentPartCount(TElPKCS7TimestampedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_get_DataSource(TElPKCS7TimestampedDataHandle _Handle, TElASN1DataSourceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7TimestampedData_Create(TElPKCS7TimestampedDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7TIMESTAMPEDDATA */

#ifdef SB_USE_CLASS_TELPKCS7AUTHENVELOPEDDATA
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_AddRecipient(TElPKCS7AuthEnvelopedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_RemoveRecipient(TElPKCS7AuthEnvelopedDataHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_RecalculateAuthenticatedAttributes(TElPKCS7AuthEnvelopedDataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_SaveToBuffer(TElPKCS7AuthEnvelopedDataHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_get_Version(TElPKCS7AuthEnvelopedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_set_Version(TElPKCS7AuthEnvelopedDataHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_get_OriginatorCertificates(TElPKCS7AuthEnvelopedDataHandle _Handle, TElMemoryCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_get_OriginatorCRLs(TElPKCS7AuthEnvelopedDataHandle _Handle, TElMemoryCRLStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_get_Recipients(TElPKCS7AuthEnvelopedDataHandle _Handle, int32_t Index, TElPKCS7RecipientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_get_RecipientCount(TElPKCS7AuthEnvelopedDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_get_AuthEncryptedContent(TElPKCS7AuthEnvelopedDataHandle _Handle, TElPKCS7EncryptedContentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_get_AuthenticatedAttributes(TElPKCS7AuthEnvelopedDataHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_get_UnauthenticatedAttributes(TElPKCS7AuthEnvelopedDataHandle _Handle, TElPKCS7AttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_get_Mac(TElPKCS7AuthEnvelopedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_set_Mac(TElPKCS7AuthEnvelopedDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_get_MacDataSource(TElPKCS7AuthEnvelopedDataHandle _Handle, TElASN1DataSourceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_get_AuthenticatedAttributesPlain(TElPKCS7AuthEnvelopedDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS7AuthEnvelopedData_Create(TElPKCS7AuthEnvelopedDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS7AUTHENVELOPEDDATA */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *IElPKCS7SignedDataCommon_ce_ptr;
extern zend_class_entry *TElPKCS7Recipient_ce_ptr;
extern zend_class_entry *TElPKCS7ContentPart_ce_ptr;
extern zend_class_entry *TElPKCS7EncryptedContent_ce_ptr;
extern zend_class_entry *TElPKCS7Message_ce_ptr;
extern zend_class_entry *TElPKCS7EnvelopedData_ce_ptr;
extern zend_class_entry *TElPKCS7CompressedData_ce_ptr;
extern zend_class_entry *TElPKCS7Signer_ce_ptr;
extern zend_class_entry *TElPKCS7SignedData_ce_ptr;
extern zend_class_entry *TElPKCS7DigestedData_ce_ptr;
extern zend_class_entry *TElPKCS7EncryptedData_ce_ptr;
extern zend_class_entry *TElPKCS7SignedAndEnvelopedData_ce_ptr;
extern zend_class_entry *TElPKCS7AuthenticatedData_ce_ptr;
extern zend_class_entry *TElPKCS7TimestampAndCRL_ce_ptr;
extern zend_class_entry *TElPKCS7TimestampedData_ce_ptr;
extern zend_class_entry *TElPKCS7AuthEnvelopedData_ce_ptr;

void Register_TElPKCS7Recipient(TSRMLS_D);
void Register_TElPKCS7ContentPart(TSRMLS_D);
void Register_TElPKCS7EncryptedContent(TSRMLS_D);
void Register_TElPKCS7Message(TSRMLS_D);
void Register_TElPKCS7EnvelopedData(TSRMLS_D);
void Register_TElPKCS7CompressedData(TSRMLS_D);
void Register_TElPKCS7Signer(TSRMLS_D);
void Register_TElPKCS7SignedData(TSRMLS_D);
void Register_TElPKCS7DigestedData(TSRMLS_D);
void Register_TElPKCS7EncryptedData(TSRMLS_D);
void Register_TElPKCS7SignedAndEnvelopedData(TSRMLS_D);
void Register_TElPKCS7AuthenticatedData(TSRMLS_D);
void Register_TElPKCS7TimestampAndCRL(TSRMLS_D);
void Register_TElPKCS7TimestampedData(TSRMLS_D);
void Register_TElPKCS7AuthEnvelopedData(TSRMLS_D);
SB_PHP_FUNCTION(SBPKCS7, ProcessContentInfo);
SB_PHP_FUNCTION(SBPKCS7, SaveSignerInfo);
SB_PHP_FUNCTION(SBPKCS7, ProcessSignerInfo);
SB_PHP_FUNCTION(SBPKCS7, RaisePKCS7Error);
void Register_SBPKCS7_Constants(int module_number TSRMLS_DC);
void Register_SBPKCS7_Enum_Flags(TSRMLS_D);
void Register_SBPKCS7_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_PKCS7
SB_IMPORT uint32_t SB_APIENTRY SBPKCS7_ProcessContentInfo(TElASN1ConstrainedTagHandle Tag, void * Buffer, int32_t * Size, uint8_t pContentType[], int32_t * szContentType, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS7_ProcessContentInfo_1(TElASN1ConstrainedTagHandle Tag, TObjectHandle PKCS7Data, int8_t ReadOnly, uint8_t pContentType[], int32_t * szContentType, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS7_SaveSignerInfo(TElASN1ConstrainedTagHandle Tag, TElPKCS7SignerHandle Signer);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS7_ProcessSignerInfo(TElASN1CustomTagHandle Tag, TElPKCS7SignerHandle SignerInfo, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBPKCS7_RaisePKCS7Error(int32_t ErrorCode);
#endif /* SB_USE_GLOBAL_PROCS_PKCS7 */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPKCS7 */

