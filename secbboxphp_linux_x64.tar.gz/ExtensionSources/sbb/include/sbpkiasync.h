#ifndef __INC_SBPKIASYNC
#define __INC_SBPKIASYNC

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbmath.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElPublicKeyAsyncCalculatorHandle;

typedef TElClassHandle TElPublicKeyComputationTokenHandle;

typedef uint8_t TSBPublicKeyComputationTokenTypeRaw;

typedef enum
{
	ttElgamalEncrypt = 0,
	ttElgamalSign = 1,
	ttDSASign = 2,
	ttPrimeGeneration = 3,
	ttDSAGeneration = 4,
	ttRSAGeneration = 5,
	ttElgamalGeneration = 6
} TSBPublicKeyComputationTokenType;

#ifdef SB_USE_CLASS_TELPUBLICKEYASYNCCALCULATOR
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_BeginElgamalEncryption(TElPublicKeyAsyncCalculatorHandle _Handle, PLInt P, PLInt G, PLInt Y, TElPublicKeyComputationTokenHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_EndElgamalEncryption(TElPublicKeyAsyncCalculatorHandle _Handle, TElPublicKeyComputationTokenHandle Token, PLInt Src, PLInt A, PLInt B);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_BeginElgamalSigning(TElPublicKeyAsyncCalculatorHandle _Handle, PLInt P, PLInt G, TElPublicKeyComputationTokenHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_EndElgamalSigning(TElPublicKeyAsyncCalculatorHandle _Handle, TElPublicKeyComputationTokenHandle Token, PLInt X, PLInt Src, PLInt A, PLInt B);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_BeginPrimeGeneration(TElPublicKeyAsyncCalculatorHandle _Handle, int32_t Bits, TElPublicKeyComputationTokenHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_EndPrimeGeneration(TElPublicKeyAsyncCalculatorHandle _Handle, TElPublicKeyComputationTokenHandle Token, PLInt Prime);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_BeginDSASigning(TElPublicKeyAsyncCalculatorHandle _Handle, PLInt P, PLInt Q, PLInt G, TElPublicKeyComputationTokenHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_EndDSASigning(TElPublicKeyAsyncCalculatorHandle _Handle, TElPublicKeyComputationTokenHandle Token, PLInt X, void * Hash, int32_t HashSize, PLInt R, PLInt S);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_BeginRSAGeneration(TElPublicKeyAsyncCalculatorHandle _Handle, int32_t Bits, TElPublicKeyComputationTokenHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_EndRSAGeneration(TElPublicKeyAsyncCalculatorHandle _Handle, TElPublicKeyComputationTokenHandle Token, PLInt M, PLInt PrivE, PLInt PubE, PLInt Prime1, PLInt Prime2, PLInt Exp1, PLInt Exp2, PLInt Coeff);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_EndRSAGeneration_1(TElPublicKeyAsyncCalculatorHandle _Handle, TElPublicKeyComputationTokenHandle Token, void * Blob, int32_t * BlobSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_BeginDSAGeneration(TElPublicKeyAsyncCalculatorHandle _Handle, int32_t Bits, TElPublicKeyComputationTokenHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_EndDSAGeneration(TElPublicKeyAsyncCalculatorHandle _Handle, TElPublicKeyComputationTokenHandle Token, PLInt P, PLInt Q, PLInt G, PLInt X, PLInt Y);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_EndDSAGeneration_1(TElPublicKeyAsyncCalculatorHandle _Handle, TElPublicKeyComputationTokenHandle Token, void * Blob, int32_t * BlobSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_BeginElgamalGeneration(TElPublicKeyAsyncCalculatorHandle _Handle, int32_t Bits, TElPublicKeyComputationTokenHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_EndElgamalGeneration(TElPublicKeyAsyncCalculatorHandle _Handle, TElPublicKeyComputationTokenHandle Token, PLInt P, PLInt G, PLInt X, PLInt Y);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_get_Priority(TElPublicKeyAsyncCalculatorHandle _Handle, TThreadPriorityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_set_Priority(TElPublicKeyAsyncCalculatorHandle _Handle, TThreadPriorityRaw Value);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyAsyncCalculator_Create(TComponentHandle AOwner, TElPublicKeyAsyncCalculatorHandle * OutResult);
#endif /* SB_USE_CLASS_TELPUBLICKEYASYNCCALCULATOR */

#ifdef SB_USE_CLASS_TELPUBLICKEYCOMPUTATIONTOKEN
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyComputationToken_Cancel(TElPublicKeyComputationTokenHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyComputationToken_get_TokenType(TElPublicKeyComputationTokenHandle _Handle, TSBPublicKeyComputationTokenTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyComputationToken_get_Finished(TElPublicKeyComputationTokenHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyComputationToken_get_Data(TElPublicKeyComputationTokenHandle _Handle, void * * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyComputationToken_set_Data(TElPublicKeyComputationTokenHandle _Handle, void * Value);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeyComputationToken_Create(TSBPublicKeyComputationTokenTypeRaw TokenType, TElPublicKeyAsyncCalculatorHandle Owner, TElPublicKeyComputationTokenHandle * OutResult);
#endif /* SB_USE_CLASS_TELPUBLICKEYCOMPUTATIONTOKEN */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPublicKeyAsyncCalculator_ce_ptr;
extern zend_class_entry *TElPublicKeyComputationToken_ce_ptr;

void Register_TElPublicKeyAsyncCalculator(TSRMLS_D);
void Register_TElPublicKeyComputationToken(TSRMLS_D);
SB_PHP_FUNCTION(SBPKIAsync, GetGlobalAsyncCalculator);
void Register_SBPKIAsync_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_PKIASYNC
SB_IMPORT uint32_t SB_APIENTRY SBPKIAsync_GetGlobalAsyncCalculator(TElPublicKeyAsyncCalculatorHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_PKIASYNC */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPKIASYNC */
