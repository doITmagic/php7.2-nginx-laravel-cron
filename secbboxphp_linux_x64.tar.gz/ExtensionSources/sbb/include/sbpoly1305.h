#ifndef __INC_SBPOLY1305
#define __INC_SBPOLY1305

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef uint8_t TSBPoly1305Tag[16];

typedef uint8_t TSBPoly1305ModeRaw;

typedef enum
{
	pmDefault = 0,
	pmOpenSSH = 1,
	pmSSL = 2
} TSBPoly1305Mode;

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TSBPoly1305Tag_ce_ptr;

void Register_TSBPoly1305Tag(TSRMLS_D);
void Register_SBPoly1305_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPOLY1305 */

