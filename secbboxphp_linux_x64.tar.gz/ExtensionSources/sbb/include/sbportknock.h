#ifndef __INC_SBPORTKNOCK
#define __INC_SBPORTKNOCK

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbhttpauth.h"
#include "sbstringlist.h"
#include "sbhttpsconstants.h"
#include "sbencoding.h"
#include "sbdnssectypes.h"
#include "sbsocket.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElPortKnockEntryHandle;

typedef TElClassHandle TElPortKnockHandle;

typedef TElPortKnockHandle ElPortKnockHandle;

#ifdef SB_USE_CLASS_TELPORTKNOCKENTRY
SB_IMPORT uint32_t SB_APIENTRY TElPortKnockEntry_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELPORTKNOCKENTRY */

#ifdef SB_USE_CLASS_TELPORTKNOCK
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_TestRuleString(const char * pcRuleString, int32_t szRuleString, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_TestRuleString_1(TElPortKnockHandle _Handle, const char * pcRuleString, int32_t szRuleString, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_Knock(TElPortKnockHandle _Handle, const char * pcConnectionAddress, int32_t szConnectionAddress, int8_t KnockToClose);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_UsingIPv6(TElPortKnockHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_InternalSocket(TElPortKnockHandle _Handle, TElSocketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_Address(TElPortKnockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_Address(TElPortKnockHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_BeforeConnectRules(TElPortKnockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_BeforeConnectRules(TElPortKnockHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_AfterDisconnectRules(TElPortKnockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_AfterDisconnectRules(TElPortKnockHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_ProxyResult(TElPortKnockHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_SocksAuthentication(TElPortKnockHandle _Handle, TElSocksAuthenticationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_SocksAuthentication(TElPortKnockHandle _Handle, TElSocksAuthenticationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_SocksPassword(TElPortKnockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_SocksPassword(TElPortKnockHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_SocksPort(TElPortKnockHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_SocksPort(TElPortKnockHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_SocksResolveAddress(TElPortKnockHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_SocksResolveAddress(TElPortKnockHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_SocksServer(TElPortKnockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_SocksServer(TElPortKnockHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_SocksUserCode(TElPortKnockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_SocksUserCode(TElPortKnockHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_SocksVersion(TElPortKnockHandle _Handle, TElSocksVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_SocksVersion(TElPortKnockHandle _Handle, TElSocksVersionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_SocksUseIPv6(TElPortKnockHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_SocksUseIPv6(TElPortKnockHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_UseIPv6(TElPortKnockHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_UseIPv6(TElPortKnockHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_UseSocks(TElPortKnockHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_UseSocks(TElPortKnockHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_DNS(TElPortKnockHandle _Handle, TElDNSSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_DNS(TElPortKnockHandle _Handle, TElDNSSettingsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_UseWebTunneling(TElPortKnockHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_UseWebTunneling(TElPortKnockHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_WebTunnelAddress(TElPortKnockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_WebTunnelAddress(TElPortKnockHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_WebTunnelAuthentication(TElPortKnockHandle _Handle, TElWebTunnelAuthenticationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_WebTunnelAuthentication(TElPortKnockHandle _Handle, TElWebTunnelAuthenticationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_WebTunnelPassword(TElPortKnockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_WebTunnelPassword(TElPortKnockHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_WebTunnelPort(TElPortKnockHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_WebTunnelPort(TElPortKnockHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_WebTunnelUserId(TElPortKnockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_WebTunnelUserId(TElPortKnockHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_WebTunnelRequestHeaders(TElPortKnockHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_WebTunnelResponseHeaders(TElPortKnockHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_WebTunnelResponseBody(TElPortKnockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_SocketBinding(TElPortKnockHandle _Handle, TElClientSocketBindingHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_SocketBinding(TElPortKnockHandle _Handle, TElClientSocketBindingHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_OnDNSKeyNeeded(TElPortKnockHandle _Handle, TSBDNSKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_OnDNSKeyNeeded(TElPortKnockHandle _Handle, TSBDNSKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_OnDNSKeyValidate(TElPortKnockHandle _Handle, TSBDNSKeyValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_OnDNSKeyValidate(TElPortKnockHandle _Handle, TSBDNSKeyValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_get_OnDNSResolve(TElPortKnockHandle _Handle, TSBDNSResolveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_set_OnDNSResolve(TElPortKnockHandle _Handle, TSBDNSResolveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElPortKnock_Create(TComponentHandle AOwner, TElPortKnockHandle * OutResult);
#endif /* SB_USE_CLASS_TELPORTKNOCK */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPortKnockEntry_ce_ptr;
extern zend_class_entry *TElPortKnock_ce_ptr;

void Register_TElPortKnockEntry(TSRMLS_D);
void Register_TElPortKnock(TSRMLS_D);
void Register_SBPortKnock_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBPORTKNOCK */

