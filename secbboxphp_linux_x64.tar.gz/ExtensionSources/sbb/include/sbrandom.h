#ifndef __INC_SBRANDOM
#define __INC_SBRANDOM

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbmath.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElRandomHandle;

typedef TElRandomHandle ElRandomHandle;

#ifdef SB_USE_CLASS_TELRANDOM
SB_IMPORT uint32_t SB_APIENTRY TElRandom_Randomize(TElRandomHandle _Handle, const uint8_t pSeed[], int32_t szSeed);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElRandom_Randomize_1(TElRandomHandle _Handle, TStreamHandle Stream, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElRandom_Randomize_2(TElRandomHandle _Handle, void * Buffer, int32_t Count);
#else
SB_IMPORT uint32_t SB_APIENTRY TElRandom_Randomize_1(TElRandomHandle _Handle, void * Buffer, int32_t Count);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElRandom_Generate(TElRandomHandle _Handle, int32_t Count, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRandom_Generate_1(TElRandomHandle _Handle, void * Buffer, int32_t Count);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElRandom_Generate_2(TElRandomHandle _Handle, TStreamHandle Stream, int32_t Count);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElRandom_Seed(TElRandomHandle _Handle, void * Buffer, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElRandom_SeedSystem(TElRandomHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElRandom_Create(TElRandomHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRandom_Create_1(uint32_t TimeSeed, TElRandomHandle * OutResult);
#endif /* SB_USE_CLASS_TELRANDOM */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElRandom_ce_ptr;

void Register_TElRandom(TSRMLS_D);
SB_PHP_FUNCTION(SBRandom, SBRndTimeSeed);
SB_PHP_FUNCTION(SBRandom, SBRndInit);
SB_PHP_FUNCTION(SBRandom, SBRndInitOnDemand);
SB_PHP_FUNCTION(SBRandom, SBRndCreate);
SB_PHP_FUNCTION(SBRandom, SBRndDestroy);
SB_PHP_FUNCTION(SBRandom, SBRndSeed);
SB_PHP_FUNCTION(SBRandom, SBRndSeedTime);
SB_PHP_FUNCTION(SBRandom, SBRndGenerate);
SB_PHP_FUNCTION(SBRandom, SBRndGenerateLInt);
SB_PHP_FUNCTION(SBRandom, SBRndRandomize);
SB_PHP_FUNCTION(SBRandom, SBRndString);
void Register_SBRandom_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_RANDOM
SB_IMPORT uint32_t SB_APIENTRY SBRandom_SBRndTimeSeed(int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBRandom_SBRndInit(void);
SB_IMPORT uint32_t SB_APIENTRY SBRandom_SBRndInitOnDemand(void);
SB_IMPORT uint32_t SB_APIENTRY SBRandom_SBRndCreate(void);
SB_IMPORT uint32_t SB_APIENTRY SBRandom_SBRndDestroy(void);
SB_IMPORT uint32_t SB_APIENTRY SBRandom_SBRndSeed(const char * pcSalt, int32_t szSalt);
SB_IMPORT uint32_t SB_APIENTRY SBRandom_SBRndSeed_1(void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY SBRandom_SBRndSeedTime(void);
SB_IMPORT uint32_t SB_APIENTRY SBRandom_SBRndGenerate(void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY SBRandom_SBRndGenerate_1(uint32_t UpperBound, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBRandom_SBRndGenerateLInt(PLInt A, int32_t Bytes);
SB_IMPORT uint32_t SB_APIENTRY SBRandom_SBRndRandomize(const uint8_t pSeed[], int32_t szSeed);
SB_IMPORT uint32_t SB_APIENTRY SBRandom_SBRndString(int32_t Len, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBRandom_SBRndString_1(int32_t Len, const char * pcAlphabet, int32_t szAlphabet, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_RANDOM */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBRANDOM */
