#ifndef __INC_SBRDN
#define __INC_SBRDN

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstringlist.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbchsunicode.h"
#include "sbasn1tree.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElRelativeDistinguishedNameHandle;

typedef TElRelativeDistinguishedNameHandle ElRelativeDistinguishedNameHandle;

typedef TElClassHandle TElRDNConverterHandle;

#ifdef SB_USE_CLASS_TELRELATIVEDISTINGUISHEDNAME
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_Assign(TElRelativeDistinguishedNameHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_CopyTo(TElRelativeDistinguishedNameHandle _Handle, TElRelativeDistinguishedNameHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_LoadFromTag(TElRelativeDistinguishedNameHandle _Handle, TElASN1ConstrainedTagHandle Tag, int8_t IgnoreTopSequence, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_LoadFromDNString(TElRelativeDistinguishedNameHandle _Handle, const char * pcS, int32_t szS, int8_t LiberalMode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_LoadFromBuffer(TElRelativeDistinguishedNameHandle _Handle, const uint8_t pBuf[], int32_t szBuf, int32_t StartIndex, int32_t Count, int8_t IgnoreTopSequence, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_SaveToTag(TElRelativeDistinguishedNameHandle _Handle, TElASN1ConstrainedTagHandle Tag, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_SaveToDNString(TElRelativeDistinguishedNameHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_SaveToBuffer(TElRelativeDistinguishedNameHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_Add(TElRelativeDistinguishedNameHandle _Handle, const uint8_t pOID[], int32_t szOID, const uint8_t pValue[], int32_t szValue, uint8_t Tag, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_Remove(TElRelativeDistinguishedNameHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_IndexOf(TElRelativeDistinguishedNameHandle _Handle, const uint8_t pOID[], int32_t szOID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_Clear(TElRelativeDistinguishedNameHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_GetValuesByOID(TElRelativeDistinguishedNameHandle _Handle, const uint8_t pOID[], int32_t szOID, TElByteArrayListHandle Values);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_GetFirstValueByOID(TElRelativeDistinguishedNameHandle _Handle, const uint8_t pOID[], int32_t szOID, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_GetStringValuesByOID(TElRelativeDistinguishedNameHandle _Handle, const uint8_t pOID[], int32_t szOID, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_GetStringValuesByOID_1(TElRelativeDistinguishedNameHandle _Handle, const uint8_t pOID[], int32_t szOID, const char * pcValueSeparator, int32_t szValueSeparator, int8_t EncodeSpecialChars, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_GetFirstStringValueByOID(TElRelativeDistinguishedNameHandle _Handle, const uint8_t pOID[], int32_t szOID, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_GetFirstStringValueByOID_1(TElRelativeDistinguishedNameHandle _Handle, const uint8_t pOID[], int32_t szOID, int8_t EncodeSpecialChars, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_Contains(TElRelativeDistinguishedNameHandle _Handle, TElRelativeDistinguishedNameHandle RDN, int8_t IgnoreTags, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_get_Values(TElRelativeDistinguishedNameHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_set_Values(TElRelativeDistinguishedNameHandle _Handle, int32_t Index, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_get_NormValues(TElRelativeDistinguishedNameHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_set_NormValues(TElRelativeDistinguishedNameHandle _Handle, int32_t Index, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_get_OIDs(TElRelativeDistinguishedNameHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_set_OIDs(TElRelativeDistinguishedNameHandle _Handle, int32_t Index, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_get_Tags(TElRelativeDistinguishedNameHandle _Handle, int32_t Index, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_set_Tags(TElRelativeDistinguishedNameHandle _Handle, int32_t Index, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_get_Groups(TElRelativeDistinguishedNameHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_set_Groups(TElRelativeDistinguishedNameHandle _Handle, int32_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_get_Count(TElRelativeDistinguishedNameHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_set_Count(TElRelativeDistinguishedNameHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeDistinguishedName_Create(TElRelativeDistinguishedNameHandle * OutResult);
#endif /* SB_USE_CLASS_TELRELATIVEDISTINGUISHEDNAME */

#ifdef SB_USE_CLASS_TELRDNCONVERTER
SB_IMPORT uint32_t SB_APIENTRY TElRDNConverter_SaveToDNString(TElRDNConverterHandle _Handle, TElRelativeDistinguishedNameHandle RDN, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRDNConverter_LoadFromDNString(TElRDNConverterHandle _Handle, TElRelativeDistinguishedNameHandle RDN, const char * pcS, int32_t szS, int8_t LiberalMode);
SB_IMPORT uint32_t SB_APIENTRY TElRDNConverter_get_Separator(TElRDNConverterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRDNConverter_set_Separator(TElRDNConverterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElRDNConverter_get_InsertSeparatorPrefix(TElRDNConverterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRDNConverter_set_InsertSeparatorPrefix(TElRDNConverterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElRDNConverter_Create(TElRDNConverterHandle * OutResult);
#endif /* SB_USE_CLASS_TELRDNCONVERTER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElRelativeDistinguishedName_ce_ptr;
extern zend_class_entry *TElRDNConverter_ce_ptr;

void Register_TElRelativeDistinguishedName(TSRMLS_D);
void Register_TElRDNConverter(TSRMLS_D);
SB_PHP_FUNCTION(SBRDN, FormatRDN);
SB_PHP_FUNCTION(SBRDN, MapUnicodeString);
SB_PHP_FUNCTION(SBRDN, InsignificantSpaceHandling);
SB_PHP_FUNCTION(SBRDN, GetRDNStringValue);
SB_PHP_FUNCTION(SBRDN, GetNormalizedRDNStringValue);
SB_PHP_FUNCTION(SBRDN, GetNormalizedRDNString);
SB_PHP_FUNCTION(SBRDN, CompareRDN);
SB_PHP_FUNCTION(SBRDN, CompareRDNAsStrings);
SB_PHP_FUNCTION(SBRDN, NonstrictCompareRDN);
SB_PHP_FUNCTION(SBRDN, NonstrictCompareRDNAsStrings);
SB_PHP_FUNCTION(SBRDN, GetIgnoreTagsWhenComparingRDNs);
SB_PHP_FUNCTION(SBRDN, SetIgnoreTagsWhenComparingRDNs);
void Register_SBRDN_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_RDN
SB_IMPORT uint32_t SB_APIENTRY SBRDN_FormatRDN(TElRelativeDistinguishedNameHandle RDN, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBRDN_MapUnicodeString(const char * pcstr, int32_t szstr, int8_t CaseIgnore, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBRDN_InsignificantSpaceHandling(const char * pcstr, int32_t szstr, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBRDN_GetRDNStringValue(const TElRelativeDistinguishedNameHandle RDN, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBRDN_GetNormalizedRDNStringValue(const TElRelativeDistinguishedNameHandle RDN, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBRDN_GetNormalizedRDNString(const char * pcValue, int32_t szValue, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBRDN_CompareRDN(TElRelativeDistinguishedNameHandle Name1, TElRelativeDistinguishedNameHandle Name2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBRDN_CompareRDNAsStrings(TElRelativeDistinguishedNameHandle Name1, TElRelativeDistinguishedNameHandle Name2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBRDN_NonstrictCompareRDN(TElRelativeDistinguishedNameHandle InnerRDN, TElRelativeDistinguishedNameHandle OuterRDN, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBRDN_NonstrictCompareRDNAsStrings(TElRelativeDistinguishedNameHandle InnerRDN, TElRelativeDistinguishedNameHandle OuterRDN, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBRDN_GetIgnoreTagsWhenComparingRDNs(int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBRDN_SetIgnoreTagsWhenComparingRDNs(int8_t Value);
#endif /* SB_USE_GLOBAL_PROCS_RDN */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBRDN */

