#ifndef __INC_SBRESTCLIENT
#define __INC_SBRESTCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbhttpsclient.h"
#include "sbhttpscommon.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbxmlcore.h"
#include "sbxmldefs.h"
#include "sbjson.h"
#include "sbchsconv.h"
#include "sbchsconvcharsets.h"
#include "sbchscjk.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElRESTClientHandle;

typedef TElRESTClientHandle ElRESTClientHandle;

typedef uint8_t TSBRESTResponseTypeRaw;

typedef enum
{
	rrtUnknown = 0,
	rrtXML = 1,
	rrtJSON = 2
} TSBRESTResponseType;

#ifdef SB_USE_CLASS_TELRESTCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Post(TElRESTClientHandle _Handle, const char * pcURL, int32_t szURL, TElXMLDOMDocumentHandle Content, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Post_1(TElRESTClientHandle _Handle, const char * pcURL, int32_t szURL, TElJsonEntityHandle Content, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Post_2(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Post_3(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcContent, int32_t szContent, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Post_4(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, const uint8_t pContent[], int32_t szContent, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Post_5(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, TStreamHandle Content, int8_t CloseStream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Put(TElRESTClientHandle _Handle, const char * pcURL, int32_t szURL, TElXMLDOMDocumentHandle Content, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Put_1(TElRESTClientHandle _Handle, const char * pcURL, int32_t szURL, TElJsonEntityHandle Content, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Put_2(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Put_3(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, int64_t ContentLength, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Put_4(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcContent, int32_t szContent, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Put_5(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, const uint8_t pContent[], int32_t szContent, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Put_6(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, const uint8_t pContent[], int32_t szContent, int32_t StartIndex, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Put_7(TElHTTPSClientHandle _Handle, const char * pcURL, int32_t szURL, TStreamHandle Content, int8_t CloseStream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_get_XMLCanonicalizationMethod(TElRESTClientHandle _Handle, TElXMLCanonicalizationMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_set_XMLCanonicalizationMethod(TElRESTClientHandle _Handle, TElXMLCanonicalizationMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_get_XMLCharset(TElRESTClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_set_XMLCharset(TElRESTClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_get_JSONIndentChar(TElRESTClientHandle _Handle, char * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_set_JSONIndentChar(TElRESTClientHandle _Handle, char Value);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_get_JSONCharsPerIndentLevel(TElRESTClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_set_JSONCharsPerIndentLevel(TElRESTClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_get_ResponseType(TElRESTClientHandle _Handle, TSBRESTResponseTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_get_ResponseXML(TElRESTClientHandle _Handle, TElXMLDOMDocumentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_get_ResponseJSON(TElRESTClientHandle _Handle, TElJsonEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_get_ResponseText(TElRESTClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRESTClient_Create(TComponentHandle AOwner, TElRESTClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELRESTCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElRESTClient_ce_ptr;

void Register_TElRESTClient(TSRMLS_D);
void Register_SBRESTClient_Enum_Flags(TSRMLS_D);
void Register_SBRESTClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBRESTCLIENT */

