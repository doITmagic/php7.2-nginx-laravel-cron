#ifndef __INC_SBSAMLIDENTITYPROVIDER
#define __INC_SBSAMLIDENTITYPROVIDER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstringlist.h"
#include "sbx509.h"
#include "sbcustomcertstorage.h"
#include "sbsslcommon.h"
#include "sbsslserver.h"
#include "sbsessionpool.h"
#include "sbhttpscommon.h"
#include "sbencoding.h"
#include "sbdictionary.h"
#include "sbhttpsconstants.h"
#include "sbhttpsserver.h"
#include "sbsharedresource.h"
#include "sbhashfunction.h"
#include "sbsslconstants.h"
#include "sbcookiemgr.h"
#include "sbxmlcore.h"
#include "sbxmlsec.h"
#include "sbxmlsig.h"
#include "sbxmlsamlcommon.h"
#include "sbxmlsamlprotocol.h"
#include "sbxmlsamlbind.h"
#include "sbxmlsamlcore.h"
#include "sbxmlsamlmetadata.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSAMLIDPSessionHandle;

typedef TElClassHandle TElSAMLServiceProviderInfoHandle;

typedef TElClassHandle TElSAMLSPDataHandle;

typedef TElClassHandle TElSAMLIDPCustomAuthSourceHandle;

typedef TElClassHandle TElSAMLIDRecordHandle;

typedef TElClassHandle TElSAMLIDPPasswordMemoryAuthSourceHandle;

typedef TElClassHandle TElSAMLIdPSSOLinkHandle;

typedef TElClassHandle TElSAMLIdentityProviderHandle;

typedef uint8_t TSBSAMLIDPCompatibilityOptionRaw;

typedef enum
{
	idcoMicrosoft = 0,
	idcoGoogleNoLogout = 1
} TSBSAMLIDPCompatibilityOption;

typedef uint32_t TSBSAMLIDPCompatibilityOptionsRaw;

typedef enum 
{
	f_idcoMicrosoft = 1,
	f_idcoGoogleNoLogout = 2
} TSBSAMLIDPCompatibilityOptions;

typedef uint8_t TSBSAMLIDPStageRaw;

typedef enum
{
	idpsStart = 0,
	idpsIdPSSORecv = 1,
	idpsAuthnRequestRecv = 2,
	idpsChallengeSent = 3,
	idpsCredentialsRecv = 4,
	idpsResponseSent = 5,
	idpsLoggedIn = 6,
	idpsLogoutRequestRecv = 7,
	idpsLogoutResponseSent = 8,
	idpsArtifactResolveRecv = 9,
	idpsArtifactResponseSent = 10,
	idpsAttributeQueryRecv = 11,
	idpsAttributeResponseSent = 12
} TSBSAMLIDPStage;

typedef void (SB_CALLBACK *SBSAMLIdentityProvider_TSBSAMLBeforeHTTPSServerUseEvent)(void * _ObjectData, TObjectHandle Sender, TElHTTPSServerHandle HTTPSServer);

typedef void (SB_CALLBACK *TSBSAMLPageContentEvent)(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle Request, TElHTTPServerResponseParamsHandle Response, uint8_t pContent[], int32_t * szContent, int32_t * Size);

typedef void (SB_CALLBACK *TSBSAMLChangeIDPSessionStageEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLIDPSessionHandle Session, TSBSAMLIDPStageRaw Stage);

typedef void (SB_CALLBACK *SBSAMLIdentityProvider_TSBSAMLSessionEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLIDPSessionHandle Session);

typedef void (SB_CALLBACK *SBSAMLIdentityProvider_TSBSAMLLogoutEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLIDPSessionHandle Session, TElHTTPServerResponseParamsHandle ResponseParams);

typedef void (SB_CALLBACK *TSBSAMLChooseAuthnContext)(void * _ObjectData, TObjectHandle Sender, TElSAMLAuthnRequestElementHandle Request, char * pcAuthnContextClassRef, int32_t * szAuthnContextClassRef);

typedef void (SB_CALLBACK *TSBSAMLChooseNameIDPolicyFormatEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLIDPSessionHandle Session, char * pcNameIDPolicy, int32_t * szNameIDPolicy);

typedef void (SB_CALLBACK *TSBSAMLIDPGetAttributeEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcID, int32_t szID, const char * pcFormat, int32_t szFormat, TElSAMLAttributeElementHandle Attribute, TElSAMLAttributeElementHandle Res);

typedef void (SB_CALLBACK *TSBSAMLIDPSetAttributeEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcID, int32_t szID, const char * pcFormat, int32_t szFormat, TElSAMLAttributeElementHandle Attribute, int8_t * Res);

#ifdef SB_USE_CLASS_TELSAMLIDPSESSION
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_AddServiceProvider(TElSAMLIDPSessionHandle _Handle, const char * pcSessionIndex, int32_t szSessionIndex, TElSAMLServiceProviderInfoHandle SPInfo);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_RemoveServiceProvider(TElSAMLIDPSessionHandle _Handle, const char * pcSessionIndex, int32_t szSessionIndex);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_LoggedIn(TElSAMLIDPSessionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_Stage(TElSAMLIDPSessionHandle _Handle, TSBSAMLIDPStageRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_set_Stage(TElSAMLIDPSessionHandle _Handle, TSBSAMLIDPStageRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_Login(TElSAMLIDPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_set_Login(TElSAMLIDPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_Certificate(TElSAMLIDPSessionHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_set_Certificate(TElSAMLIDPSessionHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_SAMLCookieSet(TElSAMLIDPSessionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_set_SAMLCookieSet(TElSAMLIDPSessionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_NameID(TElSAMLIDPSessionHandle _Handle, TElSAMLIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_set_NameID(TElSAMLIDPSessionHandle _Handle, TElSAMLIDHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_LoginAttempts(TElSAMLIDPSessionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_set_LoginAttempts(TElSAMLIDPSessionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_ServiceProviders(TElSAMLIDPSessionHandle _Handle, TElDictionaryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_LastSP(TElSAMLIDPSessionHandle _Handle, TElSAMLServiceProviderInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_set_LastSP(TElSAMLIDPSessionHandle _Handle, TElSAMLServiceProviderInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_Binding(TElSAMLIDPSessionHandle _Handle, TSBSAMLBindingTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_set_Binding(TElSAMLIDPSessionHandle _Handle, TSBSAMLBindingTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_ResponseLocation(TElSAMLIDPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_set_ResponseLocation(TElSAMLIDPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_AuthnContextClassRef(TElSAMLIDPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_set_AuthnContextClassRef(TElSAMLIDPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_NameIDPolicyFormat(TElSAMLIDPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_set_NameIDPolicyFormat(TElSAMLIDPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_SessionIndex(TElSAMLIDPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_set_SessionIndex(TElSAMLIDPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_get_IdPSSO(TElSAMLIDPSessionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_set_IdPSSO(TElSAMLIDPSessionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPSession_Create(TElSAMLIDPSessionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLIDPSESSION */

#ifdef SB_USE_CLASS_TELSAMLSERVICEPROVIDERINFO
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_CreateForGoogleAppEngine(const char * pcDomain, int32_t szDomain, TElSAMLServiceProviderInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_CreateForGoogleAppEngine_1(TElSAMLServiceProviderInfoHandle _Handle, const char * pcDomain, int32_t szDomain, TElSAMLServiceProviderInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_AddAssertionConsumerService(TElSAMLServiceProviderInfoHandle _Handle, TElSAMLEndpointHandle Endpoint, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_AddSingleLogoutService(TElSAMLServiceProviderInfoHandle _Handle, TElSAMLEndpointHandle Endpoint, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_AddArtifactResolutionService(TElSAMLServiceProviderInfoHandle _Handle, TElSAMLEndpointHandle Endpoint, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_RemoveAssertionConsumerService(TElSAMLServiceProviderInfoHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_RemoveSingleLogoutService(TElSAMLServiceProviderInfoHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_RemoveArtifactResolutionService(TElSAMLServiceProviderInfoHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_FindDefaultAssertionConsumerServiceEP(TElSAMLServiceProviderInfoHandle _Handle, TElSAMLEndpointHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_FindAssertionConsumerServiceEP(TElSAMLServiceProviderInfoHandle _Handle, TSBSAMLBindingTypeRaw Binding, TElSAMLEndpointHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_FindAssertionConsumerServiceEP_1(TElSAMLServiceProviderInfoHandle _Handle, const char * pcLocation, int32_t szLocation, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_FindAssertionConsumerServiceEP_2(TElSAMLServiceProviderInfoHandle _Handle, int32_t Idx, TElSAMLEndpointHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_FindSingleLogoutServiceEP(TElSAMLServiceProviderInfoHandle _Handle, TSBSAMLBindingTypeRaw Binding, TElSAMLEndpointHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_FindArtifactResolutionServiceEP(TElSAMLServiceProviderInfoHandle _Handle, TSBSAMLBindingTypeRaw Binding, TElSAMLEndpointHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_ChooseNameIDFormat(TElSAMLServiceProviderInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_LoadMetadata(TElSAMLServiceProviderInfoHandle _Handle, const char * pcURI, int32_t szURI);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_GetUniqueID(TElSAMLServiceProviderInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_EntityID(TElSAMLServiceProviderInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_set_EntityID(TElSAMLServiceProviderInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_SPNameQualifier(TElSAMLServiceProviderInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_set_SPNameQualifier(TElSAMLServiceProviderInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_IDPNameIDFormats(TElSAMLServiceProviderInfoHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_AssertionConsumerServices(TElSAMLServiceProviderInfoHandle _Handle, int32_t Index, TElSAMLEndpointHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_SingleLogoutServices(TElSAMLServiceProviderInfoHandle _Handle, int32_t Index, TElSAMLEndpointHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_ArtifactResolutionServices(TElSAMLServiceProviderInfoHandle _Handle, int32_t Index, TElSAMLEndpointHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_AssertionConsumerServiceCount(TElSAMLServiceProviderInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_SingleLogoutServiceCount(TElSAMLServiceProviderInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_ArtifactResolutionServiceCount(TElSAMLServiceProviderInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_SigningCertificate(TElSAMLServiceProviderInfoHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_set_SigningCertificate(TElSAMLServiceProviderInfoHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_EncryptionCertificate(TElSAMLServiceProviderInfoHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_set_EncryptionCertificate(TElSAMLServiceProviderInfoHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_MetaSigningCertificate(TElSAMLServiceProviderInfoHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_set_MetaSigningCertificate(TElSAMLServiceProviderInfoHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_SourceID(TElSAMLServiceProviderInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_set_SourceID(TElSAMLServiceProviderInfoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_OnBeforeHTTPSClientUse(TElSAMLServiceProviderInfoHandle _Handle, TSBSAMLBeforeHTTPSClientUseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_set_OnBeforeHTTPSClientUse(TElSAMLServiceProviderInfoHandle _Handle, TSBSAMLBeforeHTTPSClientUseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_get_OnChooseMetadataSPDescriptor(TElSAMLServiceProviderInfoHandle _Handle, TSBSAMLChooseMetadataDescriptorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_set_OnChooseMetadataSPDescriptor(TElSAMLServiceProviderInfoHandle _Handle, TSBSAMLChooseMetadataDescriptorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProviderInfo_Create(TElSAMLServiceProviderInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSERVICEPROVIDERINFO */

#ifdef SB_USE_CLASS_TELSAMLSPDATA
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPData_get_SessionIndex(TElSAMLSPDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPData_set_SessionIndex(TElSAMLSPDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPData_Create(TElSAMLSPDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSPDATA */

#ifdef SB_USE_CLASS_TELSAMLIDPCUSTOMAUTHSOURCE
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPCustomAuthSource_Add(TElSAMLIDPCustomAuthSourceHandle _Handle, const char * pcID, int32_t szID, const char * pcAuthToken, int32_t szAuthToken);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPCustomAuthSource_Remove(TElSAMLIDPCustomAuthSourceHandle _Handle, const char * pcID, int32_t szID);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPCustomAuthSource_Check(TElSAMLIDPCustomAuthSourceHandle _Handle, const char * pcID, int32_t szID, const char * pcAuthToken, int32_t szAuthToken, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPCustomAuthSource_GetSupportedIdentifierTypes(TElSAMLIDPCustomAuthSourceHandle _Handle, TStringListHandle OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPCustomAuthSource_GetIdentifier(TElSAMLIDPCustomAuthSourceHandle _Handle, const char * pcID, int32_t szID, const char * pcFormat, int32_t szFormat, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPCustomAuthSource_SetIdentifier(TElSAMLIDPCustomAuthSourceHandle _Handle, const char * pcID, int32_t szID, const char * pcFormat, int32_t szFormat, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPCustomAuthSource_GetAttribute(TElSAMLIDPCustomAuthSourceHandle _Handle, const char * pcID, int32_t szID, const char * pcFormat, int32_t szFormat, TElSAMLAttributeElementHandle Attribute, TElSAMLAttributeElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPCustomAuthSource_SetAttribute(TElSAMLIDPCustomAuthSourceHandle _Handle, const char * pcID, int32_t szID, const char * pcFormat, int32_t szFormat, TElSAMLAttributeElementHandle Attribute, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPCustomAuthSource_Create(TComponentHandle AOwner, TComponentHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLIDPCUSTOMAUTHSOURCE */

#ifdef SB_USE_CLASS_TELSAMLIDRECORD
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDRecord_get_Identifiers(TElSAMLIDRecordHandle _Handle, TElDictionaryHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDRecord_get_AuthToken(TElSAMLIDRecordHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDRecord_set_AuthToken(TElSAMLIDRecordHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDRecord_get_Email(TElSAMLIDRecordHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDRecord_set_Email(TElSAMLIDRecordHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDRecord_Create(TElSAMLIDRecordHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLIDRECORD */

#ifdef SB_USE_CLASS_TELSAMLIDPPASSWORDMEMORYAUTHSOURCE
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPPasswordMemoryAuthSource_GetSupportedIdentifierTypes(TElSAMLIDPPasswordMemoryAuthSourceHandle _Handle, TStringListHandle OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPPasswordMemoryAuthSource_GetIdentifier(TElSAMLIDPPasswordMemoryAuthSourceHandle _Handle, const char * pcID, int32_t szID, const char * pcFormat, int32_t szFormat, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPPasswordMemoryAuthSource_SetIdentifier(TElSAMLIDPPasswordMemoryAuthSourceHandle _Handle, const char * pcID, int32_t szID, const char * pcFormat, int32_t szFormat, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPPasswordMemoryAuthSource_GetAttribute(TElSAMLIDPPasswordMemoryAuthSourceHandle _Handle, const char * pcID, int32_t szID, const char * pcFormat, int32_t szFormat, TElSAMLAttributeElementHandle Attribute, TElSAMLAttributeElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPPasswordMemoryAuthSource_SetAttribute(TElSAMLIDPPasswordMemoryAuthSourceHandle _Handle, const char * pcID, int32_t szID, const char * pcFormat, int32_t szFormat, TElSAMLAttributeElementHandle Attribute, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPPasswordMemoryAuthSource_Add(TElSAMLIDPPasswordMemoryAuthSourceHandle _Handle, const char * pcID, int32_t szID, const char * pcAuthToken, int32_t szAuthToken);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPPasswordMemoryAuthSource_Add_1(TElSAMLIDPPasswordMemoryAuthSourceHandle _Handle, const char * pcID, int32_t szID, const char * pcEmail, int32_t szEmail, const char * pcAuthToken, int32_t szAuthToken);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPPasswordMemoryAuthSource_Remove(TElSAMLIDPPasswordMemoryAuthSourceHandle _Handle, const char * pcID, int32_t szID);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPPasswordMemoryAuthSource_Check(TElSAMLIDPPasswordMemoryAuthSourceHandle _Handle, const char * pcID, int32_t szID, const char * pcAuthToken, int32_t szAuthToken, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPPasswordMemoryAuthSource_get_OnGetAttribute(TElSAMLIDPPasswordMemoryAuthSourceHandle _Handle, TSBSAMLIDPGetAttributeEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPPasswordMemoryAuthSource_set_OnGetAttribute(TElSAMLIDPPasswordMemoryAuthSourceHandle _Handle, TSBSAMLIDPGetAttributeEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPPasswordMemoryAuthSource_get_OnSetAttribute(TElSAMLIDPPasswordMemoryAuthSourceHandle _Handle, TSBSAMLIDPSetAttributeEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPPasswordMemoryAuthSource_set_OnSetAttribute(TElSAMLIDPPasswordMemoryAuthSourceHandle _Handle, TSBSAMLIDPSetAttributeEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPPasswordMemoryAuthSource_Create(TElSAMLIDPPasswordMemoryAuthSourceHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLIDPPASSWORDMEMORYAUTHSOURCE */

#ifdef SB_USE_CLASS_TELSAMLIDPSSOLINK
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdPSSOLink_get_URL(TElSAMLIdPSSOLinkHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdPSSOLink_set_URL(TElSAMLIdPSSOLinkHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdPSSOLink_get_RelayState(TElSAMLIdPSSOLinkHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdPSSOLink_set_RelayState(TElSAMLIdPSSOLinkHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdPSSOLink_get_SPIndex(TElSAMLIdPSSOLinkHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdPSSOLink_set_SPIndex(TElSAMLIdPSSOLinkHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdPSSOLink_Create(TElSAMLIdPSSOLinkHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLIDPSSOLINK */

#ifdef SB_USE_CLASS_TELSAMLIDENTITYPROVIDER
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_Open(TElSAMLIdentityProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_DataAvailable(TElSAMLIdentityProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_Close(TElSAMLIdentityProviderHandle _Handle, int8_t Silent);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_SaveMetadata(TElSAMLIdentityProviderHandle _Handle, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_AddServiceProvider(TElSAMLIdentityProviderHandle _Handle, TElSAMLServiceProviderInfoHandle SPInfo, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_RemoveServiceProvider(TElSAMLIdentityProviderHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_AddIdPSSOLink(TElSAMLIdentityProviderHandle _Handle, TElSAMLIdPSSOLinkHandle Link, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_RemoveIdPSSOLink(TElSAMLIdentityProviderHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_ServiceProviders(TElSAMLIdentityProviderHandle _Handle, int32_t Index, TElSAMLServiceProviderInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_ServiceProviderCount(TElSAMLIdentityProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_IdPSSOLinks(TElSAMLIdentityProviderHandle _Handle, int32_t Index, TElSAMLIdPSSOLinkHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_IdPSSOLinkCount(TElSAMLIdentityProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_Control(TElSAMLIdentityProviderHandle _Handle, TElHTTPSServerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_Active(TElSAMLIdentityProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SupportedAuthnContextClasses(TElSAMLIdentityProviderHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SourceID(TElSAMLIdentityProviderHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SourceID(TElSAMLIdentityProviderHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_CurrentSession(TElSAMLIdentityProviderHandle _Handle, TElSAMLIDPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SendBufferSize(TElSAMLIdentityProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SendBufferSize(TElSAMLIdentityProviderHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_ServerName(TElSAMLIdentityProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_ServerName(TElSAMLIdentityProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_URL(TElSAMLIdentityProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_URL(TElSAMLIdentityProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SingleSignOnService(TElSAMLIdentityProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SingleSignOnService(TElSAMLIdentityProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SingleLogoutService(TElSAMLIdentityProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SingleLogoutService(TElSAMLIdentityProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_ArtifactResolutionService(TElSAMLIdentityProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_ArtifactResolutionService(TElSAMLIdentityProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_AttributeQueryService(TElSAMLIdentityProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_AttributeQueryService(TElSAMLIdentityProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SessionCookieName(TElSAMLIdentityProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SessionCookieName(TElSAMLIdentityProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_CertStorage(TElSAMLIdentityProviderHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_CertStorage(TElSAMLIdentityProviderHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_AccessLevel(TElSAMLIdentityProviderHandle _Handle, TSBSAMLAccessLevelRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_AccessLevel(TElSAMLIdentityProviderHandle _Handle, TSBSAMLAccessLevelRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SessionTTL(TElSAMLIdentityProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SessionTTL(TElSAMLIdentityProviderHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SAMLSessionTTL(TElSAMLIdentityProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SAMLSessionTTL(TElSAMLIdentityProviderHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_MaxIssueInstantTimeDiff(TElSAMLIdentityProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_MaxIssueInstantTimeDiff(TElSAMLIdentityProviderHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SessionManager(TElSAMLIdentityProviderHandle _Handle, TElCustomSessionManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SessionManager(TElSAMLIdentityProviderHandle _Handle, TElCustomSessionManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_AuthSource(TElSAMLIdentityProviderHandle _Handle, TElSAMLIDPCustomAuthSourceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_AuthSource(TElSAMLIdentityProviderHandle _Handle, TElSAMLIDPCustomAuthSourceHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_WantAuthnRequestsSigned(TElSAMLIdentityProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_WantAuthnRequestsSigned(TElSAMLIdentityProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SigningCertificate(TElSAMLIdentityProviderHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SigningCertificate(TElSAMLIdentityProviderHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_EncryptionCertificate(TElSAMLIdentityProviderHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_EncryptionCertificate(TElSAMLIdentityProviderHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_MetaSigningCertificate(TElSAMLIdentityProviderHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_MetaSigningCertificate(TElSAMLIdentityProviderHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_ConfirmationCertificate(TElSAMLIdentityProviderHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_ConfirmationCertificate(TElSAMLIdentityProviderHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SingleLogoutServiceBindings(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBindingTypesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SingleLogoutServiceBindings(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBindingTypesRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SingleSignOnServiceBindings(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBindingTypesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SingleSignOnServiceBindings(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBindingTypesRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_ArtifactResolutionServiceBindings(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBindingTypesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_MetadataURL(TElSAMLIdentityProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_MetadataURL(TElSAMLIdentityProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_AuthFormTemplate(TElSAMLIdentityProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_AuthFormTemplate(TElSAMLIdentityProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_LoginAttemptsLimit(TElSAMLIdentityProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_LoginAttemptsLimit(TElSAMLIdentityProviderHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_CurrentSP(TElSAMLIdentityProviderHandle _Handle, TElSAMLServiceProviderInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_AssertionsTTL(TElSAMLIdentityProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_AssertionsTTL(TElSAMLIdentityProviderHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_AssertionsOneTimeUse(TElSAMLIdentityProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_AssertionsOneTimeUse(TElSAMLIdentityProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SignResponse(TElSAMLIdentityProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SignResponse(TElSAMLIdentityProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SignAssertions(TElSAMLIdentityProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SignAssertions(TElSAMLIdentityProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_PreferredSingleSignOnResponseBinding(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBindingTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_PreferredSingleSignOnResponseBinding(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBindingTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_PreferredSingleLogoutResponseBinding(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBindingTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_PreferredSingleLogoutResponseBinding(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBindingTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_BlockedClientIP(TElSAMLIdentityProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_BlockedClientIP(TElSAMLIdentityProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_ArtifactStorage(TElSAMLIdentityProviderHandle _Handle, TElCustomArtifactStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_ArtifactStorage(TElSAMLIdentityProviderHandle _Handle, TElCustomArtifactStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SignMetadata(TElSAMLIdentityProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SignMetadata(TElSAMLIdentityProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_EncryptAssertions(TElSAMLIdentityProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_EncryptAssertions(TElSAMLIdentityProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_DefaultPassiveAuthnContextClassRef(TElSAMLIdentityProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_DefaultPassiveAuthnContextClassRef(TElSAMLIdentityProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_SubjectConfirmationMethod(TElSAMLIdentityProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_SubjectConfirmationMethod(TElSAMLIdentityProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_DefaultNameIDPolicyFormat(TElSAMLIdentityProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_DefaultNameIDPolicyFormat(TElSAMLIdentityProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_NotBeforeTimeout(TElSAMLIdentityProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_NotBeforeTimeout(TElSAMLIdentityProviderHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_AllowIDPSSO(TElSAMLIdentityProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_AllowIDPSSO(TElSAMLIdentityProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_IDPSSOPage(TElSAMLIdentityProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_IDPSSOPage(TElSAMLIdentityProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_CompatibilityOptions(TElSAMLIdentityProviderHandle _Handle, TSBSAMLIDPCompatibilityOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_CompatibilityOptions(TElSAMLIdentityProviderHandle _Handle, TSBSAMLIDPCompatibilityOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnSessionCreate(TElSAMLIdentityProviderHandle _Handle, SBSAMLIdentityProvider_TSBSAMLSessionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnSessionCreate(TElSAMLIdentityProviderHandle _Handle, SBSAMLIdentityProvider_TSBSAMLSessionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnSessionDestroy(TElSAMLIdentityProviderHandle _Handle, SBSAMLIdentityProvider_TSBSAMLSessionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnSessionDestroy(TElSAMLIdentityProviderHandle _Handle, SBSAMLIdentityProvider_TSBSAMLSessionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnSessionChanged(TElSAMLIdentityProviderHandle _Handle, SBSAMLIdentityProvider_TSBSAMLSessionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnSessionChanged(TElSAMLIdentityProviderHandle _Handle, SBSAMLIdentityProvider_TSBSAMLSessionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnLogout(TElSAMLIdentityProviderHandle _Handle, SBSAMLIdentityProvider_TSBSAMLLogoutEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnLogout(TElSAMLIdentityProviderHandle _Handle, SBSAMLIdentityProvider_TSBSAMLLogoutEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnBeforeHTTPSServerUse(TElSAMLIdentityProviderHandle _Handle, SBSAMLIdentityProvider_TSBSAMLBeforeHTTPSServerUseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnBeforeHTTPSServerUse(TElSAMLIdentityProviderHandle _Handle, SBSAMLIdentityProvider_TSBSAMLBeforeHTTPSServerUseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnRequestPrepared(TElSAMLIdentityProviderHandle _Handle, TSBSAMLRequestPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnRequestPrepared(TElSAMLIdentityProviderHandle _Handle, TSBSAMLRequestPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnResponseReceived(TElSAMLIdentityProviderHandle _Handle, TSBSAMLResponseReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnResponseReceived(TElSAMLIdentityProviderHandle _Handle, TSBSAMLResponseReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnResponsePrepared(TElSAMLIdentityProviderHandle _Handle, TSBSAMLResponsePreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnResponsePrepared(TElSAMLIdentityProviderHandle _Handle, TSBSAMLResponsePreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnMetadataPrepared(TElSAMLIdentityProviderHandle _Handle, TSBSAMLMetadataPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnMetadataPrepared(TElSAMLIdentityProviderHandle _Handle, TSBSAMLMetadataPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnChangeSessionStage(TElSAMLIdentityProviderHandle _Handle, TSBSAMLChangeIDPSessionStageEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnChangeSessionStage(TElSAMLIdentityProviderHandle _Handle, TSBSAMLChangeIDPSessionStageEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnSend(TElSAMLIdentityProviderHandle _Handle, TSBSendEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnSend(TElSAMLIdentityProviderHandle _Handle, TSBSendEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnReceive(TElSAMLIdentityProviderHandle _Handle, TSBReceiveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnReceive(TElSAMLIdentityProviderHandle _Handle, TSBReceiveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnOpenConnection(TElSAMLIdentityProviderHandle _Handle, TSBOpenConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnOpenConnection(TElSAMLIdentityProviderHandle _Handle, TSBOpenConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnSSLError(TElSAMLIdentityProviderHandle _Handle, TSBErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnSSLError(TElSAMLIdentityProviderHandle _Handle, TSBErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnCloseConnection(TElSAMLIdentityProviderHandle _Handle, TSBCloseConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnCloseConnection(TElSAMLIdentityProviderHandle _Handle, TSBCloseConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnCertificateValidate(TElSAMLIdentityProviderHandle _Handle, TSBCertificateValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnCertificateValidate(TElSAMLIdentityProviderHandle _Handle, TSBCertificateValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnChooseAuthnContext(TElSAMLIdentityProviderHandle _Handle, TSBSAMLChooseAuthnContext * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnChooseAuthnContext(TElSAMLIdentityProviderHandle _Handle, TSBSAMLChooseAuthnContext pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnBeforeHTTPSClientUse(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBeforeHTTPSClientUseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnBeforeHTTPSClientUse(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBeforeHTTPSClientUseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnBindingXMLPrepared(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBindingXMLPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnBindingXMLPrepared(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBindingXMLPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnBeforeBindingUse(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBeforeBindingUseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnBeforeBindingUse(TElSAMLIdentityProviderHandle _Handle, TSBSAMLBeforeBindingUseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnChooseNameIDPolicyFormat(TElSAMLIdentityProviderHandle _Handle, TSBSAMLChooseNameIDPolicyFormatEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnChooseNameIDPolicyFormat(TElSAMLIdentityProviderHandle _Handle, TSBSAMLChooseNameIDPolicyFormatEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnResponseStatusCode(TElSAMLIdentityProviderHandle _Handle, TSBSAMLResponseStatusCodeEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnResponseStatusCode(TElSAMLIdentityProviderHandle _Handle, TSBSAMLResponseStatusCodeEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_get_OnPageContent(TElSAMLIdentityProviderHandle _Handle, TSBSAMLPageContentEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_set_OnPageContent(TElSAMLIdentityProviderHandle _Handle, TSBSAMLPageContentEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIdentityProvider_Create(TComponentHandle AOwner, TElSAMLIdentityProviderHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLIDENTITYPROVIDER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSAMLIDPSession_ce_ptr;
extern zend_class_entry *TElSAMLServiceProviderInfo_ce_ptr;
extern zend_class_entry *TElSAMLSPData_ce_ptr;
extern zend_class_entry *TElSAMLIDPCustomAuthSource_ce_ptr;
extern zend_class_entry *TElSAMLIDRecord_ce_ptr;
extern zend_class_entry *TElSAMLIDPPasswordMemoryAuthSource_ce_ptr;
extern zend_class_entry *TElSAMLIdPSSOLink_ce_ptr;
extern zend_class_entry *TElSAMLIdentityProvider_ce_ptr;

void SB_CALLBACK SBSAMLIdentityProvider_TSBSAMLBeforeHTTPSServerUseEventRaw(void * _ObjectData, TObjectHandle Sender, TElHTTPSServerHandle HTTPSServer);
void SB_CALLBACK TSBSAMLPageContentEventRaw(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle Request, TElHTTPServerResponseParamsHandle Response, uint8_t pContent[], int32_t * szContent, int32_t * Size);
void SB_CALLBACK TSBSAMLChangeIDPSessionStageEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLIDPSessionHandle Session, TSBSAMLIDPStageRaw Stage);
void SB_CALLBACK SBSAMLIdentityProvider_TSBSAMLSessionEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLIDPSessionHandle Session);
void SB_CALLBACK SBSAMLIdentityProvider_TSBSAMLLogoutEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLIDPSessionHandle Session, TElHTTPServerResponseParamsHandle ResponseParams);
void SB_CALLBACK TSBSAMLChooseAuthnContextRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLAuthnRequestElementHandle Request, char * pcAuthnContextClassRef, int32_t * szAuthnContextClassRef);
void SB_CALLBACK TSBSAMLChooseNameIDPolicyFormatEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLIDPSessionHandle Session, char * pcNameIDPolicy, int32_t * szNameIDPolicy);
void SB_CALLBACK TSBSAMLIDPGetAttributeEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcID, int32_t szID, const char * pcFormat, int32_t szFormat, TElSAMLAttributeElementHandle Attribute, TElSAMLAttributeElementHandle Res);
void SB_CALLBACK TSBSAMLIDPSetAttributeEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcID, int32_t szID, const char * pcFormat, int32_t szFormat, TElSAMLAttributeElementHandle Attribute, int8_t * Res);
void Register_TElSAMLIDPSession(TSRMLS_D);
void Register_TElSAMLServiceProviderInfo(TSRMLS_D);
void Register_TElSAMLSPData(TSRMLS_D);
void Register_TElSAMLIDPCustomAuthSource(TSRMLS_D);
void Register_TElSAMLIDRecord(TSRMLS_D);
void Register_TElSAMLIDPPasswordMemoryAuthSource(TSRMLS_D);
void Register_TElSAMLIdPSSOLink(TSRMLS_D);
void Register_TElSAMLIdentityProvider(TSRMLS_D);
void Register_SBSAMLIdentityProvider_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSAMLIDENTITYPROVIDER */

