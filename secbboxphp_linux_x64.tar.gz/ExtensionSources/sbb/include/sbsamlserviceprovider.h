#ifndef __INC_SBSAMLSERVICEPROVIDER
#define __INC_SBSAMLSERVICEPROVIDER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstringlist.h"
#include "sbx509.h"
#include "sbcustomcertstorage.h"
#include "sbsslcommon.h"
#include "sbsslserver.h"
#include "sbsessionpool.h"
#include "sbhttpscommon.h"
#include "sbencoding.h"
#include "sbhttpsconstants.h"
#include "sbhttpsserver.h"
#include "sbsharedresource.h"
#include "sbhashfunction.h"
#include "sbsslconstants.h"
#include "sbcookiemgr.h"
#include "sbhttpsclient.h"
#include "sbxmlcore.h"
#include "sbxmlsec.h"
#include "sbxmlsig.h"
#include "sbxmlutils.h"
#include "sbxmlsamlcommon.h"
#include "sbxmlsamlprotocol.h"
#include "sbxmlsamlbind.h"
#include "sbxmlsamlcore.h"
#include "sbxmlsamlmetadata.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSAMLSPSessionHandle;

typedef TElClassHandle TElSAMLRequestResultHandle;

typedef TElClassHandle TElSAMLOneTimeUseRecordHandle;

typedef TElClassHandle TElSAMLCustomOneTimeUseCacheHandle;

typedef TElClassHandle TElSAMLMemoryOneTimeUseCacheHandle;

typedef TElClassHandle TElSAMLServiceProviderHandle;

typedef uint8_t TSBSAMLSPStageRaw;

typedef enum
{
	spsStart = 0,
	spsAuthnRequestSent = 1,
	spsResponseReceived = 2,
	spsResourceSupplied = 3,
	spsLogoutRequestSent = 4,
	spsLogoutResponseReceived = 5,
	spsLogoutRequestRecv = 6,
	spsLogoutResponseSent = 7,
	spsArtifactResolveRecv = 8,
	spsArtifactResponseSent = 9
} TSBSAMLSPStage;

typedef void (SB_CALLBACK *TSBSAMLChangeSPSessionStageEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLSPSessionHandle Session, TSBSAMLSPStageRaw Stage);

typedef void (SB_CALLBACK *SBSAMLServiceProvider_TSBSAMLSessionEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLSPSessionHandle Session);

typedef void (SB_CALLBACK *SBSAMLServiceProvider_TSBSAMLLogoutEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLSPSessionHandle Session, TElHTTPServerResponseParamsHandle ResponseParams);

typedef void (SB_CALLBACK *TSBSAMLChooseNameIDPolicyEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLSPSessionHandle Session, TElSAMLNameIDPolicyElementHandle NameIDPolicy);

#ifdef SB_USE_CLASS_TELSAMLSPSESSION
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_Generate(TElSAMLSPSessionHandle _Handle, int32_t TTL);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_get_Stage(TElSAMLSPSessionHandle _Handle, TSBSAMLSPStageRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_set_Stage(TElSAMLSPSessionHandle _Handle, TSBSAMLSPStageRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_get_SAMLSession(TElSAMLSPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_set_SAMLSession(TElSAMLSPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_get_AuthnRequestID(TElSAMLSPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_set_AuthnRequestID(TElSAMLSPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_get_LogoutRequestID(TElSAMLSPSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_set_LogoutRequestID(TElSAMLSPSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_get_SAMLCookieSet(TElSAMLSPSessionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_set_SAMLCookieSet(TElSAMLSPSessionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_get_NameID(TElSAMLSPSessionHandle _Handle, TElSAMLIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_set_NameID(TElSAMLSPSessionHandle _Handle, TElSAMLIDHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_get_SessionIndexes(TElSAMLSPSessionHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_get_Redirected(TElSAMLSPSessionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_set_Redirected(TElSAMLSPSessionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSPSession_Create(TElSAMLSPSessionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSPSESSION */

#ifdef SB_USE_CLASS_TELSAMLREQUESTRESULT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestResult_get_Doc(TElSAMLRequestResultHandle _Handle, TElXMLDOMDocumentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestResult_get_Response(TElSAMLRequestResultHandle _Handle, TElSAMLStatusResponseTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestResult_Create(TElXMLDOMDocumentHandle Doc, TElSAMLStatusResponseTypeHandle Response, TElSAMLRequestResultHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLREQUESTRESULT */

#ifdef SB_USE_CLASS_TELSAMLONETIMEUSERECORD
SB_IMPORT uint32_t SB_APIENTRY TElSAMLOneTimeUseRecord_get_ID(TElSAMLOneTimeUseRecordHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLOneTimeUseRecord_set_ID(TElSAMLOneTimeUseRecordHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLOneTimeUseRecord_get_IssueInstant(TElSAMLOneTimeUseRecordHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLOneTimeUseRecord_set_IssueInstant(TElSAMLOneTimeUseRecordHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLOneTimeUseRecord_Create(TElSAMLOneTimeUseRecordHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLONETIMEUSERECORD */

#ifdef SB_USE_CLASS_TELSAMLCUSTOMONETIMEUSECACHE
SB_IMPORT uint32_t SB_APIENTRY TElSAMLCustomOneTimeUseCache_Lock(TElSAMLCustomOneTimeUseCacheHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLCustomOneTimeUseCache_Unlock(TElSAMLCustomOneTimeUseCacheHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLCustomOneTimeUseCache_Clear(TElSAMLCustomOneTimeUseCacheHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLCustomOneTimeUseCache_Add(TElSAMLCustomOneTimeUseCacheHandle _Handle, TElSAMLAssertionElementHandle Assertion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLCustomOneTimeUseCache_Find(TElSAMLCustomOneTimeUseCacheHandle _Handle, TElSAMLAssertionElementHandle Assertion, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLCustomOneTimeUseCache_Create(TElSAMLCustomOneTimeUseCacheHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLCUSTOMONETIMEUSECACHE */

#ifdef SB_USE_CLASS_TELSAMLMEMORYONETIMEUSECACHE
SB_IMPORT uint32_t SB_APIENTRY TElSAMLMemoryOneTimeUseCache_Lock(TElSAMLMemoryOneTimeUseCacheHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLMemoryOneTimeUseCache_Unlock(TElSAMLMemoryOneTimeUseCacheHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLMemoryOneTimeUseCache_Clear(TElSAMLMemoryOneTimeUseCacheHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLMemoryOneTimeUseCache_Add(TElSAMLMemoryOneTimeUseCacheHandle _Handle, TElSAMLAssertionElementHandle Assertion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLMemoryOneTimeUseCache_Find(TElSAMLMemoryOneTimeUseCacheHandle _Handle, TElSAMLAssertionElementHandle Assertion, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLMemoryOneTimeUseCache_Create(TElSAMLMemoryOneTimeUseCacheHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLMEMORYONETIMEUSECACHE */

#ifdef SB_USE_CLASS_TELSAMLSERVICEPROVIDER
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_LoadMetadata(TElSAMLServiceProviderHandle _Handle, const char * pcURI, int32_t szURI);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_SaveMetadata(TElSAMLServiceProviderHandle _Handle, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_Open(TElSAMLServiceProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_DataAvailable(TElSAMLServiceProviderHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_Close(TElSAMLServiceProviderHandle _Handle, int8_t Silent);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_SendRequest(TElSAMLServiceProviderHandle _Handle, TElSAMLRequestAbstractTypeHandle Request, TElSAMLRequestResultHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_AddIDPSingleSignOnService(TElSAMLServiceProviderHandle _Handle, TElSAMLEndpointHandle Endpoint, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_AddIDPSingleLogoutService(TElSAMLServiceProviderHandle _Handle, TElSAMLEndpointHandle Endpoint, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_AddIDPArtifactResolutionService(TElSAMLServiceProviderHandle _Handle, TElSAMLEndpointHandle Endpoint, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_AddIDPAttributeQueryService(TElSAMLServiceProviderHandle _Handle, TElSAMLEndpointHandle Endpoint, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_RemoveIDPSingleSignOnService(TElSAMLServiceProviderHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_RemoveIDPSingleLogoutService(TElSAMLServiceProviderHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_RemoveIDPArtifactResolutionService(TElSAMLServiceProviderHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_RemoveIDPAttributeQueryService(TElSAMLServiceProviderHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_Control(TElSAMLServiceProviderHandle _Handle, TElHTTPSServerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_ProtectedResources(TElSAMLServiceProviderHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPSingleSignOnServices(TElSAMLServiceProviderHandle _Handle, int32_t Index, TElSAMLEndpointHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPSingleLogoutServices(TElSAMLServiceProviderHandle _Handle, int32_t Index, TElSAMLEndpointHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPArtifactResolutionServices(TElSAMLServiceProviderHandle _Handle, int32_t Index, TElSAMLEndpointHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPAttributeQueryServices(TElSAMLServiceProviderHandle _Handle, int32_t Index, TElSAMLEndpointHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPSingleSignOnServiceCount(TElSAMLServiceProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPSingleLogoutServiceCount(TElSAMLServiceProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPArtifactResolutionServiceCount(TElSAMLServiceProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPAttributeQueryServiceCount(TElSAMLServiceProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_SourceID(TElSAMLServiceProviderHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_SourceID(TElSAMLServiceProviderHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPSourceID(TElSAMLServiceProviderHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_IDPSourceID(TElSAMLServiceProviderHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_AutoIDPSourceID(TElSAMLServiceProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_AutoIDPSourceID(TElSAMLServiceProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_Active(TElSAMLServiceProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_CurrentSession(TElSAMLServiceProviderHandle _Handle, TElSAMLSPSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_SendBufferSize(TElSAMLServiceProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_SendBufferSize(TElSAMLServiceProviderHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_ServerName(TElSAMLServiceProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_ServerName(TElSAMLServiceProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_SessionManager(TElSAMLServiceProviderHandle _Handle, TElCustomSessionManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_SessionManager(TElSAMLServiceProviderHandle _Handle, TElCustomSessionManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_AssertionsOneTimeUseCache(TElSAMLServiceProviderHandle _Handle, TElSAMLCustomOneTimeUseCacheHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_AssertionsOneTimeUseCache(TElSAMLServiceProviderHandle _Handle, TElSAMLCustomOneTimeUseCacheHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_URL(TElSAMLServiceProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_URL(TElSAMLServiceProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_SPToIDPBinding(TElSAMLServiceProviderHandle _Handle, TSBSAMLBindingTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_SPToIDPBinding(TElSAMLServiceProviderHandle _Handle, TSBSAMLBindingTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_PreferredIDPToSPBinding(TElSAMLServiceProviderHandle _Handle, TSBSAMLBindingTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_PreferredIDPToSPBinding(TElSAMLServiceProviderHandle _Handle, TSBSAMLBindingTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_SingleLogoutServiceBindings(TElSAMLServiceProviderHandle _Handle, TSBSAMLBindingTypesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_SingleLogoutServiceBindings(TElSAMLServiceProviderHandle _Handle, TSBSAMLBindingTypesRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_AssertionConsumerServiceBindings(TElSAMLServiceProviderHandle _Handle, TSBSAMLBindingTypesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_AssertionConsumerServiceBindings(TElSAMLServiceProviderHandle _Handle, TSBSAMLBindingTypesRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_ArtifactResolutionServiceBindings(TElSAMLServiceProviderHandle _Handle, TSBSAMLBindingTypesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_MetadataURL(TElSAMLServiceProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_MetadataURL(TElSAMLServiceProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_AssertionConsumerService(TElSAMLServiceProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_AssertionConsumerService(TElSAMLServiceProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_SingleLogoutService(TElSAMLServiceProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_SingleLogoutService(TElSAMLServiceProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_ArtifactResolutionService(TElSAMLServiceProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_ArtifactResolutionService(TElSAMLServiceProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_LogoutPage(TElSAMLServiceProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_LogoutPage(TElSAMLServiceProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_Issuer(TElSAMLServiceProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_Issuer(TElSAMLServiceProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_SessionCookieName(TElSAMLServiceProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_SessionCookieName(TElSAMLServiceProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_SAMLSessionCookieName(TElSAMLServiceProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_SAMLSessionCookieName(TElSAMLServiceProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPSigningCertificate(TElSAMLServiceProviderHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_IDPSigningCertificate(TElSAMLServiceProviderHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPEncryptionCertificate(TElSAMLServiceProviderHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_IDPEncryptionCertificate(TElSAMLServiceProviderHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPMetaSigningCertificate(TElSAMLServiceProviderHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_IDPMetaSigningCertificate(TElSAMLServiceProviderHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPAllowCreateIdentifier(TElSAMLServiceProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_IDPAllowCreateIdentifier(TElSAMLServiceProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPNameIDFormats(TElSAMLServiceProviderHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPNameIDFormatIndex(TElSAMLServiceProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_IDPNameIDFormatIndex(TElSAMLServiceProviderHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPPreferredNameIDFormat(TElSAMLServiceProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_IDPPreferredNameIDFormat(TElSAMLServiceProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_AccessLevel(TElSAMLServiceProviderHandle _Handle, TSBSAMLAccessLevelRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_AccessLevel(TElSAMLServiceProviderHandle _Handle, TSBSAMLAccessLevelRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_SessionTTL(TElSAMLServiceProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_SessionTTL(TElSAMLServiceProviderHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_MaxIssueInstantTimeDiff(TElSAMLServiceProviderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_MaxIssueInstantTimeDiff(TElSAMLServiceProviderHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_SignAuthnRequests(TElSAMLServiceProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_SignAuthnRequests(TElSAMLServiceProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_SignLogoutRequests(TElSAMLServiceProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_SignLogoutRequests(TElSAMLServiceProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_SignArtifactResolveRequests(TElSAMLServiceProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_SignArtifactResolveRequests(TElSAMLServiceProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_CertStorage(TElSAMLServiceProviderHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_CertStorage(TElSAMLServiceProviderHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_SigningCertificate(TElSAMLServiceProviderHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_SigningCertificate(TElSAMLServiceProviderHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_EncryptionCertificate(TElSAMLServiceProviderHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_EncryptionCertificate(TElSAMLServiceProviderHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_MetaSigningCertificate(TElSAMLServiceProviderHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_MetaSigningCertificate(TElSAMLServiceProviderHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_RedirectOnLogoutPage(TElSAMLServiceProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_RedirectOnLogoutPage(TElSAMLServiceProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_ArtifactStorage(TElSAMLServiceProviderHandle _Handle, TElCustomArtifactStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_ArtifactStorage(TElSAMLServiceProviderHandle _Handle, TElCustomArtifactStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_RedirectToSuppliedResource(TElSAMLServiceProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_RedirectToSuppliedResource(TElSAMLServiceProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_SignMetadata(TElSAMLServiceProviderHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_SignMetadata(TElSAMLServiceProviderHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_IDPEntityID(TElSAMLServiceProviderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_IDPEntityID(TElSAMLServiceProviderHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnSessionCreate(TElSAMLServiceProviderHandle _Handle, SBSAMLServiceProvider_TSBSAMLSessionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnSessionCreate(TElSAMLServiceProviderHandle _Handle, SBSAMLServiceProvider_TSBSAMLSessionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnSessionDestroy(TElSAMLServiceProviderHandle _Handle, SBSAMLServiceProvider_TSBSAMLSessionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnSessionDestroy(TElSAMLServiceProviderHandle _Handle, SBSAMLServiceProvider_TSBSAMLSessionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnLogout(TElSAMLServiceProviderHandle _Handle, SBSAMLServiceProvider_TSBSAMLLogoutEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnLogout(TElSAMLServiceProviderHandle _Handle, SBSAMLServiceProvider_TSBSAMLLogoutEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnBeforeHTTPSServerUse(TElSAMLServiceProviderHandle _Handle, SBXMLSAMLCommon_TSBSAMLBeforeHTTPSServerUseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnBeforeHTTPSServerUse(TElSAMLServiceProviderHandle _Handle, SBXMLSAMLCommon_TSBSAMLBeforeHTTPSServerUseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnBeforeHTTPSClientUse(TElSAMLServiceProviderHandle _Handle, TSBSAMLBeforeHTTPSClientUseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnBeforeHTTPSClientUse(TElSAMLServiceProviderHandle _Handle, TSBSAMLBeforeHTTPSClientUseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnRequestPrepared(TElSAMLServiceProviderHandle _Handle, TSBSAMLRequestPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnRequestPrepared(TElSAMLServiceProviderHandle _Handle, TSBSAMLRequestPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnResponsePrepared(TElSAMLServiceProviderHandle _Handle, TSBSAMLResponsePreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnResponsePrepared(TElSAMLServiceProviderHandle _Handle, TSBSAMLResponsePreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnResponseReceived(TElSAMLServiceProviderHandle _Handle, TSBSAMLResponseReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnResponseReceived(TElSAMLServiceProviderHandle _Handle, TSBSAMLResponseReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnRequestReceived(TElSAMLServiceProviderHandle _Handle, TSBSAMLRequestReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnRequestReceived(TElSAMLServiceProviderHandle _Handle, TSBSAMLRequestReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnChangeSessionStage(TElSAMLServiceProviderHandle _Handle, TSBSAMLChangeSPSessionStageEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnChangeSessionStage(TElSAMLServiceProviderHandle _Handle, TSBSAMLChangeSPSessionStageEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnMetadataPrepared(TElSAMLServiceProviderHandle _Handle, TSBSAMLMetadataPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnMetadataPrepared(TElSAMLServiceProviderHandle _Handle, TSBSAMLMetadataPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnResourceOpen(TElSAMLServiceProviderHandle _Handle, TSBSAMLResourceOpenEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnResourceOpen(TElSAMLServiceProviderHandle _Handle, TSBSAMLResourceOpenEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnResourceRead(TElSAMLServiceProviderHandle _Handle, TSBSAMLResourceReadEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnResourceRead(TElSAMLServiceProviderHandle _Handle, TSBSAMLResourceReadEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnResourceClose(TElSAMLServiceProviderHandle _Handle, TSBSAMLResourceCloseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnResourceClose(TElSAMLServiceProviderHandle _Handle, TSBSAMLResourceCloseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnSend(TElSAMLServiceProviderHandle _Handle, TSBSendEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnSend(TElSAMLServiceProviderHandle _Handle, TSBSendEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnReceive(TElSAMLServiceProviderHandle _Handle, TSBReceiveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnReceive(TElSAMLServiceProviderHandle _Handle, TSBReceiveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnOpenConnection(TElSAMLServiceProviderHandle _Handle, TSBOpenConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnOpenConnection(TElSAMLServiceProviderHandle _Handle, TSBOpenConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnSSLError(TElSAMLServiceProviderHandle _Handle, TSBErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnSSLError(TElSAMLServiceProviderHandle _Handle, TSBErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnCloseConnection(TElSAMLServiceProviderHandle _Handle, TSBCloseConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnCloseConnection(TElSAMLServiceProviderHandle _Handle, TSBCloseConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnBindingXMLPrepared(TElSAMLServiceProviderHandle _Handle, TSBSAMLBindingXMLPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnBindingXMLPrepared(TElSAMLServiceProviderHandle _Handle, TSBSAMLBindingXMLPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnBeforeBindingUse(TElSAMLServiceProviderHandle _Handle, TSBSAMLBeforeBindingUseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnBeforeBindingUse(TElSAMLServiceProviderHandle _Handle, TSBSAMLBeforeBindingUseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnChooseMetadataIDPDescriptor(TElSAMLServiceProviderHandle _Handle, TSBSAMLChooseMetadataDescriptorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnChooseMetadataIDPDescriptor(TElSAMLServiceProviderHandle _Handle, TSBSAMLChooseMetadataDescriptorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnChooseNameIDPolicy(TElSAMLServiceProviderHandle _Handle, TSBSAMLChooseNameIDPolicyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnChooseNameIDPolicy(TElSAMLServiceProviderHandle _Handle, TSBSAMLChooseNameIDPolicyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnResponderError(TElSAMLServiceProviderHandle _Handle, TSBSAMLResponderErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnResponderError(TElSAMLServiceProviderHandle _Handle, TSBSAMLResponderErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_get_OnResponseStatusCode(TElSAMLServiceProviderHandle _Handle, TSBSAMLResponseStatusCodeEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_set_OnResponseStatusCode(TElSAMLServiceProviderHandle _Handle, TSBSAMLResponseStatusCodeEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLServiceProvider_Create(TComponentHandle AOwner, TElSAMLServiceProviderHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSERVICEPROVIDER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSAMLSPSession_ce_ptr;
extern zend_class_entry *TElSAMLRequestResult_ce_ptr;
extern zend_class_entry *TElSAMLOneTimeUseRecord_ce_ptr;
extern zend_class_entry *TElSAMLCustomOneTimeUseCache_ce_ptr;
extern zend_class_entry *TElSAMLMemoryOneTimeUseCache_ce_ptr;
extern zend_class_entry *TElSAMLServiceProvider_ce_ptr;

void SB_CALLBACK TSBSAMLChangeSPSessionStageEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLSPSessionHandle Session, TSBSAMLSPStageRaw Stage);
void SB_CALLBACK SBSAMLServiceProvider_TSBSAMLSessionEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLSPSessionHandle Session);
void SB_CALLBACK SBSAMLServiceProvider_TSBSAMLLogoutEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLSPSessionHandle Session, TElHTTPServerResponseParamsHandle ResponseParams);
void SB_CALLBACK TSBSAMLChooseNameIDPolicyEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLSPSessionHandle Session, TElSAMLNameIDPolicyElementHandle NameIDPolicy);
void Register_TElSAMLSPSession(TSRMLS_D);
void Register_TElSAMLRequestResult(TSRMLS_D);
void Register_TElSAMLOneTimeUseRecord(TSRMLS_D);
void Register_TElSAMLCustomOneTimeUseCache(TSRMLS_D);
void Register_TElSAMLMemoryOneTimeUseCache(TSRMLS_D);
void Register_TElSAMLServiceProvider(TSRMLS_D);
void Register_SBSAMLServiceProvider_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSAMLSERVICEPROVIDER */

