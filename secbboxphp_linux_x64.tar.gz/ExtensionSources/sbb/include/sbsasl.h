#ifndef __INC_SBSASL
#define __INC_SBSASL

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstringlist.h"
#ifdef SB_WINDOWS
#include "sbhttpauth.h"
#endif
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbrandom.h"
#include "sbhashfunction.h"
#include "sbconstants.h"
#include "sbhttpsconstants.h"
#include "sbencoding.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SASL_MECHANISM_PLAIN 	"PLAIN"
#define SB_SASL_MECHANISM_LOGIN 	"LOGIN"
#define SB_SASL_MECHANISM_CRAM_MD5 	"CRAM-MD5"
#define SB_SASL_MECHANISM_EXTERNAL 	"EXTERNAL"
#define SB_SASL_MECHANISM_ANONYMOUS 	"ANONYMOUS"
#define SB_SASL_MECHANISM_DIGEST_MD5 	"DIGEST-MD5"
#define SB_SASL_MECHANISM_NTLM 	"NTLM"
#define SB_SASL_MECHANISM_GSSAPI 	"GSSAPI"
#define SB_SASL_MECHANISM_XOAUTH2 	"XOAUTH2"
#define SB_SASL_ERROR_BASE 	47696
#define SB_SASL_CRAM_ERROR_EMPTY_CHALLENGE 	47697
#define SB_SASL_CRAM_ERROR_INVALID_CHALLENGE 	47698
#define SB_SASL_DIGEST_ERROR_INVALID_CHALLENGE 	47699
#define SB_SASL_DIGEST_ERROR_INVALID_REALM 	47700
#define SB_SASL_DIGEST_ERROR_PARAMETER_NOT_SPECIFIED 	47701
#define SB_SASL_XOAUTH2_ERROR_UNKNOWN_RESPONSE 	47702
#define SB_SASL_XOAUTH2_ERROR_AUTHENTICATION_FAILED 	47703

typedef TElClassHandle TElSASLClientHandle;

typedef TElClassHandle TElSASLPlainClientHandle;

typedef TElClassHandle TElSASLLoginClientHandle;

typedef TElClassHandle TElSASLCRAMMD5ClientHandle;

typedef TElClassHandle TElSASLAnonymousClientHandle;

typedef TElClassHandle TElSASLExternalClientHandle;

typedef TElClassHandle TElSASLDigestMD5ClientHandle;

#ifdef SB_WINDOWS
typedef TElClassHandle TElSASLNTLMClientHandle;
#endif

typedef TElClassHandle TElSASLXOAuth2ClientHandle;

typedef uint8_t TSBSASLSecurityLevelRaw;

typedef enum
{
	saslAuthOnly = 0,
	saslAuthIntegrity = 1,
	saslAuthConfidentiality = 2
} TSBSASLSecurityLevel;

typedef void (SB_CALLBACK *TSBSASLChallengeEvent)(void * _ObjectData, TElStringListHandle Options);

typedef void (SB_CALLBACK *TSBSASLGetValueEvent)(void * _ObjectData, const char * pcName, int32_t szName, char * pcValue, int32_t * szValue);

#ifdef SB_USE_CLASS_TELSASLCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_ProcessChallenge(TElSASLClientHandle _Handle, const uint8_t pChallenge[], int32_t szChallenge, uint8_t pResponse[], int32_t * szResponse);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_ValueExists(TElSASLClientHandle _Handle, const char * pcName, int32_t szName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_WrapData(TElSASLClientHandle _Handle, void * InData, int32_t InSize, void * OutData, int32_t * OutSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_WrapData_1(TElSASLClientHandle _Handle, const uint8_t pInData[], int32_t szInData, int32_t InStartIndex, int32_t InSize, uint8_t pOutData[], int32_t * szOutData, int32_t OutStartIndex, int32_t * OutSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_UnwrapData(TElSASLClientHandle _Handle, void * InData, int32_t InSize, void * OutData, int32_t * OutSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_UnwrapData_1(TElSASLClientHandle _Handle, const uint8_t pInData[], int32_t szInData, int32_t InStartIndex, int32_t InSize, uint8_t pOutData[], int32_t * szOutData, int32_t OutStartIndex, int32_t * OutSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_get_Complete(TElSASLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_get_MechanismName(TElSASLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_get_SecurityLevel(TElSASLClientHandle _Handle, TSBSASLSecurityLevelRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_get_Value(TElSASLClientHandle _Handle, const char * pcName, int32_t szName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_set_Value(TElSASLClientHandle _Handle, const char * pcName, int32_t szName, const char * pcNewValue, int32_t szNewValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_get_OnChallenge(TElSASLClientHandle _Handle, TSBSASLChallengeEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_set_OnChallenge(TElSASLClientHandle _Handle, TSBSASLChallengeEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_get_OnGetValue(TElSASLClientHandle _Handle, TSBSASLGetValueEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_set_OnGetValue(TElSASLClientHandle _Handle, TSBSASLGetValueEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLClient_Create(TElSASLClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSASLCLIENT */

#ifdef SB_USE_CLASS_TELSASLPLAINCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSASLPlainClient_ProcessChallenge(TElSASLPlainClientHandle _Handle, const uint8_t pChallenge[], int32_t szChallenge, uint8_t pResponse[], int32_t * szResponse);
SB_IMPORT uint32_t SB_APIENTRY TElSASLPlainClient_get_Password(TElSASLPlainClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLPlainClient_set_Password(TElSASLPlainClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLPlainClient_get_UserName(TElSASLPlainClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLPlainClient_set_UserName(TElSASLPlainClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLPlainClient_Create(TElSASLPlainClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSASLPLAINCLIENT */

#ifdef SB_USE_CLASS_TELSASLLOGINCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSASLLoginClient_ProcessChallenge(TElSASLLoginClientHandle _Handle, const uint8_t pChallenge[], int32_t szChallenge, uint8_t pResponse[], int32_t * szResponse);
SB_IMPORT uint32_t SB_APIENTRY TElSASLLoginClient_get_Password(TElSASLLoginClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLLoginClient_set_Password(TElSASLLoginClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLLoginClient_get_UserName(TElSASLLoginClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLLoginClient_set_UserName(TElSASLLoginClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLLoginClient_Create(TElSASLLoginClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSASLLOGINCLIENT */

#ifdef SB_USE_CLASS_TELSASLCRAMMD5CLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSASLCRAMMD5Client_ProcessChallenge(TElSASLCRAMMD5ClientHandle _Handle, const uint8_t pChallenge[], int32_t szChallenge, uint8_t pResponse[], int32_t * szResponse);
SB_IMPORT uint32_t SB_APIENTRY TElSASLCRAMMD5Client_get_Password(TElSASLCRAMMD5ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLCRAMMD5Client_set_Password(TElSASLCRAMMD5ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLCRAMMD5Client_get_UserName(TElSASLCRAMMD5ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLCRAMMD5Client_set_UserName(TElSASLCRAMMD5ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLCRAMMD5Client_Create(TElSASLCRAMMD5ClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSASLCRAMMD5CLIENT */

#ifdef SB_USE_CLASS_TELSASLANONYMOUSCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSASLAnonymousClient_ProcessChallenge(TElSASLAnonymousClientHandle _Handle, const uint8_t pChallenge[], int32_t szChallenge, uint8_t pResponse[], int32_t * szResponse);
SB_IMPORT uint32_t SB_APIENTRY TElSASLAnonymousClient_get_AuthID(TElSASLAnonymousClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLAnonymousClient_set_AuthID(TElSASLAnonymousClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLAnonymousClient_Create(TElSASLAnonymousClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSASLANONYMOUSCLIENT */

#ifdef SB_USE_CLASS_TELSASLEXTERNALCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSASLExternalClient_ProcessChallenge(TElSASLExternalClientHandle _Handle, const uint8_t pChallenge[], int32_t szChallenge, uint8_t pResponse[], int32_t * szResponse);
SB_IMPORT uint32_t SB_APIENTRY TElSASLExternalClient_get_AuthID(TElSASLExternalClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLExternalClient_set_AuthID(TElSASLExternalClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLExternalClient_Create(TElSASLExternalClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSASLEXTERNALCLIENT */

#ifdef SB_USE_CLASS_TELSASLDIGESTMD5CLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSASLDigestMD5Client_ProcessChallenge(TElSASLDigestMD5ClientHandle _Handle, const uint8_t pChallenge[], int32_t szChallenge, uint8_t pResponse[], int32_t * szResponse);
SB_IMPORT uint32_t SB_APIENTRY TElSASLDigestMD5Client_get_Password(TElSASLDigestMD5ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLDigestMD5Client_set_Password(TElSASLDigestMD5ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLDigestMD5Client_get_UserName(TElSASLDigestMD5ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLDigestMD5Client_set_UserName(TElSASLDigestMD5ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLDigestMD5Client_get_RequestURI(TElSASLDigestMD5ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLDigestMD5Client_set_RequestURI(TElSASLDigestMD5ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLDigestMD5Client_get_RequestMethod(TElSASLDigestMD5ClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLDigestMD5Client_set_RequestMethod(TElSASLDigestMD5ClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSASLDigestMD5Client_get_CustomRequestMethod(TElSASLDigestMD5ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLDigestMD5Client_set_CustomRequestMethod(TElSASLDigestMD5ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLDigestMD5Client_get_HTTPAuth(TElSASLDigestMD5ClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLDigestMD5Client_set_HTTPAuth(TElSASLDigestMD5ClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSASLDigestMD5Client_Create(TElSASLDigestMD5ClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSASLDIGESTMD5CLIENT */

#ifdef SB_WINDOWS
#ifdef SB_USE_CLASS_TELSASLNTLMCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSASLNTLMClient_ProcessChallenge(TElSASLNTLMClientHandle _Handle, const uint8_t pChallenge[], int32_t szChallenge, uint8_t pResponse[], int32_t * szResponse);
SB_IMPORT uint32_t SB_APIENTRY TElSASLNTLMClient_get_Password(TElSASLNTLMClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLNTLMClient_set_Password(TElSASLNTLMClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLNTLMClient_get_UserName(TElSASLNTLMClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLNTLMClient_set_UserName(TElSASLNTLMClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLNTLMClient_get_UsernameOption(TElSASLNTLMClientHandle _Handle, TSBUsernameOptionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLNTLMClient_set_UsernameOption(TElSASLNTLMClientHandle _Handle, TSBUsernameOptionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSASLNTLMClient_Create(TElSASLNTLMClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSASLNTLMCLIENT */
#endif

#ifdef SB_USE_CLASS_TELSASLXOAUTH2CLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSASLXOAuth2Client_ProcessChallenge(TElSASLXOAuth2ClientHandle _Handle, const uint8_t pChallenge[], int32_t szChallenge, uint8_t pResponse[], int32_t * szResponse);
SB_IMPORT uint32_t SB_APIENTRY TElSASLXOAuth2Client_get_AccessToken(TElSASLXOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLXOAuth2Client_set_AccessToken(TElSASLXOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLXOAuth2Client_get_UserName(TElSASLXOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSASLXOAuth2Client_set_UserName(TElSASLXOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSASLXOAuth2Client_Create(TElSASLXOAuth2ClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSASLXOAUTH2CLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSASLClient_ce_ptr;
extern zend_class_entry *TElSASLPlainClient_ce_ptr;
extern zend_class_entry *TElSASLLoginClient_ce_ptr;
extern zend_class_entry *TElSASLCRAMMD5Client_ce_ptr;
extern zend_class_entry *TElSASLAnonymousClient_ce_ptr;
extern zend_class_entry *TElSASLExternalClient_ce_ptr;
extern zend_class_entry *TElSASLDigestMD5Client_ce_ptr;
#ifdef SB_WINDOWS
extern zend_class_entry *TElSASLNTLMClient_ce_ptr;
#endif
extern zend_class_entry *TElSASLXOAuth2Client_ce_ptr;

void SB_CALLBACK TSBSASLChallengeEventRaw(void * _ObjectData, TElStringListHandle Options);
void SB_CALLBACK TSBSASLGetValueEventRaw(void * _ObjectData, const char * pcName, int32_t szName, char * pcValue, int32_t * szValue);
void Register_TElSASLClient(TSRMLS_D);
void Register_TElSASLPlainClient(TSRMLS_D);
void Register_TElSASLLoginClient(TSRMLS_D);
void Register_TElSASLCRAMMD5Client(TSRMLS_D);
void Register_TElSASLAnonymousClient(TSRMLS_D);
void Register_TElSASLExternalClient(TSRMLS_D);
void Register_TElSASLDigestMD5Client(TSRMLS_D);
#ifdef SB_WINDOWS
void Register_TElSASLNTLMClient(TSRMLS_D);
#endif
void Register_TElSASLXOAuth2Client(TSRMLS_D);
SB_PHP_FUNCTION(SBSASL, CreateSASLClient);
void Register_SBSASL_Constants(int module_number TSRMLS_DC);
void Register_SBSASL_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_SASL
SB_IMPORT uint32_t SB_APIENTRY SBSASL_CreateSASLClient(const char * pcMechanism, int32_t szMechanism, TElSASLClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSASL_CreateSASLClient_1(const TStringListHandle Mechanisms, TElSASLClientHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_SASL */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSASL */
