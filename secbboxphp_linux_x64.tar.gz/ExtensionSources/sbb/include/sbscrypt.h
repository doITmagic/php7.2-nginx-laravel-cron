#ifndef __INC_SBSCRYPT
#define __INC_SBSCRYPT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbpkcs5.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef uint32_t TSBSCryptArray[16];

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TSBSCryptArray_ce_ptr;

void Register_TSBSCryptArray(TSRMLS_D);
SB_PHP_FUNCTION(SBScrypt, scrypt);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_SCRYPT
SB_IMPORT uint32_t SB_APIENTRY SBScrypt_scrypt(const char * pcPassword, int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, uint64_t N, uint64_t r, uint64_t p, uint32_t DKLen, uint8_t pOutResult[], int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_SCRYPT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSCRYPT */

