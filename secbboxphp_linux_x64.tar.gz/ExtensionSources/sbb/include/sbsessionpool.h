#ifndef __INC_SBSESSIONPOOL
#define __INC_SBSESSIONPOOL

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbsharedresource.h"
#include "sbtimer.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSessionPoolHandle;

typedef TElSessionPoolHandle ElSessionPoolHandle;

#pragma pack(8)
typedef struct 
{
	void * SessionID;
	void * MasterKey;
	int32_t Version;
	uint32_t StartTime;
	int8_t AuthDone;
	int8_t _dummy0;
	int16_t _dummy1;
#ifdef CPU64
	int32_t _dummy2;
#endif
	TObjectHandle SessionInfo;
	int8_t FreeOnRelease;
} TSBSessionContext, * PSBSessionContext;

typedef void (SB_CALLBACK *TSBSessionCreatedEvent)(void * _ObjectData, TObjectHandle Sender, TObjectHandle Server, const uint8_t pSessionID[], int32_t szSessionID, TObjectHandle * SessionInfo, int8_t * FreeOnRelease);

typedef void (SB_CALLBACK *TSBSessionReleasedEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pSessionID[], int32_t szSessionID, TObjectHandle SessionInfo);

#ifdef SB_USE_CLASS_TELSESSIONPOOL
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_Add(TElSessionPoolHandle _Handle, TObjectHandle Server, int32_t Version, const uint8_t pMasterKey[], int32_t szMasterKey, const uint8_t pSessionID[], int32_t szSessionID, int8_t AuthDone, TObjectHandle SessInfo, int8_t FreeOnRelease);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_Remove(TElSessionPoolHandle _Handle, const uint8_t pSessionID[], int32_t szSessionID);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_GetContext(TElSessionPoolHandle _Handle, const uint8_t pSessionID[], int32_t szSessionID, PSBSessionContext * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_get_Timeout(TElSessionPoolHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_set_Timeout(TElSessionPoolHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_get_Interval(TElSessionPoolHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_set_Interval(TElSessionPoolHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_get_MaxCount(TElSessionPoolHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_set_MaxCount(TElSessionPoolHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_get_StatelessSymmetricKey(TElSessionPoolHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_get_StatelessHMACKey(TElSessionPoolHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_get_OnSessionCreated(TElSessionPoolHandle _Handle, TSBSessionCreatedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_set_OnSessionCreated(TElSessionPoolHandle _Handle, TSBSessionCreatedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_get_OnSessionReleased(TElSessionPoolHandle _Handle, TSBSessionReleasedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_set_OnSessionReleased(TElSessionPoolHandle _Handle, TSBSessionReleasedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSessionPool_Create(TComponentHandle Owner, TElSessionPoolHandle * OutResult);
#endif /* SB_USE_CLASS_TELSESSIONPOOL */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TSBSessionContext_ce_ptr;
extern zend_class_entry *TElSessionPool_ce_ptr;

void Register_TSBSessionContext(TSRMLS_D);
void SB_CALLBACK TSBSessionCreatedEventRaw(void * _ObjectData, TObjectHandle Sender, TObjectHandle Server, const uint8_t pSessionID[], int32_t szSessionID, TObjectHandle * SessionInfo, int8_t * FreeOnRelease);
void SB_CALLBACK TSBSessionReleasedEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pSessionID[], int32_t szSessionID, TObjectHandle SessionInfo);
void Register_TElSessionPool(TSRMLS_D);
SB_PHP_FUNCTION(SBSessionPool, FreeSessionContext);
void Register_SBSessionPool_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_SESSIONPOOL
SB_IMPORT uint32_t SB_APIENTRY SBSessionPool_FreeSessionContext(PSBSessionContext Ctx);
#endif /* SB_USE_GLOBAL_PROCS_SESSIONPOOL */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSESSIONPOOL */
