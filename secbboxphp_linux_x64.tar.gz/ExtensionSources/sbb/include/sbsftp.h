#ifndef __INC_SBSFTP
#define __INC_SBSFTP

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbsshclient.h"
#include "sbsshcommon.h"
#include "sbsshconstants.h"
#include "sbstreams.h"
#include "sbtypes.h"
#include "sbconstants.h"
#include "sbstrutils.h"
#include "sbsharedresource.h"
#include "sbchsconv.h"
#include "sbchsconvcharsets.h"
#include "sbchscjk.h"
#include "sbsftpcommon.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SResizeNotSupported 	"New file size must be greater or equal than its current size"
#define SB_SFTP_OPTIMAL_UPLOAD_BLOCK_SIZE 	32512
#define SB_SFTP_OPTIMAL_DOWNLOAD_BLOCK_SIZE 	2096896

typedef TElClassHandle TElSftpStreamHandle;

typedef TElSftpStreamHandle ElSftpStreamHandle;

typedef TElClassHandle TElSftpClientHandle;

typedef TElSftpClientHandle ElSftpClientHandle;

#ifdef SB_USE_CLASS_TELSFTPSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElSftpStream_Read(TElSftpStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStream_Write(TElSftpStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStream_Seek(TElSftpStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStream_Seek_1(TStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStream_get_Handle(TElSftpStreamHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStream_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPSTREAM */

#ifdef SB_USE_CLASS_TELSFTPCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_Read(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_Read_1(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_ReadSync(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_ReadSync_1(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_OpenStream(TElSftpClientHandle _Handle, const char * pcFilename, int32_t szFilename, TSBSftpFileOpenModesRaw Modes, TElSftpStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_Open(TElSftpClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_OpenSync(TElSftpClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_CreateFile(TElSftpClientHandle _Handle, const char * pcFilename, int32_t szFilename, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_CreateFileSync(TElSftpClientHandle _Handle, const char * pcFilename, int32_t szFilename, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_OpenFile(TElSftpClientHandle _Handle, const char * pcFilename, int32_t szFilename, TSBSftpFileOpenModesRaw Modes, TElSftpFileAttributesHandle Attributes, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_OpenFile_1(TElSftpClientHandle _Handle, const char * pcFilename, int32_t szFilename, TSBSftpFileOpenModesRaw Modes, TSBSftpFileOpenAccessRaw Access, TElSftpFileAttributesHandle Attributes, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_OpenFileSync(TElSftpClientHandle _Handle, const char * pcFilename, int32_t szFilename, TSBSftpFileOpenModesRaw Modes, TElSftpFileAttributesHandle Attributes, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_OpenFileSync_1(TElSftpClientHandle _Handle, const char * pcFilename, int32_t szFilename, TSBSftpFileOpenModesRaw Modes, TSBSftpFileOpenAccessRaw Access, TElSftpFileAttributesHandle Attributes, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_OpenDirectory(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_OpenDirectorySync(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_ReadDirectory(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_ReadDirectorySync(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RemoveFile(TElSftpClientHandle _Handle, const char * pcFilename, int32_t szFilename, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RemoveFileSync(TElSftpClientHandle _Handle, const char * pcFilename, int32_t szFilename);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RemoveFiles(TElSftpClientHandle _Handle, TStringsHandle Filenames, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RemoveFilesSync(TElSftpClientHandle _Handle, TStringsHandle Filenames);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RenameFile(TElSftpClientHandle _Handle, const char * pcOldPath, int32_t szOldPath, const char * pcNewPath, int32_t szNewPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RenameFileSync(TElSftpClientHandle _Handle, const char * pcOldPath, int32_t szOldPath, const char * pcNewPath, int32_t szNewPath);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_MakeDirectory(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, TElSftpFileAttributesHandle Attributes, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_MakeDirectorySync(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, TElSftpFileAttributesHandle Attributes);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RemoveDirectory(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RemoveDirectorySync(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestAttributes(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, int8_t FollowSymLinks, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestAttributes_1(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestAttributesSync(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, int8_t FollowSymLinks);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestAttributesSync_1(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_SetAttributes(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, TElSftpFileAttributesHandle Attributes, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_SetAttributesSync(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, TElSftpFileAttributesHandle Attributes);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_SetAttributesByHandle(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, TElSftpFileAttributesHandle Attributes, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_SetAttributesByHandleSync(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, TElSftpFileAttributesHandle Attributes);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_ReadSymLink(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_ReadSymLinkSync(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_CreateSymLink(TElSftpClientHandle _Handle, const char * pcLinkPath, int32_t szLinkPath, const char * pcTargetPath, int32_t szTargetPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_CreateSymLinkSync(TElSftpClientHandle _Handle, const char * pcLinkPath, int32_t szLinkPath, const char * pcTargetPath, int32_t szTargetPath);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_CreateHardLink(TElSftpClientHandle _Handle, const char * pcLinkPath, int32_t szLinkPath, const char * pcTargetPath, int32_t szTargetPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_CreateHardLinkSync(TElSftpClientHandle _Handle, const char * pcLinkPath, int32_t szLinkPath, const char * pcTargetPath, int32_t szTargetPath);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestAbsolutePath(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestAbsolutePathSync(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestAbsolutePathEx(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, TSBSftpRealpathControlRaw Control, TStringListHandle ComposePath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestAbsolutePathExSync(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, TSBSftpRealpathControlRaw Control, TStringListHandle ComposePath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_Block(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, int64_t Length, TSBSftpFileOpenAccessRaw LockMask, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_BlockSync(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, int64_t Length, TSBSftpFileOpenAccessRaw LockMask);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_Unblock(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, int64_t Length, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_UnblockSync(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, int64_t Length);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_CloseHandle(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_CloseHandleSync(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_Write(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, void * Buffer, uint32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_WriteSync(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, void * Buffer, uint32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_FinalizeTextWrite(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_FinalizeTextWriteSync(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_ExtensionCmd(TElSftpClientHandle _Handle, const char * pcExtension, int32_t szExtension, void * DataBuffer, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_ExtensionCmd_1(TElSftpClientHandle _Handle, const char * pcExtension, int32_t szExtension, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_ExtensionCmd_2(TElSftpClientHandle _Handle, const char * pcExtension, int32_t szExtension, const uint8_t pDataBuffer[], int32_t szDataBuffer, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_ExtensionCmd_3(TElSftpClientHandle _Handle, const uint8_t pExtension[], int32_t szExtension, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_ExtensionCmd_4(TElSftpClientHandle _Handle, const uint8_t pExtension[], int32_t szExtension, void * DataBuffer, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_ExtensionCmd_5(TElSftpClientHandle _Handle, const uint8_t pExtension[], int32_t szExtension, const uint8_t pDataBuffer[], int32_t szDataBuffer, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_ExtensionCmdSync(TElSftpClientHandle _Handle, const char * pcExtension, int32_t szExtension, void * DataBuffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_ExtensionCmdSync_1(TElSftpClientHandle _Handle, const char * pcExtension, int32_t szExtension);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_TextSeek(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t LineNumber, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_TextSeekSync(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t LineNumber);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_SendVendorID(TElSftpClientHandle _Handle, TElSftpVendorIDExtensionHandle VendorID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_SendVendorIDSync(TElSftpClientHandle _Handle, TElSftpVendorIDExtensionHandle VendorID);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestFileHash(TElSftpClientHandle _Handle, const char * pcFileName, int32_t szFileName, int64_t StartOffset, int64_t Length, uint32_t BlockSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestFileHash_1(TElSftpClientHandle _Handle, const char * pcFileName, int32_t szFileName, int64_t StartOffset, int64_t Length, uint32_t BlockSize, const char * pcHashAlgorithms, int32_t szHashAlgorithms, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestFileHashSync(TElSftpClientHandle _Handle, const char * pcFileName, int32_t szFileName, int64_t StartOffset, int64_t Length, uint32_t BlockSize);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestFileHashSync_1(TElSftpClientHandle _Handle, const char * pcFileName, int32_t szFileName, int64_t StartOffset, int64_t Length, uint32_t BlockSize, const char * pcHashAlgorithms, int32_t szHashAlgorithms);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestFileHashByHandle(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t StartOffset, int64_t Length, uint32_t BlockSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestFileHashByHandle_1(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t StartOffset, int64_t Length, uint32_t BlockSize, const char * pcHashAlgorithms, int32_t szHashAlgorithms, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestFileHashByHandleSync(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t StartOffset, int64_t Length, uint32_t BlockSize);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestFileHashByHandleSync_1(TElSftpClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t StartOffset, int64_t Length, uint32_t BlockSize, const char * pcHashAlgorithms, int32_t szHashAlgorithms);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_QueryAvailableSpace(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_QueryAvailableSpaceSync(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_QueryHomeDirectory(TElSftpClientHandle _Handle, const char * pcUsername, int32_t szUsername, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_QueryHomeDirectorySync(TElSftpClientHandle _Handle, const char * pcUsername, int32_t szUsername);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_QueryStatVFS(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_QueryStatVFSSync(TElSftpClientHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_CopyRemoteFile(TElSftpClientHandle _Handle, const char * pcSource, int32_t szSource, const char * pcDestination, int32_t szDestination, int8_t Overwrite, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_CopyRemoteFileSync(TElSftpClientHandle _Handle, const char * pcSource, int32_t szSource, const char * pcDestination, int32_t szDestination, int8_t Overwrite);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_CopyRemoteData(TElSftpClientHandle _Handle, const uint8_t pReadFrom[], int32_t szReadFrom, int64_t ReadFromOffset, const uint8_t pWriteTo[], int32_t szWriteTo, int64_t WriteToOffset, int64_t DataLength, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_CopyRemoteDataSync(TElSftpClientHandle _Handle, const uint8_t pReadFrom[], int32_t szReadFrom, int64_t ReadFromOffset, const uint8_t pWriteTo[], int32_t szWriteTo, int64_t WriteToOffset, int64_t DataLength);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestTempFolder(TElSftpClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_RequestTempFolderSync(TElSftpClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_MakeTempFolder(TElSftpClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_MakeTempFolderSync(TElSftpClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_Active(TElSftpClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_Version(TElSftpClientHandle _Handle, TSBSftpVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_SFTPExtCount(TElSftpClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_SFTPExt(TElSftpClientHandle _Handle, int32_t Index, TSBSftpExtendedAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_NewLineConvention(TElSftpClientHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_NewLineConvention(TElSftpClientHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_LocalNewLineConvention(TElSftpClientHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_LocalNewLineConvention(TElSftpClientHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_LastSyncComment(TElSftpClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_LastSyncError(TElSftpClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_LastReadCount(TElSftpClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_SBB3Compatible(TElSftpClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_SBB3Compatible(TElSftpClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_SynchronousMode(TElSftpClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_SynchronousMode(TElSftpClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_Tunnel(TElSftpClientHandle _Handle, TElCustomSSHTunnelHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_Tunnel(TElSftpClientHandle _Handle, TElCustomSSHTunnelHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_SftpBufferSize(TElSftpClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_SftpBufferSize(TElSftpClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_UseUTF8(TElSftpClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_UseUTF8(TElSftpClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_UseUTF8OnV3(TElSftpClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_UseUTF8OnV3(TElSftpClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_RemoteCharset(TElSftpClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_RemoteCharset(TElSftpClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_NoCharacterEncoding(TElSftpClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_NoCharacterEncoding(TElSftpClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_LocalCharset(TElSftpClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_LocalCharset(TElSftpClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_Versions(TElSftpClientHandle _Handle, TSBSftpVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_Versions(TElSftpClientHandle _Handle, TSBSftpVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_ExtendedProperties(TElSftpClientHandle _Handle, TElSftpExtendedPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_ExtendedProperties(TElSftpClientHandle _Handle, TElSftpExtendedPropertiesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_UploadBlockSize(TElSftpClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_UploadBlockSize(TElSftpClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_DownloadBlockSize(TElSftpClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_DownloadBlockSize(TElSftpClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_PipelineLength(TElSftpClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_PipelineLength(TElSftpClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_AutoAdjustTransferBlock(TElSftpClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_AutoAdjustTransferBlock(TElSftpClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OperationErrorHandling(TElSftpClientHandle _Handle, TSBOperationErrorHandlingRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OperationErrorHandling(TElSftpClientHandle _Handle, TSBOperationErrorHandlingRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_MessageLoop(TElSftpClientHandle _Handle, TSBSftpMessageLoopEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_MessageLoop(TElSftpClientHandle _Handle, TSBSftpMessageLoopEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnOpenConnection(TElSftpClientHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnOpenConnection(TElSftpClientHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnCloseConnection(TElSftpClientHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnCloseConnection(TElSftpClientHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnOpenFile(TElSftpClientHandle _Handle, TSBSftpFileOpenEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnOpenFile(TElSftpClientHandle _Handle, TSBSftpFileOpenEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnError(TElSftpClientHandle _Handle, TSBSftpErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnError(TElSftpClientHandle _Handle, TSBSftpErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnSuccess(TElSftpClientHandle _Handle, TSBSftpSuccessEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnSuccess(TElSftpClientHandle _Handle, TSBSftpSuccessEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnDirectoryListing(TElSftpClientHandle _Handle, TSBSftpDirectoryListingEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnDirectoryListing(TElSftpClientHandle _Handle, TSBSftpDirectoryListingEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnFileAttributes(TElSftpClientHandle _Handle, TSBSftpFileAttributesEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnFileAttributes(TElSftpClientHandle _Handle, TSBSftpFileAttributesEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnData(TElSftpClientHandle _Handle, TSBSftpDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnData(TElSftpClientHandle _Handle, TSBSftpDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnAbsolutePath(TElSftpClientHandle _Handle, TSBSftpAbsolutePathEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnAbsolutePath(TElSftpClientHandle _Handle, TSBSftpAbsolutePathEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnBlockTransferPrepared(TElSftpClientHandle _Handle, TSBSftpBlockTransferPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnBlockTransferPrepared(TElSftpClientHandle _Handle, TSBSftpBlockTransferPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnExtendedReply(TElSftpClientHandle _Handle, TSBSftpDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnExtendedReply(TElSftpClientHandle _Handle, TSBSftpDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnVersionSelect(TElSftpClientHandle _Handle, TSBSftpVersionSelectEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnVersionSelect(TElSftpClientHandle _Handle, TSBSftpVersionSelectEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnFileHash(TElSftpClientHandle _Handle, TSBSftpFileHashEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnFileHash(TElSftpClientHandle _Handle, TSBSftpFileHashEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnAvailableSpace(TElSftpClientHandle _Handle, TSBSftpAvailableSpaceEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnAvailableSpace(TElSftpClientHandle _Handle, TSBSftpAvailableSpaceEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnName(TElSftpClientHandle _Handle, TSBSftpNameEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnName(TElSftpClientHandle _Handle, TSBSftpNameEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnTransferCompleted(TElSftpClientHandle _Handle, TSBSftpTransferCompletedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnTransferCompleted(TElSftpClientHandle _Handle, TSBSftpTransferCompletedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnProgress(TElSftpClientHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnProgress(TElSftpClientHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_get_OnStatVFS(TElSftpClientHandle _Handle, TSBSftpStatvfsEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_set_OnStatVFS(TElSftpClientHandle _Handle, TSBSftpStatvfsEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpClient_Create(TComponentHandle AOwner, TElSftpClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSftpStream_ce_ptr;
extern zend_class_entry *TElSftpClient_ce_ptr;

void Register_TElSftpStream(TSRMLS_D);
void Register_TElSftpClient(TSRMLS_D);
void Register_SBSftp_Constants(int module_number TSRMLS_DC);
void Register_SBSftp_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSFTP */

