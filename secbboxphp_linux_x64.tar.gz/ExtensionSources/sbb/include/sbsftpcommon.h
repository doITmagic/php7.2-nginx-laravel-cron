#ifndef __INC_SBSFTPCOMMON
#define __INC_SBSFTPCOMMON

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbconstants.h"
#include "sbstrutils.h"
#include "sbsshconstants.h"
#include "sbsshcommon.h"
#include "sbchsconv.h"
#include "sbchsconvcharsets.h"
#include "sbchscjk.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_SFTP 	118784
#define SB_ERROR_SFTP_PROTOCOL_ERROR_FLAG 	1024
#define SB_ERROR_SFTP_CUSTOM_ERROR_FLAG 	2048
#define SB_SSH_ERROR_OK 	0
#define SB_SSH_ERROR_BASE 	0
#define SB_SSH_ERROR_WRONG_MODE 	-1
#define SB_SSH_ERROR_EOF 	1
#define SB_SSH_ERROR_NO_SUCH_FILE 	2
#define SB_SSH_ERROR_PERMISSION_DENIED 	3
#define SB_SSH_ERROR_FAILURE 	4
#define SB_SSH_ERROR_BAD_MESSAGE 	5
#define SB_SSH_ERROR_NO_CONNECTION 	6
#define SB_SSH_ERROR_CONNECTION_LOST 	7
#define SB_SSH_ERROR_OP_UNSUPPORTED 	8
#define SB_SSH_ERROR_INVALID_HANDLE 	9
#define SB_SSH_ERROR_NO_SUCH_PATH 	10
#define SB_SSH_ERROR_FILE_ALREADY_EXISTS 	11
#define SB_SSH_ERROR_WRITE_PROTECT 	12
#define SB_SSH_ERROR_NO_MEDIA 	13
#define SB_SSH_ERROR_NO_SPACE_ON_FILESYSTEM 	14
#define SB_SSH_ERROR_QUOTA_EXCEEDED 	15
#define SB_SSH_ERROR_UNKNOWN_PRINCIPAL 	16
#define SB_SSH_ERROR_LOCK_CONFLICT 	17
#define SB_SSH_ERROR_DIR_NOT_EMPTY 	18
#define SB_SSH_ERROR_NOT_A_DIRECTORY 	19
#define SB_SSH_ERROR_INVALID_FILENAME 	20
#define SB_SSH_ERROR_LINK_LOOP 	21
#define SB_SSH_ERROR_CANNOT_DELETE 	22
#define SB_SSH_ERROR_INVALID_PARAMETER 	23
#define SB_SSH_ERROR_FILE_IS_A_DIRECTORY 	24
#define SB_SSH_ERROR_BYTE_RANGE_LOCK_CONFLICT 	25
#define SB_SSH_ERROR_BYTE_RANGE_LOCK_REFUSED 	26
#define SB_SSH_ERROR_DELETE_PENDING 	27
#define SB_SSH_ERROR_FILE_CORRUPT 	28
#define SB_SSH_ERROR_OWNER_INVALID 	29
#define SB_SSH_ERROR_GROUP_INVALID 	30
#define SB_SSH_ERROR_UNSUPPORTED_VERSION 	100
#define SB_SSH_ERROR_INVALID_PACKET 	101
#define SB_SSH_ERROR_TUNNEL_ERROR 	102
#define SB_SSH_ERROR_CONNECTION_CLOSED 	103
#define SB_SSH_ERROR_UNSUPPORTED_ACTION 	104
#define SB_SSH_ERROR_NOT_A_TEXT_HANDLE 	105
#define SB_SSH_ERROR_CANCELLED_BY_USER 	106
#define SB_SFTP_ERROR_CUSTOM_BASE 	120832
#define SB_SFTP_ERROR_OFFSET_TOO_LARGE 	120833
#define SB_SFTP_ERROR_TIMES_NOT_SET 	120834
#define SB_SFTP_ERROR_LOCAL_SOURCE_NOT_FILE 	120835
#define SB_SFTP_ERROR_LOCAL_TARGET_NOT_FILE 	120836
#define SB_SFTP_ERROR_OPERATION_CRITERIA_NOT_MET 	120837
#define SB_SFTP_ERROR_INTERRUPTED_BY_USER 	120838
#define SB_SFTP_ERROR_SECONDARY_CHANNEL_ERROR 	120839
#define SB_SFTP_ERROR_UNSUPPORTED_ALGORITHM 	120840
#define SB_ACE4_ACCESS_ALLOWED_ACE_TYPE 	0
#define SB_ACE4_ACCESS_DENIED_ACE_TYPE 	1
#define SB_ACE4_SYSTEM_AUDIT_ACE_TYPE 	2
#define SB_ACE4_SYSTEM_ALARM_ACE_TYPE 	3
#define SB_ACE4_FILE_INHERIT_ACE 	1
#define SB_ACE4_DIRECTORY_INHERIT_ACE 	2
#define SB_ACE4_NO_PROPAGATE_INHERIT_ACE 	4
#define SB_ACE4_INHERIT_ONLY_ACE 	8
#define SB_ACE4_SUCCESSFUL_ACCESS_ACE_FLAG 	16
#define SB_ACE4_FAILED_ACCESS_ACE_FLAG 	32
#define SB_ACE4_IDENTIFIER_GROUP 	64
#define SB_ACE4_READ_DATA 	1
#define SB_ACE4_LIST_DIRECTORY 	1
#define SB_ACE4_WRITE_DATA 	2
#define SB_ACE4_ADD_FILE 	2
#define SB_ACE4_APPEND_DATA 	4
#define SB_ACE4_ADD_SUBDIRECTORY 	4
#define SB_ACE4_READ_NAMED_ATTRS 	8
#define SB_ACE4_WRITE_NAMED_ATTRS 	16
#define SB_ACE4_EXECUTE 	32
#define SB_ACE4_DELETE_CHILD 	64
#define SB_ACE4_READ_ATTRIBUTES 	128
#define SB_ACE4_WRITE_ATTRIBUTES 	256
#define SB_ACE4_DELETE 	65536
#define SB_ACE4_READ_ACL 	131072
#define SB_ACE4_WRITE_ACL 	262144
#define SB_ACE4_WRITE_OWNER 	524288
#define SB_ACE4_SYNCHRONIZE 	1048576
#define SB_SSH_FILEXFER_ATTR_FLAGS_READONLY 	1
#define SB_SSH_FILEXFER_ATTR_FLAGS_SYSTEM 	2
#define SB_SSH_FILEXFER_ATTR_FLAGS_HIDDEN 	4
#define SB_SSH_FILEXFER_ATTR_FLAGS_CASE_INSENSITIVE 	8
#define SB_SSH_FILEXFER_ATTR_FLAGS_ARCHIVE 	16
#define SB_SSH_FILEXFER_ATTR_FLAGS_ENCRYPTED 	32
#define SB_SSH_FILEXFER_ATTR_FLAGS_COMPRESSED 	64
#define SB_SSH_FILEXFER_ATTR_FLAGS_SPARSE 	128
#define SB_SSH_FILEXFER_ATTR_FLAGS_APPEND_ONLY 	256
#define SB_SSH_FILEXFER_ATTR_FLAGS_IMMUTABLE 	512
#define SB_SSH_FILEXFER_ATTR_FLAGS_SYNC 	1024
#define SB_SSH_FILEXFER_ATTR_FLAGS_TRANSLATION_ERR 	2048
#define SB_S_IRUSR 	256
#define SB_S_IWUSR 	128
#define SB_S_IXUSR 	64
#define SB_S_IRGRP 	32
#define SB_S_IWGRP 	16
#define SB_S_IXGRP 	8
#define SB_S_IROTH 	4
#define SB_S_IWOTH 	2
#define SB_S_IXOTH 	1
#define SB_S_ISUID 	2048
#define SB_S_ISGID 	1024
#define SB_S_ISVTX 	512
#ifndef SB_BUFFER_SIZE
#define SB_BUFFER_SIZE 	131072
#endif
#define SB_DATA_BUFFER_SIZE 	130048
#define SB_SSH_FXP_INIT 	1
#define SB_SSH_FXP_VERSION 	2
#define SB_SSH_FXP_OPEN 	3
#define SB_SSH_FXP_CLOSE 	4
#define SB_SSH_FXP_READ 	5
#define SB_SSH_FXP_WRITE 	6
#define SB_SSH_FXP_LSTAT 	7
#define SB_SSH_FXP_FSTAT 	8
#define SB_SSH_FXP_SETSTAT 	9
#define SB_SSH_FXP_FSETSTAT 	10
#define SB_SSH_FXP_OPENDIR 	11
#define SB_SSH_FXP_READDIR 	12
#define SB_SSH_FXP_REMOVE 	13
#define SB_SSH_FXP_MKDIR 	14
#define SB_SSH_FXP_RMDIR 	15
#define SB_SSH_FXP_REALPATH 	16
#define SB_SSH_FXP_STAT 	17
#define SB_SSH_FXP_RENAME 	18
#define SB_SSH_FXP_READLINK 	19
#define SB_SSH_FXP_SYMLINK 	20
#define SB_SSH_FXP_LINK 	21
#define SB_SSH_FXP_BLOCK 	22
#define SB_SSH_FXP_UNBLOCK 	23
#define SB_SSH_FXP_STATUS 	101
#define SB_SSH_FXP_HANDLE 	102
#define SB_SSH_FXP_DATA 	103
#define SB_SSH_FXP_NAME 	104
#define SB_SSH_FXP_ATTRS 	105
#define SB_SSH_FXP_EXTENDED 	200
#define SB_SSH_FXP_EXTENDED_REPLY 	201
#define SB_SSH_FILEXFER_ATTR_SIZE 	1
#define SB_SSH_FILEXFER_ATTR_UIDGID 	2
#define SB_SSH_FILEXFER_ATTR_PERMISSIONS 	4
#define SB_SSH_FILEXFER_ATTR_ACCESSTIME 	8
#define SB_SSH_FILEXFER_ATTR_ACMODTIME 	8
#define SB_SSH_FILEXFER_ATTR_CREATETIME 	16
#define SB_SSH_FILEXFER_ATTR_MODIFYTIME 	32
#define SB_SSH_FILEXFER_ATTR_ACL 	64
#define SB_SSH_FILEXFER_ATTR_OWNERGROUP 	128
#define SB_SSH_FILEXFER_ATTR_SUBSECOND_TIMES 	256
#define SB_SSH_FILEXFER_ATTR_BITS 	512
#define SB_SSH_FILEXFER_ATTR_ALLOCATION_SIZE 	1024
#define SB_SSH_FILEXFER_ATTR_TEXT_HINT 	2048
#define SB_SSH_FILEXFER_ATTR_MIME_TYPE 	4096
#define SB_SSH_FILEXFER_ATTR_LINK_COUNT 	8192
#define SB_SSH_FILEXFER_ATTR_UNTRANSLATED_NAME 	16384
#define SB_SSH_FILEXFER_ATTR_CTIME 	32768
#define SB_SSH_FILEXFER_ATTR_EXTENDED 	2147483648
#define SB_SSH_FILEXFER_ATTR_V3 	2147483663
#define SB_SSH_FILEXFER_ATTR_V4 	2147484157
#define SB_SSH_FILEXFER_ATTR_V5 	2147484669
#define SB_SSH_FILEXFER_ATTR_V6 	2147549181
#define SB_SSH_FILEXFER_TYPE_ERRONEOUS 	0
#define SB_SSH_FILEXFER_TYPE_REGULAR 	1
#define SB_SSH_FILEXFER_TYPE_DIRECTORY 	2
#define SB_SSH_FILEXFER_TYPE_SYMLINK 	3
#define SB_SSH_FILEXFER_TYPE_SPECIAL 	4
#define SB_SSH_FILEXFER_TYPE_UNKNOWN 	5
#define SB_SSH_FILEXFER_TYPE_SOCKET 	6
#define SB_SSH_FILEXFER_TYPE_CHAR_DEVICE 	7
#define SB_SSH_FILEXFER_TYPE_BLOCK_DEVICE 	8
#define SB_SSH_FILEXFER_TYPE_FIFO 	9
#define SB_SSH_FXF_READ 	1
#define SB_SSH_FXF_WRITE 	2
#define SB_SSH_FXF_APPEND 	4
#define SB_SSH_FXF_CREAT 	8
#define SB_SSH_FXF_TRUNC 	16
#define SB_SSH_FXF_EXCL 	32
#define SB_SSH_FXF_TEXT 	64
#define SB_SSH_FXF_ACCESS_DISPOSITION 	7
#define SB_SSH_FXF_CREATE_NEW 	0
#define SB_SSH_FXF_CREATE_TRUNCATE 	1
#define SB_SSH_FXF_OPEN_EXISTING 	2
#define SB_SSH_FXF_OPEN_OR_CREATE 	3
#define SB_SSH_FXF_TRUNCATE_EXISTING 	4
#define SB_SSH_FXF_ACCESS_APPEND_DATA 	8
#define SB_SSH_FXF_ACCESS_APPEND_DATA_ATOMIC 	16
#define SB_SSH_FXF_ACCESS_TEXT_MODE 	32
#define SB_SSH_FXF_ACCESS_READ_LOCK 	64
#define SB_SSH_FXF_ACCESS_WRITE_LOCK 	128
#define SB_SSH_FXF_ACCESS_DELETE_LOCK 	256
#define SB_SSH_FXF_ACCESS_BLOCK_READ 	64
#define SB_SSH_FXF_ACCESS_BLOCK_WRITE 	128
#define SB_SSH_FXF_ACCESS_BLOCK_DELETE 	256
#define SB_SSH_FXF_ACCESS_BLOCK_ADVISORY 	512
#define SB_SSH_FXF_ACCESS_NOFOLLOW 	1024
#define SB_SSH_FXF_ACCESS_DELETE_ON_CLOSE 	2048
#define SB_SSH_FX_OK 	0
#define SB_SSH_FX_EOF 	1
#define SB_SSH_FX_NO_SUCH_FILE 	2
#define SB_SSH_FX_PERMISSION_DENIED 	3
#define SB_SSH_FX_FAILURE 	4
#define SB_SSH_FX_BAD_MESSAGE 	5
#define SB_SSH_FX_NO_CONNECTION 	6
#define SB_SSH_FX_CONNECTION_LOST 	7
#define SB_SSH_FX_OP_UNSUPPORTED 	8
#define SB_SSH_FX_INVALID_HANDLE 	9
#define SB_SSH_FX_NO_SUCH_PATH 	10
#define SB_SSH_FX_FILE_ALREADY_EXISTS 	11
#define SB_SSH_FX_WRITE_PROTECT 	12
#define SB_SSH_FX_NO_MEDIA 	13
#define SB_SSH_FX_NO_SPACE_ON_FILESYSTEM 	14
#define SB_SSH_FX_QUOTA_EXCEEDED 	15
#define SB_SSH_FX_UNKNOWN_PRINCIPLE 	16
#define SB_SSH_FX_LOCK_CONFlICT 	17
#define SB_SSH_FX_DIR_NOT_EMPTY 	18
#define SB_SSH_FX_NOT_A_DIRECTORY 	19
#define SB_SSH_FX_INVALID_FILENAME 	20
#define SB_SSH_FX_LINK_LOOP 	21
#define SB_SSH_FX_CANNOT_DELETE 	22
#define SB_SSH_FX_INVALID_PARAMETER 	23
#define SB_SSH_FX_FILE_IS_A_DIRECTORY 	24
#define SB_SSH_FX_BYTE_RANGE_LOCK_CONFLICT 	25
#define SB_SSH_FX_BYTE_RANGE_LOCK_REFUSED 	26
#define SB_SSH_FX_DELETE_PENDING 	27
#define SB_SSH_FX_FILE_CORRUPT 	28
#define SB_SSH_FX_OWNER_INVALID 	29
#define SB_SSH_FX_GROUP_INVALID 	30
#define SB_SSH_FXP_REALPATH_NO_CHECK 	1
#define SB_SSH_ATTR_REQUEST4 	509
#define SB_SSH_ATTR_REQUEST5 	1021
#define SB_SSH_ATTR_REQUEST6 	33789
#define SB_SSH_EXT_NEWLINE 	"newline"
#define SB_SSH_EXT_NEWLINE_VANDYKE 	"newline@vandyke.com"
#define SB_SSH_EXT_SUPPORTED 	"supported"
#define SB_SSH_EXT_SUPPORTED2 	"supported2"
#define SB_SSH_EXT_VERSIONS 	"versions"
#define SB_SSH_EXT_VERSION_SELECT 	"version-select"
#define SB_SSH_EXT_FILENAME_CHARSET 	"filename-charset"
#define SB_SSH_EXT_FILENAME_TRANSLATION_CONTROL 	"filename-translation-control"
#define SB_SSH_EXT_TEXTSEEK 	"text-seek"
#define SB_SSH_EXT_VENDOR_ID 	"vendor-id"
#define SB_SSH_EXT_CHECK_FILE 	"check-file"
#define SB_SSH_EXT_CHECK_FILE_HANDLE 	"check-file-handle"
#define SB_SSH_EXT_CHECK_FILE_NAME 	"check-file-name"
#define SB_SSH_EXT_SPACE_AVAILABLE 	"space-available"
#define SB_SSH_EXT_HOME_DIRECTORY 	"home-directory"
#define SB_SSH_EXT_COPY_FILE 	"copy-file"
#define SB_SSH_EXT_COPY_DATA 	"copy-data"
#define SB_SSH_EXT_GET_TEMP_FOLDER 	"get-temp-folder"
#define SB_SSH_EXT_MAKE_TEMP_FOLDER 	"make-temp-folder"
#define SB_SSH_EXT_STATVFS 	"statvfs@openssh.com"

typedef TElClassHandle TSBSftpExtendedAttributeHandle;

typedef TElClassHandle TElSftpExtendedReplyHandle;

typedef TElSftpExtendedReplyHandle ElSftpExtendedReplyHandle;

typedef TElClassHandle TElSftpNewlineExtensionHandle;

typedef TElSftpNewlineExtensionHandle ElSftpNewlineExtensionHandle;

typedef TElClassHandle TElSftpVersionsExtensionHandle;

typedef TElSftpVersionsExtensionHandle ElSftpVersionsExtensionHandle;

typedef TElClassHandle TElSftpFilenameTranslationExtensionHandle;

typedef TElSftpFilenameTranslationExtensionHandle ElSftpFilenameTranslationExtensionHandle;

typedef TElClassHandle TElSftpFilenameCharsetExtensionHandle;

typedef TElSftpFilenameCharsetExtensionHandle ElSftpFilenameCharsetExtensionHandle;

typedef TElClassHandle TElSftpVersionSelectExtensionHandle;

typedef TElSftpVersionSelectExtensionHandle ElSftpVersionSelectExtensionHandle;

typedef TElClassHandle TElSftpSupportedExtensionHandle;

typedef TElSftpSupportedExtensionHandle ElSftpSupportedExtensionHandle;

typedef TElClassHandle TElSftpVendorIDExtensionHandle;

typedef TElSftpVendorIDExtensionHandle ElSftpVendorIDExtensionHandle;

typedef TElClassHandle TElSftpCheckFileExtensionHandle;

typedef TElSftpCheckFileExtensionHandle ElSftpCheckFileExtensionHandle;

typedef TElClassHandle TElSftpStatvfsExtensionHandle;

typedef TElSftpStatvfsExtensionHandle ElSftpStatvfsExtensionHandle;

typedef TElClassHandle TElSftpSpaceAvailableExtensionHandle;

typedef TElSftpSpaceAvailableExtensionHandle ElSftpSpaceAvailableExtensionHandle;

typedef TElClassHandle TElSftpHomeDirectoryExtensionHandle;

typedef TElSftpHomeDirectoryExtensionHandle ElSftpHomeDirectoryExtensionHandle;

typedef TElClassHandle TElSftpCopyFileExtensionHandle;

typedef TElSftpCopyFileExtensionHandle ElSftpCopyFileExtensionHandle;

typedef TElClassHandle TElSftpCopyDataExtensionHandle;

typedef TElSftpCopyDataExtensionHandle ElSftpCopyDataExtensionHandle;

typedef TElClassHandle TElSftpCheckFileReplyHandle;

typedef TElSftpCheckFileReplyHandle ElSftpCheckFileReplyHandle;

typedef TElClassHandle TElSftpSpaceAvailableReplyHandle;

typedef TElSftpSpaceAvailableReplyHandle ElSftpSpaceAvailableReplyHandle;

typedef TElClassHandle TElSftpStatVFSReplyHandle;

typedef TElSftpStatVFSReplyHandle ElSftpStatVFSReplyHandle;

typedef TElClassHandle TSBSftpACEHandle;

typedef TElClassHandle TElSftpExtendedPropertiesHandle;

typedef TElSftpExtendedPropertiesHandle ElSftpExtendedPropertiesHandle;

typedef TElClassHandle TElSftpFileAttributesHandle;

typedef TElSftpFileAttributesHandle ElSftpFileAttributesHandle;

typedef TElClassHandle TElSftpFileInfoHandle;

typedef TElSftpFileInfoHandle ElSftpFileInfoHandle;

typedef TElClassHandle TSBSftpOpenRequestInfoHandle;

typedef TElClassHandle TSBSftpTextHandleInfoHandle;

typedef TElClassHandle TElSftpTransferBlockHandle;

typedef TElSftpTransferBlockHandle ElSftpTransferBlockHandle;

typedef TElClassHandle TElSftpTransferManagerHandle;

typedef TElSftpTransferManagerHandle ElSftpTransferManagerHandle;

typedef TElClassHandle TElSftpRemovalTargetHandle;

typedef TElClassHandle TElSftpRemovalManagerHandle;

typedef uint8_t TSBSftpFileOpenModeRaw;

typedef enum
{
	fmRead = 0,
	fmWrite = 1,
	fmAppend = 2,
	sfmCreate = 3,
	fmTruncate = 4,
	fmExcl = 5,
	fmText = 6,
	fmOpenOrCreate = 7,
	fmAppendAtomic = 8,
	fmNoFollow = 9,
	fmDeleteOnClose = 10
} TSBSftpFileOpenMode;

typedef uint32_t TSBSftpFileOpenModesRaw;

typedef enum 
{
	f_fmRead = 1,
	f_fmWrite = 2,
	f_fmAppend = 4,
	f_sfmCreate = 8,
	f_fmTruncate = 16,
	f_fmExcl = 32,
	f_fmText = 64,
	f_fmOpenOrCreate = 128,
	f_fmAppendAtomic = 256,
	f_fmNoFollow = 512,
	f_fmDeleteOnClose = 1024
} TSBSftpFileOpenModes;

typedef uint8_t TSBSftpFileOpenAccessItemRaw;

typedef enum
{
	faReadLock = 0,
	faWriteLock = 1,
	faDeleteLock = 2,
	faBlockAdvisory = 3
} TSBSftpFileOpenAccessItem;

typedef uint32_t TSBSftpFileOpenAccessRaw;

typedef enum 
{
	f_faReadLock = 1,
	f_faWriteLock = 2,
	f_faDeleteLock = 4,
	f_faBlockAdvisory = 8
} TSBSftpFileOpenAccess;

typedef uint8_t TSBSftpVersionRaw;

typedef enum
{
	sbSFTP0 = 0,
	sbSFTP1 = 1,
	sbSFTP2 = 2,
	sbSFTP3 = 3,
	sbSFTP4 = 4,
	sbSFTP5 = 5,
	sbSFTP6 = 6
} TSBSftpVersion;

typedef uint32_t TSBSftpVersionsRaw;

typedef enum 
{
	f_sbSFTP0 = 1,
	f_sbSFTP1 = 2,
	f_sbSFTP2 = 4,
	f_sbSFTP3 = 8,
	f_sbSFTP4 = 16,
	f_sbSFTP5 = 32,
	f_sbSFTP6 = 64
} TSBSftpVersions;

typedef uint8_t TSBSftpAttributeRaw;

typedef enum
{
	saSize = 0,
	saOwner = 1,
	saGroup = 2,
	saUID = 3,
	saGID = 4,
	saPermissions = 5,
	saATime = 6,
	saMTime = 7,
	saCTime = 8,
	saSubSeconds = 9,
	saAttribBits = 10,
	saACL = 11,
	saExtended = 12,
	saCATime = 13,
	saASize = 14,
	saTextHint = 15,
	saMimeType = 16,
	saLinkCount = 17,
	saUName = 18
} TSBSftpAttribute;

typedef uint32_t TSBSftpAttributesRaw;

typedef enum 
{
	f_saSize = 1,
	f_saOwner = 2,
	f_saGroup = 4,
	f_saUID = 8,
	f_saGID = 16,
	f_saPermissions = 32,
	f_saATime = 64,
	f_saMTime = 128,
	f_saCTime = 256,
	f_saSubSeconds = 512,
	f_saAttribBits = 1024,
	f_saACL = 2048,
	f_saExtended = 4096,
	f_saCATime = 8192,
	f_saASize = 16384,
	f_saTextHint = 32768,
	f_saMimeType = 65536,
	f_saLinkCount = 131072,
	f_saUName = 262144
} TSBSftpAttributes;

typedef uint8_t TSBSftpRenameFlagRaw;

typedef enum
{
	rfOverwrite = 0,
	rfAtomic = 1,
	rfNative = 2
} TSBSftpRenameFlag;

typedef uint32_t TSBSftpRenameFlagsRaw;

typedef enum 
{
	f_rfOverwrite = 1,
	f_rfAtomic = 2,
	f_rfNative = 4
} TSBSftpRenameFlags;

typedef uint8_t TSBSftpTextHintRaw;

typedef enum
{
	thKnownText = 0,
	thGuessedText = 1,
	thKnownBinary = 2,
	thGuessedBinary = 3
} TSBSftpTextHint;

typedef uint8_t TSBSftpRealpathControlRaw;

typedef enum
{
	rcNoCheck = 0,
	rcStatIf = 1,
	rcStatAlways = 2
} TSBSftpRealpathControl;

typedef uint8_t TSBSftpFileOperationRaw;

typedef enum
{
	sfoDownloadFile = 0,
	sfoUploadFile = 1,
	sfoDeleteFile = 2,
	sfoMakeDir = 3
} TSBSftpFileOperation;

typedef uint8_t TSBSftpFileTypeRaw;

typedef enum
{
	ftFile = 0,
	ftDirectory = 1,
	ftSymblink = 2,
	ftSpecial = 3,
	ftUnknown = 4,
	ftSocket = 5,
	ftCharDevice = 6,
	ftBlockDevice = 7,
	ftFIFO = 8
} TSBSftpFileType;

typedef uint8_t TSBSftpTransferDirectionRaw;

typedef enum
{
	tdDownload = 0,
	tdUpload = 1
} TSBSftpTransferDirection;

typedef void (SB_CALLBACK *TSBSftpFileOpenEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pHandle[], int32_t szHandle);

typedef void (SB_CALLBACK *TSBSftpErrorEvent)(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode, const char * pcComment, int32_t szComment);

typedef void (SB_CALLBACK *TSBSftpSuccessEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcComment, int32_t szComment);

typedef void (SB_CALLBACK *TSBSftpDirectoryListingEvent)(void * _ObjectData, TObjectHandle Sender, const TElSftpFileInfoHandle pListing[], int32_t szListing);

typedef void (SB_CALLBACK *TSBSftpFileAttributesEvent)(void * _ObjectData, TObjectHandle Sender, TElSftpFileAttributesHandle Attributes);

typedef void (SB_CALLBACK *TSBSftpDataEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);

typedef void (SB_CALLBACK *TSBSftpAbsolutePathEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath);

typedef void (SB_CALLBACK *TSBSftpVersionSelectEvent)(void * _ObjectData, TObjectHandle Sender, TSBSftpVersionsRaw Versions, TSBSftpVersionRaw * Version);

typedef void (SB_CALLBACK *TSBSftpAvailableSpaceEvent)(void * _ObjectData, TObjectHandle Sender, TElSftpSpaceAvailableReplyHandle AvailSpace);

typedef void (SB_CALLBACK *TSBSftpFileHashEvent)(void * _ObjectData, TObjectHandle Sender, TElSftpCheckFileReplyHandle Reply, int8_t * Cont);

typedef void (SB_CALLBACK *TSBSftpNameEvent)(void * _ObjectData, TObjectHandle Sender, TElSftpFileInfoHandle FileInfo);

typedef void (SB_CALLBACK *TSBSftpTransferCompletedEvent)(void * _ObjectData, TObjectHandle Sender, int32_t Count);

typedef void (SB_CALLBACK *TSBSftpBlockTransferPreparedEvent)(void * _ObjectData, TObjectHandle Sender, int64_t Offset, int64_t Size, TSBSftpTransferDirectionRaw Direction, int8_t TextMode, int32_t * BlockSize, int32_t * PipelineLength);

typedef void (SB_CALLBACK *TSBSftpMessageLoopEvent)(void * _ObjectData, int8_t * OutResult);

typedef void (SB_CALLBACK *TSBSftpTunnelOpenFailedEvent)(void * _ObjectData, TObjectHandle Sender, TElCustomSSHTunnelHandle Tunnel, int8_t * AbortConnection);

typedef void (SB_CALLBACK *TSBSftpSecondaryChannelEvent)(void * _ObjectData, TObjectHandle Sender, TElCustomSSHTunnelHandle Tunnel);

typedef void (SB_CALLBACK *TSBSftpSecondaryChannelErrorEvent)(void * _ObjectData, TObjectHandle Sender, TElCustomSSHTunnelHandle Tunnel, int32_t ErrorCode);

typedef void (SB_CALLBACK *TSBSftpStatvfsEvent)(void * _ObjectData, TObjectHandle Sender, TElSftpStatVFSReplyHandle Statvfs);

typedef void (SB_CALLBACK *TElSFTPServerBlockEvent)(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t Offset, int64_t Length, TSBSftpFileOpenAccessRaw LockMask, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerUnblockEvent)(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t Offset, int64_t Length, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerCreateDirectoryEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerCreateSymLinkEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcLinkPath, int32_t szLinkPath, const char * pcTargetPath, int32_t szTargetPath, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerCreateHardLinkEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcNewLinkPath, int32_t szNewLinkPath, const char * pcExistingPath, int32_t szExistingPath, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerOpenFileEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TSBSftpFileOpenModesRaw Modes, TSBSftpFileOpenAccessRaw Access, uint32_t DesiredAccess, TElSftpFileAttributesHandle Attributes, void * (* Data), int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerRemoveEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerRenameFileEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcOldPath, int32_t szOldPath, const char * pcNewPath, int32_t szNewPath, TSBSftpRenameFlagsRaw Flags, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerReadSymLinkEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpFileInfoHandle Info, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerSetAttributesEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerSetAttributes2Event)(void * _ObjectData, TObjectHandle Sender, void * Data, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerRequestAttributesEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, int8_t FollowSymLinks, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerRequestAbsolutePathEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, char * pcAbsolutePath, int32_t * szAbsolutePath, TSBSftpRealpathControlRaw Control, TStringListHandle ComposePath, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerRequestAttributes2Event)(void * _ObjectData, TObjectHandle Sender, void * Data, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerFindFirstEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, void * (* Data), TElSftpFileInfoHandle Info, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerFindNextEvent)(void * _ObjectData, TObjectHandle Sender, void * Data, TElSftpFileInfoHandle Info, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerFindCloseEvent)(void * _ObjectData, TObjectHandle Sender, void * SearchRec, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerReadEvent)(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t Offset, void * Buffer, int32_t Count, int32_t * Read, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerWriteEvent)(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t Offset, void * Buffer, int32_t Count, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerTextSeekEvent)(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t LineNumber, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerCloseHandleEvent)(void * _ObjectData, TObjectHandle Sender, void * Data, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSFTPServerSendEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);

typedef void (SB_CALLBACK *TElSFTPServerReceiveEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t MaxSize, int32_t * Written);

typedef void (SB_CALLBACK *TElSFTPServerExtendedRequestEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcRequest, int32_t szRequest, void * Buffer, int32_t Size, TStreamHandle Response, int32_t * ErrorCode, char * pcComment, int32_t * szComment);

typedef void (SB_CALLBACK *TElSftpServerVersionChangeEvent)(void * _ObjectData, TObjectHandle Sender, TSBSftpVersionRaw Version);

typedef void (SB_CALLBACK *TElSFTPServerSendVendorIDEvent)(void * _ObjectData, TObjectHandle Sender, TElSftpVendorIDExtensionHandle VendorID, int8_t * Send);

typedef void (SB_CALLBACK *TElSFTPServerRequestFileHashEvent)(void * _ObjectData, TObjectHandle Sender, TElSftpCheckFileExtensionHandle Extension, TElSftpCheckFileReplyHandle Reply, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);

typedef void (SB_CALLBACK *TElSFTPServerRequestFileHashByHandleEvent)(void * _ObjectData, TObjectHandle Sender, void * Data, TElSftpCheckFileExtensionHandle Extension, TElSftpCheckFileReplyHandle Reply, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);

typedef void (SB_CALLBACK *TElSFTPServerRequestAvailableSpaceEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpSpaceAvailableReplyHandle Reply, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);

typedef void (SB_CALLBACK *TElSFTPServerRequestStatVFSEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpStatVFSReplyHandle Reply, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);

typedef void (SB_CALLBACK *TElSFTPServerRequestHomeDirectoryEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, char * pcHomeDir, int32_t * szHomeDir, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);

typedef void (SB_CALLBACK *TElSFTPServerCopyRemoteFileEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcSource, int32_t szSource, const char * pcDestination, int32_t szDestination, int8_t Overwrite, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);

typedef void (SB_CALLBACK *TElSFTPServerCopyRemoteDataEvent)(void * _ObjectData, TObjectHandle Sender, void * ReadFromData, int64_t ReadFromOffset, void * WriteToData, int64_t WriteToOffset, int64_t DataLength, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);

typedef void (SB_CALLBACK *TElSFTPServerReturnPathEvent)(void * _ObjectData, TObjectHandle Sender, char * pcPath, int32_t * szPath, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);

typedef void (SB_CALLBACK *TElSftpFileOperationEvent)(void * _ObjectData, TObjectHandle Sender, TSBSftpFileOperationRaw Operation, const char * pcRemotePath, int32_t szRemotePath, const char * pcLocalPath, int32_t szLocalPath, int8_t * Skip, int8_t * Cancel);

typedef void (SB_CALLBACK *TElSftpFileOperationResultEvent)(void * _ObjectData, TObjectHandle Sender, TSBSftpFileOperationRaw Operation, const char * pcRemotePath, int32_t szRemotePath, const char * pcLocalPath, int32_t szLocalPath, int32_t ErrorCode, const char * pcComment, int32_t szComment, int8_t * Cancel);

typedef void (SB_CALLBACK *TSBSftpFileNameChangeNeededEvent)(void * _ObjectData, TObjectHandle Sender, char * pcFileName, int32_t * szFileName, int8_t * Force);

typedef uint8_t TElSftpOperationRaw;

typedef enum
{
	soNone = 0,
	soCreateFile = 1,
	soCreateSymLink = 2,
	soMakeDirectory = 3,
	soOpenDirectory = 4,
	soOpenFile = 5,
	soRead = 6,
	soReadDirectory = 7,
	soReadSymLink = 8,
	soRemoveDirectory = 9,
	soRemoveFile = 10,
	soRenameFile = 11,
	soRequestAbsolutePath = 12,
	soRequestAttributes = 13,
	soSetAttributes = 14,
	soWrite = 15,
	soCloseHandle = 16,
	soVersion = 17,
	soExtension = 18,
	soCreateHardLink = 19,
	soBlock = 20,
	soUnblock = 21
} TElSftpOperation;

typedef TElSftpOperation ElSftpOperation;

#pragma pack(8)
typedef struct 
{
	uint32_t Id;
	uint32_t Request;
	void * ExtType;
} TSBSftpRequestInfo, * PSBSftpRequestInfo;

#pragma pack(8)
typedef struct 
{
	uint32_t Id;
	uint32_t DataID;
	void * FileHandle;
	int32_t _dummy0;
	int64_t FileOffset;
	int64_t ChunkOffset;
	int64_t Size;
} TSBSftpDataRequestInfo, * PSBSftpDataRequestInfo;

typedef uint8_t TSBSftpTransferBlockStateRaw;

typedef enum
{
	bsRequested = 0,
	bsPostponed = 1,
	bsFinished = 2
} TSBSftpTransferBlockState;

typedef void (SB_CALLBACK *TSBSftpReadRequestEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, int32_t Size, uint32_t * Id);

typedef void (SB_CALLBACK *TSBSftpWriteRequestEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pHandle[], int32_t szHandle, void * Buffer, int64_t Offset, int32_t Size, uint32_t * Id, int8_t Last);

typedef void (SB_CALLBACK *TSBSftpRemovalRequestEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcName, int32_t szName, uint32_t * Id);

#ifdef SB_USE_CLASS_TSBSFTPEXTENDEDATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_Assign(TSBSftpExtendedAttributeHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_AssignTo(TSBSftpExtendedAttributeHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_LoadFromBuffer(TSBSftpExtendedAttributeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_SaveToBuffer(TSBSftpExtendedAttributeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_Write(TSBSftpExtendedAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_get_ExtType(TSBSftpExtendedAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_set_ExtType(TSBSftpExtendedAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_get_ExtData(TSBSftpExtendedAttributeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_set_ExtData(TSBSftpExtendedAttributeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_get_UseUTF8(TSBSftpExtendedAttributeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_set_UseUTF8(TSBSftpExtendedAttributeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_get_NoCharacterEncoding(TSBSftpExtendedAttributeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_set_NoCharacterEncoding(TSBSftpExtendedAttributeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_get_LocalCharset(TSBSftpExtendedAttributeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_set_LocalCharset(TSBSftpExtendedAttributeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_get_RemoteCharset(TSBSftpExtendedAttributeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_set_RemoteCharset(TSBSftpExtendedAttributeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpExtendedAttribute_Create(TSBSftpExtendedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TSBSFTPEXTENDEDATTRIBUTE */

#ifdef SB_USE_CLASS_TELSFTPEXTENDEDREPLY
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_Assign(TElSftpExtendedReplyHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_AssignTo(TElSftpExtendedReplyHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_LoadFromBuffer(TElSftpExtendedReplyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_SaveToBuffer(TElSftpExtendedReplyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_Write(TElSftpExtendedReplyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_get_UseUTF8(TElSftpExtendedReplyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_set_UseUTF8(TElSftpExtendedReplyHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_get_NoCharacterEncoding(TElSftpExtendedReplyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_set_NoCharacterEncoding(TElSftpExtendedReplyHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_get_LocalCharset(TElSftpExtendedReplyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_set_LocalCharset(TElSftpExtendedReplyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_get_RemoteCharset(TElSftpExtendedReplyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_set_RemoteCharset(TElSftpExtendedReplyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_get_ReplyData(TElSftpExtendedReplyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_set_ReplyData(TElSftpExtendedReplyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedReply_Create(TElSftpExtendedReplyHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPEXTENDEDREPLY */

#ifdef SB_USE_CLASS_TELSFTPNEWLINEEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSftpNewlineExtension_Assign(TElSftpNewlineExtensionHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpNewlineExtension_LoadFromBuffer(TElSftpNewlineExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpNewlineExtension_SaveToBuffer(TElSftpNewlineExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpNewlineExtension_get_Newline(TElSftpNewlineExtensionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpNewlineExtension_set_Newline(TElSftpNewlineExtensionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpNewlineExtension_Create(TSBSftpExtendedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPNEWLINEEXTENSION */

#ifdef SB_USE_CLASS_TELSFTPVERSIONSEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionsExtension_Assign(TElSftpVersionsExtensionHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionsExtension_LoadFromBuffer(TElSftpVersionsExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionsExtension_SaveToBuffer(TElSftpVersionsExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionsExtension_get_Versions(TElSftpVersionsExtensionHandle _Handle, TSBSftpVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionsExtension_set_Versions(TElSftpVersionsExtensionHandle _Handle, TSBSftpVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionsExtension_get_VersionsStr(TElSftpVersionsExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionsExtension_Create(TSBSftpExtendedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPVERSIONSEXTENSION */

#ifdef SB_USE_CLASS_TELSFTPFILENAMETRANSLATIONEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSftpFilenameTranslationExtension_Assign(TElSftpFilenameTranslationExtensionHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFilenameTranslationExtension_LoadFromBuffer(TElSftpFilenameTranslationExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFilenameTranslationExtension_SaveToBuffer(TElSftpFilenameTranslationExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFilenameTranslationExtension_get_DoTranslate(TElSftpFilenameTranslationExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFilenameTranslationExtension_set_DoTranslate(TElSftpFilenameTranslationExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFilenameTranslationExtension_Create(TSBSftpExtendedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPFILENAMETRANSLATIONEXTENSION */

#ifdef SB_USE_CLASS_TELSFTPFILENAMECHARSETEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSftpFilenameCharsetExtension_Assign(TElSftpFilenameCharsetExtensionHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFilenameCharsetExtension_LoadFromBuffer(TElSftpFilenameCharsetExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFilenameCharsetExtension_SaveToBuffer(TElSftpFilenameCharsetExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFilenameCharsetExtension_get_Charset(TElSftpFilenameCharsetExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFilenameCharsetExtension_set_Charset(TElSftpFilenameCharsetExtensionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFilenameCharsetExtension_Create(TSBSftpExtendedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPFILENAMECHARSETEXTENSION */

#ifdef SB_USE_CLASS_TELSFTPVERSIONSELECTEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionSelectExtension_Assign(TElSftpVersionSelectExtensionHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionSelectExtension_LoadFromBuffer(TElSftpVersionSelectExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionSelectExtension_SaveToBuffer(TElSftpVersionSelectExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionSelectExtension_get_Version(TElSftpVersionSelectExtensionHandle _Handle, TSBSftpVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionSelectExtension_set_Version(TElSftpVersionSelectExtensionHandle _Handle, TSBSftpVersionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionSelectExtension_get_VersionInt(TElSftpVersionSelectExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionSelectExtension_set_VersionInt(TElSftpVersionSelectExtensionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionSelectExtension_get_VersionStr(TElSftpVersionSelectExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionSelectExtension_set_VersionStr(TElSftpVersionSelectExtensionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVersionSelectExtension_Create(TSBSftpExtendedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPVERSIONSELECTEXTENSION */

#ifdef SB_USE_CLASS_TELSFTPSUPPORTEDEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_Assign(TElSftpSupportedExtensionHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_Clear(TElSftpSupportedExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_FillDefault(TElSftpSupportedExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_LoadFromBuffer(TElSftpSupportedExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_SaveToBuffer(TElSftpSupportedExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_IsSupportedOpenBlockMode(TElSftpSupportedExtensionHandle _Handle, TSBSftpFileOpenAccessRaw Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_SetSupportedOpenBlockMode(TElSftpSupportedExtensionHandle _Handle, TSBSftpFileOpenAccessRaw Mode, int8_t Supported);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_IsSupportedBlockMode(TElSftpSupportedExtensionHandle _Handle, TSBSftpFileOpenAccessRaw Mode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_SetSupportedBlockMode(TElSftpSupportedExtensionHandle _Handle, TSBSftpFileOpenAccessRaw Mode, int8_t Supported);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_IsSupportedExtension(TElSftpSupportedExtensionHandle _Handle, const char * pcExtName, int32_t szExtName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_SetSupportedExtension(TElSftpSupportedExtensionHandle _Handle, const char * pcExtName, int32_t szExtName, int8_t Support);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_IsSupportedAttrExtension(TElSftpSupportedExtensionHandle _Handle, const char * pcExtName, int32_t szExtName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_SetSupportedAttrExtension(TElSftpSupportedExtensionHandle _Handle, const char * pcExtName, int32_t szExtName, int8_t Support);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_get_SupportedAttributes(TElSftpSupportedExtensionHandle _Handle, TSBSftpAttributesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_set_SupportedAttributes(TElSftpSupportedExtensionHandle _Handle, TSBSftpAttributesRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_get_SupportedAttribBits(TElSftpSupportedExtensionHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_set_SupportedAttribBits(TElSftpSupportedExtensionHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_get_SupportedOpenModes(TElSftpSupportedExtensionHandle _Handle, TSBSftpFileOpenModesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_set_SupportedOpenModes(TElSftpSupportedExtensionHandle _Handle, TSBSftpFileOpenModesRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_get_SupportedAccessModes(TElSftpSupportedExtensionHandle _Handle, TSBSftpFileOpenAccessRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_set_SupportedAccessModes(TElSftpSupportedExtensionHandle _Handle, TSBSftpFileOpenAccessRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_get_SupportedAccessMask(TElSftpSupportedExtensionHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_set_SupportedAccessMask(TElSftpSupportedExtensionHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_get_MaxReadSize(TElSftpSupportedExtensionHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_set_MaxReadSize(TElSftpSupportedExtensionHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_get_SupportedAttrExtensions(TElSftpSupportedExtensionHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_get_SupportedExtensions(TElSftpSupportedExtensionHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_get_Version(TElSftpSupportedExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_set_Version(TElSftpSupportedExtensionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSupportedExtension_Create(TElSftpSupportedExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPSUPPORTEDEXTENSION */

#ifdef SB_USE_CLASS_TELSFTPVENDORIDEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSftpVendorIDExtension_Assign(TElSftpVendorIDExtensionHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVendorIDExtension_LoadFromBuffer(TElSftpVendorIDExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVendorIDExtension_SaveToBuffer(TElSftpVendorIDExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVendorIDExtension_get_VendorName(TElSftpVendorIDExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVendorIDExtension_set_VendorName(TElSftpVendorIDExtensionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVendorIDExtension_get_ProductName(TElSftpVendorIDExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVendorIDExtension_set_ProductName(TElSftpVendorIDExtensionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVendorIDExtension_get_ProductVersion(TElSftpVendorIDExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVendorIDExtension_set_ProductVersion(TElSftpVendorIDExtensionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVendorIDExtension_get_BuildNumber(TElSftpVendorIDExtensionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVendorIDExtension_set_BuildNumber(TElSftpVendorIDExtensionHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpVendorIDExtension_Create(TElSftpVendorIDExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPVENDORIDEXTENSION */

#ifdef SB_USE_CLASS_TELSFTPCHECKFILEEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_Assign(TElSftpCheckFileExtensionHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_LoadFromBuffer(TElSftpCheckFileExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_SaveToBuffer(TElSftpCheckFileExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_get_Name(TElSftpCheckFileExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_set_Name(TElSftpCheckFileExtensionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_get_Handle(TElSftpCheckFileExtensionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_set_Handle(TElSftpCheckFileExtensionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_get_HashAlgorithms(TElSftpCheckFileExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_set_HashAlgorithms(TElSftpCheckFileExtensionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_get_StartOffset(TElSftpCheckFileExtensionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_set_StartOffset(TElSftpCheckFileExtensionHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_get_DataLength(TElSftpCheckFileExtensionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_set_DataLength(TElSftpCheckFileExtensionHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_get_BlockSize(TElSftpCheckFileExtensionHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_set_BlockSize(TElSftpCheckFileExtensionHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileExtension_Create(TElSftpCheckFileExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPCHECKFILEEXTENSION */

#ifdef SB_USE_CLASS_TELSFTPSTATVFSEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatvfsExtension_Assign(TElSftpStatvfsExtensionHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatvfsExtension_LoadFromBuffer(TElSftpStatvfsExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatvfsExtension_SaveToBuffer(TElSftpStatvfsExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatvfsExtension_get_Path(TElSftpStatvfsExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatvfsExtension_set_Path(TElSftpStatvfsExtensionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatvfsExtension_Create(TSBSftpExtendedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPSTATVFSEXTENSION */

#ifdef SB_USE_CLASS_TELSFTPSPACEAVAILABLEEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableExtension_Assign(TElSftpSpaceAvailableExtensionHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableExtension_LoadFromBuffer(TElSftpSpaceAvailableExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableExtension_SaveToBuffer(TElSftpSpaceAvailableExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableExtension_get_Path(TElSftpSpaceAvailableExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableExtension_set_Path(TElSftpSpaceAvailableExtensionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableExtension_Create(TSBSftpExtendedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPSPACEAVAILABLEEXTENSION */

#ifdef SB_USE_CLASS_TELSFTPHOMEDIRECTORYEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSftpHomeDirectoryExtension_Assign(TElSftpHomeDirectoryExtensionHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpHomeDirectoryExtension_LoadFromBuffer(TElSftpHomeDirectoryExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpHomeDirectoryExtension_SaveToBuffer(TElSftpHomeDirectoryExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpHomeDirectoryExtension_get_Username(TElSftpHomeDirectoryExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpHomeDirectoryExtension_set_Username(TElSftpHomeDirectoryExtensionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpHomeDirectoryExtension_Create(TSBSftpExtendedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPHOMEDIRECTORYEXTENSION */

#ifdef SB_USE_CLASS_TELSFTPCOPYFILEEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyFileExtension_Assign(TElSftpCopyFileExtensionHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyFileExtension_LoadFromBuffer(TElSftpCopyFileExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyFileExtension_SaveToBuffer(TElSftpCopyFileExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyFileExtension_get_Source(TElSftpCopyFileExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyFileExtension_set_Source(TElSftpCopyFileExtensionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyFileExtension_get_Destination(TElSftpCopyFileExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyFileExtension_set_Destination(TElSftpCopyFileExtensionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyFileExtension_get_Overwrite(TElSftpCopyFileExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyFileExtension_set_Overwrite(TElSftpCopyFileExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyFileExtension_Create(TSBSftpExtendedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPCOPYFILEEXTENSION */

#ifdef SB_USE_CLASS_TELSFTPCOPYDATAEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyDataExtension_Assign(TElSftpCopyDataExtensionHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyDataExtension_LoadFromBuffer(TElSftpCopyDataExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyDataExtension_SaveToBuffer(TElSftpCopyDataExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyDataExtension_get_ReadHandle(TElSftpCopyDataExtensionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyDataExtension_set_ReadHandle(TElSftpCopyDataExtensionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyDataExtension_get_ReadOffset(TElSftpCopyDataExtensionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyDataExtension_set_ReadOffset(TElSftpCopyDataExtensionHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyDataExtension_get_WriteHandle(TElSftpCopyDataExtensionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyDataExtension_set_WriteHandle(TElSftpCopyDataExtensionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyDataExtension_get_WriteOffset(TElSftpCopyDataExtensionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyDataExtension_set_WriteOffset(TElSftpCopyDataExtensionHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyDataExtension_get_DataLength(TElSftpCopyDataExtensionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyDataExtension_set_DataLength(TElSftpCopyDataExtensionHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCopyDataExtension_Create(TSBSftpExtendedAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPCOPYDATAEXTENSION */

#ifdef SB_USE_CLASS_TELSFTPCHECKFILEREPLY
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileReply_Assign(TElSftpCheckFileReplyHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileReply_AssignTo(TElSftpCheckFileReplyHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileReply_LoadFromBuffer(TElSftpCheckFileReplyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileReply_SaveToBuffer(TElSftpCheckFileReplyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileReply_get_Hashes(TElSftpCheckFileReplyHandle _Handle, TElByteArrayListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileReply_get_RawHashes(TElSftpCheckFileReplyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileReply_get_HashAlgorithm(TElSftpCheckFileReplyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileReply_set_HashAlgorithm(TElSftpCheckFileReplyHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileReply_get_HashSize(TElSftpCheckFileReplyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpCheckFileReply_Create(TElSftpCheckFileReplyHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPCHECKFILEREPLY */

#ifdef SB_USE_CLASS_TELSFTPSPACEAVAILABLEREPLY
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_Assign(TElSftpSpaceAvailableReplyHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_AssignTo(TElSftpSpaceAvailableReplyHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_LoadFromBuffer(TElSftpSpaceAvailableReplyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_SaveToBuffer(TElSftpSpaceAvailableReplyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_get_BytesOnDevice(TElSftpSpaceAvailableReplyHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_set_BytesOnDevice(TElSftpSpaceAvailableReplyHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_get_UnusedBytesOnDevice(TElSftpSpaceAvailableReplyHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_set_UnusedBytesOnDevice(TElSftpSpaceAvailableReplyHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_get_BytesAvailableToUser(TElSftpSpaceAvailableReplyHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_set_BytesAvailableToUser(TElSftpSpaceAvailableReplyHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_get_UnusedBytesAvailableToUser(TElSftpSpaceAvailableReplyHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_set_UnusedBytesAvailableToUser(TElSftpSpaceAvailableReplyHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_get_BytesPerAllocationUnit(TElSftpSpaceAvailableReplyHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_set_BytesPerAllocationUnit(TElSftpSpaceAvailableReplyHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpSpaceAvailableReply_Create(TElSftpExtendedReplyHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPSPACEAVAILABLEREPLY */

#ifdef SB_USE_CLASS_TELSFTPSTATVFSREPLY
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_Assign(TElSftpStatVFSReplyHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_AssignTo(TElSftpStatVFSReplyHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_LoadFromBuffer(TElSftpStatVFSReplyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_SaveToBuffer(TElSftpStatVFSReplyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_get_BSize(TElSftpStatVFSReplyHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_set_BSize(TElSftpStatVFSReplyHandle _Handle, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_get_FRSize(TElSftpStatVFSReplyHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_set_FRSize(TElSftpStatVFSReplyHandle _Handle, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_get_Blocks(TElSftpStatVFSReplyHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_set_Blocks(TElSftpStatVFSReplyHandle _Handle, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_get_BFree(TElSftpStatVFSReplyHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_set_BFree(TElSftpStatVFSReplyHandle _Handle, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_get_BAvail(TElSftpStatVFSReplyHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_set_BAvail(TElSftpStatVFSReplyHandle _Handle, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_get_Files(TElSftpStatVFSReplyHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_set_Files(TElSftpStatVFSReplyHandle _Handle, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_get_FFree(TElSftpStatVFSReplyHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_set_FFree(TElSftpStatVFSReplyHandle _Handle, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_get_FAvail(TElSftpStatVFSReplyHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_set_FAvail(TElSftpStatVFSReplyHandle _Handle, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_get_FSid(TElSftpStatVFSReplyHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_set_FSid(TElSftpStatVFSReplyHandle _Handle, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_get_Flag(TElSftpStatVFSReplyHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_set_Flag(TElSftpStatVFSReplyHandle _Handle, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_get_Namemax(TElSftpStatVFSReplyHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_set_Namemax(TElSftpStatVFSReplyHandle _Handle, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpStatVFSReply_Create(TElSftpExtendedReplyHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPSTATVFSREPLY */

#ifdef SB_USE_CLASS_TSBSFTPACE
SB_IMPORT uint32_t SB_APIENTRY TSBSftpACE_get_ACEType(TSBSftpACEHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpACE_set_ACEType(TSBSftpACEHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpACE_get_ACEFlags(TSBSftpACEHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpACE_set_ACEFlags(TSBSftpACEHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpACE_get_ACEMask(TSBSftpACEHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpACE_set_ACEMask(TSBSftpACEHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpACE_get_Who(TSBSftpACEHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpACE_set_Who(TSBSftpACEHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TSBSftpACE_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TSBSFTPACE */

#ifdef SB_USE_CLASS_TELSFTPEXTENDEDPROPERTIES
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_Assign(TElSftpExtendedPropertiesHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_AssignTo(TElSftpExtendedPropertiesHandle _Handle, TPersistentHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_RequestAttributesByVersion(TElSftpExtendedPropertiesHandle _Handle, int32_t Version, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_DesiredAccess(TElSftpExtendedPropertiesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_set_DesiredAccess(TElSftpExtendedPropertiesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_AutoAdjustDesiredAccess(TElSftpExtendedPropertiesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_set_AutoAdjustDesiredAccess(TElSftpExtendedPropertiesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_RenameFlags(TElSftpExtendedPropertiesHandle _Handle, TSBSftpRenameFlagsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_set_RenameFlags(TElSftpExtendedPropertiesHandle _Handle, TSBSftpRenameFlagsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_RenameFlagsUInt32(TElSftpExtendedPropertiesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_RequestAttributes(TElSftpExtendedPropertiesHandle _Handle, TSBSftpAttributesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_set_RequestAttributes(TElSftpExtendedPropertiesHandle _Handle, TSBSftpAttributesRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_RequestAttributesUInt32(TElSftpExtendedPropertiesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_AutoAdjustRequestAttributes(TElSftpExtendedPropertiesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_set_AutoAdjustRequestAttributes(TElSftpExtendedPropertiesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_SupportedAvailable(TElSftpExtendedPropertiesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_set_SupportedAvailable(TElSftpExtendedPropertiesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_SupportedExtension(TElSftpExtendedPropertiesHandle _Handle, TElSftpSupportedExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_set_SupportedExtension(TElSftpExtendedPropertiesHandle _Handle, TElSftpSupportedExtensionHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_NewlineAvailable(TElSftpExtendedPropertiesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_set_NewlineAvailable(TElSftpExtendedPropertiesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_NewlineExtension(TElSftpExtendedPropertiesHandle _Handle, TElSftpNewlineExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_set_NewlineExtension(TElSftpExtendedPropertiesHandle _Handle, TElSftpNewlineExtensionHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_VersionsAvailable(TElSftpExtendedPropertiesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_set_VersionsAvailable(TElSftpExtendedPropertiesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_VersionsExtension(TElSftpExtendedPropertiesHandle _Handle, TElSftpVersionsExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_set_VersionsExtension(TElSftpExtendedPropertiesHandle _Handle, TElSftpVersionsExtensionHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_VendorIDAvailable(TElSftpExtendedPropertiesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_set_VendorIDAvailable(TElSftpExtendedPropertiesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_VendorIDExtension(TElSftpExtendedPropertiesHandle _Handle, TElSftpVendorIDExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_set_VendorIDExtension(TElSftpExtendedPropertiesHandle _Handle, TElSftpVendorIDExtensionHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_get_FilenameCharset(TElSftpExtendedPropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_set_FilenameCharset(TElSftpExtendedPropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpExtendedProperties_Create(TElSftpExtendedPropertiesHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPEXTENDEDPROPERTIES */

#ifdef SB_USE_CLASS_TELSFTPFILEATTRIBUTES
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_CopyTo(TElSftpFileAttributesHandle _Handle, TElSftpFileAttributesHandle dst);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_SaveToBuffer(TElSftpFileAttributesHandle _Handle, int32_t Ver, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_LoadFromBuffer(TElSftpFileAttributesHandle _Handle, void * Buffer, int32_t Size, int32_t Ver, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_AddACE(TElSftpFileAttributesHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_RemoveACE(TElSftpFileAttributesHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_ClearACEs(TElSftpFileAttributesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_AddExtendedAttribute(TElSftpFileAttributesHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_RemoveExtendedAttribute(TElSftpFileAttributesHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_ClearExtendedAttributes(TElSftpFileAttributesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_IsAttributeIncluded(TElSftpFileAttributesHandle _Handle, TSBSftpAttributeRaw Attribute, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_Size(TElSftpFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_Size(TElSftpFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_AllocationSize(TElSftpFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_AllocationSize(TElSftpFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_UID(TElSftpFileAttributesHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_UID(TElSftpFileAttributesHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_GID(TElSftpFileAttributesHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_GID(TElSftpFileAttributesHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_Owner(TElSftpFileAttributesHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_Owner(TElSftpFileAttributesHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_Group(TElSftpFileAttributesHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_Group(TElSftpFileAttributesHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_CTime(TElSftpFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_CTime(TElSftpFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_CATime(TElSftpFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_CATime(TElSftpFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_FileType(TElSftpFileAttributesHandle _Handle, TSBSftpFileTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_FileType(TElSftpFileAttributesHandle _Handle, TSBSftpFileTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_ATime(TElSftpFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_ATime(TElSftpFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_MTime(TElSftpFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_MTime(TElSftpFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_ExtendedAttributeCount(TElSftpFileAttributesHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_ExtendedAttributes(TElSftpFileAttributesHandle _Handle, int32_t Index, TSBSftpExtendedAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_IncludedAttributes(TElSftpFileAttributesHandle _Handle, TSBSftpAttributesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_IncludedAttributes(TElSftpFileAttributesHandle _Handle, TSBSftpAttributesRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_UserRead(TElSftpFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_UserRead(TElSftpFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_UserWrite(TElSftpFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_UserWrite(TElSftpFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_UserExecute(TElSftpFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_UserExecute(TElSftpFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_GroupRead(TElSftpFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_GroupRead(TElSftpFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_GroupWrite(TElSftpFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_GroupWrite(TElSftpFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_GroupExecute(TElSftpFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_GroupExecute(TElSftpFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_OtherRead(TElSftpFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_OtherRead(TElSftpFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_OtherWrite(TElSftpFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_OtherWrite(TElSftpFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_OtherExecute(TElSftpFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_OtherExecute(TElSftpFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_UIDBit(TElSftpFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_UIDBit(TElSftpFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_GIDBit(TElSftpFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_GIDBit(TElSftpFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_StickyBit(TElSftpFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_StickyBit(TElSftpFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_Directory(TElSftpFileAttributesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_Directory(TElSftpFileAttributesHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_ACLFlags(TElSftpFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_ACLFlags(TElSftpFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_ACECount(TElSftpFileAttributesHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_ACEs(TElSftpFileAttributesHandle _Handle, int32_t Index, TSBSftpACEHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_ATimeInt64(TElSftpFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_ATimeInt64(TElSftpFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_MTimeInt64(TElSftpFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_MTimeInt64(TElSftpFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_CTimeInt64(TElSftpFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_CTimeInt64(TElSftpFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_CATimeInt64(TElSftpFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_CATimeInt64(TElSftpFileAttributesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_ATimeCardinal(TElSftpFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_ATimeCardinal(TElSftpFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_MTimeCardinal(TElSftpFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_MTimeCardinal(TElSftpFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_CTimeCardinal(TElSftpFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_CTimeCardinal(TElSftpFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_CATimeCardinal(TElSftpFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_CATimeCardinal(TElSftpFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_ATimeSeconds(TElSftpFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_MTimeSeconds(TElSftpFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_CTimeSeconds(TElSftpFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_CATimeSeconds(TElSftpFileAttributesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_ATimeMS(TElSftpFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_ATimeMS(TElSftpFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_CTimeMS(TElSftpFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_CTimeMS(TElSftpFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_CATimeMS(TElSftpFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_CATimeMS(TElSftpFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_MTimeMS(TElSftpFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_MTimeMS(TElSftpFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_AttribBits(TElSftpFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_AttribBits(TElSftpFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_AttribBitsValid(TElSftpFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_AttribBitsValid(TElSftpFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_FileTypeByte(TElSftpFileAttributesHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_FileTypeByte(TElSftpFileAttributesHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_Permissions(TElSftpFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_Permissions(TElSftpFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_TextHint(TElSftpFileAttributesHandle _Handle, TSBSftpTextHintRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_TextHint(TElSftpFileAttributesHandle _Handle, TSBSftpTextHintRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_MimeType(TElSftpFileAttributesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_MimeType(TElSftpFileAttributesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_LinkCount(TElSftpFileAttributesHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_LinkCount(TElSftpFileAttributesHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_get_UntranslatedName(TElSftpFileAttributesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_set_UntranslatedName(TElSftpFileAttributesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileAttributes_Create(TElSftpFileAttributesHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPFILEATTRIBUTES */

#ifdef SB_USE_CLASS_TELSFTPFILEINFO
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileInfo_CopyTo(TElSftpFileInfoHandle _Handle, TElSftpFileInfoHandle FileInfo);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileInfo_get_Name(TElSftpFileInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileInfo_set_Name(TElSftpFileInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileInfo_get_LongName(TElSftpFileInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileInfo_set_LongName(TElSftpFileInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileInfo_get_Path(TElSftpFileInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileInfo_set_Path(TElSftpFileInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileInfo_get_Attributes(TElSftpFileInfoHandle _Handle, TElSftpFileAttributesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpFileInfo_Create(TElSftpFileInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPFILEINFO */

#ifdef SB_USE_CLASS_TSBSFTPOPENREQUESTINFO
SB_IMPORT uint32_t SB_APIENTRY TSBSftpOpenRequestInfo_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TSBSFTPOPENREQUESTINFO */

#ifdef SB_USE_CLASS_TSBSFTPTEXTHANDLEINFO
SB_IMPORT uint32_t SB_APIENTRY TSBSftpTextHandleInfo_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TSBSFTPTEXTHANDLEINFO */

#ifdef SB_USE_CLASS_TELSFTPTRANSFERBLOCK
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferBlock_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPTRANSFERBLOCK */

#ifdef SB_USE_CLASS_TELSFTPTRANSFERMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_Run(TElSftpTransferManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_ProcessData(TElSftpTransferManagerHandle _Handle, uint32_t Id, void * Buffer, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_ProcessStatus(TElSftpTransferManagerHandle _Handle, uint32_t Id, int32_t StatusCode, const char * pcComment, int32_t szComment, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_OperationFinished(TElSftpTransferManagerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_Terminate(TElSftpTransferManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_get_Direction(TElSftpTransferManagerHandle _Handle, TSBSftpTransferDirectionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_get_Received(TElSftpTransferManagerHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_get_Handle(TElSftpTransferManagerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_get_TextMode(TElSftpTransferManagerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_get_LastError(TElSftpTransferManagerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_get_LastComment(TElSftpTransferManagerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_get_OnData(TElSftpTransferManagerHandle _Handle, TSBSftpDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_set_OnData(TElSftpTransferManagerHandle _Handle, TSBSftpDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_get_OnASCIIData(TElSftpTransferManagerHandle _Handle, TSBSftpDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_set_OnASCIIData(TElSftpTransferManagerHandle _Handle, TSBSftpDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_get_OnReadRequest(TElSftpTransferManagerHandle _Handle, TSBSftpReadRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_set_OnReadRequest(TElSftpTransferManagerHandle _Handle, TSBSftpReadRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_get_OnWriteRequest(TElSftpTransferManagerHandle _Handle, TSBSftpWriteRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_set_OnWriteRequest(TElSftpTransferManagerHandle _Handle, TSBSftpWriteRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_get_OnFinish(TElSftpTransferManagerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_set_OnFinish(TElSftpTransferManagerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_get_OnProgress(TElSftpTransferManagerHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_set_OnProgress(TElSftpTransferManagerHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpTransferManager_Create(const uint8_t pHandle[], int32_t szHandle, int64_t Offset, void * Buffer, int32_t Size, int32_t ChunkSize, int32_t MaxActiveCount, TSBSftpTransferDirectionRaw Direction, int8_t TextMode, TElSftpTransferManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPTRANSFERMANAGER */

#ifdef SB_USE_CLASS_TELSFTPREMOVALTARGET
SB_IMPORT uint32_t SB_APIENTRY TElSftpRemovalTarget_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPREMOVALTARGET */

#ifdef SB_USE_CLASS_TELSFTPREMOVALMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElSftpRemovalManager_Run(TElSftpRemovalManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpRemovalManager_ProcessStatus(TElSftpRemovalManagerHandle _Handle, uint32_t Id, int32_t StatusCode, const char * pcErrorMsg, int32_t szErrorMsg, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpRemovalManager_OperationFinished(TElSftpRemovalManagerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpRemovalManager_Terminate(TElSftpRemovalManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSftpRemovalManager_get_ErrorList(TElSftpRemovalManagerHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpRemovalManager_get_ErrorFilenames(TElSftpRemovalManagerHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpRemovalManager_get_OnFinish(TElSftpRemovalManagerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpRemovalManager_set_OnFinish(TElSftpRemovalManagerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpRemovalManager_get_OnProgress(TElSftpRemovalManagerHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpRemovalManager_set_OnProgress(TElSftpRemovalManagerHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpRemovalManager_get_OnRemovalRequest(TElSftpRemovalManagerHandle _Handle, TSBSftpRemovalRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSftpRemovalManager_set_OnRemovalRequest(TElSftpRemovalManagerHandle _Handle, TSBSftpRemovalRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSftpRemovalManager_Create(TStringsHandle Filenames, int32_t MaxActiveCount, TElSftpRemovalManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPREMOVALMANAGER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TSBSftpRequestInfo_ce_ptr;
extern zend_class_entry *TSBSftpDataRequestInfo_ce_ptr;
extern zend_class_entry *TSBSftpExtendedAttribute_ce_ptr;
extern zend_class_entry *TElSftpExtendedReply_ce_ptr;
extern zend_class_entry *TElSftpNewlineExtension_ce_ptr;
extern zend_class_entry *TElSftpVersionsExtension_ce_ptr;
extern zend_class_entry *TElSftpFilenameTranslationExtension_ce_ptr;
extern zend_class_entry *TElSftpFilenameCharsetExtension_ce_ptr;
extern zend_class_entry *TElSftpVersionSelectExtension_ce_ptr;
extern zend_class_entry *TElSftpSupportedExtension_ce_ptr;
extern zend_class_entry *TElSftpVendorIDExtension_ce_ptr;
extern zend_class_entry *TElSftpCheckFileExtension_ce_ptr;
extern zend_class_entry *TElSftpStatvfsExtension_ce_ptr;
extern zend_class_entry *TElSftpSpaceAvailableExtension_ce_ptr;
extern zend_class_entry *TElSftpHomeDirectoryExtension_ce_ptr;
extern zend_class_entry *TElSftpCopyFileExtension_ce_ptr;
extern zend_class_entry *TElSftpCopyDataExtension_ce_ptr;
extern zend_class_entry *TElSftpCheckFileReply_ce_ptr;
extern zend_class_entry *TElSftpSpaceAvailableReply_ce_ptr;
extern zend_class_entry *TElSftpStatVFSReply_ce_ptr;
extern zend_class_entry *TSBSftpACE_ce_ptr;
extern zend_class_entry *TElSftpExtendedProperties_ce_ptr;
extern zend_class_entry *TElSftpFileAttributes_ce_ptr;
extern zend_class_entry *TElSftpFileInfo_ce_ptr;
extern zend_class_entry *TSBSftpOpenRequestInfo_ce_ptr;
extern zend_class_entry *TSBSftpTextHandleInfo_ce_ptr;
extern zend_class_entry *TElSftpTransferBlock_ce_ptr;
extern zend_class_entry *TElSftpTransferManager_ce_ptr;
extern zend_class_entry *TElSftpRemovalTarget_ce_ptr;
extern zend_class_entry *TElSftpRemovalManager_ce_ptr;

void SB_CALLBACK TSBSftpFileOpenEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pHandle[], int32_t szHandle);
void SB_CALLBACK TSBSftpErrorEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode, const char * pcComment, int32_t szComment);
void SB_CALLBACK TSBSftpSuccessEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcComment, int32_t szComment);
void SB_CALLBACK TSBSftpDirectoryListingEventRaw(void * _ObjectData, TObjectHandle Sender, const TElSftpFileInfoHandle pListing[], int32_t szListing);
void SB_CALLBACK TSBSftpFileAttributesEventRaw(void * _ObjectData, TObjectHandle Sender, TElSftpFileAttributesHandle Attributes);
void SB_CALLBACK TSBSftpDataEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);
void SB_CALLBACK TSBSftpAbsolutePathEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath);
void SB_CALLBACK TSBSftpVersionSelectEventRaw(void * _ObjectData, TObjectHandle Sender, TSBSftpVersionsRaw Versions, TSBSftpVersionRaw * Version);
void SB_CALLBACK TSBSftpAvailableSpaceEventRaw(void * _ObjectData, TObjectHandle Sender, TElSftpSpaceAvailableReplyHandle AvailSpace);
void SB_CALLBACK TSBSftpFileHashEventRaw(void * _ObjectData, TObjectHandle Sender, TElSftpCheckFileReplyHandle Reply, int8_t * Cont);
void SB_CALLBACK TSBSftpNameEventRaw(void * _ObjectData, TObjectHandle Sender, TElSftpFileInfoHandle FileInfo);
void SB_CALLBACK TSBSftpTransferCompletedEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t Count);
void SB_CALLBACK TSBSftpBlockTransferPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, int64_t Offset, int64_t Size, TSBSftpTransferDirectionRaw Direction, int8_t TextMode, int32_t * BlockSize, int32_t * PipelineLength);
void SB_CALLBACK TSBSftpMessageLoopEventRaw(void * _ObjectData, int8_t * OutResult);
void SB_CALLBACK TSBSftpTunnelOpenFailedEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomSSHTunnelHandle Tunnel, int8_t * AbortConnection);
void SB_CALLBACK TSBSftpSecondaryChannelEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomSSHTunnelHandle Tunnel);
void SB_CALLBACK TSBSftpSecondaryChannelErrorEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomSSHTunnelHandle Tunnel, int32_t ErrorCode);
void SB_CALLBACK TSBSftpStatvfsEventRaw(void * _ObjectData, TObjectHandle Sender, TElSftpStatVFSReplyHandle Statvfs);
void SB_CALLBACK TElSFTPServerBlockEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t Offset, int64_t Length, TSBSftpFileOpenAccessRaw LockMask, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerUnblockEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t Offset, int64_t Length, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerCreateDirectoryEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerCreateSymLinkEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcLinkPath, int32_t szLinkPath, const char * pcTargetPath, int32_t szTargetPath, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerCreateHardLinkEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcNewLinkPath, int32_t szNewLinkPath, const char * pcExistingPath, int32_t szExistingPath, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerOpenFileEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TSBSftpFileOpenModesRaw Modes, TSBSftpFileOpenAccessRaw Access, uint32_t DesiredAccess, TElSftpFileAttributesHandle Attributes, void * (* Data), int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerRemoveEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerRenameFileEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcOldPath, int32_t szOldPath, const char * pcNewPath, int32_t szNewPath, TSBSftpRenameFlagsRaw Flags, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerReadSymLinkEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpFileInfoHandle Info, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerSetAttributesEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerSetAttributes2EventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerRequestAttributesEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, int8_t FollowSymLinks, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerRequestAbsolutePathEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, char * pcAbsolutePath, int32_t * szAbsolutePath, TSBSftpRealpathControlRaw Control, TStringListHandle ComposePath, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerRequestAttributes2EventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, TElSftpFileAttributesHandle Attributes, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerFindFirstEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, void * (* Data), TElSftpFileInfoHandle Info, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerFindNextEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, TElSftpFileInfoHandle Info, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerFindCloseEventRaw(void * _ObjectData, TObjectHandle Sender, void * SearchRec, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerReadEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t Offset, void * Buffer, int32_t Count, int32_t * Read, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerWriteEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t Offset, void * Buffer, int32_t Count, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerTextSeekEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, int64_t LineNumber, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerCloseHandleEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSFTPServerSendEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);
void SB_CALLBACK TElSFTPServerReceiveEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t MaxSize, int32_t * Written);
void SB_CALLBACK TElSFTPServerExtendedRequestEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcRequest, int32_t szRequest, void * Buffer, int32_t Size, TStreamHandle Response, int32_t * ErrorCode, char * pcComment, int32_t * szComment);
void SB_CALLBACK TElSftpServerVersionChangeEventRaw(void * _ObjectData, TObjectHandle Sender, TSBSftpVersionRaw Version);
void SB_CALLBACK TElSFTPServerSendVendorIDEventRaw(void * _ObjectData, TObjectHandle Sender, TElSftpVendorIDExtensionHandle VendorID, int8_t * Send);
void SB_CALLBACK TElSFTPServerRequestFileHashEventRaw(void * _ObjectData, TObjectHandle Sender, TElSftpCheckFileExtensionHandle Extension, TElSftpCheckFileReplyHandle Reply, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);
void SB_CALLBACK TElSFTPServerRequestFileHashByHandleEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data, TElSftpCheckFileExtensionHandle Extension, TElSftpCheckFileReplyHandle Reply, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);
void SB_CALLBACK TElSFTPServerRequestAvailableSpaceEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpSpaceAvailableReplyHandle Reply, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);
void SB_CALLBACK TElSFTPServerRequestStatVFSEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPath, int32_t szPath, TElSftpStatVFSReplyHandle Reply, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);
void SB_CALLBACK TElSFTPServerRequestHomeDirectoryEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, char * pcHomeDir, int32_t * szHomeDir, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);
void SB_CALLBACK TElSFTPServerCopyRemoteFileEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcSource, int32_t szSource, const char * pcDestination, int32_t szDestination, int8_t Overwrite, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);
void SB_CALLBACK TElSFTPServerCopyRemoteDataEventRaw(void * _ObjectData, TObjectHandle Sender, void * ReadFromData, int64_t ReadFromOffset, void * WriteToData, int64_t WriteToOffset, int64_t DataLength, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);
void SB_CALLBACK TElSFTPServerReturnPathEventRaw(void * _ObjectData, TObjectHandle Sender, char * pcPath, int32_t * szPath, int32_t * ErrCode, char * pcErrComment, int32_t * szErrComment);
void SB_CALLBACK TElSftpFileOperationEventRaw(void * _ObjectData, TObjectHandle Sender, TSBSftpFileOperationRaw Operation, const char * pcRemotePath, int32_t szRemotePath, const char * pcLocalPath, int32_t szLocalPath, int8_t * Skip, int8_t * Cancel);
void SB_CALLBACK TElSftpFileOperationResultEventRaw(void * _ObjectData, TObjectHandle Sender, TSBSftpFileOperationRaw Operation, const char * pcRemotePath, int32_t szRemotePath, const char * pcLocalPath, int32_t szLocalPath, int32_t ErrorCode, const char * pcComment, int32_t szComment, int8_t * Cancel);
void SB_CALLBACK TSBSftpFileNameChangeNeededEventRaw(void * _ObjectData, TObjectHandle Sender, char * pcFileName, int32_t * szFileName, int8_t * Force);
void Register_TSBSftpRequestInfo(TSRMLS_D);
void Register_TSBSftpDataRequestInfo(TSRMLS_D);
void SB_CALLBACK TSBSftpReadRequestEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, int32_t Size, uint32_t * Id);
void SB_CALLBACK TSBSftpWriteRequestEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pHandle[], int32_t szHandle, void * Buffer, int64_t Offset, int32_t Size, uint32_t * Id, int8_t Last);
void SB_CALLBACK TSBSftpRemovalRequestEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcName, int32_t szName, uint32_t * Id);
void Register_TSBSftpExtendedAttribute(TSRMLS_D);
void Register_TElSftpExtendedReply(TSRMLS_D);
void Register_TElSftpNewlineExtension(TSRMLS_D);
void Register_TElSftpVersionsExtension(TSRMLS_D);
void Register_TElSftpFilenameTranslationExtension(TSRMLS_D);
void Register_TElSftpFilenameCharsetExtension(TSRMLS_D);
void Register_TElSftpVersionSelectExtension(TSRMLS_D);
void Register_TElSftpSupportedExtension(TSRMLS_D);
void Register_TElSftpVendorIDExtension(TSRMLS_D);
void Register_TElSftpCheckFileExtension(TSRMLS_D);
void Register_TElSftpStatvfsExtension(TSRMLS_D);
void Register_TElSftpSpaceAvailableExtension(TSRMLS_D);
void Register_TElSftpHomeDirectoryExtension(TSRMLS_D);
void Register_TElSftpCopyFileExtension(TSRMLS_D);
void Register_TElSftpCopyDataExtension(TSRMLS_D);
void Register_TElSftpCheckFileReply(TSRMLS_D);
void Register_TElSftpSpaceAvailableReply(TSRMLS_D);
void Register_TElSftpStatVFSReply(TSRMLS_D);
void Register_TSBSftpACE(TSRMLS_D);
void Register_TElSftpExtendedProperties(TSRMLS_D);
void Register_TElSftpFileAttributes(TSRMLS_D);
void Register_TElSftpFileInfo(TSRMLS_D);
void Register_TSBSftpOpenRequestInfo(TSRMLS_D);
void Register_TSBSftpTextHandleInfo(TSRMLS_D);
void Register_TElSftpTransferBlock(TSRMLS_D);
void Register_TElSftpTransferManager(TSRMLS_D);
void Register_TElSftpRemovalTarget(TSRMLS_D);
void Register_TElSftpRemovalManager(TSRMLS_D);
SB_PHP_FUNCTION(SBSftpCommon, WriteDefaultAttributes);
SB_PHP_FUNCTION(SBSftpCommon, RealPathControlToByte);
SB_PHP_FUNCTION(SBSftpCommon, ByteToRealPathControl);
SB_PHP_FUNCTION(SBSftpCommon, FileOpenAccessToUInt32);
SB_PHP_FUNCTION(SBSftpCommon, UInt32ToFileOpenAccess);
SB_PHP_FUNCTION(SBSftpCommon, UInt32ToRenameFlags);
SB_PHP_FUNCTION(SBSftpCommon, GetSFTPPacketNameByCode);
void Register_SBSftpCommon_Constants(int module_number TSRMLS_DC);
void Register_SBSftpCommon_Enum_Flags(TSRMLS_D);
void Register_SBSftpCommon_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_SFTPCOMMON
SB_IMPORT uint32_t SB_APIENTRY SBSftpCommon_WriteDefaultAttributes(TElSftpFileAttributesHandle * Attributes);
SB_IMPORT uint32_t SB_APIENTRY SBSftpCommon_RealPathControlToByte(TSBSftpRealpathControlRaw Value, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSftpCommon_ByteToRealPathControl(uint8_t Value, TSBSftpRealpathControlRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSftpCommon_FileOpenAccessToUInt32(TSBSftpFileOpenAccessRaw Value, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSftpCommon_UInt32ToFileOpenAccess(uint32_t Value, TSBSftpFileOpenAccessRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSftpCommon_UInt32ToRenameFlags(uint32_t Value, TSBSftpRenameFlagsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSftpCommon_GetSFTPPacketNameByCode(int32_t Code, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_SFTPCOMMON */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSFTPCOMMON */

