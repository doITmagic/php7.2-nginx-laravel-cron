#ifndef __INC_SBSFTPHANDLER
#define __INC_SBSFTPHANDLER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbsshcommon.h"
#include "sbsshhandlers.h"
#include "sbsftpcommon.h"
#include "sbsftpserver.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSFTPSSHSubsystemHandlerHandle;

typedef TElSFTPSSHSubsystemHandlerHandle ElSFTPSSHSubsystemHandlerHandle;

#ifdef SB_USE_CLASS_TELSFTPSSHSUBSYSTEMHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElSFTPSSHSubsystemHandler_HandlerType(TElSFTPSSHSubsystemHandlerHandle _Handle, TSBSSHSubsystemHandlerTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSFTPSSHSubsystemHandler_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSFTPSSHSubsystemHandler_get_Version(TElSFTPSSHSubsystemHandlerHandle _Handle, TSBSftpVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSFTPSSHSubsystemHandler_get_Versions(TElSFTPSSHSubsystemHandlerHandle _Handle, TSBSftpVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSFTPSSHSubsystemHandler_set_Versions(TElSFTPSSHSubsystemHandlerHandle _Handle, TSBSftpVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSFTPSSHSubsystemHandler_get_NewLineConvention(TElSFTPSSHSubsystemHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSFTPSSHSubsystemHandler_set_NewLineConvention(TElSFTPSSHSubsystemHandlerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSFTPSSHSubsystemHandler_get_Server(TElSFTPSSHSubsystemHandlerHandle _Handle, TElSFTPServerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSFTPSSHSubsystemHandler_set_Server(TElSFTPSSHSubsystemHandlerHandle _Handle, TElSFTPServerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSFTPSSHSubsystemHandler_Create(TElSSHTunnelConnectionHandle Connection, TElSFTPSSHSubsystemHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSFTPSSHSubsystemHandler_CreateDelayed(TElSSHTunnelConnectionHandle Connection, TElSFTPServerHandle Server, TElSFTPSSHSubsystemHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSFTPSSHSUBSYSTEMHANDLER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSFTPSSHSubsystemHandler_ce_ptr;

void Register_TElSFTPSSHSubsystemHandler(TSRMLS_D);
void Register_SBSftpHandler_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSFTPHANDLER */

