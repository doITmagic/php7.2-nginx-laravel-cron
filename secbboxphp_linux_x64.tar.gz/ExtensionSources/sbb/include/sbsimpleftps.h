#ifndef __INC_SBSIMPLEFTPS
#define __INC_SBSIMPLEFTPS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbmath.h"
#include "sbhashfunction.h"
#include "sbcrc.h"
#include "sbstringlist.h"
#include "sbdnssecconsts.h"
#include "sbdnssectypes.h"
#include "sbchsconv.h"
#include "sbchsconvcharsets.h"
#include "sbchscjk.h"
#include "sbsslcommon.h"
#include "sbsslconstants.h"
#include "sbsslclient.h"
#include "sbcmdsslclient.h"
#include "sbconstants.h"
#include "sbsharedresource.h"
#include "sbcustomfsadapter.h"
#include "sbdiskfsadapter.h"
#include "sbsocket.h"
#include "sbportknock.h"
#include "sbx509.h"
#include "sbx509ext.h"
#include "sbcustomcertstorage.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_FTPS 	114688
#define SB_ERROR_COMM_OPERATION_BASE 	1024
#define SB_ERROR_FS_OPERATION_BASE 	2048
#define SB_FTPS_ERROR_CONTROL_CHANNEL_HANGUP 	114689
#define SB_FTPS_ERROR_CONTROL_CHANNEL_NO_DATA 	114690
#define SB_FTPS_ERROR_UNACCEPTED_REPLY_CODE 	115713
#define SB_FTPS_ERROR_INVALID_REPLY 	115714
#define SB_FTPS_ERROR_LOCAL_SOURCE_NOT_FILE 	116737
#define SB_FTPS_ERROR_LOCAL_TARGET_NOT_FILE 	116738
#define SB_FTPS_ERROR_RESUME_OFFSET_TOO_LARGE 	116739
#define SB_FTPS_ERROR_OPERATION_CRITERIA_NOT_MET 	116740
#define SB_FTPS_ERROR_TIMES_NOT_SET 	116741

typedef TElClassHandle TElSimpleFTPSClientHandle;

typedef TElClassHandle TElFTPFileInfoHandle;

typedef TElClassHandle TElFTPProxySettingsHandle;

typedef TElFTPProxySettingsHandle TSBFTPProxySettingsHandle;

typedef TElClassHandle TElFTPSTransferManagerHandle;

typedef TElSimpleFTPSClientHandle ElSimpleFTPSClientHandle;

typedef TElClassHandle TElMultipartStreamAccessHandle;

typedef TElClassHandle TElFTPSTransferChunkHandle;

typedef TElClassHandle TElMultipartStreamPartHandle;

typedef uint8_t TSBFTPSSLStateRaw;

typedef enum
{
	fsPlain = 0,
	fsEncrypted = 1
} TSBFTPSSLState;

typedef uint8_t TSBFTPTransferTypeRaw;

typedef enum
{
	ttASCII = 0,
	ttBinary = 1
} TSBFTPTransferType;

typedef uint8_t TSBFTPAuthCmdRaw;

typedef enum
{
	acAuto = 0,
	acAuthTLS = 1,
	acAuthSSL = 2,
	acAuthTLSP = 3,
	acAuthTLSC = 4
} TSBFTPAuthCmd;

typedef uint8_t TSBFTPProxyTypeRaw;

typedef enum
{
	ptNone = 0,
	ptUserSite = 1,
	ptSite = 2,
	ptOpen = 3,
	ptUserPass = 4,
	ptTransparent = 5
} TSBFTPProxyType;

typedef uint8_t TSBFileEntryFormatRaw;

typedef enum
{
	fefUnknown = 0,
	fefUnix = 1,
	fefWindows = 2,
	fefMLSD = 3
} TSBFileEntryFormat;

typedef uint8_t TSBFileEntryTypeRaw;

typedef enum
{
	fetUnknown = 0,
	fetDirectory = 1,
	fetFile = 2,
	fetSymlink = 3,
	fetSpecial = 4,
	fetCurrentDirectory = 5,
	fetParentDirectory = 6
} TSBFileEntryType;

typedef uint8_t TSBFTPStateRaw;

typedef enum
{
	fsDisconnected = 0,
	fsConnected = 1,
	fsLoggedIn = 2
} TSBFTPState;

typedef uint8_t TSBFTPCheckMethodRaw;

typedef enum
{
	cmCRC = 0,
	cmMD5 = 1,
	cmSHA1 = 2
} TSBFTPCheckMethod;

typedef uint8_t TSBFTPOptionRaw;

typedef enum
{
	foCCCSiteWorkaround = 0,
	foSyncDataChannel = 1,
	foSmartSSLSetup = 2,
	foStreamingASCIIMode = 3,
	foPreallocateStorage = 4
} TSBFTPOption;

typedef uint32_t TSBFTPOptionsRaw;

typedef enum 
{
	f_foCCCSiteWorkaround = 1,
	f_foSyncDataChannel = 2,
	f_foSmartSSLSetup = 4,
	f_foStreamingASCIIMode = 8,
	f_foPreallocateStorage = 16
} TSBFTPOptions;

typedef uint8_t TSBFtpFileOperationRaw;

typedef enum
{
	ffoDownloadFile = 0,
	ffoUploadFile = 1,
	ffoDeleteFile = 2,
	ffoMakeDir = 3
} TSBFtpFileOperation;

typedef void (SB_CALLBACK *TSBFTPSTextDataEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pTextLine[], int32_t szTextLine);

typedef void (SB_CALLBACK *TSBFTPSBinaryDataEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pData[], int32_t szData);

typedef void (SB_CALLBACK *TSBFTPSInnerClientEvent)(void * _ObjectData, TObjectHandle Sender, TElSimpleFTPSClientHandle Client);

typedef void (SB_CALLBACK *TSBFTPSRenegotiationRequestEvent)(void * _ObjectData, TObjectHandle Sender, int8_t DataChannel, int8_t * Allow);

typedef void (SB_CALLBACK *TElFTPFileOperationEvent)(void * _ObjectData, TObjectHandle Sender, TSBFtpFileOperationRaw Operation, const char * pcRemotePath, int32_t szRemotePath, const char * pcLocalPath, int32_t szLocalPath, int8_t * Skip, int8_t * Cancel);

typedef void (SB_CALLBACK *TElFTPFileOperationResultEvent)(void * _ObjectData, TObjectHandle Sender, TSBFtpFileOperationRaw Operation, const char * pcRemotePath, int32_t szRemotePath, const char * pcLocalPath, int32_t szLocalPath, int32_t ErrorCode, const char * pcComment, int32_t szComment, int8_t * Cancel);

typedef void (SB_CALLBACK *TSBFTPSFileNameChangeNeededEvent)(void * _ObjectData, TObjectHandle Sender, char * pcFileName, int32_t * szFileName, int8_t * Force);

#pragma pack(8)
typedef struct 
{
	void * FileName;
	int32_t _dummy0;
	int64_t FileSize;
	TSBFileEntryTypeRaw FileType;
	int8_t _dummy1;
	int16_t _dummy2;
	int32_t _dummy3;
	double FileDate;
	TSBFileEntryFormatRaw EntryFormat;
	int8_t _dummy4;
	int16_t _dummy5;
	void * RawData;
} TSBFTPFileInfo;

typedef void (SB_CALLBACK *TSBFTPSBeforeParseFileListEntry)(void * _ObjectData, TObjectHandle Sender, const char * pcEntry, int32_t szEntry, TElFTPFileInfoHandle FileInfo, int8_t * Handled);

typedef void (SB_CALLBACK *TSBFTPSAfterParseFileListEntry)(void * _ObjectData, TObjectHandle Sender, const char * pcEntry, int32_t szEntry, TElFTPFileInfoHandle FileInfo, int8_t * Success);

typedef uint8_t TSBFTPSTransferChunkStateRaw;

typedef enum
{
	tcsPrepared = 0,
	tcsActive = 1,
	tcsSucceeded = 2,
	tcsFailed = 3
} TSBFTPSTransferChunkState;

#ifdef SB_USE_CLASS_TELSIMPLEFTPSCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_ParseFileListEntry(const char * pcEntry, int32_t szEntry, TSBFTPFileInfo * FileInfo);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_ParseFileListEntry_1(TElSimpleFTPSClientHandle _Handle, const char * pcEntry, int32_t szEntry, TSBFTPFileInfo * FileInfo);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_ParseFileListEntry_2(TElSimpleFTPSClientHandle _Handle, const char * pcEntry, int32_t szEntry, TElFTPFileInfoHandle FileInfo);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_ParseMLSDEntry(const char * pcEntry, int32_t szEntry, TSBFTPFileInfo * FileInfo);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_ParseMLSDEntry_1(TElSimpleFTPSClientHandle _Handle, const char * pcEntry, int32_t szEntry, TSBFTPFileInfo * FileInfo);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_ParseMLSDEntry_2(const char * pcEntry, int32_t szEntry, TElFTPFileInfoHandle FileInfo);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_ParseMLSDEntry_3(TElSimpleFTPSClientHandle _Handle, const char * pcEntry, int32_t szEntry, TElFTPFileInfoHandle FileInfo);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Abort(TElSimpleFTPSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Acct(TElSimpleFTPSClientHandle _Handle, const char * pcAcctInfo, int32_t szAcctInfo);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Allocate(TElSimpleFTPSClientHandle _Handle, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Assign(TElSimpleFTPSClientHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_CDUp(TElSimpleFTPSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_ClearCommandChannel(TElSimpleFTPSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_ClearCommandChannel_1(TElSimpleFTPSClientHandle _Handle, int8_t GracefulSSLClosure);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Interrupt(TElSimpleFTPSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Close(TElSimpleFTPSClientHandle _Handle, int8_t Silent);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Cwd(TElSimpleFTPSClientHandle _Handle, const char * pcAPath, int32_t szAPath);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Delete(TElSimpleFTPSClientHandle _Handle, const char * pcAFilename, int32_t szAFilename);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_GetCurrentDir(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_GetServerSystem(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_MLSD(TElSimpleFTPSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_MLSD_1(TElSimpleFTPSClientHandle _Handle, TElStringListHandle ResultList);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_MLSD_2(TElSimpleFTPSClientHandle _Handle, TListHandle ResultList);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_MLSD_3(TElSimpleFTPSClientHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_MLSD_4(TElSimpleFTPSClientHandle _Handle, const char * pcPath, int32_t szPath, TElStringListHandle ResultList);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_MLSD_5(TElSimpleFTPSClientHandle _Handle, const char * pcPath, int32_t szPath, TListHandle ResultList);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_MLST(TElSimpleFTPSClientHandle _Handle, const char * pcPath, int32_t szPath, TElFTPFileInfoHandle FileInfo, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_CreateCompletePath(TElSimpleFTPSClientHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_NOOP(TElSimpleFTPSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_DirectoryExists(TElSimpleFTPSClientHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_FileExists(TElSimpleFTPSClientHandle _Handle, const char * pcAFilename, int32_t szAFilename, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_GetFileSize(TElSimpleFTPSClientHandle _Handle, const char * pcAFilename, int32_t szAFilename, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_GetFileTime(TElSimpleFTPSClientHandle _Handle, const char * pcAFilename, int32_t szAFilename, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_SetFileTime(TElSimpleFTPSClientHandle _Handle, const char * pcAFilename, int32_t szAFilename, int64_t NewDate, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_GetRemoteChecksum(TElSimpleFTPSClientHandle _Handle, const char * pcAFileName, int32_t szAFileName, TSBFTPCheckMethodRaw CheckMethod, int64_t StartPoint, int64_t EndPoint, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_GetLocalChecksum(TElSimpleFTPSClientHandle _Handle, const char * pcAFileName, int32_t szAFileName, TSBFTPCheckMethodRaw CheckMethod, int64_t StartPoint, int64_t EndPoint, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_GetNameList(TElSimpleFTPSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_GetNameList_1(TElSimpleFTPSClientHandle _Handle, const char * pcParameters, int32_t szParameters);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_GetFileList(TElSimpleFTPSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_GetFileList_1(TElSimpleFTPSClientHandle _Handle, const char * pcParameters, int32_t szParameters);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_GetFileList_2(TElSimpleFTPSClientHandle _Handle, const char * pcParameters, int32_t szParameters, TElStringListHandle ResultList);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_GetFileList_3(TElSimpleFTPSClientHandle _Handle, const char * pcParameters, int32_t szParameters, TListHandle ResultList);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_ListDirectory(TElSimpleFTPSClientHandle _Handle, const char * pcPath, int32_t szPath, TListHandle Listing, const char * pcMask, int32_t szMask, int8_t CaseSensitive, int8_t IncludeFiles, int8_t IncludeDirectories);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_ListDirectory_1(TElSimpleFTPSClientHandle _Handle, const char * pcPath, int32_t szPath, TListHandle Listing, const char * pcMask, int32_t szMask, int8_t CaseSensitive, int8_t IncludeFiles, int8_t IncludeDirectories, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Open(TElSimpleFTPSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_InternalValidate(TElSimpleFTPSClientHandle _Handle, TSBCertificateValidityRaw * Validity, TSBCertificateValidityReasonRaw * Reason);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_EstablishSSLSession(TElSimpleFTPSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Login(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_MakeDir(TElSimpleFTPSClientHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_MountStruct(TElSimpleFTPSClientHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Receive(TElSimpleFTPSClientHandle _Handle, const char * pcFilename, int32_t szFilename, int64_t StartPos, int64_t EndPos);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Receive_1(TElSimpleFTPSClientHandle _Handle, const char * pcFilename, int32_t szFilename, TStreamHandle Stream, int64_t StartPos, int64_t EndPos);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Reinitialize(TElSimpleFTPSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_RemoveDir(TElSimpleFTPSClientHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Rename(TElSimpleFTPSClientHandle _Handle, const char * pcSourceFile, int32_t szSourceFile, const char * pcDestFile, int32_t szDestFile);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_RenegotiateCiphers(TElSimpleFTPSClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_SendCmd(TElSimpleFTPSClientHandle _Handle, const char * pcCommand, int32_t szCommand, const int16_t pAcceptCodes[], int32_t szAcceptCodes, int16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_SendCmd_1(TElSimpleFTPSClientHandle _Handle, const char * pcCommand, int32_t szCommand, const int16_t pAcceptCodes[], int32_t szAcceptCodes, const int16_t pIntermediateAcceptCodes[], int32_t szIntermediateAcceptCodes, int16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Send(TElSimpleFTPSClientHandle _Handle, TStreamHandle Stream, const char * pcFileName, int32_t szFileName, int64_t StartPos, int64_t EndPos, int8_t Append, int64_t RestartFrom);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Send_1(TElSimpleFTPSClientHandle _Handle, TStreamHandle Stream, const char * pcFileName, int32_t szFileName, int64_t RestartFrom);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Send_2(TElSimpleFTPSClientHandle _Handle, TStreamHandle Stream, const char * pcFileName, int32_t szFileName);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_DownloadFile(TElSimpleFTPSClientHandle _Handle, const char * pcRemoteFileName, int32_t szRemoteFileName, const char * pcLocalFileName, int32_t szLocalFileName);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_DownloadFile_1(TElSimpleFTPSClientHandle _Handle, const char * pcRemoteFileName, int32_t szRemoteFileName, const char * pcLocalFileName, int32_t szLocalFileName, TSBFileTransferModeRaw Mode);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_DownloadFile_2(TElSimpleFTPSClientHandle _Handle, const char * pcRemoteFileName, int32_t szRemoteFileName, const char * pcLocalFileName, int32_t szLocalFileName, TSBFileTransferModeRaw Mode, int64_t RestartFrom);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_UploadFile(TElSimpleFTPSClientHandle _Handle, const char * pcLocalFileName, int32_t szLocalFileName, const char * pcRemoteFileName, int32_t szRemoteFileName);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_UploadFile_1(TElSimpleFTPSClientHandle _Handle, const char * pcLocalFileName, int32_t szLocalFileName, const char * pcRemoteFileName, int32_t szRemoteFileName, TSBFileTransferModeRaw Mode);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_UploadFile_2(TElSimpleFTPSClientHandle _Handle, const char * pcLocalFileName, int32_t szLocalFileName, const char * pcRemoteFileName, int32_t szRemoteFileName, TSBFileTransferModeRaw Mode, int64_t RestartFrom);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_DownloadStream(TElSimpleFTPSClientHandle _Handle, const char * pcRemoteFileName, int32_t szRemoteFileName, TStreamHandle LocalStream, TSBFileTransferModeRaw Mode, int64_t RestartFrom);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_UploadStream(TElSimpleFTPSClientHandle _Handle, TStreamHandle LocalStream, const char * pcRemoteFileName, int32_t szRemoteFileName, TSBFileTransferModeRaw Mode, int64_t RestartFrom);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_DownloadFiles(TElSimpleFTPSClientHandle _Handle, const char * pcRemotePath, int32_t szRemotePath, const char * pcRemoteMask, int32_t szRemoteMask, const char * pcLocalPath, int32_t szLocalPath, TSBFileTransferModeRaw Mode, int8_t CaseSensitive, TSBCaseConversionRaw CaseConversion, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_DownloadFiles_1(TElSimpleFTPSClientHandle _Handle, const char * pcRemotePath, int32_t szRemotePath, const char * pcRemoteMask, int32_t szRemoteMask, const char * pcLocalPath, int32_t szLocalPath, TSBFileTransferModeRaw Mode, TSBFileCopyModeRaw CopyMode, int8_t CaseSensitive, TSBCaseConversionRaw CaseConversion, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_UploadFiles(TElSimpleFTPSClientHandle _Handle, const char * pcLocalPath, int32_t szLocalPath, const char * pcLocalMask, int32_t szLocalMask, const char * pcRemotePath, int32_t szRemotePath, TSBFileTransferModeRaw Mode, int8_t CaseSensitive, TSBCaseConversionRaw CaseConversion, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_UploadFiles_1(TElSimpleFTPSClientHandle _Handle, const char * pcLocalPath, int32_t szLocalPath, const char * pcLocalMask, int32_t szLocalMask, const char * pcRemotePath, int32_t szRemotePath, TSBFileTransferModeRaw Mode, TSBFileCopyModeRaw CopyMode, int8_t CaseSensitive, TSBCaseConversionRaw CaseConversion, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_RemoveFile(TElSimpleFTPSClientHandle _Handle, const char * pcFilename, int32_t szFilename);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_RemoveFiles(TElSimpleFTPSClientHandle _Handle, const char * pcPath, int32_t szPath, const char * pcMask, int32_t szMask, int8_t CaseSensitive, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_RemoveFiles_1(TElSimpleFTPSClientHandle _Handle, TStringsHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_CipherSuite(TElSimpleFTPSClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_CompressionAlgorithm(TElSimpleFTPSClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_CipherSuites(TElSimpleFTPSClientHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_CipherSuites(TElSimpleFTPSClientHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_CipherSuitePriorities(TElSimpleFTPSClientHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_CipherSuitePriorities(TElSimpleFTPSClientHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_CompressionAlgorithms(TElSimpleFTPSClientHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_CompressionAlgorithms(TElSimpleFTPSClientHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_Version(TElSimpleFTPSClientHandle _Handle, TSBVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_Active(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_LastReceivedReply(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ModeZSupported(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ExtMLSTSupported(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ExtMDTMSupported(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ExtMFMTSupported(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ExtSIZESupported(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ExtRESTSupported(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ExtXCRCSupported(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ExtXMD5Supported(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ExtXSHA1Supported(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ExtOPTSUTF8Supported(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ExtHOSTSupported(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_LocalNewLineConvention(TElSimpleFTPSClientHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_LocalNewLineConvention(TElSimpleFTPSClientHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_UsingIPv6(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_WebTunnelResult(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_RemoteHost(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_RemoteIP(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_TotalBytesSent(TElSimpleFTPSClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_TotalBytesReceived(TElSimpleFTPSClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_TotalDataBytesSent(TElSimpleFTPSClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_TotalDataBytesReceived(TElSimpleFTPSClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_Socket(TElSimpleFTPSClientHandle _Handle, TElSocketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_DataSocket(TElSimpleFTPSClientHandle _Handle, TElSocketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_Address(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_Address(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_AuthCmd(TElSimpleFTPSClientHandle _Handle, TSBFTPAuthCmdRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_AuthCmd(TElSimpleFTPSClientHandle _Handle, TSBFTPAuthCmdRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_Port(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_Port(TElSimpleFTPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_Username(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_Username(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_Password(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_Password(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_VirtualHostName(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_VirtualHostName(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_AccountInfo(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_AccountInfo(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_PassiveMode(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_PassiveMode(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_SRPUsername(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_SRPUsername(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_SRPPassword(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_SRPPassword(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_TransferType(TElSimpleFTPSClientHandle _Handle, TSBFTPTransferTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_TransferType(TElSimpleFTPSClientHandle _Handle, TSBFTPTransferTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_UseIPv6(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_UseIPv6(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_UseSSL(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_UseSSL(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ModeZ(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_ModeZ(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ModeZLevel(TElSimpleFTPSClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_ModeZLevel(TElSimpleFTPSClientHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_Versions(TElSimpleFTPSClientHandle _Handle, TSBVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_Versions(TElSimpleFTPSClientHandle _Handle, TSBVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_CertStorage(TElSimpleFTPSClientHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_CertStorage(TElSimpleFTPSClientHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ClientCertStorage(TElSimpleFTPSClientHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_ClientCertStorage(TElSimpleFTPSClientHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_SSLMode(TElSimpleFTPSClientHandle _Handle, TSBSSLModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_SSLMode(TElSimpleFTPSClientHandle _Handle, TSBSSLModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_EncryptDataChannel(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_EncryptDataChannel(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_FTPBufferSize(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_FTPBufferSize(TElSimpleFTPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_FTPTextBufferSize(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_FTPTextBufferSize(TElSimpleFTPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_FTPWriteBufferSize(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_FTPWriteBufferSize(TElSimpleFTPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ProxySettings(TElSimpleFTPSClientHandle _Handle, TElFTPProxySettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_ProxySettings(TElSimpleFTPSClientHandle _Handle, TElFTPProxySettingsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_SocketSettings(TElSimpleFTPSClientHandle _Handle, TElSocketSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_SocketTimeout(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_SocketTimeout(TElSimpleFTPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_TransferTimeout(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_TransferTimeout(TElSimpleFTPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_CtlPollInterval(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_CtlPollInterval(TElSimpleFTPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_Extensions(TElSimpleFTPSClientHandle _Handle, TElClientSSLExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_PeerExtensions(TElSimpleFTPSClientHandle _Handle, TElCustomSSLExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_CommandSocketBinding(TElSimpleFTPSClientHandle _Handle, TElClientSocketBindingHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_CommandSocketBinding(TElSimpleFTPSClientHandle _Handle, TElClientSocketBindingHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_DataSocketBinding(TElSimpleFTPSClientHandle _Handle, TElClientSocketBindingHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_DataSocketBinding(TElSimpleFTPSClientHandle _Handle, TElClientSocketBindingHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_FileSystemAdapter(TElSimpleFTPSClientHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_FileSystemAdapter(TElSimpleFTPSClientHandle _Handle, TElCustomFileSystemAdapterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_PortKnock(TElSimpleFTPSClientHandle _Handle, TElPortKnockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_PortKnock(TElSimpleFTPSClientHandle _Handle, TElPortKnockHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_TransferKeepAliveInterval(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_TransferKeepAliveInterval(TElSimpleFTPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ListenTimeout(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_ListenTimeout(TElSimpleFTPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_UseSIZECmd(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_UseSIZECmd(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_UseFEATCmd(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_UseFEATCmd(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_AdjustPasvAddress(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_AdjustPasvAddress(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_UseSSLSessionResumption(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_UseSSLSessionResumption(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_RenegotiationAttackPreventionMode(TElSimpleFTPSClientHandle _Handle, TSBRenegotiationAttackPreventionModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_RenegotiationAttackPreventionMode(TElSimpleFTPSClientHandle _Handle, TSBRenegotiationAttackPreventionModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_IncomingSpeedLimit(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_IncomingSpeedLimit(TElSimpleFTPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OutgoingSpeedLimit(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OutgoingSpeedLimit(TElSimpleFTPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_ConcurrentConnections(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_ConcurrentConnections(TElSimpleFTPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_MinSizeForConcurrentDownload(TElSimpleFTPSClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_MinSizeForConcurrentDownload(TElSimpleFTPSClientHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_Options(TElSimpleFTPSClientHandle _Handle, TSBFTPOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_Options(TElSimpleFTPSClientHandle _Handle, TSBFTPOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_SSLOptions(TElSimpleFTPSClientHandle _Handle, TSBSSLOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_SSLOptions(TElSimpleFTPSClientHandle _Handle, TSBSSLOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_QuoteParameters(TElSimpleFTPSClientHandle _Handle, TSBParamQuoteModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_QuoteParameters(TElSimpleFTPSClientHandle _Handle, TSBParamQuoteModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_QuoteParamChar(TElSimpleFTPSClientHandle _Handle, char * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_QuoteParamChar(TElSimpleFTPSClientHandle _Handle, char Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_SocksAuthentication(TElSimpleFTPSClientHandle _Handle, TElSocksAuthenticationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_SocksAuthentication(TElSimpleFTPSClientHandle _Handle, TElSocksAuthenticationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_SocksPassword(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_SocksPassword(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_SocksPort(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_SocksPort(TElSimpleFTPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_SocksResolveAddress(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_SocksResolveAddress(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_SocksServer(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_SocksServer(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_SocksUserCode(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_SocksUserCode(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_SocksVersion(TElSimpleFTPSClientHandle _Handle, TElSocksVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_SocksVersion(TElSimpleFTPSClientHandle _Handle, TElSocksVersionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_SocksUseIPv6(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_SocksUseIPv6(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_UseSocks(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_UseSocks(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_UseWebTunneling(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_UseWebTunneling(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_WebTunnelAddress(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_WebTunnelAddress(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_WebTunnelAuthentication(TElSimpleFTPSClientHandle _Handle, TElWebTunnelAuthenticationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_WebTunnelAuthentication(TElSimpleFTPSClientHandle _Handle, TElWebTunnelAuthenticationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_WebTunnelPassword(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_WebTunnelPassword(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_WebTunnelPort(TElSimpleFTPSClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_WebTunnelPort(TElSimpleFTPSClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_WebTunnelUserId(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_WebTunnelUserId(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_WebTunnelRequestHeaders(TElSimpleFTPSClientHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_WebTunnelResponseHeaders(TElSimpleFTPSClientHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_WebTunnelResponseBody(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_UseProxySettingsForDataChannel(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_UseProxySettingsForDataChannel(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_PreserveExistingFileTimes(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_PreserveExistingFileTimes(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_CopyEmptyDirs(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_CopyEmptyDirs(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_DeleteFailedDownloads(TElSimpleFTPSClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_DeleteFailedDownloads(TElSimpleFTPSClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_RemoteCharset(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_RemoteCharset(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_LocalCharset(TElSimpleFTPSClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_LocalCharset(TElSimpleFTPSClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_DNS(TElSimpleFTPSClientHandle _Handle, TElDNSSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_DNS(TElSimpleFTPSClientHandle _Handle, TElDNSSettingsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OperationErrorHandling(TElSimpleFTPSClientHandle _Handle, TSBOperationErrorHandlingRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OperationErrorHandling(TElSimpleFTPSClientHandle _Handle, TSBOperationErrorHandlingRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnTextDataLine(TElSimpleFTPSClientHandle _Handle, TSBFTPSTextDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnTextDataLine(TElSimpleFTPSClientHandle _Handle, TSBFTPSTextDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnBinaryData(TElSimpleFTPSClientHandle _Handle, TSBFTPSBinaryDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnBinaryData(TElSimpleFTPSClientHandle _Handle, TSBFTPSBinaryDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnCertificateValidate(TElSimpleFTPSClientHandle _Handle, TSBCertificateValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnCertificateValidate(TElSimpleFTPSClientHandle _Handle, TSBCertificateValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnCertificateNeededEx(TElSimpleFTPSClientHandle _Handle, TSBCertificateNeededExEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnCertificateNeededEx(TElSimpleFTPSClientHandle _Handle, TSBCertificateNeededExEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnCiphersNegotiated(TElSimpleFTPSClientHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnCiphersNegotiated(TElSimpleFTPSClientHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnSSLError(TElSimpleFTPSClientHandle _Handle, TSBErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnSSLError(TElSimpleFTPSClientHandle _Handle, TSBErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnCertificateStatus(TElSimpleFTPSClientHandle _Handle, TSBCertificateStatusEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnCertificateStatus(TElSimpleFTPSClientHandle _Handle, TSBCertificateStatusEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnExtensionsReceived(TElSimpleFTPSClientHandle _Handle, TSBExtensionsReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnExtensionsReceived(TElSimpleFTPSClientHandle _Handle, TSBExtensionsReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnExtensionsPrepared(TElSimpleFTPSClientHandle _Handle, TSBExtensionsPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnExtensionsPrepared(TElSimpleFTPSClientHandle _Handle, TSBExtensionsPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnKeyNeeded(TElSimpleFTPSClientHandle _Handle, TSBClientKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnKeyNeeded(TElSimpleFTPSClientHandle _Handle, TSBClientKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnRenegotiationRequest(TElSimpleFTPSClientHandle _Handle, TSBFTPSRenegotiationRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnRenegotiationRequest(TElSimpleFTPSClientHandle _Handle, TSBFTPSRenegotiationRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnProgress(TElSimpleFTPSClientHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnProgress(TElSimpleFTPSClientHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnControlSend(TElSimpleFTPSClientHandle _Handle, TSBFTPSTextDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnControlSend(TElSimpleFTPSClientHandle _Handle, TSBFTPSTextDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnControlReceive(TElSimpleFTPSClientHandle _Handle, TSBFTPSTextDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnControlReceive(TElSimpleFTPSClientHandle _Handle, TSBFTPSTextDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnInnerClientCreated(TElSimpleFTPSClientHandle _Handle, TSBFTPSInnerClientEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnInnerClientCreated(TElSimpleFTPSClientHandle _Handle, TSBFTPSInnerClientEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnInnerClientLoggedIn(TElSimpleFTPSClientHandle _Handle, TSBFTPSInnerClientEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnInnerClientLoggedIn(TElSimpleFTPSClientHandle _Handle, TSBFTPSInnerClientEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnInnerClientDestroyed(TElSimpleFTPSClientHandle _Handle, TSBFTPSInnerClientEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnInnerClientDestroyed(TElSimpleFTPSClientHandle _Handle, TSBFTPSInnerClientEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnDNSKeyNeeded(TElSimpleFTPSClientHandle _Handle, TSBDNSKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnDNSKeyNeeded(TElSimpleFTPSClientHandle _Handle, TSBDNSKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnDNSKeyValidate(TElSimpleFTPSClientHandle _Handle, TSBDNSKeyValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnDNSKeyValidate(TElSimpleFTPSClientHandle _Handle, TSBDNSKeyValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnDNSResolve(TElSimpleFTPSClientHandle _Handle, TSBDNSResolveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnDNSResolve(TElSimpleFTPSClientHandle _Handle, TSBDNSResolveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnFileOperation(TElSimpleFTPSClientHandle _Handle, TElFTPFileOperationEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnFileOperation(TElSimpleFTPSClientHandle _Handle, TElFTPFileOperationEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnFileOperationResult(TElSimpleFTPSClientHandle _Handle, TElFTPFileOperationResultEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnFileOperationResult(TElSimpleFTPSClientHandle _Handle, TElFTPFileOperationResultEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnFileNameChangeNeeded(TElSimpleFTPSClientHandle _Handle, TSBFTPSFileNameChangeNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnFileNameChangeNeeded(TElSimpleFTPSClientHandle _Handle, TSBFTPSFileNameChangeNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnBeforeParseFileListEntry(TElSimpleFTPSClientHandle _Handle, TSBFTPSBeforeParseFileListEntry * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnBeforeParseFileListEntry(TElSimpleFTPSClientHandle _Handle, TSBFTPSBeforeParseFileListEntry pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_get_OnAfterParseFileListEntry(TElSimpleFTPSClientHandle _Handle, TSBFTPSAfterParseFileListEntry * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_set_OnAfterParseFileListEntry(TElSimpleFTPSClientHandle _Handle, TSBFTPSAfterParseFileListEntry pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSClient_Create(TComponentHandle AOwner, TElSimpleFTPSClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLEFTPSCLIENT */

#ifdef SB_USE_CLASS_TELFTPFILEINFO
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_Assign(TElFTPFileInfoHandle _Handle, TElFTPFileInfoHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_Assign_1(TElFTPFileInfoHandle _Handle, TSBFTPFileInfo * Source);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_get_FileDate(TElFTPFileInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_set_FileDate(TElFTPFileInfoHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_get_FileType(TElFTPFileInfoHandle _Handle, TSBFileEntryTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_set_FileType(TElFTPFileInfoHandle _Handle, TSBFileEntryTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_get_Name(TElFTPFileInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_set_Name(TElFTPFileInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_get_Path(TElFTPFileInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_set_Path(TElFTPFileInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_get_Size(TElFTPFileInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_set_Size(TElFTPFileInfoHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_get_EntryFormat(TElFTPFileInfoHandle _Handle, TSBFileEntryFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_set_EntryFormat(TElFTPFileInfoHandle _Handle, TSBFileEntryFormatRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_get_RawData(TElFTPFileInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_set_RawData(TElFTPFileInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElFTPFileInfo_Create(TElFTPFileInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELFTPFILEINFO */

#ifdef SB_USE_CLASS_TELFTPPROXYSETTINGS
SB_IMPORT uint32_t SB_APIENTRY TElFTPProxySettings_Assign(TElFTPProxySettingsHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElFTPProxySettings_get_Host(TElFTPProxySettingsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFTPProxySettings_set_Host(TElFTPProxySettingsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElFTPProxySettings_get_Password(TElFTPProxySettingsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFTPProxySettings_set_Password(TElFTPProxySettingsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElFTPProxySettings_get_Port(TElFTPProxySettingsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFTPProxySettings_set_Port(TElFTPProxySettingsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElFTPProxySettings_get_ProxyType(TElFTPProxySettingsHandle _Handle, TSBFTPProxyTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFTPProxySettings_set_ProxyType(TElFTPProxySettingsHandle _Handle, TSBFTPProxyTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElFTPProxySettings_get_Username(TElFTPProxySettingsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFTPProxySettings_set_Username(TElFTPProxySettingsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElFTPProxySettings_Create(TElFTPProxySettingsHandle * OutResult);
#endif /* SB_USE_CLASS_TELFTPPROXYSETTINGS */

#ifdef SB_USE_CLASS_TELFTPSTRANSFERMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElFTPSTransferManager_Execute(TElFTPSTransferManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElFTPSTransferManager_Create(TElSimpleFTPSClientHandle Owner, const char * pcFilename, int32_t szFilename, const char * pcDir, int32_t szDir, TStreamHandle Stream, int64_t StartPos, int64_t EndPos, TElFTPSTransferManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELFTPSTRANSFERMANAGER */

#ifdef SB_USE_CLASS_TELMULTIPARTSTREAMACCESS
SB_IMPORT uint32_t SB_APIENTRY TElMultipartStreamAccess_AcquirePart(TElMultipartStreamAccessHandle _Handle, int64_t StartPos, int64_t Size, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartStreamAccess_ReleasePart(TElMultipartStreamAccessHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartStreamAccess_Create(TStreamHandle Stream, int64_t Size, TElMultipartStreamAccessHandle * OutResult);
#endif /* SB_USE_CLASS_TELMULTIPARTSTREAMACCESS */

#ifdef SB_USE_CLASS_TELFTPSTRANSFERCHUNK
SB_IMPORT uint32_t SB_APIENTRY TElFTPSTransferChunk_Run(TElFTPSTransferChunkHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElFTPSTransferChunk_Create(const char * pcFilename, int32_t szFilename, const char * pcDir, int32_t szDir, int64_t StartPos, int64_t EndPos, TElSimpleFTPSClientHandle Client, int8_t CreateCopy, TElMultipartStreamAccessHandle StreamAccess, TElFTPSTransferChunkHandle * OutResult);
#endif /* SB_USE_CLASS_TELFTPSTRANSFERCHUNK */

#ifdef SB_USE_CLASS_TELMULTIPARTSTREAMPART
SB_IMPORT uint32_t SB_APIENTRY TElMultipartStreamPart_Read(TElMultipartStreamPartHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartStreamPart_Write(TElMultipartStreamPartHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartStreamPart_Seek(TElMultipartStreamPartHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartStreamPart_Seek_1(TElMultipartStreamPartHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultipartStreamPart_Create(TElMultipartStreamAccessHandle Owner, TStreamHandle BaseStream, int64_t BaseSize, int64_t StartPos, int64_t Size, TElMultipartStreamPartHandle * OutResult);
#endif /* SB_USE_CLASS_TELMULTIPARTSTREAMPART */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TSBFTPFileInfo_ce_ptr;
extern zend_class_entry *TElSimpleFTPSClient_ce_ptr;
extern zend_class_entry *TElFTPFileInfo_ce_ptr;
extern zend_class_entry *TElFTPProxySettings_ce_ptr;
extern zend_class_entry *TElFTPSTransferManager_ce_ptr;
extern zend_class_entry *TElMultipartStreamAccess_ce_ptr;
extern zend_class_entry *TElFTPSTransferChunk_ce_ptr;
extern zend_class_entry *TElMultipartStreamPart_ce_ptr;

void SB_CALLBACK TSBFTPSTextDataEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pTextLine[], int32_t szTextLine);
void SB_CALLBACK TSBFTPSBinaryDataEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pData[], int32_t szData);
void SB_CALLBACK TSBFTPSInnerClientEventRaw(void * _ObjectData, TObjectHandle Sender, TElSimpleFTPSClientHandle Client);
void SB_CALLBACK TSBFTPSRenegotiationRequestEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t DataChannel, int8_t * Allow);
void SB_CALLBACK TElFTPFileOperationEventRaw(void * _ObjectData, TObjectHandle Sender, TSBFtpFileOperationRaw Operation, const char * pcRemotePath, int32_t szRemotePath, const char * pcLocalPath, int32_t szLocalPath, int8_t * Skip, int8_t * Cancel);
void SB_CALLBACK TElFTPFileOperationResultEventRaw(void * _ObjectData, TObjectHandle Sender, TSBFtpFileOperationRaw Operation, const char * pcRemotePath, int32_t szRemotePath, const char * pcLocalPath, int32_t szLocalPath, int32_t ErrorCode, const char * pcComment, int32_t szComment, int8_t * Cancel);
void SB_CALLBACK TSBFTPSFileNameChangeNeededEventRaw(void * _ObjectData, TObjectHandle Sender, char * pcFileName, int32_t * szFileName, int8_t * Force);
void Register_TSBFTPFileInfo(TSRMLS_D);
void SB_CALLBACK TSBFTPSBeforeParseFileListEntryRaw(void * _ObjectData, TObjectHandle Sender, const char * pcEntry, int32_t szEntry, TElFTPFileInfoHandle FileInfo, int8_t * Handled);
void SB_CALLBACK TSBFTPSAfterParseFileListEntryRaw(void * _ObjectData, TObjectHandle Sender, const char * pcEntry, int32_t szEntry, TElFTPFileInfoHandle FileInfo, int8_t * Success);
void Register_TElSimpleFTPSClient(TSRMLS_D);
void Register_TElFTPFileInfo(TSRMLS_D);
void Register_TElFTPProxySettings(TSRMLS_D);
void Register_TElFTPSTransferManager(TSRMLS_D);
void Register_TElMultipartStreamAccess(TSRMLS_D);
void Register_TElFTPSTransferChunk(TSRMLS_D);
void Register_TElMultipartStreamPart(TSRMLS_D);
void Register_SBSimpleFTPS_Constants(int module_number TSRMLS_DC);
void Register_SBSimpleFTPS_Enum_Flags(TSRMLS_D);
void Register_SBSimpleFTPS_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSIMPLEFTPS */

