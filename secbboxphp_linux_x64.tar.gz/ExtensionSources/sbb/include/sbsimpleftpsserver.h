#ifndef __INC_SBSIMPLEFTPSSERVER
#define __INC_SBSIMPLEFTPSSERVER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcustomfsadapter.h"
#include "sbdiskfsadapter.h"
#include "sbsharedresource.h"
#include "sbcustomcertstorage.h"
#include "sbftpscommon.h"
#include "sbftpsserver.h"
#include "sbsslconstants.h"
#include "sbsslcommon.h"
#include "sbsslserver.h"
#include "sbsessionpool.h"
#include "sbtimer.h"
#include "sbsocket.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbusers.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSimpleFTPSServerSessionThreadHandle;

typedef TElClassHandle TElSimpleFTPSServerHandle;

typedef TElClassHandle TElSimpleFTPSServerListeningThreadHandle;

typedef TElSimpleFTPSServerListeningThreadHandle ElSimpleFTPSServerListeningThreadHandle;

typedef TElClassHandle TElFTPSUsersHandle;

typedef TElSimpleFTPSServerSessionThreadHandle ElSimpleFTPSServerSessionThreadHandle;

typedef TElSimpleFTPSServerHandle ElSimpleFTPSServerHandle;

typedef void (SB_CALLBACK *TSBSimpleFTPSServerNewConnectionEvent)(void * _ObjectData, TObjectHandle Sender, TElSimpleFTPSServerSessionThreadHandle Session);

typedef void (SB_CALLBACK *TSBSimpleFTPSServerCloseConnectionEvent)(void * _ObjectData, TObjectHandle Sender, TElSimpleFTPSServerSessionThreadHandle Session);

typedef void (SB_CALLBACK *TSBFTPSServerExceptionEvent)(void * _ObjectData, TObjectHandle Sender, TElClassHandle Ex);

typedef void (SB_CALLBACK *TSBSimpleFTPSListenerNewConnectionEvent)(void * _ObjectData, TObjectHandle Sender, TElSocketHandle Socket, int8_t * Reject);

typedef void (SB_CALLBACK *TSBSimpleFTPSServerBeforeNewConnectionEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcRemoteIP, int32_t szRemoteIP, int32_t RemotePort, int8_t * Reject);

typedef void (SB_CALLBACK *TSBSimpleFTPSServerAuthAttemptEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, const char * pcPassword, int32_t szPassword, int8_t * Allow);

#ifdef SB_USE_CLASS_TELSIMPLEFTPSSERVERSESSIONTHREAD
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_Socket(TElSimpleFTPSServerSessionThreadHandle _Handle, TElSocketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_FTPSServer(TElSimpleFTPSServerSessionThreadHandle _Handle, TElFTPSServerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_ListenAddress(TElSimpleFTPSServerSessionThreadHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_ListenAddress(TElSimpleFTPSServerSessionThreadHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_PassiveModeAddress(TElSimpleFTPSServerSessionThreadHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_PassiveModeAddress(TElSimpleFTPSServerSessionThreadHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_SessionTimeout(TElSimpleFTPSServerSessionThreadHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_SessionTimeout(TElSimpleFTPSServerSessionThreadHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_HandshakeTimeout(TElSimpleFTPSServerSessionThreadHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_HandshakeTimeout(TElSimpleFTPSServerSessionThreadHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_SocketTimeout(TElSimpleFTPSServerSessionThreadHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_SocketTimeout(TElSimpleFTPSServerSessionThreadHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_IncomingSpeedLimit(TElSimpleFTPSServerSessionThreadHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_IncomingSpeedLimit(TElSimpleFTPSServerSessionThreadHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_OutgoingSpeedLimit(TElSimpleFTPSServerSessionThreadHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_OutgoingSpeedLimit(TElSimpleFTPSServerSessionThreadHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_DataPortRangeFrom(TElSimpleFTPSServerSessionThreadHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_DataPortRangeFrom(TElSimpleFTPSServerSessionThreadHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_DataPortRangeTo(TElSimpleFTPSServerSessionThreadHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_DataPortRangeTo(TElSimpleFTPSServerSessionThreadHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_AllowAnonymous(TElSimpleFTPSServerSessionThreadHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_AllowAnonymous(TElSimpleFTPSServerSessionThreadHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_RootDirectory(TElSimpleFTPSServerSessionThreadHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_RootDirectory(TElSimpleFTPSServerSessionThreadHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_CurrentDirectory(TElSimpleFTPSServerSessionThreadHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_CurrentDirectory(TElSimpleFTPSServerSessionThreadHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_AnonymousLogin(TElSimpleFTPSServerSessionThreadHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_DataConnectionOpened(TElSimpleFTPSServerSessionThreadHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_FileSystemAdapter(TElSimpleFTPSServerSessionThreadHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_FileSystemAdapter(TElSimpleFTPSServerSessionThreadHandle _Handle, TElCustomFileSystemAdapterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_ReleaseFileSystemAdapter(TElSimpleFTPSServerSessionThreadHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_ReleaseFileSystemAdapter(TElSimpleFTPSServerSessionThreadHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_OutgoingLocalBinding(TElSimpleFTPSServerSessionThreadHandle _Handle, TElClientSocketBindingHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_OutgoingLocalBinding(TElSimpleFTPSServerSessionThreadHandle _Handle, TElClientSocketBindingHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_Executed(TElSimpleFTPSServerSessionThreadHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_OnAuthAttempt(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBSimpleFTPSServerAuthAttemptEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_OnAuthAttempt(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBSimpleFTPSServerAuthAttemptEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_OnCommandReceived(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerCommandReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_OnCommandReceived(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerCommandReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_OnBeforeSendReply(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerBeforeSendReplyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_OnBeforeSendReply(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerBeforeSendReplyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_OnCommandProcessed(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerCommandProcessedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_OnCommandProcessed(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerCommandProcessedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_OnTransferProgress(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerTransferProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_OnTransferProgress(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerTransferProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_OnTransferCompleted(TElSimpleFTPSServerSessionThreadHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_OnTransferCompleted(TElSimpleFTPSServerSessionThreadHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_OnClose(TElSimpleFTPSServerSessionThreadHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_OnClose(TElSimpleFTPSServerSessionThreadHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_OnException(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerExceptionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_OnException(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerExceptionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_OnCommandUnhandled(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerCommandUnhandledEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_OnCommandUnhandled(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerCommandUnhandledEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_OnSiteCommand(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerSiteCommandEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_OnSiteCommand(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerSiteCommandEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_get_OnFileAllocate(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerFileAllocateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_set_OnFileAllocate(TElSimpleFTPSServerSessionThreadHandle _Handle, TSBFTPSServerFileAllocateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerSessionThread_Create(TElSocketHandle Socket, TElSimpleFTPSServerSessionThreadHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLEFTPSSERVERSESSIONTHREAD */

#ifdef SB_USE_CLASS_TELSIMPLEFTPSSERVER
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_Start(TElSimpleFTPSServerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_Stop(TElSimpleFTPSServerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_AssignTLSParamsFromTemplate(TElSimpleFTPSServerHandle _Handle, TElSSLServerHandle Tpl);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_ConfigureTLS(TElSimpleFTPSServerHandle _Handle, TSBServerSSLPredefinedConfigurationRaw Configuration);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_Active(TElSimpleFTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_MessageTable(TElSimpleFTPSServerHandle _Handle, TElFTPSServerMessageTableHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OutgoingLocalBinding(TElSimpleFTPSServerHandle _Handle, TElClientSocketBindingHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OutgoingLocalBinding(TElSimpleFTPSServerHandle _Handle, TElClientSocketBindingHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_SocketSettings(TElSimpleFTPSServerHandle _Handle, TElSocketSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_CipherSuites(TElSimpleFTPSServerHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_CipherSuites(TElSimpleFTPSServerHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_CipherSuitePriorities(TElSimpleFTPSServerHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_CipherSuitePriorities(TElSimpleFTPSServerHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_CompressionAlgorithms(TElSimpleFTPSServerHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_CompressionAlgorithms(TElSimpleFTPSServerHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_Versions(TElSimpleFTPSServerHandle _Handle, TSBVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_Versions(TElSimpleFTPSServerHandle _Handle, TSBVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_ClientAuthentication(TElSimpleFTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_ClientAuthentication(TElSimpleFTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_AuthenticationLevel(TElSimpleFTPSServerHandle _Handle, TSBAuthenticationLevelRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_AuthenticationLevel(TElSimpleFTPSServerHandle _Handle, TSBAuthenticationLevelRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_ForceCertificateChain(TElSimpleFTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_ForceCertificateChain(TElSimpleFTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_CertStorage(TElSimpleFTPSServerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_CertStorage(TElSimpleFTPSServerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_SessionPool(TElSimpleFTPSServerHandle _Handle, TElSessionPoolHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_SessionPool(TElSimpleFTPSServerHandle _Handle, TElSessionPoolHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_ClientCertStorage(TElSimpleFTPSServerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_ClientCertStorage(TElSimpleFTPSServerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_Host(TElSimpleFTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_Host(TElSimpleFTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_PassiveModeHost(TElSimpleFTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_PassiveModeHost(TElSimpleFTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_DataHost(TElSimpleFTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_DataHost(TElSimpleFTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_Port(TElSimpleFTPSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_Port(TElSimpleFTPSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_DataPortRangeFrom(TElSimpleFTPSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_DataPortRangeFrom(TElSimpleFTPSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_DataPortRangeTo(TElSimpleFTPSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_DataPortRangeTo(TElSimpleFTPSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_UseIPv6(TElSimpleFTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_UseIPv6(TElSimpleFTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_SessionTimeout(TElSimpleFTPSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_SessionTimeout(TElSimpleFTPSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_HandshakeTimeout(TElSimpleFTPSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_HandshakeTimeout(TElSimpleFTPSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_RootDirectory(TElSimpleFTPSServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_RootDirectory(TElSimpleFTPSServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_ReadOnly(TElSimpleFTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_ReadOnly(TElSimpleFTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_IncomingSpeedLimit(TElSimpleFTPSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_IncomingSpeedLimit(TElSimpleFTPSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OutgoingSpeedLimit(TElSimpleFTPSServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OutgoingSpeedLimit(TElSimpleFTPSServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_FileSystemAdapter(TElSimpleFTPSServerHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_FileSystemAdapter(TElSimpleFTPSServerHandle _Handle, TElCustomFileSystemAdapterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_AllowAnonymous(TElSimpleFTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_AllowAnonymous(TElSimpleFTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_ImplicitSSL(TElSimpleFTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_ImplicitSSL(TElSimpleFTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_UseUTF8(TElSimpleFTPSServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_UseUTF8(TElSimpleFTPSServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_Users(TElSimpleFTPSServerHandle _Handle, TElFTPSUsersHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OnBeforeNewConnection(TElSimpleFTPSServerHandle _Handle, TSBSimpleFTPSServerBeforeNewConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OnBeforeNewConnection(TElSimpleFTPSServerHandle _Handle, TSBSimpleFTPSServerBeforeNewConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OnNewConnection(TElSimpleFTPSServerHandle _Handle, TSBSimpleFTPSServerNewConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OnNewConnection(TElSimpleFTPSServerHandle _Handle, TSBSimpleFTPSServerNewConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OnCloseConnection(TElSimpleFTPSServerHandle _Handle, TSBSimpleFTPSServerCloseConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OnCloseConnection(TElSimpleFTPSServerHandle _Handle, TSBSimpleFTPSServerCloseConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OnAuthAttempt(TElSimpleFTPSServerHandle _Handle, TSBSimpleFTPSServerAuthAttemptEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OnAuthAttempt(TElSimpleFTPSServerHandle _Handle, TSBSimpleFTPSServerAuthAttemptEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OnCommandReceived(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerCommandReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OnCommandReceived(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerCommandReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OnBeforeSendReply(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerBeforeSendReplyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OnBeforeSendReply(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerBeforeSendReplyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OnCommandProcessed(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerCommandProcessedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OnCommandProcessed(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerCommandProcessedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OnTransferProgress(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerTransferProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OnTransferProgress(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerTransferProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OnTransferCompleted(TElSimpleFTPSServerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OnTransferCompleted(TElSimpleFTPSServerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OnSessionException(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerExceptionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OnSessionException(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerExceptionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OnCommandUnhandled(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerCommandUnhandledEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OnCommandUnhandled(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerCommandUnhandledEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OnSiteCommand(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerSiteCommandEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OnSiteCommand(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerSiteCommandEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_get_OnFileAllocate(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerFileAllocateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_set_OnFileAllocate(TElSimpleFTPSServerHandle _Handle, TSBFTPSServerFileAllocateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServer_Create(TComponentHandle AOwner, TElSimpleFTPSServerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLEFTPSSERVER */

#ifdef SB_USE_CLASS_TELSIMPLEFTPSSERVERLISTENINGTHREAD
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerListeningThread_get_Socket(TElSimpleFTPSServerListeningThreadHandle _Handle, TElSocketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerListeningThread_set_Socket(TElSimpleFTPSServerListeningThreadHandle _Handle, TElSocketHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerListeningThread_get_OnNewConnection(TElSimpleFTPSServerListeningThreadHandle _Handle, TSBSimpleFTPSListenerNewConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerListeningThread_set_OnNewConnection(TElSimpleFTPSServerListeningThreadHandle _Handle, TSBSimpleFTPSListenerNewConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerListeningThread_get_OnClose(TElSimpleFTPSServerListeningThreadHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerListeningThread_set_OnClose(TElSimpleFTPSServerListeningThreadHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleFTPSServerListeningThread_Create(TElSimpleFTPSServerHandle Owner, TElSimpleFTPSServerListeningThreadHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLEFTPSSERVERLISTENINGTHREAD */

#ifdef SB_USE_CLASS_TELFTPSUSERS
SB_IMPORT uint32_t SB_APIENTRY TElFTPSUsers_AddFTPSUser(TElFTPSUsersHandle _Handle, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword);
SB_IMPORT uint32_t SB_APIENTRY TElFTPSUsers_AddFTPSUser_1(TElFTPSUsersHandle _Handle, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword, const char * pcBasePath, int32_t szBasePath);
SB_IMPORT uint32_t SB_APIENTRY TElFTPSUsers_AddFTPSUser_2(TElFTPSUsersHandle _Handle, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword, const char * pcBasePath, int32_t szBasePath, int32_t OutgoingSpeedLimit, int32_t IncomingSpeedLimit);
SB_IMPORT uint32_t SB_APIENTRY TElFTPSUsers_UpdateFTPSUser(TElFTPSUsersHandle _Handle, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword);
SB_IMPORT uint32_t SB_APIENTRY TElFTPSUsers_FindFTPSUser(TElFTPSUsersHandle _Handle, const char * pcUserName, int32_t szUserName, TElFTPSUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFTPSUsers_get_FTPSUsers(TElFTPSUsersHandle _Handle, int32_t Index, TElFTPSUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFTPSUsers_Create(TComponentHandle AOwner, TElUsersHandle * OutResult);
#endif /* SB_USE_CLASS_TELFTPSUSERS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSimpleFTPSServerSessionThread_ce_ptr;
extern zend_class_entry *TElSimpleFTPSServer_ce_ptr;
extern zend_class_entry *TElSimpleFTPSServerListeningThread_ce_ptr;
extern zend_class_entry *TElFTPSUsers_ce_ptr;

void SB_CALLBACK TSBSimpleFTPSServerNewConnectionEventRaw(void * _ObjectData, TObjectHandle Sender, TElSimpleFTPSServerSessionThreadHandle Session);
void SB_CALLBACK TSBSimpleFTPSServerCloseConnectionEventRaw(void * _ObjectData, TObjectHandle Sender, TElSimpleFTPSServerSessionThreadHandle Session);
void SB_CALLBACK TSBFTPSServerExceptionEventRaw(void * _ObjectData, TObjectHandle Sender, TElClassHandle Ex);
void SB_CALLBACK TSBSimpleFTPSListenerNewConnectionEventRaw(void * _ObjectData, TObjectHandle Sender, TElSocketHandle Socket, int8_t * Reject);
void SB_CALLBACK TSBSimpleFTPSServerBeforeNewConnectionEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcRemoteIP, int32_t szRemoteIP, int32_t RemotePort, int8_t * Reject);
void SB_CALLBACK TSBSimpleFTPSServerAuthAttemptEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, const char * pcPassword, int32_t szPassword, int8_t * Allow);
void Register_TElSimpleFTPSServerSessionThread(TSRMLS_D);
void Register_TElSimpleFTPSServer(TSRMLS_D);
void Register_TElSimpleFTPSServerListeningThread(TSRMLS_D);
void Register_TElFTPSUsers(TSRMLS_D);
void Register_SBSimpleFTPSServer_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSIMPLEFTPSSERVER */

