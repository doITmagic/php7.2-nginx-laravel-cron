#ifndef __INC_SBSIMPLEMIME
#define __INC_SBSIMPLEMIME

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbmime.h"
#include "sbdomainkeys.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSimpleMIMEAttachmentHandle;

typedef TElSimpleMIMEAttachmentHandle ElSimpleMIMEAttachmentHandle;

typedef TElClassHandle TElSimpleMIMEMessageHandle;

typedef TElSimpleMIMEMessageHandle ElSimpleMIMEMessageHandle;

#ifdef SB_USE_CLASS_TELSIMPLEMIMEATTACHMENT
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEAttachment_AttachFile(TElSimpleMIMEAttachmentHandle _Handle, const char * pcFileName, int32_t szFileName);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEAttachment_get_ContentDisposition(TElSimpleMIMEAttachmentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEAttachment_set_ContentDisposition(TElSimpleMIMEAttachmentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEAttachment_get_ContentId(TElSimpleMIMEAttachmentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEAttachment_set_ContentId(TElSimpleMIMEAttachmentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEAttachment_get_ContentStream(TElSimpleMIMEAttachmentHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEAttachment_set_ContentStream(TElSimpleMIMEAttachmentHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEAttachment_get_ContentType(TElSimpleMIMEAttachmentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEAttachment_set_ContentType(TElSimpleMIMEAttachmentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEAttachment_get_Name(TElSimpleMIMEAttachmentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEAttachment_set_Name(TElSimpleMIMEAttachmentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEAttachment_get_DisposeStream(TElSimpleMIMEAttachmentHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEAttachment_set_DisposeStream(TElSimpleMIMEAttachmentHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEAttachment_Create(TElSimpleMIMEAttachmentHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLEMIMEATTACHMENT */

#ifdef SB_USE_CLASS_TELSIMPLEMIMEMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_AddAttachment(TElSimpleMIMEMessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_GetMessage(TElSimpleMIMEMessageHandle _Handle, TElMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_DeleteAttachment(TElSimpleMIMEMessageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_IndexOfAttachment(TElSimpleMIMEMessageHandle _Handle, TElSimpleMIMEAttachmentHandle Attachment, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_RemoveAttachment(TElSimpleMIMEMessageHandle _Handle, TElSimpleMIMEAttachmentHandle Attachment);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_SaveToStream(TElSimpleMIMEMessageHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_SaveToText(TElSimpleMIMEMessageHandle _Handle, TStringsHandle Text);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_Attachments(TElSimpleMIMEMessageHandle _Handle, int32_t Index, TElSimpleMIMEAttachmentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_AttachEncoding(TElSimpleMIMEMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_AttachEncoding(TElSimpleMIMEMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_AttachmentCount(TElSimpleMIMEMessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_BCC(TElSimpleMIMEMessageHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_BCC(TElSimpleMIMEMessageHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_BodyEncoding(TElSimpleMIMEMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_BodyEncoding(TElSimpleMIMEMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_BodyHTML(TElSimpleMIMEMessageHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_BodyHTML(TElSimpleMIMEMessageHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_BodyPlain(TElSimpleMIMEMessageHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_BodyPlain(TElSimpleMIMEMessageHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_CC(TElSimpleMIMEMessageHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_CC(TElSimpleMIMEMessageHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_Charset(TElSimpleMIMEMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_Charset(TElSimpleMIMEMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_CustomHeaders(TElSimpleMIMEMessageHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_CustomHeaders(TElSimpleMIMEMessageHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_DomainKeysSigner(TElSimpleMIMEMessageHandle _Handle, TElDomainKeysSignerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_DomainKeysSigner(TElSimpleMIMEMessageHandle _Handle, TElDomainKeysSignerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_From(TElSimpleMIMEMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_From(TElSimpleMIMEMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_HeaderEncoding(TElSimpleMIMEMessageHandle _Handle, TElHeaderEncodingRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_HeaderEncoding(TElSimpleMIMEMessageHandle _Handle, TElHeaderEncodingRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_InReplyTo(TElSimpleMIMEMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_InReplyTo(TElSimpleMIMEMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_IsHTML(TElSimpleMIMEMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_IsHTML(TElSimpleMIMEMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_To_(TElSimpleMIMEMessageHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_To_(TElSimpleMIMEMessageHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_Priority(TElSimpleMIMEMessageHandle _Handle, TElMIMEMessagePriorityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_Priority(TElSimpleMIMEMessageHandle _Handle, TElMIMEMessagePriorityRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_RequestDeliveryReceipt(TElSimpleMIMEMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_RequestDeliveryReceipt(TElSimpleMIMEMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_RequestReadReceipt(TElSimpleMIMEMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_RequestReadReceipt(TElSimpleMIMEMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_ReplyTo(TElSimpleMIMEMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_ReplyTo(TElSimpleMIMEMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_Sender(TElSimpleMIMEMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_Sender(TElSimpleMIMEMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_Subject(TElSimpleMIMEMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_Subject(TElSimpleMIMEMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_get_XMailer(TElSimpleMIMEMessageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_set_XMailer(TElSimpleMIMEMessageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleMIMEMessage_Create(TComponentHandle AOwner, TElSimpleMIMEMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLEMIMEMESSAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSimpleMIMEAttachment_ce_ptr;
extern zend_class_entry *TElSimpleMIMEMessage_ce_ptr;

void Register_TElSimpleMIMEAttachment(TSRMLS_D);
void Register_TElSimpleMIMEMessage(TSRMLS_D);
void Register_SBSimpleMIME_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSIMPLEMIME */

