#ifndef __INC_SBSIMPLEOAUTH2
#define __INC_SBSIMPLEOAUTH2

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbstrutils.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sboauth2.h"
#include "sbhttpsclient.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_OAUTH2_SIMPLE_ERROR_FLAG 	2560
#define SB_SIMPLE_OAUTH2_ERROR_NO_HTTPS_CLIENT 	2561
#define SB_SIMPLE_OAUTH2_ERROR_AUTH_NOT_STARTED 	2562
#define SB_SIMPLE_OAUTH2_ERROR_INVALID_AUTH_CODE 	2563
#define SB_SIMPLE_OAUTH2_ERROR_AUTH_FAILED 	2564
#define SB_SIMPLE_OAUTH2_ERROR_NO_LAUNCH_BROWSER_HANDLER 	2565
#define SB_SIMPLE_OAUTH2_ERROR_TIMEOUT 	2566
#define SB_SIMPLE_OAUTH2_ERROR_CANCELLED 	2567
#define SB_SIMPLE_OAUTH2_ERROR_EXPIRED 	2568

typedef TElClassHandle TElSimpleOAuth2ClientHandle;

typedef void (SB_CALLBACK *TSBSimpleOAuth2LaunchBrowserEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL);

typedef void (SB_CALLBACK *TSBSimpleOAuth2WaitEvent)(void * _ObjectData, TObjectHandle Sender, uint32_t TimeLeft, int8_t * Stop);

#ifdef SB_USE_CLASS_TELSIMPLEOAUTH2CLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_StartAuthorization(TElSimpleOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_CompleteAuthorization(TElSimpleOAuth2ClientHandle _Handle, const char * pcAuthCode, int32_t szAuthCode);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_Authorize(TElSimpleOAuth2ClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_ClearCustomParams(TElSimpleOAuth2ClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_AccessToken(TElSimpleOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_CustomParam(TElSimpleOAuth2ClientHandle _Handle, const char * pcName, int32_t szName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_CustomParam(TElSimpleOAuth2ClientHandle _Handle, const char * pcName, int32_t szName, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_ExpiresAt(TElSimpleOAuth2ClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_ExpiresIn(TElSimpleOAuth2ClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_TokenType(TElSimpleOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_AuthURL(TElSimpleOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_AuthURL(TElSimpleOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_AutoRefresh(TElSimpleOAuth2ClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_AutoRefresh(TElSimpleOAuth2ClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_ClientID(TElSimpleOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_ClientID(TElSimpleOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_ClientSecret(TElSimpleOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_ClientSecret(TElSimpleOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_FailureResponse(TElSimpleOAuth2ClientHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_FailureResponse(TElSimpleOAuth2ClientHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_HTTPClient(TElSimpleOAuth2ClientHandle _Handle, TElHTTPSClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_HTTPClient(TElSimpleOAuth2ClientHandle _Handle, TElHTTPSClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_RedirectURL(TElSimpleOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_RedirectURL(TElSimpleOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_RefreshToken(TElSimpleOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_RefreshToken(TElSimpleOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_Scope(TElSimpleOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_Scope(TElSimpleOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_State(TElSimpleOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_State(TElSimpleOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_SuccessResponse(TElSimpleOAuth2ClientHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_SuccessResponse(TElSimpleOAuth2ClientHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_Timeout(TElSimpleOAuth2ClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_Timeout(TElSimpleOAuth2ClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_TokenURL(TElSimpleOAuth2ClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_TokenURL(TElSimpleOAuth2ClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_OnLaunchBrowser(TElSimpleOAuth2ClientHandle _Handle, TSBSimpleOAuth2LaunchBrowserEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_OnLaunchBrowser(TElSimpleOAuth2ClientHandle _Handle, TSBSimpleOAuth2LaunchBrowserEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_get_OnWait(TElSimpleOAuth2ClientHandle _Handle, TSBSimpleOAuth2WaitEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_set_OnWait(TElSimpleOAuth2ClientHandle _Handle, TSBSimpleOAuth2WaitEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleOAuth2Client_Create(TComponentHandle AOwner, TElSimpleOAuth2ClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLEOAUTH2CLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSimpleOAuth2Client_ce_ptr;

void SB_CALLBACK TSBSimpleOAuth2LaunchBrowserEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL);
void SB_CALLBACK TSBSimpleOAuth2WaitEventRaw(void * _ObjectData, TObjectHandle Sender, uint32_t TimeLeft, int8_t * Stop);
void Register_TElSimpleOAuth2Client(TSRMLS_D);
void Register_SBSimpleOAuth2_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSIMPLEOAUTH2 */

