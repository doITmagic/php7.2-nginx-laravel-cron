#ifndef __INC_SBSIMPLESFTP
#define __INC_SBSIMPLESFTP

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbstringlist.h"
#include "sbcryptoprov.h"
#include "sbsshcommon.h"
#include "sbsshclient.h"
#include "sbsshkeystorage.h"
#include "sbgssapibase.h"
#include "sbgssapi.h"
#include "sbsshconstants.h"
#include "sbsftp.h"
#include "sbsftpcommon.h"
#include "sbtimer.h"
#include "sbcustomfsadapter.h"
#include "sbdiskfsadapter.h"
#include "sbsharedresource.h"
#include "sbdnssecconsts.h"
#include "sbdnssectypes.h"
#include "sbsocket.h"
#include "sbportknock.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSimpleSFTPClientHandle;

typedef TElSimpleSFTPClientHandle ElSimpleSFTPClientHandle;

#ifdef SB_USE_CLASS_TELSIMPLESFTPCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ExtensionCmd(TElSimpleSFTPClientHandle _Handle, const char * pcExtension, int32_t szExtension, void * DataBuffer, int32_t Size, TStreamHandle ResponseStream);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ExtensionCmd_1(TElSimpleSFTPClientHandle _Handle, const char * pcExtension, int32_t szExtension, TStreamHandle ResponseStream);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_Block(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, int64_t Length, TSBSftpFileOpenAccessRaw LockMask);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_Unblock(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, int64_t Length);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_SendVendorID(TElSimpleSFTPClientHandle _Handle, TElSftpVendorIDExtensionHandle VendorID);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RequestFileHash(TElSimpleSFTPClientHandle _Handle, const char * pcFileName, int32_t szFileName, int64_t StartOffset, int64_t Length, uint32_t BlockSize, TElSftpCheckFileReplyHandle FileHash);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RequestFileHash_1(TElSimpleSFTPClientHandle _Handle, const char * pcFileName, int32_t szFileName, TElSftpCheckFileReplyHandle FileHash);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RequestFileHash_2(TElSimpleSFTPClientHandle _Handle, const char * pcFileName, int32_t szFileName, int64_t StartOffset, int64_t Length, uint32_t BlockSize, const char * pcHashAlgorithms, int32_t szHashAlgorithms, TElSftpCheckFileReplyHandle FileHash);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RequestFileHash_3(TElSimpleSFTPClientHandle _Handle, const char * pcFileName, int32_t szFileName, int32_t HashAlgorithm, TElSftpCheckFileReplyHandle FileHash);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RequestFileHashByHandle(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t StartOffset, int64_t Length, uint32_t BlockSize, TElSftpCheckFileReplyHandle FileHash);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RequestFileHashByHandle_1(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, TElSftpCheckFileReplyHandle FileHash);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RequestFileHashByHandle_2(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t StartOffset, int64_t Length, uint32_t BlockSize, const char * pcHashAlgorithms, int32_t szHashAlgorithms, TElSftpCheckFileReplyHandle FileHash);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RequestFileHashByHandle_3(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int32_t HashAlgorithm, TElSftpCheckFileReplyHandle FileHash);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_QueryAvailableSpace(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, TElSftpSpaceAvailableReplyHandle AvailSpace);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_QueryStatVFS(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, TElSftpStatVFSReplyHandle StatVFS);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_QueryHomeDirectory(TElSimpleSFTPClientHandle _Handle, const char * pcUsername, int32_t szUsername, TElSftpFileInfoHandle HomeDir);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_CopyRemoteFile(TElSimpleSFTPClientHandle _Handle, const char * pcSource, int32_t szSource, const char * pcDestination, int32_t szDestination, int8_t Overwrite);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_CopyRemoteData(TElSimpleSFTPClientHandle _Handle, const uint8_t pReadFrom[], int32_t szReadFrom, int64_t ReadFromOffset, const uint8_t pWriteTo[], int32_t szWriteTo, int64_t WriteToOffset, int64_t DataLength);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RequestTempFolder(TElSimpleSFTPClientHandle _Handle, TElSftpFileInfoHandle TempFolder);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_MakeTempFolder(TElSimpleSFTPClientHandle _Handle, TElSftpFileInfoHandle TempFolder);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_FileExists(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_GetFileSize(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_DirExists(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_Interrupt(TElSimpleSFTPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_Close(TElSimpleSFTPClientHandle _Handle, int8_t Silent);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_CloseHandle(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_CreateFile(TElSimpleSFTPClientHandle _Handle, const char * pcFilename, int32_t szFilename, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_CreateSymLink(TElSimpleSFTPClientHandle _Handle, const char * pcLinkPath, int32_t szLinkPath, const char * pcTargetPath, int32_t szTargetPath);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_CreateHardLink(TElSimpleSFTPClientHandle _Handle, const char * pcLinkPath, int32_t szLinkPath, const char * pcTargetPath, int32_t szTargetPath);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_DownloadFiles(TElSimpleSFTPClientHandle _Handle, const char * pcRemotePath, int32_t szRemotePath, const char * pcRemoteMask, int32_t szRemoteMask, const char * pcLocalPath, int32_t szLocalPath, TSBFileTransferModeRaw Mode, int8_t CaseSensitive, TSBCaseConversionRaw CaseConversion, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_DownloadFiles_1(TElSimpleSFTPClientHandle _Handle, const char * pcRemotePath, int32_t szRemotePath, const char * pcRemoteMask, int32_t szRemoteMask, const char * pcLocalPath, int32_t szLocalPath, TSBFileTransferModeRaw Mode, int8_t CaseSensitive, TSBCaseConversionRaw CaseConversion, int8_t Recursive, int8_t DeleteFiles);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_DownloadFiles_2(TElSimpleSFTPClientHandle _Handle, const char * pcRemotePath, int32_t szRemotePath, const char * pcRemoteMask, int32_t szRemoteMask, const char * pcLocalPath, int32_t szLocalPath, TSBFileTransferModeRaw Mode, TSBFileCopyModeRaw CopyMode, int8_t CaseSensitive, TSBCaseConversionRaw CaseConversion, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_UploadFiles(TElSimpleSFTPClientHandle _Handle, const char * pcLocalPath, int32_t szLocalPath, const char * pcLocalMask, int32_t szLocalMask, const char * pcRemotePath, int32_t szRemotePath, TSBFileTransferModeRaw Mode, int8_t CaseSensitive, TSBCaseConversionRaw CaseConversion, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_UploadFiles_1(TElSimpleSFTPClientHandle _Handle, const char * pcLocalPath, int32_t szLocalPath, const char * pcLocalMask, int32_t szLocalMask, const char * pcRemotePath, int32_t szRemotePath, TSBFileTransferModeRaw Mode, int8_t CaseSensitive, TSBCaseConversionRaw CaseConversion, int8_t Recursive, int8_t DeleteFiles);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_UploadFiles_2(TElSimpleSFTPClientHandle _Handle, const char * pcLocalPath, int32_t szLocalPath, const char * pcLocalMask, int32_t szLocalMask, const char * pcRemotePath, int32_t szRemotePath, TSBFileTransferModeRaw Mode, TSBFileCopyModeRaw CopyMode, int8_t CaseSensitive, TSBCaseConversionRaw CaseConversion, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_DownloadFile(TElSimpleSFTPClientHandle _Handle, const char * pcRemoteFileName, int32_t szRemoteFileName, const char * pcLocalFileName, int32_t szLocalFileName);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_DownloadFile_1(TElSimpleSFTPClientHandle _Handle, const char * pcRemoteFileName, int32_t szRemoteFileName, const char * pcLocalFileName, int32_t szLocalFileName, int8_t SuppressAdditionalOperations);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_DownloadFile_2(TElSimpleSFTPClientHandle _Handle, const char * pcRemoteFileName, int32_t szRemoteFileName, const char * pcLocalFileName, int32_t szLocalFileName, TSBFileTransferModeRaw Mode);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_DownloadFile_3(TElSimpleSFTPClientHandle _Handle, const char * pcRemoteFileName, int32_t szRemoteFileName, const char * pcLocalFileName, int32_t szLocalFileName, TSBFileTransferModeRaw Mode, int64_t RestartFrom);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_UploadFile(TElSimpleSFTPClientHandle _Handle, const char * pcLocalFileName, int32_t szLocalFileName, const char * pcRemoteFileName, int32_t szRemoteFileName);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_UploadFile_1(TElSimpleSFTPClientHandle _Handle, const char * pcLocalFileName, int32_t szLocalFileName, const char * pcRemoteFileName, int32_t szRemoteFileName, int8_t SuppressAdditionalOperations);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_UploadFile_2(TElSimpleSFTPClientHandle _Handle, const char * pcLocalFileName, int32_t szLocalFileName, const char * pcRemoteFileName, int32_t szRemoteFileName, TSBFileTransferModeRaw Mode);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_UploadFile_3(TElSimpleSFTPClientHandle _Handle, const char * pcLocalFileName, int32_t szLocalFileName, const char * pcRemoteFileName, int32_t szRemoteFileName, TSBFileTransferModeRaw Mode, int64_t RestartFrom);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_DownloadStream(TElSimpleSFTPClientHandle _Handle, const char * pcRemoteFileName, int32_t szRemoteFileName, TStreamHandle LocalStream, TSBFileTransferModeRaw Mode);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_DownloadStream_1(TElSimpleSFTPClientHandle _Handle, const char * pcRemoteFileName, int32_t szRemoteFileName, TStreamHandle LocalStream, TSBFileTransferModeRaw Mode, int64_t RestartFrom);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_DownloadStream_2(TElSimpleSFTPClientHandle _Handle, const char * pcRemoteFileName, int32_t szRemoteFileName, TStreamHandle LocalStream, int8_t SuppressAdditionalOperations);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_UploadStream(TElSimpleSFTPClientHandle _Handle, TStreamHandle LocalStream, const char * pcRemoteFileName, int32_t szRemoteFileName, TSBFileTransferModeRaw Mode);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_UploadStream_1(TElSimpleSFTPClientHandle _Handle, TStreamHandle LocalStream, const char * pcRemoteFileName, int32_t szRemoteFileName, TSBFileTransferModeRaw Mode, int64_t RestartFrom);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_UploadStream_2(TElSimpleSFTPClientHandle _Handle, TStreamHandle LocalStream, const char * pcRemoteFileName, int32_t szRemoteFileName, int8_t SuppressAdditionalOperations);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_MakeDirectory(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, TElSftpFileAttributesHandle Attributes);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_CreateDirectoryPath(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_Open(TElSimpleSFTPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_OpenDirectory(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_OpenFile(TElSimpleSFTPClientHandle _Handle, const char * pcFilename, int32_t szFilename, TSBSftpFileOpenModesRaw Modes, TElSftpFileAttributesHandle Attributes, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_OpenFile_1(TElSimpleSFTPClientHandle _Handle, const char * pcFilename, int32_t szFilename, TSBSftpFileOpenModesRaw Modes, TSBSftpFileOpenAccessRaw Access, TElSftpFileAttributesHandle Attributes, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_OpenStream(TElSimpleSFTPClientHandle _Handle, const char * pcFilename, int32_t szFilename, TSBSftpFileOpenModesRaw Modes, TElSftpStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ReadDirectory(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, TListHandle Listing);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ReadDirectory_1(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, TListHandle Listing, const char * pcMask, int32_t szMask, int8_t CaseSensitive, int8_t IncludeFiles, int8_t IncludeDirectories);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ReadDirectory_2(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, TListHandle Listing, const char * pcMask, int32_t szMask, const char * pcDirectoryMask, int32_t szDirectoryMask, int8_t CaseSensitive, int8_t IncludeFiles, int8_t IncludeDirectories);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ReadDirectory_3(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, TListHandle Listing, const char * pcMask, int32_t szMask, const char * pcDirectoryMask, int32_t szDirectoryMask, int8_t CaseSensitive, int8_t IncludeFiles, int8_t IncludeDirectories, int8_t Recursive, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ListDirectory(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, TListHandle Listing);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ListDirectory_1(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, TListHandle Listing, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ListDirectory_2(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, TListHandle Listing, const char * pcMask, int32_t szMask, int8_t CaseSensitive, int8_t IncludeFiles, int8_t IncludeDirectories);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ListDirectory_3(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, TListHandle Listing, const char * pcMask, int32_t szMask, int8_t CaseSensitive, int8_t IncludeFiles, int8_t IncludeDirectories, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ReadSymLink(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, TElSftpFileInfoHandle Info);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_Read(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, void * Buffer, int32_t Length, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RemoveDirectory(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RemoveDirectory_1(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RemoveFile(TElSimpleSFTPClientHandle _Handle, const char * pcFilename, int32_t szFilename);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RemoveFiles(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, const char * pcMask, int32_t szMask, int8_t CaseSensitive, int8_t Recursive);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RemoveFiles_1(TElSimpleSFTPClientHandle _Handle, TStringsHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RenameFile(TElSimpleSFTPClientHandle _Handle, const char * pcOldPath, int32_t szOldPath, const char * pcNewPath, int32_t szNewPath);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RequestAbsolutePath(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RequestAbsolutePathEx(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, TSBSftpRealpathControlRaw Control, TStringListHandle ComposePath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RequestAttributes(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, int8_t FollowSymLinks, TElSftpFileAttributesHandle Attributes);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RequestAttributes_1(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, TElSftpFileAttributesHandle Attributes);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_SetAttributes(TElSimpleSFTPClientHandle _Handle, const char * pcPath, int32_t szPath, TElSftpFileAttributesHandle Attributes);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_SetAttributesByHandle(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, TElSftpFileAttributesHandle Attributes);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_Write(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t Offset, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_FinalizeTextWrite(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_TextSeek(TElSimpleSFTPClientHandle _Handle, const uint8_t pHandle[], int32_t szHandle, int64_t LineNumber);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_RenegotiateCiphers(TElSimpleSFTPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ExecuteSSHCommand(TElSimpleSFTPClientHandle _Handle, const char * pcCommand, int32_t szCommand, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ExecuteSSHCommand_1(TElSimpleSFTPClientHandle _Handle, const char * pcCommand, int32_t szCommand, int8_t RedirectStdErr, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ExecuteSSHCommand_2(TElSimpleSFTPClientHandle _Handle, const char * pcCommand, int32_t szCommand, uint8_t pStdErrData[], int32_t * szStdErrData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_ProcessServerInitiatedData(TElSimpleSFTPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_CompressionAlgorithms(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_CompressionAlgorithms(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_EncryptionAlgorithms(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_EncryptionAlgorithms(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_KexAlgorithms(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_KexAlgorithms(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_MacAlgorithms(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_MacAlgorithms(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_PublicKeyAlgorithms(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_PublicKeyAlgorithms(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_EncryptionAlgorithmPriorities(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_EncryptionAlgorithmPriorities(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_CompressionAlgorithmPriorities(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_CompressionAlgorithmPriorities(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_MacAlgorithmPriorities(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_MacAlgorithmPriorities(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_KexAlgorithmPriorities(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_KexAlgorithmPriorities(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_PublicKeyAlgorithmPriorities(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_PublicKeyAlgorithmPriorities(TElSimpleSFTPClientHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_AuthTypePriorities(TElSimpleSFTPClientHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_AuthTypePriorities(TElSimpleSFTPClientHandle _Handle, int32_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_Active(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_CompressionAlgorithmClientToServer(TElSimpleSFTPClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_CompressionAlgorithmServerToClient(TElSimpleSFTPClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_EncryptionAlgorithmClientToServer(TElSimpleSFTPClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_EncryptionAlgorithmServerToClient(TElSimpleSFTPClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_KexAlgorithm(TElSimpleSFTPClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_LastSyncComment(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_LastSyncError(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_MacAlgorithmClientToServer(TElSimpleSFTPClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_MacAlgorithmServerToClient(TElSimpleSFTPClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SocketSettings(TElSimpleSFTPClientHandle _Handle, TElSocketSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_NewLineConvention(TElSimpleSFTPClientHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_NewLineConvention(TElSimpleSFTPClientHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_LocalNewLineConvention(TElSimpleSFTPClientHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_LocalNewLineConvention(TElSimpleSFTPClientHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_PublicKeyAlgorithm(TElSimpleSFTPClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_ServerCloseReason(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_ServerSoftwareName(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SFTPExt(TElSimpleSFTPClientHandle _Handle, TSBSftpExtendedAttributeHandle pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_SFTPExt(TElSimpleSFTPClientHandle _Handle, const TSBSftpExtendedAttributeHandle pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_Version(TElSimpleSFTPClientHandle _Handle, TSBSftpVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_ExtendedProperties(TElSimpleSFTPClientHandle _Handle, TElSftpExtendedPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_KbdIntName(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_KbdIntInstruction(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_ServerKey(TElSimpleSFTPClientHandle _Handle, TElSSHKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_ProxyResult(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_TotalBytesSent(TElSimpleSFTPClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_TotalBytesReceived(TElSimpleSFTPClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_UsingIPv6(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_GSSMechanism(TElSimpleSFTPClientHandle _Handle, TElGSSBaseMechanismHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_GSSMechanism(TElSimpleSFTPClientHandle _Handle, TElGSSBaseMechanismHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_GSSHostName(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_GSSHostName(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_GSSDelegateCredentials(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_GSSDelegateCredentials(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_InternalSocket(TElSimpleSFTPClientHandle _Handle, TElSocketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SecondaryChannelExitStatus(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SecondaryChannelExitSignal(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SecondaryChannelExitMessage(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SSHAuthOrder(TElSimpleSFTPClientHandle _Handle, TSBSSHAuthOrderRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_SSHAuthOrder(TElSimpleSFTPClientHandle _Handle, TSBSSHAuthOrderRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_Address(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_Address(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_AutoAdjustCiphers(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_AutoAdjustCiphers(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_AuthenticationTypes(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_AuthenticationTypes(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_ASCIIMode(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_ASCIIMode(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_ClientHostname(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_ClientHostname(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_ClientUsername(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_ClientUsername(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_CompressionLevel(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_CompressionLevel(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_ForceCompression(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_ForceCompression(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_KeyStorage(TElSimpleSFTPClientHandle _Handle, TElSSHCustomKeyStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_KeyStorage(TElSimpleSFTPClientHandle _Handle, TElSSHCustomKeyStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_CryptoProviderManager(TElSimpleSFTPClientHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_CryptoProviderManager(TElSimpleSFTPClientHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_FileSystemAdapter(TElSimpleSFTPClientHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_FileSystemAdapter(TElSimpleSFTPClientHandle _Handle, TElCustomFileSystemAdapterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_PortKnock(TElSimpleSFTPClientHandle _Handle, TElPortKnockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_PortKnock(TElSimpleSFTPClientHandle _Handle, TElPortKnockHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_DefaultWindowSize(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_DefaultWindowSize(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_MinWindowSize(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_MinWindowSize(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_MaxSSHPacketSize(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_MaxSSHPacketSize(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_TrustedKeys(TElSimpleSFTPClientHandle _Handle, TElSSHCustomKeyStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_TrustedKeys(TElSimpleSFTPClientHandle _Handle, TElSSHCustomKeyStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_ObfuscateHandshake(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_ObfuscateHandshake(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_ObfuscationPassword(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_ObfuscationPassword(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_CopyEmptyDirs(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_CopyEmptyDirs(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_DeleteFailedDownloads(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_DeleteFailedDownloads(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_EarlyIdString(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_EarlyIdString(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_Password(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_Password(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_Port(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_Port(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SftpBufferSize(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_SftpBufferSize(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SocketTimeout(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_SocketTimeout(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SocksAuthentication(TElSimpleSFTPClientHandle _Handle, TElSocksAuthenticationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_SocksAuthentication(TElSimpleSFTPClientHandle _Handle, TElSocksAuthenticationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SocksPassword(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_SocksPassword(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SocksPort(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_SocksPort(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SocksResolveAddress(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_SocksResolveAddress(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SocksServer(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_SocksServer(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SocksUserCode(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_SocksUserCode(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SocksVersion(TElSimpleSFTPClientHandle _Handle, TElSocksVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_SocksVersion(TElSimpleSFTPClientHandle _Handle, TElSocksVersionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SoftwareName(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_SoftwareName(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_AutoAdjustTransferBlock(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_AutoAdjustTransferBlock(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_UseInternalSocket(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_UseInternalSocket(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_Username(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_Username(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SocksUseIPv6(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_SocksUseIPv6(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_UseIPv6(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_UseIPv6(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_UseSocks(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_UseSocks(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_DNS(TElSimpleSFTPClientHandle _Handle, TElDNSSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_DNS(TElSimpleSFTPClientHandle _Handle, TElDNSSettingsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_UseWebTunneling(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_UseWebTunneling(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_Versions(TElSimpleSFTPClientHandle _Handle, TSBSftpVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_Versions(TElSimpleSFTPClientHandle _Handle, TSBSftpVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_WebTunnelAddress(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_WebTunnelAddress(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_WebTunnelAuthentication(TElSimpleSFTPClientHandle _Handle, TElWebTunnelAuthenticationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_WebTunnelAuthentication(TElSimpleSFTPClientHandle _Handle, TElWebTunnelAuthenticationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_LocalAddress(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_LocalAddress(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_LocalPort(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_LocalPort(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_PipelineLength(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_PipelineLength(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_DownloadBlockSize(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_DownloadBlockSize(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_UploadBlockSize(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_UploadBlockSize(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_UseUTF8(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_UseUTF8(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_UseUTF8OnV3(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_UseUTF8OnV3(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_NoCharacterEncoding(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_NoCharacterEncoding(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_LocalCharset(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_LocalCharset(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_RemoteCharset(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_RemoteCharset(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_WebTunnelPassword(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_WebTunnelPassword(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_WebTunnelPort(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_WebTunnelPort(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_WebTunnelUserId(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_WebTunnelUserId(TElSimpleSFTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_WebTunnelRequestHeaders(TElSimpleSFTPClientHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_WebTunnelResponseHeaders(TElSimpleSFTPClientHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_WebTunnelResponseBody(TElSimpleSFTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OperationErrorHandling(TElSimpleSFTPClientHandle _Handle, TSBOperationErrorHandlingRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OperationErrorHandling(TElSimpleSFTPClientHandle _Handle, TSBOperationErrorHandlingRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_RequestPasswordChange(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_RequestPasswordChange(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_CertAuthMode(TElSimpleSFTPClientHandle _Handle, TSBSSHCertAuthModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_CertAuthMode(TElSimpleSFTPClientHandle _Handle, TSBSSHCertAuthModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_AuthAttempts(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_AuthAttempts(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_IncomingSpeedLimit(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_IncomingSpeedLimit(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OutgoingSpeedLimit(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OutgoingSpeedLimit(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SocketBinding(TElSimpleSFTPClientHandle _Handle, TElClientSocketBindingHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_SocketBinding(TElSimpleSFTPClientHandle _Handle, TElClientSocketBindingHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_KeepAlivePeriod(TElSimpleSFTPClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_KeepAlivePeriod(TElSimpleSFTPClientHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_ThreadSafe(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_ThreadSafe(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_AdjustFileTimes(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_AdjustFileTimes(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_PreserveExistingFileTimes(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_PreserveExistingFileTimes(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_UseTruncateFlagOnUpload(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_UseTruncateFlagOnUpload(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_TreatZeroSizeAsUndefined(TElSimpleSFTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_TreatZeroSizeAsUndefined(TElSimpleSFTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_SFTPServerExecutableLocations(TElSimpleSFTPClientHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_CommandTimeout(TElSimpleSFTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_CommandTimeout(TElSimpleSFTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnAuthenticationFailed(TElSimpleSFTPClientHandle _Handle, TSSHAuthenticationFailedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnAuthenticationFailed(TElSimpleSFTPClientHandle _Handle, TSSHAuthenticationFailedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnAuthenticationKeyboard(TElSimpleSFTPClientHandle _Handle, TSSHAuthenticationKeyboardEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnAuthenticationKeyboard(TElSimpleSFTPClientHandle _Handle, TSSHAuthenticationKeyboardEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnAuthenticationSuccess(TElSimpleSFTPClientHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnAuthenticationSuccess(TElSimpleSFTPClientHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnBanner(TElSimpleSFTPClientHandle _Handle, TSSHBannerEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnBanner(TElSimpleSFTPClientHandle _Handle, TSSHBannerEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnCloseConnection(TElSimpleSFTPClientHandle _Handle, TSSHCloseConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnCloseConnection(TElSimpleSFTPClientHandle _Handle, TSSHCloseConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnError(TElSimpleSFTPClientHandle _Handle, TSSHErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnError(TElSimpleSFTPClientHandle _Handle, TSSHErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnKeyValidate(TElSimpleSFTPClientHandle _Handle, TSSHKeyValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnKeyValidate(TElSimpleSFTPClientHandle _Handle, TSSHKeyValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnReceive(TElSimpleSFTPClientHandle _Handle, TSSHReceiveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnReceive(TElSimpleSFTPClientHandle _Handle, TSSHReceiveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnSend(TElSimpleSFTPClientHandle _Handle, TSSHSendEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnSend(TElSimpleSFTPClientHandle _Handle, TSSHSendEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnProgress(TElSimpleSFTPClientHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnProgress(TElSimpleSFTPClientHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnFileOperation(TElSimpleSFTPClientHandle _Handle, TElSftpFileOperationEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnFileOperation(TElSimpleSFTPClientHandle _Handle, TElSftpFileOperationEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnFileOperationResult(TElSimpleSFTPClientHandle _Handle, TElSftpFileOperationResultEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnFileOperationResult(TElSimpleSFTPClientHandle _Handle, TElSftpFileOperationResultEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnBlockTransferPrepared(TElSimpleSFTPClientHandle _Handle, TSBSftpBlockTransferPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnBlockTransferPrepared(TElSimpleSFTPClientHandle _Handle, TSBSftpBlockTransferPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnCiphersNegotiated(TElSimpleSFTPClientHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnCiphersNegotiated(TElSimpleSFTPClientHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnPasswordChangeRequest(TElSimpleSFTPClientHandle _Handle, TSSHPasswordChangeRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnPasswordChangeRequest(TElSimpleSFTPClientHandle _Handle, TSSHPasswordChangeRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnPrivateKeyNeeded(TElSimpleSFTPClientHandle _Handle, TSSHPrivateKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnPrivateKeyNeeded(TElSimpleSFTPClientHandle _Handle, TSSHPrivateKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnAuthenticationStart(TElSimpleSFTPClientHandle _Handle, TSSHAuthenticationStartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnAuthenticationStart(TElSimpleSFTPClientHandle _Handle, TSSHAuthenticationStartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnAuthenticationAttempt(TElSimpleSFTPClientHandle _Handle, TSSHAuthenticationAttemptEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnAuthenticationAttempt(TElSimpleSFTPClientHandle _Handle, TSSHAuthenticationAttemptEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_MessageLoop(TElSimpleSFTPClientHandle _Handle, TSBSftpMessageLoopEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_MessageLoop(TElSimpleSFTPClientHandle _Handle, TSBSftpMessageLoopEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnTunnelOpenFailed(TElSimpleSFTPClientHandle _Handle, TSBSftpTunnelOpenFailedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnTunnelOpenFailed(TElSimpleSFTPClientHandle _Handle, TSBSftpTunnelOpenFailedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnSecondaryChannelPrepared(TElSimpleSFTPClientHandle _Handle, TSBSftpSecondaryChannelEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnSecondaryChannelPrepared(TElSimpleSFTPClientHandle _Handle, TSBSftpSecondaryChannelEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnSecondaryChannelOpen(TElSimpleSFTPClientHandle _Handle, TSBSftpSecondaryChannelEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnSecondaryChannelOpen(TElSimpleSFTPClientHandle _Handle, TSBSftpSecondaryChannelEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnSecondaryChannelError(TElSimpleSFTPClientHandle _Handle, TSBSftpSecondaryChannelErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnSecondaryChannelError(TElSimpleSFTPClientHandle _Handle, TSBSftpSecondaryChannelErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnFileNameChangeNeeded(TElSimpleSFTPClientHandle _Handle, TSBSftpFileNameChangeNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnFileNameChangeNeeded(TElSimpleSFTPClientHandle _Handle, TSBSftpFileNameChangeNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnKexInitReceived(TElSimpleSFTPClientHandle _Handle, TSSHKexInitReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnKexInitReceived(TElSimpleSFTPClientHandle _Handle, TSSHKexInitReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnDNSKeyNeeded(TElSimpleSFTPClientHandle _Handle, TSBDNSKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnDNSKeyNeeded(TElSimpleSFTPClientHandle _Handle, TSBDNSKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnDNSKeyValidate(TElSimpleSFTPClientHandle _Handle, TSBDNSKeyValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnDNSKeyValidate(TElSimpleSFTPClientHandle _Handle, TSBDNSKeyValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_get_OnDNSResolve(TElSimpleSFTPClientHandle _Handle, TSBDNSResolveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_set_OnDNSResolve(TElSimpleSFTPClientHandle _Handle, TSBDNSResolveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPClient_Create(TComponentHandle AOwner, TElSimpleSFTPClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLESFTPCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSimpleSFTPClient_ce_ptr;

void Register_TElSimpleSFTPClient(TSRMLS_D);
void Register_SBSimpleSftp_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSIMPLESFTP */

