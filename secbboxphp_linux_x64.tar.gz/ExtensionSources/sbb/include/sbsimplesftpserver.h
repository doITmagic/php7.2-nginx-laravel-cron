#ifndef __INC_SBSIMPLESFTPSERVER
#define __INC_SBSIMPLESFTPSERVER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbmath.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbrandom.h"
#include "sbchsconv.h"
#include "sbchsconvcharsets.h"
#include "sbchscjk.h"
#include "sbsshterm.h"
#include "sbsharedresource.h"
#include "sbsshconstants.h"
#include "sbsshkeystorage.h"
#include "sbsshutils.h"
#include "sbcryptoprov.h"
#include "sbsymmetriccrypto.h"
#include "sbcryptoprovmanager.h"
#include "sbhashfunction.h"
#include "sbsocket.h"
#include "sbsshcommon.h"
#include "sbsshpubkeycommon.h"
#include "sbsshhandlers.h"
#include "sbsshpubkeyhandler.h"
#include "sbsshforwardinghandlers.h"
#include "sbsftphandler.h"
#include "sbsshserver.h"
#include "sbsftpcommon.h"
#include "sbcustomfsadapter.h"
#include "sbdiskfsadapter.h"
#include "sbconstants.h"
#include "sbsimplesshserver.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SFileNotFound 	"File not found"
#define SB_SPermissionDenied 	"Permission denied"
#define SB_SOperationFailed 	"Operation failed"
#define SB_SFileWriteOpFailed 	"Write operation failed"
#define SB_SFileReadOpFailed 	"Read operation failed"

typedef TElClassHandle TElSimpleSFTPServerHandle;

typedef TElClassHandle TElSimpleSSHsftpSearchRecHandle;

typedef TElClassHandle TElSimpleSFTPServerSessionThreadHandle;

#ifdef SB_USE_CLASS_TELSIMPLESFTPSERVER
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_AllowSftp(TElSimpleSFTPServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_AllowSftp(TElSimpleSFTPServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_ReadOnly(TElSimpleSFTPServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_ReadOnly(TElSimpleSFTPServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_SFTPBaseDir(TElSimpleSFTPServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_SFTPBaseDir(TElSimpleSFTPServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_FilenameCharset(TElSimpleSFTPServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_FilenameCharset(TElSimpleSFTPServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_FileSystemAdapter(TElSimpleSFTPServerHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_FileSystemAdapter(TElSimpleSFTPServerHandle _Handle, TElCustomFileSystemAdapterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_Versions(TElSimpleSFTPServerHandle _Handle, TSBSftpVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_Versions(TElSimpleSFTPServerHandle _Handle, TSBSftpVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_DefaultOwnerUsername(TElSimpleSFTPServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_DefaultOwnerUsername(TElSimpleSFTPServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_DefaultOwnerGroup(TElSimpleSFTPServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_DefaultOwnerGroup(TElSimpleSFTPServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPBlock(TElSimpleSFTPServerHandle _Handle, TElSFTPServerBlockEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPBlock(TElSimpleSFTPServerHandle _Handle, TElSFTPServerBlockEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPUnblock(TElSimpleSFTPServerHandle _Handle, TElSFTPServerUnblockEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPUnblock(TElSimpleSFTPServerHandle _Handle, TElSFTPServerUnblockEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPClose(TElSimpleSFTPServerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPClose(TElSimpleSFTPServerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPCloseHandle(TElSimpleSFTPServerHandle _Handle, TElSFTPServerCloseHandleEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPCloseHandle(TElSimpleSFTPServerHandle _Handle, TElSFTPServerCloseHandleEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPCreateDirectory(TElSimpleSFTPServerHandle _Handle, TElSFTPServerCreateDirectoryEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPCreateDirectory(TElSimpleSFTPServerHandle _Handle, TElSFTPServerCreateDirectoryEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPCreateSymLink(TElSimpleSFTPServerHandle _Handle, TElSFTPServerCreateSymLinkEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPCreateSymLink(TElSimpleSFTPServerHandle _Handle, TElSFTPServerCreateSymLinkEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPCreateHardLink(TElSimpleSFTPServerHandle _Handle, TElSFTPServerCreateHardLinkEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPCreateHardLink(TElSimpleSFTPServerHandle _Handle, TElSFTPServerCreateHardLinkEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPError(TElSimpleSFTPServerHandle _Handle, TSBSftpErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPError(TElSimpleSFTPServerHandle _Handle, TSBSftpErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPFindClose(TElSimpleSFTPServerHandle _Handle, TElSFTPServerFindCloseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPFindClose(TElSimpleSFTPServerHandle _Handle, TElSFTPServerFindCloseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPFindFirst(TElSimpleSFTPServerHandle _Handle, TElSFTPServerFindFirstEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPFindFirst(TElSimpleSFTPServerHandle _Handle, TElSFTPServerFindFirstEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPFindNext(TElSimpleSFTPServerHandle _Handle, TElSFTPServerFindNextEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPFindNext(TElSimpleSFTPServerHandle _Handle, TElSFTPServerFindNextEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPOpen(TElSimpleSFTPServerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPOpen(TElSimpleSFTPServerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPOpenFile(TElSimpleSFTPServerHandle _Handle, TElSFTPServerOpenFileEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPOpenFile(TElSimpleSFTPServerHandle _Handle, TElSFTPServerOpenFileEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPReadFile(TElSimpleSFTPServerHandle _Handle, TElSFTPServerReadEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPReadFile(TElSimpleSFTPServerHandle _Handle, TElSFTPServerReadEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPReadSymLink(TElSimpleSFTPServerHandle _Handle, TElSFTPServerReadSymLinkEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPReadSymLink(TElSimpleSFTPServerHandle _Handle, TElSFTPServerReadSymLinkEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPReceive(TElSimpleSFTPServerHandle _Handle, TElSFTPServerReceiveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPReceive(TElSimpleSFTPServerHandle _Handle, TElSFTPServerReceiveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPRemove(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRemoveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPRemove(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRemoveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPRenameFile(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRenameFileEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPRenameFile(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRenameFileEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPRequestAbsolutePath(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestAbsolutePathEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPRequestAbsolutePath(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestAbsolutePathEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPRequestAttributes(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestAttributesEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPRequestAttributes(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestAttributesEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPRequestAttributes2(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestAttributes2Event * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPRequestAttributes2(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestAttributes2Event pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPSend(TElSimpleSFTPServerHandle _Handle, TElSFTPServerSendEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPSend(TElSimpleSFTPServerHandle _Handle, TElSFTPServerSendEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPSetAttributes(TElSimpleSFTPServerHandle _Handle, TElSFTPServerSetAttributesEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPSetAttributes(TElSimpleSFTPServerHandle _Handle, TElSFTPServerSetAttributesEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPSetAttributes2(TElSimpleSFTPServerHandle _Handle, TElSFTPServerSetAttributes2Event * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPSetAttributes2(TElSimpleSFTPServerHandle _Handle, TElSFTPServerSetAttributes2Event pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPTextSeek(TElSimpleSFTPServerHandle _Handle, TElSFTPServerTextSeekEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPTextSeek(TElSimpleSFTPServerHandle _Handle, TElSFTPServerTextSeekEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPWriteFile(TElSimpleSFTPServerHandle _Handle, TElSFTPServerWriteEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPWriteFile(TElSimpleSFTPServerHandle _Handle, TElSFTPServerWriteEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPExtendedRequest(TElSimpleSFTPServerHandle _Handle, TElSFTPServerExtendedRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPExtendedRequest(TElSimpleSFTPServerHandle _Handle, TElSFTPServerExtendedRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPVersionChange(TElSimpleSFTPServerHandle _Handle, TElSftpServerVersionChangeEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPVersionChange(TElSimpleSFTPServerHandle _Handle, TElSftpServerVersionChangeEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPSendVendorID(TElSimpleSFTPServerHandle _Handle, TElSFTPServerSendVendorIDEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPSendVendorID(TElSimpleSFTPServerHandle _Handle, TElSFTPServerSendVendorIDEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPRequestFileHash(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestFileHashEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPRequestFileHash(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestFileHashEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPRequestFileHashByHandle(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestFileHashByHandleEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPRequestFileHashByHandle(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestFileHashByHandleEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPRequestAvailableSpace(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestAvailableSpaceEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPRequestAvailableSpace(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestAvailableSpaceEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPRequestStatVFS(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestStatVFSEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPRequestStatVFS(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestStatVFSEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPRequestHomeDirectory(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestHomeDirectoryEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPRequestHomeDirectory(TElSimpleSFTPServerHandle _Handle, TElSFTPServerRequestHomeDirectoryEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPCopyRemoteFile(TElSimpleSFTPServerHandle _Handle, TElSFTPServerCopyRemoteFileEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPCopyRemoteFile(TElSimpleSFTPServerHandle _Handle, TElSFTPServerCopyRemoteFileEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPCopyRemoteData(TElSimpleSFTPServerHandle _Handle, TElSFTPServerCopyRemoteDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPCopyRemoteData(TElSimpleSFTPServerHandle _Handle, TElSFTPServerCopyRemoteDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPMakeTempFolder(TElSimpleSFTPServerHandle _Handle, TElSFTPServerReturnPathEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPMakeTempFolder(TElSimpleSFTPServerHandle _Handle, TElSFTPServerReturnPathEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_get_OnSFTPRequestTempFolder(TElSimpleSFTPServerHandle _Handle, TElSFTPServerReturnPathEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_set_OnSFTPRequestTempFolder(TElSimpleSFTPServerHandle _Handle, TElSFTPServerReturnPathEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServer_Create(TComponentHandle AOwner, TElSimpleSFTPServerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLESFTPSERVER */

#ifdef SB_USE_CLASS_TELSIMPLESSHSFTPSEARCHREC
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHsftpSearchRec_get_Current(TElSimpleSSHsftpSearchRecHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHsftpSearchRec_set_Current(TElSimpleSSHsftpSearchRecHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHsftpSearchRec_get_InfoList(TElSimpleSSHsftpSearchRecHandle _Handle, TElVFSEntryInformationListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHsftpSearchRec_set_InfoList(TElSimpleSSHsftpSearchRecHandle _Handle, TElVFSEntryInformationListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHsftpSearchRec_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLESSHSFTPSEARCHREC */

#ifdef SB_USE_CLASS_TELSIMPLESFTPSERVERSESSIONTHREAD
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServerSessionThread_get_SFTPServer(TElSimpleSFTPServerSessionThreadHandle _Handle, TElSimpleSFTPServerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServerSessionThread_set_SFTPServer(TElSimpleSFTPServerSessionThreadHandle _Handle, TElSimpleSFTPServerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServerSessionThread_get_FSAdapter(TElSimpleSFTPServerSessionThreadHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSFTPServerSessionThread_Create(TElSimpleSSHServerSessionThreadHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLESFTPSERVERSESSIONTHREAD */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSimpleSFTPServer_ce_ptr;
extern zend_class_entry *TElSimpleSSHsftpSearchRec_ce_ptr;
extern zend_class_entry *TElSimpleSFTPServerSessionThread_ce_ptr;

void Register_TElSimpleSFTPServer(TSRMLS_D);
void Register_TElSimpleSSHsftpSearchRec(TSRMLS_D);
void Register_TElSimpleSFTPServerSessionThread(TSRMLS_D);
void Register_SBSimpleSFTPServer_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSIMPLESFTPSERVER */

