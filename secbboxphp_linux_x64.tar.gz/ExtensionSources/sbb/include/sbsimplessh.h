#ifndef __INC_SBSIMPLESSH
#define __INC_SBSIMPLESSH

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbcryptoprov.h"
#include "sbgssapi.h"
#include "sbsshcommon.h"
#include "sbsshterm.h"
#include "sbsocket.h"
#include "sbportknock.h"
#include "sbdnssecconsts.h"
#include "sbdnssectypes.h"
#include "sbsshclient.h"
#include "sbsshconstants.h"
#include "sbsshkeystorage.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSimpleSSHClientHandle;

typedef TElSimpleSSHClientHandle ElSimpleSSHClientHandle;

#ifdef SB_USE_CLASS_TELSIMPLESSHCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_Interrupt(TElSimpleSSHClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_Close(TElSimpleSSHClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_Close_1(TElSimpleSSHClientHandle _Handle, int8_t FlushPendingData);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_Open(TElSimpleSSHClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_RenegotiateCiphers(TElSimpleSSHClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_SendData(TElSimpleSSHClientHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_ReceiveData(TElSimpleSSHClientHandle _Handle, void * Buffer, int32_t * Size, void * StdErrBuffer, int32_t * StdErrSize);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_SendText(TElSimpleSSHClientHandle _Handle, const char * pcS, int32_t szS);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_ReceiveText(TElSimpleSSHClientHandle _Handle, char * pcText, int32_t * szText, char * pcStdErrText, int32_t * szStdErrText);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_ReceiveText_1(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_CanReceive(TElSimpleSSHClientHandle _Handle, int32_t Timeout, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_SendKeepAlive(TElSimpleSSHClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_ExecuteCommand(TElSimpleSSHClientHandle _Handle, const char * pcCmd, int32_t szCmd, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_ExecuteCommand_1(TElSimpleSSHClientHandle _Handle, const char * pcCmd, int32_t szCmd, int8_t RedirectStdErr, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_ExecuteCommand_2(TElSimpleSSHClientHandle _Handle, const char * pcCmd, int32_t szCmd, uint8_t pStdErrData[], int32_t * szStdErrData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_ExecuteCommand_3(TElSimpleSSHClientHandle _Handle, const char * pcCmd, int32_t szCmd, int8_t RedirectStdErr, int8_t KeepConnectionOpen, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_ExecuteCommand_4(TElSimpleSSHClientHandle _Handle, const char * pcCmd, int32_t szCmd, uint8_t pStdErrData[], int32_t * szStdErrData, int8_t KeepConnectionOpen, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_SendEOF(TElSimpleSSHClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_EncryptionAlgorithms(TElSimpleSSHClientHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_EncryptionAlgorithms(TElSimpleSSHClientHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_CompressionAlgorithms(TElSimpleSSHClientHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_CompressionAlgorithms(TElSimpleSSHClientHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_MacAlgorithms(TElSimpleSSHClientHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_MacAlgorithms(TElSimpleSSHClientHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_KexAlgorithms(TElSimpleSSHClientHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_KexAlgorithms(TElSimpleSSHClientHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_PublicKeyAlgorithms(TElSimpleSSHClientHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_PublicKeyAlgorithms(TElSimpleSSHClientHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_EncryptionAlgorithmPriorities(TElSimpleSSHClientHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_EncryptionAlgorithmPriorities(TElSimpleSSHClientHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_CompressionAlgorithmPriorities(TElSimpleSSHClientHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_CompressionAlgorithmPriorities(TElSimpleSSHClientHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_MacAlgorithmPriorities(TElSimpleSSHClientHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_MacAlgorithmPriorities(TElSimpleSSHClientHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_KexAlgorithmPriorities(TElSimpleSSHClientHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_KexAlgorithmPriorities(TElSimpleSSHClientHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_PublicKeyAlgorithmPriorities(TElSimpleSSHClientHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_PublicKeyAlgorithmPriorities(TElSimpleSSHClientHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_AuthTypePriorities(TElSimpleSSHClientHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_AuthTypePriorities(TElSimpleSSHClientHandle _Handle, int32_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_Active(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_ServerSoftwareName(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_Version(TElSimpleSSHClientHandle _Handle, TSSHVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_ServerCloseReason(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_EncryptionAlgorithmServerToClient(TElSimpleSSHClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_EncryptionAlgorithmClientToServer(TElSimpleSSHClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_CompressionAlgorithmServerToClient(TElSimpleSSHClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_CompressionAlgorithmClientToServer(TElSimpleSSHClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_MacAlgorithmServerToClient(TElSimpleSSHClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_MacAlgorithmClientToServer(TElSimpleSSHClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_KexAlgorithm(TElSimpleSSHClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_PublicKeyAlgorithm(TElSimpleSSHClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_KeyStorage(TElSimpleSSHClientHandle _Handle, TElSSHCustomKeyStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_KeyStorage(TElSimpleSSHClientHandle _Handle, TElSSHCustomKeyStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_TerminalInfo(TElSimpleSSHClientHandle _Handle, TElTerminalInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_TerminalInfo(TElSimpleSSHClientHandle _Handle, TElTerminalInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_ExitStatus(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_ExitSignal(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_ExitMessage(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_KbdIntName(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_KbdIntInstruction(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_ExtendedDataType(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_RequestPasswordChange(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_RequestPasswordChange(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_ServerKey(TElSimpleSSHClientHandle _Handle, TElSSHKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_UsingIPv6(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_TotalBytesSent(TElSimpleSSHClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_TotalBytesReceived(TElSimpleSSHClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_GSSMechanism(TElSimpleSSHClientHandle _Handle, TElGSSBaseMechanismHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_GSSMechanism(TElSimpleSSHClientHandle _Handle, TElGSSBaseMechanismHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_GSSHostName(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_GSSHostName(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_GSSDelegateCredentials(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_GSSDelegateCredentials(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_InternalSocket(TElSimpleSSHClientHandle _Handle, TElSocketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_Command(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_Command(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_Commands(TElSimpleSSHClientHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_Subsystem(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_Subsystem(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_AuthenticationTypes(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_AuthenticationTypes(TElSimpleSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_ClientHostname(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_ClientHostname(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_ClientUsername(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_ClientUsername(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_CompressionLevel(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_CompressionLevel(TElSimpleSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_ForceCompression(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_ForceCompression(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_SendCommandEOF(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_SendCommandEOF(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_Password(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_Password(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_SoftwareName(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_SoftwareName(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_Username(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_Username(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_Versions(TElSimpleSSHClientHandle _Handle, TSSHVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_Versions(TElSimpleSSHClientHandle _Handle, TSSHVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_Address(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_Address(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_Environment(TElSimpleSSHClientHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_RequestTerminal(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_RequestTerminal(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_TrustedKeys(TElSimpleSSHClientHandle _Handle, TElSSHCustomKeyStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_TrustedKeys(TElSimpleSSHClientHandle _Handle, TElSSHCustomKeyStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_CryptoProviderManager(TElSimpleSSHClientHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_CryptoProviderManager(TElSimpleSSHClientHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_DefaultWindowSize(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_DefaultWindowSize(TElSimpleSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_MinWindowSize(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_MinWindowSize(TElSimpleSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_MaxSSHPacketSize(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_MaxSSHPacketSize(TElSimpleSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_ThrottleControl(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_ThrottleControl(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_RaiseExceptionOnCommandTimeout(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_RaiseExceptionOnCommandTimeout(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_RaiseExceptionOnTunnelFailure(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_RaiseExceptionOnTunnelFailure(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_SocketBinding(TElSimpleSSHClientHandle _Handle, TElClientSocketBindingHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_SocketBinding(TElSimpleSSHClientHandle _Handle, TElClientSocketBindingHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_DNS(TElSimpleSSHClientHandle _Handle, TElDNSSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_DNS(TElSimpleSSHClientHandle _Handle, TElDNSSettingsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_PortKnock(TElSimpleSSHClientHandle _Handle, TElPortKnockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_PortKnock(TElSimpleSSHClientHandle _Handle, TElPortKnockHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_SocketSettings(TElSimpleSSHClientHandle _Handle, TElSocketSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_Port(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_Port(TElSimpleSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_SocketTimeout(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_SocketTimeout(TElSimpleSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_CommandTimeout(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_CommandTimeout(TElSimpleSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_SocksAuthentication(TElSimpleSSHClientHandle _Handle, TElSocksAuthenticationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_SocksAuthentication(TElSimpleSSHClientHandle _Handle, TElSocksAuthenticationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_SocksPassword(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_SocksPassword(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_SocksPort(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_SocksPort(TElSimpleSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_SocksResolveAddress(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_SocksResolveAddress(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_SocksServer(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_SocksServer(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_SocksUserCode(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_SocksUserCode(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_SocksVersion(TElSimpleSSHClientHandle _Handle, TElSocksVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_SocksVersion(TElSimpleSSHClientHandle _Handle, TElSocksVersionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_SocksUseIPv6(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_SocksUseIPv6(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_UseInternalSocket(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_UseInternalSocket(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_UseSocks(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_UseSocks(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_UseIPv6(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_UseIPv6(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_UseWebTunneling(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_UseWebTunneling(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_WebTunnelAddress(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_WebTunnelAddress(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_WebTunnelAuthentication(TElSimpleSSHClientHandle _Handle, TElWebTunnelAuthenticationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_WebTunnelAuthentication(TElSimpleSSHClientHandle _Handle, TElWebTunnelAuthenticationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_WebTunnelPassword(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_WebTunnelPassword(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_WebTunnelPort(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_WebTunnelPort(TElSimpleSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_WebTunnelUserId(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_WebTunnelUserId(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_WebTunnelRequestHeaders(TElSimpleSSHClientHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_WebTunnelResponseHeaders(TElSimpleSSHClientHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_WebTunnelResponseBody(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_ProxyResult(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_ErrorString(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_LocalAddress(TElSimpleSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_LocalAddress(TElSimpleSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_LocalPort(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_LocalPort(TElSimpleSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_SSHAuthOrder(TElSimpleSSHClientHandle _Handle, TSBSSHAuthOrderRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_SSHAuthOrder(TElSimpleSSHClientHandle _Handle, TSBSSHAuthOrderRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_CertAuthMode(TElSimpleSSHClientHandle _Handle, TSBSSHCertAuthModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_CertAuthMode(TElSimpleSSHClientHandle _Handle, TSBSSHCertAuthModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_AutoAdjustCiphers(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_AutoAdjustCiphers(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_UseUTF8(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_UseUTF8(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_CheckForIncomingDataOnSend(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_CheckForIncomingDataOnSend(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_NoCharacterEncoding(TElSimpleSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_NoCharacterEncoding(TElSimpleSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_AuthAttempts(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_AuthAttempts(TElSimpleSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_IncomingSpeedLimit(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_IncomingSpeedLimit(TElSimpleSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OutgoingSpeedLimit(TElSimpleSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OutgoingSpeedLimit(TElSimpleSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnAuthenticationKeyboard(TElSimpleSSHClientHandle _Handle, TSSHAuthenticationKeyboardEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnAuthenticationKeyboard(TElSimpleSSHClientHandle _Handle, TSSHAuthenticationKeyboardEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnAuthenticationFailed(TElSimpleSSHClientHandle _Handle, TSSHAuthenticationFailedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnAuthenticationFailed(TElSimpleSSHClientHandle _Handle, TSSHAuthenticationFailedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnAuthenticationSuccess(TElSimpleSSHClientHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnAuthenticationSuccess(TElSimpleSSHClientHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnAuthenticationStart(TElSimpleSSHClientHandle _Handle, TSSHAuthenticationStartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnAuthenticationStart(TElSimpleSSHClientHandle _Handle, TSSHAuthenticationStartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnAuthenticationAttempt(TElSimpleSSHClientHandle _Handle, TSSHAuthenticationAttemptEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnAuthenticationAttempt(TElSimpleSSHClientHandle _Handle, TSSHAuthenticationAttemptEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnBanner(TElSimpleSSHClientHandle _Handle, TSSHBannerEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnBanner(TElSimpleSSHClientHandle _Handle, TSSHBannerEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnCloseConnection(TElSimpleSSHClientHandle _Handle, TSSHCloseConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnCloseConnection(TElSimpleSSHClientHandle _Handle, TSSHCloseConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnError(TElSimpleSSHClientHandle _Handle, TSSHErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnError(TElSimpleSSHClientHandle _Handle, TSSHErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnTunnelError(TElSimpleSSHClientHandle _Handle, TSSHErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnTunnelError(TElSimpleSSHClientHandle _Handle, TSSHErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnKeyValidate(TElSimpleSSHClientHandle _Handle, TSSHKeyValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnKeyValidate(TElSimpleSSHClientHandle _Handle, TSSHKeyValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnReceive(TElSimpleSSHClientHandle _Handle, TSSHReceiveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnReceive(TElSimpleSSHClientHandle _Handle, TSSHReceiveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnSend(TElSimpleSSHClientHandle _Handle, TSSHSendEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnSend(TElSimpleSSHClientHandle _Handle, TSSHSendEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnPrivateKeyNeeded(TElSimpleSSHClientHandle _Handle, TSSHPrivateKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnPrivateKeyNeeded(TElSimpleSSHClientHandle _Handle, TSSHPrivateKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnSendCommandRequest(TElSimpleSSHClientHandle _Handle, TSSHCommandExecutionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnSendCommandRequest(TElSimpleSSHClientHandle _Handle, TSSHCommandExecutionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnCiphersNegotiated(TElSimpleSSHClientHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnCiphersNegotiated(TElSimpleSSHClientHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnPasswordChangeRequest(TElSimpleSSHClientHandle _Handle, TSSHPasswordChangeRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnPasswordChangeRequest(TElSimpleSSHClientHandle _Handle, TSSHPasswordChangeRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnKexInitReceived(TElSimpleSSHClientHandle _Handle, TSSHKexInitReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnKexInitReceived(TElSimpleSSHClientHandle _Handle, TSSHKexInitReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_MessageLoop(TElSimpleSSHClientHandle _Handle, TSSHMessageLoopEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_MessageLoop(TElSimpleSSHClientHandle _Handle, TSSHMessageLoopEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnDNSKeyNeeded(TElSimpleSSHClientHandle _Handle, TSBDNSKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnDNSKeyNeeded(TElSimpleSSHClientHandle _Handle, TSBDNSKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnDNSKeyValidate(TElSimpleSSHClientHandle _Handle, TSBDNSKeyValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnDNSKeyValidate(TElSimpleSSHClientHandle _Handle, TSBDNSKeyValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_get_OnDNSResolve(TElSimpleSSHClientHandle _Handle, TSBDNSResolveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_set_OnDNSResolve(TElSimpleSSHClientHandle _Handle, TSBDNSResolveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHClient_Create(TComponentHandle AOwner, TElSimpleSSHClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLESSHCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSimpleSSHClient_ce_ptr;

void Register_TElSimpleSSHClient(TSRMLS_D);
void Register_SBSimpleSSH_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSIMPLESSH */

