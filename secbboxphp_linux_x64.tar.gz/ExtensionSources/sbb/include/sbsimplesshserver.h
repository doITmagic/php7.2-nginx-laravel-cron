#ifndef __INC_SBSIMPLESSHSERVER
#define __INC_SBSIMPLESSHSERVER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbmath.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbrandom.h"
#include "sbchsconv.h"
#include "sbchsconvcharsets.h"
#include "sbchscjk.h"
#include "sbsshterm.h"
#include "sbsharedresource.h"
#include "sbsshconstants.h"
#include "sbsshkeystorage.h"
#include "sbsshutils.h"
#include "sbcryptoprov.h"
#include "sbsymmetriccrypto.h"
#include "sbcryptoprovmanager.h"
#include "sbhashfunction.h"
#include "sbsocket.h"
#include "sbsshcommon.h"
#include "sbsshpubkeycommon.h"
#include "sbsshhandlers.h"
#include "sbsshpubkeyhandler.h"
#include "sbsshforwardinghandlers.h"
#include "sbsshserver.h"
#include "sbconstants.h"
#include "sbusers.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SUnsupportedFunction 	"Unsupported"
#define SB_SSetKeyStoaregeError 	"Can not change KeyStorage on active server"
#define SB_SFailedBindSocket 	"Failed to bind server socket"

typedef TElClassHandle TElSimpleSSHServerHandle;

typedef TElClassHandle TElSSHUsersHandle;

typedef TElClassHandle TElCustomSessionThreadHandle;

typedef TElClassHandle TElSimpleSSHServerListeningThreadHandle;

typedef TElClassHandle TElSimpleSSHServerSessionThreadHandle;

typedef TElClassHandle TElSimpleSSHServerForwardingListeningThreadHandle;

typedef TElClassHandle TElSimpleSSHServerForwardingSessionThreadHandle;

#ifdef SB_USE_CLASS_TELSIMPLESSHSERVER
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_SocketSettings(TElSimpleSSHServerHandle _Handle, TElSocketSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_Active(TElSimpleSSHServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_Active(TElSimpleSSHServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_AllowShell(TElSimpleSSHServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_AllowShell(TElSimpleSSHServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_AllowCommand(TElSimpleSSHServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_AllowCommand(TElSimpleSSHServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_AllowClientForwarding(TElSimpleSSHServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_AllowClientForwarding(TElSimpleSSHServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_AllowServerForwarding(TElSimpleSSHServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_AllowServerForwarding(TElSimpleSSHServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_ForceCompression(TElSimpleSSHServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_ForceCompression(TElSimpleSSHServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_Host(TElSimpleSSHServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_Host(TElSimpleSSHServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_Port(TElSimpleSSHServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_Port(TElSimpleSSHServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_DataPortRangeFrom(TElSimpleSSHServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_DataPortRangeFrom(TElSimpleSSHServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_DataPortRangeTo(TElSimpleSSHServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_DataPortRangeTo(TElSimpleSSHServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_UseIPv6(TElSimpleSSHServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_UseIPv6(TElSimpleSSHServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_SessionTimeout(TElSimpleSSHServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_SessionTimeout(TElSimpleSSHServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_HandshakeTimeout(TElSimpleSSHServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_HandshakeTimeout(TElSimpleSSHServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_KeyStorage(TElSimpleSSHServerHandle _Handle, TElSSHCustomKeyStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_KeyStorage(TElSimpleSSHServerHandle _Handle, TElSSHCustomKeyStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_SSHAuthOrder(TElSimpleSSHServerHandle _Handle, TSBSSHAuthOrderRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_SSHAuthOrder(TElSimpleSSHServerHandle _Handle, TSBSSHAuthOrderRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_SoftwareName(TElSimpleSSHServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_SoftwareName(TElSimpleSSHServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_CompressionLevel(TElSimpleSSHServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_CompressionLevel(TElSimpleSSHServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_AuthenticationTypes(TElSimpleSSHServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_AuthenticationTypes(TElSimpleSSHServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_CloseIfNoActiveTunnels(TElSimpleSSHServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_CloseIfNoActiveTunnels(TElSimpleSSHServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_UseUTF8(TElSimpleSSHServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_UseUTF8(TElSimpleSSHServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_CryptoProviderManager(TElSimpleSSHServerHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_CryptoProviderManager(TElSimpleSSHServerHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_NoCharacterEncoding(TElSimpleSSHServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_NoCharacterEncoding(TElSimpleSSHServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_LocalCharset(TElSimpleSSHServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_LocalCharset(TElSimpleSSHServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_RemoteCharset(TElSimpleSSHServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_RemoteCharset(TElSimpleSSHServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_ObfuscateHandshake(TElSimpleSSHServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_ObfuscateHandshake(TElSimpleSSHServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_ObfuscationPassword(TElSimpleSSHServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_ObfuscationPassword(TElSimpleSSHServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_Users(TElSimpleSSHServerHandle _Handle, TElSSHUsersHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnAuthAttempt(TElSimpleSSHServerHandle _Handle, TSSHAuthAttemptEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnAuthAttempt(TElSimpleSSHServerHandle _Handle, TSSHAuthAttemptEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnAuthFailed(TElSimpleSSHServerHandle _Handle, TSSHAuthenticationFailedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnAuthFailed(TElSimpleSSHServerHandle _Handle, TSSHAuthenticationFailedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnAuthBanner(TElSimpleSSHServerHandle _Handle, TSSHAuthBannerEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnAuthBanner(TElSimpleSSHServerHandle _Handle, TSSHAuthBannerEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnAuthPassword(TElSimpleSSHServerHandle _Handle, TSSHAuthPasswordEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnAuthPassword(TElSimpleSSHServerHandle _Handle, TSSHAuthPasswordEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnAuthPasswordChange(TElSimpleSSHServerHandle _Handle, TSSHAuthPasswordChangeEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnAuthPasswordChange(TElSimpleSSHServerHandle _Handle, TSSHAuthPasswordChangeEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnAuthPublicKey(TElSimpleSSHServerHandle _Handle, TSSHAuthPublicKeyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnAuthPublicKey(TElSimpleSSHServerHandle _Handle, TSSHAuthPublicKeyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnAuthHostbased(TElSimpleSSHServerHandle _Handle, TSSHAuthHostbasedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnAuthHostbased(TElSimpleSSHServerHandle _Handle, TSSHAuthHostbasedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnAuthKeyboard(TElSimpleSSHServerHandle _Handle, TSSHAuthKeyboardEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnAuthKeyboard(TElSimpleSSHServerHandle _Handle, TSSHAuthKeyboardEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnAuthKeyboardResponse(TElSimpleSSHServerHandle _Handle, TSSHAuthKeyboardResponseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnAuthKeyboardResponse(TElSimpleSSHServerHandle _Handle, TSSHAuthKeyboardResponseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnFurtherAuthNeeded(TElSimpleSSHServerHandle _Handle, TSSHFurtherAuthNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnFurtherAuthNeeded(TElSimpleSSHServerHandle _Handle, TSSHFurtherAuthNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnBeforeOpenSession(TElSimpleSSHServerHandle _Handle, TSSHBeforeOpenSessionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnBeforeOpenSession(TElSimpleSSHServerHandle _Handle, TSSHBeforeOpenSessionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnBeforeOpenShell(TElSimpleSSHServerHandle _Handle, TSSHBeforeOpenShellEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnBeforeOpenShell(TElSimpleSSHServerHandle _Handle, TSSHBeforeOpenShellEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnBeforeOpenCommand(TElSimpleSSHServerHandle _Handle, TSSHBeforeOpenCommandEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnBeforeOpenCommand(TElSimpleSSHServerHandle _Handle, TSSHBeforeOpenCommandEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnBeforeOpenSubsystem(TElSimpleSSHServerHandle _Handle, TSSHBeforeOpenSubsystemEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnBeforeOpenSubsystem(TElSimpleSSHServerHandle _Handle, TSSHBeforeOpenSubsystemEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnBeforeOpenClientForwarding(TElSimpleSSHServerHandle _Handle, TSSHBeforeOpenClientForwardingEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnBeforeOpenClientForwarding(TElSimpleSSHServerHandle _Handle, TSSHBeforeOpenClientForwardingEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnOpenSession(TElSimpleSSHServerHandle _Handle, TSSHOpenSessionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnOpenSession(TElSimpleSSHServerHandle _Handle, TSSHOpenSessionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnOpenShell(TElSimpleSSHServerHandle _Handle, TSSHOpenShellEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnOpenShell(TElSimpleSSHServerHandle _Handle, TSSHOpenShellEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnOpenCommand(TElSimpleSSHServerHandle _Handle, TSSHOpenCommandEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnOpenCommand(TElSimpleSSHServerHandle _Handle, TSSHOpenCommandEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnOpenSubsystem(TElSimpleSSHServerHandle _Handle, TSSHOpenSubsystemEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnOpenSubsystem(TElSimpleSSHServerHandle _Handle, TSSHOpenSubsystemEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnOpenClientForwarding(TElSimpleSSHServerHandle _Handle, TSSHOpenClientForwardingEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnOpenClientForwarding(TElSimpleSSHServerHandle _Handle, TSSHOpenClientForwardingEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnOpenServerForwarding(TElSimpleSSHServerHandle _Handle, TSSHOpenServerForwardingEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnOpenServerForwarding(TElSimpleSSHServerHandle _Handle, TSSHOpenServerForwardingEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnServerForwardingFailed(TElSimpleSSHServerHandle _Handle, TSSHServerForwardingFailedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnServerForwardingFailed(TElSimpleSSHServerHandle _Handle, TSSHServerForwardingFailedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnServerForwardingRequest(TElSimpleSSHServerHandle _Handle, TSSHServerForwardingRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnServerForwardingRequest(TElSimpleSSHServerHandle _Handle, TSSHServerForwardingRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnServerForwardingCancel(TElSimpleSSHServerHandle _Handle, TSSHServerForwardingCancelEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnServerForwardingCancel(TElSimpleSSHServerHandle _Handle, TSSHServerForwardingCancelEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnSpecialMessageReceived(TElSimpleSSHServerHandle _Handle, TSSHSpecialMessageEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnSpecialMessageReceived(TElSimpleSSHServerHandle _Handle, TSSHSpecialMessageEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnKexInitReceived(TElSimpleSSHServerHandle _Handle, TSSHKexInitReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnKexInitReceived(TElSimpleSSHServerHandle _Handle, TSSHKexInitReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnEnvironmentVariableReceived(TElSimpleSSHServerHandle _Handle, TSSHEnvironmentVariableReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnEnvironmentVariableReceived(TElSimpleSSHServerHandle _Handle, TSSHEnvironmentVariableReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnOpenConnection(TElSimpleSSHServerHandle _Handle, TSSHOpenConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnOpenConnection(TElSimpleSSHServerHandle _Handle, TSSHOpenConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnCloseConnection(TElSimpleSSHServerHandle _Handle, TSSHCloseConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnCloseConnection(TElSimpleSSHServerHandle _Handle, TSSHCloseConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnError(TElSimpleSSHServerHandle _Handle, TSSHErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnError(TElSimpleSSHServerHandle _Handle, TSSHErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnPubKeyReceive(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyReceiveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnPubKeyReceive(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyReceiveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnPubKeySend(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeySendEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnPubKeySend(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeySendEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnPubKeyClose(TElSimpleSSHServerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnPubKeyClose(TElSimpleSSHServerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnPubKeyError(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnPubKeyError(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnPubKeyOpen(TElSimpleSSHServerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnPubKeyOpen(TElSimpleSSHServerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnPubKeyStatus(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyStatusEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnPubKeyStatus(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyStatusEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnPubKeyAdd(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyAddEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnPubKeyAdd(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyAddEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnPubKeyRemove(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyRemoveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnPubKeyRemove(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyRemoveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnPubKeyList(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyListEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnPubKeyList(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyListEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnPubKeyListAttributes(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyListAttributesEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnPubKeyListAttributes(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyListAttributesEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_get_OnPubKeyAttributeSupported(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyAttrubuteSupportedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_set_OnPubKeyAttributeSupported(TElSimpleSSHServerHandle _Handle, TSBSSHPublicKeyAttrubuteSupportedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServer_Create(TComponentHandle AOwner, TElSimpleSSHServerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLESSHSERVER */

#ifdef SB_USE_CLASS_TELSSHUSERS
SB_IMPORT uint32_t SB_APIENTRY TElSSHUsers_AddSSHUser(TElSSHUsersHandle _Handle, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword, TElSSHKeyHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUsers_AddSSHUser_1(TElSSHUsersHandle _Handle, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword, TElSSHKeyHandle Key, const char * pcBasePath, int32_t szBasePath);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUsers_UpdateSSHUser(TElSSHUsersHandle _Handle, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword, TElSSHKeyHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUsers_FindSSHUser(TElSSHUsersHandle _Handle, const char * pcUserName, int32_t szUserName, TElSSHUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUsers_IsValidSSHKey(TElSSHUsersHandle _Handle, const char * pcUserName, int32_t szUserName, TElSSHKeyHandle Key, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUsers_Create(TComponentHandle AOwner, TElUsersHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHUSERS */

#ifdef SB_USE_CLASS_TELCUSTOMSESSIONTHREAD
SB_IMPORT uint32_t SB_APIENTRY TElCustomSessionThread_get_OnSessionTerminate(TElCustomSessionThreadHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSessionThread_set_OnSessionTerminate(TElCustomSessionThreadHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
#ifdef SB_DEFINE_FPC_SPECIFIC_METHODS
SB_IMPORT uint32_t SB_APIENTRY TElCustomSessionThread_Create(int8_t CreateSuspended, uint32_t StackSize, TThreadHandle * OutResult);
#endif /* SB_DEFINE_FPC_SPECIFIC_METHODS */
#endif /* SB_USE_CLASS_TELCUSTOMSESSIONTHREAD */

#ifdef SB_USE_CLASS_TELSIMPLESSHSERVERLISTENINGTHREAD
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerListeningThread_get_Owner(TElSimpleSSHServerListeningThreadHandle _Handle, TElSimpleSSHServerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerListeningThread_set_Owner(TElSimpleSSHServerListeningThreadHandle _Handle, TElSimpleSSHServerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerListeningThread_get_Socket(TElSimpleSSHServerListeningThreadHandle _Handle, TElSocketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerListeningThread_set_Socket(TElSimpleSSHServerListeningThreadHandle _Handle, TElSocketHandle Value);
#ifdef SB_DEFINE_FPC_SPECIFIC_METHODS
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerListeningThread_Create(int8_t CreateSuspended, uint32_t StackSize, TThreadHandle * OutResult);
#endif /* SB_DEFINE_FPC_SPECIFIC_METHODS */
#endif /* SB_USE_CLASS_TELSIMPLESSHSERVERLISTENINGTHREAD */

#ifdef SB_USE_CLASS_TELSIMPLESSHSERVERSESSIONTHREAD
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerSessionThread_get_Owner(TElSimpleSSHServerSessionThreadHandle _Handle, TElSimpleSSHServerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerSessionThread_set_Owner(TElSimpleSSHServerSessionThreadHandle _Handle, TElSimpleSSHServerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerSessionThread_get_Socket(TElSimpleSSHServerSessionThreadHandle _Handle, TElSocketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerSessionThread_set_Socket(TElSimpleSSHServerSessionThreadHandle _Handle, TElSocketHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerSessionThread_get_SSHServer(TElSimpleSSHServerSessionThreadHandle _Handle, TElSSHServerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerSessionThread_get_SessionTimeout(TElSimpleSSHServerSessionThreadHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerSessionThread_set_SessionTimeout(TElSimpleSSHServerSessionThreadHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerSessionThread_get_HandshakeTimeout(TElSimpleSSHServerSessionThreadHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerSessionThread_set_HandshakeTimeout(TElSimpleSSHServerSessionThreadHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerSessionThread_Create(TElSimpleSSHServerSessionThreadHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLESSHSERVERSESSIONTHREAD */

#ifdef SB_USE_CLASS_TELSIMPLESSHSERVERFORWARDINGLISTENINGTHREAD
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerForwardingListeningThread_get_Owner(TElSimpleSSHServerForwardingListeningThreadHandle _Handle, TElSimpleSSHServerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerForwardingListeningThread_set_Owner(TElSimpleSSHServerForwardingListeningThreadHandle _Handle, TElSimpleSSHServerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerForwardingListeningThread_get_Socket(TElSimpleSSHServerForwardingListeningThreadHandle _Handle, TElSocketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerForwardingListeningThread_get_SSHServer(TElSimpleSSHServerForwardingListeningThreadHandle _Handle, TElSSHServerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerForwardingListeningThread_set_SSHServer(TElSimpleSSHServerForwardingListeningThreadHandle _Handle, TElSSHServerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerForwardingListeningThread_Create(TElSimpleSSHServerForwardingListeningThreadHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLESSHSERVERFORWARDINGLISTENINGTHREAD */

#ifdef SB_USE_CLASS_TELSIMPLESSHSERVERFORWARDINGSESSIONTHREAD
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerForwardingSessionThread_InternalExecute(TElSimpleSSHServerForwardingSessionThreadHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerForwardingSessionThread_get_Connection(TElSimpleSSHServerForwardingSessionThreadHandle _Handle, TElSSHTunnelConnectionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerForwardingSessionThread_set_Connection(TElSimpleSSHServerForwardingSessionThreadHandle _Handle, TElSSHTunnelConnectionHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerForwardingSessionThread_get_Handler(TElSimpleSSHServerForwardingSessionThreadHandle _Handle, TElBuiltinServerTCPForwardingSSHSubsystemHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerForwardingSessionThread_get_Socket(TElSimpleSSHServerForwardingSessionThreadHandle _Handle, TElSocketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSHServerForwardingSessionThread_Create(TElSocketHandle Socket, TElSimpleSSHServerForwardingSessionThreadHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLESSHSERVERFORWARDINGSESSIONTHREAD */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSimpleSSHServer_ce_ptr;
extern zend_class_entry *TElSSHUsers_ce_ptr;
extern zend_class_entry *TElCustomSessionThread_ce_ptr;
extern zend_class_entry *TElSimpleSSHServerListeningThread_ce_ptr;
extern zend_class_entry *TElSimpleSSHServerSessionThread_ce_ptr;
extern zend_class_entry *TElSimpleSSHServerForwardingListeningThread_ce_ptr;
extern zend_class_entry *TElSimpleSSHServerForwardingSessionThread_ce_ptr;

void Register_TElSimpleSSHServer(TSRMLS_D);
void Register_TElSSHUsers(TSRMLS_D);
void Register_TElCustomSessionThread(TSRMLS_D);
void Register_TElSimpleSSHServerListeningThread(TSRMLS_D);
void Register_TElSimpleSSHServerSessionThread(TSRMLS_D);
void Register_TElSimpleSSHServerForwardingListeningThread(TSRMLS_D);
void Register_TElSimpleSSHServerForwardingSessionThread(TSRMLS_D);
void Register_SBSimpleSSHServer_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSIMPLESSHSERVER */

