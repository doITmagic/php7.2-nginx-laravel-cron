#ifndef __INC_SBSIMPLESSL
#define __INC_SBSIMPLESSL

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbsocket.h"
#include "sbportknock.h"
#include "sbsslclient.h"
#include "sbsslcommon.h"
#include "sbsslconstants.h"
#include "sbdnssecconsts.h"
#include "sbdnssectypes.h"
#include "sbx509.h"
#include "sbcustomcertstorage.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElCustomSimpleSSLClientHandle;

typedef TElCustomSimpleSSLClientHandle ElCustomSimpleSSLClientHandle;

typedef TElClassHandle TElSimpleSSLClientHandle;

typedef TElSimpleSSLClientHandle ElSimpleSSLClientHandle;

#ifdef SB_USE_CLASS_TELCUSTOMSIMPLESSLCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_Interrupt(TElCustomSimpleSSLClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_Close(TElCustomSimpleSSLClientHandle _Handle, int8_t Silent);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_Open(TElCustomSimpleSSLClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_SendText(TElCustomSimpleSSLClientHandle _Handle, const char * pcS, int32_t szS);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_Join(TElCustomSimpleSSLClientHandle _Handle, TElCustomSimpleSSLClientHandle Client);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_SendData(TElCustomSimpleSSLClientHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_ReceiveData(TElCustomSimpleSSLClientHandle _Handle, void * Buffer, int32_t * Size, int8_t ReadAll);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_SendKeepAlive(TElCustomSimpleSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_InternalValidate(TElCustomSimpleSSLClientHandle _Handle, TSBCertificateValidityRaw * Validity, TSBCertificateValidityReasonRaw * Reason);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_CanReceive(TElCustomSimpleSSLClientHandle _Handle, int32_t Timeout, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_RenegotiateCiphers(TElCustomSimpleSSLClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_RemoteHost(TElCustomSimpleSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_RemoteIP(TElCustomSimpleSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_Active(TElCustomSimpleSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_CipherSuite(TElCustomSimpleSSLClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_CipherSuites(TElCustomSimpleSSLClientHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_CipherSuites(TElCustomSimpleSSLClientHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_CipherSuitePriorities(TElCustomSimpleSSLClientHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_CipherSuitePriorities(TElCustomSimpleSSLClientHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_CompressionAlgorithm(TElCustomSimpleSSLClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_CompressionAlgorithms(TElCustomSimpleSSLClientHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_CompressionAlgorithms(TElCustomSimpleSSLClientHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_CurrentVersion(TElCustomSimpleSSLClientHandle _Handle, TSBVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_Extensions(TElCustomSimpleSSLClientHandle _Handle, TElClientSSLExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_PeerExtensions(TElCustomSimpleSSLClientHandle _Handle, TElCustomSSLExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_TotalBytesSent(TElCustomSimpleSSLClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_TotalBytesReceived(TElCustomSimpleSSLClientHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_ProxyResult(TElCustomSimpleSSLClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_UsingIPv6(TElCustomSimpleSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_InternalSocket(TElCustomSimpleSSLClientHandle _Handle, TElSocketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_Control(TElCustomSimpleSSLClientHandle _Handle, TElSSLClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_ConnectionInfo(TElCustomSimpleSSLClientHandle _Handle, TElSSLConnectionInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_CertStorage(TElCustomSimpleSSLClientHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_CertStorage(TElCustomSimpleSSLClientHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_ClientCertStorage(TElCustomSimpleSSLClientHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_ClientCertStorage(TElCustomSimpleSSLClientHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_Client(TElCustomSimpleSSLClientHandle _Handle, TElSSLClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_SocketSettings(TElCustomSimpleSSLClientHandle _Handle, TElSocketSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_SocketTimeout(TElCustomSimpleSSLClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_SocketTimeout(TElCustomSimpleSSLClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_Versions(TElCustomSimpleSSLClientHandle _Handle, TSBVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_Versions(TElCustomSimpleSSLClientHandle _Handle, TSBVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_SSLOptions(TElCustomSimpleSSLClientHandle _Handle, TSBSSLOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_SSLOptions(TElCustomSimpleSSLClientHandle _Handle, TSBSSLOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_LocalAddress(TElCustomSimpleSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_LocalAddress(TElCustomSimpleSSLClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_LocalPort(TElCustomSimpleSSLClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_LocalPort(TElCustomSimpleSSLClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_IncomingSpeedLimit(TElCustomSimpleSSLClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_IncomingSpeedLimit(TElCustomSimpleSSLClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_OutgoingSpeedLimit(TElCustomSimpleSSLClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_OutgoingSpeedLimit(TElCustomSimpleSSLClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_UseSSLSessionResumption(TElCustomSimpleSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_UseSSLSessionResumption(TElCustomSimpleSSLClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_ForceResumeIfDestinationChanges(TElCustomSimpleSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_ForceResumeIfDestinationChanges(TElCustomSimpleSSLClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_UseLocalPortForwarding(TElCustomSimpleSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_UseLocalPortForwarding(TElCustomSimpleSSLClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_LocalForwardingPort(TElCustomSimpleSSLClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_LocalForwardingPort(TElCustomSimpleSSLClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_SocksAuthentication(TElCustomSimpleSSLClientHandle _Handle, TElSocksAuthenticationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_SocksAuthentication(TElCustomSimpleSSLClientHandle _Handle, TElSocksAuthenticationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_SocksPassword(TElCustomSimpleSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_SocksPassword(TElCustomSimpleSSLClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_SocksPort(TElCustomSimpleSSLClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_SocksPort(TElCustomSimpleSSLClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_SocksResolveAddress(TElCustomSimpleSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_SocksResolveAddress(TElCustomSimpleSSLClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_SocksServer(TElCustomSimpleSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_SocksServer(TElCustomSimpleSSLClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_SocksUserCode(TElCustomSimpleSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_SocksUserCode(TElCustomSimpleSSLClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_SocksVersion(TElCustomSimpleSSLClientHandle _Handle, TElSocksVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_SocksVersion(TElCustomSimpleSSLClientHandle _Handle, TElSocksVersionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_SocksUseIPv6(TElCustomSimpleSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_SocksUseIPv6(TElCustomSimpleSSLClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_UseSocks(TElCustomSimpleSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_UseSocks(TElCustomSimpleSSLClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_UseWebTunneling(TElCustomSimpleSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_UseWebTunneling(TElCustomSimpleSSLClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_WebTunnelAddress(TElCustomSimpleSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_WebTunnelAddress(TElCustomSimpleSSLClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_WebTunnelAuthentication(TElCustomSimpleSSLClientHandle _Handle, TElWebTunnelAuthenticationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_WebTunnelAuthentication(TElCustomSimpleSSLClientHandle _Handle, TElWebTunnelAuthenticationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_WebTunnelPassword(TElCustomSimpleSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_WebTunnelPassword(TElCustomSimpleSSLClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_WebTunnelPort(TElCustomSimpleSSLClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_WebTunnelPort(TElCustomSimpleSSLClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_WebTunnelUserId(TElCustomSimpleSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_WebTunnelUserId(TElCustomSimpleSSLClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_WebTunnelRequestHeaders(TElCustomSimpleSSLClientHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_WebTunnelResponseHeaders(TElCustomSimpleSSLClientHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_WebTunnelResponseBody(TElCustomSimpleSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_SocketBinding(TElCustomSimpleSSLClientHandle _Handle, TElClientSocketBindingHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_SocketBinding(TElCustomSimpleSSLClientHandle _Handle, TElClientSocketBindingHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_SRPUserName(TElCustomSimpleSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_SRPUserName(TElCustomSimpleSSLClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_SRPPassword(TElCustomSimpleSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_SRPPassword(TElCustomSimpleSSLClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_RenegotiationAttackPreventionMode(TElCustomSimpleSSLClientHandle _Handle, TSBRenegotiationAttackPreventionModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_RenegotiationAttackPreventionMode(TElCustomSimpleSSLClientHandle _Handle, TSBRenegotiationAttackPreventionModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_PortKnock(TElCustomSimpleSSLClientHandle _Handle, TElPortKnockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_PortKnock(TElCustomSimpleSSLClientHandle _Handle, TElPortKnockHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_DNS(TElCustomSimpleSSLClientHandle _Handle, TElDNSSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_DNS(TElCustomSimpleSSLClientHandle _Handle, TElDNSSettingsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_MessageLoop(TElCustomSimpleSSLClientHandle _Handle, TElMessageLoopEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_MessageLoop(TElCustomSimpleSSLClientHandle _Handle, TElMessageLoopEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_OnDNSKeyNeeded(TElCustomSimpleSSLClientHandle _Handle, TSBDNSKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_OnDNSKeyNeeded(TElCustomSimpleSSLClientHandle _Handle, TSBDNSKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_OnDNSKeyValidate(TElCustomSimpleSSLClientHandle _Handle, TSBDNSKeyValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_OnDNSKeyValidate(TElCustomSimpleSSLClientHandle _Handle, TSBDNSKeyValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_get_OnDNSResolve(TElCustomSimpleSSLClientHandle _Handle, TSBDNSResolveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_set_OnDNSResolve(TElCustomSimpleSSLClientHandle _Handle, TSBDNSResolveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSimpleSSLClient_Create(TComponentHandle AOwner, TElCustomSimpleSSLClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMSIMPLESSLCLIENT */

#ifdef SB_USE_CLASS_TELSIMPLESSLCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_StartTLS(TElSimpleSSLClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_StopTLS(TElSimpleSSLClientHandle _Handle, int8_t Silent);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_Address(TElSimpleSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_Address(TElSimpleSSLClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_Enabled(TElSimpleSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_Enabled(TElSimpleSSLClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_Port(TElSimpleSSLClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_Port(TElSimpleSSLClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_UseIPv6(TElSimpleSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_UseIPv6(TElSimpleSSLClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_UseInternalSocket(TElSimpleSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_UseInternalSocket(TElSimpleSSLClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_OnCertificateChoose(TElSimpleSSLClientHandle _Handle, TSBChooseCertificateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_OnCertificateChoose(TElSimpleSSLClientHandle _Handle, TSBChooseCertificateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_OnCertificateNeededEx(TElSimpleSSLClientHandle _Handle, TSBCertificateNeededExEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_OnCertificateNeededEx(TElSimpleSSLClientHandle _Handle, TSBCertificateNeededExEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_OnCertificateValidate(TElSimpleSSLClientHandle _Handle, TSBCertificateValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_OnCertificateValidate(TElSimpleSSLClientHandle _Handle, TSBCertificateValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_OnCiphersNegotiated(TElSimpleSSLClientHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_OnCiphersNegotiated(TElSimpleSSLClientHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_OnCloseConnection(TElSimpleSSLClientHandle _Handle, TSBCloseConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_OnCloseConnection(TElSimpleSSLClientHandle _Handle, TSBCloseConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_OnError(TElSimpleSSLClientHandle _Handle, TSBErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_OnError(TElSimpleSSLClientHandle _Handle, TSBErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_OnReceive(TElSimpleSSLClientHandle _Handle, TSBReceiveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_OnReceive(TElSimpleSSLClientHandle _Handle, TSBReceiveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_OnSend(TElSimpleSSLClientHandle _Handle, TSBSendEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_OnSend(TElSimpleSSLClientHandle _Handle, TSBSendEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_OnExtensionsReceived(TElSimpleSSLClientHandle _Handle, TSBExtensionsReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_OnExtensionsReceived(TElSimpleSSLClientHandle _Handle, TSBExtensionsReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_OnExtensionsPrepared(TElSimpleSSLClientHandle _Handle, TSBExtensionsPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_OnExtensionsPrepared(TElSimpleSSLClientHandle _Handle, TSBExtensionsPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_OnCertificateStatus(TElSimpleSSLClientHandle _Handle, TSBCertificateStatusEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_OnCertificateStatus(TElSimpleSSLClientHandle _Handle, TSBCertificateStatusEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_OnKeyNeeded(TElSimpleSSLClientHandle _Handle, TSBClientKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_OnKeyNeeded(TElSimpleSSLClientHandle _Handle, TSBClientKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_get_OnRenegotiationRequest(TElSimpleSSLClientHandle _Handle, TSBRenegotiationRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_set_OnRenegotiationRequest(TElSimpleSSLClientHandle _Handle, TSBRenegotiationRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSSLClient_Create(TComponentHandle AOwner, TElCustomSimpleSSLClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLESSLCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElCustomSimpleSSLClient_ce_ptr;
extern zend_class_entry *TElSimpleSSLClient_ce_ptr;

void Register_TElCustomSimpleSSLClient(TSRMLS_D);
void Register_TElSimpleSSLClient(TSRMLS_D);
void Register_SBSimpleSSL_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSIMPLESSL */

