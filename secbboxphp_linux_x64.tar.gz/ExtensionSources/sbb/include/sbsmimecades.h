#ifndef __INC_SBSMIMECADES
#define __INC_SBSMIMECADES

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstreams.h"
#include "sbmime.h"
#include "sbmimestream.h"
#include "sbsmimecore.h"
#include "sbcustomcertstorage.h"
#include "sbcertvalidator.h"
#include "sbx509.h"
#include "sbpkicommon.h"
#include "sbcades.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SMIME_ERROR_CADES_BASE 	82176
#define SB_SMIME_ERROR_NO_CADESREVOCATION_INFO 	82177

typedef TElClassHandle TElMessagePartHandlerSMimeCAdESHandle;

typedef void (SB_CALLBACK *TSBSMimeCAdESSign)(void * _ObjectData, TObjectHandle Sender, TElCAdESSignatureProcessorHandle Processor);

typedef void (SB_CALLBACK *TSBSMimeCAdESValidate)(void * _ObjectData, TObjectHandle Sender, TElCAdESSignatureProcessorHandle Processor);

#ifdef SB_USE_CLASS_TELMESSAGEPARTHANDLERSMIMECADES
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMimeCAdES_GetDescription(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMimeCAdES_GetDescription_1(TElMessagePartHandlerSMimeCAdESHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMimeCAdES_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMimeCAdES_get_UseCAdES(TElMessagePartHandlerSMimeCAdESHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMimeCAdES_set_UseCAdES(TElMessagePartHandlerSMimeCAdESHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMimeCAdES_get_CAdESValidity(TElMessagePartHandlerSMimeCAdESHandle _Handle, TSBCAdESSignatureValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMimeCAdES_get_CAdESErrorCode(TElMessagePartHandlerSMimeCAdESHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMimeCAdES_get_CAdESCertValidity(TElMessagePartHandlerSMimeCAdESHandle _Handle, TSBCertificateValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMimeCAdES_get_CAdESReason(TElMessagePartHandlerSMimeCAdESHandle _Handle, TSBCertificateValidityReasonRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMimeCAdES_get_OnSign(TElMessagePartHandlerSMimeCAdESHandle _Handle, TSBSMimeCAdESSign * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMimeCAdES_set_OnSign(TElMessagePartHandlerSMimeCAdESHandle _Handle, TSBSMimeCAdESSign pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMimeCAdES_get_OnValidate(TElMessagePartHandlerSMimeCAdESHandle _Handle, TSBSMimeCAdESValidate * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMimeCAdES_set_OnValidate(TElMessagePartHandlerSMimeCAdESHandle _Handle, TSBSMimeCAdESValidate pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMimeCAdES_Create(TObjectHandle aParams, TElMessagePartHandlerSMimeCAdESHandle * OutResult);
#endif /* SB_USE_CLASS_TELMESSAGEPARTHANDLERSMIMECADES */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElMessagePartHandlerSMimeCAdES_ce_ptr;

void SB_CALLBACK TSBSMimeCAdESSignRaw(void * _ObjectData, TObjectHandle Sender, TElCAdESSignatureProcessorHandle Processor);
void SB_CALLBACK TSBSMimeCAdESValidateRaw(void * _ObjectData, TObjectHandle Sender, TElCAdESSignatureProcessorHandle Processor);
void Register_TElMessagePartHandlerSMimeCAdES(TSRMLS_D);
void Register_SBSMIMECAdES_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSMIMECADES */

