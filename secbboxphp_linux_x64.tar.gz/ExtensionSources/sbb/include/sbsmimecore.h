#ifndef __INC_SBSMIMECORE
#define __INC_SBSMIMECORE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbmimestream.h"
#include "sbmime.h"
#include "sbcryptoprov.h"
#include "sbmessages.h"
#include "sbcustomcertstorage.h"
#include "sbx509.h"
#include "sbx509ext.h"
#include "sbstringlist.h"
#ifdef SB_WINDOWS
#include "sbwincertstorage.h"
#endif
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbchsunicode.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbpkcs7.h"
#include "sbsimplemime.h"
#include "sbsmimesignatures.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SMIME_STR_ALG_MD5 	"md5"
#define SB_SMIME_STR_ALG_SHA1 	"sha1"
#define SB_SMIME_STR_ALG_SHA256 	"sha256"
#define SB_SMIME_STR_ALG_SHA384 	"sha384"
#define SB_SMIME_STR_ALG_SHA512 	"sha512"
#define SB_SMIME_STR_ALG_SHA3_256 	"sha3-256"
#define SB_SMIME_STR_ALG_SHA3_384 	"sha3-384"
#define SB_SMIME_STR_ALG_SHA3_512 	"sha3-512"
#define SB_SMIME_STR_ALG_BLAKE2S_128 	"blake2s-128"
#define SB_SMIME_STR_ALG_BLAKE2S_160 	"blake2s-160"
#define SB_SMIME_STR_ALG_BLAKE2S_224 	"blake2s-224"
#define SB_SMIME_STR_ALG_BLAKE2S_256 	"blake2s-256"
#define SB_SMIME_STR_ALG_BLAKE2B_160 	"blake2b-160"
#define SB_SMIME_STR_ALG_BLAKE2B_256 	"blake2b-256"
#define SB_SMIME_STR_ALG_BLAKE2B_384 	"blake2b-384"
#define SB_SMIME_STR_ALG_BLAKE2B_512 	"blake2b-512"
#define SB_SMIME_ERROR_BASE 	81920
#define SB_SMIME_ERROR_NO_SIGNING_CERTIFICATE_STORAGE 	81921
#define SB_SMIME_ERROR_NO_SIGNING_CERTIFICATE 	81922
#define SB_SMIME_ERROR_HEADER_ASSEMBLING_FAILED 	81923
#define SB_SMIME_ERROR_NO_ENCRYPTION_CERTIFICATE_STORAGE 	81924
#define SB_SMIME_ERROR_NO_ENCRYPTION_CERTIFICATE 	81925
#define SB_SMIME_ERROR_ENCRYPTION_FAILED 	81926
#define SB_SMIME_ERROR_UNKNOWN_DIGEST_ALGORITHM 	81927
#define SB_SMIME_ERROR_SIGNING_FAILED 	81928
#define SB_CEnvelopedHeader 	"Content-Type: application/pkcs7-mime; smime-type=enveloped-data;\r\n\tname=smime.p7m; charset=\"%s\"\r\nContent-Transfer-Encoding: base64\r\nContent-Disposition: attachment; filename=smime.p7m\r\n"
#define SB_CSignedHeader 	"Content-Type: application/pkcs7-mime; smime-type=signed-data;\r\n\tname=smime.p7m; charset=\"%s\"\r\nContent-Transfer-Encoding: base64\r\nContent-Disposition: attachment; filename=smime.p7m\r\n"
#define SB_CSignatureHeader 	"Content-Type: application/pkcs7-signature; name=smime.p7s\r\nContent-Transfer-Encoding: base64\r\nContent-Disposition: attachment; filename=smime.p7s\r\n"
#define SB_SDefaultMIMEPrefix 	"This is a multi-part message in MIME format"
#define SB_SNoSigningCertificateStorage 	"No signing certificate storage"
#ifndef SB_SNoSigningCertificate
#define SB_SNoSigningCertificate 	"No signing certificate with private key available in the storage"
#endif
#define SB_SFailedToAssembleOriginalPartHeader 	"Failed to assemble the original part header"
#define SB_SNoEncryptionCertificateStorage 	"No encryption certificate storage"
#define SB_SNoEncryptionCertificate 	"No encryption certificate available in the storage"
#ifndef SB_SEncryptionFailed
#define SB_SEncryptionFailed 	"Failed to encrypt data"
#endif
#ifndef SB_SSigningFailed
#define SB_SSigningFailed 	"Failed to sign data"
#endif
#define SB_SUnknownDigestAlgorithm 	"Unknown digest algorithm specified: %s"

typedef TElClassHandle TElMessagePartHandlerSMimeHandle;

typedef TElClassHandle TElSimpleSMIMEMessageHandle;

typedef TElClassHandle TElSimpleSMIMEOptionsHandle;

typedef TElMessagePartHandlerSMimeHandle ElMessagePartHandlerSMimeHandle;

typedef TElSimpleSMIMEOptionsHandle ElSimpleSMIMEOptionsHandle;

typedef TElSimpleSMIMEMessageHandle ElSimpleSMIMEMessageHandle;

typedef uint8_t TElSMimeBoolStateRaw;

typedef enum
{
	smbsNull = 0,
	smbsFalse = 1,
	smbsTrue = 2
} TElSMimeBoolState;

typedef uint8_t TElSMimeTypeRaw;

typedef enum
{
	smtUnknown = 0,
	smtSignOnly = 1,
	smtCryptOnly = 2,
	smtSignAndCrypt = 3
} TElSMimeType;

typedef uint8_t TElSMimeErrorRaw;

typedef enum
{
	smeUnknown = 0,
	smeSignaturePartNotFound = 1,
	smeBodyPartNotFound = 2,
	smeInvalidSignature = 3,
	smeSigningCertificateMismatch = 4,
	smeEncryptingCertificateMismatch = 5,
	smeNoData = 6,
	smeInvalidMessageDigest = 7,
	smeOmittedMessageDigest = 8
} TElSMimeError;

typedef uint32_t TElSMimeErrorsRaw;

typedef enum 
{
	f_smeUnknown = 1,
	f_smeSignaturePartNotFound = 2,
	f_smeBodyPartNotFound = 4,
	f_smeInvalidSignature = 8,
	f_smeSigningCertificateMismatch = 16,
	f_smeEncryptingCertificateMismatch = 32,
	f_smeNoData = 64,
	f_smeInvalidMessageDigest = 128,
	f_smeOmittedMessageDigest = 256
} TElSMimeErrors;

typedef TElSMimeBoolState ElSMimeBoolState;

typedef TElSMimeType ElSMimeType;

typedef TElSMimeError ElSMimeError;

typedef TElSMimeErrors ElSMimeErrors;

#ifdef SB_USE_CLASS_TELMESSAGEPARTHANDLERSMIME
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_GetDescription(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_GetDescription_1(TElMessagePartHandlerSMimeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_DecoderIsSignedOnly(TElMessagePartHandlerSMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_DecoderIsSigned(TElMessagePartHandlerSMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_DecoderIsCrypted(TElMessagePartHandlerSMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_UseSystemCertificates(TElMessagePartHandlerSMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_UseSystemCertificates(TElMessagePartHandlerSMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_CertificatesStorage(TElMessagePartHandlerSMimeHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_CertificatesStorage(TElMessagePartHandlerSMimeHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_CryptoProviderManager(TElMessagePartHandlerSMimeHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_CryptoProviderManager(TElMessagePartHandlerSMimeHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_Errors(TElMessagePartHandlerSMimeHandle _Handle, TElSMimeErrorsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_DecoderSignIsCorrectly(TElMessagePartHandlerSMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_DecoderSignCertStorage(TElMessagePartHandlerSMimeHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_DecoderCryptCertStorage(TElMessagePartHandlerSMimeHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_DecoderIncludeIssuerCertificates(TElMessagePartHandlerSMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_DecoderIncludeIssuerCertificates(TElMessagePartHandlerSMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_EncoderCrypted(TElMessagePartHandlerSMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_EncoderCrypted(TElMessagePartHandlerSMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_EncoderSignBeforeCrypt(TElMessagePartHandlerSMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_EncoderSignBeforeCrypt(TElMessagePartHandlerSMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_EncoderSigned(TElMessagePartHandlerSMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_EncoderSigned(TElMessagePartHandlerSMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_EncoderSignOnlyClearFormat(TElMessagePartHandlerSMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_EncoderSignOnlyClearFormat(TElMessagePartHandlerSMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_EncoderMicalg(TElMessagePartHandlerSMimeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_EncoderMicalg(TElMessagePartHandlerSMimeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_EncoderCryptAlgorithm(TElMessagePartHandlerSMimeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_EncoderCryptAlgorithm(TElMessagePartHandlerSMimeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_EncoderCryptBitsInKey(TElMessagePartHandlerSMimeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_EncoderCryptBitsInKey(TElMessagePartHandlerSMimeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_EncoderIncludeIssuerCertificates(TElMessagePartHandlerSMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_EncoderIncludeIssuerCertificates(TElMessagePartHandlerSMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_EncoderSignRootHeader(TElMessagePartHandlerSMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_EncoderSignRootHeader(TElMessagePartHandlerSMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_EncoderSignTime(TElMessagePartHandlerSMimeHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_EncoderSignTime(TElMessagePartHandlerSMimeHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_DecoderSignTime(TElMessagePartHandlerSMimeHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_EncoderAlignEncryptedKey(TElMessagePartHandlerSMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_EncoderAlignEncryptedKey(TElMessagePartHandlerSMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_EncoderCryptCertStorage(TElMessagePartHandlerSMimeHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_EncoderCryptCertStorage(TElMessagePartHandlerSMimeHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_EncoderSignCertStorage(TElMessagePartHandlerSMimeHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_EncoderSignCertStorage(TElMessagePartHandlerSMimeHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_get_EncoderIgnoreCertAddress(TElMessagePartHandlerSMimeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_set_EncoderIgnoreCertAddress(TElMessagePartHandlerSMimeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElMessagePartHandlerSMime_Create(TObjectHandle aParams, TElMessagePartHandlerSMimeHandle * OutResult);
#endif /* SB_USE_CLASS_TELMESSAGEPARTHANDLERSMIME */

#ifdef SB_USE_CLASS_TELSIMPLESMIMEMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEMessage_get_SMIMEOptions(TElSimpleSMIMEMessageHandle _Handle, TElSimpleSMIMEOptionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEMessage_set_SMIMEOptions(TElSimpleSMIMEMessageHandle _Handle, TElSimpleSMIMEOptionsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEMessage_get_EncryptCertStorage(TElSimpleSMIMEMessageHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEMessage_set_EncryptCertStorage(TElSimpleSMIMEMessageHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEMessage_get_SignCertStorage(TElSimpleSMIMEMessageHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEMessage_set_SignCertStorage(TElSimpleSMIMEMessageHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEMessage_Create(TComponentHandle AOwner, TElSimpleSMIMEMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLESMIMEMESSAGE */

#ifdef SB_USE_CLASS_TELSIMPLESMIMEOPTIONS
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_Assign(TElSimpleSMIMEOptionsHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_get_CryptoProviderManager(TElSimpleSMIMEOptionsHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_set_CryptoProviderManager(TElSimpleSMIMEOptionsHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_get_EncryptMessage(TElSimpleSMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_set_EncryptMessage(TElSimpleSMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_get_SignMessage(TElSimpleSMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_set_SignMessage(TElSimpleSMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_get_SignBeforeCrypt(TElSimpleSMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_set_SignBeforeCrypt(TElSimpleSMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_get_SignOnlyClearFormat(TElSimpleSMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_set_SignOnlyClearFormat(TElSimpleSMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_get_MicAlg(TElSimpleSMIMEOptionsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_set_MicAlg(TElSimpleSMIMEOptionsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_get_EncryptAlgorithm(TElSimpleSMIMEOptionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_set_EncryptAlgorithm(TElSimpleSMIMEOptionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_get_EnryptBitsInKey(TElSimpleSMIMEOptionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_set_EnryptBitsInKey(TElSimpleSMIMEOptionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_get_IncludeIssuerCertificates(TElSimpleSMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_set_IncludeIssuerCertificates(TElSimpleSMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_get_SignRootHeader(TElSimpleSMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_set_SignRootHeader(TElSimpleSMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_get_SignTime(TElSimpleSMIMEOptionsHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_set_SignTime(TElSimpleSMIMEOptionsHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_get_AlignEncryptedKey(TElSimpleSMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_set_AlignEncryptedKey(TElSimpleSMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_get_IgnoreCertAddress(TElSimpleSMIMEOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_set_IgnoreCertAddress(TElSimpleSMIMEOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSimpleSMIMEOptions_Create(TElSimpleSMIMEOptionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIMPLESMIMEOPTIONS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElMessagePartHandlerSMime_ce_ptr;
extern zend_class_entry *TElSimpleSMIMEMessage_ce_ptr;
extern zend_class_entry *TElSimpleSMIMEOptions_ce_ptr;

void Register_TElMessagePartHandlerSMime(TSRMLS_D);
void Register_TElSimpleSMIMEMessage(TSRMLS_D);
void Register_TElSimpleSMIMEOptions(TSRMLS_D);
SB_PHP_FUNCTION(SBSMIMECore, Initialize);
void Register_SBSMIMECore_Constants(int module_number TSRMLS_DC);
void Register_SBSMIMECore_Enum_Flags(TSRMLS_D);
void Register_SBSMIMECore_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_SMIMECORE
SB_IMPORT uint32_t SB_APIENTRY SBSMIMECore_Initialize(void);
#endif /* SB_USE_GLOBAL_PROCS_SMIMECORE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSMIMECORE */
