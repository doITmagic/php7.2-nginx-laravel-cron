#ifndef __INC_SBSMIMESIGNATURES
#define __INC_SBSMIMESIGNATURES

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbmessages.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbstreams.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_MESSAGE_ERROR_INVALID_MESSAGE_DIGEST 	8272
#define SB_MESSAGE_WARNING_OMITTED_MESSAGE_DIGEST 	8273

typedef TElClassHandle TElSMIMEMessageSignerHandle;

typedef TElSMIMEMessageSignerHandle ElSMIMEMessageSignerHandle;

typedef TElClassHandle TElSMIMEMessageVerifierHandle;

typedef TElSMIMEMessageVerifierHandle ElSMIMEMessageVerifierHandle;

#ifdef SB_USE_CLASS_TELSMIMEMESSAGESIGNER
SB_IMPORT uint32_t SB_APIENTRY TElSMIMEMessageSigner_Sign(TElSMIMEMessageSignerHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int8_t Detached, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMIMEMessageSigner_Sign_1(TElSMIMEMessageSignerHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int8_t Detached, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMIMEMessageSigner_Create(TComponentHandle AOwner, TElMessageSignerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSMIMEMESSAGESIGNER */

#ifdef SB_USE_CLASS_TELSMIMEMESSAGEVERIFIER
SB_IMPORT uint32_t SB_APIENTRY TElSMIMEMessageVerifier_Verify(TElSMIMEMessageVerifierHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMIMEMessageVerifier_Verify_1(TElMessageVerifierHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int64_t InCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMIMEMessageVerifier_VerifyDetached(TElSMIMEMessageVerifierHandle _Handle, void * Buffer, int32_t Size, void * Signature, int32_t SignatureSize, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMIMEMessageVerifier_VerifyDetached_1(TElMessageVerifierHandle _Handle, TStreamHandle InStream, TStreamHandle SigStream, int64_t InCount, int64_t SigCount, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMIMEMessageVerifier_Create(TComponentHandle AOwner, TElMessageVerifierHandle * OutResult);
#endif /* SB_USE_CLASS_TELSMIMEMESSAGEVERIFIER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSMIMEMessageSigner_ce_ptr;
extern zend_class_entry *TElSMIMEMessageVerifier_ce_ptr;

void Register_TElSMIMEMessageSigner(TSRMLS_D);
void Register_TElSMIMEMessageVerifier(TSRMLS_D);
void Register_SBSMIMESignatures_Constants(int module_number TSRMLS_DC);
void Register_SBSMIMESignatures_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSMIMESIGNATURES */

