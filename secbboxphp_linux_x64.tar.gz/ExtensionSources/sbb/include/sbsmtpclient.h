#ifndef __INC_SBSMTPCLIENT
#define __INC_SBSMTPCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbrandom.h"
#include "sbsslcommon.h"
#include "sbsslclient.h"
#include "sbsimplessl.h"
#include "sbx509.h"
#include "sbcustomcertstorage.h"
#include "sbconstants.h"
#include "sbsslconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbencoding.h"
#include "sbsasl.h"
#ifdef SB_WINDOWS
#include "sbhttpauth.h"
#endif
#include "sbsocket.h"
#include "sbstreams.h"
#include "sbmime.h"
#include "sbsimplemime.h"
#include "sbcmdsslclient.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_SMTP 	167936
#define SB_ERROR_SMTP_ERROR_FLAG 	2048
#define SB_SMTP_ERROR_INVALID_REPLY 	169985
#define SB_SMTP_ERROR_NO_DOMAIN_FOR_LOGIN 	169986
#define SB_SMTP_ERROR_INVALID_PARAMETER 	169987
#define SB_SMTP_ERROR_NO_APPLICABLE_SASL_MECH 	169988
#define SB_SMTP_ERROR_AUTH_FAILED 	169989
#define SB_DefaultChunkSize 	65536
#define SB_DefaultBufferSize 	1048576

typedef TElClassHandle TElSMTPClientHandle;

typedef TElSMTPClientHandle ElSMTPClientHandle;

typedef uint8_t TSBSMTPStateRaw;

typedef enum
{
	ssPlain = 0,
	ssEncrypted = 1
} TSBSMTPState;

typedef uint8_t TSBSMTPDSNOptionRaw;

typedef enum
{
	sdnSuccess = 0,
	sdnFailure = 1,
	sdnDelay = 2
} TSBSMTPDSNOption;

typedef uint32_t TSBSMTPDSNOptionsRaw;

typedef enum 
{
	f_sdnSuccess = 1,
	f_sdnFailure = 2,
	f_sdnDelay = 4
} TSBSMTPDSNOptions;

typedef uint8_t TSBSMTPDSNReturnTypeRaw;

typedef enum
{
	srtFull = 0,
	srtHeaders = 1
} TSBSMTPDSNReturnType;

typedef void (SB_CALLBACK *TSBSMTPDSNEnvIDGenerateEvent)(void * _ObjectData, TObjectHandle Sender, TElStringListHandle RcptTo, char * pcEnvID, int32_t * szEnvID);

typedef void (SB_CALLBACK *TSBSMTPDSNOptionsEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcRcptTo, int32_t szRcptTo, TSBSMTPDSNOptionsRaw * Options);

#ifdef SB_USE_CLASS_TELSMTPCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_Close(TElSMTPClientHandle _Handle, int8_t Silent);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_Open(TElSMTPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_EstablishSSLSession(TElSMTPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_Login(TElSMTPClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_Send(TElSMTPClientHandle _Handle, TElMessageHandle Message);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_Send_1(TElSMTPClientHandle _Handle, TElSimpleMIMEMessageHandle Message);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_Send_2(TElSMTPClientHandle _Handle, const char * pcMailFrom, int32_t szMailFrom, TElStringListHandle RcptTo, TElStringListHandle Message);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_Send_3(TElSMTPClientHandle _Handle, const char * pcMailFrom, int32_t szMailFrom, TElStringListHandle RcptTo, TStreamHandle Message);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_Send_4(TElSMTPClientHandle _Handle, TStreamHandle Message);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_SASLMechanism(TElSMTPClientHandle _Handle, const char * pcName, int32_t szName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_SASLMechanism(TElSMTPClientHandle _Handle, const char * pcName, int32_t szName, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_SASLMechanismPriorities(TElSMTPClientHandle _Handle, const char * pcName, int32_t szName, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_SASLMechanismPriorities(TElSMTPClientHandle _Handle, const char * pcName, int32_t szName, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_ExtSASLMechanisms(TElSMTPClientHandle _Handle, TStringListHandle OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_ExtensionChunkingSupported(TElSMTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_ExtensionBinarySupported(TElSMTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_ExtensionAuthPlainSupported(TElSMTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_ExtensionAuthLoginSupported(TElSMTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_ExtensionSASLLoginSupported(TElSMTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_ExtensionSizeSupported(TElSMTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_ExtensionDSNSupported(TElSMTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_ExtensionStatusCodesSupported(TElSMTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_MaxMessageSize(TElSMTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_SSLActive(TElSMTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_Address(TElSMTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_Address(TElSMTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_AllowAuthentication(TElSMTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_AllowAuthentication(TElSMTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_AllowBinaryMode(TElSMTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_AllowBinaryMode(TElSMTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_BinaryChunkSize(TElSMTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_BinaryChunkSize(TElSMTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_Domain(TElSMTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_Domain(TElSMTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_Password(TElSMTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_Password(TElSMTPClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_Port(TElSMTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_Port(TElSMTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_RemoveBCC(TElSMTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_RemoveBCC(TElSMTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_SendBufferSize(TElSMTPClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_SendBufferSize(TElSMTPClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_SSLMode(TElSMTPClientHandle _Handle, TSBSSLModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_SSLMode(TElSMTPClientHandle _Handle, TSBSSLModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_UseSSL(TElSMTPClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_UseSSL(TElSMTPClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_Username(TElSMTPClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_Username(TElSMTPClientHandle _Handle, const char * pcValue, int32_t szValue);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_UsernameOption(TElSMTPClientHandle _Handle, TSBUsernameOptionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_UsernameOption(TElSMTPClientHandle _Handle, TSBUsernameOptionRaw Value);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_DSNOptions(TElSMTPClientHandle _Handle, TSBSMTPDSNOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_DSNOptions(TElSMTPClientHandle _Handle, TSBSMTPDSNOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_DSNReturnType(TElSMTPClientHandle _Handle, TSBSMTPDSNReturnTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_DSNReturnType(TElSMTPClientHandle _Handle, TSBSMTPDSNReturnTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_OnProgress(TElSMTPClientHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_OnProgress(TElSMTPClientHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_OnDSNEnvIDGenerate(TElSMTPClientHandle _Handle, TSBSMTPDSNEnvIDGenerateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_OnDSNEnvIDGenerate(TElSMTPClientHandle _Handle, TSBSMTPDSNEnvIDGenerateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_get_OnDSNOptions(TElSMTPClientHandle _Handle, TSBSMTPDSNOptionsEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_set_OnDSNOptions(TElSMTPClientHandle _Handle, TSBSMTPDSNOptionsEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSMTPClient_Create(TComponentHandle AOwner, TElSMTPClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSMTPCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSMTPClient_ce_ptr;

void SB_CALLBACK TSBSMTPDSNEnvIDGenerateEventRaw(void * _ObjectData, TObjectHandle Sender, TElStringListHandle RcptTo, char * pcEnvID, int32_t * szEnvID);
void SB_CALLBACK TSBSMTPDSNOptionsEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcRcptTo, int32_t szRcptTo, TSBSMTPDSNOptionsRaw * Options);
void Register_TElSMTPClient(TSRMLS_D);
void Register_SBSMTPClient_Constants(int module_number TSRMLS_DC);
void Register_SBSMTPClient_Enum_Flags(TSRMLS_D);
void Register_SBSMTPClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSMTPCLIENT */
