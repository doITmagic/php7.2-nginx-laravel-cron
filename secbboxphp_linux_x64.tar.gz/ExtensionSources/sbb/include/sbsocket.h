#ifndef __INC_SBSOCKET
#define __INC_SBSOCKET

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbhttpauth.h"
#include "sbstringlist.h"
#include "sbhttpsconstants.h"
#include "sbencoding.h"
#include "sbdnssectypes.h"
#include "sbpunycode.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_SOCKET 	94208
#define SB_ERROR_SOCKET_PROTOCOL_ERROR_FLAG 	2048
#define SB_SOCKET_ERROR_CONN_CLOSED_BY_USER 	94209
#define SB_SOCKET_ERROR_WINSOCK_INIT_FAILED 	96257
#define SB_SOCKET_ERROR_WRONG_SOCKET_STATE 	96258
#define SB_SOCKET_ERROR_NOT_A_SOCKET 	96259
#define SB_SOCKET_ERROR_INVALID_ADDRESS 	96260
#define SB_SOCKET_ERROR_ACCEPT_FAILED 	96261
#define SB_SOCKET_ERROR_ADDRESS_FAMILY_MISMATCH 	96262
#define SB_SOCKET_ERROR_INVALID_SOCKET_TYPE 	96263
#define SB_SOCKET_ERROR_SOCKS_NEGOTIATION_FAILED 	96264
#define SB_SOCKET_ERROR_SOCKS_AUTH_FAILED 	96265
#define SB_SOCKET_ERROR_SOCKS_FAILED_TO_RESOLVE_DESTINATION_ADDRESS 	96266
#define SB_SOCKET_ERROR_DNS_SECURITY_FAILURE 	96267
#define SB_SOCKET_ERROR_DNS_TIMEOUT 	96268
#define SB_SOCKET_ERROR_WEBTUNNEL_NEGOTIATION_FAILED 	96269
#define SB_SOCKET_ERROR_TIMEOUT 	96270
#define SB_SOCKET_ERROR_NO_PROXY_HEADER 	96271
#define SB_SOCKET_ERROR_WRONG_PROXY_HEADER 	96272
#define SB_SOCKET_ERROR_PRELIMINARY_DISCONNECTION 	96273
#define SB_HAPROXY_AF_UNSPEC 	0
#define SB_HAPROXY_AF_INET 	1
#define SB_HAPROXY_AF_INET6 	2
#define SB_HAPROXY_AF_UNIX 	3
#define SB_HAPROXY_PROT_UNSPEC 	0
#define SB_HAPROXY_PROT_TCP 	1
#define SB_HAPROXY_PROT_STREAM 	1
#define SB_HAPROXY_PROT_UDP 	2
#define SB_HAPROXY_PROT_DGRAM 	2
#define SB_HAPROXY_CMD_LOCAL 	0
#define SB_HAPROXY_CMD_PROXY 	1
#define SB_MAX_PROXY_HEADER_SIZE 	536
#define SB__SSALIGNSIZE 	8
#define SB__SSMAXSIZE 	128
#define SB__SSPAD1SIZE 	6
#define SB__SSPAD2SIZE 	112
#ifdef SB_WINDOWS
#define SB_AF_INET6 	23
#define SB_INVALID_SOCKET 	-1
#define SB_SOCKET_ERROR_CODE_TIMEDOUT 	10060
#endif
#ifdef LINUX
#define SB_MSG_NOSIGNAL 	16384
#endif
#ifdef MACOS
#define SB_SO_NOSIGPIPE 	4130
#endif
#ifndef SB_WINDOWS
#define SB_SOCKET_ERROR_CODE_TIMEDOUT 	110
#endif
#define SB_SOCKET_ERROR_CODE_WOULDBLOCK 	10035
#ifdef SB_WINDOWS
#define SB_SOCKET_ERROR_CODE_CONNRESET 	10054
#define SB_SOCKET_ERROR_CODE_ADDRINUSE 	10048
#define SB_SOCKET_ERROR_CODE_ISCONN 	10056
#define SB_SOCKET_ERROR_CODE_INPROGRESS 	10036
#define SB_SOCKET_ERROR_CODE_SHUTDOWN 	10058
#else
#define SB_SOCKET_ERROR_CODE_CONNRESET 	104
#define SB_SOCKET_ERROR_CODE_ADDRINUSE 	10022
#define SB_SOCKET_ERROR_CODE_ISCONN 	106
#define SB_SOCKET_ERROR_CODE_INPROGRESS 	115
#define SB_SOCKET_ERROR_CODE_SHUTDOWN 	108
#endif

typedef TElClassHandle TElSocketHandle;

typedef TElClassHandle TElCustomProxyHeaderInfoHandle;

typedef TElClassHandle TElHAPROXYHeaderInfoHandle;

typedef TElClassHandle TElCustomSocketBindingHandle;

typedef TElCustomSocketBindingHandle ElCustomSocketBindingHandle;

typedef TElClassHandle TElClientSocketBindingHandle;

typedef TElClientSocketBindingHandle TElSocketBindingHandle;

typedef TElClientSocketBindingHandle ElClientSocketBindingHandle;

typedef TElClientSocketBindingHandle ElSocketBindingHandle;

typedef TElClassHandle TElDNSSettingsHandle;

typedef TElClassHandle TElSocketSettingsHandle;

typedef uint8_t TElShutdownDirectionRaw;

typedef enum
{
	sdReceive = 0,
	sdSend = 1,
	sdSendAndReceive = 2
} TElShutdownDirection;

typedef uint8_t TElSocketStateRaw;

typedef enum
{
	issNotASocket = 0,
	issInitializing = 1,
	issInitialized = 2,
	issBound = 3,
	issConnected = 4,
	issListening = 5,
	issConnecting = 6
} TElSocketState;

typedef uint8_t TElSocketTypeRaw;

typedef enum
{
	istStream = 0,
	istDatagram = 1
} TElSocketType;

typedef uint8_t TElSocksVersionRaw;

typedef enum
{
	elSocks4 = 0,
	elSocks5 = 1
} TElSocksVersion;

typedef uint8_t TElSocksAuthenticationRaw;

typedef enum
{
	saNoAuthentication = 0,
	saUsercode = 1
} TElSocksAuthentication;

typedef uint8_t TElWebTunnelAuthenticationRaw;

typedef enum
{
	wtaNoAuthentication = 0,
	wtaBasic = 1,
	wtaDigest = 2,
	wtaNTLM = 3
} TElWebTunnelAuthentication;

typedef uint8_t TElBandwidthPolicyRaw;

typedef enum
{
	bpFlexible = 0,
	bpStrict = 1
} TElBandwidthPolicy;

#ifndef SB_WINDOWS
typedef sockaddr_in TSockAddrIn;

typedef uint32_t * PSOCKLEN_T;

#pragma pack(8)
typedef struct 
{
	char * h_name;
	char * (* h_aliases);
	int32_t h_addrtype;
	uint32_t h_length;
	union
	{
		struct
		{
			char * (* h_addr_list);
		} S1;
		struct
		{
			char * (* h_addr);
		} S2;
	};
} hostent, * Phostent;

typedef uint32_t * Pin_addr_t;
#endif

#pragma pack(1)
typedef struct 
{
	uint16_t ss_family;
	uint8_t __ss_pad1[6];
	int64_t __ss_align;
	uint8_t __ss_pad2[112];
} sockaddr_storage, * PSockAddrStorage;

typedef sockaddr_storage TSockAddrStorage;

typedef void (SB_CALLBACK *TSBSocksAuthMethodChooseEvent)(void * _ObjectData, TObjectHandle Sender, const TElSocksAuthenticationRaw pAuthMethods[], int32_t szAuthMethods, TElSocksAuthenticationRaw * AuthMethod, int8_t * Cancel);

typedef void (SB_CALLBACK *TSBSocksAuthPasswordEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, const char * pcPassword, int32_t szPassword, int8_t * Accept);

typedef void (SB_CALLBACK *TSBSocksConnectEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcDestHost, int32_t szDestHost, int32_t DestPort, int8_t * Allow);

typedef void (SB_CALLBACK *TElSocketSecondaryEvent)(void * _ObjectData, TObjectHandle Sender, TElSocketHandle Socket, int32_t State, int8_t * AbortConnect);

typedef void (SB_CALLBACK *TSBDNSResolveEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcHostName, int32_t szHostName, TElDNSResourceRecordSetHandle Response, int32_t ResolveResult, TSBDNSSecurityStatusRaw SecurityStatus);

#ifndef SB_WINDOWS
typedef in_addr * Pin_addr;

typedef psockaddr_in PSockAddrIn;

typedef Phostent (* PPhostent);
#endif

#ifdef SB_USE_CLASS_TELSOCKET
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElSocket_LoadIPv6Proc(const char * pcProcName, int32_t szProcName, void * * Proc, int32_t * WinsockUsed, int32_t * Wship6Used, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_LoadIPv6Proc_1(TElSocketHandle _Handle, const char * pcProcName, int32_t szProcName, void * * Proc, int32_t * WinsockUsed, int32_t * Wship6Used, int8_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElSocket_InitializeIPv6();
SB_IMPORT uint32_t SB_APIENTRY TElSocket_InitializeIPv6_1(TElSocketHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_FinalizeIPv6();
SB_IMPORT uint32_t SB_APIENTRY TElSocket_FinalizeIPv6_1(TElSocketHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_ShutdownSocket(TElSocketHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_ShutdownSocket_1(TElSocketHandle _Handle, TElShutdownDirectionRaw Direction);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_Close(TElSocketHandle _Handle, int8_t Forced);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_Close_1(TElSocketHandle _Handle, int8_t Forced, int32_t Timeout);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_Close_2(TElSocketHandle _Handle, int8_t Forced, int32_t Timeout, int8_t Gradually);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_StartAsyncConnect(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_AsyncConnect(TElSocketHandle _Handle, int32_t Timeout, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_FinalizeWinSock();
SB_IMPORT uint32_t SB_APIENTRY TElSocket_FinalizeWinSock_1(TElSocketHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_InitializeWinSock();
SB_IMPORT uint32_t SB_APIENTRY TElSocket_InitializeWinSock_1(TElSocketHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_LastNetError(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_IPFromHost(TElSocketHandle _Handle, const char * pcHost, int32_t szHost, int8_t UseIPv6, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_Receive(TElSocketHandle _Handle, void * Data, int32_t DataLen, int32_t * Received, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_Send(TElSocketHandle _Handle, void * Data, int32_t DataLen, int32_t * Sent, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_ReceiveFrom(TElSocketHandle _Handle, void * Data, int32_t DataLen, int32_t * Received, char * pcRemoteAddress, int32_t * szRemoteAddress, uint16_t * RemotePort, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_SendTo(TElSocketHandle _Handle, void * Data, int32_t DataLen, int32_t * Sent, const char * pcRemoteAddress, int32_t szRemoteAddress, uint16_t RemotePort, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_ApplySettings(TElSocketHandle _Handle, TElSocketSettingsHandle Settings);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_Connect(TElSocketHandle _Handle, int32_t Timeout, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_CanReceive(TElSocketHandle _Handle, int32_t WaitTime, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_CanSend(TElSocketHandle _Handle, int32_t WaitTime, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_CanAccept(TElSocketHandle _Handle, int32_t WaitTime, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_Bind(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_Bind_1(TElSocketHandle _Handle, int8_t Outgoing, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_Bind_2(TElSocketHandle _Handle, int8_t Outgoing, int8_t ReuseAddress, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_Listen(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_Accept(TElSocketHandle _Handle, int32_t Timeout, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_Accept_1(TElSocketHandle _Handle, int32_t Timeout, TElSocketHandle * Socket);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_AsyncConnectEx(TElSocketHandle _Handle, int32_t Timeout, TElSocketHandle SecondarySocket, int8_t SecSend, int8_t SecRecv, TElSocketSecondaryEvent pMethodSecEvent, void * pDataSecEvent, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_SocksAccept(TElSocketHandle _Handle, int32_t Timeout, TSBSocksAuthMethodChooseEvent pMethodOnAuthMethodChoose, void * pDataOnAuthMethodChoose, TSBSocksAuthPasswordEvent pMethodOnAuthPassword, void * pDataOnAuthPassword, TSBSocksConnectEvent pMethodOnConnect, void * pDataOnConnect, int8_t CloseConnectionOnError, int8_t ResolveAddress);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_LocalHostName(TElSocketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_RemoteAddress(TElSocketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_ProxyResult(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_SocketType(TElSocketHandle _Handle, TElSocketTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_SocketType(TElSocketHandle _Handle, TElSocketTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_State(TElSocketHandle _Handle, TElSocketStateRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_UsingIPv6(TElSocketHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_BoundPort(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_BoundAddress(TElSocketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_NativeSocket(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_Address(TElSocketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_Address(TElSocketHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_Port(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_Port(TElSocketHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_ListenBinding(TElSocketHandle _Handle, TElClientSocketBindingHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_ListenBinding(TElSocketHandle _Handle, TElClientSocketBindingHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_OutgoingLocalBinding(TElSocketHandle _Handle, TElClientSocketBindingHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_OutgoingLocalBinding(TElSocketHandle _Handle, TElClientSocketBindingHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_IncomingSpeedLimit(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_IncomingSpeedLimit(TElSocketHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_OutgoingSpeedLimit(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_OutgoingSpeedLimit(TElSocketHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_SocksAuthentication(TElSocketHandle _Handle, TElSocksAuthenticationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_SocksAuthentication(TElSocketHandle _Handle, TElSocksAuthenticationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_SocksPassword(TElSocketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_SocksPassword(TElSocketHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_SocksPort(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_SocksPort(TElSocketHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_SocksResolveAddress(TElSocketHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_SocksResolveAddress(TElSocketHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_SocksServer(TElSocketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_SocksServer(TElSocketHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_SocksUseIPv6(TElSocketHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_SocksUseIPv6(TElSocketHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_SocksUserCode(TElSocketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_SocksUserCode(TElSocketHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_SocksVersion(TElSocketHandle _Handle, TElSocksVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_SocksVersion(TElSocketHandle _Handle, TElSocksVersionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_UseSocks(TElSocketHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_UseSocks(TElSocketHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_UseIPv6(TElSocketHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_UseIPv6(TElSocketHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_UseNagle(TElSocketHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_UseNagle(TElSocketHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_UseWebTunneling(TElSocketHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_UseWebTunneling(TElSocketHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_WebTunnelAddress(TElSocketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_WebTunnelAddress(TElSocketHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_WebTunnelAuthentication(TElSocketHandle _Handle, TElWebTunnelAuthenticationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_WebTunnelAuthentication(TElSocketHandle _Handle, TElWebTunnelAuthenticationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_WebTunnelPassword(TElSocketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_WebTunnelPassword(TElSocketHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_WebTunnelPort(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_WebTunnelPort(TElSocketHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_WebTunnelUserId(TElSocketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_WebTunnelUserId(TElSocketHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_WebTunnelRequestHeaders(TElSocketHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_WebTunnelRequestHeaders(TElSocketHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_WebTunnelResponseHeaders(TElSocketHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_WebTunnelResponseBody(TElSocketHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_AutoAdjustBuffersSize(TElSocketHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_AutoAdjustBuffersSize(TElSocketHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_MinBufferSize(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_MinBufferSize(TElSocketHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_MaxBufferSize(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_MaxBufferSize(TElSocketHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_BuffersAdjustStep(TElSocketHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_BuffersAdjustStep(TElSocketHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_SendBufferSize(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_SendBufferSize(TElSocketHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_RecvBufferSize(TElSocketHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_RecvBufferSize(TElSocketHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_ProxyHeaderInfo(TElSocketHandle _Handle, TElCustomProxyHeaderInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_DNS(TElSocketHandle _Handle, TElDNSSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_DNS(TElSocketHandle _Handle, TElDNSSettingsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_OnDNSKeyNeeded(TElSocketHandle _Handle, TSBDNSKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_OnDNSKeyNeeded(TElSocketHandle _Handle, TSBDNSKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_OnDNSKeyValidate(TElSocketHandle _Handle, TSBDNSKeyValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_OnDNSKeyValidate(TElSocketHandle _Handle, TSBDNSKeyValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_get_OnDNSResolve(TElSocketHandle _Handle, TSBDNSResolveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_set_OnDNSResolve(TElSocketHandle _Handle, TSBDNSResolveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_Create(TComponentHandle Owner, TElSocketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocket_Create_1(TElSocketHandle * OutResult);
#endif /* SB_USE_CLASS_TELSOCKET */

#ifdef SB_USE_CLASS_TELCUSTOMPROXYHEADERINFO
SB_IMPORT uint32_t SB_APIENTRY TElCustomProxyHeaderInfo_get_SourcePort(TElCustomProxyHeaderInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomProxyHeaderInfo_get_SourceAddress(TElCustomProxyHeaderInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomProxyHeaderInfo_get_CompleteRawHeader(TElCustomProxyHeaderInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomProxyHeaderInfo_Create(TElCustomProxyHeaderInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMPROXYHEADERINFO */

#ifdef SB_USE_CLASS_TELHAPROXYHEADERINFO
SB_IMPORT uint32_t SB_APIENTRY TElHAPROXYHeaderInfo_get_AddressFamily(TElHAPROXYHeaderInfoHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHAPROXYHeaderInfo_get_Command(TElHAPROXYHeaderInfoHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHAPROXYHeaderInfo_get_DestinationPort(TElHAPROXYHeaderInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHAPROXYHeaderInfo_get_DestinationAddress(TElHAPROXYHeaderInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHAPROXYHeaderInfo_get_ProtocolType(TElHAPROXYHeaderInfoHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHAPROXYHeaderInfo_get_ProtocolVersion(TElHAPROXYHeaderInfoHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHAPROXYHeaderInfo_get_RawHeaderExtra(TElHAPROXYHeaderInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHAPROXYHeaderInfo_Create(TElHAPROXYHeaderInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELHAPROXYHEADERINFO */

#ifdef SB_USE_CLASS_TELCUSTOMSOCKETBINDING
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketBinding_Assign(TElCustomSocketBindingHandle _Handle, TElCustomSocketBindingHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketBinding_get_LocalIntfAddress(TElCustomSocketBindingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketBinding_set_LocalIntfAddress(TElCustomSocketBindingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketBinding_get_Port(TElCustomSocketBindingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketBinding_set_Port(TElCustomSocketBindingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketBinding_get_ReuseAddress(TElCustomSocketBindingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketBinding_set_ReuseAddress(TElCustomSocketBindingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketBinding_Create(TElCustomSocketBindingHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMSOCKETBINDING */

#ifdef SB_USE_CLASS_TELCLIENTSOCKETBINDING
SB_IMPORT uint32_t SB_APIENTRY TElClientSocketBinding_Assign(TElClientSocketBindingHandle _Handle, TElCustomSocketBindingHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElClientSocketBinding_get_PortRangeFrom(TElClientSocketBindingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElClientSocketBinding_set_PortRangeFrom(TElClientSocketBindingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElClientSocketBinding_get_PortRangeTo(TElClientSocketBindingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElClientSocketBinding_set_PortRangeTo(TElClientSocketBindingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElClientSocketBinding_Create(TElClientSocketBindingHandle * OutResult);
#endif /* SB_USE_CLASS_TELCLIENTSOCKETBINDING */

#ifdef SB_USE_CLASS_TELDNSSETTINGS
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_Assign(TElDNSSettingsHandle _Handle, TPersistentHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_InternalResolveHostName(TElDNSSettingsHandle _Handle, const char * pcHostName, int32_t szHostName, int8_t UseIPv6, sockaddr_storage * Addr, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_ResolveHostName(TElDNSSettingsHandle _Handle, const char * pcHostName, int32_t szHostName, int8_t UseIPv6, sockaddr_storage * Addr, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_get_AllowStatuses(TElDNSSettingsHandle _Handle, TSBDNSSecurityStatusesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_set_AllowStatuses(TElDNSSettingsHandle _Handle, TSBDNSSecurityStatusesRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_get_Enabled(TElDNSSettingsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_set_Enabled(TElDNSSettingsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_get_Port(TElDNSSettingsHandle _Handle, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_set_Port(TElDNSSettingsHandle _Handle, uint16_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_get_Servers(TElDNSSettingsHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_set_Servers(TElDNSSettingsHandle _Handle, TElStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_get_QueryTimeout(TElDNSSettingsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_set_QueryTimeout(TElDNSSettingsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_get_TotalTimeout(TElDNSSettingsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_set_TotalTimeout(TElDNSSettingsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_get_UseSocketTimeout(TElDNSSettingsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_set_UseSocketTimeout(TElDNSSettingsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_get_UseIPv6(TElDNSSettingsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_set_UseIPv6(TElDNSSettingsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_get_UseSecurity(TElDNSSettingsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_set_UseSecurity(TElDNSSettingsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDNSSettings_Create(TElDNSSettingsHandle * OutResult);
#endif /* SB_USE_CLASS_TELDNSSETTINGS */

#ifdef SB_USE_CLASS_TELSOCKETSETTINGS
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_get_AutoAdjustBuffersSize(TElSocketSettingsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_set_AutoAdjustBuffersSize(TElSocketSettingsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_get_MinBufferSize(TElSocketSettingsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_set_MinBufferSize(TElSocketSettingsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_get_MaxBufferSize(TElSocketSettingsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_set_MaxBufferSize(TElSocketSettingsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_get_BuffersAdjustStep(TElSocketSettingsHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_set_BuffersAdjustStep(TElSocketSettingsHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_get_SendBufferSize(TElSocketSettingsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_set_SendBufferSize(TElSocketSettingsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_get_RecvBufferSize(TElSocketSettingsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_set_RecvBufferSize(TElSocketSettingsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_get_UseNagle(TElSocketSettingsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_set_UseNagle(TElSocketSettingsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_get_ExpectHAProxyHeader(TElSocketSettingsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_set_ExpectHAProxyHeader(TElSocketSettingsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSocketSettings_Create(TElSocketHandle Socket, TElSocketSettingsHandle * OutResult);
#endif /* SB_USE_CLASS_TELSOCKETSETTINGS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifndef SB_WINDOWS
extern zend_class_entry *hostent_ce_ptr;
#endif
extern zend_class_entry *sockaddr_storage_ce_ptr;
extern zend_class_entry *TElSocket_ce_ptr;
extern zend_class_entry *TElCustomProxyHeaderInfo_ce_ptr;
extern zend_class_entry *TElHAPROXYHeaderInfo_ce_ptr;
extern zend_class_entry *TElCustomSocketBinding_ce_ptr;
extern zend_class_entry *TElClientSocketBinding_ce_ptr;
extern zend_class_entry *TElDNSSettings_ce_ptr;
extern zend_class_entry *TElSocketSettings_ce_ptr;

#ifndef SB_WINDOWS
void Register_hostent(TSRMLS_D);
#endif
void Register_sockaddr_storage(TSRMLS_D);
void SB_CALLBACK TSBSocksAuthMethodChooseEventRaw(void * _ObjectData, TObjectHandle Sender, const TElSocksAuthenticationRaw pAuthMethods[], int32_t szAuthMethods, TElSocksAuthenticationRaw * AuthMethod, int8_t * Cancel);
void SB_CALLBACK TSBSocksAuthPasswordEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, const char * pcPassword, int32_t szPassword, int8_t * Accept);
void SB_CALLBACK TSBSocksConnectEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcDestHost, int32_t szDestHost, int32_t DestPort, int8_t * Allow);
void SB_CALLBACK TElSocketSecondaryEventRaw(void * _ObjectData, TObjectHandle Sender, TElSocketHandle Socket, int32_t State, int8_t * AbortConnect);
void SB_CALLBACK TSBDNSResolveEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcHostName, int32_t szHostName, TElDNSResourceRecordSetHandle Response, int32_t ResolveResult, TSBDNSSecurityStatusRaw SecurityStatus);
void Register_TElSocket(TSRMLS_D);
void Register_TElCustomProxyHeaderInfo(TSRMLS_D);
void Register_TElHAPROXYHeaderInfo(TSRMLS_D);
void Register_TElCustomSocketBinding(TSRMLS_D);
void Register_TElClientSocketBinding(TSRMLS_D);
void Register_TElDNSSettings(TSRMLS_D);
void Register_TElSocketSettings(TSRMLS_D);
SB_PHP_FUNCTION(SBSocket, AddressToString);
SB_PHP_FUNCTION(SBSocket, StringToAddress);
SB_PHP_FUNCTION(SBSocket, IsIPv6Address);
void Register_SBSocket_Constants(int module_number TSRMLS_DC);
void Register_SBSocket_Enum_Flags(TSRMLS_D);
void Register_SBSocket_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_SOCKET
SB_IMPORT uint32_t SB_APIENTRY SBSocket_AddressToString(const sockaddr_storage * Addr, char * pcS, int32_t * szS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSocket_StringToAddress(const char * pcS, int32_t szS, sockaddr_storage * Addr, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSocket_IsIPv6Address(const char * pcS, int32_t szS, int8_t * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_SOCKET */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSOCKET */
