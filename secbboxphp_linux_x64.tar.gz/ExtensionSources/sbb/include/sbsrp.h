#ifndef __INC_SBSRP
#define __INC_SBSRP

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbhashfunction.h"
#include "sbstreams.h"
#include "sbmath.h"
#include "sbstrutils.h"
#include "sbencoding.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef TElClassHandle TElSRPCredentialHandle;

typedef TElClassHandle TElSRPCredentialStoreHandle;

typedef uint8_t TSBSRPCredentialPrimeLenRaw;

typedef enum
{
	srppl1024 = 0,
	srpp1536 = 1,
	srpp2048 = 2,
	srpp3072 = 3,
	srpp4096 = 4,
	srpp6144 = 5,
	srpp8192 = 6
} TSBSRPCredentialPrimeLen;

#ifdef SB_USE_CLASS_TELSRPCREDENTIAL
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredential_Generate(TElSRPCredentialHandle _Handle, const char * pcUsername, int32_t szUsername, const char * pcPassword, int32_t szPassword, TSBSRPCredentialPrimeLenRaw PrimeLen);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredential_Generate_1(TElSRPCredentialHandle _Handle, const char * pcUsername, int32_t szUsername, const char * pcPassword, int32_t szPassword, const uint8_t pPrime[], int32_t szPrime, const uint8_t pGenerator[], int32_t szGenerator);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredential_Load(TElSRPCredentialHandle _Handle, const char * pcData, int32_t szData);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredential_Load_1(TElSRPCredentialHandle _Handle, const char * pcUsername, int32_t szUsername, const uint8_t pSalt[], int32_t szSalt, const uint8_t pPrime[], int32_t szPrime, const uint8_t pGenerator[], int32_t szGenerator, const uint8_t pVerifier[], int32_t szVerifier);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredential_Save(TElSRPCredentialHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredential_get_Username(TElSRPCredentialHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredential_get_Prime(TElSRPCredentialHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredential_get_Generator(TElSRPCredentialHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredential_set_Generator(TElSRPCredentialHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredential_get_Salt(TElSRPCredentialHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredential_get_Verifier(TElSRPCredentialHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredential_Create(TElSRPCredentialHandle * OutResult);
#endif /* SB_USE_CLASS_TELSRPCREDENTIAL */

#ifdef SB_USE_CLASS_TELSRPCREDENTIALSTORE
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredentialStore_Add(TElSRPCredentialStoreHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredentialStore_Add_1(TElSRPCredentialStoreHandle _Handle, const char * pcUsername, int32_t szUsername, const char * pcPassword, int32_t szPassword, TSBSRPCredentialPrimeLenRaw PrimeLen, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredentialStore_Remove(TElSRPCredentialStoreHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredentialStore_Clear(TElSRPCredentialStoreHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredentialStore_LoadFromStream(TElSRPCredentialStoreHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredentialStore_SaveToStream(TElSRPCredentialStoreHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredentialStore_get_Credentials(TElSRPCredentialStoreHandle _Handle, int32_t Index, TElSRPCredentialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredentialStore_get_Count(TElSRPCredentialStoreHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSRPCredentialStore_Create(TComponentHandle AOwner, TElSRPCredentialStoreHandle * OutResult);
#endif /* SB_USE_CLASS_TELSRPCREDENTIALSTORE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSRPCredential_ce_ptr;
extern zend_class_entry *TElSRPCredentialStore_ce_ptr;

void Register_TElSRPCredential(TSRMLS_D);
void Register_TElSRPCredentialStore(TSRMLS_D);
void Register_SBSRP_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSRP */

