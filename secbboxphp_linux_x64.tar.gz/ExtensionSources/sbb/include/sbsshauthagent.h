#ifndef __INC_SBSSHAUTHAGENT
#define __INC_SBSSHAUTHAGENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbsocket.h"
#include "sbstrutils.h"
#include "sbtypes.h"
#include "sbstreams.h"
#include "sbutils.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSSHAuthAgentHandle;

#ifdef SB_WINDOWS
typedef TElClassHandle TElPageantAuthAgentHandle;
#endif

typedef TElClassHandle TElOpenSSHAuthAgentHandle;

#pragma pack(8)
typedef struct 
{
	void * AlgName;
	void * KeyBlob;
	void * Comment;
} TElSSHAuthAgentSSH2Key;

#ifdef SB_USE_CLASS_TELSSHAUTHAGENT
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthAgent_CalculateSignature(TElSSHAuthAgentHandle _Handle, int32_t AKeyIndex, const uint8_t pASessionID[], int32_t szASessionID, const uint8_t pAPacket[], int32_t szAPacket, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthAgent_get_Count(TElSSHAuthAgentHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthAgent_get_SSH2Keys(TElSSHAuthAgentHandle _Handle, int32_t AIndex, TElSSHAuthAgentSSH2Key * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthAgent_Create(TElSSHAuthAgentHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHAUTHAGENT */

#ifdef SB_WINDOWS
#ifdef SB_USE_CLASS_TELPAGEANTAUTHAGENT
SB_IMPORT uint32_t SB_APIENTRY TElPageantAuthAgent_Create(TElSSHAuthAgentHandle * OutResult);
#endif /* SB_USE_CLASS_TELPAGEANTAUTHAGENT */
#endif

#ifdef SB_USE_CLASS_TELOPENSSHAUTHAGENT
SB_IMPORT uint32_t SB_APIENTRY TElOpenSSHAuthAgent_Create(TElSSHAuthAgentHandle * OutResult);
#endif /* SB_USE_CLASS_TELOPENSSHAUTHAGENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSSHAuthAgentSSH2Key_ce_ptr;
extern zend_class_entry *TElSSHAuthAgent_ce_ptr;
#ifdef SB_WINDOWS
extern zend_class_entry *TElPageantAuthAgent_ce_ptr;
#endif
extern zend_class_entry *TElOpenSSHAuthAgent_ce_ptr;

void Register_TElSSHAuthAgentSSH2Key(TSRMLS_D);
void Register_TElSSHAuthAgent(TSRMLS_D);
#ifdef SB_WINDOWS
void Register_TElPageantAuthAgent(TSRMLS_D);
#endif
void Register_TElOpenSSHAuthAgent(TSRMLS_D);
#ifdef SB_WINDOWS
SB_PHP_FUNCTION(SBSSHAuthAgent, PageantAvailable);
SB_PHP_FUNCTION(SBSSHAuthAgent, ParseAccessInfo);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_SSHAUTHAGENT
SB_IMPORT uint32_t SB_APIENTRY SBSSHAuthAgent_PageantAvailable(int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSSHAuthAgent_ParseAccessInfo(const char * pcAInfo, int32_t szAInfo, int32_t * Port, uint8_t pMagic[], int32_t * szMagic, int8_t * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_SSHAUTHAGENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSSHAUTHAGENT */
