#ifndef __INC_SBSSHCLIENT
#define __INC_SBSSHCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbmath.h"
#include "sbcryptoprov.h"
#include "sbsymmetriccrypto.h"
#include "sbcustomcrypto.h"
#include "sbpublickeycrypto.h"
#include "sbhashfunction.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstringlist.h"
#include "sbencoding.h"
#include "sbsshterm.h"
#include "sbsharedresource.h"
#include "sbsshconstants.h"
#include "sbsshcommon.h"
#include "sbcustomcertstorage.h"
#include "sbocspclient.h"
#include "sbocspstorage.h"
#include "sbsshkeystorage.h"
#include "sbsshutils.h"
#include "sbgssapibase.h"
#include "sbgssapi.h"
#include "sbsshauthagent.h"
#include "sbconstants.h"
#include "sbpoly1305.h"
#include "sbx509.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SSH_OPEN_ADMINISTRATIVELY_PROHIBITED 	1

typedef TElClassHandle TElSSHClientHandle;

typedef TElSSHClientHandle ElSSHClientHandle;

typedef TElClassHandle TElSSHClientTunnelListHandle;

typedef TElSSHClientTunnelListHandle ElSSHClientTunnelListHandle;

typedef TElClassHandle TElSSHClientTunnelConnectionHandle;

typedef TElSSHClientTunnelConnectionHandle ElSSHClientTunnelConnectionHandle;

typedef uint8_t TSSHClientStateRaw;

typedef enum
{
	csBefore = 0,
	csIdentificationLineReceived = 1,
	csIdentificationLineSent = 2
} TSSHClientState;

typedef uint8_t TSBSSHCertAuthModeRaw;

typedef enum
{
	camAuto = 0,
	camStandard = 1,
	camTectia = 2,
	camRawPublicKey = 3
} TSBSSHCertAuthMode;

#ifdef SB_USE_CLASS_TELSSHCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_Open(TElSSHClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_Close(TElSSHClientHandle _Handle, int8_t Forced);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_DataAvailable(TElSSHClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_RenegotiateCiphers(TElSSHClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_SendKeepAlive(TElSSHClientHandle _Handle, TElSSHTunnelConnectionHandle Connection);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_SendIgnore(TElSSHClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_SendIgnore_1(TElSSHClientHandle _Handle, const uint8_t pData[], int32_t szData, int32_t StartIndex, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_Version(TElSSHClientHandle _Handle, TSSHVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_ServerCloseReason(TElSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_ServerSoftwareName(TElSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_ErrorString(TElSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_KbdIntName(TElSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_KbdIntInstruction(TElSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_AuthTypePriorities(TElSSHClientHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_AuthTypePriorities(TElSSHClientHandle _Handle, int32_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_ServerKey(TElSSHClientHandle _Handle, TElSSHKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_GSSMechanism(TElSSHClientHandle _Handle, TElGSSBaseMechanismHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_GSSMechanism(TElSSHClientHandle _Handle, TElGSSBaseMechanismHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_GSSHostName(TElSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_GSSHostName(TElSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_GSSDelegateCredentials(TElSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_GSSDelegateCredentials(TElSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_SSHAuthOrder(TElSSHClientHandle _Handle, TSBSSHAuthOrderRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_SSHAuthOrder(TElSSHClientHandle _Handle, TSBSSHAuthOrderRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_Versions(TElSSHClientHandle _Handle, TSSHVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_Versions(TElSSHClientHandle _Handle, TSSHVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_ClientUserName(TElSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_ClientUserName(TElSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_ClientHostName(TElSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_ClientHostName(TElSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_DefaultWindowSize(TElSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_DefaultWindowSize(TElSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_MinWindowSize(TElSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_MinWindowSize(TElSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_MaxSSHPacketSize(TElSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_MaxSSHPacketSize(TElSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_UserName(TElSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_UserName(TElSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_Password(TElSSHClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_Password(TElSSHClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_TunnelList(TElSSHClientHandle _Handle, TElSSHTunnelListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_TunnelList(TElSSHClientHandle _Handle, TElSSHTunnelListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_TrustedKeys(TElSSHClientHandle _Handle, TElSSHCustomKeyStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_TrustedKeys(TElSSHClientHandle _Handle, TElSSHCustomKeyStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_ThreadSafe(TElSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_ThreadSafe(TElSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_CertAuthMode(TElSSHClientHandle _Handle, TSBSSHCertAuthModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_CertAuthMode(TElSSHClientHandle _Handle, TSBSSHCertAuthModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_AutoAdjustCiphers(TElSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_AutoAdjustCiphers(TElSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_RequestPasswordChange(TElSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_RequestPasswordChange(TElSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_AuthAttempts(TElSSHClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_AuthAttempts(TElSSHClientHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_EarlyIdString(TElSSHClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_EarlyIdString(TElSSHClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_OnKeyValidate(TElSSHClientHandle _Handle, TSSHKeyValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_OnKeyValidate(TElSSHClientHandle _Handle, TSSHKeyValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_OnAuthenticationSuccess(TElSSHClientHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_OnAuthenticationSuccess(TElSSHClientHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_OnAuthenticationFailed(TElSSHClientHandle _Handle, TSSHAuthenticationFailedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_OnAuthenticationFailed(TElSSHClientHandle _Handle, TSSHAuthenticationFailedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_OnAuthenticationKeyboard(TElSSHClientHandle _Handle, TSSHAuthenticationKeyboardEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_OnAuthenticationKeyboard(TElSSHClientHandle _Handle, TSSHAuthenticationKeyboardEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_OnAuthenticationStart(TElSSHClientHandle _Handle, TSSHAuthenticationStartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_OnAuthenticationStart(TElSSHClientHandle _Handle, TSSHAuthenticationStartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_OnAuthenticationAttempt(TElSSHClientHandle _Handle, TSSHAuthenticationAttemptEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_OnAuthenticationAttempt(TElSSHClientHandle _Handle, TSSHAuthenticationAttemptEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_OnBanner(TElSSHClientHandle _Handle, TSSHBannerEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_OnBanner(TElSSHClientHandle _Handle, TSSHBannerEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_OnPrivateKeyNeeded(TElSSHClientHandle _Handle, TSSHPrivateKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_OnPrivateKeyNeeded(TElSSHClientHandle _Handle, TSSHPrivateKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_OnSendCommandRequest(TElSSHClientHandle _Handle, TSSHCommandExecutionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_OnSendCommandRequest(TElSSHClientHandle _Handle, TSSHCommandExecutionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_OnPasswordChangeRequest(TElSSHClientHandle _Handle, TSSHPasswordChangeRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_OnPasswordChangeRequest(TElSSHClientHandle _Handle, TSSHPasswordChangeRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_get_OnTunnelRequest(TElSSHClientHandle _Handle, TSSHTunnelRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_set_OnTunnelRequest(TElSSHClientHandle _Handle, TSSHTunnelRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClient_Create(TComponentHandle AOwner, TElSSHClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHCLIENT */

#ifdef SB_USE_CLASS_TELSSHCLIENTTUNNELLIST
SB_IMPORT uint32_t SB_APIENTRY TElSSHClientTunnelList_Create(TComponentHandle AOwner, TElSSHTunnelListHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHCLIENTTUNNELLIST */

#ifdef SB_USE_CLASS_TELSSHCLIENTTUNNELCONNECTION
SB_IMPORT uint32_t SB_APIENTRY TElSSHClientTunnelConnection_SendData(TElSSHClientTunnelConnectionHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClientTunnelConnection_SendExtendedData(TElSSHClientTunnelConnectionHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClientTunnelConnection_CanSend(TElSSHClientTunnelConnectionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClientTunnelConnection_get_ExtendedDataType(TElSSHClientTunnelConnectionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClientTunnelConnection_Create(TElSSHTunnelConnectionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHCLIENTTUNNELCONNECTION */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSSHClient_ce_ptr;
extern zend_class_entry *TElSSHClientTunnelList_ce_ptr;
extern zend_class_entry *TElSSHClientTunnelConnection_ce_ptr;

void Register_TElSSHClient(TSRMLS_D);
void Register_TElSSHClientTunnelList(TSRMLS_D);
void Register_TElSSHClientTunnelConnection(TSRMLS_D);
void Register_SBSSHClient_Constants(int module_number TSRMLS_DC);
void Register_SBSSHClient_Enum_Flags(TSRMLS_D);
void Register_SBSSHClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSSHCLIENT */

