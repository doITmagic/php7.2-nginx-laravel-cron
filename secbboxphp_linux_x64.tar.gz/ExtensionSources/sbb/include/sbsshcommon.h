#ifndef __INC_SBSSHCOMMON
#define __INC_SBSSHCOMMON

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbmath.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbrandom.h"
#include "sbocspstorage.h"
#include "sbcustomcertstorage.h"
#include "sbchsconv.h"
#include "sbchsconvcharsets.h"
#include "sbchscjk.h"
#include "sbsshterm.h"
#include "sbsharedresource.h"
#include "sbsshconstants.h"
#include "sbsshkeystorage.h"
#include "sbsshutils.h"
#include "sbcryptoprov.h"
#include "sbsymmetriccrypto.h"
#include "sbcryptoprovmanager.h"
#include "sbhashfunction.h"
#include "sbx509.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_OBFUSCATE_MAGIC_VALUE 	200657534
#define SB_OBFUSCATE_MAX_PADDING 	8192
#define SB_OBFUSCATE_SEED_LENGTH 	16
#define SB_OBFUSCATE_HASH_ITERATIONS 	6000
#define SB_OBFUSCATE_KEY_LENGTH 	16
#define SB_CURVE25519_SIZE 	32
#define SB_CURVE448_SIZE 	56
#define SB_SNewPasswordRequest 	"New password needed"
#define SB_SSessionRequestintTunnelsAreOnlyAllowed 	"Session-requesting tunnel objects are only allowed"

typedef TElClassHandle TElSSHClassHandle;

typedef TElSSHClassHandle ElSSHClassHandle;

typedef TElClassHandle TElSSHTunnelListHandle;

typedef TElSSHTunnelListHandle ElSSHTunnelListHandle;

typedef TElClassHandle TElCustomSSHTunnelHandle;

typedef TElCustomSSHTunnelHandle ElCustomSSHTunnelHandle;

typedef TElClassHandle TElSSHTunnelConnectionHandle;

typedef TElSSHTunnelConnectionHandle ElSSHTunnelConnectionHandle;

typedef TElClassHandle TElCustomSSHTunnelParamsHandle;

typedef TElClassHandle TElShellSSHTunnelHandle;

typedef TElShellSSHTunnelHandle ElShellSSHTunnelHandle;

typedef TElClassHandle TElCommandSSHTunnelHandle;

typedef TElCommandSSHTunnelHandle ElCommandSSHTunnelHandle;

typedef TElClassHandle TElSubsystemSSHTunnelHandle;

typedef TElSubsystemSSHTunnelHandle ElSubsystemSSHTunnelHandle;

typedef TElClassHandle TElRemotePortForwardSSHTunnelHandle;

typedef TElRemotePortForwardSSHTunnelHandle ElRemotePortForwardSSHTunnelHandle;

typedef TElClassHandle TElLocalPortForwardSSHTunnelHandle;

typedef TElLocalPortForwardSSHTunnelHandle ElLocalPortForwardSSHTunnelHandle;

typedef TElClassHandle TElLocalPortForwardSSHTunnelParamsHandle;

typedef TElClassHandle TElX11ForwardSSHTunnelHandle;

typedef TElX11ForwardSSHTunnelHandle ElX11ForwardSSHTunnelHandle;

typedef TElClassHandle TElAuthenticationAgentSSHTunnelHandle;

typedef TElAuthenticationAgentSSHTunnelHandle ElAuthenticationAgentSSHTunnelHandle;

typedef TElClassHandle TElSSHAuthHandlerHandle;

typedef uint8_t TSSHTunnelTypeRaw;

typedef enum
{
	ttLocalPortToRemoteAddress = 0,
	ttRemotePortToLocalAddress = 1,
	ttX11 = 2,
	ttAuthenticationAgent = 3,
	ttSubsystem = 4,
	ttCommand = 5,
	ttShell = 6
} TSSHTunnelType;

typedef uint8_t TSSHCloseTypeRaw;

typedef enum
{
	ctReturn = 0,
	ctSignal = 1,
	ctError = 2
} TSSHCloseType;

typedef uint8_t TSBSSHAuthOrderRaw;

typedef enum
{
	aoDefault = 0,
	aoKbdIntLast = 1,
	aoCustom = 2
} TSBSSHAuthOrder;

typedef void (SB_CALLBACK *TSSHSendEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);

typedef void (SB_CALLBACK *TSSHReceiveEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t MaxSize, int32_t * Written);

typedef void (SB_CALLBACK *TSSHDataEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);

typedef void (SB_CALLBACK *TSSHOpenConnectionEvent)(void * _ObjectData, TObjectHandle Sender);

typedef void (SB_CALLBACK *TSSHCloseConnectionEvent)(void * _ObjectData, TObjectHandle Sender);

typedef void (SB_CALLBACK *TSSHChannelCloseEvent)(void * _ObjectData, TObjectHandle Sender, TSSHCloseTypeRaw CloseType);

typedef void (SB_CALLBACK *TSSHErrorEvent)(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode);

typedef void (SB_CALLBACK *TSSHPrivateKeyNeededEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHKeyHandle Key, int8_t * Skip);

typedef void (SB_CALLBACK *TSSHKexInitReceivedEvent)(void * _ObjectData, TObjectHandle Sender, TElStringListHandle KexLines);

typedef void (SB_CALLBACK *TTunnelEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle TunnelConnection);

typedef void (SB_CALLBACK *TTunnelDataEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle TunnelConnection, void * Buffer, int32_t Size);

typedef void (SB_CALLBACK *TTunnelErrorEvent)(void * _ObjectData, TObjectHandle Sender, int32_t Error, void * Data);

typedef void (SB_CALLBACK *TSSHAuthenticationFailedEvent)(void * _ObjectData, TObjectHandle Sender, int32_t AuthenticationType);

typedef void (SB_CALLBACK *TSSHAuthenticationKeyboardEvent)(void * _ObjectData, TObjectHandle Sender, TStringListHandle Prompts, TBitsHandle Echo, TStringListHandle Responses);

typedef void (SB_CALLBACK *TSSHAuthenticationStartEvent)(void * _ObjectData, TObjectHandle Sender, int32_t SupportedAuths);

typedef void (SB_CALLBACK *TSSHAuthenticationAttemptEvent)(void * _ObjectData, TObjectHandle Sender, int32_t AuthType, TObjectHandle AuthParam);

typedef void (SB_CALLBACK *TSSHKeyValidateEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHKeyHandle ServerKey, int8_t * Validate);

typedef void (SB_CALLBACK *TSSHBannerEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pText[], int32_t szText, const uint8_t pLanguage[], int32_t szLanguage);

typedef void (SB_CALLBACK *TSSHMessageLoopEvent)(void * _ObjectData, int8_t * OutResult);

typedef void (SB_CALLBACK *TSSHWindowChangedEvent)(void * _ObjectData, TObjectHandle Sender, int32_t Cols, int32_t Rows, int32_t Width, int32_t Height);

typedef void (SB_CALLBACK *TSSHCommandExecutionEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcCommand, int32_t szCommand, int32_t CommandIdx);

typedef void (SB_CALLBACK *TSSHPasswordChangeRequestEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcPrompt, int32_t szPrompt, char * pcNewPassword, int32_t * szNewPassword, int8_t * Cancel);

typedef void (SB_CALLBACK *TSSHTunnelRequestEvent)(void * _ObjectData, TObjectHandle Sender, TElCustomSSHTunnelHandle Tunnel, int8_t * Allow);

typedef void (SB_CALLBACK *TSSHEOFEvent)(void * _ObjectData, TObjectHandle Sender, int8_t * CloseChannel);

typedef uint8_t TSSHReceiveStateRaw;

typedef enum
{
	rsRecordHeaderWanted = 0,
	rsRecordWanted = 1,
	rsMACWanted = 2
} TSSHReceiveState;

typedef void (SB_CALLBACK *TSSHCertificateValidateEvent)(void * _ObjectData, TObjectHandle Sender, TElCustomCertStorageHandle CertStorage, TElOCSPResponseStorageHandle OCSPStorage, int8_t * Validate);

typedef uint8_t TSSHVersionRaw;

typedef enum
{
	sbSSH1 = 0,
	sbSSH2 = 1
} TSSHVersion;

typedef uint32_t TSSHVersionsRaw;

typedef enum 
{
	f_sbSSH1 = 1,
	f_sbSSH2 = 2
} TSSHVersions;

typedef uint8_t TSSHStandardAlgorithmPriorityTemplateRaw;

typedef enum
{
	sapDefault = 0,
	sapDefinite = 1,
	sapUniform = 2
} TSSHStandardAlgorithmPriorityTemplate;

typedef uint8_t TSSH1StateRaw;

typedef enum
{
	stNotEncrypted = 0,
	stEncrypted = 1
} TSSH1State;

#pragma pack(8)
typedef struct 
{
	PLInt P;
	PLInt G;
	PLInt Q;
	PLInt X;
	PLInt E;
	PLInt K;
} TDHParams;

#pragma pack(8)
typedef struct 
{
	int32_t CurveID;
#ifdef CPU64
	int32_t _dummy0;
#endif
	void * D;
	void * QX;
	void * QY;
	void * Q;
	void * K;
} TECDHParams;

#pragma pack(8)
typedef struct 
{
	void * PrivateKey;
	void * PublicKey;
	void * K;
} TC25519Params;

#pragma pack(8)
typedef struct 
{
	void * PrivateKey;
	void * PublicKey;
	void * K;
} TC448Params;

#pragma pack(8)
typedef struct 
{
	PLInt Modulus;
	PLInt PublicExponent;
	PLInt PrivateExponent;
} TRSAParams;

#pragma pack(8)
typedef struct 
{
	void * ClientVersionString;
	void * ServerVersionString;
	void * ClientKexInit;
	void * ServerKexInit;
	void * PubHostKey;
	void * Min;
	void * Max;
	void * N;
	void * P;
	void * G;
	void * E;
	void * F;
} THandshakeParams;

#pragma pack(8)
typedef struct 
{
	int32_t Cipher;
	int32_t Auth;
	uint8_t SessionID[16];
	uint8_t SessionKey[32];
} TSSH1Params;

#pragma pack(8)
typedef struct 
{
	int32_t KexAlgorithm;
	int32_t ServerHostKeyAlgorithm;
	int32_t EncryptionAlgorithmCS;
	int32_t EncryptionAlgorithmSC;
	int32_t EncCSBlockSize;
	int32_t EncSCBlockSize;
	int32_t MacAlgorithmCS;
	int32_t MacAlgorithmSC;
	void * MacKeyCS;
	void * MacKeySC;
	int32_t CompAlgorithmCS;
	int32_t CompAlgorithmSC;
	int32_t LanguageCS;
	int32_t LanguageSC;
	int32_t HashAlgorithm;
#ifdef CPU64
	int32_t _dummy0;
#endif
	void * SessionID;
} TSSH2Params;

typedef TElClassHandle IElSSHAuthHandlerContainerHandle;

#ifdef SB_USE_CLASS_TELSSHCLASS
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_Close(TElSSHClassHandle _Handle, int8_t Forced);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_RenegotiateCiphers(TElSSHClassHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_AdjustAlgorithmPriorities(TElSSHClassHandle _Handle, TSSHStandardAlgorithmPriorityTemplateRaw Priorities);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_Active(TElSSHClassHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_EncryptionAlgorithms(TElSSHClassHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_EncryptionAlgorithms(TElSSHClassHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_CompressionAlgorithms(TElSSHClassHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_CompressionAlgorithms(TElSSHClassHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_MacAlgorithms(TElSSHClassHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_MacAlgorithms(TElSSHClassHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_KexAlgorithms(TElSSHClassHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_KexAlgorithms(TElSSHClassHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_PublicKeyAlgorithms(TElSSHClassHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_PublicKeyAlgorithms(TElSSHClassHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_EncryptionAlgorithmPriorities(TElSSHClassHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_EncryptionAlgorithmPriorities(TElSSHClassHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_CompressionAlgorithmPriorities(TElSSHClassHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_CompressionAlgorithmPriorities(TElSSHClassHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_MacAlgorithmPriorities(TElSSHClassHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_MacAlgorithmPriorities(TElSSHClassHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_KexAlgorithmPriorities(TElSSHClassHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_KexAlgorithmPriorities(TElSSHClassHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_PublicKeyAlgorithmPriorities(TElSSHClassHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_PublicKeyAlgorithmPriorities(TElSSHClassHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_EncryptionAlgorithmServerToClient(TElSSHClassHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_EncryptionAlgorithmClientToServer(TElSSHClassHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_CompressionAlgorithmServerToClient(TElSSHClassHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_CompressionAlgorithmClientToServer(TElSSHClassHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_MacAlgorithmServerToClient(TElSSHClassHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_MacAlgorithmClientToServer(TElSSHClassHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_KexAlgorithm(TElSSHClassHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_PublicKeyAlgorithm(TElSSHClassHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_TotalBytesSent(TElSSHClassHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_TotalBytesReceived(TElSSHClassHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_SoftwareName(TElSSHClassHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_SoftwareName(TElSSHClassHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_KeyStorage(TElSSHClassHandle _Handle, TElSSHCustomKeyStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_KeyStorage(TElSSHClassHandle _Handle, TElSSHCustomKeyStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_CertStorage(TElSSHClassHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_CertStorage(TElSSHClassHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_OCSPStorage(TElSSHClassHandle _Handle, TElOCSPResponseStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_OCSPStorage(TElSSHClassHandle _Handle, TElOCSPResponseStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_ForceCompression(TElSSHClassHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_ForceCompression(TElSSHClassHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_CompressionLevel(TElSSHClassHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_CompressionLevel(TElSSHClassHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_AuthenticationTypes(TElSSHClassHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_AuthenticationTypes(TElSSHClassHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_CloseIfNoActiveTunnels(TElSSHClassHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_CloseIfNoActiveTunnels(TElSSHClassHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_UseUTF8(TElSSHClassHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_UseUTF8(TElSSHClassHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_CryptoProviderManager(TElSSHClassHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_CryptoProviderManager(TElSSHClassHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_NoCharacterEncoding(TElSSHClassHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_NoCharacterEncoding(TElSSHClassHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_LocalCharset(TElSSHClassHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_LocalCharset(TElSSHClassHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_RemoteCharset(TElSSHClassHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_RemoteCharset(TElSSHClassHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_ObfuscateHandshake(TElSSHClassHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_ObfuscateHandshake(TElSSHClassHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_ObfuscationPassword(TElSSHClassHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_ObfuscationPassword(TElSSHClassHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_OnSend(TElSSHClassHandle _Handle, TSSHSendEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_OnSend(TElSSHClassHandle _Handle, TSSHSendEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_OnReceive(TElSSHClassHandle _Handle, TSSHReceiveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_OnReceive(TElSSHClassHandle _Handle, TSSHReceiveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_OnOpenConnection(TElSSHClassHandle _Handle, TSSHOpenConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_OnOpenConnection(TElSSHClassHandle _Handle, TSSHOpenConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_OnCloseConnection(TElSSHClassHandle _Handle, TSSHCloseConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_OnCloseConnection(TElSSHClassHandle _Handle, TSSHCloseConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_OnDebugData(TElSSHClassHandle _Handle, TSSHDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_OnDebugData(TElSSHClassHandle _Handle, TSSHDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_OnError(TElSSHClassHandle _Handle, TSSHErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_OnError(TElSSHClassHandle _Handle, TSSHErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_OnCiphersNegotiated(TElSSHClassHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_OnCiphersNegotiated(TElSSHClassHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_OnKexInitReceived(TElSSHClassHandle _Handle, TSSHKexInitReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_OnKexInitReceived(TElSSHClassHandle _Handle, TSSHKexInitReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_get_OnCertificateValidate(TElSSHClassHandle _Handle, TSSHCertificateValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_set_OnCertificateValidate(TElSSHClassHandle _Handle, TSSHCertificateValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHClass_Create(TComponentHandle AOwner, TElSSHClassHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHCLASS */

#ifdef SB_USE_CLASS_TELSSHTUNNELLIST
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelList_FindTunnel(TElSSHTunnelListHandle _Handle, const char * pcSubSystemType, int32_t szSubSystemType, const char * pcSubSystemName, int32_t szSubSystemName, TElCustomSSHTunnelHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelList_get_SSHClass(TElSSHTunnelListHandle _Handle, TElSSHClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelList_get_Tunnels(TElSSHTunnelListHandle _Handle, int32_t Index, TElCustomSSHTunnelHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelList_get_Count(TElSSHTunnelListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelList_Create(TComponentHandle AOwner, TElSSHTunnelListHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHTUNNELLIST */

#ifdef SB_USE_CLASS_TELCUSTOMSSHTUNNEL
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_DoOpen(TElCustomSSHTunnelHandle _Handle, TElSSHTunnelConnectionHandle Connection);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_DoClose(TElCustomSSHTunnelHandle _Handle, TElSSHTunnelConnectionHandle Connection);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_DoError(TElCustomSSHTunnelHandle _Handle, int32_t Error, void * Data);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_AddConnection(TElCustomSSHTunnelHandle _Handle, TElSSHTunnelConnectionHandle Conn);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_RemoveConnection(TElCustomSSHTunnelHandle _Handle, TElSSHTunnelConnectionHandle Conn);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_Open(TElCustomSSHTunnelHandle _Handle, void * Data);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_get_Connections(TElCustomSSHTunnelHandle _Handle, int32_t Index, TElSSHTunnelConnectionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_get_ConnectionCount(TElCustomSSHTunnelHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_get_ConnectionsList(TElCustomSSHTunnelHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_get_AutoOpen(TElCustomSSHTunnelHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_set_AutoOpen(TElCustomSSHTunnelHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_get_TunnelList(TElCustomSSHTunnelHandle _Handle, TElSSHTunnelListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_set_TunnelList(TElCustomSSHTunnelHandle _Handle, TElSSHTunnelListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_get_OnOpen(TElCustomSSHTunnelHandle _Handle, TTunnelEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_set_OnOpen(TElCustomSSHTunnelHandle _Handle, TTunnelEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_get_OnClose(TElCustomSSHTunnelHandle _Handle, TTunnelEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_set_OnClose(TElCustomSSHTunnelHandle _Handle, TTunnelEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_get_OnError(TElCustomSSHTunnelHandle _Handle, TTunnelErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_set_OnError(TElCustomSSHTunnelHandle _Handle, TTunnelErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnel_Create(TComponentHandle AOwner, TElCustomSSHTunnelHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMSSHTUNNEL */

#ifdef SB_USE_CLASS_TELSSHTUNNELCONNECTION
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_SendData(TElSSHTunnelConnectionHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_SendExtendedData(TElSSHTunnelConnectionHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_SendSignal(TElSSHTunnelConnectionHandle _Handle, const uint8_t pSignal[], int32_t szSignal);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_SendText(TElSSHTunnelConnectionHandle _Handle, const char * pcS, int32_t szS);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_SendExtendedText(TElSSHTunnelConnectionHandle _Handle, const char * pcS, int32_t szS);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_Close(TElSSHTunnelConnectionHandle _Handle, int8_t FlushCachedData);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_Close_1(TElSSHTunnelConnectionHandle _Handle, int32_t ExitStatus, int8_t FlushCachedData);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_Close_2(TElSSHTunnelConnectionHandle _Handle, const char * pcExitSignal, int32_t szExitSignal, const char * pcExitMessage, int32_t szExitMessage, int8_t FlushCachedData);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_CloseLocal(TElSSHTunnelConnectionHandle _Handle, int8_t FlushCachedData);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_CanSend(TElSSHTunnelConnectionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_Tunnel(TElSSHTunnelConnectionHandle _Handle, TElCustomSSHTunnelHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_set_Tunnel(TElSSHTunnelConnectionHandle _Handle, TElCustomSSHTunnelHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_Data(TElSSHTunnelConnectionHandle _Handle, void * * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_set_Data(TElSSHTunnelConnectionHandle _Handle, void * Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_UseUTF8(TElSSHTunnelConnectionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_set_UseUTF8(TElSSHTunnelConnectionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_HasUnsentData(TElSSHTunnelConnectionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_EOFSent(TElSSHTunnelConnectionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_ExitStatus(TElSSHTunnelConnectionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_ExitSignal(TElSSHTunnelConnectionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_ExitMessage(TElSSHTunnelConnectionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_ReturnExitStatus(TElSSHTunnelConnectionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_set_ReturnExitStatus(TElSSHTunnelConnectionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_ReturnExitSignal(TElSSHTunnelConnectionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_set_ReturnExitSignal(TElSSHTunnelConnectionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_OnData(TElSSHTunnelConnectionHandle _Handle, TSSHDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_set_OnData(TElSSHTunnelConnectionHandle _Handle, TSSHDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_OnExtendedData(TElSSHTunnelConnectionHandle _Handle, TSSHDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_set_OnExtendedData(TElSSHTunnelConnectionHandle _Handle, TSSHDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_OnError(TElSSHTunnelConnectionHandle _Handle, TSSHErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_set_OnError(TElSSHTunnelConnectionHandle _Handle, TSSHErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_OnClose(TElSSHTunnelConnectionHandle _Handle, TSSHChannelCloseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_set_OnClose(TElSSHTunnelConnectionHandle _Handle, TSSHChannelCloseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_OnWindowChanged(TElSSHTunnelConnectionHandle _Handle, TSSHWindowChangedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_set_OnWindowChanged(TElSSHTunnelConnectionHandle _Handle, TSSHWindowChangedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_get_OnEOF(TElSSHTunnelConnectionHandle _Handle, TSSHEOFEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_set_OnEOF(TElSSHTunnelConnectionHandle _Handle, TSSHEOFEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelConnection_Create(TElSSHTunnelConnectionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHTUNNELCONNECTION */

#ifdef SB_USE_CLASS_TELCUSTOMSSHTUNNELPARAMS
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHTunnelParams_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMSSHTUNNELPARAMS */

#ifdef SB_USE_CLASS_TELSHELLSSHTUNNEL
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHTunnel_get_TerminalInfo(TElShellSSHTunnelHandle _Handle, TElTerminalInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHTunnel_set_TerminalInfo(TElShellSSHTunnelHandle _Handle, TElTerminalInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHTunnel_get_Environment(TElShellSSHTunnelHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHTunnel_get_RequestTerminal(TElShellSSHTunnelHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHTunnel_set_RequestTerminal(TElShellSSHTunnelHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHTunnel_Create(TComponentHandle AOwner, TElShellSSHTunnelHandle * OutResult);
#endif /* SB_USE_CLASS_TELSHELLSSHTUNNEL */

#ifdef SB_USE_CLASS_TELCOMMANDSSHTUNNEL
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSHTunnel_get_Command(TElCommandSSHTunnelHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSHTunnel_set_Command(TElCommandSSHTunnelHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSHTunnel_get_Commands(TElCommandSSHTunnelHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSHTunnel_get_ActiveCommand(TElCommandSSHTunnelHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSHTunnel_set_ActiveCommand(TElCommandSSHTunnelHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSHTunnel_get_Environment(TElCommandSSHTunnelHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSHTunnel_get_TerminalInfo(TElCommandSSHTunnelHandle _Handle, TElTerminalInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSHTunnel_set_TerminalInfo(TElCommandSSHTunnelHandle _Handle, TElTerminalInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSHTunnel_get_RequestTerminal(TElCommandSSHTunnelHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSHTunnel_set_RequestTerminal(TElCommandSSHTunnelHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCommandSSHTunnel_Create(TComponentHandle AOwner, TElCommandSSHTunnelHandle * OutResult);
#endif /* SB_USE_CLASS_TELCOMMANDSSHTUNNEL */

#ifdef SB_USE_CLASS_TELSUBSYSTEMSSHTUNNEL
SB_IMPORT uint32_t SB_APIENTRY TElSubsystemSSHTunnel_get_Subsystem(TElSubsystemSSHTunnelHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSubsystemSSHTunnel_set_Subsystem(TElSubsystemSSHTunnelHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSubsystemSSHTunnel_get_Environment(TElSubsystemSSHTunnelHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSubsystemSSHTunnel_Create(TComponentHandle AOwner, TElSubsystemSSHTunnelHandle * OutResult);
#endif /* SB_USE_CLASS_TELSUBSYSTEMSSHTUNNEL */

#ifdef SB_USE_CLASS_TELREMOTEPORTFORWARDSSHTUNNEL
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_DoSetupSucceeded(TElRemotePortForwardSSHTunnelHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_DoSetupFailed(TElRemotePortForwardSSHTunnelHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_GetToHost(TElRemotePortForwardSSHTunnelHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_SetToHost(TElRemotePortForwardSSHTunnelHandle _Handle, const char * pcAValue, int32_t szAValue);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_Close(TElRemotePortForwardSSHTunnelHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_get_Host(TElRemotePortForwardSSHTunnelHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_set_Host(TElRemotePortForwardSSHTunnelHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_get_Port(TElRemotePortForwardSSHTunnelHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_set_Port(TElRemotePortForwardSSHTunnelHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_get_ToHost(TElRemotePortForwardSSHTunnelHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_set_ToHost(TElRemotePortForwardSSHTunnelHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_get_ToPort(TElRemotePortForwardSSHTunnelHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_set_ToPort(TElRemotePortForwardSSHTunnelHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_get_BoundPort(TElRemotePortForwardSSHTunnelHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_set_BoundPort(TElRemotePortForwardSSHTunnelHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_get_UseDefaultBindAddress(TElRemotePortForwardSSHTunnelHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_set_UseDefaultBindAddress(TElRemotePortForwardSSHTunnelHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_get_OnSetupSucceeded(TElRemotePortForwardSSHTunnelHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_set_OnSetupSucceeded(TElRemotePortForwardSSHTunnelHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_get_OnSetupFailed(TElRemotePortForwardSSHTunnelHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_set_OnSetupFailed(TElRemotePortForwardSSHTunnelHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElRemotePortForwardSSHTunnel_Create(TComponentHandle AOwner, TElRemotePortForwardSSHTunnelHandle * OutResult);
#endif /* SB_USE_CLASS_TELREMOTEPORTFORWARDSSHTUNNEL */

#ifdef SB_USE_CLASS_TELLOCALPORTFORWARDSSHTUNNEL
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnel_GetToHost(TElLocalPortForwardSSHTunnelHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnel_SetToHost(TElLocalPortForwardSSHTunnelHandle _Handle, const char * pcAValue, int32_t szAValue);
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnel_Open(TElLocalPortForwardSSHTunnelHandle _Handle, void * Data, const char * pcOrigHost, int32_t szOrigHost, int32_t OrigPort);
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnel_Open_1(TElCustomSSHTunnelHandle _Handle, void * Data);
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnel_get_Port(TElLocalPortForwardSSHTunnelHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnel_set_Port(TElLocalPortForwardSSHTunnelHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnel_get_Host(TElLocalPortForwardSSHTunnelHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnel_set_Host(TElLocalPortForwardSSHTunnelHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnel_get_ToHost(TElLocalPortForwardSSHTunnelHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnel_set_ToHost(TElLocalPortForwardSSHTunnelHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnel_get_ToPort(TElLocalPortForwardSSHTunnelHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnel_set_ToPort(TElLocalPortForwardSSHTunnelHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnel_Create(TComponentHandle AOwner, TElLocalPortForwardSSHTunnelHandle * OutResult);
#endif /* SB_USE_CLASS_TELLOCALPORTFORWARDSSHTUNNEL */

#ifdef SB_USE_CLASS_TELLOCALPORTFORWARDSSHTUNNELPARAMS
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnelParams_get_OrigHost(TElLocalPortForwardSSHTunnelParamsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnelParams_get_OrigPort(TElLocalPortForwardSSHTunnelParamsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLocalPortForwardSSHTunnelParams_Create(const char * pcOrigHost, int32_t szOrigHost, int32_t OrigPort, TElLocalPortForwardSSHTunnelParamsHandle * OutResult);
#endif /* SB_USE_CLASS_TELLOCALPORTFORWARDSSHTUNNELPARAMS */

#ifdef SB_USE_CLASS_TELX11FORWARDSSHTUNNEL
SB_IMPORT uint32_t SB_APIENTRY TElX11ForwardSSHTunnel_get_AuthenticationProtocol(TElX11ForwardSSHTunnelHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX11ForwardSSHTunnel_set_AuthenticationProtocol(TElX11ForwardSSHTunnelHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElX11ForwardSSHTunnel_get_Cookie(TElX11ForwardSSHTunnelHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX11ForwardSSHTunnel_set_Cookie(TElX11ForwardSSHTunnelHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElX11ForwardSSHTunnel_get_ScreenNumber(TElX11ForwardSSHTunnelHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX11ForwardSSHTunnel_set_ScreenNumber(TElX11ForwardSSHTunnelHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElX11ForwardSSHTunnel_get_TerminalInfo(TElX11ForwardSSHTunnelHandle _Handle, TElTerminalInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX11ForwardSSHTunnel_set_TerminalInfo(TElX11ForwardSSHTunnelHandle _Handle, TElTerminalInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElX11ForwardSSHTunnel_get_Environment(TElX11ForwardSSHTunnelHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX11ForwardSSHTunnel_get_RequestTerminal(TElX11ForwardSSHTunnelHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX11ForwardSSHTunnel_set_RequestTerminal(TElX11ForwardSSHTunnelHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElX11ForwardSSHTunnel_get_Target(TElX11ForwardSSHTunnelHandle _Handle, TElCustomSSHTunnelHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX11ForwardSSHTunnel_set_Target(TElX11ForwardSSHTunnelHandle _Handle, TElCustomSSHTunnelHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElX11ForwardSSHTunnel_Create(TComponentHandle AOwner, TElX11ForwardSSHTunnelHandle * OutResult);
#endif /* SB_USE_CLASS_TELX11FORWARDSSHTUNNEL */

#ifdef SB_USE_CLASS_TELAUTHENTICATIONAGENTSSHTUNNEL
SB_IMPORT uint32_t SB_APIENTRY TElAuthenticationAgentSSHTunnel_Create(TComponentHandle AOwner, TElCustomSSHTunnelHandle * OutResult);
#endif /* SB_USE_CLASS_TELAUTHENTICATIONAGENTSSHTUNNEL */

#ifdef SB_USE_CLASS_TELSSHAUTHHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthHandler_GetAlgorithmFromClientKexDHReply(TElSSHAuthHandlerHandle _Handle, const uint8_t pHostAlg[], int32_t szHostAlg, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthHandler_ValidateServerSignature(TElSSHAuthHandlerHandle _Handle, int32_t Algorithm, const uint8_t pPubKeyStr[], int32_t szPubKeyStr, const uint8_t pSignature[], int32_t szSignature, const uint8_t pHash[], int32_t szHash, int32_t HashAlg, int32_t * ErrCode, char * pcErrMessage, int32_t * szErrMessage, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthHandler_FindKeyByAlgorithm(TElSSHAuthHandlerHandle _Handle, TElSSHCustomKeyStorageHandle Storage, int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthHandler_GetKeyBlob(TElSSHAuthHandlerHandle _Handle, TElSSHKeyHandle Key, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthHandler_KeyBlobToKey(TElSSHAuthHandlerHandle _Handle, const char * pcAlgName, int32_t szAlgName, const uint8_t pBlob[], int32_t szBlob, TElSSHKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthHandler_HashAlgFromKey(TElSSHAuthHandlerHandle _Handle, TElSSHKeyHandle Key, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthHandler_CalculateServerSignature(TElSSHAuthHandlerHandle _Handle, TElSSHKeyHandle Key, const uint8_t paHash[], int32_t szaHash, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthHandler_ServerValidateClientSignature(TElSSHAuthHandlerHandle _Handle, const uint8_t pAlgName[], int32_t szAlgName, const uint8_t pKeyBlob[], int32_t szKeyBlob, const uint8_t pSignature[], int32_t szSignature, const uint8_t pHash[], int32_t szHash, int8_t * Valid, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthHandler_get_SSHClass(TElSSHAuthHandlerHandle _Handle, IElSSHAuthHandlerContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthHandler_set_SSHClass(TElSSHAuthHandlerHandle _Handle, IElSSHAuthHandlerContainerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHAuthHandler_Create(TComponentHandle AOwner, TComponentHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHAUTHHANDLER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TDHParams_ce_ptr;
extern zend_class_entry *TECDHParams_ce_ptr;
extern zend_class_entry *TC25519Params_ce_ptr;
extern zend_class_entry *TC448Params_ce_ptr;
extern zend_class_entry *TRSAParams_ce_ptr;
extern zend_class_entry *THandshakeParams_ce_ptr;
extern zend_class_entry *TSSH1Params_ce_ptr;
extern zend_class_entry *TSSH2Params_ce_ptr;
extern zend_class_entry *IElSSHAuthHandlerContainer_ce_ptr;
extern zend_class_entry *TElSSHClass_ce_ptr;
extern zend_class_entry *TElSSHTunnelList_ce_ptr;
extern zend_class_entry *TElCustomSSHTunnel_ce_ptr;
extern zend_class_entry *TElSSHTunnelConnection_ce_ptr;
extern zend_class_entry *TElCustomSSHTunnelParams_ce_ptr;
extern zend_class_entry *TElShellSSHTunnel_ce_ptr;
extern zend_class_entry *TElCommandSSHTunnel_ce_ptr;
extern zend_class_entry *TElSubsystemSSHTunnel_ce_ptr;
extern zend_class_entry *TElRemotePortForwardSSHTunnel_ce_ptr;
extern zend_class_entry *TElLocalPortForwardSSHTunnel_ce_ptr;
extern zend_class_entry *TElLocalPortForwardSSHTunnelParams_ce_ptr;
extern zend_class_entry *TElX11ForwardSSHTunnel_ce_ptr;
extern zend_class_entry *TElAuthenticationAgentSSHTunnel_ce_ptr;
extern zend_class_entry *TElSSHAuthHandler_ce_ptr;

void SB_CALLBACK TSSHSendEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);
void SB_CALLBACK TSSHReceiveEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t MaxSize, int32_t * Written);
void SB_CALLBACK TSSHDataEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);
void SB_CALLBACK TSSHOpenConnectionEventRaw(void * _ObjectData, TObjectHandle Sender);
void SB_CALLBACK TSSHCloseConnectionEventRaw(void * _ObjectData, TObjectHandle Sender);
void SB_CALLBACK TSSHChannelCloseEventRaw(void * _ObjectData, TObjectHandle Sender, TSSHCloseTypeRaw CloseType);
void SB_CALLBACK TSSHErrorEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode);
void SB_CALLBACK TSSHPrivateKeyNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHKeyHandle Key, int8_t * Skip);
void SB_CALLBACK TSSHKexInitReceivedEventRaw(void * _ObjectData, TObjectHandle Sender, TElStringListHandle KexLines);
void SB_CALLBACK TTunnelEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle TunnelConnection);
void SB_CALLBACK TTunnelDataEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle TunnelConnection, void * Buffer, int32_t Size);
void SB_CALLBACK TTunnelErrorEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t Error, void * Data);
void SB_CALLBACK TSSHAuthenticationFailedEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t AuthenticationType);
void SB_CALLBACK TSSHAuthenticationKeyboardEventRaw(void * _ObjectData, TObjectHandle Sender, TStringListHandle Prompts, TBitsHandle Echo, TStringListHandle Responses);
void SB_CALLBACK TSSHAuthenticationStartEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t SupportedAuths);
void SB_CALLBACK TSSHAuthenticationAttemptEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t AuthType, TObjectHandle AuthParam);
void SB_CALLBACK TSSHKeyValidateEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHKeyHandle ServerKey, int8_t * Validate);
void SB_CALLBACK TSSHBannerEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pText[], int32_t szText, const uint8_t pLanguage[], int32_t szLanguage);
void SB_CALLBACK TSSHMessageLoopEventRaw(void * _ObjectData, int8_t * OutResult);
void SB_CALLBACK TSSHWindowChangedEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t Cols, int32_t Rows, int32_t Width, int32_t Height);
void SB_CALLBACK TSSHCommandExecutionEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcCommand, int32_t szCommand, int32_t CommandIdx);
void SB_CALLBACK TSSHPasswordChangeRequestEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcPrompt, int32_t szPrompt, char * pcNewPassword, int32_t * szNewPassword, int8_t * Cancel);
void SB_CALLBACK TSSHTunnelRequestEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomSSHTunnelHandle Tunnel, int8_t * Allow);
void SB_CALLBACK TSSHEOFEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t * CloseChannel);
void SB_CALLBACK TSSHCertificateValidateEventRaw(void * _ObjectData, TObjectHandle Sender, TElCustomCertStorageHandle CertStorage, TElOCSPResponseStorageHandle OCSPStorage, int8_t * Validate);
void Register_TDHParams(TSRMLS_D);
void Register_TECDHParams(TSRMLS_D);
void Register_TC25519Params(TSRMLS_D);
void Register_TC448Params(TSRMLS_D);
void Register_TRSAParams(TSRMLS_D);
void Register_THandshakeParams(TSRMLS_D);
void Register_TSSH1Params(TSRMLS_D);
void Register_TSSH2Params(TSRMLS_D);
void Register_TElSSHClass(TSRMLS_D);
void Register_TElSSHTunnelList(TSRMLS_D);
void Register_TElCustomSSHTunnel(TSRMLS_D);
void Register_TElSSHTunnelConnection(TSRMLS_D);
void Register_TElCustomSSHTunnelParams(TSRMLS_D);
void Register_TElShellSSHTunnel(TSRMLS_D);
void Register_TElCommandSSHTunnel(TSRMLS_D);
void Register_TElSubsystemSSHTunnel(TSRMLS_D);
void Register_TElRemotePortForwardSSHTunnel(TSRMLS_D);
void Register_TElLocalPortForwardSSHTunnel(TSRMLS_D);
void Register_TElLocalPortForwardSSHTunnelParams(TSRMLS_D);
void Register_TElX11ForwardSSHTunnel(TSRMLS_D);
void Register_TElAuthenticationAgentSSHTunnel(TSRMLS_D);
void Register_TElSSHAuthHandler(TSRMLS_D);
SB_PHP_FUNCTION(SBSSHCommon, SSHEncodeString);
SB_PHP_FUNCTION(SBSSHCommon, SSHDecodeString);
SB_PHP_FUNCTION(SBSSHCommon, SSHMemoryManager);
void Register_SBSSHCommon_Constants(int module_number TSRMLS_DC);
void Register_SBSSHCommon_Enum_Flags(TSRMLS_D);
void Register_SBSSHCommon_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_SSHCOMMON
SB_IMPORT uint32_t SB_APIENTRY SBSSHCommon_SSHEncodeString(const char * pcS, int32_t szS, int8_t UseUTF8, int8_t NoTranslation, TPlConverterHandle Converter, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSSHCommon_SSHDecodeString(const uint8_t pBuf[], int32_t szBuf, int8_t UseUTF8, int8_t NoTranslation, TPlConverterHandle Converter, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSSHCommon_SSHMemoryManager(TElByteArrayManagerHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_SSHCOMMON */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSSHCOMMON */
