#ifndef __INC_SBSSHCONNECTIONHANDLER
#define __INC_SBSSHCONNECTIONHANDLER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbsshcommon.h"
#include "sbsharedresource.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSSHConnectionHandlerHandle;

typedef TElSSHConnectionHandlerHandle ElSSHConnectionHandlerHandle;

#ifdef SB_USE_CLASS_TELSSHCONNECTIONHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElSSHConnectionHandler_Disconnect(TElSSHConnectionHandlerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHConnectionHandler_SendData(TElSSHConnectionHandlerHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSSHConnectionHandler_SendExtendedData(TElSSHConnectionHandlerHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSSHConnectionHandler_ReceiveData(TElSSHConnectionHandlerHandle _Handle, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHConnectionHandler_ReceiveLength(TElSSHConnectionHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHConnectionHandler_get_Connected(TElSSHConnectionHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHConnectionHandler_get_Connection(TElSSHConnectionHandlerHandle _Handle, TElSSHTunnelConnectionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHConnectionHandler_get_OnDisconnect(TElSSHConnectionHandlerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHConnectionHandler_set_OnDisconnect(TElSSHConnectionHandlerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHConnectionHandler_Create(TElSSHTunnelConnectionHandle Connection, TElSSHConnectionHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHCONNECTIONHANDLER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSSHConnectionHandler_ce_ptr;

void Register_TElSSHConnectionHandler(TSRMLS_D);
void Register_SBSSHConnectionHandler_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSSHCONNECTIONHANDLER */

