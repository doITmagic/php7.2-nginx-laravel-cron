#ifndef __INC_SBSSHFORWARDING
#define __INC_SBSSHFORWARDING

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcryptoprov.h"
#include "sbsshcommon.h"
#include "sbsshclient.h"
#include "sbsshkeystorage.h"
#include "sbsharedresource.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbstrutils.h"
#include "sbdnssectypes.h"
#include "sbdnssecutils.h"
#include "sbgssapibase.h"
#include "sbgssapi.h"
#include "sbsocket.h"
#include "sbportknock.h"
#include "sbsshconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_SSH_TCP_CONNECTION_FAILED 	24577
#define SB_ERROR_SSH_TCP_BIND_FAILED 	24578

typedef TElClassHandle TElSSHForwardedConnectionHandle;

typedef TElSSHForwardedConnectionHandle ElSSHForwardedConnectionHandle;

typedef TElClassHandle TElSSHForwardingTunnelHandle;

typedef TElClassHandle TElSSHForwardingSessionHandle;

typedef TElSSHForwardingSessionHandle ElSSHForwardingSessionHandle;

typedef TElClassHandle TElSSHCustomForwardingHandle;

typedef TElSSHCustomForwardingHandle ElSSHCustomForwardingHandle;

typedef TElClassHandle TElSSHForwardingInterceptHandle;

typedef TElClassHandle TElSSHLocalPortForwardingHandle;

typedef TElSSHLocalPortForwardingHandle ElSSHLocalPortForwardingHandle;

typedef TElClassHandle TElSSHRemotePortForwardingHandle;

typedef TElSSHRemotePortForwardingHandle ElSSHRemotePortForwardingHandle;

typedef TElClassHandle TElSSHTunnelStateHandle;

typedef TElClassHandle TElSSHLPFListeningThreadHandle;

typedef TElClassHandle TElSSHLocalTunnelStateHandle;

typedef TElClassHandle TElSSHRemoteTunnelStateHandle;

typedef TElClassHandle TElSSHLocalPortForwardingSessionHandle;

typedef TElSSHLocalPortForwardingSessionHandle ElSSHLocalPortForwardingSessionHandle;

typedef TElClassHandle TElSSHRemotePortForwardingSessionHandle;

typedef TElSSHRemotePortForwardingSessionHandle ElSSHRemotePortForwardingSessionHandle;

typedef TElClassHandle TElSSHScheduledSpecialMessageHandle;

typedef void (SB_CALLBACK *TSBSSHConnectionEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHForwardedConnectionHandle Conn);

typedef void (SB_CALLBACK *TSBSSHConnectionErrorEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHForwardedConnectionHandle Conn, int32_t ErrorCode);

typedef void (SB_CALLBACK *TSBSSHTunnelEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHForwardingTunnelHandle Tunnel);

typedef void (SB_CALLBACK *TSBSSHLPFAcceptEvent)(void * _ObjectData, TObjectHandle Sender, TElSocketHandle Socket);

typedef void (SB_CALLBACK *TSBSSHSocketAcceptEvent)(void * _ObjectData, TObjectHandle Sender, TElSocketHandle Socket, int8_t * Reject);

typedef void (SB_CALLBACK *TSBSSHSocksAuthMethodChooseEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHForwardedConnectionHandle Conn, const TElSocksAuthenticationRaw pAuthMethods[], int32_t szAuthMethods, TElSocksAuthenticationRaw * AuthMethod, int8_t * Cancel);

typedef void (SB_CALLBACK *TSBSSHSocksAuthPasswordEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHForwardedConnectionHandle Conn, const char * pcUsername, int32_t szUsername, const char * pcPassword, int32_t szPassword, int8_t * Accept);

typedef void (SB_CALLBACK *TSBSSHSocksConnectEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHForwardedConnectionHandle Conn, const char * pcDestHost, int32_t szDestHost, int32_t DestPort, int8_t * Allow);

typedef void (SB_CALLBACK *TSBSSHBeforeConnectingEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHClientHandle Client, TElSocketHandle Socket);

typedef uint8_t TSBSSHForwardingPriorityRaw;

typedef enum
{
	sfpLow = 0,
	sfpNormal = 1,
	sfpHigh = 2
} TSBSSHForwardingPriority;

typedef uint8_t TSBSSHForwardingSocketStateRaw;

typedef enum
{
	fssEstablishing = 0,
	fssActive = 1,
	fssClosing = 2,
	fssClosed = 3
} TSBSSHForwardingSocketState;

typedef uint8_t TSBSSHForwardingChannelStateRaw;

typedef enum
{
	fcsEstablishing = 0,
	fcsActive = 1,
	fcsClosing = 2,
	fcsClosed = 3
} TSBSSHForwardingChannelState;

#ifdef SB_USE_CLASS_TELSSHFORWARDEDCONNECTION
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_Close(TElSSHForwardedConnectionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_AutoAdjustPriority(TElSSHForwardedConnectionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_set_AutoAdjustPriority(TElSSHForwardedConnectionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_Socket(TElSSHForwardedConnectionHandle _Handle, TElSocketHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_set_Socket(TElSSHForwardedConnectionHandle _Handle, TElSocketHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_ReceivedFromSocket(TElSSHForwardedConnectionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_SentToSocket(TElSSHForwardedConnectionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_ReceivedFromChannel(TElSSHForwardedConnectionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_SentToChannel(TElSSHForwardedConnectionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_SocketState(TElSSHForwardedConnectionHandle _Handle, TSBSSHForwardingSocketStateRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_ChannelState(TElSSHForwardedConnectionHandle _Handle, TSBSSHForwardingChannelStateRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_Data(TElSSHForwardedConnectionHandle _Handle, void * * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_set_Data(TElSSHForwardedConnectionHandle _Handle, void * Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_ForwardedHost(TElSSHForwardedConnectionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_ForwardedPort(TElSSHForwardedConnectionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_DestHost(TElSSHForwardedConnectionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_DestPort(TElSSHForwardedConnectionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_BoundPort(TElSSHForwardedConnectionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_KeepAlivePeriod(TElSSHForwardedConnectionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_set_KeepAlivePeriod(TElSSHForwardedConnectionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_DestUsingIPv6(TElSSHForwardedConnectionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_ForwardedUsingIPv6(TElSSHForwardedConnectionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_SocketReadBufSize(TElSSHForwardedConnectionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_set_SocketReadBufSize(TElSSHForwardedConnectionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_SocketWriteBufSize(TElSSHForwardedConnectionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_set_SocketWriteBufSize(TElSSHForwardedConnectionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_MaxCacheSize(TElSSHForwardedConnectionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_set_MaxCacheSize(TElSSHForwardedConnectionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_ExitStatus(TElSSHForwardedConnectionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_ExitSignal(TElSSHForwardedConnectionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_get_ExitMessage(TElSSHForwardedConnectionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardedConnection_Create(TElSSHForwardingSessionHandle Owner, TElSSHForwardedConnectionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHFORWARDEDCONNECTION */

#ifdef SB_USE_CLASS_TELSSHFORWARDINGTUNNEL
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_Open(TElSSHForwardingTunnelHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_Close(TElSSHForwardingTunnelHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_Active(TElSSHForwardingTunnelHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_BoundPort(TElSSHForwardingTunnelHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_UsingIPv6(TElSSHForwardingTunnelHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_ForwardedHost(TElSSHForwardingTunnelHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_set_ForwardedHost(TElSSHForwardingTunnelHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_ForwardedPort(TElSSHForwardingTunnelHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_set_ForwardedPort(TElSSHForwardingTunnelHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_DestHost(TElSSHForwardingTunnelHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_set_DestHost(TElSSHForwardingTunnelHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_DestPort(TElSSHForwardingTunnelHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_set_DestPort(TElSSHForwardingTunnelHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_DestUseIPv6(TElSSHForwardingTunnelHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_set_DestUseIPv6(TElSSHForwardingTunnelHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_ForwardedUseIPv6(TElSSHForwardingTunnelHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_set_ForwardedUseIPv6(TElSSHForwardingTunnelHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_UseProxySettingsForForwardedConnections(TElSSHForwardingTunnelHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_set_UseProxySettingsForForwardedConnections(TElSSHForwardingTunnelHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_AutoOpen(TElSSHForwardingTunnelHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_set_AutoOpen(TElSSHForwardingTunnelHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_UseDefaultBindAddress(TElSSHForwardingTunnelHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_set_UseDefaultBindAddress(TElSSHForwardingTunnelHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_UseDynamicForwarding(TElSSHForwardingTunnelHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_set_UseDynamicForwarding(TElSSHForwardingTunnelHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_ResolveDynamicForwardingAddresses(TElSSHForwardingTunnelHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_set_ResolveDynamicForwardingAddresses(TElSSHForwardingTunnelHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_SocketReadBufSize(TElSSHForwardingTunnelHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_set_SocketReadBufSize(TElSSHForwardingTunnelHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_SocketWriteBufSize(TElSSHForwardingTunnelHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_set_SocketWriteBufSize(TElSSHForwardingTunnelHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_get_MaxCacheSize(TElSSHForwardingTunnelHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_set_MaxCacheSize(TElSSHForwardingTunnelHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingTunnel_Create(TElSSHCustomForwardingHandle Owner, TElSSHForwardingTunnelHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHFORWARDINGTUNNEL */

#ifdef SB_USE_CLASS_TELSSHFORWARDINGSESSION
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_get_Username(TElSSHForwardingSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_set_Username(TElSSHForwardingSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_get_Password(TElSSHForwardingSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_set_Password(TElSSHForwardingSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_get_ForwardedPort(TElSSHForwardingSessionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_set_ForwardedPort(TElSSHForwardingSessionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_get_DestHost(TElSSHForwardingSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_set_DestHost(TElSSHForwardingSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_get_DestPort(TElSSHForwardingSessionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_set_DestPort(TElSSHForwardingSessionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_get_OnConnectionOpen(TElSSHForwardingSessionHandle _Handle, TSBSSHConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_set_OnConnectionOpen(TElSSHForwardingSessionHandle _Handle, TSBSSHConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_get_OnConnectionChange(TElSSHForwardingSessionHandle _Handle, TSBSSHConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_set_OnConnectionChange(TElSSHForwardingSessionHandle _Handle, TSBSSHConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_get_OnConnectionRemove(TElSSHForwardingSessionHandle _Handle, TSBSSHConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_set_OnConnectionRemove(TElSSHForwardingSessionHandle _Handle, TSBSSHConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_get_OnReceive(TElSSHForwardingSessionHandle _Handle, TSSHReceiveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_set_OnReceive(TElSSHForwardingSessionHandle _Handle, TSSHReceiveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_get_OnSend(TElSSHForwardingSessionHandle _Handle, TSSHSendEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_set_OnSend(TElSSHForwardingSessionHandle _Handle, TSSHSendEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingSession_Create(TElSSHCustomForwardingHandle Owner, TElSSHForwardingSessionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHFORWARDINGSESSION */

#ifdef SB_USE_CLASS_TELSSHCUSTOMFORWARDING
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_Open(TElSSHCustomForwardingHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_Close(TElSSHCustomForwardingHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_Close_1(TElSSHCustomForwardingHandle _Handle, int8_t Wait);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_RenegotiateCiphers(TElSSHCustomForwardingHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_SendIgnore(TElSSHCustomForwardingHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_AddTunnel(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_RemoveTunnel(TElSSHCustomForwardingHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_ClearTunnels(TElSSHCustomForwardingHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_KexAlgorithm(TElSSHCustomForwardingHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_PublicKeyAlgorithm(TElSSHCustomForwardingHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_CompressionAlgorithms(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_CompressionAlgorithms(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_EncryptionAlgorithms(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_EncryptionAlgorithms(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_KexAlgorithms(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_KexAlgorithms(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_MacAlgorithms(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_MacAlgorithms(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_PublicKeyAlgorithms(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_PublicKeyAlgorithms(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_AuthTypePriorities(TElSSHCustomForwardingHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_AuthTypePriorities(TElSSHCustomForwardingHandle _Handle, int32_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_PublicKeyAlgorithmPriorities(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_PublicKeyAlgorithmPriorities(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_EncryptionAlgorithmPriorities(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_EncryptionAlgorithmPriorities(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_CompressionAlgorithmPriorities(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_CompressionAlgorithmPriorities(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_MacAlgorithmPriorities(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_MacAlgorithmPriorities(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_KexAlgorithmPriorities(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_KexAlgorithmPriorities(TElSSHCustomForwardingHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_Tunnels(TElSSHCustomForwardingHandle _Handle, int32_t Index, TElSSHForwardingTunnelHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_Active(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_CompressionAlgorithmServerToClient(TElSSHCustomForwardingHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_CompressionAlgorithmClientToServer(TElSSHCustomForwardingHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_EncryptionAlgorithmServerToClient(TElSSHCustomForwardingHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_EncryptionAlgorithmClientToServer(TElSSHCustomForwardingHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_MacAlgorithmServerToClient(TElSSHCustomForwardingHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_MacAlgorithmClientToServer(TElSSHCustomForwardingHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_ServerCloseReason(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_ServerSoftwareName(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_Version(TElSSHCustomForwardingHandle _Handle, TSSHVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_TunnelCount(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_KbdIntName(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_KbdIntInstruction(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_ServerKey(TElSSHCustomForwardingHandle _Handle, TElSSHKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_BoundPort(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_UsingIPv6(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_TotalBytesSent(TElSSHCustomForwardingHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_TotalBytesReceived(TElSSHCustomForwardingHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_Address(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_Address(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_AuthenticationTypes(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_AuthenticationTypes(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_AutoAdjustCiphers(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_AutoAdjustCiphers(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_ClientHostname(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_ClientHostname(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_ClientUsername(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_ClientUsername(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_CompressionLevel(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_CompressionLevel(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_DestHost(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_DestHost(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_DestPort(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_DestPort(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_ForceCompression(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_ForceCompression(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_ForwardedPort(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_ForwardedPort(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_ForwardedHost(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_ForwardedHost(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_KeepAlivePeriod(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_KeepAlivePeriod(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_GlobalKeepAlivePeriod(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_GlobalKeepAlivePeriod(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_KeyStorage(TElSSHCustomForwardingHandle _Handle, TElSSHCustomKeyStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_KeyStorage(TElSSHCustomForwardingHandle _Handle, TElSSHCustomKeyStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_Password(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_Password(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_Port(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_Port(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SoftwareName(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SoftwareName(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SynchronizeGUI(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SynchronizeGUI(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_Username(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_Username(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_Versions(TElSSHCustomForwardingHandle _Handle, TSSHVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_Versions(TElSSHCustomForwardingHandle _Handle, TSSHVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SocketTimeout(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SocketTimeout(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SessionTimeout(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SessionTimeout(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_UseIPv6(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_UseIPv6(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_DNS(TElSSHCustomForwardingHandle _Handle, TElDNSSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_DNS(TElSSHCustomForwardingHandle _Handle, TElDNSSettingsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_PortKnock(TElSSHCustomForwardingHandle _Handle, TElPortKnockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_PortKnock(TElSSHCustomForwardingHandle _Handle, TElPortKnockHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SocksAuthentication(TElSSHCustomForwardingHandle _Handle, TElSocksAuthenticationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SocksAuthentication(TElSSHCustomForwardingHandle _Handle, TElSocksAuthenticationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SocksPassword(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SocksPassword(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SocksPort(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SocksPort(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SocksResolveAddress(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SocksResolveAddress(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SocksServer(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SocksServer(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SocksUseIPv6(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SocksUseIPv6(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SocksUserCode(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SocksUserCode(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SocksVersion(TElSSHCustomForwardingHandle _Handle, TElSocksVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SocksVersion(TElSSHCustomForwardingHandle _Handle, TElSocksVersionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_UseSocks(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_UseSocks(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_UseWebTunneling(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_UseWebTunneling(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_WebTunnelAddress(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_WebTunnelAddress(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_WebTunnelAuthentication(TElSSHCustomForwardingHandle _Handle, TElWebTunnelAuthenticationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_WebTunnelAuthentication(TElSSHCustomForwardingHandle _Handle, TElWebTunnelAuthenticationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_WebTunnelPassword(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_WebTunnelPassword(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_WebTunnelPort(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_WebTunnelPort(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_WebTunnelUserId(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_WebTunnelUserId(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_WebTunnelRequestHeaders(TElSSHCustomForwardingHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SocketSettings(TElSSHCustomForwardingHandle _Handle, TElSocketSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_Priority(TElSSHCustomForwardingHandle _Handle, TSBSSHForwardingPriorityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_Priority(TElSSHCustomForwardingHandle _Handle, TSBSSHForwardingPriorityRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_Intercept(TElSSHCustomForwardingHandle _Handle, TElSSHForwardingInterceptHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_Intercept(TElSSHCustomForwardingHandle _Handle, TElSSHForwardingInterceptHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_CloseIfNoActiveTunnels(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_CloseIfNoActiveTunnels(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_UseUTF8(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_UseUTF8(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_RequestPasswordChange(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_RequestPasswordChange(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_CertAuthMode(TElSSHCustomForwardingHandle _Handle, TSBSSHCertAuthModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_CertAuthMode(TElSSHCustomForwardingHandle _Handle, TSBSSHCertAuthModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_AutoAdjustPriority(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_AutoAdjustPriority(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_AuthAttempts(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_AuthAttempts(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SSHAuthOrder(TElSSHCustomForwardingHandle _Handle, TSBSSHAuthOrderRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SSHAuthOrder(TElSSHCustomForwardingHandle _Handle, TSBSSHAuthOrderRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_TrustedKeys(TElSSHCustomForwardingHandle _Handle, TElSSHCustomKeyStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_TrustedKeys(TElSSHCustomForwardingHandle _Handle, TElSSHCustomKeyStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_CryptoProviderManager(TElSSHCustomForwardingHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_CryptoProviderManager(TElSSHCustomForwardingHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_DefaultWindowSize(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_DefaultWindowSize(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_MinWindowSize(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_MinWindowSize(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_MaxSSHPacketSize(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_MaxSSHPacketSize(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_FlushCachedDataOnClose(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_FlushCachedDataOnClose(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_IncomingSpeedLimit(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_IncomingSpeedLimit(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OutgoingSpeedLimit(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OutgoingSpeedLimit(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_EstablishShellChannel(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_EstablishShellChannel(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_ObfuscateHandshake(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_ObfuscateHandshake(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_ObfuscationPassword(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_ObfuscationPassword(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SocketReadBufSize(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SocketReadBufSize(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_SocketWriteBufSize(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_SocketWriteBufSize(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_MaxCacheSize(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_MaxCacheSize(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_GSSMechanism(TElSSHCustomForwardingHandle _Handle, TElGSSBaseMechanismHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_GSSMechanism(TElSSHCustomForwardingHandle _Handle, TElGSSBaseMechanismHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_GSSHostName(TElSSHCustomForwardingHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_GSSHostName(TElSSHCustomForwardingHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_GSSDelegateCredentials(TElSSHCustomForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_GSSDelegateCredentials(TElSSHCustomForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_InactivityPeriod(TElSSHCustomForwardingHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_InactivityPeriod(TElSSHCustomForwardingHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnAuthenticationKeyboard(TElSSHCustomForwardingHandle _Handle, TSSHAuthenticationKeyboardEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnAuthenticationKeyboard(TElSSHCustomForwardingHandle _Handle, TSSHAuthenticationKeyboardEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnAuthenticationFailed(TElSSHCustomForwardingHandle _Handle, TSSHAuthenticationFailedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnAuthenticationFailed(TElSSHCustomForwardingHandle _Handle, TSSHAuthenticationFailedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnAuthenticationSuccess(TElSSHCustomForwardingHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnAuthenticationSuccess(TElSSHCustomForwardingHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnAuthenticationStart(TElSSHCustomForwardingHandle _Handle, TSSHAuthenticationStartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnAuthenticationStart(TElSSHCustomForwardingHandle _Handle, TSSHAuthenticationStartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnAuthenticationAttempt(TElSSHCustomForwardingHandle _Handle, TSSHAuthenticationAttemptEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnAuthenticationAttempt(TElSSHCustomForwardingHandle _Handle, TSSHAuthenticationAttemptEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnBanner(TElSSHCustomForwardingHandle _Handle, TSSHBannerEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnBanner(TElSSHCustomForwardingHandle _Handle, TSSHBannerEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnError(TElSSHCustomForwardingHandle _Handle, TSSHErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnError(TElSSHCustomForwardingHandle _Handle, TSSHErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnKeyValidate(TElSSHCustomForwardingHandle _Handle, TSSHKeyValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnKeyValidate(TElSSHCustomForwardingHandle _Handle, TSSHKeyValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnDebugData(TElSSHCustomForwardingHandle _Handle, TSSHDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnDebugData(TElSSHCustomForwardingHandle _Handle, TSSHDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnPrivateKeyNeeded(TElSSHCustomForwardingHandle _Handle, TSSHPrivateKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnPrivateKeyNeeded(TElSSHCustomForwardingHandle _Handle, TSSHPrivateKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnCiphersNegotiated(TElSSHCustomForwardingHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnCiphersNegotiated(TElSSHCustomForwardingHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnOpen(TElSSHCustomForwardingHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnOpen(TElSSHCustomForwardingHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnClose(TElSSHCustomForwardingHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnClose(TElSSHCustomForwardingHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnConnectionOpen(TElSSHCustomForwardingHandle _Handle, TSBSSHConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnConnectionOpen(TElSSHCustomForwardingHandle _Handle, TSBSSHConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnConnectionClose(TElSSHCustomForwardingHandle _Handle, TSBSSHConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnConnectionClose(TElSSHCustomForwardingHandle _Handle, TSBSSHConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnConnectionChange(TElSSHCustomForwardingHandle _Handle, TSBSSHConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnConnectionChange(TElSSHCustomForwardingHandle _Handle, TSBSSHConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnConnectionError(TElSSHCustomForwardingHandle _Handle, TSBSSHConnectionErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnConnectionError(TElSSHCustomForwardingHandle _Handle, TSBSSHConnectionErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnConnectionWork(TElSSHCustomForwardingHandle _Handle, TSBSSHConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnConnectionWork(TElSSHCustomForwardingHandle _Handle, TSBSSHConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnTunnelOpen(TElSSHCustomForwardingHandle _Handle, TSBSSHTunnelEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnTunnelOpen(TElSSHCustomForwardingHandle _Handle, TSBSSHTunnelEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnTunnelClose(TElSSHCustomForwardingHandle _Handle, TSBSSHTunnelEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnTunnelClose(TElSSHCustomForwardingHandle _Handle, TSBSSHTunnelEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnPasswordChangeRequest(TElSSHCustomForwardingHandle _Handle, TSSHPasswordChangeRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnPasswordChangeRequest(TElSSHCustomForwardingHandle _Handle, TSSHPasswordChangeRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnBeforeConnecting(TElSSHCustomForwardingHandle _Handle, TSBSSHBeforeConnectingEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnBeforeConnecting(TElSSHCustomForwardingHandle _Handle, TSBSSHBeforeConnectingEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnKexInitReceived(TElSSHCustomForwardingHandle _Handle, TSSHKexInitReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnKexInitReceived(TElSSHCustomForwardingHandle _Handle, TSSHKexInitReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnDNSError(TElSSHCustomForwardingHandle _Handle, TSSHErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnDNSError(TElSSHCustomForwardingHandle _Handle, TSSHErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnDNSKeyNeeded(TElSSHCustomForwardingHandle _Handle, TSBDNSKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnDNSKeyNeeded(TElSSHCustomForwardingHandle _Handle, TSBDNSKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnDNSKeyValidate(TElSSHCustomForwardingHandle _Handle, TSBDNSKeyValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnDNSKeyValidate(TElSSHCustomForwardingHandle _Handle, TSBDNSKeyValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_get_OnDNSResolve(TElSSHCustomForwardingHandle _Handle, TSBDNSResolveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_set_OnDNSResolve(TElSSHCustomForwardingHandle _Handle, TSBDNSResolveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomForwarding_Create(TComponentHandle AOwner, TElSSHCustomForwardingHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHCUSTOMFORWARDING */

#ifdef SB_USE_CLASS_TELSSHFORWARDINGINTERCEPT
SB_IMPORT uint32_t SB_APIENTRY TElSSHForwardingIntercept_Create(TComponentHandle AOwner, TElSSHForwardingInterceptHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHFORWARDINGINTERCEPT */

#ifdef SB_USE_CLASS_TELSSHLOCALPORTFORWARDING
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_get_ForwardedUsingIPv6(TElSSHLocalPortForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_get_ForwardedUseIPv6(TElSSHLocalPortForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_set_ForwardedUseIPv6(TElSSHLocalPortForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_get_ReportRealClientLocationToServer(TElSSHLocalPortForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_set_ReportRealClientLocationToServer(TElSSHLocalPortForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_get_UseDynamicForwarding(TElSSHLocalPortForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_set_UseDynamicForwarding(TElSSHLocalPortForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_get_ResolveDynamicForwardingAddresses(TElSSHLocalPortForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_set_ResolveDynamicForwardingAddresses(TElSSHLocalPortForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_get_OnAccept(TElSSHLocalPortForwardingHandle _Handle, TSBSSHSocketAcceptEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_set_OnAccept(TElSSHLocalPortForwardingHandle _Handle, TSBSSHSocketAcceptEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_get_OnConnectionSocksAuthMethodChoose(TElSSHLocalPortForwardingHandle _Handle, TSBSSHSocksAuthMethodChooseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_set_OnConnectionSocksAuthMethodChoose(TElSSHLocalPortForwardingHandle _Handle, TSBSSHSocksAuthMethodChooseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_get_OnConnectionSocksAuthPassword(TElSSHLocalPortForwardingHandle _Handle, TSBSSHSocksAuthPasswordEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_set_OnConnectionSocksAuthPassword(TElSSHLocalPortForwardingHandle _Handle, TSBSSHSocksAuthPasswordEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_get_OnConnectionSocksConnect(TElSSHLocalPortForwardingHandle _Handle, TSBSSHSocksConnectEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_set_OnConnectionSocksConnect(TElSSHLocalPortForwardingHandle _Handle, TSBSSHSocksConnectEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwarding_Create(TComponentHandle AOwner, TElSSHCustomForwardingHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHLOCALPORTFORWARDING */

#ifdef SB_USE_CLASS_TELSSHREMOTEPORTFORWARDING
SB_IMPORT uint32_t SB_APIENTRY TElSSHRemotePortForwarding_get_DestUsingIPv6(TElSSHRemotePortForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHRemotePortForwarding_get_DestUseDNS(TElSSHRemotePortForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHRemotePortForwarding_set_DestUseDNS(TElSSHRemotePortForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHRemotePortForwarding_get_DestUseIPv6(TElSSHRemotePortForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHRemotePortForwarding_set_DestUseIPv6(TElSSHRemotePortForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHRemotePortForwarding_get_UseDefaultBindAddress(TElSSHRemotePortForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHRemotePortForwarding_set_UseDefaultBindAddress(TElSSHRemotePortForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHRemotePortForwarding_get_UseProxySettingsForForwardedConnections(TElSSHRemotePortForwardingHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHRemotePortForwarding_set_UseProxySettingsForForwardedConnections(TElSSHRemotePortForwardingHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHRemotePortForwarding_Create(TComponentHandle Owner, TElSSHRemotePortForwardingHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHREMOTEPORTFORWARDING */

#ifdef SB_USE_CLASS_TELSSHTUNNELSTATE
SB_IMPORT uint32_t SB_APIENTRY TElSSHTunnelState_Create(TElSSHForwardingTunnelHandle Tunnel, TElSSHTunnelStateHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHTUNNELSTATE */

#ifdef SB_USE_CLASS_TELSSHLPFLISTENINGTHREAD
SB_IMPORT uint32_t SB_APIENTRY TElSSHLPFListeningThread_get_OnAccept(TElSSHLPFListeningThreadHandle _Handle, TSBSSHLPFAcceptEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLPFListeningThread_set_OnAccept(TElSSHLPFListeningThreadHandle _Handle, TSBSSHLPFAcceptEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLPFListeningThread_get_OnListeningStarted(TElSSHLPFListeningThreadHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLPFListeningThread_set_OnListeningStarted(TElSSHLPFListeningThreadHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHLPFListeningThread_Create(TElSSHForwardingSessionHandle Owner, const char * pcAddress, int32_t szAddress, int32_t Port, int8_t UseIPv6, TElSSHLPFListeningThreadHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHLPFLISTENINGTHREAD */

#ifdef SB_USE_CLASS_TELSSHLOCALTUNNELSTATE
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalTunnelState_Create(TElSSHForwardingTunnelHandle Tunnel, TElSSHLocalTunnelStateHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHLOCALTUNNELSTATE */

#ifdef SB_USE_CLASS_TELSSHREMOTETUNNELSTATE
SB_IMPORT uint32_t SB_APIENTRY TElSSHRemoteTunnelState_Create(TElSSHForwardingTunnelHandle Tunnel, TElSSHRemoteTunnelStateHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHREMOTETUNNELSTATE */

#ifdef SB_USE_CLASS_TELSSHLOCALPORTFORWARDINGSESSION
SB_IMPORT uint32_t SB_APIENTRY TElSSHLocalPortForwardingSession_Create(TElSSHCustomForwardingHandle Owner, TElSSHForwardingSessionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHLOCALPORTFORWARDINGSESSION */

#ifdef SB_USE_CLASS_TELSSHREMOTEPORTFORWARDINGSESSION
SB_IMPORT uint32_t SB_APIENTRY TElSSHRemotePortForwardingSession_Create(TElSSHCustomForwardingHandle Owner, TElSSHForwardingSessionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHREMOTEPORTFORWARDINGSESSION */

#ifdef SB_USE_CLASS_TELSSHSCHEDULEDSPECIALMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElSSHScheduledSpecialMessage_Create(int32_t Code, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, TElSSHScheduledSpecialMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHSCHEDULEDSPECIALMESSAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSSHForwardedConnection_ce_ptr;
extern zend_class_entry *TElSSHForwardingTunnel_ce_ptr;
extern zend_class_entry *TElSSHForwardingSession_ce_ptr;
extern zend_class_entry *TElSSHCustomForwarding_ce_ptr;
extern zend_class_entry *TElSSHForwardingIntercept_ce_ptr;
extern zend_class_entry *TElSSHLocalPortForwarding_ce_ptr;
extern zend_class_entry *TElSSHRemotePortForwarding_ce_ptr;
extern zend_class_entry *TElSSHTunnelState_ce_ptr;
extern zend_class_entry *TElSSHLPFListeningThread_ce_ptr;
extern zend_class_entry *TElSSHLocalTunnelState_ce_ptr;
extern zend_class_entry *TElSSHRemoteTunnelState_ce_ptr;
extern zend_class_entry *TElSSHLocalPortForwardingSession_ce_ptr;
extern zend_class_entry *TElSSHRemotePortForwardingSession_ce_ptr;
extern zend_class_entry *TElSSHScheduledSpecialMessage_ce_ptr;

void SB_CALLBACK TSBSSHConnectionEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHForwardedConnectionHandle Conn);
void SB_CALLBACK TSBSSHConnectionErrorEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHForwardedConnectionHandle Conn, int32_t ErrorCode);
void SB_CALLBACK TSBSSHTunnelEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHForwardingTunnelHandle Tunnel);
void SB_CALLBACK TSBSSHLPFAcceptEventRaw(void * _ObjectData, TObjectHandle Sender, TElSocketHandle Socket);
void SB_CALLBACK TSBSSHSocketAcceptEventRaw(void * _ObjectData, TObjectHandle Sender, TElSocketHandle Socket, int8_t * Reject);
void SB_CALLBACK TSBSSHSocksAuthMethodChooseEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHForwardedConnectionHandle Conn, const TElSocksAuthenticationRaw pAuthMethods[], int32_t szAuthMethods, TElSocksAuthenticationRaw * AuthMethod, int8_t * Cancel);
void SB_CALLBACK TSBSSHSocksAuthPasswordEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHForwardedConnectionHandle Conn, const char * pcUsername, int32_t szUsername, const char * pcPassword, int32_t szPassword, int8_t * Accept);
void SB_CALLBACK TSBSSHSocksConnectEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHForwardedConnectionHandle Conn, const char * pcDestHost, int32_t szDestHost, int32_t DestPort, int8_t * Allow);
void SB_CALLBACK TSBSSHBeforeConnectingEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHClientHandle Client, TElSocketHandle Socket);
void Register_TElSSHForwardedConnection(TSRMLS_D);
void Register_TElSSHForwardingTunnel(TSRMLS_D);
void Register_TElSSHForwardingSession(TSRMLS_D);
void Register_TElSSHCustomForwarding(TSRMLS_D);
void Register_TElSSHForwardingIntercept(TSRMLS_D);
void Register_TElSSHLocalPortForwarding(TSRMLS_D);
void Register_TElSSHRemotePortForwarding(TSRMLS_D);
void Register_TElSSHTunnelState(TSRMLS_D);
void Register_TElSSHLPFListeningThread(TSRMLS_D);
void Register_TElSSHLocalTunnelState(TSRMLS_D);
void Register_TElSSHRemoteTunnelState(TSRMLS_D);
void Register_TElSSHLocalPortForwardingSession(TSRMLS_D);
void Register_TElSSHRemotePortForwardingSession(TSRMLS_D);
void Register_TElSSHScheduledSpecialMessage(TSRMLS_D);
void Register_SBSSHForwarding_Constants(int module_number TSRMLS_DC);
void Register_SBSSHForwarding_Enum_Flags(TSRMLS_D);
void Register_SBSSHForwarding_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSSHFORWARDING */

