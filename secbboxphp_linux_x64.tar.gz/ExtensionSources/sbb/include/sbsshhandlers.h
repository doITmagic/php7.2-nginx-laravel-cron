#ifndef __INC_SBSSHHANDLERS
#define __INC_SBSSHHANDLERS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbsshcommon.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbsharedresource.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElCustomSSHSubsystemHandlerHandle;

typedef TElCustomSSHSubsystemHandlerHandle ElCustomSSHSubsystemHandlerHandle;

#ifdef SB_WINDOWS
typedef TElClassHandle TElShellSSHSubsystemHandlerHandle;

typedef TElShellSSHSubsystemHandlerHandle ElShellSSHSubsystemHandlerHandle;
#endif

typedef TElClassHandle TElCustomSocketForwardingSSHSubsystemHandlerHandle;

typedef TElCustomSocketForwardingSSHSubsystemHandlerHandle ElCustomSocketForwardingSSHSubsystemHandlerHandle;

typedef TElClassHandle TElSSHSubsystemThreadHandle;

typedef TElSSHSubsystemThreadHandle ElSSHSubsystemThreadHandle;

typedef uint8_t TSBSSHSubsystemHandlerTypeRaw;

typedef enum
{
	shtSynchronous = 0,
	shtAsynchronous = 1
} TSBSSHSubsystemHandlerType;

typedef void (SB_CALLBACK *TSBSSHSubsystemHandlerTerminateRequest)(void * _ObjectData, TObjectHandle Sender, int8_t * Terminate);

typedef TElClassHandle TElSSHSubsystemHandlerClassHandle;

typedef TElSSHSubsystemHandlerClassHandle ElSSHSubsystemHandlerClassHandle;

#ifdef SB_WINDOWS
typedef void (SB_CALLBACK *TSBSSHEncodedStringEvent)(void * _ObjectData, TObjectHandle Sender, uint8_t pBuf[], int32_t * szBuf);
#endif

#ifdef SB_USE_CLASS_TELCUSTOMSSHSUBSYSTEMHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_HandlerType(TElCustomSSHSubsystemHandlerHandle _Handle, TSBSSHSubsystemHandlerTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_Run(TElCustomSSHSubsystemHandlerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_Terminate(TElCustomSSHSubsystemHandlerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_WaitForInputData(TElCustomSSHSubsystemHandlerHandle _Handle, int32_t Time, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_get_Connection(TElCustomSSHSubsystemHandlerHandle _Handle, TElSSHTunnelConnectionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_get_FlushCachedData(TElCustomSSHSubsystemHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_set_FlushCachedData(TElCustomSSHSubsystemHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_get_OnTerminateRequest(TElCustomSSHSubsystemHandlerHandle _Handle, TSBSSHSubsystemHandlerTerminateRequest * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_set_OnTerminateRequest(TElCustomSSHSubsystemHandlerHandle _Handle, TSBSSHSubsystemHandlerTerminateRequest pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_get_OnDisconnect(TElCustomSSHSubsystemHandlerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_set_OnDisconnect(TElCustomSSHSubsystemHandlerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_get_OnUnsafeOperationStart(TElCustomSSHSubsystemHandlerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_set_OnUnsafeOperationStart(TElCustomSSHSubsystemHandlerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_get_OnUnsafeOperationEnd(TElCustomSSHSubsystemHandlerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_set_OnUnsafeOperationEnd(TElCustomSSHSubsystemHandlerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_get_OnEOF(TElCustomSSHSubsystemHandlerHandle _Handle, TSSHEOFEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_set_OnEOF(TElCustomSSHSubsystemHandlerHandle _Handle, TSSHEOFEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_Create(TElSSHTunnelConnectionHandle Connection, TElCustomSSHSubsystemHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSHSubsystemHandler_CreateDelayed(TElSSHTunnelConnectionHandle Connection, TElCustomSSHSubsystemHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMSSHSUBSYSTEMHANDLER */

#ifdef SB_WINDOWS
#ifdef SB_USE_CLASS_TELSHELLSSHSUBSYSTEMHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_HandlerType(TElShellSSHSubsystemHandlerHandle _Handle, TSBSSHSubsystemHandlerTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_get_Command(TElShellSSHSubsystemHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_set_Command(TElShellSSHSubsystemHandlerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_get_RawCommandLine(TElShellSSHSubsystemHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_set_RawCommandLine(TElShellSSHSubsystemHandlerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_get_CurrentDirectory(TElShellSSHSubsystemHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_set_CurrentDirectory(TElShellSSHSubsystemHandlerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_get_NoCharacterEncoding(TElShellSSHSubsystemHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_set_NoCharacterEncoding(TElShellSSHSubsystemHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_get_UseUTF8(TElShellSSHSubsystemHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_set_UseUTF8(TElShellSSHSubsystemHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_get_OutputLines(TElShellSSHSubsystemHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_set_OutputLines(TElShellSSHSubsystemHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_get_SendCharactersBack(TElShellSSHSubsystemHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_set_SendCharactersBack(TElShellSSHSubsystemHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_get_MaxCacheSize(TElShellSSHSubsystemHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_set_MaxCacheSize(TElShellSSHSubsystemHandlerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_get_OnBeforeDecoding(TElShellSSHSubsystemHandlerHandle _Handle, TSBSSHEncodedStringEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_set_OnBeforeDecoding(TElShellSSHSubsystemHandlerHandle _Handle, TSBSSHEncodedStringEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_get_OnAfterEncoding(TElShellSSHSubsystemHandlerHandle _Handle, TSBSSHEncodedStringEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_set_OnAfterEncoding(TElShellSSHSubsystemHandlerHandle _Handle, TSBSSHEncodedStringEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_Create(TElSSHTunnelConnectionHandle Connection, TElCustomSSHSubsystemHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElShellSSHSubsystemHandler_CreateDelayed(TElSSHTunnelConnectionHandle Connection, TElCustomSSHSubsystemHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSHELLSSHSUBSYSTEMHANDLER */
#endif

#ifdef SB_USE_CLASS_TELCUSTOMSOCKETFORWARDINGSSHSUBSYSTEMHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketForwardingSSHSubsystemHandler_HandlerType(TElCustomSocketForwardingSSHSubsystemHandlerHandle _Handle, TSBSSHSubsystemHandlerTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketForwardingSSHSubsystemHandler_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketForwardingSSHSubsystemHandler_get_Host(TElCustomSocketForwardingSSHSubsystemHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketForwardingSSHSubsystemHandler_set_Host(TElCustomSocketForwardingSSHSubsystemHandlerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketForwardingSSHSubsystemHandler_get_Port(TElCustomSocketForwardingSSHSubsystemHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketForwardingSSHSubsystemHandler_set_Port(TElCustomSocketForwardingSSHSubsystemHandlerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketForwardingSSHSubsystemHandler_get_Timeout(TElCustomSocketForwardingSSHSubsystemHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketForwardingSSHSubsystemHandler_set_Timeout(TElCustomSocketForwardingSSHSubsystemHandlerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketForwardingSSHSubsystemHandler_Create(TElSSHTunnelConnectionHandle Connection, TElCustomSSHSubsystemHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSocketForwardingSSHSubsystemHandler_CreateDelayed(TElSSHTunnelConnectionHandle Connection, TElCustomSSHSubsystemHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMSOCKETFORWARDINGSSHSUBSYSTEMHANDLER */

#ifdef SB_USE_CLASS_TELSSHSUBSYSTEMTHREAD
SB_IMPORT uint32_t SB_APIENTRY TElSSHSubsystemThread_get_Handler(TElSSHSubsystemThreadHandle _Handle, TElCustomSSHSubsystemHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHSubsystemThread_get_OnTerminateSubsystem(TElSSHSubsystemThreadHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHSubsystemThread_set_OnTerminateSubsystem(TElSSHSubsystemThreadHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHSubsystemThread_Create(TElSSHSubsystemHandlerClassHandle Cls, TElSSHTunnelConnectionHandle Connection, int8_t CreateSuspended, TElSSHSubsystemThreadHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHSUBSYSTEMTHREAD */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSSHSubsystemHandlerClass_ce_ptr;
extern zend_class_entry *TElCustomSSHSubsystemHandler_ce_ptr;
#ifdef SB_WINDOWS
extern zend_class_entry *TElShellSSHSubsystemHandler_ce_ptr;
#endif
extern zend_class_entry *TElCustomSocketForwardingSSHSubsystemHandler_ce_ptr;
extern zend_class_entry *TElSSHSubsystemThread_ce_ptr;

void SB_CALLBACK TSBSSHSubsystemHandlerTerminateRequestRaw(void * _ObjectData, TObjectHandle Sender, int8_t * Terminate);
#ifdef SB_WINDOWS
void SB_CALLBACK TSBSSHEncodedStringEventRaw(void * _ObjectData, TObjectHandle Sender, uint8_t pBuf[], int32_t * szBuf);
#endif
void Register_TElCustomSSHSubsystemHandler(TSRMLS_D);
#ifdef SB_WINDOWS
void Register_TElShellSSHSubsystemHandler(TSRMLS_D);
#endif
void Register_TElCustomSocketForwardingSSHSubsystemHandler(TSRMLS_D);
void Register_TElSSHSubsystemThread(TSRMLS_D);
void Register_SBSSHHandlers_Enum_Flags(TSRMLS_D);
void Register_SBSSHHandlers_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSSHHANDLERS */
