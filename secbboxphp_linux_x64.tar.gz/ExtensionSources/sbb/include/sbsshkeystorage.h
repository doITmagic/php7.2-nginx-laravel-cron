#ifndef __INC_SBSSHKEYSTORAGE
#define __INC_SBSSHKEYSTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbencoding.h"
#include "sbrandom.h"
#include "sbsocket.h"
#include "sbsharedresource.h"
#include "sbpkcs8.h"
#include "sbasn1tree.h"
#include "sbcryptoprov.h"
#include "sbsymmetriccrypto.h"
#include "sbhashfunction.h"
#include "sbpublickeycrypto.h"
#include "sbconstants.h"
#include "sbx509.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ALGORITHM_RSA 	0
#define SB_ALGORITHM_DSS 	1
#define SB_ALGORITHM_ECDSA 	2
#define SB_ALGORITHM_NOT_SPECIFIED 	65535
#define SB_ERROR_SSH_KEYS_INVALID_PUBLIC_KEY 	3329
#define SB_ERROR_SSH_KEYS_INVALID_PRIVATE_KEY 	3330
#define SB_ERROR_SSH_KEYS_FILE_READ_ERROR 	3331
#define SB_ERROR_SSH_KEYS_FILE_WRITE_ERROR 	3332
#define SB_ERROR_SSH_KEYS_UNSUPPORTED_ALGORITHM 	3333
#define SB_ERROR_SSH_KEYS_INTERNAL_ERROR 	3334
#define SB_ERROR_SSH_KEYS_BUFFER_TOO_SMALL 	3335
#define SB_ERROR_SSH_KEYS_NO_PRIVATE_KEY 	3336
#define SB_ERROR_SSH_KEYS_INVALID_PASSPHRASE 	3337
#define SB_ERROR_SSH_KEYS_UNSUPPORTED_PEM_ALGORITHM 	3338
#define SB_ERROR_SSH_KEYS_UNSUPPORTED_CURVE 	3339

typedef TElClassHandle TElSSHKeyHandle;

typedef TElSSHKeyHandle ElSSHKeyHandle;

typedef TElClassHandle TElSSHCustomKeyStorageHandle;

typedef TElSSHCustomKeyStorageHandle ElSSHCustomKeyStorageHandle;

typedef TElClassHandle TElSSHMemoryKeyStorageHandle;

typedef TElSSHMemoryKeyStorageHandle ElSSHMemoryKeyStorageHandle;

typedef uint8_t TSBSSHKeyFormatRaw;

typedef enum
{
	kfOpenSSH = 0,
	kfOpenSSH2 = 1,
	kfIETF = 2,
	kfPuTTY = 3,
	kfX509 = 4,
	kfBinary = 5,
	kfSSH1 = 6,
	kfPGP = 7,
	kfPKCS8 = 8
} TSBSSHKeyFormat;

#ifdef SB_USE_CLASS_TELSSHKEY
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_IsKeyValid(TElSSHKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_Copy(TElSSHKeyHandle _Handle, TElSSHKeyHandle * Dest);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_Clear(TElSSHKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_Clone(TElSSHKeyHandle _Handle, TElSSHKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_CreateObjectInstance(TElSSHKeyHandle _Handle, TElSSHKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_Generate(TElSSHKeyHandle _Handle, int32_t Algorithm, int32_t Bits, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_GenerateEC(TElSSHKeyHandle _Handle, int32_t Curve, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_LoadPublicKey(TElSSHKeyHandle _Handle, const char * pcPublicKeyFile, int32_t szPublicKeyFile, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_LoadPublicKey_1(TElSSHKeyHandle _Handle, TStreamHandle KeyStream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_LoadPublicKey_2(TElSSHKeyHandle _Handle, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_LoadPrivateKey(TElSSHKeyHandle _Handle, const char * pcPrivateKeyFile, int32_t szPrivateKeyFile, const char * pcPassphrase, int32_t szPassphrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_LoadPrivateKey_1(TElSSHKeyHandle _Handle, TStreamHandle KeyStream, const char * pcPassphrase, int32_t szPassphrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_LoadPrivateKey_2(TElSSHKeyHandle _Handle, void * Buffer, int32_t Size, const char * pcPassphrase, int32_t szPassphrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_SavePublicKey(TElSSHKeyHandle _Handle, void * Buffer, int32_t * Size, TSBEOLMarkerRaw EOLMarker, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_SavePublicKey_1(TElSSHKeyHandle _Handle, const char * pcPublicKeyFile, int32_t szPublicKeyFile, TSBEOLMarkerRaw EOLMarker, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_SavePublicKey_2(TElSSHKeyHandle _Handle, TStreamHandle KeyStream, TSBEOLMarkerRaw EOLMarker, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_SavePrivateKey(TElSSHKeyHandle _Handle, TStreamHandle KeyStream, const char * pcPassphrase, int32_t szPassphrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_SavePrivateKey_1(TElSSHKeyHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassphrase, int32_t szPassphrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_SavePrivateKey_2(TElSSHKeyHandle _Handle, const char * pcPrivateKeyFile, int32_t szPrivateKeyFile, const char * pcPassphrase, int32_t szPassphrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_Import(TElSSHKeyHandle _Handle, TElX509CertificateHandle Certificate);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_LoadPublicKeyFromBlob(TElSSHKeyHandle _Handle, const char * pcAlgName, int32_t szAlgName, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_SavePublicKeyToBlob(TElSSHKeyHandle _Handle, char * pcAlgName, int32_t * szAlgName, void * Buffer, int32_t * Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_RSAPublicExponent(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_RSAPublicExponent(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_RSAPublicModulus(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_RSAPublicModulus(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_RSAPrivateExponent(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_RSAPrivateExponent(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_DSSP(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_DSSP(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_DSSQ(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_DSSQ(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_DSSG(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_DSSG(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_DSSY(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_DSSY(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_DSSX(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_DSSX(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_CurveID(TElSSHKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_CurveID(TElSSHKeyHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_ECCD(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_ECCD(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_ECCQX(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_ECCQX(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_ECCQY(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_ECCQY(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_FingerprintMD5(TElSSHKeyHandle _Handle, TMessageDigest128 * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_FingerprintMD5String(TElSSHKeyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_FingerprintSHA1(TElSSHKeyHandle _Handle, TMessageDigest160 * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_FingerprintSHA1String(TElSSHKeyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_FingerprintSHA256(TElSSHKeyHandle _Handle, TMessageDigest256 * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_FingerprintSHA256String(TElSSHKeyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_Algorithm(TElSSHKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_Algorithm(TElSSHKeyHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_Bits(TElSSHKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_Comment(TElSSHKeyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_Comment(TElSSHKeyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_Subject(TElSSHKeyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_Subject(TElSSHKeyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_KeyFormat(TElSSHKeyHandle _Handle, TSBSSHKeyFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_KeyFormat(TElSSHKeyHandle _Handle, TSBSSHKeyFormatRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_KeyProtectionAlgorithm(TElSSHKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_KeyProtectionAlgorithm(TElSSHKeyHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_IsPrivate(TElSSHKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_IsPublic(TElSSHKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_IsExtractable(TElSSHKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_Headers(TElSSHKeyHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_Certificate(TElSSHKeyHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_KeyMaterial(TElSSHKeyHandle _Handle, TElPublicKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_UsePlatformKeyGeneration(TElSSHKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_UsePlatformKeyGeneration(TElSSHKeyHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_CryptoProviderManager(TElSSHKeyHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_CryptoProviderManager(TElSSHKeyHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_KDFRounds(TElSSHKeyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_KDFRounds(TElSSHKeyHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_PreserveLoadedKeyParams(TElSSHKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_PreserveLoadedKeyParams(TElSSHKeyHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_KDFSalt(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_KDFSalt(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_EncryptionCheckInt(TElSSHKeyHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_EncryptionCheckInt(TElSSHKeyHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_RSAIQMP(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_RSAIQMP(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_RSAP(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_RSAP(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_get_RSAQ(TElSSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_set_RSAQ(TElSSHKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHKey_Create(TElSSHKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHKEY */

#ifdef SB_USE_CLASS_TELSSHCUSTOMKEYSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomKeyStorage_Add(TElSSHCustomKeyStorageHandle _Handle, TElSSHKeyHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomKeyStorage_Remove(TElSSHCustomKeyStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomKeyStorage_Clear(TElSSHCustomKeyStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomKeyStorage_IndexOf(TElSSHCustomKeyStorageHandle _Handle, TElSSHKeyHandle Key, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomKeyStorage_LoadPublic(TElSSHCustomKeyStorageHandle _Handle, TStreamHandle F, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomKeyStorage_LoadPublic_1(TElSSHCustomKeyStorageHandle _Handle, const char * pcFilename, int32_t szFilename, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomKeyStorage_SavePublic(TElSSHCustomKeyStorageHandle _Handle, TStreamHandle F, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomKeyStorage_SavePublic_1(TElSSHCustomKeyStorageHandle _Handle, const char * pcFilename, int32_t szFilename, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomKeyStorage_get_Keys(TElSSHCustomKeyStorageHandle _Handle, int32_t Index, TElSSHKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomKeyStorage_get_Count(TElSSHCustomKeyStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomKeyStorage_get_CryptoProviderManager(TElSSHCustomKeyStorageHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomKeyStorage_set_CryptoProviderManager(TElSSHCustomKeyStorageHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHCustomKeyStorage_Create(TComponentHandle AOwner, TElSSHCustomKeyStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHCUSTOMKEYSTORAGE */

#ifdef SB_USE_CLASS_TELSSHMEMORYKEYSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElSSHMemoryKeyStorage_Add(TElSSHMemoryKeyStorageHandle _Handle, TElSSHKeyHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElSSHMemoryKeyStorage_Remove(TElSSHMemoryKeyStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSSHMemoryKeyStorage_Clear(TElSSHMemoryKeyStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHMemoryKeyStorage_LoadPublic(TElSSHMemoryKeyStorageHandle _Handle, TStreamHandle F, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHMemoryKeyStorage_LoadPublic_1(TElSSHMemoryKeyStorageHandle _Handle, const char * pcFilename, int32_t szFilename, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHMemoryKeyStorage_SavePublic(TElSSHMemoryKeyStorageHandle _Handle, TStreamHandle F, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHMemoryKeyStorage_SavePublic_1(TElSSHMemoryKeyStorageHandle _Handle, const char * pcFilename, int32_t szFilename, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHMemoryKeyStorage_IndexOf(TElSSHMemoryKeyStorageHandle _Handle, TElSSHKeyHandle Key, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHMemoryKeyStorage_Create(TComponentHandle AOwner, TElSSHMemoryKeyStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHMEMORYKEYSTORAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSSHKey_ce_ptr;
extern zend_class_entry *TElSSHCustomKeyStorage_ce_ptr;
extern zend_class_entry *TElSSHMemoryKeyStorage_ce_ptr;

void Register_TElSSHKey(TSRMLS_D);
void Register_TElSSHCustomKeyStorage(TSRMLS_D);
void Register_TElSSHMemoryKeyStorage(TSRMLS_D);
void Register_SBSSHKeyStorage_Constants(int module_number TSRMLS_DC);
void Register_SBSSHKeyStorage_Enum_Flags(TSRMLS_D);
void Register_SBSSHKeyStorage_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSSHKEYSTORAGE */

