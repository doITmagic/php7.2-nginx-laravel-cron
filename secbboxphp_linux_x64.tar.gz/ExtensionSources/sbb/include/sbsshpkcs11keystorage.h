#ifndef __INC_SBSSHPKCS11KEYSTORAGE
#define __INC_SBSSHPKCS11KEYSTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbcustomcrypto.h"
#include "sbpublickeycrypto.h"
#include "sbcryptoprov.h"
#include "sbcryptoprovutils.h"
#include "sbcryptoprovpkcs11.h"
#include "sbpkcs11base.h"
#include "sbpkcs11common.h"
#include "sbsshkeystorage.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSSHPKCS11KeyStorageHandle;

typedef TElClassHandle TElSSHPKCS11ConsumerKeyStorageHandle;

typedef TElClassHandle TElPKCS11SSHKeyHandle;

#ifdef SB_USE_CLASS_TELSSHPKCS11KEYSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_Open(TElSSHPKCS11KeyStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_Close(TElSSHPKCS11KeyStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_OpenSession(TElSSHPKCS11KeyStorageHandle _Handle, int32_t SlotIndex, int8_t ReadOnly, TElPKCS11SessionInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_CloseSession(TElSSHPKCS11KeyStorageHandle _Handle, int32_t SessionIndex);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_CloseAllSessions(TElSSHPKCS11KeyStorageHandle _Handle, TElPKCS11SlotInfoHandle Slot);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_Add(TElSSHPKCS11KeyStorageHandle _Handle, TElSSHKeyHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_Add_1(TElSSHPKCS11KeyStorageHandle _Handle, int32_t SessionIndex, TElSSHKeyHandle Key, int8_t CopyPrivateKey, int8_t Exportable, const uint8_t pID[], int32_t szID, const uint8_t pKeyLabel[], int32_t szKeyLabel);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_Remove(TElSSHPKCS11KeyStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_Clear(TElSSHPKCS11KeyStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_IndexOf(TElSSHPKCS11KeyStorageHandle _Handle, TElSSHKeyHandle Key, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_LoadPublic(TElSSHPKCS11KeyStorageHandle _Handle, TStreamHandle F, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_LoadPublic_1(TElSSHPKCS11KeyStorageHandle _Handle, const char * pcFilename, int32_t szFilename, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_SavePublic(TElSSHPKCS11KeyStorageHandle _Handle, TStreamHandle F, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_SavePublic_1(TElSSHPKCS11KeyStorageHandle _Handle, const char * pcFilename, int32_t szFilename, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_Module(TElSSHPKCS11KeyStorageHandle _Handle, TElPKCS11ModuleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_Opened(TElSSHPKCS11KeyStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_UniqueID(TElSSHPKCS11KeyStorageHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_DLLName(TElSSHPKCS11KeyStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_set_DLLName(TElSSHPKCS11KeyStorageHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_TrySingleThreadedMode(TElSSHPKCS11KeyStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_set_TrySingleThreadedMode(TElSSHPKCS11KeyStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_MonitorSlotEvents(TElSSHPKCS11KeyStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_set_MonitorSlotEvents(TElSSHPKCS11KeyStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_SlotEventMonitoringMode(TElSSHPKCS11KeyStorageHandle _Handle, TSBPKCS11SlotEventMonitoringModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_set_SlotEventMonitoringMode(TElSSHPKCS11KeyStorageHandle _Handle, TSBPKCS11SlotEventMonitoringModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_SlotEventMonitoringDelay(TElSSHPKCS11KeyStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_set_SlotEventMonitoringDelay(TElSSHPKCS11KeyStorageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_SynchronizeGUI(TElSSHPKCS11KeyStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_set_SynchronizeGUI(TElSSHPKCS11KeyStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_CryptoProvider(TElSSHPKCS11KeyStorageHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_set_CryptoProvider(TElSSHPKCS11KeyStorageHandle _Handle, TElCustomCryptoProviderHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_PKCS11Options(TElSSHPKCS11KeyStorageHandle _Handle, TSBPKCS11StorageOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_set_PKCS11Options(TElSSHPKCS11KeyStorageHandle _Handle, TSBPKCS11StorageOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_TokenAccessMode(TElSSHPKCS11KeyStorageHandle _Handle, TSBPKCS11TokenAccessModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_set_TokenAccessMode(TElSSHPKCS11KeyStorageHandle _Handle, TSBPKCS11TokenAccessModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_NSSParams(TElSSHPKCS11KeyStorageHandle _Handle, TElPKCS11NSSParamsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_PlatformPointerSize(TElSSHPKCS11KeyStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_set_PlatformPointerSize(TElSSHPKCS11KeyStorageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_PlatformLongIntSize(TElSSHPKCS11KeyStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_set_PlatformLongIntSize(TElSSHPKCS11KeyStorageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_PlatformAlignment(TElSSHPKCS11KeyStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_set_PlatformAlignment(TElSSHPKCS11KeyStorageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_OnSlotEvent(TElSSHPKCS11KeyStorageHandle _Handle, TElPKCSSlotEventEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_set_OnSlotEvent(TElSSHPKCS11KeyStorageHandle _Handle, TElPKCSSlotEventEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_get_OnNotification(TElSSHPKCS11KeyStorageHandle _Handle, TElPKCSNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_set_OnNotification(TElSSHPKCS11KeyStorageHandle _Handle, TElPKCSNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11KeyStorage_Create(TComponentHandle AOwner, TElSSHPKCS11KeyStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHPKCS11KEYSTORAGE */

#ifdef SB_USE_CLASS_TELSSHPKCS11CONSUMERKEYSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElSSHPKCS11ConsumerKeyStorage_Create(TElPKCS11ConsumerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHPKCS11CONSUMERKEYSTORAGE */

#ifdef SB_USE_CLASS_TELPKCS11SSHKEY
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SSHKey_Copy(TElPKCS11SSHKeyHandle _Handle, TElSSHKeyHandle * Dest);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SSHKey_Clone(TElPKCS11SSHKeyHandle _Handle, TElSSHKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SSHKey_CreateObjectInstance(TElPKCS11SSHKeyHandle _Handle, TElSSHKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SSHKey_Clear(TElPKCS11SSHKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SSHKey_get_KeyID(TElPKCS11SSHKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPKCS11SSHKey_Create(TElPKCS11SSHKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELPKCS11SSHKEY */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSSHPKCS11KeyStorage_ce_ptr;
extern zend_class_entry *TElSSHPKCS11ConsumerKeyStorage_ce_ptr;
extern zend_class_entry *TElPKCS11SSHKey_ce_ptr;

void Register_TElSSHPKCS11KeyStorage(TSRMLS_D);
void Register_TElSSHPKCS11ConsumerKeyStorage(TSRMLS_D);
void Register_TElPKCS11SSHKey(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSSHPKCS11KEYSTORAGE */

