#ifndef __INC_SBSSHPUBKEYCLIENT
#define __INC_SBSSHPUBKEYCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbsshclient.h"
#include "sbsshcommon.h"
#include "sbsshconstants.h"
#include "sbsshkeystorage.h"
#include "sbsshpubkeycommon.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSSHPublicKeyClientHandle;

typedef TElSSHPublicKeyClientHandle ElSSHPublicKeyClientHandle;

#ifdef SB_USE_CLASS_TELSSHPUBLICKEYCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_Add(TElSSHPublicKeyClientHandle _Handle, TElSSHKeyHandle Key, TElSSHPublicKeyAttributesHandle Attributes, int8_t Overwrite);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_Remove(TElSSHPublicKeyClientHandle _Handle, TElSSHKeyHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_List(TElSSHPublicKeyClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_ListAttributes(TElSSHPublicKeyClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_get_Active(TElSSHPublicKeyClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_get_RemoteVersion(TElSSHPublicKeyClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_get_Version(TElSSHPublicKeyClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_get_Tunnel(TElSSHPublicKeyClientHandle _Handle, TElSubsystemSSHTunnelHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_set_Tunnel(TElSSHPublicKeyClientHandle _Handle, TElSubsystemSSHTunnelHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_get_Subsystem(TElSSHPublicKeyClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_set_Subsystem(TElSSHPublicKeyClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_get_OnOpenConnection(TElSSHPublicKeyClientHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_set_OnOpenConnection(TElSSHPublicKeyClientHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_get_OnCloseConnection(TElSSHPublicKeyClientHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_set_OnCloseConnection(TElSSHPublicKeyClientHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_get_OnError(TElSSHPublicKeyClientHandle _Handle, TSBSSHPublicKeyErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_set_OnError(TElSSHPublicKeyClientHandle _Handle, TSBSSHPublicKeyErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_get_OnStatus(TElSSHPublicKeyClientHandle _Handle, TSBSSHPublicKeyStatusEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_set_OnStatus(TElSSHPublicKeyClientHandle _Handle, TSBSSHPublicKeyStatusEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_get_OnPublicKey(TElSSHPublicKeyClientHandle _Handle, TSBSSHPublicKeyPublicKeyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_set_OnPublicKey(TElSSHPublicKeyClientHandle _Handle, TSBSSHPublicKeyPublicKeyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_get_OnAttribute(TElSSHPublicKeyClientHandle _Handle, TSBSSHPublicKeyAttributeEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_set_OnAttribute(TElSSHPublicKeyClientHandle _Handle, TSBSSHPublicKeyAttributeEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHPublicKeyClient_Create(TComponentHandle AOwner, TElSSHPublicKeyClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHPUBLICKEYCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSSHPublicKeyClient_ce_ptr;

void Register_TElSSHPublicKeyClient(TSRMLS_D);
void Register_SBSSHPubKeyClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSSHPUBKEYCLIENT */

