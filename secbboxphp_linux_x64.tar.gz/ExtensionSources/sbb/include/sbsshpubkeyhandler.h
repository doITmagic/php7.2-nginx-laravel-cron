#ifndef __INC_SBSSHPUBKEYHANDLER
#define __INC_SBSSHPUBKEYHANDLER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbsshcommon.h"
#include "sbsshhandlers.h"
#include "sbsshpubkeycommon.h"
#include "sbsshpubkeyserver.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElPublicKeySSHSubsystemHandlerHandle;

typedef TElPublicKeySSHSubsystemHandlerHandle ElPublicKeySSHSubsystemHandlerHandle;

#ifdef SB_USE_CLASS_TELPUBLICKEYSSHSUBSYSTEMHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeySSHSubsystemHandler_HandlerType(TElPublicKeySSHSubsystemHandlerHandle _Handle, TSBSSHSubsystemHandlerTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeySSHSubsystemHandler_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeySSHSubsystemHandler_get_Server(TElPublicKeySSHSubsystemHandlerHandle _Handle, TElSSHPublicKeyServerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeySSHSubsystemHandler_set_Server(TElPublicKeySSHSubsystemHandlerHandle _Handle, TElSSHPublicKeyServerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeySSHSubsystemHandler_Create(TElSSHTunnelConnectionHandle Connection, TElPublicKeySSHSubsystemHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPublicKeySSHSubsystemHandler_CreateDelayed(TElSSHTunnelConnectionHandle Connection, TElSSHPublicKeyServerHandle Server, TElPublicKeySSHSubsystemHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELPUBLICKEYSSHSUBSYSTEMHANDLER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElPublicKeySSHSubsystemHandler_ce_ptr;

void Register_TElPublicKeySSHSubsystemHandler(TSRMLS_D);
void Register_SBSSHPubKeyHandler_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSSHPUBKEYHANDLER */

