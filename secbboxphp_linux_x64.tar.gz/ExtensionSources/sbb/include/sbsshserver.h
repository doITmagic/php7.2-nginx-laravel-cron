#ifndef __INC_SBSSHSERVER
#define __INC_SBSSHSERVER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbmath.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbcryptoprov.h"
#include "sbcustomcrypto.h"
#include "sbsymmetriccrypto.h"
#include "sbpublickeycrypto.h"
#include "sbsshterm.h"
#include "sbsharedresource.h"
#include "sbsshconstants.h"
#include "sbsshcommon.h"
#include "sbsshkeystorage.h"
#include "sbsshutils.h"
#include "sbusers.h"
#include "sbhashfunction.h"
#include "sbconstants.h"
#include "sbstringlist.h"
#include "sbx509.h"
#include "sbpoly1305.h"
#include "sbcustomcertstorage.h"
#include "sbocspstorage.h"
#include "sbocspclient.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSSHUserHandle;

typedef TElClassHandle TElSSHServerTunnelConnectionHandle;

typedef TElSSHServerTunnelConnectionHandle ElSSHServerTunnelConnectionHandle;

typedef TElClassHandle TElSSHServerAdditionalSettingsHandle;

typedef TElClassHandle TElSSHServerHandle;

typedef TElSSHServerHandle ElSSHServerHandle;

typedef uint8_t TSSHServerStateRaw;

typedef enum
{
	ssBefore = 0,
	ssIdentificationLineSent = 1,
	ssIdentificationLineReceived = 2
} TSSHServerState;

typedef uint8_t TSSHServerProtServiceRaw;

typedef enum
{
	spsNone = 0,
	spsAuth = 1,
	spsConn = 2
} TSSHServerProtService;

typedef void (SB_CALLBACK *TSSHAuthAttemptEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, int32_t AuthType, int8_t * Accept);

typedef void (SB_CALLBACK *TSSHAuthPublicKeyEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, TElSSHKeyHandle Key, int8_t * Accept);

typedef void (SB_CALLBACK *TSSHAuthHostbasedEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, const char * pcClientUsername, int32_t szClientUsername, const char * pcClientHostname, int32_t szClientHostname, TElSSHKeyHandle Key, int8_t * Accept);

typedef void (SB_CALLBACK *TSSHAuthBannerEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, int32_t AuthType, char * pcBanner, int32_t * szBanner, uint8_t pLanguageTag[], int32_t * szLanguageTag);

typedef void (SB_CALLBACK *TSSHAuthPasswordEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, const char * pcPassword, int32_t szPassword, int8_t * Accept, int8_t * ForceChangePassword);

typedef void (SB_CALLBACK *TSSHAuthPasswordChangeEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, const char * pcOldPassword, int32_t szOldPassword, const char * pcNewPassword, int32_t szNewPassword, int8_t * Accept);

typedef void (SB_CALLBACK *TSSHAuthKeyboardEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, TStringListHandle Submethods, char * pcName, int32_t * szName, char * pcInstruction, int32_t * szInstruction, TStringListHandle Requests, TBitsHandle Echoes);

typedef void (SB_CALLBACK *TSSHAuthKeyboardResponseEvent)(void * _ObjectData, TObjectHandle Sender, TStringListHandle Requests, TStringListHandle Responses, char * pcName, int32_t * szName, char * pcInstruction, int32_t * szInstruction, TStringListHandle NewRequests, TBitsHandle Echoes, int8_t * Accept);

typedef void (SB_CALLBACK *TSSHFurtherAuthNeededEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, int8_t * Needed);

typedef void (SB_CALLBACK *TSSHBeforeOpenSessionEvent)(void * _ObjectData, TObjectHandle Sender, int8_t * Accept);

typedef void (SB_CALLBACK *TSSHBeforeOpenShellEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, int8_t * Accept);

typedef void (SB_CALLBACK *TSSHBeforeOpenCommandEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcCommand, int32_t szCommand, int8_t * Accept);

typedef void (SB_CALLBACK *TSSHBeforeOpenSubsystemEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcSubsystem, int32_t szSubsystem, TElSSHTunnelConnectionHandle Connection, int8_t * Accept);

typedef void (SB_CALLBACK *TSSHBeforeOpenClientForwardingEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcDestHost, int32_t szDestHost, int32_t DestPort, const char * pcSrcHost, int32_t szSrcHost, int32_t SrcPort, int8_t * Accept);

typedef void (SB_CALLBACK *TSSHBeforeOpenX11ForwardingEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcOrigIP, int32_t szOrigIP, int32_t OrigPort, int8_t * Accept);

typedef void (SB_CALLBACK *TSSHOpenSessionEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection);

typedef void (SB_CALLBACK *TSSHOpenShellEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection);

typedef void (SB_CALLBACK *TSSHOpenCommandEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcCommand, int32_t szCommand);

typedef void (SB_CALLBACK *TSSHOpenSubsystemEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcSubsystem, int32_t szSubsystem);

typedef void (SB_CALLBACK *TSSHOpenClientForwardingEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcDestHost, int32_t szDestHost, int32_t DestPort, const char * pcSrcHost, int32_t szSrcHost, int32_t SrcPort);

typedef void (SB_CALLBACK *TSSHOpenServerForwardingEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection);

typedef void (SB_CALLBACK *TSSHOpenX11ForwardingEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcOrigIP, int32_t szOrigIP, int32_t OrigPort);

typedef void (SB_CALLBACK *TSSHServerForwardingFailedEvent)(void * _ObjectData, TObjectHandle Sender, void * Data);

typedef void (SB_CALLBACK *TSSHServerForwardingRequestEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcAddress, int32_t szAddress, int32_t Port, int8_t * Accept, int32_t * RealPort);

typedef void (SB_CALLBACK *TSSHServerForwardingCancelEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcAddress, int32_t szAddress, int32_t Port);

typedef void (SB_CALLBACK *TSSHX11ForwardingRequestEvent)(void * _ObjectData, TObjectHandle Sender, int8_t SingleConnection, const char * pcAuthProtocol, int32_t szAuthProtocol, const char * pcAuthCookie, int32_t szAuthCookie, int32_t ScreenNumber, int8_t * Accept);

typedef void (SB_CALLBACK *TSSHTerminalRequestEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, TElTerminalInfoHandle Info, int8_t * Accept);

typedef void (SB_CALLBACK *TSSHEnvironmentVariableReceivedEvent)(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcVarName, int32_t szVarName, const char * pcVarValue, int32_t szVarValue);

typedef void (SB_CALLBACK *TSSHSpecialMessageEvent)(void * _ObjectData, TObjectHandle Sender, int32_t Code, void * Buffer, int32_t Size);

typedef uint8_t TSBSSHBannerSendStageRaw;

typedef enum
{
	bssBeforeAuth = 0,
	bssAfterSuccess = 1
} TSBSSHBannerSendStage;

#ifdef SB_USE_CLASS_TELSSHUSER
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_GetData(TElSSHUserHandle _Handle, uint8_t pBuffer[], int32_t * szBuffer, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_SetData(TElSSHUserHandle _Handle, const uint8_t pValue[], int32_t szValue, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_SetBasePath(TElSSHUserHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_SetSSHKey(TElSSHUserHandle _Handle, TElSSHKeyHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_AddUser(TElUsersHandle Users, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword, TElSSHKeyHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_AddUser_1(TElSSHUserHandle _Handle, TElUsersHandle Users, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword, TElSSHKeyHandle Key);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_AddUser_2(TElUsersHandle Users, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword, TElSSHKeyHandle Key, const char * pcBasePath, int32_t szBasePath);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_AddUser_3(TElSSHUserHandle _Handle, TElUsersHandle Users, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword, TElSSHKeyHandle Key, const char * pcBasePath, int32_t szBasePath);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_IsValidSSHKey(TElSSHUserHandle _Handle, TElSSHKeyHandle Key, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_get_SSHKey(TElSSHUserHandle _Handle, TElSSHKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_set_SSHKey(TElSSHUserHandle _Handle, TElSSHKeyHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_get_BasePath(TElSSHUserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_set_BasePath(TElSSHUserHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHUser_Create(const char * pcUserName, int32_t szUserName, TElSSHUserHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHUSER */

#ifdef SB_USE_CLASS_TELSSHSERVERTUNNELCONNECTION
SB_IMPORT uint32_t SB_APIENTRY TElSSHServerTunnelConnection_SendData(TElSSHServerTunnelConnectionHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServerTunnelConnection_SendExtendedData(TElSSHServerTunnelConnectionHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServerTunnelConnection_CanSend(TElSSHServerTunnelConnectionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServerTunnelConnection_GetWindowBufferLength(TElSSHServerTunnelConnectionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServerTunnelConnection_GetExtWindowBufferLength(TElSSHServerTunnelConnectionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServerTunnelConnection_Create(TElSSHTunnelConnectionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHSERVERTUNNELCONNECTION */

#ifdef SB_USE_CLASS_TELSSHSERVERADDITIONALSETTINGS
SB_IMPORT uint32_t SB_APIENTRY TElSSHServerAdditionalSettings_get_OperationStatusCode(TElSSHServerAdditionalSettingsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServerAdditionalSettings_set_OperationStatusCode(TElSSHServerAdditionalSettingsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServerAdditionalSettings_get_OperationStatusString(TElSSHServerAdditionalSettingsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServerAdditionalSettings_set_OperationStatusString(TElSSHServerAdditionalSettingsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServerAdditionalSettings_get_UseKexHashAlgorithmForInnerHash(TElSSHServerAdditionalSettingsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServerAdditionalSettings_set_UseKexHashAlgorithmForInnerHash(TElSSHServerAdditionalSettingsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServerAdditionalSettings_Create(TElSSHServerAdditionalSettingsHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHSERVERADDITIONALSETTINGS */

#ifdef SB_USE_CLASS_TELSSHSERVER
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_Open(TElSSHServerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_OpenServerForwarding(TElSSHServerHandle _Handle, const char * pcAddress, int32_t szAddress, int32_t Port, const char * pcSrcHost, int32_t szSrcHost, int32_t SrcPort, void * Data);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_OpenX11Forwarding(TElSSHServerHandle _Handle, const char * pcOrigHost, int32_t szOrigHost, int32_t OrigPort, void * Data);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_DataAvailable(TElSSHServerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_RenegotiateCiphers(TElSSHServerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_Close(TElSSHServerHandle _Handle, int8_t Forced);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_Close_1(TElSSHServerHandle _Handle, int32_t ErrorCode, const char * pcReason, int32_t szReason);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_ClientCloseReason(TElSSHServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_Username(TElSSHServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_ChangePwdPrompt(TElSSHServerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_ChangePwdPrompt(TElSSHServerHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_AuthTypePriorities(TElSSHServerHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_AuthTypePriorities(TElSSHServerHandle _Handle, int32_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_DefaultWindowSize(TElSSHServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_DefaultWindowSize(TElSSHServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_MinWindowSize(TElSSHServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_MinWindowSize(TElSSHServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_AdditionalSettings(TElSSHServerHandle _Handle, TElSSHServerAdditionalSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_ClientSoftwareName(TElSSHServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_AllowedSubsystems(TElSSHServerHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_KexKeyStorage(TElSSHServerHandle _Handle, TElSSHCustomKeyStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_KexKeyStorage(TElSSHServerHandle _Handle, TElSSHCustomKeyStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_ThreadSafe(TElSSHServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_ThreadSafe(TElSSHServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_BannerSendStage(TElSSHServerHandle _Handle, TSBSSHBannerSendStageRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_BannerSendStage(TElSSHServerHandle _Handle, TSBSSHBannerSendStageRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_SSHAuthOrder(TElSSHServerHandle _Handle, TSBSSHAuthOrderRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_SSHAuthOrder(TElSSHServerHandle _Handle, TSBSSHAuthOrderRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnAuthAttempt(TElSSHServerHandle _Handle, TSSHAuthAttemptEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnAuthAttempt(TElSSHServerHandle _Handle, TSSHAuthAttemptEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnAuthFailed(TElSSHServerHandle _Handle, TSSHAuthenticationFailedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnAuthFailed(TElSSHServerHandle _Handle, TSSHAuthenticationFailedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnAuthBanner(TElSSHServerHandle _Handle, TSSHAuthBannerEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnAuthBanner(TElSSHServerHandle _Handle, TSSHAuthBannerEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnAuthPassword(TElSSHServerHandle _Handle, TSSHAuthPasswordEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnAuthPassword(TElSSHServerHandle _Handle, TSSHAuthPasswordEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnAuthPasswordChange(TElSSHServerHandle _Handle, TSSHAuthPasswordChangeEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnAuthPasswordChange(TElSSHServerHandle _Handle, TSSHAuthPasswordChangeEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnAuthPublicKey(TElSSHServerHandle _Handle, TSSHAuthPublicKeyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnAuthPublicKey(TElSSHServerHandle _Handle, TSSHAuthPublicKeyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnAuthHostbased(TElSSHServerHandle _Handle, TSSHAuthHostbasedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnAuthHostbased(TElSSHServerHandle _Handle, TSSHAuthHostbasedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnAuthKeyboard(TElSSHServerHandle _Handle, TSSHAuthKeyboardEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnAuthKeyboard(TElSSHServerHandle _Handle, TSSHAuthKeyboardEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnAuthKeyboardResponse(TElSSHServerHandle _Handle, TSSHAuthKeyboardResponseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnAuthKeyboardResponse(TElSSHServerHandle _Handle, TSSHAuthKeyboardResponseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnFurtherAuthNeeded(TElSSHServerHandle _Handle, TSSHFurtherAuthNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnFurtherAuthNeeded(TElSSHServerHandle _Handle, TSSHFurtherAuthNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnBeforeOpenSession(TElSSHServerHandle _Handle, TSSHBeforeOpenSessionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnBeforeOpenSession(TElSSHServerHandle _Handle, TSSHBeforeOpenSessionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnBeforeOpenShell(TElSSHServerHandle _Handle, TSSHBeforeOpenShellEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnBeforeOpenShell(TElSSHServerHandle _Handle, TSSHBeforeOpenShellEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnBeforeOpenCommand(TElSSHServerHandle _Handle, TSSHBeforeOpenCommandEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnBeforeOpenCommand(TElSSHServerHandle _Handle, TSSHBeforeOpenCommandEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnBeforeOpenSubsystem(TElSSHServerHandle _Handle, TSSHBeforeOpenSubsystemEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnBeforeOpenSubsystem(TElSSHServerHandle _Handle, TSSHBeforeOpenSubsystemEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnBeforeOpenClientForwarding(TElSSHServerHandle _Handle, TSSHBeforeOpenClientForwardingEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnBeforeOpenClientForwarding(TElSSHServerHandle _Handle, TSSHBeforeOpenClientForwardingEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnBeforeOpenX11Forwarding(TElSSHServerHandle _Handle, TSSHBeforeOpenX11ForwardingEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnBeforeOpenX11Forwarding(TElSSHServerHandle _Handle, TSSHBeforeOpenX11ForwardingEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnOpenSession(TElSSHServerHandle _Handle, TSSHOpenSessionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnOpenSession(TElSSHServerHandle _Handle, TSSHOpenSessionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnOpenShell(TElSSHServerHandle _Handle, TSSHOpenShellEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnOpenShell(TElSSHServerHandle _Handle, TSSHOpenShellEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnOpenCommand(TElSSHServerHandle _Handle, TSSHOpenCommandEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnOpenCommand(TElSSHServerHandle _Handle, TSSHOpenCommandEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnOpenSubsystem(TElSSHServerHandle _Handle, TSSHOpenSubsystemEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnOpenSubsystem(TElSSHServerHandle _Handle, TSSHOpenSubsystemEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnOpenClientForwarding(TElSSHServerHandle _Handle, TSSHOpenClientForwardingEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnOpenClientForwarding(TElSSHServerHandle _Handle, TSSHOpenClientForwardingEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnOpenServerForwarding(TElSSHServerHandle _Handle, TSSHOpenServerForwardingEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnOpenServerForwarding(TElSSHServerHandle _Handle, TSSHOpenServerForwardingEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnOpenX11Forwarding(TElSSHServerHandle _Handle, TSSHOpenX11ForwardingEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnOpenX11Forwarding(TElSSHServerHandle _Handle, TSSHOpenX11ForwardingEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnServerForwardingFailed(TElSSHServerHandle _Handle, TSSHServerForwardingFailedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnServerForwardingFailed(TElSSHServerHandle _Handle, TSSHServerForwardingFailedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnServerForwardingRequest(TElSSHServerHandle _Handle, TSSHServerForwardingRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnServerForwardingRequest(TElSSHServerHandle _Handle, TSSHServerForwardingRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnServerForwardingCancel(TElSSHServerHandle _Handle, TSSHServerForwardingCancelEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnServerForwardingCancel(TElSSHServerHandle _Handle, TSSHServerForwardingCancelEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnX11ForwardingRequest(TElSSHServerHandle _Handle, TSSHX11ForwardingRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnX11ForwardingRequest(TElSSHServerHandle _Handle, TSSHX11ForwardingRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnTerminalRequest(TElSSHServerHandle _Handle, TSSHTerminalRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnTerminalRequest(TElSSHServerHandle _Handle, TSSHTerminalRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnSpecialMessageReceived(TElSSHServerHandle _Handle, TSSHSpecialMessageEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnSpecialMessageReceived(TElSSHServerHandle _Handle, TSSHSpecialMessageEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_get_OnEnvironmentVariableReceived(TElSSHServerHandle _Handle, TSSHEnvironmentVariableReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_set_OnEnvironmentVariableReceived(TElSSHServerHandle _Handle, TSSHEnvironmentVariableReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSHServer_Create(TComponentHandle AOwner, TElSSHServerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSHSERVER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSSHUser_ce_ptr;
extern zend_class_entry *TElSSHServerTunnelConnection_ce_ptr;
extern zend_class_entry *TElSSHServerAdditionalSettings_ce_ptr;
extern zend_class_entry *TElSSHServer_ce_ptr;

void SB_CALLBACK TSSHAuthAttemptEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, int32_t AuthType, int8_t * Accept);
void SB_CALLBACK TSSHAuthPublicKeyEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, TElSSHKeyHandle Key, int8_t * Accept);
void SB_CALLBACK TSSHAuthHostbasedEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, const char * pcClientUsername, int32_t szClientUsername, const char * pcClientHostname, int32_t szClientHostname, TElSSHKeyHandle Key, int8_t * Accept);
void SB_CALLBACK TSSHAuthBannerEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, int32_t AuthType, char * pcBanner, int32_t * szBanner, uint8_t pLanguageTag[], int32_t * szLanguageTag);
void SB_CALLBACK TSSHAuthPasswordEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, const char * pcPassword, int32_t szPassword, int8_t * Accept, int8_t * ForceChangePassword);
void SB_CALLBACK TSSHAuthPasswordChangeEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, const char * pcOldPassword, int32_t szOldPassword, const char * pcNewPassword, int32_t szNewPassword, int8_t * Accept);
void SB_CALLBACK TSSHAuthKeyboardEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, TStringListHandle Submethods, char * pcName, int32_t * szName, char * pcInstruction, int32_t * szInstruction, TStringListHandle Requests, TBitsHandle Echoes);
void SB_CALLBACK TSSHAuthKeyboardResponseEventRaw(void * _ObjectData, TObjectHandle Sender, TStringListHandle Requests, TStringListHandle Responses, char * pcName, int32_t * szName, char * pcInstruction, int32_t * szInstruction, TStringListHandle NewRequests, TBitsHandle Echoes, int8_t * Accept);
void SB_CALLBACK TSSHFurtherAuthNeededEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcUsername, int32_t szUsername, int8_t * Needed);
void SB_CALLBACK TSSHBeforeOpenSessionEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t * Accept);
void SB_CALLBACK TSSHBeforeOpenShellEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, int8_t * Accept);
void SB_CALLBACK TSSHBeforeOpenCommandEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcCommand, int32_t szCommand, int8_t * Accept);
void SB_CALLBACK TSSHBeforeOpenSubsystemEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcSubsystem, int32_t szSubsystem, TElSSHTunnelConnectionHandle Connection, int8_t * Accept);
void SB_CALLBACK TSSHBeforeOpenClientForwardingEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcDestHost, int32_t szDestHost, int32_t DestPort, const char * pcSrcHost, int32_t szSrcHost, int32_t SrcPort, int8_t * Accept);
void SB_CALLBACK TSSHBeforeOpenX11ForwardingEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcOrigIP, int32_t szOrigIP, int32_t OrigPort, int8_t * Accept);
void SB_CALLBACK TSSHOpenSessionEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection);
void SB_CALLBACK TSSHOpenShellEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection);
void SB_CALLBACK TSSHOpenCommandEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcCommand, int32_t szCommand);
void SB_CALLBACK TSSHOpenSubsystemEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcSubsystem, int32_t szSubsystem);
void SB_CALLBACK TSSHOpenClientForwardingEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcDestHost, int32_t szDestHost, int32_t DestPort, const char * pcSrcHost, int32_t szSrcHost, int32_t SrcPort);
void SB_CALLBACK TSSHOpenServerForwardingEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection);
void SB_CALLBACK TSSHOpenX11ForwardingEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcOrigIP, int32_t szOrigIP, int32_t OrigPort);
void SB_CALLBACK TSSHServerForwardingFailedEventRaw(void * _ObjectData, TObjectHandle Sender, void * Data);
void SB_CALLBACK TSSHServerForwardingRequestEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcAddress, int32_t szAddress, int32_t Port, int8_t * Accept, int32_t * RealPort);
void SB_CALLBACK TSSHServerForwardingCancelEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcAddress, int32_t szAddress, int32_t Port);
void SB_CALLBACK TSSHX11ForwardingRequestEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t SingleConnection, const char * pcAuthProtocol, int32_t szAuthProtocol, const char * pcAuthCookie, int32_t szAuthCookie, int32_t ScreenNumber, int8_t * Accept);
void SB_CALLBACK TSSHTerminalRequestEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, TElTerminalInfoHandle Info, int8_t * Accept);
void SB_CALLBACK TSSHEnvironmentVariableReceivedEventRaw(void * _ObjectData, TObjectHandle Sender, TElSSHTunnelConnectionHandle Connection, const char * pcVarName, int32_t szVarName, const char * pcVarValue, int32_t szVarValue);
void SB_CALLBACK TSSHSpecialMessageEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t Code, void * Buffer, int32_t Size);
void Register_TElSSHUser(TSRMLS_D);
void Register_TElSSHServerTunnelConnection(TSRMLS_D);
void Register_TElSSHServerAdditionalSettings(TSRMLS_D);
void Register_TElSSHServer(TSRMLS_D);
void Register_SBSSHServer_Enum_Flags(TSRMLS_D);
void Register_SBSSHServer_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSSHSERVER */

