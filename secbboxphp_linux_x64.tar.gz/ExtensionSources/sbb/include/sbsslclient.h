#ifndef __INC_SBSSLCLIENT
#define __INC_SBSSLCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbasn1tree.h"
#include "sbalgorithmidentifier.h"
#include "sbsslcommon.h"
#include "sbsslconstants.h"
#include "sbrdn.h"
#include "sbocspclient.h"
#include "sbpoly1305.h"
#include "sbcustomcrypto.h"
#include "sbpublickeycrypto.h"
#include "sbcryptoprov.h"
#include "sbcryptoprovmanager.h"
#include "sbsymmetriccrypto.h"
#include "sbhashfunction.h"
#include "sbx509.h"
#include "sbcustomcertstorage.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SSLBufferSize 	65536
#define SB_SSLPacketSize 	8192
#define SB_SSLSmallBufferSize 	32768
#define SB_SSLMaxBufferSize 	262144
#define SB_MIN_SRP_PRIME_LEN 	128

typedef TElClassHandle TElClientSSLConnectionInfoHandle;

typedef TElClassHandle TElSSLClientHandle;

typedef TElSSLClientHandle ElSSLClientHandle;

typedef TElClassHandle TElClientSSLConnectionSettingsHandle;

typedef uint8_t TClientCertificateTypeRaw;

typedef enum
{
	ccRSA = 0,
	ccDSS = 1,
	ccRSADH = 2,
	ccDSSDH = 3,
	ccECDSA = 4,
	ccRSA_ECDH = 5,
	ccECDSA_ECDH = 6
} TClientCertificateType;

typedef void (SB_CALLBACK *TSBChooseCertificateEvent)(void * _ObjectData, TObjectHandle Sender, const TElX509CertificateHandle pCertificates[], int32_t szCertificates, int32_t * CertificateIndex);

typedef void (SB_CALLBACK *TSBCertificateNeededEvent)(void * _ObjectData, TObjectHandle Sender, void * CertificateBuffer, int32_t * CertificateSize, void * PrivateKeyBuffer, int32_t * PrivateKeySize, TClientCertificateTypeRaw CertificateType);

typedef void (SB_CALLBACK *TSBCertificateNeededExEvent)(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle * Certificate);

typedef void (SB_CALLBACK *TSBRawPublicKeyNeededEvent)(void * _ObjectData, TObjectHandle Sender, TElPublicKeyMaterialHandle * RawPublicKey);

typedef void (SB_CALLBACK *TSBClientKeyNeededEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcHint, int32_t szHint, char * pcIdentity, int32_t * szIdentity, uint8_t pKey[], int32_t * szKey);

typedef void (SB_CALLBACK *TSBCertificateStatusEvent)(void * _ObjectData, TObjectHandle Sender, TSBCertificateStatusTypeRaw StatusType, TListHandle Data);

typedef uint8_t TSBRoleRaw;

typedef enum
{
	sClient = 0,
	sServer = 1
} TSBRole;

typedef uint8_t TSSL2ContentTypeRaw;

typedef enum
{
	_ctError = 0,
	ctClientHello = 1,
	ctClientMasterKey = 2,
	ctClientFinished = 3,
	ctServerHello = 4,
	ctServerVerify = 5,
	ctServerFinished = 6,
	ctRequestCertificate = 7,
	ctClientCertificate = 8
} TSSL2ContentType;

#pragma pack(8)
typedef struct 
{
	uint8_t Index;
	uint8_t First;
	uint8_t Second;
	uint8_t Third;
	TSBEncryptAlgorithmRaw EncryptAlgorithm;
	int8_t Exportable;
	uint8_t HashSize;
} TSSL2CipherSuite;

typedef uint8_t TSSL2StateRaw;

typedef enum
{
	stAlone = 0,
	stClientHelloSent = 1,
	stServerHelloReceived = 2,
	stClientMasterKeySent = 3,
	stServerVerifyReceived = 4,
	stClientFinishedSent = 5,
	stServerFinishedReceived = 6,
	stEncryptedDataTransfer = 7
} TSSL2State;

typedef uint8_t TSSL2SequenceNumberOwnerRaw;

typedef enum
{
	snServer = 0,
	snClient = 1
} TSSL2SequenceNumberOwner;

typedef uint8_t TSSL3StateRaw;

typedef enum
{
	st3Alone = 0,
	st3ClientHelloSent = 1,
	st3ServerHelloReceived = 2,
	st3CertificateReceived = 3,
	st3ServerKeyExchangeReceived = 4,
	st3CertificateSent = 5,
	st3ClientKeyExchangeSent = 6,
	st3CertificateVerifySent = 7,
	st3ClientChangeCipherSpecSent = 8,
	st3FinishedSent = 9,
	st3ServerChangeCipherSpecReceived = 10,
	st3ServerFinishedReceived = 11,
	st3EncryptedDataTransfer = 12,
	st3ServerHelloDoneReceived = 13,
	_stUnknown = 14
} TSSL3State;

#pragma pack(8)
typedef struct 
{
	uint8_t Index;
	uint8_t First;
	uint8_t Second;
	int8_t Exportable;
	TSBEncryptAlgorithmRaw EncryptAlgorithm;
	TSBDigestAlgorithmRaw DigestAlgorithm;
	TSBKeyExchangeAlgorithmRaw KeyExchangeAlgorithm;
	TSBSignatureAlgorithmRaw SignatureAlgorithm;
	int32_t PRFHashAlgorithm;
	uint8_t HashSize;
	uint8_t RealHashSize;
	uint8_t KeySize;
	uint8_t IVSize;
	uint8_t BlockSize;
	uint8_t PaddingSize;
	int8_t AEADCipher;
} TSSL3CipherSuite;

typedef uint8_t TCloseExplainRaw;

typedef enum
{
	ceNormal = 0,
	ceBadHandshake = 1,
	ceServerClose = 2
} TCloseExplain;

#pragma pack(8)
typedef struct 
{
	TClientCertificateTypeRaw CertificateType;
	int8_t _dummy0;
	int16_t _dummy1;
#ifdef CPU64
	int32_t _dummy2;
#endif
	void * CertificateData;
	int32_t CertificateSize;
#ifdef CPU64
	int32_t _dummy3;
#endif
	void * PrivateKeyData;
	int32_t PrivateKeySize;
} TClientCertificate;

typedef uint8_t TSBClientSSLPredefinedConfigurationRaw;

typedef enum
{
	scpcDefault = 0,
	scpcComprehensive = 1,
	scpcHighlySecure = 2,
	scpcOld = 3
} TSBClientSSLPredefinedConfiguration;

#ifdef SB_USE_CLASS_TELCLIENTSSLCONNECTIONINFO
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionInfo_Initialize(TElClientSSLConnectionInfoHandle _Handle, TSBVersionRaw Version, uint8_t Ciphersuite, TElCustomCertStorageHandle ServerChain, TElCustomCertStorageHandle ClientChain, const uint8_t pSessionID[], int32_t szSessionID, int8_t ResumedSession);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionInfo_Initialize2(TElClientSSLConnectionInfoHandle _Handle, TSBVersionRaw Version, uint8_t Ciphersuite, TElX509CertificateChainHandle ServerChain, TElCustomCertStorageHandle ClientChain, const uint8_t pSessionID[], int32_t szSessionID, int8_t ResumedSession, int32_t ECCurve);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionInfo_Reset(TElClientSSLConnectionInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionInfo_Create(TElSSLClassHandle Owner, TElSSLConnectionInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELCLIENTSSLCONNECTIONINFO */

#ifdef SB_USE_CLASS_TELSSLCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_Open(TElSSLClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_Close(TElSSLClientHandle _Handle, int8_t Silent);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_DataAvailable(TElSSLClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_SendData(TElSSLClientHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_SendText(TElSSLClientHandle _Handle, const uint8_t pS[], int32_t szS);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_SendKeepAlive(TElSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_InternalValidate(TElSSLClientHandle _Handle, TSBCertificateValidityRaw * Validity, TSBCertificateValidityReasonRaw * Reason);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_Resume(TElSSLClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_Join(TElSSLClientHandle _Handle, TElSSLClientHandle ElSecureClient);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_RenegotiateCiphers(TElSSLClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_Reset(TElSSLClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_AddCertificateType(TElSSLClientHandle _Handle, TElSSLCertificateTypeRaw C_Type);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_DelCertificateType(TElSSLClientHandle _Handle, TElSSLCertificateTypeRaw C_Type);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_GetCertTypesCount(TElSSLClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_ClearCertificateType(TElSSLClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_AddClientCertificateType(TElSSLClientHandle _Handle, TElSSLCertificateTypeRaw C_Type);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_DelClientCertificateType(TElSSLClientHandle _Handle, TElSSLCertificateTypeRaw C_Type);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_GetClientCertTypesCount(TElSSLClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_ClearClientCertificateType(TElSSLClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_CipherSuite(TElSSLClientHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_CertTypes(TElSSLClientHandle _Handle, int32_t Index, TElSSLCertificateTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_CertTypes(TElSSLClientHandle _Handle, int32_t Index, TElSSLCertificateTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_ClientCertTypes(TElSSLClientHandle _Handle, int32_t Index, TElSSLCertificateTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_ClientCertTypes(TElSSLClientHandle _Handle, int32_t Index, TElSSLCertificateTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_ECCurves(TElSSLClientHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_ECCurves(TElSSLClientHandle _Handle, int32_t Index, int8_t Enabled);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_ECPoints(TElSSLClientHandle _Handle, int32_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_ECPoints(TElSSLClientHandle _Handle, int32_t Index, int8_t Enabled);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_CanResume(TElSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_ClientState(TElSSLClientHandle _Handle, TSSL3StateRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_Enabled(TElSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_Enabled(TElSSLClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_CryptoProviderManager(TElSSLClientHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_CryptoProviderManager(TElSSLClientHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_UsedCertificateTypeExtension(TElSSLClientHandle _Handle, TSBCertificateTypeExtensionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_UsedCertificateTypeExtension(TElSSLClientHandle _Handle, TSBCertificateTypeExtensionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_UseExtendedMasterSecret(TElSSLClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_UseExtendedMasterSecret(TElSSLClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_CertStorage(TElSSLClientHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_CertStorage(TElSSLClientHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_ClientCertStorage(TElSSLClientHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_ClientCertStorage(TElSSLClientHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_ClientRawKeyStorage(TElSSLClientHandle _Handle, TElKeyMaterialStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_ClientRawKeyStorage(TElSSLClientHandle _Handle, TElKeyMaterialStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_Extensions(TElSSLClientHandle _Handle, TElClientSSLExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_PeerExtensions(TElSSLClientHandle _Handle, TElServerSSLExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_SRPUsername(TElSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_SRPUsername(TElSSLClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_SRPPassword(TElSSLClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_SRPPassword(TElSSLClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_OnCloseConnection(TElSSLClientHandle _Handle, TSBCloseConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_OnCloseConnection(TElSSLClientHandle _Handle, TSBCloseConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_OnCertificateChoose(TElSSLClientHandle _Handle, TSBChooseCertificateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_OnCertificateChoose(TElSSLClientHandle _Handle, TSBChooseCertificateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_OnCertificateNeeded(TElSSLClientHandle _Handle, TSBCertificateNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_OnCertificateNeeded(TElSSLClientHandle _Handle, TSBCertificateNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_OnCertificateNeededEx(TElSSLClientHandle _Handle, TSBCertificateNeededExEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_OnCertificateNeededEx(TElSSLClientHandle _Handle, TSBCertificateNeededExEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_OnCertificateStatus(TElSSLClientHandle _Handle, TSBCertificateStatusEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_OnCertificateStatus(TElSSLClientHandle _Handle, TSBCertificateStatusEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_OnKeyNeeded(TElSSLClientHandle _Handle, TSBClientKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_OnKeyNeeded(TElSSLClientHandle _Handle, TSBClientKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_get_OnRenegotiationRequest(TElSSLClientHandle _Handle, TSBRenegotiationRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_set_OnRenegotiationRequest(TElSSLClientHandle _Handle, TSBRenegotiationRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClient_Create(TComponentHandle Owner, TElSSLClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSLCLIENT */

#ifdef SB_USE_CLASS_TELCLIENTSSLCONNECTIONSETTINGS
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_ActivatePredefinedConfiguration(TElClientSSLConnectionSettingsHandle _Handle, TSBClientSSLPredefinedConfigurationRaw Config);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_EnableAllCiphers(TElClientSSLConnectionSettingsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_EnableAllCiphers_1(TElClientSSLConnectionSettingsHandle _Handle, int8_t ExcludeInsecure);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_EnableCiphers(TElClientSSLConnectionSettingsHandle _Handle, int32_t MinLevel, int32_t MaxLevel);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_DisableAllCiphers(TElClientSSLConnectionSettingsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_DisableCiphers(TElClientSSLConnectionSettingsHandle _Handle, int32_t MinLevel, int32_t MaxLevel);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_DisableEncryptionAlgorithm(TElClientSSLConnectionSettingsHandle _Handle, TSBEncryptAlgorithmRaw Algorithm);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_DisableEncryptionAlgorithm_1(TElClientSSLConnectionSettingsHandle _Handle, TSBEncryptAlgorithmRaw Algorithm, int8_t Inverted);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_DisableKeyExchangeAlgorithm(TElClientSSLConnectionSettingsHandle _Handle, TSBKeyExchangeAlgorithmRaw Algorithm);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_DisableKeyExchangeAlgorithm_1(TElClientSSLConnectionSettingsHandle _Handle, TSBKeyExchangeAlgorithmRaw Algorithm, int8_t Inverted);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_DisableDigestAlgorithm(TElClientSSLConnectionSettingsHandle _Handle, TSBDigestAlgorithmRaw Algorithm);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_DisableDigestAlgorithm_1(TElClientSSLConnectionSettingsHandle _Handle, TSBDigestAlgorithmRaw Algorithm, int8_t Inverted);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_DisableSignatureAlgorithm(TElClientSSLConnectionSettingsHandle _Handle, TSBSignatureAlgorithmRaw Algorithm);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_DisableSignatureAlgorithm_1(TElClientSSLConnectionSettingsHandle _Handle, TSBSignatureAlgorithmRaw Algorithm, int8_t Inverted);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_Load(TElClientSSLConnectionSettingsHandle _Handle, const char * pcS, int32_t szS);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_Save(TElClientSSLConnectionSettingsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_get_Versions(TElClientSSLConnectionSettingsHandle _Handle, TSBVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_set_Versions(TElClientSSLConnectionSettingsHandle _Handle, TSBVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLConnectionSettings_Create(TElSSLClientHandle Owner, TElClientSSLConnectionSettingsHandle * OutResult);
#endif /* SB_USE_CLASS_TELCLIENTSSLCONNECTIONSETTINGS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TSSL2CipherSuite_ce_ptr;
extern zend_class_entry *TSSL3CipherSuite_ce_ptr;
extern zend_class_entry *TClientCertificate_ce_ptr;
extern zend_class_entry *TElClientSSLConnectionInfo_ce_ptr;
extern zend_class_entry *TElSSLClient_ce_ptr;
extern zend_class_entry *TElClientSSLConnectionSettings_ce_ptr;

void SB_CALLBACK TSBChooseCertificateEventRaw(void * _ObjectData, TObjectHandle Sender, const TElX509CertificateHandle pCertificates[], int32_t szCertificates, int32_t * CertificateIndex);
void SB_CALLBACK TSBCertificateNeededEventRaw(void * _ObjectData, TObjectHandle Sender, void * CertificateBuffer, int32_t * CertificateSize, void * PrivateKeyBuffer, int32_t * PrivateKeySize, TClientCertificateTypeRaw CertificateType);
void SB_CALLBACK TSBCertificateNeededExEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle * Certificate);
void SB_CALLBACK TSBRawPublicKeyNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElPublicKeyMaterialHandle * RawPublicKey);
void SB_CALLBACK TSBClientKeyNeededEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcHint, int32_t szHint, char * pcIdentity, int32_t * szIdentity, uint8_t pKey[], int32_t * szKey);
void SB_CALLBACK TSBCertificateStatusEventRaw(void * _ObjectData, TObjectHandle Sender, TSBCertificateStatusTypeRaw StatusType, TListHandle Data);
void Register_TSSL2CipherSuite(TSRMLS_D);
void Register_TSSL3CipherSuite(TSRMLS_D);
void Register_TClientCertificate(TSRMLS_D);
void Register_TElClientSSLConnectionInfo(TSRMLS_D);
void Register_TElSSLClient(TSRMLS_D);
void Register_TElClientSSLConnectionSettings(TSRMLS_D);
void Register_SBSSLClient_Constants(int module_number TSRMLS_DC);
void Register_SBSSLClient_Enum_Flags(TSRMLS_D);
void Register_SBSSLClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSSLCLIENT */
