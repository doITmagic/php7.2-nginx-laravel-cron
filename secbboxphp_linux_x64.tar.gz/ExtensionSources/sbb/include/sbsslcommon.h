#ifndef __INC_SBSSLCOMMON
#define __INC_SBSSLCOMMON

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcustomcertstorage.h"
#include "sbx509.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbalgorithmidentifier.h"
#include "sbrdn.h"
#include "sbsharedresource.h"
#include "sbtimer.h"
#include "sbpublickeycrypto.h"
#include "sbcustomcrypto.h"
#include "sbsslconstants.h"
#include "sbrandom.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_DTLS_WINDOW_SIZE 	64

typedef TElClassHandle TElSSLCertificateTypeHandlerHandle;

typedef TElSSLCertificateTypeHandlerHandle ElSSLCertificateTypeHandlerHandle;

typedef TElClassHandle TElCustomSSLExtensionHandle;

typedef TElCustomSSLExtensionHandle ElCustomSSLExtensionHandle;

typedef TElClassHandle TElSSLClassHandle;

typedef TElSSLClassHandle ElSSLClassHandle;

typedef TElClassHandle TElSSLConnectionInfoHandle;

typedef TElClassHandle TElSSLServerNameHandle;

typedef TElSSLServerNameHandle ElSSLServerNameHandle;

typedef TElClassHandle TElHeartbeatHelloSSLExtensionHandle;

typedef TElHeartbeatHelloSSLExtensionHandle ElHeartbeatHelloSSLExtensionHandle;

typedef TElClassHandle TElServerNameSSLExtensionHandle;

typedef TElServerNameSSLExtensionHandle ElServerNameSSLExtensionHandle;

typedef TElClassHandle TElUserNameSSLExtensionHandle;

typedef TElUserNameSSLExtensionHandle ElUserNameSSLExtensionHandle;

typedef TElClassHandle TElECCurveSSLExtensionHandle;

typedef TElClassHandle TElECPointSSLExtensionHandle;

typedef TElClassHandle TElCertificateTypeResponseHandle;

typedef TElClassHandle TElCertificateTypeRequestHandle;

typedef TElClassHandle TElExtendedMasterSecretExtensionHandle;

typedef TElExtendedMasterSecretExtensionHandle ElExtendedMasterSecretExtensionHandle;

typedef TElClassHandle TElMaxFragmentLengthSSLExtensionHandle;

typedef TElMaxFragmentLengthSSLExtensionHandle ElMaxFragmentLengthSSLExtensionHandle;

typedef TElClassHandle TElSSLCertURLHandle;

typedef TElSSLCertURLHandle ElSSLCertURLHandle;

typedef TElClassHandle TElClientCertURLsSSLExtensionHandle;

typedef TElClientCertURLsSSLExtensionHandle ElClientCertURLsSSLExtensionHandle;

typedef TElClassHandle TElSSLTrustedCAHandle;

typedef TElSSLTrustedCAHandle ElSSLTrustedCAHandle;

typedef TElClassHandle TElTrustedCAsSSLExtensionHandle;

typedef TElTrustedCAsSSLExtensionHandle ElTrustedCAsSSLExtensionHandle;

typedef TElClassHandle TElTruncatedHMACSSLExtensionHandle;

typedef TElTruncatedHMACSSLExtensionHandle ElTruncatedHMACSSLExtensionHandle;

typedef TElClassHandle TElSSLOCSPStatusRequestHandle;

typedef TElSSLOCSPStatusRequestHandle ElSSLOCSPStatusRequestHandle;

typedef TElClassHandle TElCertificateStatusSSLExtensionHandle;

typedef TElCertificateStatusSSLExtensionHandle ElCertificateStatusSSLExtensionHandle;

typedef TElClassHandle TElSessionTicketSSLExtensionHandle;

typedef TElClassHandle TElCertHashTypesSSLExtensionHandle;

typedef TElClassHandle TElRenegotiationInfoSSLExtensionHandle;

typedef TElClassHandle TElSignatureAlgorithmsSSLExtensionHandle;

typedef TElClassHandle TElSRPSSLExtensionHandle;

typedef TElClassHandle TElCustomSSLExtensionsHandle;

typedef TElCustomSSLExtensionsHandle ElCustomSSLExtensionsHandle;

typedef TElClassHandle TElClientSSLExtensionsHandle;

typedef TElClientSSLExtensionsHandle ElClientSSLExtensionsHandle;

typedef TElClassHandle TElServerSSLExtensionsHandle;

typedef TElServerSSLExtensionsHandle ElServerSSLExtensionsHandle;

typedef TElClassHandle TElSSLRetransmissionTimerHandle;

typedef TElClassHandle TElSSLX509CertificateTypeHandlerHandle;

typedef TElSSLX509CertificateTypeHandlerHandle ElSSLX509CertificateTypeHandlerHandle;

typedef TElClassHandle TElSSLRawKeyCertificateTypeHandlerHandle;

typedef TElSSLRawKeyCertificateTypeHandlerHandle ElSSLRawKeyCertificateTypeHandlerHandle;

typedef TElClassHandle TElDTLSFlightItemHandle;

typedef uint8_t TSBReceiveStateRaw;

typedef enum
{
	_rsRecordHeaderWanted = 0,
	_rsRecordWanted = 1,
	rsOneByteWanted = 2
} TSBReceiveState;

typedef TElClassHandle IElSSLCertificateHandlerContainerHandle;

typedef uint8_t TSBSSLModeRaw;

typedef enum
{
	smImplicit = 0,
	smExplicit = 1,
	smExplicitManual = 2
} TSBSSLMode;

typedef uint8_t TSBCloseReasonRaw;

typedef enum
{
	crError = 0,
	crClose = 1
} TSBCloseReason;

typedef void (SB_CALLBACK *TSBDataEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);

typedef void (SB_CALLBACK *TSBReceiveEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t MaxSize, int32_t * Written);

typedef void (SB_CALLBACK *TSBSendEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);

typedef void (SB_CALLBACK *TSBOpenConnectionEvent)(void * _ObjectData, TObjectHandle Sender);

typedef void (SB_CALLBACK *TSBCloseConnectionEvent)(void * _ObjectData, TObjectHandle Sender, TSBCloseReasonRaw CloseReason);

typedef void (SB_CALLBACK *TSBRenegotiationStartEvent)(void * _ObjectData, TObjectHandle Sender, int8_t Safe, int8_t * Allow);

typedef void (SB_CALLBACK *TSBRenegotiationRequestEvent)(void * _ObjectData, TObjectHandle Sender, int8_t * Allow);

typedef void (SB_CALLBACK *TSBErrorEvent)(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode, int8_t Fatal, int8_t Remote);

typedef uint8_t TSBAlertLevelRaw;

typedef enum
{
	alWarning = 0,
	alFatal = 1
} TSBAlertLevel;

typedef uint8_t TSBAlertDescriptionRaw;

typedef enum
{
	adCloseNotify = 0,
	adUnexpectedMessage = 1,
	adBadRecordMac = 2,
	adDecryptionFailed = 3,
	adRecordOverflow = 4,
	adDecompressionFailure = 5,
	adHandshakeFailure = 6,
	adNoCertificate = 7,
	adBadCertificate = 8,
	adUnsupportedCertificate = 9,
	adCertificateRevoked = 10,
	adCertificateExpired = 11,
	adCertificateUnknown = 12,
	adIllegalParameter = 13,
	adUnknownCa = 14,
	adAccessDenied = 15,
	adDecodeError = 16,
	adDecryptError = 17,
	adExportRestriction = 18,
	adProtocolVersion = 19,
	adInsufficientSecurity = 20,
	adInternalError = 21,
	adUserCanceled = 22,
	adNoRenegotiation = 23,
	adUnsupportedExtension = 24,
	adNoSharedCipher = 25,
	adInappropriateFallback = 26,
	adUnknownPSKIdentity = 27,
	adCertificateUnobtainable = 28,
	adUnrecognizedName = 29,
	adBadCertificateStatusResponse = 30,
	adBadCertificateHashValue = 31
} TSBAlertDescription;

typedef uint8_t TSBSSLOptionRaw;

typedef enum
{
	ssloExpectShutdownMessage = 0,
	ssloOpenSSLDTLSWorkaround = 1,
	ssloDisableKexLengthAlignment = 2,
	ssloForceUseOfClientCertHashAlg = 3,
	ssloAutoAddServerNameExtension = 4,
	ssloAcceptTrustedSRPPrimesOnly = 5,
	ssloDisableSignatureAlgorithmsExtension = 6,
	ssloIntolerateHigherProtocolVersions = 7,
	ssloStickToPrefCertHashAlg = 8
} TSBSSLOption;

typedef uint32_t TSBSSLOptionsRaw;

typedef enum 
{
	f_ssloExpectShutdownMessage = 1,
	f_ssloOpenSSLDTLSWorkaround = 2,
	f_ssloDisableKexLengthAlignment = 4,
	f_ssloForceUseOfClientCertHashAlg = 8,
	f_ssloAutoAddServerNameExtension = 16,
	f_ssloAcceptTrustedSRPPrimesOnly = 32,
	f_ssloDisableSignatureAlgorithmsExtension = 64,
	f_ssloIntolerateHigherProtocolVersions = 128,
	f_ssloStickToPrefCertHashAlg = 256
} TSBSSLOptions;

typedef uint8_t TSBKeyExchangeAlgorithmRaw;

typedef enum
{
	kaNULL = 0,
	kaRSA = 1,
	kaDH = 2,
	kaDHE = 3,
	kaDHanon = 4,
	kaPSK = 5,
	kaDHEPSK = 6,
	kaRSAPSK = 7,
	kaSRP = 8,
	kaECDH_ECDSA = 9,
	kaECDHE_ECDSA = 10,
	kaECDH_RSA = 11,
	kaECDHE_RSA = 12,
	kaECDH_anon = 13,
	kaECDHE_PSK = 14
} TSBKeyExchangeAlgorithm;

typedef uint8_t TSBDigestAlgorithmRaw;

typedef enum
{
	daNULL = 0,
	daMD5 = 1,
	daSHA = 2,
	daSHA256 = 3,
	daSHA384 = 4,
	daSHA512 = 5
} TSBDigestAlgorithm;

typedef uint8_t TSBEncryptAlgorithmRaw;

typedef enum
{
	eaNULL = 0,
	eaRC4 = 1,
	eaRC2 = 2,
	eaDES = 3,
	ea3DES = 4,
	eaIDEA = 5,
	eaAES128 = 6,
	eaAES256 = 7,
	eaCamellia128 = 8,
	eaCamellia256 = 9,
	eaSeed = 10,
	eaAES128GCM = 11,
	eaAES256GCM = 12,
	eaCamellia128GCM = 13,
	eaCamellia256GCM = 14,
	eaChaCha20Poly1305 = 15
} TSBEncryptAlgorithm;

typedef uint8_t TSBSignatureAlgorithmRaw;

typedef enum
{
	saAnonymous = 0,
	saRSA = 1,
	saDSA = 2,
	saECDSA = 3,
	saNull = 4
} TSBSignatureAlgorithm;

typedef uint8_t TSBRenegotiationAttackPreventionModeRaw;

typedef enum
{
	rapmCompatible = 0,
	rapmStrict = 1,
	rapmAuto = 2
} TSBRenegotiationAttackPreventionMode;

typedef uint8_t TSBSSLServerNameTypeRaw;

typedef enum
{
	ntHostName = 0,
	ntUnknown = 1
} TSBSSLServerNameType;

typedef uint8_t TSBSSLFragmentLengthRaw;

typedef enum
{
	fl512 = 0,
	fl1024 = 1,
	fl2048 = 2,
	fl4096 = 3,
	flUnknown = 4
} TSBSSLFragmentLength;

typedef uint8_t TSBCertChainTypeRaw;

typedef enum
{
	cctIndividualCerts = 0,
	cctPKIPath = 1,
	cctUnknown = 2
} TSBCertChainType;

typedef uint8_t TSBCAIdentifierTypeRaw;

typedef enum
{
	itPreAgreed = 0,
	itKeyHash = 1,
	itRDN = 2,
	itCertHash = 3,
	itUnknown = 4
} TSBCAIdentifierType;

typedef uint8_t TSBCertificateStatusTypeRaw;

typedef enum
{
	cstOCSP = 0,
	cstMultiOCSP = 1,
	cstUnknown = 2
} TSBCertificateStatusType;

typedef void (SB_CALLBACK *TSBExtensionsReceivedEvent)(void * _ObjectData, TObjectHandle Sender);

typedef void (SB_CALLBACK *TSBExtensionsPreparedEvent)(void * _ObjectData, TObjectHandle Sender);

typedef uint8_t TSSL3ContentTypeRaw;

typedef enum
{
	ctChangeCipherSpec = 0,
	ctAlert = 1,
	ctHandshake = 2,
	ctApplicationData = 3,
	ctHeartbeat = 4,
	__ctUnknown = 5
} TSSL3ContentType;

typedef uint8_t TSSL3HandshakeTypeRaw;

typedef enum
{
	htHelloRequest = 0,
	htClientHello = 1,
	htServerHello = 2,
	htCertificate = 3,
	htServerKeyExchange = 4,
	htCertificateRequest = 5,
	htServerHelloDone = 6,
	htCertificateVerify = 7,
	htClientKeyExchange = 8,
	htFinished = 9,
	htCertificateURL = 10,
	htCertificateStatus = 11,
	htNewSessionTicket = 12
} TSSL3HandshakeType;

#ifdef SB_USE_CLASS_TELSSLCERTIFICATETYPEHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertificateTypeHandler_GetCertificateType(TElSSLCertificateTypeHandlerHandle _Handle, TElSSLCertificateTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertificateTypeHandler_GetDataForRemote(TElSSLCertificateTypeHandlerHandle _Handle, int32_t CipherSuite, TSBKeyExchangeAlgorithmRaw KeyExchange, uint8_t pData[], int32_t * szData, int32_t Optional, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertificateTypeHandler_ValidateRemoteCert(TElSSLCertificateTypeHandlerHandle _Handle, const uint8_t pData[], int32_t szData, int32_t Optional, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertificateTypeHandler_GetRemoteKeyMaterial(TElSSLCertificateTypeHandlerHandle _Handle, const uint8_t pData[], int32_t szData, int32_t KeyType, int32_t * PKType, int32_t * KeyAlgorithm, TElKeyMaterialHandle * KeyMaterial);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertificateTypeHandler_GetKeyMaterial(TElSSLCertificateTypeHandlerHandle _Handle, TElKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertificateTypeHandler_GetPublicKeySize(TElSSLCertificateTypeHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertificateTypeHandler_GetPublicKeyAlgorithm(TElSSLCertificateTypeHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertificateTypeHandler_get_KeyIndex(TElSSLCertificateTypeHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertificateTypeHandler_set_KeyIndex(TElSSLCertificateTypeHandlerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertificateTypeHandler_get_KeyCount(TElSSLCertificateTypeHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertificateTypeHandler_get_SSLClass(TElSSLCertificateTypeHandlerHandle _Handle, IElSSLCertificateHandlerContainerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertificateTypeHandler_set_SSLClass(TElSSLCertificateTypeHandlerHandle _Handle, IElSSLCertificateHandlerContainerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertificateTypeHandler_Create(TComponentHandle AOwner, TComponentHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSLCERTIFICATETYPEHANDLER */

#ifdef SB_USE_CLASS_TELCUSTOMSSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtension_Assign(TElCustomSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtension_Clear(TElCustomSSLExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtension_get_ExtensionType(TElCustomSSLExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtension_set_ExtensionType(TElCustomSSLExtensionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtension_get_ExtensionData(TElCustomSSLExtensionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtension_set_ExtensionData(TElCustomSSLExtensionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtension_get_Enabled(TElCustomSSLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtension_set_Enabled(TElCustomSSLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtension_get_Server(TElCustomSSLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtension_set_Server(TElCustomSSLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtension_Create(TElCustomSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMSSLEXTENSION */

#ifdef SB_USE_CLASS_TELSSLCLASS
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_AddCertTypeHandler(TElSSLClassHandle _Handle, TElSSLCertificateTypeHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_RemoveCertTypeHandler(TElSSLClassHandle _Handle, TElSSLCertificateTypeHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_EnterCS(TElSSLClassHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_LeaveCS(TElSSLClassHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_AssignFromTemplate(TElSSLClassHandle _Handle, TElSSLClassHandle Tpl);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_Reset(TElSSLClassHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_CipherSuites(TElSSLClassHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_CipherSuites(TElSSLClassHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_CipherSuitePriorities(TElSSLClassHandle _Handle, uint8_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_CipherSuitePriorities(TElSSLClassHandle _Handle, uint8_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_CompressionAlgorithms(TElSSLClassHandle _Handle, uint8_t Index, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_CompressionAlgorithms(TElSSLClassHandle _Handle, uint8_t Index, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_Active(TElSSLClassHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_CurrentVersion(TElSSLClassHandle _Handle, TSBVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_CompressionAlgorithm(TElSSLClassHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_TotalBytesSent(TElSSLClassHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_TotalBytesReceived(TElSSLClassHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_ConnectionInfo(TElSSLClassHandle _Handle, TElSSLConnectionInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_Versions(TElSSLClassHandle _Handle, TSBVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_Versions(TElSSLClassHandle _Handle, TSBVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_Options(TElSSLClassHandle _Handle, TSBSSLOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_Options(TElSSLClassHandle _Handle, TSBSSLOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_RenegotiationAttackPreventionMode(TElSSLClassHandle _Handle, TSBRenegotiationAttackPreventionModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_RenegotiationAttackPreventionMode(TElSSLClassHandle _Handle, TSBRenegotiationAttackPreventionModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_OnSend(TElSSLClassHandle _Handle, TSBSendEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_OnSend(TElSSLClassHandle _Handle, TSBSendEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_OnReceive(TElSSLClassHandle _Handle, TSBReceiveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_OnReceive(TElSSLClassHandle _Handle, TSBReceiveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_OnData(TElSSLClassHandle _Handle, TSBDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_OnData(TElSSLClassHandle _Handle, TSBDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_OnOpenConnection(TElSSLClassHandle _Handle, TSBOpenConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_OnOpenConnection(TElSSLClassHandle _Handle, TSBOpenConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_OnCertificateValidate(TElSSLClassHandle _Handle, TSBCertificateValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_OnCertificateValidate(TElSSLClassHandle _Handle, TSBCertificateValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_OnRawPublicKeyValidate(TElSSLClassHandle _Handle, TSBRawPublicKeyValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_OnRawPublicKeyValidate(TElSSLClassHandle _Handle, TSBRawPublicKeyValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_OnCiphersNegotiated(TElSSLClassHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_OnCiphersNegotiated(TElSSLClassHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_OnError(TElSSLClassHandle _Handle, TSBErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_OnError(TElSSLClassHandle _Handle, TSBErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_OnExtensionsReceived(TElSSLClassHandle _Handle, TSBExtensionsReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_OnExtensionsReceived(TElSSLClassHandle _Handle, TSBExtensionsReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_OnExtensionsPrepared(TElSSLClassHandle _Handle, TSBExtensionsPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_OnExtensionsPrepared(TElSSLClassHandle _Handle, TSBExtensionsPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_get_OnKeepAliveResponse(TElSSLClassHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_set_OnKeepAliveResponse(TElSSLClassHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLClass_Create(TComponentHandle Owner, TElSSLClassHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSLCLASS */

#ifdef SB_USE_CLASS_TELSSLCONNECTIONINFO
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_InitializeNonSecure(TElSSLConnectionInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_Initialize(TElSSLConnectionInfoHandle _Handle, TSBVersionRaw Version, uint8_t Ciphersuite, TElCustomCertStorageHandle ServerChain, TElCustomCertStorageHandle ClientChain, const uint8_t pSessionID[], int32_t szSessionID, int8_t ResumedSession);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_Reset(TElSSLConnectionInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_Ciphersuite(TElSSLConnectionInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_CiphersuiteName(TElSSLConnectionInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_EncryptionAlgorithm(TElSSLConnectionInfoHandle _Handle, TSBEncryptAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_KeyExchangeAlgorithm(TElSSLConnectionInfoHandle _Handle, TSBKeyExchangeAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_SignatureAlgorithm(TElSSLConnectionInfoHandle _Handle, TSBSignatureAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_DigestAlgorithm(TElSSLConnectionInfoHandle _Handle, TSBDigestAlgorithmRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_Version(TElSSLConnectionInfoHandle _Handle, TSBVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_Exportable(TElSSLConnectionInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_SymmetricKeyBits(TElSSLConnectionInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_PublicKeyBits(TElSSLConnectionInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_KeyExchangeKeyBits(TElSSLConnectionInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_SymmetricBlockSize(TElSSLConnectionInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_AEADCipher(TElSSLConnectionInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_ClientChain(TElSSLConnectionInfoHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_ServerChain(TElSSLConnectionInfoHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_SessionID(TElSSLConnectionInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_ResumedSession(TElSSLConnectionInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_ConnectionEstablished(TElSSLConnectionInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_PFSCipher(TElSSLConnectionInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_ClientAuthenticated(TElSSLConnectionInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_ServerAuthenticated(TElSSLConnectionInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_SecureConnection(TElSSLConnectionInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_get_NamedECCurve(TElSSLConnectionInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLConnectionInfo_Create(TElSSLClassHandle Owner, TElSSLConnectionInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSLCONNECTIONINFO */

#ifdef SB_USE_CLASS_TELSSLSERVERNAME
SB_IMPORT uint32_t SB_APIENTRY TElSSLServerName_get_NameType(TElSSLServerNameHandle _Handle, TSBSSLServerNameTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLServerName_set_NameType(TElSSLServerNameHandle _Handle, TSBSSLServerNameTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLServerName_get_Name(TElSSLServerNameHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLServerName_set_Name(TElSSLServerNameHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLServerName_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSLSERVERNAME */

#ifdef SB_USE_CLASS_TELHEARTBEATHELLOSSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElHeartbeatHelloSSLExtension_Assign(TElHeartbeatHelloSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElHeartbeatHelloSSLExtension_get_Mode(TElHeartbeatHelloSSLExtensionHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElHeartbeatHelloSSLExtension_set_Mode(TElHeartbeatHelloSSLExtensionHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElHeartbeatHelloSSLExtension_Create(TElHeartbeatHelloSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELHEARTBEATHELLOSSLEXTENSION */

#ifdef SB_USE_CLASS_TELSERVERNAMESSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElServerNameSSLExtension_Assign(TElServerNameSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElServerNameSSLExtension_Add(TElServerNameSSLExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElServerNameSSLExtension_Remove(TElServerNameSSLExtensionHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElServerNameSSLExtension_Clear(TElServerNameSSLExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElServerNameSSLExtension_get_Names(TElServerNameSSLExtensionHandle _Handle, int32_t Index, TElSSLServerNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElServerNameSSLExtension_get_Count(TElServerNameSSLExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElServerNameSSLExtension_Create(TElServerNameSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSERVERNAMESSLEXTENSION */

#ifdef SB_USE_CLASS_TELUSERNAMESSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElUserNameSSLExtension_Assign(TElUserNameSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElUserNameSSLExtension_get_Name(TElUserNameSSLExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUserNameSSLExtension_set_Name(TElUserNameSSLExtensionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElUserNameSSLExtension_Create(TElUserNameSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELUSERNAMESSLEXTENSION */

#ifdef SB_USE_CLASS_TELECCURVESSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElECCurveSSLExtension_Assign(TElECCurveSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElECCurveSSLExtension_SetCurves(TElECCurveSSLExtensionHandle _Handle, int32_t Curve, int8_t Enabled);
SB_IMPORT uint32_t SB_APIENTRY TElECCurveSSLExtension_IsCurveEnabled(TElECCurveSSLExtensionHandle _Handle, int32_t Curve, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECCurveSSLExtension_GetCurve(TElECCurveSSLExtensionHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECCurveSSLExtension_GetCurveCount(TElECCurveSSLExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECCurveSSLExtension_Create(TElECCurveSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELECCURVESSLEXTENSION */

#ifdef SB_USE_CLASS_TELECPOINTSSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElECPointSSLExtension_Assign(TElECPointSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElECPointSSLExtension_SetPointType(TElECPointSSLExtensionHandle _Handle, uint8_t Point, int8_t Enabled);
SB_IMPORT uint32_t SB_APIENTRY TElECPointSSLExtension_GetPointType(TElECPointSSLExtensionHandle _Handle, uint8_t Point, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElECPointSSLExtension_Create(TElECPointSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELECPOINTSSLEXTENSION */

#ifdef SB_USE_CLASS_TELCERTIFICATETYPERESPONSE
SB_IMPORT uint32_t SB_APIENTRY TElCertificateTypeResponse_Assign(TElCertificateTypeResponseHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateTypeResponse_get_CertType(TElCertificateTypeResponseHandle _Handle, TElSSLCertificateTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateTypeResponse_set_CertType(TElCertificateTypeResponseHandle _Handle, TElSSLCertificateTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateTypeResponse_Create(TElCertificateTypeResponseHandle * OutResult);
#endif /* SB_USE_CLASS_TELCERTIFICATETYPERESPONSE */

#ifdef SB_USE_CLASS_TELCERTIFICATETYPEREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElCertificateTypeRequest_Assign(TElCertificateTypeRequestHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateTypeRequest_AddCertType(TElCertificateTypeRequestHandle _Handle, TElSSLCertificateTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateTypeRequest_DelCertType(TElCertificateTypeRequestHandle _Handle, TElSSLCertificateTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateTypeRequest_GetCertTypesCount(TElCertificateTypeRequestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateTypeRequest_ClearCertTypes(TElCertificateTypeRequestHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateTypeRequest_CheckCertType(TElCertificateTypeRequestHandle _Handle, TElSSLCertificateTypeRaw Value, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateTypeRequest_GetBaseCertType(TElCertificateTypeRequestHandle _Handle, TElSSLCertificateTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateTypeRequest_get_CertTypes(TElCertificateTypeRequestHandle _Handle, int32_t Index, TElSSLCertificateTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateTypeRequest_set_CertTypes(TElCertificateTypeRequestHandle _Handle, int32_t Index, TElSSLCertificateTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateTypeRequest_Create(TElCertificateTypeRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELCERTIFICATETYPEREQUEST */

#ifdef SB_USE_CLASS_TELEXTENDEDMASTERSECRETEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElExtendedMasterSecretExtension_Assign(TElExtendedMasterSecretExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElExtendedMasterSecretExtension_Create(TElExtendedMasterSecretExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELEXTENDEDMASTERSECRETEXTENSION */

#ifdef SB_USE_CLASS_TELMAXFRAGMENTLENGTHSSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElMaxFragmentLengthSSLExtension_Assign(TElMaxFragmentLengthSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElMaxFragmentLengthSSLExtension_Clear(TElMaxFragmentLengthSSLExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElMaxFragmentLengthSSLExtension_get_MaxLength(TElMaxFragmentLengthSSLExtensionHandle _Handle, TSBSSLFragmentLengthRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMaxFragmentLengthSSLExtension_set_MaxLength(TElMaxFragmentLengthSSLExtensionHandle _Handle, TSBSSLFragmentLengthRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElMaxFragmentLengthSSLExtension_Create(TElCustomSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELMAXFRAGMENTLENGTHSSLEXTENSION */

#ifdef SB_USE_CLASS_TELSSLCERTURL
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertURL_get_URL(TElSSLCertURLHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertURL_set_URL(TElSSLCertURLHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertURL_get_Hash(TElSSLCertURLHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertURL_set_Hash(TElSSLCertURLHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertURL_get_PrivateKey(TElSSLCertURLHandle _Handle, TElPublicKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertURL_set_PrivateKey(TElSSLCertURLHandle _Handle, TElPublicKeyMaterialHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLCertURL_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSLCERTURL */

#ifdef SB_USE_CLASS_TELCLIENTCERTURLSSSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElClientCertURLsSSLExtension_Assign(TElClientCertURLsSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElClientCertURLsSSLExtension_Add(TElClientCertURLsSSLExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElClientCertURLsSSLExtension_Remove(TElClientCertURLsSSLExtensionHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElClientCertURLsSSLExtension_Clear(TElClientCertURLsSSLExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElClientCertURLsSSLExtension_get_ChainType(TElClientCertURLsSSLExtensionHandle _Handle, TSBCertChainTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElClientCertURLsSSLExtension_set_ChainType(TElClientCertURLsSSLExtensionHandle _Handle, TSBCertChainTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElClientCertURLsSSLExtension_get_URLs(TElClientCertURLsSSLExtensionHandle _Handle, int32_t Index, TElSSLCertURLHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElClientCertURLsSSLExtension_get_Count(TElClientCertURLsSSLExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElClientCertURLsSSLExtension_Create(TElClientCertURLsSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELCLIENTCERTURLSSSLEXTENSION */

#ifdef SB_USE_CLASS_TELSSLTRUSTEDCA
SB_IMPORT uint32_t SB_APIENTRY TElSSLTrustedCA_Import(TElSSLTrustedCAHandle _Handle, TElX509CertificateHandle Cert);
SB_IMPORT uint32_t SB_APIENTRY TElSSLTrustedCA_get_IdentifierType(TElSSLTrustedCAHandle _Handle, TSBCAIdentifierTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLTrustedCA_set_IdentifierType(TElSSLTrustedCAHandle _Handle, TSBCAIdentifierTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLTrustedCA_get_Value(TElSSLTrustedCAHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLTrustedCA_set_Value(TElSSLTrustedCAHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLTrustedCA_get_RDN(TElSSLTrustedCAHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLTrustedCA_Create(TElSSLTrustedCAHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSLTRUSTEDCA */

#ifdef SB_USE_CLASS_TELTRUSTEDCASSSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElTrustedCAsSSLExtension_Assign(TElTrustedCAsSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElTrustedCAsSSLExtension_Add(TElTrustedCAsSSLExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTrustedCAsSSLExtension_Remove(TElTrustedCAsSSLExtensionHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElTrustedCAsSSLExtension_Clear(TElTrustedCAsSSLExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElTrustedCAsSSLExtension_get_TrustedCAs(TElTrustedCAsSSLExtensionHandle _Handle, int32_t Index, TElSSLTrustedCAHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTrustedCAsSSLExtension_get_Count(TElTrustedCAsSSLExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTrustedCAsSSLExtension_Create(TElTrustedCAsSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELTRUSTEDCASSSLEXTENSION */

#ifdef SB_USE_CLASS_TELTRUNCATEDHMACSSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElTruncatedHMACSSLExtension_Assign(TElTruncatedHMACSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElTruncatedHMACSSLExtension_Create(TElCustomSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELTRUNCATEDHMACSSLEXTENSION */

#ifdef SB_USE_CLASS_TELSSLOCSPSTATUSREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElSSLOCSPStatusRequest_get_ResponderIDs(TElSSLOCSPStatusRequestHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLOCSPStatusRequest_set_ResponderIDs(TElSSLOCSPStatusRequestHandle _Handle, int32_t Index, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLOCSPStatusRequest_get_ResponderIDCount(TElSSLOCSPStatusRequestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLOCSPStatusRequest_set_ResponderIDCount(TElSSLOCSPStatusRequestHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLOCSPStatusRequest_get_Extensions(TElSSLOCSPStatusRequestHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLOCSPStatusRequest_set_Extensions(TElSSLOCSPStatusRequestHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLOCSPStatusRequest_Create(TElSSLOCSPStatusRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSLOCSPSTATUSREQUEST */

#ifdef SB_USE_CLASS_TELCERTIFICATESTATUSSSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_Assign(TElCertificateStatusSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_Clear(TElCertificateStatusSSLExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_AddOCSPStatusRequest(TElCertificateStatusSSLExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_RemoveOCSPStatusRequest(TElCertificateStatusSSLExtensionHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_get_StatusType(TElCertificateStatusSSLExtensionHandle _Handle, TSBCertificateStatusTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_set_StatusType(TElCertificateStatusSSLExtensionHandle _Handle, TSBCertificateStatusTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_get_OCSPStatusRequest(TElCertificateStatusSSLExtensionHandle _Handle, TElSSLOCSPStatusRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_get_OCSPStatusRequests(TElCertificateStatusSSLExtensionHandle _Handle, int32_t Index, TElSSLOCSPStatusRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_get_OCSPStatusRequestCount(TElCertificateStatusSSLExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_get_OCSPResponse(TElCertificateStatusSSLExtensionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_set_OCSPResponse(TElCertificateStatusSSLExtensionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_get_OCSPResponses(TElCertificateStatusSSLExtensionHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_set_OCSPResponses(TElCertificateStatusSSLExtensionHandle _Handle, int32_t Index, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_get_OCSPResponseCount(TElCertificateStatusSSLExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_set_OCSPResponseCount(TElCertificateStatusSSLExtensionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertificateStatusSSLExtension_Create(TElCertificateStatusSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELCERTIFICATESTATUSSSLEXTENSION */

#ifdef SB_USE_CLASS_TELSESSIONTICKETSSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSessionTicketSSLExtension_Assign(TElSessionTicketSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSessionTicketSSLExtension_Clear(TElSessionTicketSSLExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSessionTicketSSLExtension_get_Ticket(TElSessionTicketSSLExtensionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSessionTicketSSLExtension_set_Ticket(TElSessionTicketSSLExtensionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSessionTicketSSLExtension_Create(TElCustomSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSESSIONTICKETSSLEXTENSION */

#ifdef SB_USE_CLASS_TELCERTHASHTYPESSSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElCertHashTypesSSLExtension_Assign(TElCertHashTypesSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElCertHashTypesSSLExtension_Clear(TElCertHashTypesSSLExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCertHashTypesSSLExtension_SwitchAll(TElCertHashTypesSSLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertHashTypesSSLExtension_get_MD5(TElCertHashTypesSSLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertHashTypesSSLExtension_set_MD5(TElCertHashTypesSSLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertHashTypesSSLExtension_get_SHA1(TElCertHashTypesSSLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertHashTypesSSLExtension_set_SHA1(TElCertHashTypesSSLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertHashTypesSSLExtension_get_SHA256(TElCertHashTypesSSLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertHashTypesSSLExtension_set_SHA256(TElCertHashTypesSSLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertHashTypesSSLExtension_get_SHA384(TElCertHashTypesSSLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertHashTypesSSLExtension_set_SHA384(TElCertHashTypesSSLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertHashTypesSSLExtension_get_SHA512(TElCertHashTypesSSLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCertHashTypesSSLExtension_set_SHA512(TElCertHashTypesSSLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCertHashTypesSSLExtension_Create(TElCertHashTypesSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELCERTHASHTYPESSSLEXTENSION */

#ifdef SB_USE_CLASS_TELRENEGOTIATIONINFOSSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElRenegotiationInfoSSLExtension_Assign(TElRenegotiationInfoSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElRenegotiationInfoSSLExtension_Clear(TElRenegotiationInfoSSLExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElRenegotiationInfoSSLExtension_get_Info(TElRenegotiationInfoSSLExtensionHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRenegotiationInfoSSLExtension_set_Info(TElRenegotiationInfoSSLExtensionHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElRenegotiationInfoSSLExtension_get_UseSignalingCipherSuite(TElRenegotiationInfoSSLExtensionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRenegotiationInfoSSLExtension_set_UseSignalingCipherSuite(TElRenegotiationInfoSSLExtensionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElRenegotiationInfoSSLExtension_Create(TElRenegotiationInfoSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELRENEGOTIATIONINFOSSLEXTENSION */

#ifdef SB_USE_CLASS_TELSIGNATUREALGORITHMSSSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSignatureAlgorithmsSSLExtension_Assign(TElSignatureAlgorithmsSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSignatureAlgorithmsSSLExtension_Clear(TElSignatureAlgorithmsSSLExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSignatureAlgorithmsSSLExtension_EnableAllSupported(TElSignatureAlgorithmsSSLExtensionHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSignatureAlgorithmsSSLExtension_get_Count(TElSignatureAlgorithmsSSLExtensionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSignatureAlgorithmsSSLExtension_set_Count(TElSignatureAlgorithmsSSLExtensionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSignatureAlgorithmsSSLExtension_get_HashAlgorithms(TElSignatureAlgorithmsSSLExtensionHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSignatureAlgorithmsSSLExtension_set_HashAlgorithms(TElSignatureAlgorithmsSSLExtensionHandle _Handle, int32_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSignatureAlgorithmsSSLExtension_get_SignatureAlgorithms(TElSignatureAlgorithmsSSLExtensionHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSignatureAlgorithmsSSLExtension_set_SignatureAlgorithms(TElSignatureAlgorithmsSSLExtensionHandle _Handle, int32_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSignatureAlgorithmsSSLExtension_Create(TElCustomSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSIGNATUREALGORITHMSSSLEXTENSION */

#ifdef SB_USE_CLASS_TELSRPSSLEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElSRPSSLExtension_Assign(TElSRPSSLExtensionHandle _Handle, TElCustomSSLExtensionHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElSRPSSLExtension_get_Name(TElSRPSSLExtensionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSRPSSLExtension_set_Name(TElSRPSSLExtensionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSRPSSLExtension_Create(TElSRPSSLExtensionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSRPSSLEXTENSION */

#ifdef SB_USE_CLASS_TELCUSTOMSSLEXTENSIONS
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_Assign(TElCustomSSLExtensionsHandle _Handle, TElCustomSSLExtensionsHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_Clear(TElCustomSSLExtensionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_DisableAll(TElCustomSSLExtensionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_CertificateStatus(TElCustomSSLExtensionsHandle _Handle, TElCertificateStatusSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_ClientCertURLs(TElCustomSSLExtensionsHandle _Handle, TElClientCertURLsSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_MaxFragmentLength(TElCustomSSLExtensionsHandle _Handle, TElMaxFragmentLengthSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_OtherCount(TElCustomSSLExtensionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_set_OtherCount(TElCustomSSLExtensionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_OtherExtensions(TElCustomSSLExtensionsHandle _Handle, int32_t Index, TElCustomSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_ServerName(TElCustomSSLExtensionsHandle _Handle, TElServerNameSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_TruncatedHMAC(TElCustomSSLExtensionsHandle _Handle, TElTruncatedHMACSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_TrustedCAs(TElCustomSSLExtensionsHandle _Handle, TElTrustedCAsSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_UserName(TElCustomSSLExtensionsHandle _Handle, TElUserNameSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_ECCurves(TElCustomSSLExtensionsHandle _Handle, TElECCurveSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_ECPoints(TElCustomSSLExtensionsHandle _Handle, TElECPointSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_StatelessTLS(TElCustomSSLExtensionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_set_StatelessTLS(TElCustomSSLExtensionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_CertHashTypes(TElCustomSSLExtensionsHandle _Handle, TElCertHashTypesSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_RenegotiationInfo(TElCustomSSLExtensionsHandle _Handle, TElRenegotiationInfoSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_set_RenegotiationInfo(TElCustomSSLExtensionsHandle _Handle, TElRenegotiationInfoSSLExtensionHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_Heartbeat(TElCustomSSLExtensionsHandle _Handle, TElHeartbeatHelloSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_SignatureAlgorithms(TElCustomSSLExtensionsHandle _Handle, TElSignatureAlgorithmsSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_SRP(TElCustomSSLExtensionsHandle _Handle, TElSRPSSLExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_get_ExtendedMasterSecret(TElCustomSSLExtensionsHandle _Handle, TElExtendedMasterSecretExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSSLExtensions_Create(TElCustomSSLExtensionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMSSLEXTENSIONS */

#ifdef SB_USE_CLASS_TELCLIENTSSLEXTENSIONS
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLExtensions_Assign(TElClientSSLExtensionsHandle _Handle, TElCustomSSLExtensionsHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLExtensions_Clear(TElClientSSLExtensionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLExtensions_DisableAll(TElClientSSLExtensionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLExtensions_ClearAcceptableCAs(TElClientSSLExtensionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLExtensions_AddAcceptableCAs(TElClientSSLExtensionsHandle _Handle, TElRelativeDistinguishedNameHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLExtensions_get_AcceptableCAs(TElClientSSLExtensionsHandle _Handle, int32_t Index, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLExtensions_get_AcceptableCACount(TElClientSSLExtensionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLExtensions_get_FallbackConnection(TElClientSSLExtensionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLExtensions_set_FallbackConnection(TElClientSSLExtensionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLExtensions_get_ServerCertificateType(TElClientSSLExtensionsHandle _Handle, TElCertificateTypeRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLExtensions_get_ClientCertificateType(TElClientSSLExtensionsHandle _Handle, TElCertificateTypeRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElClientSSLExtensions_Create(TElClientSSLExtensionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELCLIENTSSLEXTENSIONS */

#ifdef SB_USE_CLASS_TELSERVERSSLEXTENSIONS
SB_IMPORT uint32_t SB_APIENTRY TElServerSSLExtensions_Assign(TElServerSSLExtensionsHandle _Handle, TElCustomSSLExtensionsHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElServerSSLExtensions_Clear(TElServerSSLExtensionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElServerSSLExtensions_DisableAll(TElServerSSLExtensionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElServerSSLExtensions_get_StrictCertRequest(TElServerSSLExtensionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElServerSSLExtensions_set_StrictCertRequest(TElServerSSLExtensionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElServerSSLExtensions_get_PSKIdentityHint(TElServerSSLExtensionsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElServerSSLExtensions_set_PSKIdentityHint(TElServerSSLExtensionsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElServerSSLExtensions_get_ServerCertificateType(TElServerSSLExtensionsHandle _Handle, TElCertificateTypeResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElServerSSLExtensions_get_ClientCertificateType(TElServerSSLExtensionsHandle _Handle, TElCertificateTypeResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElServerSSLExtensions_Create(TElServerSSLExtensionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELSERVERSSLEXTENSIONS */

#ifdef SB_USE_CLASS_TELSSLRETRANSMISSIONTIMER
SB_IMPORT uint32_t SB_APIENTRY TElSSLRetransmissionTimer_Start(TElSSLRetransmissionTimerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSLRetransmissionTimer_Stop(TElSSLRetransmissionTimerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSSLRetransmissionTimer_get_Interval(TElSSLRetransmissionTimerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLRetransmissionTimer_set_Interval(TElSSLRetransmissionTimerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSSLRetransmissionTimer_get_Enabled(TElSSLRetransmissionTimerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLRetransmissionTimer_get_OnTimer(TElSSLRetransmissionTimerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLRetransmissionTimer_set_OnTimer(TElSSLRetransmissionTimerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSSLRetransmissionTimer_Create(TElSSLRetransmissionTimerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSLRETRANSMISSIONTIMER */

#ifdef SB_USE_CLASS_TELSSLX509CERTIFICATETYPEHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElSSLX509CertificateTypeHandler_GetCertificateType(TElSSLX509CertificateTypeHandlerHandle _Handle, TElSSLCertificateTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLX509CertificateTypeHandler_GetDataForRemote(TElSSLX509CertificateTypeHandlerHandle _Handle, int32_t CipherSuite, TSBKeyExchangeAlgorithmRaw KeyExchange, uint8_t pData[], int32_t * szData, int32_t Optional, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLX509CertificateTypeHandler_ValidateRemoteCert(TElSSLX509CertificateTypeHandlerHandle _Handle, const uint8_t pData[], int32_t szData, int32_t Optional, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLX509CertificateTypeHandler_GetRemoteKeyMaterial(TElSSLX509CertificateTypeHandlerHandle _Handle, const uint8_t pData[], int32_t szData, int32_t KeyType, int32_t * PKType, int32_t * KeyAlgorithm, TElKeyMaterialHandle * KeyMaterial);
SB_IMPORT uint32_t SB_APIENTRY TElSSLX509CertificateTypeHandler_GetKeyMaterial(TElSSLX509CertificateTypeHandlerHandle _Handle, TElKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLX509CertificateTypeHandler_GetPublicKeySize(TElSSLX509CertificateTypeHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLX509CertificateTypeHandler_GetPublicKeyAlgorithm(TElSSLX509CertificateTypeHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLX509CertificateTypeHandler_Create(TComponentHandle AOwner, TComponentHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSLX509CERTIFICATETYPEHANDLER */

#ifdef SB_USE_CLASS_TELSSLRAWKEYCERTIFICATETYPEHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElSSLRawKeyCertificateTypeHandler_GetCertificateType(TElSSLRawKeyCertificateTypeHandlerHandle _Handle, TElSSLCertificateTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLRawKeyCertificateTypeHandler_GetDataForRemote(TElSSLRawKeyCertificateTypeHandlerHandle _Handle, int32_t CipherSuite, TSBKeyExchangeAlgorithmRaw KeyExchange, uint8_t pData[], int32_t * szData, int32_t Optional, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLRawKeyCertificateTypeHandler_ValidateRemoteCert(TElSSLRawKeyCertificateTypeHandlerHandle _Handle, const uint8_t pData[], int32_t szData, int32_t Optional, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLRawKeyCertificateTypeHandler_GetRemoteKeyMaterial(TElSSLRawKeyCertificateTypeHandlerHandle _Handle, const uint8_t pData[], int32_t szData, int32_t KeyType, int32_t * PKType, int32_t * KeyAlgorithm, TElKeyMaterialHandle * KeyMaterial);
SB_IMPORT uint32_t SB_APIENTRY TElSSLRawKeyCertificateTypeHandler_GetKeyMaterial(TElSSLRawKeyCertificateTypeHandlerHandle _Handle, TElKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLRawKeyCertificateTypeHandler_GetPublicKeySize(TElSSLRawKeyCertificateTypeHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLRawKeyCertificateTypeHandler_GetPublicKeyAlgorithm(TElSSLRawKeyCertificateTypeHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSSLRawKeyCertificateTypeHandler_Create(TComponentHandle AOwner, TComponentHandle * OutResult);
#endif /* SB_USE_CLASS_TELSSLRAWKEYCERTIFICATETYPEHANDLER */

#ifdef SB_USE_CLASS_TELDTLSFLIGHTITEM
SB_IMPORT uint32_t SB_APIENTRY TElDTLSFlightItem_get_Epoch(TElDTLSFlightItemHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSFlightItem_get_ContentType(TElDTLSFlightItemHandle _Handle, TSSL3ContentTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSFlightItem_get_Data(TElDTLSFlightItemHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSFlightItem_get_Length(TElDTLSFlightItemHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSFlightItem_get_MessageSeq(TElDTLSFlightItemHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSFlightItem_get_FragmentOffset(TElDTLSFlightItemHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSFlightItem_get_FragmentLength(TElDTLSFlightItemHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSFlightItem_get_HandshakeType(TElDTLSFlightItemHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSFlightItem_Create(TSSL3ContentTypeRaw ContentType, void * Header, int32_t HeaderLen, void * Data, int32_t DataLen, int32_t Epoch, TElDTLSFlightItemHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSFlightItem_Create_1(int32_t HandshakeType, int32_t Len, int32_t MessageSeq, int32_t FragmentOffset, int32_t FragmentLength, void * Fragment, TElDTLSFlightItemHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDTLSFlightItem_CreateChangeCipherSpec(TElDTLSFlightItemHandle * OutResult);
#endif /* SB_USE_CLASS_TELDTLSFLIGHTITEM */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *IElSSLCertificateHandlerContainer_ce_ptr;
extern zend_class_entry *TElSSLCertificateTypeHandler_ce_ptr;
extern zend_class_entry *TElCustomSSLExtension_ce_ptr;
extern zend_class_entry *TElSSLClass_ce_ptr;
extern zend_class_entry *TElSSLConnectionInfo_ce_ptr;
extern zend_class_entry *TElSSLServerName_ce_ptr;
extern zend_class_entry *TElHeartbeatHelloSSLExtension_ce_ptr;
extern zend_class_entry *TElServerNameSSLExtension_ce_ptr;
extern zend_class_entry *TElUserNameSSLExtension_ce_ptr;
extern zend_class_entry *TElECCurveSSLExtension_ce_ptr;
extern zend_class_entry *TElECPointSSLExtension_ce_ptr;
extern zend_class_entry *TElCertificateTypeResponse_ce_ptr;
extern zend_class_entry *TElCertificateTypeRequest_ce_ptr;
extern zend_class_entry *TElExtendedMasterSecretExtension_ce_ptr;
extern zend_class_entry *TElMaxFragmentLengthSSLExtension_ce_ptr;
extern zend_class_entry *TElSSLCertURL_ce_ptr;
extern zend_class_entry *TElClientCertURLsSSLExtension_ce_ptr;
extern zend_class_entry *TElSSLTrustedCA_ce_ptr;
extern zend_class_entry *TElTrustedCAsSSLExtension_ce_ptr;
extern zend_class_entry *TElTruncatedHMACSSLExtension_ce_ptr;
extern zend_class_entry *TElSSLOCSPStatusRequest_ce_ptr;
extern zend_class_entry *TElCertificateStatusSSLExtension_ce_ptr;
extern zend_class_entry *TElSessionTicketSSLExtension_ce_ptr;
extern zend_class_entry *TElCertHashTypesSSLExtension_ce_ptr;
extern zend_class_entry *TElRenegotiationInfoSSLExtension_ce_ptr;
extern zend_class_entry *TElSignatureAlgorithmsSSLExtension_ce_ptr;
extern zend_class_entry *TElSRPSSLExtension_ce_ptr;
extern zend_class_entry *TElCustomSSLExtensions_ce_ptr;
extern zend_class_entry *TElClientSSLExtensions_ce_ptr;
extern zend_class_entry *TElServerSSLExtensions_ce_ptr;
extern zend_class_entry *TElSSLRetransmissionTimer_ce_ptr;
extern zend_class_entry *TElSSLX509CertificateTypeHandler_ce_ptr;
extern zend_class_entry *TElSSLRawKeyCertificateTypeHandler_ce_ptr;
extern zend_class_entry *TElDTLSFlightItem_ce_ptr;

void SB_CALLBACK TSBDataEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);
void SB_CALLBACK TSBReceiveEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t MaxSize, int32_t * Written);
void SB_CALLBACK TSBSendEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size);
void SB_CALLBACK TSBOpenConnectionEventRaw(void * _ObjectData, TObjectHandle Sender);
void SB_CALLBACK TSBCloseConnectionEventRaw(void * _ObjectData, TObjectHandle Sender, TSBCloseReasonRaw CloseReason);
void SB_CALLBACK TSBRenegotiationStartEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t Safe, int8_t * Allow);
void SB_CALLBACK TSBRenegotiationRequestEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t * Allow);
void SB_CALLBACK TSBErrorEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode, int8_t Fatal, int8_t Remote);
void SB_CALLBACK TSBExtensionsReceivedEventRaw(void * _ObjectData, TObjectHandle Sender);
void SB_CALLBACK TSBExtensionsPreparedEventRaw(void * _ObjectData, TObjectHandle Sender);
void Register_TElSSLCertificateTypeHandler(TSRMLS_D);
void Register_TElCustomSSLExtension(TSRMLS_D);
void Register_TElSSLClass(TSRMLS_D);
void Register_TElSSLConnectionInfo(TSRMLS_D);
void Register_TElSSLServerName(TSRMLS_D);
void Register_TElHeartbeatHelloSSLExtension(TSRMLS_D);
void Register_TElServerNameSSLExtension(TSRMLS_D);
void Register_TElUserNameSSLExtension(TSRMLS_D);
void Register_TElECCurveSSLExtension(TSRMLS_D);
void Register_TElECPointSSLExtension(TSRMLS_D);
void Register_TElCertificateTypeResponse(TSRMLS_D);
void Register_TElCertificateTypeRequest(TSRMLS_D);
void Register_TElExtendedMasterSecretExtension(TSRMLS_D);
void Register_TElMaxFragmentLengthSSLExtension(TSRMLS_D);
void Register_TElSSLCertURL(TSRMLS_D);
void Register_TElClientCertURLsSSLExtension(TSRMLS_D);
void Register_TElSSLTrustedCA(TSRMLS_D);
void Register_TElTrustedCAsSSLExtension(TSRMLS_D);
void Register_TElTruncatedHMACSSLExtension(TSRMLS_D);
void Register_TElSSLOCSPStatusRequest(TSRMLS_D);
void Register_TElCertificateStatusSSLExtension(TSRMLS_D);
void Register_TElSessionTicketSSLExtension(TSRMLS_D);
void Register_TElCertHashTypesSSLExtension(TSRMLS_D);
void Register_TElRenegotiationInfoSSLExtension(TSRMLS_D);
void Register_TElSignatureAlgorithmsSSLExtension(TSRMLS_D);
void Register_TElSRPSSLExtension(TSRMLS_D);
void Register_TElCustomSSLExtensions(TSRMLS_D);
void Register_TElClientSSLExtensions(TSRMLS_D);
void Register_TElServerSSLExtensions(TSRMLS_D);
void Register_TElSSLRetransmissionTimer(TSRMLS_D);
void Register_TElSSLX509CertificateTypeHandler(TSRMLS_D);
void Register_TElSSLRawKeyCertificateTypeHandler(TSRMLS_D);
void Register_TElDTLSFlightItem(TSRMLS_D);
SB_PHP_FUNCTION(SBSSLCommon, ConvertAlertDescriptionToErrorCode);
SB_PHP_FUNCTION(SBSSLCommon, ConvertSSLError);
SB_PHP_FUNCTION(SBSSLCommon, GetAlertDescriptionFromValidityReason);
SB_PHP_FUNCTION(SBSSLCommon, GetSecondsCount);
SB_PHP_FUNCTION(SBSSLCommon, GetCurveByTlsCurve);
SB_PHP_FUNCTION(SBSSLCommon, GetTlsCurveByCurve);
SB_PHP_FUNCTION(SBSSLCommon, ReadLengthPrefixedArray);
SB_PHP_FUNCTION(SBSSLCommon, SSLMemoryManager);
void Register_SBSSLCommon_Constants(int module_number TSRMLS_DC);
void Register_SBSSLCommon_Enum_Flags(TSRMLS_D);
void Register_SBSSLCommon_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_SSLCOMMON
SB_IMPORT uint32_t SB_APIENTRY SBSSLCommon_ConvertAlertDescriptionToErrorCode(TSBAlertDescriptionRaw Desc, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSSLCommon_ConvertSSLError(uint8_t AD, TSBAlertDescriptionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSSLCommon_GetAlertDescriptionFromValidityReason(TSBCertificateValidityReasonRaw Reason, TSBAlertDescriptionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSSLCommon_GetSecondsCount(uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSSLCommon_GetCurveByTlsCurve(int32_t Curve, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSSLCommon_GetTlsCurveByCurve(int32_t Curve, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSSLCommon_ReadLengthPrefixedArray(void * ABuffer, int32_t ASize, int32_t ALenBytes, int32_t * BytesRead, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBSSLCommon_SSLMemoryManager(TElByteArrayManagerHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_SSLCOMMON */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSSLCOMMON */

