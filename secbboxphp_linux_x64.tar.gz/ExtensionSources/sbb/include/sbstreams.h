#ifndef __INC_SBSTREAMS
#define __INC_SBSTREAMS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TStreamHandle TElStreamHandle;

typedef TMemoryStreamHandle TElMemoryStreamHandle;

typedef TStreamHandle SBStreams_TElNativeStreamHandle;

typedef TElClassHandle TElFileStreamHandle;

typedef TElClassHandle TElDataStreamHandle;

typedef TElClassHandle TElMultiStreamHandle;

typedef TElClassHandle TElReadCachingStreamHandle;

typedef TElClassHandle TElWriteCachingStreamHandle;

#ifdef SB_USE_CLASS_TELFILESTREAM
SB_IMPORT uint32_t SB_APIENTRY TElFileStream_get_Position64(TElFileStreamHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileStream_set_Position64(TElFileStreamHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElFileStream_get_Size64(TElFileStreamHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileStream_set_Size64(TElFileStreamHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElFileStream_Create(const char * pcAFileName, int32_t szAFileName, uint16_t Mode, TFileStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileStream_Create_1(const char * pcAFileName, int32_t szAFileName, uint16_t Mode, uint32_t Rights, TFileStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELFILESTREAM */

#ifdef SB_USE_CLASS_TELDATASTREAM
SB_IMPORT uint32_t SB_APIENTRY TElDataStream_get_Start(TElDataStreamHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDataStream_get_Stream(TElDataStreamHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDataStream_set_Stream(TElDataStreamHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDataStream_get_FreeOnSent(TElDataStreamHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDataStream_set_FreeOnSent(TElDataStreamHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDataStream_Create(TStreamHandle LStream, int8_t LFreeOnSent, TElDataStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDataStream_Create_1(const uint8_t pBuffer[], int32_t szBuffer, TElDataStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELDATASTREAM */

#ifdef SB_USE_CLASS_TELMULTISTREAM
SB_IMPORT uint32_t SB_APIENTRY TElMultiStream_AddStream(TElMultiStreamHandle _Handle, TStreamHandle AStream, int8_t FreeStream, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultiStream_Read(TElMultiStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultiStream_Write(TElMultiStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultiStream_Seek(TElMultiStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultiStream_Seek_1(TElMultiStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultiStream_Create(TElMultiStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELMULTISTREAM */

#ifdef SB_USE_CLASS_TELREADCACHINGSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElReadCachingStream_Read(TElReadCachingStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElReadCachingStream_Write(TElReadCachingStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElReadCachingStream_Seek(TElReadCachingStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElReadCachingStream_Seek_1(TElReadCachingStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElReadCachingStream_get_Stream(TElReadCachingStreamHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElReadCachingStream_set_Stream(TElReadCachingStreamHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElReadCachingStream_get_CacheSize(TElReadCachingStreamHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElReadCachingStream_set_CacheSize(TElReadCachingStreamHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElReadCachingStream_Create(TElReadCachingStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELREADCACHINGSTREAM */

#ifdef SB_USE_CLASS_TELWRITECACHINGSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElWriteCachingStream_Read(TElWriteCachingStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWriteCachingStream_Write(TElWriteCachingStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWriteCachingStream_Seek(TElWriteCachingStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWriteCachingStream_Seek_1(TElWriteCachingStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWriteCachingStream_Flush(TElWriteCachingStreamHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWriteCachingStream_get_Stream(TElWriteCachingStreamHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWriteCachingStream_set_Stream(TElWriteCachingStreamHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWriteCachingStream_get_CacheSize(TElWriteCachingStreamHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWriteCachingStream_set_CacheSize(TElWriteCachingStreamHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWriteCachingStream_Create(TElWriteCachingStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELWRITECACHINGSTREAM */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElFileStream_ce_ptr;
extern zend_class_entry *TElDataStream_ce_ptr;
extern zend_class_entry *TElMultiStream_ce_ptr;
extern zend_class_entry *TElReadCachingStream_ce_ptr;
extern zend_class_entry *TElWriteCachingStream_ce_ptr;

void Register_TElFileStream(TSRMLS_D);
void Register_TElDataStream(TSRMLS_D);
void Register_TElMultiStream(TSRMLS_D);
void Register_TElReadCachingStream(TSRMLS_D);
void Register_TElWriteCachingStream(TSRMLS_D);
SB_PHP_FUNCTION(SBStreams, CopyStream);
SB_PHP_FUNCTION(SBStreams, StreamPosition);
SB_PHP_FUNCTION(SBStreams, StreamSize);
SB_PHP_FUNCTION(SBStreams, SetStreamPosition);
SB_PHP_FUNCTION(SBStreams, StreamSetPosition);
SB_PHP_FUNCTION(SBStreams, StreamSkip);
SB_PHP_FUNCTION(SBStreams, StreamRewind);
SB_PHP_FUNCTION(SBStreams, StreamRead);
SB_PHP_FUNCTION(SBStreams, StreamReadAll);
SB_PHP_FUNCTION(SBStreams, StreamReadByte);
SB_PHP_FUNCTION(SBStreams, StreamWrite);
SB_PHP_FUNCTION(SBStreams, StreamWriteLn);
SB_PHP_FUNCTION(SBStreams, StreamClear);
void Register_SBStreams_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_STREAMS
SB_IMPORT uint32_t SB_APIENTRY SBStreams_CopyStream(TStreamHandle SrcStream, TStreamHandle DestStream, int64_t Offset, int64_t Count, int8_t PreservePosition, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_CopyStream_1(TStreamHandle Source, TStreamHandle Dest, int64_t Offset, int64_t Count, int8_t PreservePosition, TSBProgressEvent pMethodProgressEvent, void * pDataProgressEvent, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_StreamPosition(TStreamHandle Stream, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_StreamSize(TStreamHandle Stream, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_SetStreamPosition(TStreamHandle Stream, int64_t Position);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_StreamSetPosition(TStreamHandle Stream, int64_t NewPosition);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_StreamSkip(TStreamHandle Stream, int64_t Count);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_StreamRewind(TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_StreamRead(TStreamHandle Stream, uint8_t pBuffer[], int32_t * szBuffer, int32_t Offset, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_StreamReadAll(TStreamHandle Stream, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_StreamReadByte(TStreamHandle Stream, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_StreamWrite(TStreamHandle Stream, const uint8_t pBuffer[], int32_t szBuffer);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_StreamWrite_1(TStreamHandle Stream, const uint8_t pBuffer[], int32_t szBuffer, int32_t Offset, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_StreamWrite_2(TStreamHandle Stream, const void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_StreamWriteLn(TStreamHandle Stream, const char * pcText, int32_t szText);
SB_IMPORT uint32_t SB_APIENTRY SBStreams_StreamClear(TStreamHandle Stream);
#endif /* SB_USE_GLOBAL_PROCS_STREAMS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSTREAMS */

