#ifndef __INC_SBSTRINGLIST
#define __INC_SBSTRINGLIST

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElStringListHandle ElStringListHandle;

typedef TElClassHandle TElStringTokenizerHandle;

typedef uint8_t TSBTokenizerModeRaw;

typedef enum
{
	tAll = 0,
	tNext = 1,
	tRest = 2
} TSBTokenizerMode;

#ifdef SB_USE_CLASS_TELSTRINGTOKENIZER
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_GetAll(TElStringTokenizerHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_GetAll_1(TElStringTokenizerHandle _Handle, TElStringListHandle ResultList);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_GetNext(TElStringTokenizerHandle _Handle, char * pcValue, int32_t * szValue, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_GetRest(TElStringTokenizerHandle _Handle, char * pcValue, int32_t * szValue, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_Reset(TElStringTokenizerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_get_ClosingQuote(TElStringTokenizerHandle _Handle, char * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_set_ClosingQuote(TElStringTokenizerHandle _Handle, char Value);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_get_ReturnEmptyTokens(TElStringTokenizerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_set_ReturnEmptyTokens(TElStringTokenizerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_get_Delimiters(TElStringTokenizerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_set_Delimiters(TElStringTokenizerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_get_EscapeChar(TElStringTokenizerHandle _Handle, char * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_set_EscapeChar(TElStringTokenizerHandle _Handle, char Value);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_get_OpeningQuote(TElStringTokenizerHandle _Handle, char * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_set_OpeningQuote(TElStringTokenizerHandle _Handle, char Value);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_get_SourceString(TElStringTokenizerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_set_SourceString(TElStringTokenizerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_get_TrimQuotes(TElStringTokenizerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_set_TrimQuotes(TElStringTokenizerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_get_TrimSpaces(TElStringTokenizerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_set_TrimSpaces(TElStringTokenizerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_Create(TElStringTokenizerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringTokenizer_Create_1(const char * pcSource, int32_t szSource, TElStringTokenizerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSTRINGTOKENIZER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElStringTokenizer_ce_ptr;

void Register_TElStringTokenizer(TSRMLS_D);
void Register_SBStringList_Enum_Flags(TSRMLS_D);
void Register_SBStringList_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSTRINGLIST */

