#ifndef __INC_SBSTRUTILS
#define __INC_SBSTRUTILS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_CP_UTF8 	65001

typedef TElClassHandle TElStringConverterHandle;

#ifdef SB_WINDOWS
typedef TElClassHandle TElPlatformStringConverterHandle;
#endif

#ifdef SB_USE_CLASS_TELSTRINGCONVERTER
SB_IMPORT uint32_t SB_APIENTRY TElStringConverter_StrToUtf8(TElStringConverterHandle _Handle, const char * pcSource, int32_t szSource, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringConverter_Utf8ToStr(TElStringConverterHandle _Handle, const uint8_t pSource[], int32_t szSource, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringConverter_StrToWideStr(TElStringConverterHandle _Handle, const char * pcSource, int32_t szSource, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringConverter_WideStrToStr(TElStringConverterHandle _Handle, const uint8_t pSource[], int32_t szSource, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringConverter_get_DefCharset(TElStringConverterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringConverter_set_DefCharset(TElStringConverterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElStringConverter_Create(TElStringConverterHandle * OutResult);
#endif /* SB_USE_CLASS_TELSTRINGCONVERTER */

#ifdef SB_WINDOWS
#ifdef SB_USE_CLASS_TELPLATFORMSTRINGCONVERTER
SB_IMPORT uint32_t SB_APIENTRY TElPlatformStringConverter_StrToUtf8(TElPlatformStringConverterHandle _Handle, const char * pcSource, int32_t szSource, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPlatformStringConverter_Utf8ToStr(TElPlatformStringConverterHandle _Handle, const uint8_t pSource[], int32_t szSource, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPlatformStringConverter_StrToWideStr(TElPlatformStringConverterHandle _Handle, const char * pcSource, int32_t szSource, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPlatformStringConverter_WideStrToStr(TElPlatformStringConverterHandle _Handle, const uint8_t pSource[], int32_t szSource, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPlatformStringConverter_EncodeStr(TElPlatformStringConverterHandle _Handle, const char * pcSource, int32_t szSource, int32_t Encoding, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPlatformStringConverter_EncodeStr_1(TElPlatformStringConverterHandle _Handle, const char * pcSource, int32_t szSource, const char * pcEncoding, int32_t szEncoding, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPlatformStringConverter_DecodeStr(TElPlatformStringConverterHandle _Handle, const uint8_t pSource[], int32_t szSource, int32_t Encoding, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPlatformStringConverter_DecodeStr_1(TElPlatformStringConverterHandle _Handle, const uint8_t pSource[], int32_t szSource, const char * pcEncoding, int32_t szEncoding, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPlatformStringConverter_Create(TElPlatformStringConverterHandle * OutResult);
#endif /* SB_USE_CLASS_TELPLATFORMSTRINGCONVERTER */
#endif

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElStringConverter_ce_ptr;
#ifdef SB_WINDOWS
extern zend_class_entry *TElPlatformStringConverter_ce_ptr;
#endif

void Register_TElStringConverter(TSRMLS_D);
#ifdef SB_WINDOWS
void Register_TElPlatformStringConverter(TSRMLS_D);
#endif
SB_PHP_FUNCTION(SBStrUtils, StringEndsWith);
SB_PHP_FUNCTION(SBStrUtils, StringEquals);
SB_PHP_FUNCTION(SBStrUtils, StringIndexOf);
SB_PHP_FUNCTION(SBStrUtils, StringIndexOfU);
SB_PHP_FUNCTION(SBStrUtils, StringInsert);
SB_PHP_FUNCTION(SBStrUtils, StringIsEmpty);
SB_PHP_FUNCTION(SBStrUtils, StringLastIndexOf);
SB_PHP_FUNCTION(SBStrUtils, StringRemove);
SB_PHP_FUNCTION(SBStrUtils, WideStringRemove);
SB_PHP_FUNCTION(SBStrUtils, AnsiStringRemove);
SB_PHP_FUNCTION(SBStrUtils, StringToLower);
SB_PHP_FUNCTION(SBStrUtils, StringToLowerInvariant);
SB_PHP_FUNCTION(SBStrUtils, StringStartsWith);
SB_PHP_FUNCTION(SBStrUtils, StringSubstring);
SB_PHP_FUNCTION(SBStrUtils, StringCopy);
SB_PHP_FUNCTION(SBStrUtils, StringTrim);
SB_PHP_FUNCTION(SBStrUtils, StringTrimEnd);
SB_PHP_FUNCTION(SBStrUtils, StringTrimStart);
SB_PHP_FUNCTION(SBStrUtils, StringToUpper);
SB_PHP_FUNCTION(SBStrUtils, StringToUpperInvariant);
SB_PHP_FUNCTION(SBStrUtils, StringSplit);
SB_PHP_FUNCTION(SBStrUtils, StringSplitPV);
SB_PHP_FUNCTION(SBStrUtils, StringPadLeft);
SB_PHP_FUNCTION(SBStrUtils, StringPadRight);
SB_PHP_FUNCTION(SBStrUtils, StrToDefEncoding);
SB_PHP_FUNCTION(SBStrUtils, DefEncodingToStr);
SB_PHP_FUNCTION(SBStrUtils, StrToStdEncoding);
SB_PHP_FUNCTION(SBStrUtils, StdEncodingToStr);
SB_PHP_FUNCTION(SBStrUtils, SBExtractFilePath);
SB_PHP_FUNCTION(SBStrUtils, SBExtractFileName);
SB_PHP_FUNCTION(SBStrUtils, SBExtractFileExt);
SB_PHP_FUNCTION(SBStrUtils, ReplaceExt);
SB_PHP_FUNCTION(SBStrUtils, FilenameMatchesMask);
SB_PHP_FUNCTION(SBStrUtils, DomainNameMatchesCertSN);
SB_PHP_FUNCTION(SBStrUtils, CountFoldersInPath);
SB_PHP_FUNCTION(SBStrUtils, ParseURL);
SB_PHP_FUNCTION(SBStrUtils, ComposeURL);
SB_PHP_FUNCTION(SBStrUtils, SBRightPos);
SB_PHP_FUNCTION(SBStrUtils, SBPos);
SB_PHP_FUNCTION(SBStrUtils, SBCopy);
SB_PHP_FUNCTION(SBStrUtils, SBConcatAnsiStrings);
SB_PHP_FUNCTION(SBStrUtils, OIDToStr);
SB_PHP_FUNCTION(SBStrUtils, StrToOID);
SB_PHP_FUNCTION(SBStrUtils, StrToUTF8);
SB_PHP_FUNCTION(SBStrUtils, UTF8ToStr);
SB_PHP_FUNCTION(SBStrUtils, StrToWideStr);
SB_PHP_FUNCTION(SBStrUtils, WideStrToStr);
SB_PHP_FUNCTION(SBStrUtils, EncodeString);
SB_PHP_FUNCTION(SBStrUtils, DecodeString);
SB_PHP_FUNCTION(SBStrUtils, UnicodeChangeEndianness);
SB_PHP_FUNCTION(SBStrUtils, WideStrToUTF8);
SB_PHP_FUNCTION(SBStrUtils, UTF8ToWideStr);
SB_PHP_FUNCTION(SBStrUtils, ConvertUTF16toUTF8);
SB_PHP_FUNCTION(SBStrUtils, isLegalUTF8);
SB_PHP_FUNCTION(SBStrUtils, ConvertUTF8toUTF16);
SB_PHP_FUNCTION(SBStrUtils, ConvertFromUTF8String);
SB_PHP_FUNCTION(SBStrUtils, ConvertToUTF8String);
SB_PHP_FUNCTION(SBStrUtils, ConvertFromUTF32String);
SB_PHP_FUNCTION(SBStrUtils, SetGlobalStringConverter);
SB_PHP_FUNCTION(SBStrUtils, SetDefaultCharset);
SB_PHP_FUNCTION(SBStrUtils, StrMixToInt64);
SB_PHP_FUNCTION(SBStrUtils, SBTrim);
SB_PHP_FUNCTION(SBStrUtils, SBUppercase);
SB_PHP_FUNCTION(SBStrUtils, StringReplace);
SB_PHP_FUNCTION(SBStrUtils, PrefixString);
SB_PHP_FUNCTION(SBStrUtils, SuffixString);
SB_PHP_FUNCTION(SBStrUtils, PathFirstComponent);
SB_PHP_FUNCTION(SBStrUtils, PathLastComponent);
SB_PHP_FUNCTION(SBStrUtils, PathCutFirstComponent);
SB_PHP_FUNCTION(SBStrUtils, PathCutLastComponent);
SB_PHP_FUNCTION(SBStrUtils, PathIsDirectory);
SB_PHP_FUNCTION(SBStrUtils, PathTrim);
SB_PHP_FUNCTION(SBStrUtils, PathConcatenate);
SB_PHP_FUNCTION(SBStrUtils, PathNormalizeSlashes);
SB_PHP_FUNCTION(SBStrUtils, PathReverseSlashes);
SB_PHP_FUNCTION(SBStrUtils, PathMatchesMask);
SB_PHP_FUNCTION(SBStrUtils, IsFileMask);
SB_PHP_FUNCTION(SBStrUtils, ExtractPathFromMask);
SB_PHP_FUNCTION(SBStrUtils, SftpNormalizePath);
SB_PHP_FUNCTION(SBStrUtils, ZipPathFirstComponent);
SB_PHP_FUNCTION(SBStrUtils, ZipPathLastComponent);
SB_PHP_FUNCTION(SBStrUtils, ZipPathCutFirstComponent);
SB_PHP_FUNCTION(SBStrUtils, ZipPathCutLastComponent);
SB_PHP_FUNCTION(SBStrUtils, ZipPathIsDirectory);
SB_PHP_FUNCTION(SBStrUtils, ZipPathTrim);
SB_PHP_FUNCTION(SBStrUtils, ZipPathConcatenate);
SB_PHP_FUNCTION(SBStrUtils, ZipPathNormalizeSlashes);
SB_PHP_FUNCTION(SBStrUtils, ZipPathReverseSlashes);
SB_PHP_FUNCTION(SBStrUtils, ZipPathMatchesMask);
SB_PHP_FUNCTION(SBStrUtils, ZipIsFileMask);
SB_PHP_FUNCTION(SBStrUtils, ZipExtractPathFromMask);
SB_PHP_FUNCTION(SBStrUtils, PosExSafe);
SB_PHP_FUNCTION(SBStrUtils, PosLast);
SB_PHP_FUNCTION(SBStrUtils, WidePosEx);
SB_PHP_FUNCTION(SBStrUtils, WidePosLast);
SB_PHP_FUNCTION(SBStrUtils, WideStringToByteString);
SB_PHP_FUNCTION(SBStrUtils, AnsiStringToByteWideString);
SB_PHP_FUNCTION(SBStrUtils, IntToStrPadLeft);
SB_PHP_FUNCTION(SBStrUtils, GetWideBytesOf);
SB_PHP_FUNCTION(SBStrUtils, GetStringOf);
SB_PHP_FUNCTION(SBStrUtils, GetStringOfEx);
SB_PHP_FUNCTION(SBStrUtils, GetWideStringOf);
SB_PHP_FUNCTION(SBStrUtils, TrimEx);
SB_PHP_FUNCTION(SBStrUtils, TrimSemicolon);
SB_PHP_FUNCTION(SBStrUtils, ExtractWideFileName);
SB_PHP_FUNCTION(SBStrUtils, ExtractFileExtension);
SB_PHP_FUNCTION(SBStrUtils, ExtractWideFileExtension);
SB_PHP_FUNCTION(SBStrUtils, WideTrimRight);
SB_PHP_FUNCTION(SBStrUtils, DecodeDateTime);
SB_PHP_FUNCTION(SBStrUtils, SBDecStr2ToIntDef);
SB_PHP_FUNCTION(SBStrUtils, SBDecStr3ToIntDef);
SB_PHP_FUNCTION(SBStrUtils, SBDecStr4ToIntDef);
SB_PHP_FUNCTION(SBStrUtils, SBLength);
SB_PHP_FUNCTION(SBStrUtils, SBStringZToString);
void Register_SBStrUtils_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_STRUTILS
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringEndsWith(const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringEndsWith_1(const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int8_t IgnoreCase, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringEquals(const char * pcS1, int32_t szS1, const char * pcS2, int32_t szS2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringEquals_1(const char * pcS1, int32_t szS1, const char * pcS2, int32_t szS2, int8_t IgnoreCase, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringEquals_2(const char * pcS1, int32_t szS1, const char * pcS2, int32_t szS2, int32_t MaxLength, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringEquals_3(const char * pcS1, int32_t szS1, const char * pcS2, int32_t szS2, int32_t MaxLength, int8_t IgnoreCase, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringEquals_4(const char * pcS1, int32_t szS1, int32_t Index1, const char * pcS2, int32_t szS2, int32_t Index2, int32_t MaxLength, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringEquals_5(const char * pcS1, int32_t szS1, int32_t Index1, const char * pcS2, int32_t szS2, int32_t Index2, int32_t MaxLength, int8_t IgnoreCase, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringIndexOf(const char * pcS, int32_t szS, char C, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringIndexOf_1(const char * pcS, int32_t szS, char C, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringIndexOf_2(const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringIndexOf_3(const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringIndexOfU(const char * pcS, int32_t szS, const char * pcC, int32_t szC, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringInsert(const char * pcS, int32_t szS, int32_t Index, const char * pcC, int32_t szC, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringInsert_1(const char * pcS, int32_t szS, int32_t Index, const char * pcSubS, int32_t szSubS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringInsert_2(const char * pcS, int32_t szS, int32_t Index, char C, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringInsert_3(const char * pcS, int32_t szS, int32_t Index, const char * pcSubS, int32_t szSubS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringIsEmpty(const char * pcS, int32_t szS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringLastIndexOf(const char * pcS, int32_t szS, const char * pcC, int32_t szC, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringLastIndexOf_1(const char * pcS, int32_t szS, const char * pcC, int32_t szC, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringLastIndexOf_2(const char * pcS, int32_t szS, char C, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringLastIndexOf_3(const char * pcS, int32_t szS, char C, int32_t StartIndex, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringRemove(const char * pcS, int32_t szS, int32_t StartIndex, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringRemove_1(const char * pcS, int32_t szS, int32_t StartIndex, int32_t Count, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_WideStringRemove(const char * pcS, int32_t szS, int32_t StartIndex, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_WideStringRemove_1(const char * pcS, int32_t szS, int32_t StartIndex, int32_t Count, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_AnsiStringRemove(const char * pcS, int32_t szS, int32_t StartIndex, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_AnsiStringRemove_1(const char * pcS, int32_t szS, int32_t StartIndex, int32_t Count, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringToLower(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringToLower_1(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringToLowerInvariant(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringToLowerInvariant_1(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringStartsWith(const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringStartsWith_1(const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int8_t IgnoreCase, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringSubstring(const char * pcS, int32_t szS, int32_t StartIndex, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringSubstring_1(const char * pcS, int32_t szS, int32_t StartIndex, int32_t Length, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringSubstring_2(const char * pcS, int32_t szS, int32_t StartIndex, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringSubstring_3(const char * pcS, int32_t szS, int32_t StartIndex, int32_t Length, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringCopy(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringTrim(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringTrim_1(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringTrimEnd(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringTrimEnd_1(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringTrimStart(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringTrimStart_1(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringToUpper(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringToUpper_1(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringToUpperInvariant(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringToUpperInvariant_1(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringSplit(const char * pcS, int32_t szS, char Separator, TStringListHandle OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringSplit_1(const char * pcS, int32_t szS, char Separator, int8_t RemoveEmptyEntries, TStringListHandle OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringSplitPV(const char * pcS, int32_t szS, char * pcName, int32_t * szName, char * pcValue, int32_t * szValue, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringSplitPV_1(const char * pcS, int32_t szS, char * pcName, int32_t * szName, char * pcValue, int32_t * szValue, char Separator, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringSplitPV_2(const char * pcS, int32_t szS, char * pcName, int32_t * szName, char * pcValue, int32_t * szValue, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringSplitPV_3(const char * pcS, int32_t szS, char * pcName, int32_t * szName, char * pcValue, int32_t * szValue, const char * pcSeparator, int32_t szSeparator, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringPadLeft(const char * pcS, int32_t szS, char C, int32_t Len, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringPadRight(const char * pcS, int32_t szS, char C, int32_t Len, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StrToDefEncoding(const char * pcAStr, int32_t szAStr, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_DefEncodingToStr(const uint8_t pASrc[], int32_t szASrc, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StrToStdEncoding(const char * pcAStr, int32_t szAStr, int8_t UseUTF8, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StdEncodingToStr(const uint8_t pASrc[], int32_t szASrc, int8_t UseUTF8, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBExtractFilePath(const char * pcFileName, int32_t szFileName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBExtractFileName(const char * pcFileName, int32_t szFileName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBExtractFileExt(const char * pcFileName, int32_t szFileName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBExtractFileExt_1(const char * pcFileName, int32_t szFileName, int8_t IncludeDot, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ReplaceExt(const char * pcFileName, int32_t szFileName, const char * pcNewExtension, int32_t szNewExtension, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_FilenameMatchesMask(const char * pcName, int32_t szName, const char * pcMask, int32_t szMask, int8_t CaseSensitive, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_DomainNameMatchesCertSN(const char * pcDomainName, int32_t szDomainName, const char * pcMatch, int32_t szMatch, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_CountFoldersInPath(const char * pcPath, int32_t szPath, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ParseURL(const char * pcURL, int32_t szURL, int8_t SingleNameIsPage, char * pcProtocol, int32_t * szProtocol, char * pcUsername, int32_t * szUsername, char * pcPassword, int32_t * szPassword, char * pcHost, int32_t * szHost, uint16_t * Port, char * pcPath, int32_t * szPath, char * pcanchor, int32_t * szanchor, char * pcParameters, int32_t * szParameters);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ParseURL_1(const char * pcURL, int32_t szURL, int8_t SingleNameIsPage, char * pcProtocol, int32_t * szProtocol, char * pcUsername, int32_t * szUsername, char * pcPassword, int32_t * szPassword, char * pcHost, int32_t * szHost, uint16_t * Port, char * pcPath, int32_t * szPath, char * pcanchor, int32_t * szanchor, char * pcParameters, int32_t * szParameters, const char * pcDefaultProtocol, int32_t szDefaultProtocol);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ComposeURL(const char * pcProtocol, int32_t szProtocol, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword, const char * pcHost, int32_t szHost, uint16_t Port, const char * pcPath, int32_t szPath, const char * pcAnchor, int32_t szAnchor, const char * pcParameters, int32_t szParameters, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBRightPos(const char * pcSubstr, int32_t szSubstr, const char * pcStr, int32_t szStr, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBPos(const char * pcsubstr, int32_t szsubstr, const char * pcstr, int32_t szstr, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBPos_1(const uint8_t pSubP[], int32_t szSubP, const uint8_t pP[], int32_t szP, int32_t StartPos, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBPos_2(const char * pcSubP, int32_t szSubP, const uint8_t pP[], int32_t szP, int32_t StartPos, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBPos_3(uint8_t SubP, const uint8_t pP[], int32_t szP, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBCopy(const uint8_t pstr[], int32_t szstr, int32_t Offset, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBCopy_1(const uint8_t pstr[], int32_t szstr, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBConcatAnsiStrings(const char * pcStr1, int32_t szStr1, char Str2, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBConcatAnsiStrings_1(const char * pcStr1, int32_t szStr1, const char * pcStr2, int32_t szStr2, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBConcatAnsiStrings_2(const TStringListHandle Strs, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_OIDToStr(const uint8_t pOID[], int32_t szOID, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StrToOID(const char * pcStr, int32_t szStr, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StrToUTF8(const char * pcAStr, int32_t szAStr, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_UTF8ToStr(const uint8_t pASrc[], int32_t szASrc, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StrToWideStr(const char * pcAStr, int32_t szAStr, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_WideStrToStr(const uint8_t pASrc[], int32_t szASrc, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_EncodeString(const char * pcAStr, int32_t szAStr, const char * pcEncoding, int32_t szEncoding, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_DecodeString(const uint8_t pASrc[], int32_t szASrc, const char * pcEncoding, int32_t szEncoding, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_UnicodeChangeEndianness(const uint8_t pData[], int32_t szData, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_WideStrToUTF8(const char * pcAStr, int32_t szAStr, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_WideStrToUTF8_1(const void * ASrc, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_UTF8ToWideStr(const uint8_t pBuf[], int32_t szBuf, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_UTF8ToWideStr_1(const void * Buf, int32_t Size, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ConvertUTF16toUTF8(const char * pcsource, int32_t szsource, uint8_t ptarget[], int32_t * sztarget, ConversionFlagsRaw flags, int8_t BOM, ConversionResultRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_isLegalUTF8(const uint8_t psource[], int32_t szsource, uint32_t sourcelen, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ConvertUTF8toUTF16(const uint8_t psource[], int32_t szsource, char * pctarget, int32_t * sztarget, ConversionFlagsRaw flags, int8_t BOM, ConversionResultRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ConvertFromUTF8String(const uint8_t pSource[], int32_t szSource, int8_t CheckBOM, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ConvertToUTF8String(const char * pcSource, int32_t szSource, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ConvertFromUTF32String(const uint8_t pSource[], int32_t szSource, int8_t CheckBOM, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SetGlobalStringConverter(TElStringConverterHandle Converter);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SetDefaultCharset(const char * pcCharset, int32_t szCharset);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StrMixToInt64(const char * pcS, int32_t szS, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBTrim(const uint8_t pS[], int32_t szS, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBUppercase(const uint8_t pS[], int32_t szS, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringReplace(const char * pcSource, int32_t szSource, const char * pcEntry, int32_t szEntry, const char * pcReplaceWith, int32_t szReplaceWith, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_StringReplace_1(const char * pcSource, int32_t szSource, const char * pcEntry, int32_t szEntry, const char * pcReplaceWith, int32_t szReplaceWith, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_PrefixString(const char * pcS, int32_t szS, int32_t Count, char Value, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SuffixString(const char * pcS, int32_t szS, int32_t Count, char Value, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_PathFirstComponent(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_PathLastComponent(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_PathCutFirstComponent(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_PathCutLastComponent(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_PathIsDirectory(const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_PathTrim(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_PathConcatenate(const char * pcPath1, int32_t szPath1, const char * pcPath2, int32_t szPath2, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_PathNormalizeSlashes(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_PathReverseSlashes(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_PathMatchesMask(const char * pcPath, int32_t szPath, const char * pcMask, int32_t szMask, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_PathMatchesMask_1(const char * pcPath, int32_t szPath, const char * pcMask, int32_t szMask, int8_t CaseSensitive, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_IsFileMask(const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ExtractPathFromMask(const char * pcMask, int32_t szMask, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SftpNormalizePath(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ZipPathFirstComponent(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ZipPathLastComponent(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ZipPathCutFirstComponent(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ZipPathCutLastComponent(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ZipPathIsDirectory(const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ZipPathTrim(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ZipPathConcatenate(const char * pcPath1, int32_t szPath1, const char * pcPath2, int32_t szPath2, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ZipPathNormalizeSlashes(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ZipPathReverseSlashes(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ZipPathMatchesMask(const char * pcPath, int32_t szPath, const char * pcMask, int32_t szMask, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ZipPathMatchesMask_1(const char * pcPath, int32_t szPath, const char * pcMask, int32_t szMask, int8_t CaseSensitive, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ZipIsFileMask(const char * pcPath, int32_t szPath, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ZipExtractPathFromMask(const char * pcMask, int32_t szMask, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_PosExSafe(const char * pcSubStr, int32_t szSubStr, const char * pcS, int32_t szS, int32_t Offset, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_PosLast(const char * pcSubStr, int32_t szSubStr, const char * pcS, int32_t szS, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_WidePosEx(const char * pcSubStr, int32_t szSubStr, const char * pcS, int32_t szS, int32_t Offset, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_WidePosLast(const char * pcSubStr, int32_t szSubStr, const char * pcS, int32_t szS, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_WideStringToByteString(const char * pcWS, int32_t szWS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_AnsiStringToByteWideString(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_IntToStrPadLeft(int32_t Val, int32_t iWidth, const char * pcchTemplate, int32_t szchTemplate, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_GetWideBytesOf(const char * pcValue, int32_t szValue, uint8_t pB[], int32_t * szB);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_GetStringOf(const uint8_t pBytes[], int32_t szBytes, char * pcS, int32_t * szS);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_GetStringOfEx(const uint8_t pBytes[], int32_t szBytes, char * pcS, int32_t * szS, int64_t LPos, int64_t RPos);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_GetWideStringOf(const uint8_t pBytes[], int32_t szBytes, char * pcWS, int32_t * szWS);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_TrimEx(char * pcS, int32_t * szS, int8_t bTrimLeft, int8_t bTrimRight);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_TrimSemicolon(char * pcS, int32_t * szS);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ExtractWideFileName(const char * pcFileName, int32_t szFileName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ExtractFileExtension(const char * pcFileName, int32_t szFileName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_ExtractWideFileExtension(const char * pcFileName, int32_t szFileName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_WideTrimRight(const char * pcS, int32_t szS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_DecodeDateTime(int64_t AValue, uint16_t * AYear, uint16_t * AMonth, uint16_t * ADay, uint16_t * AHour, uint16_t * AMinute, uint16_t * ASecond, uint16_t * AMilliSecond);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBDecStr2ToIntDef(const char * pcSourceString, int32_t szSourceString, int32_t StartOffset, int32_t DefaultValue, int8_t SkipLengthCheck, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBDecStr3ToIntDef(const char * pcSourceString, int32_t szSourceString, int32_t StartOffset, int32_t DefaultValue, int8_t SkipLengthCheck, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBDecStr4ToIntDef(const char * pcSourceString, int32_t szSourceString, int32_t StartOffset, int32_t DefaultValue, int8_t SkipLengthCheck, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBLength(const char * pcStr, int32_t szStr, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBStrUtils_SBStringZToString(const uint8_t pCS[], int32_t szCS, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_STRUTILS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSTRUTILS */
