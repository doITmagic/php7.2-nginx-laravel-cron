#ifndef __INC_SBSYMMETRICCRYPTO
#define __INC_SBSYMMETRICCRYPTO

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcustomcrypto.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#ifdef SB_WINDOWS
#include "sbwincrypt.h"
#endif
#include "sbcryptoprov.h"
#include "sbcryptoprovmanager.h"
#include "sbcryptoprovutils.h"
#include "sbcryptoprovrs.h"
#include "sbconstants.h"
#include "sbrandom.h"
#include "sbpoly1305.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElSymmetricKeyMaterialHandle;

typedef TElSymmetricKeyMaterialHandle ElSymmetricKeyMaterialHandle;

typedef TElClassHandle TElSymmetricCryptoHandle;

typedef TElSymmetricCryptoHandle ElSymmetricCryptoHandle;

typedef TElClassHandle TElSymmetricCryptoFactoryHandle;

typedef TElSymmetricCryptoFactoryHandle ElSymmetricCryptoFactoryHandle;

typedef TElClassHandle TElAESSymmetricCryptoHandle;

typedef TElAESSymmetricCryptoHandle ElAESSymmetricCryptoHandle;

typedef TElClassHandle TElBlowfishSymmetricCryptoHandle;

typedef TElBlowfishSymmetricCryptoHandle ElBlowfishSymmetricCryptoHandle;

typedef TElClassHandle TElTwofishSymmetricCryptoHandle;

typedef TElTwofishSymmetricCryptoHandle ElTwofishSymmetricCryptoHandle;

typedef TElClassHandle TElIDEASymmetricCryptoHandle;

typedef TElIDEASymmetricCryptoHandle ElIDEASymmetricCryptoHandle;

typedef TElClassHandle TElCAST128SymmetricCryptoHandle;

typedef TElCAST128SymmetricCryptoHandle ElCAST128SymmetricCryptoHandle;

typedef TElClassHandle TElRC2SymmetricCryptoHandle;

typedef TElRC2SymmetricCryptoHandle ElRC2SymmetricCryptoHandle;

typedef TElClassHandle TElRC4SymmetricCryptoHandle;

typedef TElRC4SymmetricCryptoHandle ElRC4SymmetricCryptoHandle;

typedef TElClassHandle TElDESSymmetricCryptoHandle;

typedef TElDESSymmetricCryptoHandle ElDESSymmetricCryptoHandle;

typedef TElClassHandle TEl3DESSymmetricCryptoHandle;

typedef TEl3DESSymmetricCryptoHandle El3DESSymmetricCryptoHandle;

typedef TElClassHandle TElCamelliaSymmetricCryptoHandle;

typedef TElCamelliaSymmetricCryptoHandle ElCamelliaSymmetricCryptoHandle;

typedef TElClassHandle TElSerpentSymmetricCryptoHandle;

typedef TElSerpentSymmetricCryptoHandle ElSerpentSymmetricCryptoHandle;

typedef TElClassHandle TElSEEDSymmetricCryptoHandle;

typedef TElSEEDSymmetricCryptoHandle ElSEEDSymmetricCryptoHandle;

typedef TElClassHandle TElRabbitSymmetricCryptoHandle;

typedef TElRabbitSymmetricCryptoHandle ElRabbitSymmetricCryptoHandle;

typedef TElClassHandle TElGOST28147SymmetricCryptoHandle;

typedef TElGOST28147SymmetricCryptoHandle ElGOST28147SymmetricCryptoHandle;

typedef TElClassHandle TElIdentitySymmetricCryptoHandle;

typedef TElIdentitySymmetricCryptoHandle ElIdentitySymmetricCryptoHandle;

typedef TElClassHandle TElChaCha20SymmetricCryptoHandle;

typedef TElChaCha20SymmetricCryptoHandle ElChaCha20SymmetricCryptoHandle;

typedef TElClassHandle TElAEADChaCha20Poly1305SymmetricCryptoHandle;

typedef TElAEADChaCha20Poly1305SymmetricCryptoHandle ElAEADChaCha20Poly1305SymmetricCryptoHandle;

typedef uint8_t TSBKeyDerivationAlgorithmRaw;

typedef enum
{
	kdaPKCS5v2 = 0,
	kdaBCrypt = 1,
	kdaSCrypt = 2
} TSBKeyDerivationAlgorithm;

typedef uint8_t TSBSymmetricCryptoModeRaw;

typedef enum
{
	_cmDefault = 0,
	_cmECB = 1,
	_cmCBC = 2,
	_cmCTR = 3,
	_cmCFB8 = 4,
	_cmGCM = 5,
	_cmCCM = 6,
	_cmAEADChaCha20Poly1305 = 7
} TSBSymmetricCryptoMode;

typedef uint8_t TSBSymmetricCipherPaddingRaw;

typedef enum
{
	_cpNone = 0,
	_cpPKCS5 = 1,
	_cpANSIX923 = 2
} TSBSymmetricCipherPadding;

typedef TElClassHandle TElSymmetricCryptoClassHandle;

typedef TElSymmetricCryptoClassHandle ElSymmetricCryptoClassHandle;

#ifdef SB_USE_CLASS_TELSYMMETRICKEYMATERIAL
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_Generate(TElSymmetricKeyMaterialHandle _Handle, int32_t Bits);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_GenerateIV(TElSymmetricKeyMaterialHandle _Handle, int32_t Bits);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_DeriveKey(TElSymmetricKeyMaterialHandle _Handle, int32_t Bits, const char * pcPassword, int32_t szPassword);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_DeriveKey_1(TElSymmetricKeyMaterialHandle _Handle, int32_t Bits, const char * pcPassword, int32_t szPassword, const char * pcSalt, int32_t szSalt);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_DeriveKey_2(TElSymmetricKeyMaterialHandle _Handle, int32_t Bits, const char * pcPassword, int32_t szPassword, const uint8_t pSalt[], int32_t szSalt);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_DeriveKey_3(TElSymmetricKeyMaterialHandle _Handle, int32_t Bits, const char * pcPassword, int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, int32_t Iterations);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_DeriveKey_4(TElSymmetricKeyMaterialHandle _Handle, int32_t Bits, const char * pcPassword, int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, int32_t Iterations, int32_t HMACAlgorithm);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_DeriveKeyMaterial(int32_t Bits, const char * pcPassword, int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, int32_t Iterations, TSBKeyDerivationAlgorithmRaw Algorithm, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_DeriveKeyMaterial_1(TElSymmetricKeyMaterialHandle _Handle, int32_t Bits, const char * pcPassword, int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, int32_t Iterations, TSBKeyDerivationAlgorithmRaw Algorithm, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_DeriveKeyMaterial_2(int32_t Bits, const char * pcPassword, int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, int32_t Iterations, TSBKeyDerivationAlgorithmRaw Algorithm, int32_t HMACAlgorithm, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_DeriveKeyMaterial_3(TElSymmetricKeyMaterialHandle _Handle, int32_t Bits, const char * pcPassword, int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, int32_t Iterations, TSBKeyDerivationAlgorithmRaw Algorithm, int32_t HMACAlgorithm, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_Load(TElSymmetricKeyMaterialHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_Load_1(TElSymmetricKeyMaterialHandle _Handle, TStreamHandle Stream, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_Save(TElSymmetricKeyMaterialHandle _Handle, void * Buffer, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_Save_1(TElSymmetricKeyMaterialHandle _Handle, TStreamHandle Stream);
#ifndef SB_CPU64_OR_NOT_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_ImportEncryptedSymmetricKeyWin32(TElSymmetricKeyMaterialHandle _Handle, const uint8_t pEncryptedKey[], int32_t szEncryptedKey, int32_t SymAlgorithm, int32_t PKAlgorithm, const uint8_t pSymAlgParams[], int32_t szSymAlgParams, uint32_t hProv, uint32_t hUserKey, int8_t * OutResult);
#endif
#ifndef SB_NOT_CPU64_OR_NOT_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_ImportEncryptedSymmetricKeyWin32(TElSymmetricKeyMaterialHandle _Handle, const uint8_t pEncryptedKey[], int32_t szEncryptedKey, int32_t SymAlgorithm, int32_t PKAlgorithm, const uint8_t pSymAlgParams[], int32_t szSymAlgParams, uint64_t hProv, uint64_t hUserKey, int8_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_Persistentiate(TElSymmetricKeyMaterialHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_get_Key(TElSymmetricKeyMaterialHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_set_Key(TElSymmetricKeyMaterialHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_get_IV(TElSymmetricKeyMaterialHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_set_IV(TElSymmetricKeyMaterialHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_get_Algorithm(TElSymmetricKeyMaterialHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_set_Algorithm(TElSymmetricKeyMaterialHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_Create(TElCustomCryptoProviderHandle Prov, TElSymmetricKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_Create_1(TElCustomCryptoKeyHandle Key, TElCustomCryptoProviderHandle Prov, TElSymmetricKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_Create_2(TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElSymmetricKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_Create_3(TElCustomCryptoKeyHandle Key, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElSymmetricKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_Create_4(int32_t Algorithm, TElCustomCryptoProviderHandle Prov, TElSymmetricKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricKeyMaterial_Create_5(int32_t Algorithm, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElSymmetricKeyMaterialHandle * OutResult);
#endif /* SB_USE_CLASS_TELSYMMETRICKEYMATERIAL */

#ifdef SB_USE_CLASS_TELSYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_InitializeEncryption(TElSymmetricCryptoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_InitializeDecryption(TElSymmetricCryptoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Encrypt(TElSymmetricCryptoHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Encrypt_1(TElSymmetricCryptoHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Encrypt_2(int32_t AlgID, const uint8_t pKey[], int32_t szKey, const uint8_t pIV[], int32_t szIV, TSBSymmetricCryptoModeRaw Mode, void * Buffer, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Encrypt_3(TElSymmetricCryptoHandle _Handle, int32_t AlgID, const uint8_t pKey[], int32_t szKey, const uint8_t pIV[], int32_t szIV, TSBSymmetricCryptoModeRaw Mode, void * Buffer, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_EncryptUpdate(TElSymmetricCryptoHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_FinalizeEncryption(TElSymmetricCryptoHandle _Handle, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_EncryptAEAD(TElSymmetricCryptoHandle _Handle, void * AssociatedData, int32_t ADataSize, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Decrypt(TElSymmetricCryptoHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Decrypt_1(TElSymmetricCryptoHandle _Handle, TStreamHandle InStream, TStreamHandle OutStream, int32_t InCount);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Decrypt_2(int32_t AlgID, const uint8_t pKey[], int32_t szKey, const uint8_t pIV[], int32_t szIV, TSBSymmetricCryptoModeRaw Mode, void * Buffer, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Decrypt_3(TElSymmetricCryptoHandle _Handle, int32_t AlgID, const uint8_t pKey[], int32_t szKey, const uint8_t pIV[], int32_t szIV, TSBSymmetricCryptoModeRaw Mode, void * Buffer, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_DecryptAEAD(TElSymmetricCryptoHandle _Handle, void * AssociatedData, int32_t ADataSize, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_DecryptUpdate(TElSymmetricCryptoHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_DecryptUpdateWin32(TElSymmetricCryptoHandle _Handle, void * InBuffer, int32_t InSize, void * OutBuffer, int32_t * OutSize);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_FinalizeDecryption(TElSymmetricCryptoHandle _Handle, void * OutBuffer, int32_t * OutSize);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_AlgID(TElSymmetricCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_MACAlgorithm(TElSymmetricCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_KeyMaterial(TElSymmetricCryptoHandle _Handle, TElSymmetricKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_set_KeyMaterial(TElSymmetricCryptoHandle _Handle, TElSymmetricKeyMaterialHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_Mode(TElSymmetricCryptoHandle _Handle, TSBSymmetricCryptoModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_BlockSize(TElSymmetricCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_KeySize(TElSymmetricCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_Padding(TElSymmetricCryptoHandle _Handle, TSBSymmetricCipherPaddingRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_set_Padding(TElSymmetricCryptoHandle _Handle, TSBSymmetricCipherPaddingRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_CTRLittleEndian(TElSymmetricCryptoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_set_CTRLittleEndian(TElSymmetricCryptoHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_Nonce(TElSymmetricCryptoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_set_Nonce(TElSymmetricCryptoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_TagSize(TElSymmetricCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_set_TagSize(TElSymmetricCryptoHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_AssociatedDataSize(TElSymmetricCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_set_AssociatedDataSize(TElSymmetricCryptoHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_PayloadSize(TElSymmetricCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_set_PayloadSize(TElSymmetricCryptoHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_AssociatedData(TElSymmetricCryptoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_set_AssociatedData(TElSymmetricCryptoHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_IsStreamCipher(TElSymmetricCryptoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_CryptoProvider(TElSymmetricCryptoHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_set_CryptoProvider(TElSymmetricCryptoHandle _Handle, TElCustomCryptoProviderHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_CryptoProviderManager(TElSymmetricCryptoHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_set_CryptoProviderManager(TElSymmetricCryptoHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_get_OnProgress(TElSymmetricCryptoHandle _Handle, TSBProgressEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_set_OnProgress(TElSymmetricCryptoHandle _Handle, TSBProgressEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Create_6(int32_t AlgID, int32_t MacAlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCrypto_Create_7(int32_t AlgID, int32_t MacAlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElSymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELSYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELSYMMETRICCRYPTOFACTORY
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCryptoFactory_CreateInstance(TElSymmetricCryptoFactoryHandle _Handle, const uint8_t pOID[], int32_t szOID, TSBSymmetricCryptoModeRaw Mode, TElSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCryptoFactory_CreateInstance_1(TElSymmetricCryptoFactoryHandle _Handle, int32_t Alg, TSBSymmetricCryptoModeRaw Mode, TElSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCryptoFactory_CreateInstance_2(TElSymmetricCryptoFactoryHandle _Handle, int32_t Alg, int32_t Mac, TSBSymmetricCryptoModeRaw Mode, TElSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCryptoFactory_IsAlgorithmSupported(TElSymmetricCryptoFactoryHandle _Handle, const uint8_t pOID[], int32_t szOID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCryptoFactory_IsAlgorithmSupported_1(TElSymmetricCryptoFactoryHandle _Handle, int32_t Alg, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCryptoFactory_GetDefaultKeyAndBlockLengths(TElSymmetricCryptoFactoryHandle _Handle, int32_t Alg, int32_t * KeyLen, int32_t * BlockLen, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCryptoFactory_GetDefaultKeyAndBlockLengths_1(TElSymmetricCryptoFactoryHandle _Handle, const uint8_t pOID[], int32_t szOID, int32_t * KeyLen, int32_t * BlockLen, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCryptoFactory_get_CryptoProvider(TElSymmetricCryptoFactoryHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCryptoFactory_set_CryptoProvider(TElSymmetricCryptoFactoryHandle _Handle, TElCustomCryptoProviderHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCryptoFactory_get_CryptoProviderManager(TElSymmetricCryptoFactoryHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCryptoFactory_set_CryptoProviderManager(TElSymmetricCryptoFactoryHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSymmetricCryptoFactory_Create(TElSymmetricCryptoFactoryHandle * OutResult);
#endif /* SB_USE_CLASS_TELSYMMETRICCRYPTOFACTORY */

#ifdef SB_USE_CLASS_TELAESSYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElAESSymmetricCrypto_GetDefaultKeyWrapIV(uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAESSymmetricCrypto_GetDefaultKeyWrapIV_1(TElAESSymmetricCryptoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAESSymmetricCrypto_KeyWrapEncrypt(int32_t Algorithm, const uint8_t pWrappedKey[], int32_t szWrappedKey, const uint8_t pKeyEncryptionKey[], int32_t szKeyEncryptionKey, const uint8_t pIV[], int32_t szIV, TElCustomCryptoProviderManagerHandle Manager, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAESSymmetricCrypto_KeyWrapEncrypt_1(TElAESSymmetricCryptoHandle _Handle, int32_t Algorithm, const uint8_t pWrappedKey[], int32_t szWrappedKey, const uint8_t pKeyEncryptionKey[], int32_t szKeyEncryptionKey, const uint8_t pIV[], int32_t szIV, TElCustomCryptoProviderManagerHandle Manager, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAESSymmetricCrypto_KeyWrapDecrypt(int32_t Algorithm, const uint8_t pEncryptedWrappedKey[], int32_t szEncryptedWrappedKey, const uint8_t pKeyEncryptionKey[], int32_t szKeyEncryptionKey, const uint8_t pIV[], int32_t szIV, TElCustomCryptoProviderManagerHandle Manager, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAESSymmetricCrypto_KeyWrapDecrypt_1(TElAESSymmetricCryptoHandle _Handle, int32_t Algorithm, const uint8_t pEncryptedWrappedKey[], int32_t szEncryptedWrappedKey, const uint8_t pKeyEncryptionKey[], int32_t szKeyEncryptionKey, const uint8_t pIV[], int32_t szIV, TElCustomCryptoProviderManagerHandle Manager, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAESSymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAESSymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElAESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAESSymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElAESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAESSymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElAESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAESSymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElAESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAESSymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElAESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAESSymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElAESSymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELAESSYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELBLOWFISHSYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElBlowfishSymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBlowfishSymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElBlowfishSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBlowfishSymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElBlowfishSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBlowfishSymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElBlowfishSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBlowfishSymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElBlowfishSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBlowfishSymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElBlowfishSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBlowfishSymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElBlowfishSymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELBLOWFISHSYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELTWOFISHSYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElTwofishSymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTwofishSymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElTwofishSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTwofishSymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElTwofishSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTwofishSymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElTwofishSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTwofishSymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElTwofishSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTwofishSymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElTwofishSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTwofishSymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElTwofishSymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELTWOFISHSYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELIDEASYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElIDEASymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIDEASymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElIDEASymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIDEASymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElIDEASymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIDEASymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElIDEASymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIDEASymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElIDEASymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIDEASymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElIDEASymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIDEASymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElIDEASymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELIDEASYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELCAST128SYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElCAST128SymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCAST128SymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElCAST128SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCAST128SymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElCAST128SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCAST128SymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElCAST128SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCAST128SymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElCAST128SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCAST128SymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElCAST128SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCAST128SymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElCAST128SymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELCAST128SYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELRC2SYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElRC2SymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRC2SymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElRC2SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRC2SymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElRC2SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRC2SymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElRC2SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRC2SymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElRC2SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRC2SymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElRC2SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRC2SymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElRC2SymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELRC2SYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELRC4SYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElRC4SymmetricCrypto_InitializeEncryption(TElRC4SymmetricCryptoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElRC4SymmetricCrypto_InitializeDecryption(TElRC4SymmetricCryptoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElRC4SymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRC4SymmetricCrypto_get_SkipKeystreamBytes(TElRC4SymmetricCryptoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRC4SymmetricCrypto_set_SkipKeystreamBytes(TElRC4SymmetricCryptoHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElRC4SymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElRC4SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRC4SymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElRC4SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRC4SymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElRC4SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRC4SymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElRC4SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRC4SymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElRC4SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRC4SymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElRC4SymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELRC4SYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELDESSYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElDESSymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDESSymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElDESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDESSymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElDESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDESSymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElDESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDESSymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElDESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDESSymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElDESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDESSymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElDESSymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELDESSYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TEL3DESSYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TEl3DESSymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl3DESSymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TEl3DESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl3DESSymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TEl3DESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl3DESSymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TEl3DESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl3DESSymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TEl3DESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl3DESSymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TEl3DESSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TEl3DESSymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TEl3DESSymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TEL3DESSYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELCAMELLIASYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElCamelliaSymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCamelliaSymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElCamelliaSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCamelliaSymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElCamelliaSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCamelliaSymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElCamelliaSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCamelliaSymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElCamelliaSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCamelliaSymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElCamelliaSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCamelliaSymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElCamelliaSymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELCAMELLIASYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELSERPENTSYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElSerpentSymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSerpentSymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElSerpentSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSerpentSymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElSerpentSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSerpentSymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElSerpentSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSerpentSymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElSerpentSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSerpentSymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElSerpentSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSerpentSymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElSerpentSymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELSERPENTSYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELSEEDSYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElSEEDSymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSEEDSymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElSEEDSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSEEDSymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElSEEDSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSEEDSymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElSEEDSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSEEDSymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElSEEDSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSEEDSymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElSEEDSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSEEDSymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElSEEDSymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELSEEDSYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELRABBITSYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElRabbitSymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRabbitSymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElRabbitSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRabbitSymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElRabbitSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRabbitSymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElRabbitSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRabbitSymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElRabbitSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRabbitSymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElRabbitSymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRabbitSymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElRabbitSymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELRABBITSYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELGOST28147SYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_InitializeEncryption(TElGOST28147SymmetricCryptoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_InitializeDecryption(TElGOST28147SymmetricCryptoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_get_ParamSet(TElGOST28147SymmetricCryptoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_set_ParamSet(TElGOST28147SymmetricCryptoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_get_SBoxes(TElGOST28147SymmetricCryptoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_set_SBoxes(TElGOST28147SymmetricCryptoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_get_UseKeyMeshing(TElGOST28147SymmetricCryptoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_set_UseKeyMeshing(TElGOST28147SymmetricCryptoHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElGOST28147SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElGOST28147SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElGOST28147SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElGOST28147SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElGOST28147SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElGOST28147SymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElGOST28147SymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELGOST28147SYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELIDENTITYSYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElIdentitySymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentitySymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElIdentitySymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentitySymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElIdentitySymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentitySymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElIdentitySymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentitySymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElIdentitySymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentitySymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElIdentitySymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIdentitySymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElIdentitySymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELIDENTITYSYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELCHACHA20SYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElChaCha20SymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChaCha20SymmetricCrypto_get_Counter(TElChaCha20SymmetricCryptoHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChaCha20SymmetricCrypto_set_Counter(TElChaCha20SymmetricCryptoHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElChaCha20SymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElChaCha20SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChaCha20SymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElChaCha20SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChaCha20SymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElChaCha20SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChaCha20SymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElChaCha20SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChaCha20SymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElChaCha20SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElChaCha20SymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElChaCha20SymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELCHACHA20SYMMETRICCRYPTO */

#ifdef SB_USE_CLASS_TELAEADCHACHA20POLY1305SYMMETRICCRYPTO
SB_IMPORT uint32_t SB_APIENTRY TElAEADChaCha20Poly1305SymmetricCrypto_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAEADChaCha20Poly1305SymmetricCrypto_get_AAD(TElAEADChaCha20Poly1305SymmetricCryptoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAEADChaCha20Poly1305SymmetricCrypto_set_AAD(TElAEADChaCha20Poly1305SymmetricCryptoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElAEADChaCha20Poly1305SymmetricCrypto_get_Tag(TElAEADChaCha20Poly1305SymmetricCryptoHandle _Handle, TSBPoly1305Tag * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAEADChaCha20Poly1305SymmetricCrypto_set_Tag(TElAEADChaCha20Poly1305SymmetricCryptoHandle _Handle, TSBPoly1305Tag * Value);
SB_IMPORT uint32_t SB_APIENTRY TElAEADChaCha20Poly1305SymmetricCrypto_get_Poly1305Mode(TElAEADChaCha20Poly1305SymmetricCryptoHandle _Handle, TSBPoly1305ModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAEADChaCha20Poly1305SymmetricCrypto_set_Poly1305Mode(TElAEADChaCha20Poly1305SymmetricCryptoHandle _Handle, TSBPoly1305ModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElAEADChaCha20Poly1305SymmetricCrypto_Create(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElAEADChaCha20Poly1305SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAEADChaCha20Poly1305SymmetricCrypto_Create_1(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElAEADChaCha20Poly1305SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAEADChaCha20Poly1305SymmetricCrypto_Create_2(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderHandle CryptoProvider, TElAEADChaCha20Poly1305SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAEADChaCha20Poly1305SymmetricCrypto_Create_3(int32_t AlgID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElAEADChaCha20Poly1305SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAEADChaCha20Poly1305SymmetricCrypto_Create_4(const uint8_t pAlgOID[], int32_t szAlgOID, TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElAEADChaCha20Poly1305SymmetricCryptoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAEADChaCha20Poly1305SymmetricCrypto_Create_5(TSBSymmetricCryptoModeRaw Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle CryptoProvider, TElAEADChaCha20Poly1305SymmetricCryptoHandle * OutResult);
#endif /* SB_USE_CLASS_TELAEADCHACHA20POLY1305SYMMETRICCRYPTO */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSymmetricCryptoClass_ce_ptr;
extern zend_class_entry *TElSymmetricKeyMaterial_ce_ptr;
extern zend_class_entry *TElSymmetricCrypto_ce_ptr;
extern zend_class_entry *TElSymmetricCryptoFactory_ce_ptr;
extern zend_class_entry *TElAESSymmetricCrypto_ce_ptr;
extern zend_class_entry *TElBlowfishSymmetricCrypto_ce_ptr;
extern zend_class_entry *TElTwofishSymmetricCrypto_ce_ptr;
extern zend_class_entry *TElIDEASymmetricCrypto_ce_ptr;
extern zend_class_entry *TElCAST128SymmetricCrypto_ce_ptr;
extern zend_class_entry *TElRC2SymmetricCrypto_ce_ptr;
extern zend_class_entry *TElRC4SymmetricCrypto_ce_ptr;
extern zend_class_entry *TElDESSymmetricCrypto_ce_ptr;
extern zend_class_entry *TEl3DESSymmetricCrypto_ce_ptr;
extern zend_class_entry *TElCamelliaSymmetricCrypto_ce_ptr;
extern zend_class_entry *TElSerpentSymmetricCrypto_ce_ptr;
extern zend_class_entry *TElSEEDSymmetricCrypto_ce_ptr;
extern zend_class_entry *TElRabbitSymmetricCrypto_ce_ptr;
extern zend_class_entry *TElGOST28147SymmetricCrypto_ce_ptr;
extern zend_class_entry *TElIdentitySymmetricCrypto_ce_ptr;
extern zend_class_entry *TElChaCha20SymmetricCrypto_ce_ptr;
extern zend_class_entry *TElAEADChaCha20Poly1305SymmetricCrypto_ce_ptr;

void Register_TElSymmetricKeyMaterial(TSRMLS_D);
void Register_TElSymmetricCrypto(TSRMLS_D);
void Register_TElSymmetricCryptoFactory(TSRMLS_D);
void Register_TElAESSymmetricCrypto(TSRMLS_D);
void Register_TElBlowfishSymmetricCrypto(TSRMLS_D);
void Register_TElTwofishSymmetricCrypto(TSRMLS_D);
void Register_TElIDEASymmetricCrypto(TSRMLS_D);
void Register_TElCAST128SymmetricCrypto(TSRMLS_D);
void Register_TElRC2SymmetricCrypto(TSRMLS_D);
void Register_TElRC4SymmetricCrypto(TSRMLS_D);
void Register_TElDESSymmetricCrypto(TSRMLS_D);
void Register_TEl3DESSymmetricCrypto(TSRMLS_D);
void Register_TElCamelliaSymmetricCrypto(TSRMLS_D);
void Register_TElSerpentSymmetricCrypto(TSRMLS_D);
void Register_TElSEEDSymmetricCrypto(TSRMLS_D);
void Register_TElRabbitSymmetricCrypto(TSRMLS_D);
void Register_TElGOST28147SymmetricCrypto(TSRMLS_D);
void Register_TElIdentitySymmetricCrypto(TSRMLS_D);
void Register_TElChaCha20SymmetricCrypto(TSRMLS_D);
void Register_TElAEADChaCha20Poly1305SymmetricCrypto(TSRMLS_D);
void Register_SBSymmetricCrypto_Enum_Flags(TSRMLS_D);
void Register_SBSymmetricCrypto_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBSYMMETRICCRYPTO */
