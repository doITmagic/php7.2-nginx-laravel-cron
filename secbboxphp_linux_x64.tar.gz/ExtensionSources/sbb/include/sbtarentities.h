#ifndef __INC_SBTARENTITIES
#define __INC_SBTARENTITIES

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstreams.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_TAR_ERROR_HEADERSIZE_CORRUPTED 	1
#define SB_TAR_ERROR_HEADER_CORRUPTED 	2
#define SB_TAR_ERROR_USTARSIZE_CORRUPTED 	3
#define SB_TAR_ERROR_CHECKSUM_CORRUPTED 	4

typedef TElClassHandle TElUStarTarHeaderHandle;

typedef void (SB_CALLBACK *TSBTarArchiveErrorEvent)(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode, const char * pcErrorMessage, int32_t szErrorMessage, int8_t * TryContinue);

#ifdef SB_USE_CLASS_TELUSTARTARHEADER
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_Assign(TElUStarTarHeaderHandle _Handle, TElUStarTarHeaderHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_AssignTo(TElUStarTarHeaderHandle _Handle, TElUStarTarHeaderHandle Dest);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_LoadFromBuffer(TElUStarTarHeaderHandle _Handle, const uint8_t pB[], int32_t szB);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_SaveToBuffer(TElUStarTarHeaderHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_get_Magic(TElUStarTarHeaderHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_set_Magic(TElUStarTarHeaderHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_get_UName(TElUStarTarHeaderHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_set_UName(TElUStarTarHeaderHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_get_GName(TElUStarTarHeaderHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_set_GName(TElUStarTarHeaderHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_get_DevMajor(TElUStarTarHeaderHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_set_DevMajor(TElUStarTarHeaderHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_get_DevMinor(TElUStarTarHeaderHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_set_DevMinor(TElUStarTarHeaderHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_get_Prefix(TElUStarTarHeaderHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_set_Prefix(TElUStarTarHeaderHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElUStarTarHeader_Create(TElUStarTarHeaderHandle * OutResult);
#endif /* SB_USE_CLASS_TELUSTARTARHEADER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElUStarTarHeader_ce_ptr;

void SB_CALLBACK TSBTarArchiveErrorEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t ErrorCode, const char * pcErrorMessage, int32_t szErrorMessage, int8_t * TryContinue);
void Register_TElUStarTarHeader(TSRMLS_D);
void Register_SBTarEntities_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBTARENTITIES */

