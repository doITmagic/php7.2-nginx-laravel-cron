#ifndef __INC_SBTIMER
#define __INC_SBTIMER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbsharedresource.h"
#include "sbtypes.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TTimerThreadHandle;

typedef TElClassHandle TElTimerHandle;

#ifdef SB_USE_CLASS_TTIMERTHREAD
SB_IMPORT uint32_t SB_APIENTRY TTimerThread_Execute(TTimerThreadHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TTimerThread_get_Interval(TTimerThreadHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TTimerThread_set_Interval(TTimerThreadHandle _Handle, int32_t Value);
#ifdef LINUX
SB_IMPORT uint32_t SB_APIENTRY TTimerThread_get_TimerStep(TTimerThreadHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TTimerThread_set_TimerStep(TTimerThreadHandle _Handle, int32_t Value);
#endif
SB_IMPORT uint32_t SB_APIENTRY TTimerThread_get_TerminateNow(TTimerThreadHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TTimerThread_set_TerminateNow(TTimerThreadHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TTimerThread_get_Enabled(TTimerThreadHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TTimerThread_set_Enabled(TTimerThreadHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TTimerThread_get_OnTimer(TTimerThreadHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TTimerThread_set_OnTimer(TTimerThreadHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TTimerThread_get_OnFinish(TTimerThreadHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TTimerThread_set_OnFinish(TTimerThreadHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TTimerThread_Create(TTimerThreadHandle * OutResult);
#endif /* SB_USE_CLASS_TTIMERTHREAD */

#ifdef SB_USE_CLASS_TELTIMER
SB_IMPORT uint32_t SB_APIENTRY TElTimer_get_Interval(TElTimerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTimer_set_Interval(TElTimerHandle _Handle, int32_t Value);
#ifdef LINUX
SB_IMPORT uint32_t SB_APIENTRY TElTimer_get_TimerStep(TElTimerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTimer_set_TimerStep(TElTimerHandle _Handle, int32_t Value);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElTimer_get_Enabled(TElTimerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTimer_set_Enabled(TElTimerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTimer_get_RecreateThreads(TElTimerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTimer_set_RecreateThreads(TElTimerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTimer_get_OnTimer(TElTimerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTimer_set_OnTimer(TElTimerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElTimer_Create(TComponentHandle AOwner, TElTimerHandle * OutResult);
#endif /* SB_USE_CLASS_TELTIMER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TTimerThread_ce_ptr;
extern zend_class_entry *TElTimer_ce_ptr;

void Register_TTimerThread(TSRMLS_D);
void Register_TElTimer(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBTIMER */
