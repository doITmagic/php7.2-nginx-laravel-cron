#ifndef __INC_SBTSPSERVER
#define __INC_SBTSPSERVER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbencoding.h"
#include "sbstreams.h"
#include "sbasn1.h"
#include "sbasn1tree.h"
#include "sbpem.h"
#include "sbx509ext.h"
#include "sbpkcs7.h"
#include "sbmessages.h"
#include "sbpkicommon.h"
#include "sbtspcommon.h"
#include "sbconstants.h"
#include "sbcustomcertstorage.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElServerTSPInfoHandle;

typedef TElServerTSPInfoHandle ElServerTSPInfoHandle;

typedef TElClassHandle TElCustomTSPServerHandle;

typedef TElCustomTSPServerHandle ElCustomTSPServerHandle;

typedef TElClassHandle TElFileTSPServerHandle;

typedef TElFileTSPServerHandle ElFileTSPServerHandle;

#ifdef SB_USE_CLASS_TELSERVERTSPINFO
SB_IMPORT uint32_t SB_APIENTRY TElServerTSPInfo_get_Nonce(TElServerTSPInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElServerTSPInfo_get_HashAlgorithm(TElServerTSPInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElServerTSPInfo_get_Time(TElServerTSPInfoHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElServerTSPInfo_set_Time(TElServerTSPInfoHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElServerTSPInfo_get_AccuracySec(TElServerTSPInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElServerTSPInfo_set_AccuracySec(TElServerTSPInfoHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElServerTSPInfo_get_AccuracyMilli(TElServerTSPInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElServerTSPInfo_set_AccuracyMilli(TElServerTSPInfoHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElServerTSPInfo_get_AccuracyMicro(TElServerTSPInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElServerTSPInfo_set_AccuracyMicro(TElServerTSPInfoHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElServerTSPInfo_get_TSAName(TElServerTSPInfoHandle _Handle, TElGeneralNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElServerTSPInfo_Create(TElTSPInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELSERVERTSPINFO */

#ifdef SB_USE_CLASS_TELCUSTOMTSPSERVER
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPServer_get_TSPInfo(TElCustomTSPServerHandle _Handle, TElServerTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPServer_get_DefaultPolicy(TElCustomTSPServerHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPServer_set_DefaultPolicy(TElCustomTSPServerHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPServer_get_IsAuthenticode(TElCustomTSPServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPServer_get_Certificates(TElCustomTSPServerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPServer_set_Certificates(TElCustomTSPServerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPServer_Create(TComponentHandle Owner, TElCustomTSPServerHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMTSPSERVER */

#ifdef SB_USE_CLASS_TELFILETSPSERVER
SB_IMPORT uint32_t SB_APIENTRY TElFileTSPServer_SaveReplyToStream(TElFileTSPServerHandle _Handle, TSBPKIStatusRaw ServerResult, int32_t FailureInfo, TStreamHandle Stream, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileTSPServer_LoadRequestFromStream(TElFileTSPServerHandle _Handle, TStreamHandle Stream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFileTSPServer_Create(TComponentHandle Owner, TElCustomTSPServerHandle * OutResult);
#endif /* SB_USE_CLASS_TELFILETSPSERVER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElServerTSPInfo_ce_ptr;
extern zend_class_entry *TElCustomTSPServer_ce_ptr;
extern zend_class_entry *TElFileTSPServer_ce_ptr;

void Register_TElServerTSPInfo(TSRMLS_D);
void Register_TElCustomTSPServer(TSRMLS_D);
void Register_TElFileTSPServer(TSRMLS_D);
void Register_SBTSPServer_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBTSPSERVER */

