#ifndef __INC_SBU2FCLIENT
#define __INC_SBU2FCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbconstants.h"
#include "sbstrutils.h"
#include "sbstringlist.h"
#include "sbutils.h"
#include "sbu2fcommon.h"
#include "sbhid.h"
#include "sbsharedresource.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElU2FDeviceHandle;

typedef TElClassHandle TElU2FHIDDeviceHandle;

typedef TElClassHandle TElU2FClientHandle;

#ifdef SB_USE_CLASS_TELU2FDEVICE
SB_IMPORT uint32_t SB_APIENTRY TElU2FDevice_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELU2FDEVICE */

#ifdef SB_USE_CLASS_TELU2FHIDDEVICE
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_Lock(TElU2FHIDDeviceHandle _Handle, int32_t TimePeriod);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_Unlock(TElU2FHIDDeviceHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_Ping(TElU2FHIDDeviceHandle _Handle, const uint8_t pData[], int32_t szData);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_Sync(TElU2FHIDDeviceHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_Wink(TElU2FHIDDeviceHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_SendMessage(TElU2FHIDDeviceHandle _Handle, const uint8_t pData[], int32_t szData, int32_t StartIndex, int32_t Count, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_SendVendorCommand(TElU2FHIDDeviceHandle _Handle, uint8_t Command, const uint8_t pData[], int32_t szData, int32_t StartIndex, int32_t Count, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_get_AutoWink(TElU2FHIDDeviceHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_set_AutoWink(TElU2FHIDDeviceHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_get_CapabilitiesFlags(TElU2FHIDDeviceHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_get_VersionInterface(TElU2FHIDDeviceHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_get_VersionMajor(TElU2FHIDDeviceHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_get_VersionMinor(TElU2FHIDDeviceHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_get_VersionBuild(TElU2FHIDDeviceHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_get_U2FVersion(TElU2FHIDDeviceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_get_HIDDevice(TElU2FHIDDeviceHandle _Handle, TElHIDDeviceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FHIDDevice_Create(TElU2FHIDDeviceHandle * OutResult);
#endif /* SB_USE_CLASS_TELU2FHIDDEVICE */

#ifdef SB_USE_CLASS_TELU2FCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElU2FClient_RegisterUser(TElU2FClientHandle _Handle, TElU2FDeviceHandle Device, const char * pcJSONRegistrationChallenge, int32_t szJSONRegistrationChallenge, char * pcJSONClientData, int32_t * szJSONClientData, uint8_t pRegistrationData[], int32_t * szRegistrationData);
SB_IMPORT uint32_t SB_APIENTRY TElU2FClient_RegisterUser_1(TElU2FClientHandle _Handle, const char * pcU2FRegisterRequest, int32_t szU2FRegisterRequest, char * pcU2FRegisterResponse, int32_t * szU2FRegisterResponse, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FClient_AuthenticateUser(TElU2FClientHandle _Handle, const char * pcJSONAuthenticationChallenge, int32_t szJSONAuthenticationChallenge, TElU2FUserKeysHandle UserKeys, char * pcJSONClientData, int32_t * szJSONClientData, uint8_t pAuthData[], int32_t * szAuthData);
SB_IMPORT uint32_t SB_APIENTRY TElU2FClient_AuthenticateUser_1(TElU2FClientHandle _Handle, const char * pcU2FSignRequest, int32_t szU2FSignRequest, char * pcU2FSignResponse, int32_t * szU2FSignResponse, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FClient_AddDevice(TElU2FClientHandle _Handle, TElU2FDeviceHandle Device);
SB_IMPORT uint32_t SB_APIENTRY TElU2FClient_EnumerateDevices(TElU2FClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElU2FClient_get_RetryIterations(TElU2FClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FClient_get_RetryInterval(TElU2FClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FClient_get_U2FDeviceCount(TElU2FClientHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FClient_get_U2FDevices(TElU2FClientHandle _Handle, int32_t Index, TElU2FDeviceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FClient_Create(TComponentHandle AOwner, TElU2FClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELU2FCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElU2FDevice_ce_ptr;
extern zend_class_entry *TElU2FHIDDevice_ce_ptr;
extern zend_class_entry *TElU2FClient_ce_ptr;

void Register_TElU2FDevice(TSRMLS_D);
void Register_TElU2FHIDDevice(TSRMLS_D);
void Register_TElU2FClient(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBU2FCLIENT */

