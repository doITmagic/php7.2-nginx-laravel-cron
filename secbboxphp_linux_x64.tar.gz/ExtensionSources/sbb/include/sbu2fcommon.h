#ifndef __INC_SBU2FCOMMON
#define __INC_SBU2FCOMMON

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbstrutils.h"
#include "sbutils.h"
#include "sbpublickeycrypto.h"
#include "sbx509.h"
#include "sbsharedresource.h"
#include "sbstringlist.h"
#include "sbusers.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_U2F 	139264
#define SB_ERROR_U2F_ERROR_FLAG 	2048
#define SB_ERROR_U2F_SERVER_ERROR_FLAG 	2304
#define SB_ERROR_U2F_SERVER_ERROR_CLIENT_JSAPI_ERROR_FLAG 	2352
#define SB_ERROR_U2F_CLIENT_ERROR_FLAG 	2560
#define SB_U2F_ERROR_INDEX_OUT_OF_BOUNDS 	141313
#define SB_U2F_ERROR_INVALID_REGISTRATION_RESPONSE_DATA 	141314
#define SB_U2F_ERROR_REGISTRATION_RESPONSE_DATA_TOO_SMALL 	141315
#define SB_U2F_ERROR_AUTH_RESPONSE_DATA_TOO_SMALL 	141316
#define SB_U2F_ERROR_ATTESTATION_CERTIFICATE_PARSE_FAILED 	141317
#define SB_U2F_ERROR_INVALID_ATTESTATION_CERTIFICATE_TYPE 	141318
#define SB_U2F_ERROR_INVALID_USER_PUBLIC_KEY 	141319
#define SB_U2F_ERROR_NO_RESPONSE_DATA 	141320
#define SB_U2F_ERROR_INVALID_U2F_REGISTER_REQUEST_TYPE 	141321
#define SB_U2F_ERROR_INVALID_U2F_REGISTER_RESPONSE_TYPE 	141322
#define SB_U2F_ERROR_INVALID_U2F_AUTH_REQUEST_TYPE 	141323
#define SB_U2F_ERROR_INVALID_U2F_AUTH_RESPONSE_TYPE 	141324
#define SB_U2F_ERROR_INVALID_USER_CLASS 	141324
#define SB_U2F_SERVER_ERROR_OK 	0
#define SB_U2F_SERVER_ERROR_NO_USERINFO 	141569
#define SB_U2F_SERVER_ERROR_WRONG_CLIENT_DATATYPE 	141570
#define SB_U2F_SERVER_ERROR_UNKNOWN_CHALLENGE 	141571
#define SB_U2F_SERVER_ERROR_WRONG_APPID 	141572
#define SB_U2F_SERVER_ERROR_INVALID_SIGNATURE 	141573
#define SB_U2F_SERVER_ERROR_ATTESTATION_CERT_NOT_VALID 	141574
#define SB_U2F_SERVER_ERROR_ATTESTATION_CERT_NOT_ACCEPTED 	141575
#define SB_U2F_SERVER_ERROR_KEY_ALREADY_REGISTERED 	141576
#define SB_U2F_SERVER_ERROR_UNKNOWN_KEY 	141577
#define SB_U2F_SERVER_ERROR_AUTH_REPLAY_DETECTED 	141578
#define SB_U2F_SERVER_ERROR_BAD_RESPONSE 	141579
#define SB_U2F_SERVER_ERROR_BAD_CLIENT_DATA 	141580
#define SB_U2F_SERVER_ERROR_BAD_SIGNATURE 	141581
#define SB_U2F_SERVER_ERROR_BAD_REGISTRATION_DATA 	141582
#define SB_U2F_SERVER_ERROR_BAD_SIGNATURE_DATA 	141583
#define SB_U2F_JSAPI_ERROR_OK 	0
#define SB_U2F_JSAPI_ERROR_OTHER_ERROR 	1
#define SB_U2F_JSAPI_ERROR_BAD_REQUEST 	2
#define SB_U2F_JSAPI_ERROR_CONFIGURATION_UNSUPPORTED 	3
#define SB_U2F_JSAPI_ERROR_DEVICE_INELIGIBLE 	4
#define SB_U2F_JSAPI_ERROR_TIMEOUT 	5
#define SB_U2F_SERVER_ERROR_CLIENT_OTHER_ERROR 	141617
#define SB_U2F_SERVER_ERROR_CLIENT_BAD_REQUEST 	141618
#define SB_U2F_SERVER_ERROR_CLIENT_CONFIGURATION_UNSUPPORTED 	141619
#define SB_U2F_SERVER_ERROR_CLIENT_DEVICE_INELIGIBLE 	141620
#define SB_U2F_SERVER_ERROR_CLIENT_TIMEOUT 	141621
#define SB_U2F_CLIENT_ERROR_DEVICE_NOT_OPEN 	141825
#define SB_U2F_CLIENT_ERROR_WINK_NOT_SUPPORTED 	141826
#define SB_U2F_CLIENT_ERROR_INVALID_DEVICE_LOCK_TIME 	141827
#define SB_U2F_CLIENT_ERROR_DEVICE_REPORTED_ERROR 	141828
#define SB_U2F_CLIENT_ERROR_NO_REGISTERED_DEVICE_FOUND 	141829
#define SB_U2F_CLIENT_ERROR_NO_U2F_DEVICES 	141830
#define SB_U2F_CLIENT_ERROR_U2F_DEVICE_NOT_CHOSEN 	141831
#define SB_U2F_CLIENT_ERROR_UNSUPPORTED_PROTOCOL_VERSION 	141832
#define SB_MAX_U2F_DEVICE_LOCK_TIME 	30000
#define SB_U2F_CMD_REGISTER 	1
#define SB_U2F_CMD_AUTHENTICATE 	2
#define SB_U2F_CMD_VERSION 	3
#define SB_U2F_CMD_CHECK_REGISTER 	4
#define SB_U2F_CMD_AUTHENTICATE_BATCH 	5
#define SB_U2F_CMD_VENDOR_FIRST 	192
#define SB_U2F_CMD_VENDOR_LAST 	255
#define SB_U2F_REGISTER_ID 	5
#define SB_U2F_REGISTER_HASH_ID 	0
#define SB_U2F_AUTH_ENFORCE 	3
#define SB_U2F_AUTH_CHECK_ONLY 	7
#define SB_U2F_AUTH_FLAG_TUP 	1
#define SB_U2F_SW_NO_ERROR 	36864
#define SB_U2F_SW_WRONG_DATA 	27264
#define SB_U2F_SW_CONDITIONS_NOT_SATISFIED 	27013
#define SB_U2F_SW_COMMAND_NOT_ALLOWED 	27014
#define SB_U2F_SW_INS_NOT_SUPPORTED 	27904
#define SB_U2F_REGISTER_TYPE 	"navigator.id.finishEnrollment"
#define SB_U2F_AUTHENTICATE_TYPE 	"navigator.id.getAssertion"
#define SB_U2F_VERSION 	"U2F_V2"
#define SB_SFU2FIndexOutOfBounds 	"Index out of bounds (%d)."
#define SB_SFU2FUnsupportedProtocolVersion 	"Unsupported U2F protocol version: %s"
#define SB_SU2FDeviceNotOpened 	"Device not opened"
#define SB_SU2FClientWinkNotSupported 	"Wink command not supported by the device"
#define SB_SU2FInvalidLockTime 	"Invalid lock time"
#define SB_SU2FKeyOwnerDeviceNotFound 	"No devices, registered on the server, have been found"
#define SB_SU2FNoU2FDevices 	"No U2F devices detected"
#define SB_SU2FDeviceNotChosen 	"U2F device not specified"
#define SB_SU2FInvalidRegistrationResponseData 	"Invalid registration response data"
#define SB_SU2FRegistrationResponseDataTooSmall 	"Registration response data is too small"
#define SB_SU2FAuthResponseDataTooSmall 	"Authentication response data is too small"
#define SB_SU2FAttestationCertificateParseFailed 	"Failed to parse attestation certificate in registration response"
#define SB_SU2FInvalidAttestationCertificateType 	"Invalid attestation certificate type"
#define SB_SU2FInvalidUserPublicKey 	"Invalid user public key"
#define SB_SU2FMissingResponseData 	"Response data is missing"
#define SB_SU2FInvalidU2FRegisterRequestMessageType 	"Invalid U2F register request message type"
#define SB_SU2FInvalidU2FRegisterResponseMessageType 	"Invalid U2F register response message type"
#define SB_SU2FInvalidU2FSignRequestMessageType 	"Invalid U2F sign request message type"
#define SB_SU2FInvalidU2FSignResponseMessageType 	"Invalid U2F sign response message type"
#define SB_SU2FStatusWrongData 	"The request was rejected due to an invalid key handle"
#define SB_SU2FStatusConditionsNotSatisfied 	"The request was rejected due to test-of-user-presence being required"
#define SB_SU2FStatusCommandNotAllowed 	"Command not allowed"
#define SB_SU2FStatusINSNotSupported 	"INS value not supported"
#define SB_SU2FStatusCode 	"U2F error, status code: "

typedef TElClassHandle TElU2FUsersHandle;

typedef TElClassHandle TElU2FUserKeyHandle;

typedef TElClassHandle TElU2FUserKeysHandle;

typedef TElClassHandle TElU2FUserHandle;

typedef TElClassHandle TElU2FJSRegisterRequestHandle;

typedef TElClassHandle TElU2FJSRegisterRequestsHandle;

typedef TElClassHandle TElU2FJSSignRequestHandle;

typedef TElClassHandle TElU2FJwkKeyHandle;

typedef uint8_t TSBU2FTransportRaw;

typedef enum
{
	uftBT = 0,
	uftBLE = 1,
	uftNFC = 2,
	uftUSB = 3
} TSBU2FTransport;

typedef uint8_t TSBU2FTransportsRaw;

typedef enum 
{
	f_uftBT = 1,
	f_uftBLE = 2,
	f_uftNFC = 4,
	f_uftUSB = 8
} TSBU2FTransports;

typedef uint8_t TSBU2FJSAPIVersionRaw;

typedef enum
{
	U2F_JSAPI_v1_0 = 0,
	U2F_JSAPI_v1_1 = 1
} TSBU2FJSAPIVersion;

#ifdef SB_USE_CLASS_TELU2FUSERS
SB_IMPORT uint32_t SB_APIENTRY TElU2FUsers_AddU2FUser(TElU2FUsersHandle _Handle, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUsers_FindU2FUser(TElU2FUsersHandle _Handle, const char * pcUserName, int32_t szUserName, TElU2FUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUsers_get_U2FUsers(TElU2FUsersHandle _Handle, int32_t Index, TElU2FUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUsers_Create(TComponentHandle AOwner, TElU2FUsersHandle * OutResult);
#endif /* SB_USE_CLASS_TELU2FUSERS */

#ifdef SB_USE_CLASS_TELU2FUSERKEY
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKey_get_KeyHandle(TElU2FUserKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKey_set_KeyHandle(TElU2FUserKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKey_get_PublicKey(TElU2FUserKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKey_set_PublicKey(TElU2FUserKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKey_get_Counter(TElU2FUserKeyHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKey_set_Counter(TElU2FUserKeyHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKey_get_Version(TElU2FUserKeyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKey_set_Version(TElU2FUserKeyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKey_get_Transports(TElU2FUserKeyHandle _Handle, TSBU2FTransportsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKey_set_Transports(TElU2FUserKeyHandle _Handle, TSBU2FTransportsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKey_Create(TElU2FUserKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELU2FUSERKEY */

#ifdef SB_USE_CLASS_TELU2FUSERKEYS
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKeys_Clear(TElU2FUserKeysHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKeys_Add(TElU2FUserKeysHandle _Handle, TElU2FUserKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKeys_Add_1(TElU2FUserKeysHandle _Handle, const uint8_t pKeyHandle[], int32_t szKeyHandle, const uint8_t pPublicKey[], int32_t szPublicKey, int32_t Counter, TElU2FUserKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKeys_Add_2(TElU2FUserKeysHandle _Handle, const uint8_t pKeyHandle[], int32_t szKeyHandle, const uint8_t pPublicKey[], int32_t szPublicKey, int32_t Counter, const char * pcVersion, int32_t szVersion, TElU2FUserKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKeys_Lookup(TElU2FUserKeysHandle _Handle, const uint8_t pKeyHandle[], int32_t szKeyHandle, const uint8_t pPublicKey[], int32_t szPublicKey, TElU2FUserKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKeys_get_Keys(TElU2FUserKeysHandle _Handle, int32_t index, TElU2FUserKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKeys_get_Count(TElU2FUserKeysHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUserKeys_Create(TElU2FUsersHandle Owner, TElU2FUserKeysHandle * OutResult);
#endif /* SB_USE_CLASS_TELU2FUSERKEYS */

#ifdef SB_USE_CLASS_TELU2FUSER
SB_IMPORT uint32_t SB_APIENTRY TElU2FUser_GetData(TElU2FUserHandle _Handle, uint8_t pBuffer[], int32_t * szBuffer, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUser_SetData(TElU2FUserHandle _Handle, const uint8_t pValue[], int32_t szValue, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUser_AddUser(TElUsersHandle Users, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUser_AddUser_1(TElU2FUserHandle _Handle, TElUsersHandle Users, const char * pcUserName, int32_t szUserName, const char * pcPassword, int32_t szPassword);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUser_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUser_get_Challenge(TElU2FUserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUser_set_Challenge(TElU2FUserHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUser_get_Keys(TElU2FUserHandle _Handle, TElU2FUserKeysHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FUser_Create(const char * pcUserName, int32_t szUserName, TElU2FUserHandle * OutResult);
#endif /* SB_USE_CLASS_TELU2FUSER */

#ifdef SB_USE_CLASS_TELU2FJSREGISTERREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSRegisterRequest_get_ApplicationID(TElU2FJSRegisterRequestHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSRegisterRequest_set_ApplicationID(TElU2FJSRegisterRequestHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSRegisterRequest_get_Challenge(TElU2FJSRegisterRequestHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSRegisterRequest_set_Challenge(TElU2FJSRegisterRequestHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSRegisterRequest_get_Version(TElU2FJSRegisterRequestHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSRegisterRequest_set_Version(TElU2FJSRegisterRequestHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSRegisterRequest_Create(TElU2FJSRegisterRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELU2FJSREGISTERREQUEST */

#ifdef SB_USE_CLASS_TELU2FJSREGISTERREQUESTS
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSRegisterRequests_Add(TElU2FJSRegisterRequestsHandle _Handle, TElU2FJSRegisterRequestHandle ARequest, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSRegisterRequests_Insert(TElU2FJSRegisterRequestsHandle _Handle, int32_t Index, TElU2FJSRegisterRequestHandle ARequest);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSRegisterRequests_Delete(TElU2FJSRegisterRequestsHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSRegisterRequests_Clear(TElU2FJSRegisterRequestsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSRegisterRequests_get_Count(TElU2FJSRegisterRequestsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSRegisterRequests_get_RegisterRequests(TElU2FJSRegisterRequestsHandle _Handle, int32_t Index, TElU2FJSRegisterRequestHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSRegisterRequests_Create(TElU2FJSRegisterRequestsHandle * OutResult);
#endif /* SB_USE_CLASS_TELU2FJSREGISTERREQUESTS */

#ifdef SB_USE_CLASS_TELU2FJSSIGNREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSSignRequest_get_ApplicationID(TElU2FJSSignRequestHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSSignRequest_set_ApplicationID(TElU2FJSSignRequestHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSSignRequest_get_Challenge(TElU2FJSSignRequestHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSSignRequest_set_Challenge(TElU2FJSSignRequestHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSSignRequest_get_KeyHandle(TElU2FJSSignRequestHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSSignRequest_set_KeyHandle(TElU2FJSSignRequestHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSSignRequest_get_Version(TElU2FJSSignRequestHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSSignRequest_set_Version(TElU2FJSSignRequestHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJSSignRequest_Create(TElU2FJSSignRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELU2FJSSIGNREQUEST */

#ifdef SB_USE_CLASS_TELU2FJWKKEY
SB_IMPORT uint32_t SB_APIENTRY TElU2FJwkKey_get_KTY(TElU2FJwkKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJwkKey_set_KTY(TElU2FJwkKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJwkKey_get_CRV(TElU2FJwkKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJwkKey_set_CRV(TElU2FJwkKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJwkKey_get_X(TElU2FJwkKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJwkKey_set_X(TElU2FJwkKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJwkKey_get_Y(TElU2FJwkKeyHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJwkKey_set_Y(TElU2FJwkKeyHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FJwkKey_Create(TElU2FJwkKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELU2FJWKKEY */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElU2FUsers_ce_ptr;
extern zend_class_entry *TElU2FUserKey_ce_ptr;
extern zend_class_entry *TElU2FUserKeys_ce_ptr;
extern zend_class_entry *TElU2FUser_ce_ptr;
extern zend_class_entry *TElU2FJSRegisterRequest_ce_ptr;
extern zend_class_entry *TElU2FJSRegisterRequests_ce_ptr;
extern zend_class_entry *TElU2FJSSignRequest_ce_ptr;
extern zend_class_entry *TElU2FJwkKey_ce_ptr;

void Register_TElU2FUsers(TSRMLS_D);
void Register_TElU2FUserKey(TSRMLS_D);
void Register_TElU2FUserKeys(TSRMLS_D);
void Register_TElU2FUser(TSRMLS_D);
void Register_TElU2FJSRegisterRequest(TSRMLS_D);
void Register_TElU2FJSRegisterRequests(TSRMLS_D);
void Register_TElU2FJSSignRequest(TSRMLS_D);
void Register_TElU2FJwkKey(TSRMLS_D);
SB_PHP_FUNCTION(SBU2FCommon, U2FFormatRequestMessageFrame);
SB_PHP_FUNCTION(SBU2FCommon, U2FGetStatusCodeFromResponseMessageFrame);
SB_PHP_FUNCTION(SBU2FCommon, U2FStatusCodeToMessage);
SB_PHP_FUNCTION(SBU2FCommon, U2FFormatRegistrationRequestMessage);
SB_PHP_FUNCTION(SBU2FCommon, U2FParseRegistrationResponseMessage);
SB_PHP_FUNCTION(SBU2FCommon, U2FFormatAuthRequestMessage);
SB_PHP_FUNCTION(SBU2FCommon, U2FParseAuthResponseMessage);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONFormatClientData);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONParseClientData);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONFormatRegistrationChallenge);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONParseRegistrationChallenge);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONFormatAuthenticationChallenge);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONParseAuthenticationChallenge);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONLoadU2FRegisterRequest);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONSaveU2FRegisterRequest);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONLoadU2FRegisterResponse);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONSaveU2FRegisterResponse);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONSaveU2FRegisterResponseError);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONLoadU2FSignRequest);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONSaveU2FSignRequest);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONLoadU2FSignResponse);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONSaveU2FSignResponse);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSONSaveU2FSignResponseError);
SB_PHP_FUNCTION(SBU2FCommon, U2FJSAPIErrorToServerError);
SB_PHP_FUNCTION(SBU2FCommon, U2FBase64UrlEncodeBytes);
SB_PHP_FUNCTION(SBU2FCommon, U2FBase64UrlDecodeBytes);
SB_PHP_FUNCTION(SBU2FCommon, U2FVerifyRegistrationSignature);
SB_PHP_FUNCTION(SBU2FCommon, U2FVerifyAuthenticationSignature);
void Register_SBU2FCommon_Constants(int module_number TSRMLS_DC);
void Register_SBU2FCommon_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_U2FCOMMON
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FFormatRequestMessageFrame(uint8_t Cmd, uint8_t P1, uint8_t P2, const uint8_t pRequestData[], int32_t szRequestData, int32_t StartIndex, int32_t Count, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FGetStatusCodeFromResponseMessageFrame(const uint8_t pResponseData[], int32_t szResponseData, int32_t StartIndex, int32_t Count, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FStatusCodeToMessage(uint16_t StatusCode, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FFormatRegistrationRequestMessage(const uint8_t pChallengeParameter[], int32_t szChallengeParameter, const uint8_t pApplicationParameter[], int32_t szApplicationParameter, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FParseRegistrationResponseMessage(const uint8_t pMsg[], int32_t szMsg, int32_t Count, uint8_t pUserPublicKey[], int32_t * szUserPublicKey, uint8_t pKeyHandle[], int32_t * szKeyHandle, uint8_t pAttestationCertificate[], int32_t * szAttestationCertificate, uint8_t pSignature[], int32_t * szSignature);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FFormatAuthRequestMessage(const uint8_t pChallengeParameter[], int32_t szChallengeParameter, const uint8_t pApplicationParameter[], int32_t szApplicationParameter, const uint8_t pKeyHandle[], int32_t szKeyHandle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FParseAuthResponseMessage(const uint8_t pMsg[], int32_t szMsg, int32_t Count, uint8_t * UserPresence, uint32_t * Counter, uint8_t pSignature[], int32_t * szSignature);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONFormatClientData(const char * pcDataType, int32_t szDataType, const char * pcChallenge, int32_t szChallenge, const char * pcOrigin, int32_t szOrigin, const char * pcCIDPubkey, int32_t szCIDPubkey, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONFormatClientData_1(const char * pcDataType, int32_t szDataType, const char * pcChallenge, int32_t szChallenge, const char * pcOrigin, int32_t szOrigin, TElU2FJwkKeyHandle CIDPubkey, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONParseClientData(const char * pcClientData, int32_t szClientData, char * pcDataType, int32_t * szDataType, char * pcChallenge, int32_t * szChallenge, char * pcOrigin, int32_t * szOrigin, char * pcCIDPubkey, int32_t * szCIDPubkey);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONFormatRegistrationChallenge(const char * pcChallenge, int32_t szChallenge, const char * pcAppID, int32_t szAppID, const char * pcVersion, int32_t szVersion, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONParseRegistrationChallenge(const char * pcRegChallenge, int32_t szRegChallenge, char * pcChallenge, int32_t * szChallenge, char * pcAppID, int32_t * szAppID, char * pcVersion, int32_t * szVersion);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONFormatAuthenticationChallenge(const char * pcChallenge, int32_t szChallenge, const char * pcAppID, int32_t szAppID, const char * pcVersion, int32_t szVersion, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONParseAuthenticationChallenge(const char * pcAuthChallenge, int32_t szAuthChallenge, char * pcChallenge, int32_t * szChallenge, char * pcAppID, int32_t * szAppID, char * pcVersion, int32_t * szVersion);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONLoadU2FRegisterRequest(const char * pcU2FRegisterRequest, int32_t szU2FRegisterRequest, char * pcAppId, int32_t * szAppId, TElU2FJSRegisterRequestsHandle RegisterRequests, TElU2FUserKeysHandle UserKeys, TElStringListHandle AppIDs, int32_t * TimeoutSeconds, int32_t * RequestID, TSBU2FJSAPIVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONSaveU2FRegisterRequest(const char * pcAppID, int32_t szAppID, TElU2FJSRegisterRequestsHandle RegisterRequests, TElU2FUserKeysHandle UserKeys, int32_t TimeoutSeconds, int32_t RequestID, TSBU2FJSAPIVersionRaw JSAPIVersion, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONLoadU2FRegisterResponse(const char * pcU2FRegisterResponse, int32_t szU2FRegisterResponse, char * pcVersion, int32_t * szVersion, char * pcClientData, int32_t * szClientData, uint8_t pRegistrationData[], int32_t * szRegistrationData, int32_t * ErrorCode, char * pcErrorMessage, int32_t * szErrorMessage, int32_t * RequestID, TSBU2FJSAPIVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONSaveU2FRegisterResponse(const char * pcVersion, int32_t szVersion, const char * pcClientData, int32_t szClientData, const uint8_t pRegistrationData[], int32_t szRegistrationData, int32_t RequestID, TSBU2FJSAPIVersionRaw JSAPIVersion, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONSaveU2FRegisterResponseError(int32_t ErrorCode, const char * pcErrorMessage, int32_t szErrorMessage, int32_t RequestID, TSBU2FJSAPIVersionRaw JSAPIVersion, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONLoadU2FSignRequest(const char * pcU2FSignRequest, int32_t szU2FSignRequest, char * pcChallenge, int32_t * szChallenge, char * pcAppId, int32_t * szAppId, TElU2FUserKeysHandle UserKeys, TElStringListHandle Challenges, TElStringListHandle AppIDs, int32_t * TimeoutSeconds, int32_t * RequestID, TSBU2FJSAPIVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONSaveU2FSignRequest(const char * pcChallenge, int32_t szChallenge, const char * pcAppID, int32_t szAppID, TElU2FUserKeysHandle UserKeys, int32_t TimeoutSeconds, int32_t RequestID, TSBU2FJSAPIVersionRaw JSAPIVersion, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONLoadU2FSignResponse(const char * pcU2FSignResponse, int32_t szU2FSignResponse, uint8_t pKeyHandle[], int32_t * szKeyHandle, uint8_t pSignatureData[], int32_t * szSignatureData, char * pcClientData, int32_t * szClientData, int32_t * ErrorCode, char * pcErrorMessage, int32_t * szErrorMessage, int32_t * RequestID, TSBU2FJSAPIVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONSaveU2FSignResponse(const uint8_t pKeyHandle[], int32_t szKeyHandle, const uint8_t pSignatureData[], int32_t szSignatureData, const char * pcClientData, int32_t szClientData, int32_t RequestID, TSBU2FJSAPIVersionRaw JSAPIVersion, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSONSaveU2FSignResponseError(int32_t ErrorCode, const char * pcErrorMessage, int32_t szErrorMessage, int32_t RequestID, TSBU2FJSAPIVersionRaw JSAPIVersion, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FJSAPIErrorToServerError(int32_t ErrorCode, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FBase64UrlEncodeBytes(const uint8_t pValue[], int32_t szValue, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FBase64UrlDecodeBytes(const char * pcValue, int32_t szValue, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FVerifyRegistrationSignature(const uint8_t pChallengeParameter[], int32_t szChallengeParameter, const uint8_t pApplicationParameter[], int32_t szApplicationParameter, const uint8_t pKeyHandle[], int32_t szKeyHandle, const uint8_t pUserPublicKey[], int32_t szUserPublicKey, const uint8_t pSignature[], int32_t szSignature, TElX509CertificateHandle AttestationCertificate, TSBPublicKeyVerificationResultRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FCommon_U2FVerifyAuthenticationSignature(const uint8_t pChallengeParameter[], int32_t szChallengeParameter, const uint8_t pApplicationParameter[], int32_t szApplicationParameter, const uint8_t pUserPublicKey[], int32_t szUserPublicKey, const uint8_t pSignature[], int32_t szSignature, uint8_t UserPresence, uint32_t Counter, TSBPublicKeyVerificationResultRaw * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_U2FCOMMON */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBU2FCOMMON */

