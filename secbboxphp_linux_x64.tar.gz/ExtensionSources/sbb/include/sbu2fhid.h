#ifndef __INC_SBU2FHID
#define __INC_SBU2FHID

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbhid.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_U2FHID 	155648
#define SB_ERROR_U2FHID_ERROR_FLAG 	2048
#define SB_U2FHID_ERROR_DEVICE_NOT_OPEN 	157697
#define SB_U2FHID_ERROR_TRANSACTION_ABORTED 	157698
#define SB_U2FHID_ERROR_INVALID_INPUT_REPORT_SIZE 	157699
#define SB_U2FHID_ERROR_INVALID_OUTPUT_REPORT_SIZE 	157700
#define SB_U2FHID_ERROR_INVALID_DATA 	157701
#define SB_U2FHID_ERROR_INPUT_DATA_TOO_LARGE 	157702
#define SB_U2FHID_ERROR_OUTPUT_DATA_TOO_LARGE 	157703
#define SB_U2FHID_ERROR_READ_FAILED 	157704
#define SB_U2FHID_ERROR_WRITE_FAILED 	157705
#define SB_U2FHID_ERROR_INVALID_CHANNEL_ID 	157706
#define SB_U2FHID_ERROR_INVALID_SEQUENCE_NUMBER 	157707
#define SB_U2FHID_ERROR_INVALID_COMMAND_RECEIVED 	157708
#define SB_U2FHID_ERROR_ERROR_COMMAND_INVALID_DATA_RECEIVED 	157709
#define SB_U2FHID_ERROR_INIT_COMMAND_INVALID_DATA_RECEIVED 	157710
#define SB_U2FHID_ERROR_INIT_COMMAND_INVALID_NONCE_RECEIVED 	157711
#define SB_U2FHID_ERROR_PING_COMMAND_INVALID_DATA_RECEIVED 	157712
#define SB_U2FHID_ERROR_SYNC_COMMAND_INVALID_NONCE_RECEIVED 	157713
#define SB_U2FHID_ERROR_WINK_COMMAND_UNEXPECTED_DATA_RECEIVED 	157714
#define SB_U2FHID_ERROR_LOCK_COMMAND_UNEXPECTED_DATA_RECEIVED 	157715
#define SB_U2FHID_ERROR_DEVICE_REPORTED_ERROR 	157716
#define SB_FIDO_USAGE_PAGE 	61904
#define SB_FIDO_USAGE_U2FHID 	1
#define SB_FIDO_USAGE_DATA_IN 	32
#define SB_FIDO_USAGE_DATA_OUT 	33
#define SB_U2FHID_CAPFLAG_WINK 	1
#define SB_U2FHID_IF_VERSION 	2
#define SB_U2FHID_TRANS_TIMEOUT 	3000
#define SB_U2FHID_ERROR_NONE 	0
#define SB_U2FHID_ERROR_INVALID_CMD 	1
#define SB_U2FHID_ERROR_INVALID_PAR 	2
#define SB_U2FHID_ERROR_INVALID_LEN 	3
#define SB_U2FHID_ERROR_INVALID_SEQ 	4
#define SB_U2FHID_ERROR_MSG_TIMEOUT 	5
#define SB_U2FHID_ERROR_CHANNEL_BUSY 	6
#define SB_U2FHID_ERROR_LOCK_REQUIRED 	10
#define SB_U2FHID_ERROR_SYNC_FAIL 	11
#define SB_U2FHID_ERROR_OTHER 	127

#ifdef __cplusplus
};	/* extern "C" */
#endif

SB_PHP_FUNCTION(SBU2FHID, U2FHIDEnumerateDevices);
SB_PHP_FUNCTION(SBU2FHID, U2FHIDInit);
SB_PHP_FUNCTION(SBU2FHID, U2FHIDSendCmd);
SB_PHP_FUNCTION(SBU2FHID, U2FHIDMessage);
SB_PHP_FUNCTION(SBU2FHID, U2FHIDPing);
SB_PHP_FUNCTION(SBU2FHID, U2FHIDWink);
SB_PHP_FUNCTION(SBU2FHID, U2FHIDLock);
SB_PHP_FUNCTION(SBU2FHID, U2FHIDSync);
void Register_SBU2FHID_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_U2FHID
SB_IMPORT uint32_t SB_APIENTRY SBU2FHID_U2FHIDEnumerateDevices(TElHIDDeviceInfoListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FHID_U2FHIDInit(TElHIDDeviceHandle Device, uint8_t * VersionInterface, uint8_t * VersionMajor, uint8_t * VersionMinor, uint8_t * VersionBuild, uint8_t * CapFlags, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FHID_U2FHIDSendCmd(TElHIDDeviceHandle Device, uint32_t CID, uint8_t Cmd, const uint8_t pData[], int32_t szData, int32_t StartIndex, int32_t Count, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FHID_U2FHIDMessage(TElHIDDeviceHandle Device, uint32_t CID, const uint8_t pData[], int32_t szData, int32_t StartIndex, int32_t Count, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBU2FHID_U2FHIDPing(TElHIDDeviceHandle Device, uint32_t CID, const uint8_t pData[], int32_t szData);
SB_IMPORT uint32_t SB_APIENTRY SBU2FHID_U2FHIDWink(TElHIDDeviceHandle Device, uint32_t CID);
SB_IMPORT uint32_t SB_APIENTRY SBU2FHID_U2FHIDLock(TElHIDDeviceHandle Device, uint32_t CID, int32_t LockTime);
SB_IMPORT uint32_t SB_APIENTRY SBU2FHID_U2FHIDSync(TElHIDDeviceHandle Device, uint32_t CID);
#endif /* SB_USE_GLOBAL_PROCS_U2FHID */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBU2FHID */

