#ifndef __INC_SBU2FSERVER
#define __INC_SBU2FSERVER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbstrutils.h"
#include "sbstringlist.h"
#include "sbutils.h"
#include "sbsharedresource.h"
#include "sbx509.h"
#include "sbu2fcommon.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElU2FServerHandle;

typedef TElU2FServerHandle ElU2FServerHandle;

#ifdef SB_USE_CLASS_TELU2FSERVER
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_GenerateRegistrationChallenge(TElU2FServerHandle _Handle, TElU2FUserHandle User, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_GenerateRegisterRequest(TElU2FServerHandle _Handle, TElU2FUserHandle User, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_GenerateRegisterRequest_1(TElU2FServerHandle _Handle, TElU2FUserHandle User, TSBU2FJSAPIVersionRaw JSAPIVersion, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_VerifyRegistrationResponse(TElU2FServerHandle _Handle, TElU2FUserHandle User, const char * pcVersion, int32_t szVersion, const char * pcClientData, int32_t szClientData, const uint8_t pRegistrationData[], int32_t szRegistrationData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_VerifyRegistrationResponse_1(TElU2FServerHandle _Handle, TElU2FUserHandle User, const char * pcU2FRegisterResponse, int32_t szU2FRegisterResponse, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_GenerateAuthChallenge(TElU2FServerHandle _Handle, TElU2FUserHandle User, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_GenerateAuthRequest(TElU2FServerHandle _Handle, TElU2FUserHandle User, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_GenerateAuthRequest_1(TElU2FServerHandle _Handle, TElU2FUserHandle User, TSBU2FJSAPIVersionRaw JSAPIVersion, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_VerifyAuthResponse(TElU2FServerHandle _Handle, TElU2FUserHandle User, const char * pcClientData, int32_t szClientData, const uint8_t pAuthData[], int32_t szAuthData, const uint8_t pKeyHandle[], int32_t szKeyHandle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_VerifyAuthResponse_1(TElU2FServerHandle _Handle, TElU2FUserHandle User, const char * pcU2FSignResponse, int32_t szU2FSignResponse, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_get_ApplicationID(TElU2FServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_set_ApplicationID(TElU2FServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_get_Users(TElU2FServerHandle _Handle, TElU2FUsersHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_get_OnCertificateValidate(TElU2FServerHandle _Handle, TSBCertificateValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_set_OnCertificateValidate(TElU2FServerHandle _Handle, TSBCertificateValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElU2FServer_Create(TComponentHandle AOwner, TElU2FServerHandle * OutResult);
#endif /* SB_USE_CLASS_TELU2FSERVER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElU2FServer_ce_ptr;

void Register_TElU2FServer(TSRMLS_D);
void Register_SBU2FServer_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBU2FSERVER */

