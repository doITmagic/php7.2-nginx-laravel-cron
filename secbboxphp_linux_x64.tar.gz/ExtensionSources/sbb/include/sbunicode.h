#ifndef __INC_SBUNICODE
#define __INC_SBUNICODE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbchsconv.h"
#include "sbchsconvcharsets.h"
#include "sbchscjk.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElUnicodeConverterHandle;

#ifdef SB_USE_CLASS_TELUNICODECONVERTER
SB_IMPORT uint32_t SB_APIENTRY TElUnicodeConverter_StrToUtf8(TElUnicodeConverterHandle _Handle, const char * pcSource, int32_t szSource, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUnicodeConverter_Utf8ToStr(TElUnicodeConverterHandle _Handle, const uint8_t pSource[], int32_t szSource, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUnicodeConverter_StrToWideStr(TElUnicodeConverterHandle _Handle, const char * pcSource, int32_t szSource, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUnicodeConverter_WideStrToStr(TElUnicodeConverterHandle _Handle, const uint8_t pSource[], int32_t szSource, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUnicodeConverter_Create(TElUnicodeConverterHandle * OutResult);
#endif /* SB_USE_CLASS_TELUNICODECONVERTER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElUnicodeConverter_ce_ptr;

void Register_TElUnicodeConverter(TSRMLS_D);
SB_PHP_FUNCTION(SBUnicode, CreateUnicodeStringConverter);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_UNICODE
SB_IMPORT uint32_t SB_APIENTRY SBUnicode_CreateUnicodeStringConverter(TElStringConverterHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_UNICODE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBUNICODE */

