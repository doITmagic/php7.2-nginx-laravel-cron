#ifndef __INC_SBUNIVERSALCERTSTORAGE
#define __INC_SBUNIVERSALCERTSTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbconstants.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstringlist.h"
#include "sbx509.h"
#include "sbrdn.h"
#include "sbcryptoprov.h"
#include "sbcustomcrypto.h"
#include "sbpublickeycrypto.h"
#include "sbuniversalkeystorage.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_KS_MOD_CERTSTORAGE 	512
#define SB_ERROR_KS_CERT_NOT_FOUND 	152065
#define SB_ERROR_KS_OBJECT_NOT_A_CERT 	152066
#define SB_ERROR_KS_FAILED_TO_ADD_KEY 	152067
#define SB_ERROR_KS_FAILED_TO_ADD_CERT 	152068
#define SB_ERROR_KS_UNSUPPORTED_CERT_ALGORITHM 	152069
#define SB_SCertNotFound 	"Certificate with the provided ID not found in the storage"
#define SB_SObjectNotACert 	"Object is not a certificate"
#define SB_SFailedToAddKey 	"Failed to add key"
#define SB_SFailedToAddCert 	"Failed to add certificate"

typedef TElClassHandle TElUniversalCertStorageHandle;

#ifdef SB_USE_CLASS_TELUNIVERSALCERTSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_Add(TElUniversalCertStorageHandle _Handle, TElX509CertificateHandle Cert, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_Add_1(TElUniversalCertStorageHandle _Handle, TElX509CertificateHandle Cert, int8_t CopyPrivateKey, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_Add_2(TElUniversalCertStorageHandle _Handle, TElX509CertificateHandle Cert, int8_t CopyPrivateKey, const uint8_t pKeyID[], int32_t szKeyID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_Remove(TElUniversalCertStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_Clear(TElUniversalCertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_Find(TElUniversalCertStorageHandle _Handle, const uint8_t pKeyID[], int32_t szKeyID, int32_t StartFrom, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_Find_1(TElUniversalCertStorageHandle _Handle, const uint8_t pKeyID[], int32_t szKeyID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_Find_2(TElUniversalCertStorageHandle _Handle, TElRelativeDistinguishedNameHandle Subject, int32_t StartFrom, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_Find_3(TElUniversalCertStorageHandle _Handle, TElRelativeDistinguishedNameHandle Subject, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_FindCertByAttribute(TElUniversalCertStorageHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int32_t StartFrom, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_GetCertAttribute(TElUniversalCertStorageHandle _Handle, int32_t Index, const uint8_t pAttrID[], int32_t szAttrID, int8_t * Protected, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_SetCertAttribute(TElUniversalCertStorageHandle _Handle, int32_t Index, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int8_t Protected);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_get_Certificates(TElUniversalCertStorageHandle _Handle, int32_t Index, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_get_CertificateIDs(TElUniversalCertStorageHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_get_Count(TElUniversalCertStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorage_Create(TComponentHandle AOwner, TElUniversalCertStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELUNIVERSALCERTSTORAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElUniversalCertStorage_ce_ptr;

void Register_TElUniversalCertStorage(TSRMLS_D);
void Register_SBUniversalCertStorage_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBUNIVERSALCERTSTORAGE */

