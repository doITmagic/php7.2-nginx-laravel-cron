#ifndef __INC_SBUNIVERSALCERTSTORAGEEX
#define __INC_SBUNIVERSALCERTSTORAGEEX

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbconstants.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbx509.h"
#include "sbx509ex.h"
#include "sbrdn.h"
#include "sbcryptoprov.h"
#include "sbcustomcrypto.h"
#include "sbpublickeycrypto.h"
#include "sbuniversalkeystorage.h"
#include "sbuniversalcertstorage.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SUnsupportedCertAlgorithm 	"Unsupported certificate algorithm"

typedef TElClassHandle TElUniversalCertStorageExHandle;

#ifdef SB_USE_CLASS_TELUNIVERSALCERTSTORAGEEX
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorageEx_CreateCertificate(TElUniversalCertStorageExHandle _Handle, TElX509CertificateExHandle CertTpl, int32_t PublicKeyAlgorithm, int32_t HashAlgorithm, int32_t Bits, const uint8_t pKeyID[], int32_t szKeyID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorageEx_CreateCertificate_1(TElUniversalCertStorageExHandle _Handle, TElX509CertificateExHandle CertTpl, int32_t CertAlgorithm, int32_t Bits, const uint8_t pKeyID[], int32_t szKeyID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorageEx_CreateCertificate_2(TElUniversalCertStorageExHandle _Handle, TElX509CertificateExHandle CertTpl, int32_t Bits, const uint8_t pKeyID[], int32_t szKeyID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorageEx_CreateCertificate_3(TElUniversalCertStorageExHandle _Handle, TElX509CertificateExHandle CertTpl, int32_t Bits, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorageEx_CreateCertificate_4(TElUniversalCertStorageExHandle _Handle, TElX509CertificateHandle Parent, TElX509CertificateExHandle CertTpl, int32_t PublicKeyAlgorithm, int32_t HashAlgorithm, int32_t Bits, const uint8_t pKeyID[], int32_t szKeyID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorageEx_CreateCertificate_5(TElUniversalCertStorageExHandle _Handle, TElX509CertificateHandle Parent, TElX509CertificateExHandle CertTpl, int32_t CertAlgorithm, int32_t Bits, const uint8_t pKeyID[], int32_t szKeyID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorageEx_CreateCertificate_6(TElUniversalCertStorageExHandle _Handle, TElX509CertificateHandle Parent, TElX509CertificateExHandle CertTpl, int32_t Bits, const uint8_t pKeyID[], int32_t szKeyID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalCertStorageEx_Create(TComponentHandle AOwner, TElUniversalCertStorageExHandle * OutResult);
#endif /* SB_USE_CLASS_TELUNIVERSALCERTSTORAGEEX */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElUniversalCertStorageEx_ce_ptr;

void Register_TElUniversalCertStorageEx(TSRMLS_D);
void Register_SBUniversalCertStorageEx_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBUNIVERSALCERTSTORAGEEX */

