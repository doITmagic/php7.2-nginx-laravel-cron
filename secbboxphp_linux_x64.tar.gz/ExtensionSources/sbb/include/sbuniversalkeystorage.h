#ifndef __INC_SBUNIVERSALKEYSTORAGE
#define __INC_SBUNIVERSALKEYSTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbcryptoprov.h"
#include "sbcryptoprovmanager.h"
#include "sbcryptoprovutils.h"
#include "sbstrutils.h"
#include "sbstringlist.h"
#include "sbcustomcrypto.h"
#include "sbpublickeycrypto.h"
#include "sbsymmetriccrypto.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_KEYSTORAGE 	151552
#define SB_ERROR_KS_KEY_NOT_FOUND 	151553
#define SB_ERROR_KS_UNSUPPORTED_KEY_TYPE 	151554
#define SB_ERROR_KS_OBJECT_NOT_FOUND 	151555
#define SB_ERROR_KS_FAILED_TO_ADD_OBJECT 	151556

typedef TElClassHandle TElUniversalKeyStorageHandle;

#ifdef SB_USE_CLASS_TELUNIVERSALKEYSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_ListStorages(TElCustomCryptoProviderHandle CryptoProvider, TElStringListHandle IDList, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_ListStorages_1(TElUniversalKeyStorageHandle _Handle, TElCustomCryptoProviderHandle CryptoProvider, TElStringListHandle IDList, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_CreateNew(TElUniversalKeyStorageHandle _Handle, int8_t Persistent);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_CreateNew_1(TElUniversalKeyStorageHandle _Handle, int8_t Persistent, const char * pcStorageID, int32_t szStorageID);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_Open(TElUniversalKeyStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_Open_1(TElUniversalKeyStorageHandle _Handle, const char * pcStorageID, int32_t szStorageID);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_Close(TElUniversalKeyStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_Commit(TElUniversalKeyStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_Refresh(TElUniversalKeyStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_IsTransactional(TElUniversalKeyStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_AddKey(TElUniversalKeyStorageHandle _Handle, TElKeyMaterialHandle Key, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_AddKey_1(TElUniversalKeyStorageHandle _Handle, TElKeyMaterialHandle Key, int8_t CopyPrivateKey, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_AddKey_2(TElUniversalKeyStorageHandle _Handle, TElKeyMaterialHandle Key, int8_t CopyPrivateKey, const uint8_t pKeyID[], int32_t szKeyID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_CreateKey(TElUniversalKeyStorageHandle _Handle, int32_t Algorithm, int32_t Bits, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_CreateKey_1(TElUniversalKeyStorageHandle _Handle, int32_t Algorithm, int32_t Bits, const uint8_t pKeyID[], int32_t szKeyID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_RemoveKey(TElUniversalKeyStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_ClearKeys(TElUniversalKeyStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_FindKey(TElUniversalKeyStorageHandle _Handle, const uint8_t pKeyID[], int32_t szKeyID, int32_t StartFrom, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_FindKey_1(TElUniversalKeyStorageHandle _Handle, const uint8_t pKeyID[], int32_t szKeyID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_FindKeyByAttribute(TElUniversalKeyStorageHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int32_t StartFrom, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_AddObject(TElUniversalKeyStorageHandle _Handle, const uint8_t pObjectValue[], int32_t szObjectValue, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_AddObject_1(TElUniversalKeyStorageHandle _Handle, const uint8_t pObjectValue[], int32_t szObjectValue, const uint8_t pKeyID[], int32_t szKeyID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_RemoveObject(TElUniversalKeyStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_ClearObjects(TElUniversalKeyStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_FindObject(TElUniversalKeyStorageHandle _Handle, const uint8_t pKeyID[], int32_t szKeyID, int32_t StartFrom, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_FindObject_1(TElUniversalKeyStorageHandle _Handle, const uint8_t pKeyID[], int32_t szKeyID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_FindObjectByAttribute(TElUniversalKeyStorageHandle _Handle, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int32_t StartFrom, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_GetKeyAttribute(TElUniversalKeyStorageHandle _Handle, int32_t Index, const uint8_t pAttrID[], int32_t szAttrID, int8_t * Protected, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_SetKeyAttribute(TElUniversalKeyStorageHandle _Handle, int32_t Index, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int8_t Protected);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_GetObjectAttribute(TElUniversalKeyStorageHandle _Handle, int32_t Index, const uint8_t pAttrID[], int32_t szAttrID, int8_t * Protected, const uint8_t pDefault[], int32_t szDefault, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_SetObjectAttribute(TElUniversalKeyStorageHandle _Handle, int32_t Index, const uint8_t pAttrID[], int32_t szAttrID, const uint8_t pAttrValue[], int32_t szAttrValue, int8_t Protected);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_get_Keys(TElUniversalKeyStorageHandle _Handle, int32_t Index, TElKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_get_KeyCount(TElUniversalKeyStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_get_KeyIDs(TElUniversalKeyStorageHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_get_Objects(TElUniversalKeyStorageHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_get_ObjectCount(TElUniversalKeyStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_get_ID(TElUniversalKeyStorageHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_get_CryptoProvider(TElUniversalKeyStorageHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_set_CryptoProvider(TElUniversalKeyStorageHandle _Handle, TElCustomCryptoProviderHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_get_DefaultECCurve(TElUniversalKeyStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_set_DefaultECCurve(TElUniversalKeyStorageHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElUniversalKeyStorage_Create(TComponentHandle AOwner, TElUniversalKeyStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELUNIVERSALKEYSTORAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElUniversalKeyStorage_ce_ptr;

void Register_TElUniversalKeyStorage(TSRMLS_D);
void Register_SBUniversalKeyStorage_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBUNIVERSALKEYSTORAGE */

