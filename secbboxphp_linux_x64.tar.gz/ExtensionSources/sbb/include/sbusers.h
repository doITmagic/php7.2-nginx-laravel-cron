#ifndef __INC_SBUSERS
#define __INC_SBUSERS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbsharedresource.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbrandom.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SUserExists 	"User already exists"
#define SB_SCannotCreateNewUser 	"Can not create new user. Use OnCreateNewUser to create proper user class"
#define SB_SCanNotLoadUsers 	"Can not load users data. FilePassword not set"
#define SB_SInvalidUserFile 	"Invalid users file"
#define SB_SCanNotSaveUsers 	"Can not save users data. FilePassword not set"
#define SB_rsCannotCreateFile 	"Cannot create file \"%s\""
#define SB_rsCannotOpenFile 	"Cannot open file \"%s\""
#define SB_SCannotEditUser 	"Lock user with TElUsers.LockUser before editing"
#define SB_SInvalidUserClass 	"Invalid user class"

typedef TElClassHandle TElUsersHandle;

typedef TElClassHandle TElCustomUserHandle;

typedef TElClassHandle TElCustomUserClassHandle;

typedef void (SB_CALLBACK *TSBOnCreateNewUserEvent)(void * _ObjectData, TElCustomUserHandle * OutResult);

#ifdef SB_USE_CLASS_TELUSERS
SB_IMPORT uint32_t SB_APIENTRY TElUsers_AddUser(TElUsersHandle _Handle, TElCustomUserHandle User);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_Clear(TElUsersHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_DeleteUser(TElUsersHandle _Handle, const char * pcUserName, int32_t szUserName);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_FindUser(TElUsersHandle _Handle, const char * pcUserName, int32_t szUserName, TElCustomUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_IsValidPassword(TElUsersHandle _Handle, const char * pcAUserName, int32_t szAUserName, const char * pcAPassword, int32_t szAPassword, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_Lock(TElUsersHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_Unlock(TElUsersHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_LockUser(TElUsersHandle _Handle, TElCustomUserHandle User);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_UnlockUser(TElUsersHandle _Handle, TElCustomUserHandle User);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_Load(TElUsersHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_Load_1(TElUsersHandle _Handle, const char * pcAFileName, int32_t szAFileName, const char * pcAPassword, int32_t szAPassword);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_Save(TElUsersHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_Save_1(TElUsersHandle _Handle, const char * pcAFileName, int32_t szAFileName, const char * pcAPassword, int32_t szAPassword);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_LoadFromStream(TElUsersHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_LoadFromStream_1(TElUsersHandle _Handle, TStreamHandle Stream, const char * pcAPassword, int32_t szAPassword);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_SaveToStream(TElUsersHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_SaveToStream_1(TElUsersHandle _Handle, TStreamHandle Stream, const char * pcAPassword, int32_t szAPassword);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_get_Users(TElUsersHandle _Handle, int32_t Index, TElCustomUserHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_get_Count(TElUsersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_get_FileName(TElUsersHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_set_FileName(TElUsersHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_get_FilePassword(TElUsersHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_set_FilePassword(TElUsersHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_get_OnCreateNewUser(TElUsersHandle _Handle, TSBOnCreateNewUserEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_set_OnCreateNewUser(TElUsersHandle _Handle, TSBOnCreateNewUserEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElUsers_Create(TComponentHandle AOwner, TElUsersHandle * OutResult);
#endif /* SB_USE_CLASS_TELUSERS */

#ifdef SB_USE_CLASS_TELCUSTOMUSER
SB_IMPORT uint32_t SB_APIENTRY TElCustomUser_GetData(TElCustomUserHandle _Handle, uint8_t pBuffer[], int32_t * szBuffer, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY TElCustomUser_SetData(TElCustomUserHandle _Handle, const uint8_t pValue[], int32_t szValue, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElCustomUser_IsValidPassword(TElCustomUserHandle _Handle, const char * pcAPassword, int32_t szAPassword, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomUser_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomUser_get_Name(TElCustomUserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomUser_get_Password(TElCustomUserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomUser_set_Password(TElCustomUserHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElCustomUser_get_UserData(TElCustomUserHandle _Handle, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomUser_set_UserData(TElCustomUserHandle _Handle, TObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomUser_Create(const char * pcUserName, int32_t szUserName, TElCustomUserHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMUSER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElCustomUserClass_ce_ptr;
extern zend_class_entry *TElUsers_ce_ptr;
extern zend_class_entry *TElCustomUser_ce_ptr;

void SB_CALLBACK TSBOnCreateNewUserEventRaw(void * _ObjectData, TElCustomUserHandle * OutResult);
void Register_TElUsers(TSRMLS_D);
void Register_TElCustomUser(TSRMLS_D);
void Register_SBUsers_Constants(int module_number TSRMLS_DC);
void Register_SBUsers_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBUSERS */

