#ifndef __INC_SBUTILS
#define __INC_SBUTILS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbconstants.h"
#include "sbmath.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SBB_VERSION_NUMBER 	"16.0.320.0"
#define SBB_VERSION_RELEASE_NUMBER 	"16"
#define SBB_VERSION_UNIQUE_ID 	"B02241FC518928E1"
#define SBB_HOMEPAGE 	"https://www.SecureBlackbox.com/"
#define SB_ERROR_FACILITY_INTERNAL 	256
#define SB_ERROR_FACILITY_CRYPTO_BASE 	512
#define SB_ERROR_FACILITY_PDF 	720896
#define SB_ERROR_FACILITY_XML 	724992
#define SB_ERROR_FACILITY_SOAP 	729088
#define SB_ERROR_FACILITY_OFFICE 	733184
#define SB_ERROR_LICENSE_TRIAL_RESTRICTION 	257
#define SB_ERROR_LICENSE_FUNCTION_NOT_LICENSED 	258
#define SB_ERROR_LICENSE_KEY_EXPIRED 	259
#define SB_ERROR_LICENSE_KEY_NOT_SET 	260
#define SB_ERROR_LICENSE_KEY_INVALID 	261
#define SB_ERROR_LICENSE_KEY_BIZCRYPTO 	262
#define SB_ERROR_LICENSE_KEY_NOT_BIZCRYPTO 	263
#define SB_ERROR_LICENSE_KEY_CANNOT_BE_USED_WITH_APP 	264
#define SB_ERROR_CRYPTO_NOT_IMPLEMENTED 	513
#define SB_ERROR_CRYPTO_RSA_ANTITIMING_NOT_INIT 	514
#define SB_ERROR_CRYPTO_DSA_KEY_NOT_LOADED 	515
#define SB_ERROR_CRYPTO_DSA_KEY_FORMAT_INVALID 	516
#define SB_COREDLL 	"coredll.dll"
#define SB_OLE32 	"ole32.dll"
#define SB_KERNEL32 	"kernel32.dll"
#define SB_NTDLL 	"ntdll.dll"
#define SB_SRegexUnsupported 	"Regular expressions in masks are not supported in this version of compiler / platform"
#define SB_SInvalidInputSize 	"Invalid input block size"
#define SB_SInvalidKeySize 	"Invalid key size [%d bits]"
#define SB_SInvalidUInt16BufferOffset 	"Cannot get 2 bytes at offset %d (buffer size is %d)"
#define SB_SInvalidUInt32BufferOffset 	"Cannot get 4 bytes at offset %d (buffer size is %d)"
#define SB_SInvalidOID 	"Invalid object identifier"
#define SB_sOutputBufferTooSmall 	"Output buffer too small"
#define SB_SUnicodeNotInitialized 	"Unicode module is not initialized. Please execute a SBUnicode.Unit.Initialize() call at the very start of your project."
#define SB_SUnsupportedCharset 	"Unsupported charset"
#define SB_SOperationCancelled 	"Synchronous operation has been cancelled"
#define SB_SArrayIndexOutOfBounds 	"Array index is out of bounds"
#define SB_SArrayIndexOutOfBoundsExt 	"Array index %d is out of bounds [0, %d]"
#define SB_SArrayIndexOutOfBoundsSrc 	"Array source index %d is out of bounds [0, %d]"
#define SB_SArrayIndexOutOfBoundsDst 	"Array destination index %d is out of bounds [0, %d]"
#define SB_SArrayStartOutOfBounds 	"Range start %d is out of array bounds [0, %d]"
#define SB_SArrayRangeOutOfBounds 	"Range [%d, %d] is out of array bounds [0, %d]"
#define SB_SStringIndexOutOfBounds 	"String index is out of bounds"
#define SB_SArrayLengthOutOfBounds 	"Array length is out of bounds"
#define SB_SArrayLengthOutOfBoundsExt 	"Array length %d is out of bounds"
#define SB_SBufferCannotBeNull 	"Buffer cannot be empty"
#define SB_SStringCannotBeNull 	"String cannot be empty"
#define SB_SLicenseKeyNotSet 	"SecureBlackbox license key is not set. Please pass production or evaluation license key to SBUtils.SetLicenseKey function in initialization section of your application.\r\nIf this message appears in design-time, place TElSBLicenseManager component on the form and put the key to LicenseKey property.\r\nEvaluation license key can be found in <SecureBlackbox folder>\\LicenseKey.txt file"
#define SB_SInvalidDateToken 	"Invalid date token (%s)"
#define SB_SInvalidTimeToken 	"Invalid time token (%s)"
#define SB_SOldLicenseKey 	"Provided license key is valid for old version of SecureBlackbox and not the current one. Please upgrade your license."
#define SB_SUnknownLicenseKey 	"Provided license key is valid for version of SecureBlackbox, other than current one. Please check the version of SecureBlackbox and your license."
#define SB_SLicenseKeyExpired 	"Time-limited SecureBlackbox license key has expired. Please use evaluation license key to continue evaluation."
#define SB_SLicenseTypeNotEnabled 	"Your SecureBlackbox license key doesn\'t enable the requested functionality. Please check if you have a license for the components that you are trying to use."
#define SB_SBadOrOldLicenseKey 	"Provided license key is invalid or is valid for version of SecureBlackbox, other than current one. Please check that the license key is pasted correctly and your license covers current SecureBlackbox version."
#define SB_SAutomaticKeyExpired 	"Your time-limited SecureBlackbox license key has expired. Please use evaluation license key to continue evaluation or request license prolongation via the HelpDesk system."
#define SB_SBadLicenseKeyFormat 	"Bad SecureBlackbox license key format. Please re-check that you\'ve copied and pasted your (or evaluation) license key correctly to your application code. A correct license key is a very long line of letters and numbers (512 characters altogether), which should be passed to the SetLicenseKey() call unchanged and in its entirety."
#define SB_SLicenseKeyCannotBeUsedWithApp 	"Provided license key cannot be used with this application. Please re-check that all your license conditions are met."
#define SB_SSeekOffsetRangeError 	"Seek offset is out of Int32 range"
#define SB_SBase32InvalidDataSize 	"Input data size must be multiple of 8"
#define SB_SBase32InvalidData 	"Input buffer contains invalid data that is not base32 encoded"
#define SB_SWS_EDITION_ALL 	0
#define SB_SWS_EDITION_FIRST 	1
#define SB_SWS_EDITION_VCL 	1
#define SB_SWS_EDITION_NET 	2
#define SB_SWS_EDITION_JAVA 	3
#define SB_SWS_EDITION_CPP 	4
#define SB_SWS_EDITION_PHP 	5
#define SB_SWS_EDITION_NG 	6
#define SB_SWS_EDITION_LAST 	6
#define SB_SWS_PACKAGE_ALL 	0
#define SB_SWS_PACKAGE_FIRST 	1
#define SB_SWS_PACKAGE_PKI 	1
#define SB_SWS_PACKAGE_PGP 	2
#define SB_SWS_PACKAGE_MIME 	3
#define SB_SWS_PACKAGE_XML 	4
#define SB_SWS_PACKAGE_PDF 	5
#define SB_SWS_PACKAGE_ZIP 	6
#define SB_SWS_PACKAGE_SSL_CLI 	7
#define SB_SWS_PACKAGE_SSL_SRV 	8
#define SB_SWS_PACKAGE_FTPS_CLI 	9
#define SB_SWS_PACKAGE_FTPS_SRV 	10
#define SB_SWS_PACKAGE_HTTPS_CLI 	11
#define SB_SWS_PACKAGE_HTTPS_SRV 	12
#define SB_SWS_PACKAGE_SSH_CLI 	13
#define SB_SWS_PACKAGE_SSH_SRV 	14
#define SB_SWS_PACKAGE_SFTP_CLI 	15
#define SB_SWS_PACKAGE_SFTP_SRV 	16
#define SB_SWS_PACKAGE_WEBDAV_CLI 	17
#define SB_SWS_PACKAGE_WEBDAV_SRV 	18
#define SB_SWS_PACKAGE_MAIL 	19
#define SB_SWS_PACKAGE_CLOUD 	20
#define SB_SWS_PACKAGE_OFFICE 	21
#define SB_SWS_PACKAGE_EDI 	22
#define SB_SWS_PACKAGE_LDAP 	23
#define SB_SWS_PACKAGE_XMPP 	24
#define SB_SWS_PACKAGE_SAML 	25
#define SB_SWS_PACKAGE_DC 	26
#define SB_SWS_PACKAGE_LAST 	26
#define SB_SWS_VERSION_FIRST 	1
#define SB_SWS_VERSION_FIRST_ENABLED 	16
#define SB_SWS_VERSION_LAST_ENABLED 	16
#define SB_SWS_VERSION_LAST 	127
#define SB_SWS_VF_BAD_PACKAGES 	1
#define SB_SWS_VF_BAD_EDITIONS 	2
#define SB_SWS_VF_BAD_USE_TIME 	4
#define SB_SWS_VF_BAD_BUILT_TIME 	8
#define SB_SWS_VF_BAD_SCOPE 	16
#define SB_SWS_VF_BAD_LICENSEE 	32
#define SB_SWS_VF_BAD_ROOT 	64
#define SB_SWS_VF_BAD_EXECUTABLES 	128

typedef TComponentHandle TSBComponentBaseHandle;

typedef TComponentHandle TSBControlBaseHandle;

typedef TObjectHandle TSBDisposableBaseHandle;

typedef TListHandle TElListHandle;

typedef TListHandle TElIntegerListHandle;

typedef TElClassHandle TElStringListHandle;

typedef TElClassHandle TElByteArrayListHandle;

typedef TElClassHandle TSBObjectListHandle;

typedef TElClassHandle TElCustomExceptionHandlerHandle;

typedef TElClassHandle TElStandardExceptionHandlerHandle;

typedef TElClassHandle TElDebugExceptionHandlerHandle;

typedef TElClassHandle TElCustomGlobalLoggerHandle;

typedef TElClassHandle TElStandardGlobalLoggerHandle;

typedef TElClassHandle TElByteArrayManagerHandle;

typedef TElClassHandle TElIntegerArrayHandle;

typedef void (SB_CALLBACK *TSBTextDataEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pTextLine[], int32_t szTextLine);

typedef void (SB_CALLBACK *TSBProgressEvent)(void * _ObjectData, TObjectHandle Sender, int64_t Total, int64_t Current, int8_t * Cancel);

typedef void (SB_CALLBACK *TSBProgressFunc)(void * _ObjectData, int64_t Total, int64_t Current, void * Data, int8_t * Cancel);

typedef void (SB_CALLBACK *TElMessageLoopEvent)(void * _ObjectData, int8_t * OutResult);

typedef uint8_t TSBTraceDestinationRaw;

typedef enum
{
	tdDefault = 0,
	tdDebug = 1,
	tdTrace = 2,
	tdStdErr = 3,
	tdStdOut = 4,
	tdFile = 5,
	tdNone = 6
} TSBTraceDestination;

typedef uint8_t TSBGlobalLoggerLevelRaw;

typedef enum
{
	glmNone = 0,
	glmError = 1,
	glmWarning = 2,
	glmInfo = 3,
	glmDebug = 4
} TSBGlobalLoggerLevel;

#ifdef SB_USE_CLASS_TELSTRINGLIST
SB_IMPORT uint32_t SB_APIENTRY TElStringList_ValueByIdx(TElStringListHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElStringList_Create(const char * pcListText, int32_t szListText, TElStringListHandle * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY TElStringList_Create(TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStringList_Create_1(const char * pcListText, int32_t szListText, TElStringListHandle * OutResult);
#endif
#endif /* SB_USE_CLASS_TELSTRINGLIST */

#ifdef SB_USE_CLASS_TELBYTEARRAYLIST
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayList_Add(TElByteArrayListHandle _Handle, const uint8_t pS[], int32_t szS, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayList_AddRange(TElByteArrayListHandle _Handle, TElByteArrayListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayList_Assign(TElByteArrayListHandle _Handle, TElByteArrayListHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayList_Clear(TElByteArrayListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayList_Delete(TElByteArrayListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayList_IndexOf(TElByteArrayListHandle _Handle, const uint8_t pS[], int32_t szS, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayList_Insert(TElByteArrayListHandle _Handle, int32_t Index, const uint8_t pS[], int32_t szS);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayList_Sort(TElByteArrayListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayList_get_Capacity(TElByteArrayListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayList_set_Capacity(TElByteArrayListHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayList_get_Count(TElByteArrayListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayList_get_Item(TElByteArrayListHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayList_set_Item(TElByteArrayListHandle _Handle, int32_t Index, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayList_Create(TElByteArrayListHandle * OutResult);
#endif /* SB_USE_CLASS_TELBYTEARRAYLIST */

#ifdef SB_USE_CLASS_TSBOBJECTLIST
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_Add(TSBObjectListHandle _Handle, TObjectHandle AObject, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_Add_1(TListHandle _Handle, void * Item, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_Remove(TSBObjectListHandle _Handle, TObjectHandle AObject, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_Remove_1(TListHandle _Handle, void * Item, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_IndexOf(TSBObjectListHandle _Handle, TObjectHandle AObject, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_IndexOf_1(TListHandle _Handle, void * Item, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_Insert(TSBObjectListHandle _Handle, int32_t Index, TObjectHandle AObject);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_Insert_1(TListHandle _Handle, int32_t Index, void * Item);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_FindInstanceOf(TSBObjectListHandle _Handle, TClassHandle AClass, int8_t AExact, int32_t AStartAt, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_Extract(TSBObjectListHandle _Handle, TObjectHandle Item, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_Extract_1(TListHandle _Handle, void * item, void * * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_get_OwnsObjects(TSBObjectListHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_set_OwnsObjects(TSBObjectListHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_get_Items_TObject(TSBObjectListHandle _Handle, int32_t Index, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_set_Items_TObject(TSBObjectListHandle _Handle, int32_t Index, TObjectHandle AObject);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_Create(TSBObjectListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TSBObjectList_Create_1(int8_t AOwnsObjects, TSBObjectListHandle * OutResult);
#endif /* SB_USE_CLASS_TSBOBJECTLIST */

#ifdef SB_USE_CLASS_TELCUSTOMEXCEPTIONHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElCustomExceptionHandler_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMEXCEPTIONHANDLER */

#ifdef SB_USE_CLASS_TELSTANDARDEXCEPTIONHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElStandardExceptionHandler_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELSTANDARDEXCEPTIONHANDLER */

#ifdef SB_USE_CLASS_TELDEBUGEXCEPTIONHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElDebugExceptionHandler_get_Destination(TElDebugExceptionHandlerHandle _Handle, TSBTraceDestinationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDebugExceptionHandler_set_Destination(TElDebugExceptionHandlerHandle _Handle, TSBTraceDestinationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElDebugExceptionHandler_Create(TElDebugExceptionHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELDEBUGEXCEPTIONHANDLER */

#ifdef SB_USE_CLASS_TELCUSTOMGLOBALLOGGER
SB_IMPORT uint32_t SB_APIENTRY TElCustomGlobalLogger_LogEntry(TElCustomGlobalLoggerHandle _Handle, TSBGlobalLoggerLevelRaw Level, const char * pcSource, int32_t szSource, const char * pcLine, int32_t szLine);
SB_IMPORT uint32_t SB_APIENTRY TElCustomGlobalLogger_get_Enabled(TElCustomGlobalLoggerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomGlobalLogger_set_Enabled(TElCustomGlobalLoggerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomGlobalLogger_get_LogLevel(TElCustomGlobalLoggerHandle _Handle, TSBGlobalLoggerLevelRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomGlobalLogger_set_LogLevel(TElCustomGlobalLoggerHandle _Handle, TSBGlobalLoggerLevelRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCustomGlobalLogger_Create(TElCustomGlobalLoggerHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMGLOBALLOGGER */

#ifdef SB_USE_CLASS_TELSTANDARDGLOBALLOGGER
SB_IMPORT uint32_t SB_APIENTRY TElStandardGlobalLogger_get_UpdateTime(TElStandardGlobalLoggerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStandardGlobalLogger_set_UpdateTime(TElStandardGlobalLoggerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElStandardGlobalLogger_get_Destination(TElStandardGlobalLoggerHandle _Handle, TSBTraceDestinationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStandardGlobalLogger_set_Destination(TElStandardGlobalLoggerHandle _Handle, TSBTraceDestinationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElStandardGlobalLogger_get_Filename(TElStandardGlobalLoggerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStandardGlobalLogger_set_Filename(TElStandardGlobalLoggerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElStandardGlobalLogger_Create(TElStandardGlobalLoggerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSTANDARDGLOBALLOGGER */

#ifdef SB_USE_CLASS_TELBYTEARRAYMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayManager_GetArray(TElByteArrayManagerHandle _Handle, int32_t Len, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayManager_ReleaseArray(TElByteArrayManagerHandle _Handle, uint8_t pArr[], int32_t * szArr);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayManager_ResizeArray(TElByteArrayManagerHandle _Handle, uint8_t pArr[], int32_t * szArr, int32_t NewSize);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayManager_ReleaseAll(TElByteArrayManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayManager_get_Enabled(TElByteArrayManagerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayManager_set_Enabled(TElByteArrayManagerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayManager_get_MaxCount(TElByteArrayManagerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayManager_set_MaxCount(TElByteArrayManagerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElByteArrayManager_Create(TElByteArrayManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELBYTEARRAYMANAGER */

#ifdef SB_USE_CLASS_TELINTEGERARRAY
SB_IMPORT uint32_t SB_APIENTRY TElIntegerArray_Assign(TElIntegerArrayHandle _Handle, TElIntegerArrayHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElIntegerArray_Add(TElIntegerArrayHandle _Handle, int32_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIntegerArray_RemoveAt(TElIntegerArrayHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElIntegerArray_Clear(TElIntegerArrayHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElIntegerArray_FirstIndexOf(TElIntegerArrayHandle _Handle, int32_t Value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIntegerArray_SelfTest(TElIntegerArrayHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIntegerArray_get_Items(TElIntegerArrayHandle _Handle, int32_t Index, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIntegerArray_set_Items(TElIntegerArrayHandle _Handle, int32_t Index, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElIntegerArray_get_Count(TElIntegerArrayHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElIntegerArray_Create(TElIntegerArrayHandle * OutResult);
#endif /* SB_USE_CLASS_TELINTEGERARRAY */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElStringList_ce_ptr;
extern zend_class_entry *TElByteArrayList_ce_ptr;
extern zend_class_entry *TSBObjectList_ce_ptr;
extern zend_class_entry *TElCustomExceptionHandler_ce_ptr;
extern zend_class_entry *TElStandardExceptionHandler_ce_ptr;
extern zend_class_entry *TElDebugExceptionHandler_ce_ptr;
extern zend_class_entry *TElCustomGlobalLogger_ce_ptr;
extern zend_class_entry *TElStandardGlobalLogger_ce_ptr;
extern zend_class_entry *TElByteArrayManager_ce_ptr;
extern zend_class_entry *TElIntegerArray_ce_ptr;

void SB_CALLBACK TSBTextDataEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pTextLine[], int32_t szTextLine);
void SB_CALLBACK TSBProgressEventRaw(void * _ObjectData, TObjectHandle Sender, int64_t Total, int64_t Current, int8_t * Cancel);
void SB_CALLBACK TSBProgressFuncRaw(void * _ObjectData, int64_t Total, int64_t Current, void * Data, int8_t * Cancel);
void SB_CALLBACK TElMessageLoopEventRaw(void * _ObjectData, int8_t * OutResult);
void Register_TElStringList(TSRMLS_D);
void Register_TElByteArrayList(TSRMLS_D);
void Register_TSBObjectList(TSRMLS_D);
void Register_TElCustomExceptionHandler(TSRMLS_D);
void Register_TElStandardExceptionHandler(TSRMLS_D);
void Register_TElDebugExceptionHandler(TSRMLS_D);
void Register_TElCustomGlobalLogger(TSRMLS_D);
void Register_TElStandardGlobalLogger(TSRMLS_D);
void Register_TElByteArrayManager(TSRMLS_D);
void Register_TElIntegerArray(TSRMLS_D);
SB_PHP_FUNCTION(SBUtils, DigestToStr);
SB_PHP_FUNCTION(SBUtils, StrToDigest);
SB_PHP_FUNCTION(SBUtils, DigestToBinary);
SB_PHP_FUNCTION(SBUtils, BinaryToDigest);
SB_PHP_FUNCTION(SBUtils, DigestToByteArray128);
SB_PHP_FUNCTION(SBUtils, DigestToByteArray160);
SB_PHP_FUNCTION(SBUtils, DigestToByteArray224);
SB_PHP_FUNCTION(SBUtils, DigestToByteArray256);
SB_PHP_FUNCTION(SBUtils, DigestToByteArray320);
SB_PHP_FUNCTION(SBUtils, DigestToByteArray384);
SB_PHP_FUNCTION(SBUtils, DigestToByteArray512);
SB_PHP_FUNCTION(SBUtils, ByteArrayToDigest128);
SB_PHP_FUNCTION(SBUtils, ByteArrayToDigest160);
SB_PHP_FUNCTION(SBUtils, ByteArrayToDigest224);
SB_PHP_FUNCTION(SBUtils, ByteArrayToDigest256);
SB_PHP_FUNCTION(SBUtils, ByteArrayToDigest320);
SB_PHP_FUNCTION(SBUtils, ByteArrayToDigest384);
SB_PHP_FUNCTION(SBUtils, ByteArrayToDigest512);
SB_PHP_FUNCTION(SBUtils, SBIncPtr);
SB_PHP_FUNCTION(SBUtils, SBDecPtr);
SB_PHP_FUNCTION(SBUtils, PointerToLIntP);
SB_PHP_FUNCTION(SBUtils, PointerToLInt);
SB_PHP_FUNCTION(SBUtils, LIntToPointerP);
SB_PHP_FUNCTION(SBUtils, LIntToPointer);
SB_PHP_FUNCTION(SBUtils, LIntToPointerTrunc);
SB_PHP_FUNCTION(SBUtils, BufferBitCount);
SB_PHP_FUNCTION(SBUtils, BeautifyBinaryString);
SB_PHP_FUNCTION(SBUtils, SwapUInt16);
SB_PHP_FUNCTION(SBUtils, SwapInt32);
SB_PHP_FUNCTION(SBUtils, SwapUInt32);
SB_PHP_FUNCTION(SBUtils, SwapInt64);
SB_PHP_FUNCTION(SBUtils, SwapSomeInt);
SB_PHP_FUNCTION(SBUtils, RotateInteger);
SB_PHP_FUNCTION(SBUtils, TrimZeros);
SB_PHP_FUNCTION(SBUtils, SubArray);
SB_PHP_FUNCTION(SBUtils, SwapBigEndianWords);
SB_PHP_FUNCTION(SBUtils, SwapBigEndianDWords);
SB_PHP_FUNCTION(SBUtils, IsEmptyDateTime);
SB_PHP_FUNCTION(SBUtils, EmptyDateTime);
SB_PHP_FUNCTION(SBUtils, ByteArrayFromPtr);
SB_PHP_FUNCTION(SBUtils, TrimLeadingZeros);
SB_PHP_FUNCTION(SBUtils, TrimTrailingZeros);
SB_PHP_FUNCTION(SBUtils, PrefixByteArray);
SB_PHP_FUNCTION(SBUtils, SuffixByteArray);
SB_PHP_FUNCTION(SBUtils, FillByteArray);
SB_PHP_FUNCTION(SBUtils, GetBytes64);
SB_PHP_FUNCTION(SBUtils, GetBytes32);
SB_PHP_FUNCTION(SBUtils, GetBytes16);
SB_PHP_FUNCTION(SBUtils, GetBytes8);
SB_PHP_FUNCTION(SBUtils, LocalDateTimeToSystemDateTime);
SB_PHP_FUNCTION(SBUtils, SystemDateTimeToLocalDateTime);
SB_PHP_FUNCTION(SBUtils, DateTimeAddMillis);
SB_PHP_FUNCTION(SBUtils, DateTimeAddDays);
SB_PHP_FUNCTION(SBUtils, DateTimeAddHours);
SB_PHP_FUNCTION(SBUtils, DateTimeAddMinutes);
SB_PHP_FUNCTION(SBUtils, DateTimeAddSeconds);
SB_PHP_FUNCTION(SBUtils, DateTimeAddYears);
SB_PHP_FUNCTION(SBUtils, DateTimeAfter);
SB_PHP_FUNCTION(SBUtils, DateTimeBefore);
SB_PHP_FUNCTION(SBUtils, DateTimeClone);
SB_PHP_FUNCTION(SBUtils, DateTimeCompare);
SB_PHP_FUNCTION(SBUtils, DateTimeEquals);
SB_PHP_FUNCTION(SBUtils, DateTimeGetMonth);
SB_PHP_FUNCTION(SBUtils, DateTimeGetYear);
SB_PHP_FUNCTION(SBUtils, DateTimeIsLeapYear);
SB_PHP_FUNCTION(SBUtils, DateTimeNow);
SB_PHP_FUNCTION(SBUtils, DateTimeToString);
SB_PHP_FUNCTION(SBUtils, DateTimeUtcNow);
SB_PHP_FUNCTION(SBUtils, DateTimeGetHour);
SB_PHP_FUNCTION(SBUtils, DateTimeGetMinute);
SB_PHP_FUNCTION(SBUtils, CompareMem);
SB_PHP_FUNCTION(SBUtils, CompareBuffers);
SB_PHP_FUNCTION(SBUtils, CompareMD128);
SB_PHP_FUNCTION(SBUtils, CompareMD160);
SB_PHP_FUNCTION(SBUtils, CompareMD224);
SB_PHP_FUNCTION(SBUtils, CompareMD256);
SB_PHP_FUNCTION(SBUtils, CompareMD320);
SB_PHP_FUNCTION(SBUtils, CompareMD384);
SB_PHP_FUNCTION(SBUtils, CompareMD512);
SB_PHP_FUNCTION(SBUtils, CompareHashes);
SB_PHP_FUNCTION(SBUtils, FreeAndNil);
SB_PHP_FUNCTION(SBUtils, GetDigestSizeBits);
SB_PHP_FUNCTION(SBUtils, EncodeDSASignature);
SB_PHP_FUNCTION(SBUtils, DecodeDSASignature);
SB_PHP_FUNCTION(SBUtils, CompareAnsiStr);
SB_PHP_FUNCTION(SBUtils, ChangeByteOrder);
SB_PHP_FUNCTION(SBUtils, BinaryToString);
SB_PHP_FUNCTION(SBUtils, StringToBinary);
SB_PHP_FUNCTION(SBUtils, CompareGUID);
SB_PHP_FUNCTION(SBUtils, AnsiStringOfBytes);
SB_PHP_FUNCTION(SBUtils, ArrayStartsWith);
SB_PHP_FUNCTION(SBUtils, CompareArrays);
SB_PHP_FUNCTION(SBUtils, CreateByteArrayConst);
SB_PHP_FUNCTION(SBUtils, AnsiStringOfString);
SB_PHP_FUNCTION(SBUtils, StringOfAnsiString);
SB_PHP_FUNCTION(SBUtils, BytesOfAnsiString);
SB_PHP_FUNCTION(SBUtils, GetByteArrayFromByte);
SB_PHP_FUNCTION(SBUtils, GetByteArrayFromBytes);
SB_PHP_FUNCTION(SBUtils, GetByteArrayFromWordLE);
SB_PHP_FUNCTION(SBUtils, GetByteArrayFromWordBE);
SB_PHP_FUNCTION(SBUtils, GetByteArrayFromDWordLE);
SB_PHP_FUNCTION(SBUtils, GetByteArrayFromDWordBE);
SB_PHP_FUNCTION(SBUtils, GetByteArrayFromInt64LE);
SB_PHP_FUNCTION(SBUtils, GetByteArrayFromInt64BE);
SB_PHP_FUNCTION(SBUtils, GetWordLEFromByteArray);
SB_PHP_FUNCTION(SBUtils, GetWordBEFromByteArray);
SB_PHP_FUNCTION(SBUtils, GetDWordLEFromByteArray);
SB_PHP_FUNCTION(SBUtils, GetDWordBEFromByteArray);
SB_PHP_FUNCTION(SBUtils, GetInt64LEFromByteArray);
SB_PHP_FUNCTION(SBUtils, GetInt64BEFromByteArray);
SB_PHP_FUNCTION(SBUtils, SBBoolToStr);
SB_PHP_FUNCTION(SBUtils, SBStrToBool);
SB_PHP_FUNCTION(SBUtils, WideStringOf);
SB_PHP_FUNCTION(SBUtils, WideBytesOf);
SB_PHP_FUNCTION(SBUtils, SBConcatArrays);
SB_PHP_FUNCTION(SBUtils, ArrayEndsWith);
SB_PHP_FUNCTION(SBUtils, DateStrToDate);
SB_PHP_FUNCTION(SBUtils, ParseRFC822TimeString);
SB_PHP_FUNCTION(SBUtils, RFC822TimeToDateTime);
SB_PHP_FUNCTION(SBUtils, UTCTimeToDate);
SB_PHP_FUNCTION(SBUtils, UTCTimeToTime);
SB_PHP_FUNCTION(SBUtils, UTCTimeToDateTime);
SB_PHP_FUNCTION(SBUtils, GeneralizedTimeToDate);
SB_PHP_FUNCTION(SBUtils, GeneralizedTimeToTime);
SB_PHP_FUNCTION(SBUtils, GeneralizedTimeToDateTime);
SB_PHP_FUNCTION(SBUtils, DateTimeToUTCTime);
SB_PHP_FUNCTION(SBUtils, DateTimeToGeneralizedTime);
SB_PHP_FUNCTION(SBUtils, UniversalDateTimeToRFC822DateTimeString);
SB_PHP_FUNCTION(SBUtils, RFC822TimeStringToUniversalTime);
SB_PHP_FUNCTION(SBUtils, LocalDateTimeToRFC822DateTimeString);
SB_PHP_FUNCTION(SBUtils, SystemDateTimeToRFC822DateTimeString);
#ifndef SB_WINDOWS
SB_PHP_FUNCTION(SBUtils, FileTimeToUnixTime);
SB_PHP_FUNCTION(SBUtils, UnixTimeToFileTime);
#endif
SB_PHP_FUNCTION(SBUtils, FileTimeToDateTime);
SB_PHP_FUNCTION(SBUtils, DateTimeToFileTime);
SB_PHP_FUNCTION(SBUtils, UnixTimeToDateTime);
SB_PHP_FUNCTION(SBUtils, DateTimeToUnixTime);
SB_PHP_FUNCTION(SBUtils, ConstLength);
SB_PHP_FUNCTION(SBUtils, TickDiff);
SB_PHP_FUNCTION(SBUtils, GenerateGUID);
SB_PHP_FUNCTION(SBUtils, IsTextualOID);
SB_PHP_FUNCTION(SBUtils, IsWindowsOS);
SB_PHP_FUNCTION(SBUtils, WaitFor);
SB_PHP_FUNCTION(SBUtils, LocalTimeToUTCTime);
SB_PHP_FUNCTION(SBUtils, UTCTimeToLocalTime);
SB_PHP_FUNCTION(SBUtils, UTCNow);
SB_PHP_FUNCTION(SBUtils, RegisterGlobalObject);
SB_PHP_FUNCTION(SBUtils, UnregisterGlobalObject);
SB_PHP_FUNCTION(SBUtils, CleanupRegisteredGlobalObjects);
SB_PHP_FUNCTION(SBUtils, AcquireGlobalLock);
SB_PHP_FUNCTION(SBUtils, ReleaseGlobalLock);
SB_PHP_FUNCTION(SBUtils, HexDump);
SB_PHP_FUNCTION(SBUtils, SBSameDateTime);
SB_PHP_FUNCTION(SBUtils, SBSameDate);
SB_PHP_FUNCTION(SBUtils, SBSameTime);
SB_PHP_FUNCTION(SBUtils, SBEncodeDateTime);
SB_PHP_FUNCTION(SBUtils, GetUTCOffsetDateTime);
SB_PHP_FUNCTION(SBUtils, CompareContent);
SB_PHP_FUNCTION(SBUtils, DateTimeToISO8601Time);
SB_PHP_FUNCTION(SBUtils, ISO8601TimeToDateTime);
SB_PHP_FUNCTION(SBUtils, DateTimeToRFC3339);
SB_PHP_FUNCTION(SBUtils, SetLicenseKey);
SB_PHP_FUNCTION(SBUtils, AppendSlash);
SB_PHP_FUNCTION(SBUtils, EnsureDirectoryExists);
SB_PHP_FUNCTION(SBUtils, DirectoryExists);
#ifndef SB_WINDOWS
SB_PHP_FUNCTION(SBUtils, GetCurrentThreadID);
#endif
SB_PHP_FUNCTION(SBUtils, SetDefaultExceptionHandler);
SB_PHP_FUNCTION(SBUtils, GetDefaultExceptionHandler);
SB_PHP_FUNCTION(SBUtils, SetDefaultGlobalLogger);
SB_PHP_FUNCTION(SBUtils, GetDefaultGlobalLogger);
SB_PHP_FUNCTION(SBUtils, RecordEntryInGlobalLog);
void Register_SBUtils_Constants(int module_number TSRMLS_DC);
void Register_SBUtils_Enum_Flags(TSRMLS_D);
void Register_SBUtils_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_UTILS
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToStr(const TMessageDigest128 * Digest, int8_t LowerCase, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToStr_1(const TMessageDigest160 * Digest, int8_t LowerCase, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToStr_2(const TMessageDigest224 * Digest, int8_t LowerCase, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToStr_3(const TMessageDigest256 * Digest, int8_t LowerCase, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToStr_4(const TMessageDigest320 * Digest, int8_t LowerCase, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToStr_5(const TMessageDigest384 * Digest, int8_t LowerCase, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToStr_6(const TMessageDigest512 * Digest, int8_t LowerCase, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_StrToDigest(const char * pcDigestStr, int32_t szDigestStr, TMessageDigest128 * Digest, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_StrToDigest_1(const char * pcDigestStr, int32_t szDigestStr, TMessageDigest160 * Digest, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToBinary(const TMessageDigest128 * Digest, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToBinary_1(const TMessageDigest160 * Digest, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_BinaryToDigest(const uint8_t pBinary[], int32_t szBinary, TMessageDigest128 * Digest, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_BinaryToDigest_1(const uint8_t pBinary[], int32_t szBinary, TMessageDigest160 * Digest, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToByteArray128(const TMessageDigest128 * Digest, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToByteArray160(const TMessageDigest160 * Digest, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToByteArray224(const TMessageDigest224 * Digest, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToByteArray256(const TMessageDigest256 * Digest, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToByteArray320(const TMessageDigest320 * Digest, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToByteArray384(const TMessageDigest384 * Digest, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DigestToByteArray512(const TMessageDigest512 * Digest, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ByteArrayToDigest128(const uint8_t pBinary[], int32_t szBinary, int32_t Position, TMessageDigest128 * Digest, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ByteArrayToDigest160(const uint8_t pBinary[], int32_t szBinary, int32_t Position, TMessageDigest160 * Digest, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ByteArrayToDigest224(const uint8_t pBinary[], int32_t szBinary, int32_t Position, TMessageDigest224 * Digest, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ByteArrayToDigest256(const uint8_t pBinary[], int32_t szBinary, int32_t Position, TMessageDigest256 * Digest, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ByteArrayToDigest320(const uint8_t pBinary[], int32_t szBinary, int32_t Position, TMessageDigest320 * Digest, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ByteArrayToDigest384(const uint8_t pBinary[], int32_t szBinary, int32_t Position, TMessageDigest384 * Digest, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ByteArrayToDigest512(const uint8_t pBinary[], int32_t szBinary, int32_t Position, TMessageDigest512 * Digest, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBIncPtr(void * Ptr, int32_t Value, void * * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBDecPtr(void * Ptr, int32_t Value, void * * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_PointerToLIntP(PLInt * B, void * P, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_PointerToLInt(PLInt * B, const uint8_t pP[], int32_t szP, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_LIntToPointerP(PLInt B, void * P, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_LIntToPointer(PLInt B, const uint8_t pP[], int32_t szP, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_LIntToPointerTrunc(PLInt B, void * P, int32_t * Size);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_BufferBitCount(void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_BeautifyBinaryString(const char * pcStr, int32_t szStr, char Separator, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SwapUInt16(uint16_t Value, uint8_t pBuffer[], int32_t * szBuffer);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SwapUInt16_1(uint16_t Value, uint8_t pBuffer[], int32_t * szBuffer, int32_t * Index);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SwapUInt16_2(const uint8_t pBuffer[], int32_t szBuffer, uint32_t Offset, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SwapInt32(int32_t value, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SwapUInt32(uint32_t Value, uint8_t pBuffer[], int32_t * szBuffer);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SwapUInt32_1(uint32_t Value, uint8_t pBuffer[], int32_t * szBuffer, int32_t * Index);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SwapUInt32_2(const uint8_t pBuffer[], int32_t szBuffer, uint32_t Offset, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SwapUInt32_3(uint32_t value, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SwapInt64(int64_t value, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SwapSomeInt(int32_t Value, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_RotateInteger(const uint8_t pValue[], int32_t szValue, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_TrimZeros(const uint8_t pValue[], int32_t szValue, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SubArray(const uint8_t pArr[], int32_t szArr, int32_t Index, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SwapBigEndianWords(void * P, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SwapBigEndianDWords(void * P, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_IsEmptyDateTime(int64_t DT, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_EmptyDateTime(int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ByteArrayFromPtr(void * Source, int32_t Size, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_TrimLeadingZeros(const uint8_t pV[], int32_t szV, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_TrimTrailingZeros(const uint8_t pV[], int32_t szV, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_PrefixByteArray(const uint8_t pBuffer[], int32_t szBuffer, int32_t Count, uint8_t Value, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SuffixByteArray(const uint8_t pBuffer[], int32_t szBuffer, int32_t Count, uint8_t Value, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_FillByteArray(const uint8_t pBuffer[], int32_t szBuffer, int32_t SrcOffset, int32_t Count, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_FillByteArray_1(const uint8_t pBuffer[], int32_t szBuffer, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetBytes64(int64_t X, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetBytes64_1(int64_t X, uint8_t pBuffer[], int32_t * szBuffer, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetBytes32(uint32_t X, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetBytes32_1(uint32_t X, uint8_t pBuffer[], int32_t * szBuffer, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetBytes16(uint16_t X, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetBytes16_1(uint16_t X, uint8_t pBuffer[], int32_t * szBuffer, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetBytes8(uint8_t X, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetBytes8_1(uint8_t X, uint8_t pBuffer[], int32_t * szBuffer, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_LocalDateTimeToSystemDateTime(int64_t ADateTime, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SystemDateTimeToLocalDateTime(int64_t ADateTime, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeAddMillis(int64_t DateTime, int32_t Millis, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeAddDays(int64_t DateTime, int32_t Days, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeAddHours(int64_t DateTime, int32_t Hours, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeAddMinutes(int64_t DateTime, int32_t Minutes, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeAddSeconds(int64_t DateTime, int32_t Seconds, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeAddYears(int64_t DateTime, int32_t Years, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeAfter(int64_t DT1, int64_t DT2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeBefore(int64_t DT1, int64_t DT2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeClone(int64_t DateTime, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeCompare(int64_t DT1, int64_t DT2, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeEquals(int64_t DT1, int64_t DT2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeGetMonth(int64_t DT, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeGetYear(int64_t DT, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeIsLeapYear(int32_t Year, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeIsLeapYear_1(int64_t DT, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeNow(int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeToString(int64_t DateTime, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeUtcNow(int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeGetHour(int64_t DT, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeGetMinute(int64_t DT, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareMem(const uint8_t pMem1[], int32_t szMem1, const uint8_t pMem2[], int32_t szMem2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareMem_1(const uint8_t pMem1[], int32_t szMem1, int32_t Offset1, const uint8_t pMem2[], int32_t szMem2, int32_t Offset2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareMem_2(const uint8_t pMem1[], int32_t szMem1, int32_t Offset1, const uint8_t pMem2[], int32_t szMem2, int32_t Offset2, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareMem_3(const void * Mem1, const void * Mem2, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareBuffers(const uint8_t pBuf1[], int32_t szBuf1, const uint8_t pBuf2[], int32_t szBuf2, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareMD128(const TMessageDigest128 * M1, const TMessageDigest128 * M2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareMD160(const TMessageDigest160 * M1, const TMessageDigest160 * M2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareMD224(const TMessageDigest224 * M1, const TMessageDigest224 * M2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareMD256(const TMessageDigest256 * M1, const TMessageDigest256 * M2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareMD320(const TMessageDigest320 * M1, const TMessageDigest320 * M2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareMD384(const TMessageDigest384 * M1, const TMessageDigest384 * M2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareMD512(const TMessageDigest512 * M1, const TMessageDigest512 * M2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareHashes(const uint8_t pHash1[], int32_t szHash1, const uint8_t pHash2[], int32_t szHash2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareHashes_1(const uint8_t pHash1[], int32_t szHash1, int32_t StartIndex1, int32_t Count1, const uint8_t pHash2[], int32_t szHash2, int32_t StartIndex2, int32_t Count2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareHashes_2(void * Hash1, int32_t Len1, void * Hash2, int32_t Len2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_FreeAndNil(void * Obj);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetDigestSizeBits(int32_t Algorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_EncodeDSASignature(void * R, int32_t RSize, void * S, int32_t SSize, void * Blob, int32_t * BlobSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DecodeDSASignature(void * Blob, int32_t Size, void * R, int32_t * RSize, void * S, int32_t * SSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareAnsiStr(const char * pcContent, int32_t szContent, const char * pcOID, int32_t szOID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ChangeByteOrder(const uint8_t pBuffer[], int32_t szBuffer, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_BinaryToString(const uint8_t pBuffer[], int32_t szBuffer, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_BinaryToString_1(const uint8_t pBuffer[], int32_t szBuffer, int32_t Start, int32_t Count, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_BinaryToString_2(void * Buffer, int32_t BufSize, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_StringToBinary(const char * pcS, int32_t szS, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareGUID(const TGuid * Guid1, const TGuid * Guid2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_AnsiStringOfBytes(const uint8_t pSrc[], int32_t szSrc, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ArrayStartsWith(const uint8_t pSubP[], int32_t szSubP, const uint8_t pP[], int32_t szP, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareArrays(const uint8_t pBuf1[], int32_t szBuf1, const uint8_t pBuf2[], int32_t szBuf2, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CreateByteArrayConst(const char * pcSrc, int32_t szSrc, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_AnsiStringOfString(const char * pcSource, int32_t szSource, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_StringOfAnsiString(const char * pcSource, int32_t szSource, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_BytesOfAnsiString(const char * pcStr, int32_t szStr, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromByte(uint8_t Value, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromByte_1(uint8_t Value, const uint8_t pDest[], int32_t szDest, int32_t Position);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromBytes(uint8_t Value1, uint8_t Value2, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromBytes_1(uint8_t Value1, uint8_t Value2, const uint8_t pDest[], int32_t szDest, int32_t Position);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromBytes_2(uint8_t Value1, uint8_t Value2, uint8_t Value3, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromBytes_3(uint8_t Value1, uint8_t Value2, uint8_t Value3, const uint8_t pDest[], int32_t szDest, int32_t Position);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromWordLE(uint16_t Value, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromWordLE_1(uint16_t Value, const uint8_t pDest[], int32_t szDest, int32_t Position);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromWordBE(uint16_t Value, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromWordBE_1(uint16_t Value, const uint8_t pDest[], int32_t szDest, int32_t Position);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromDWordLE(uint32_t Value, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromDWordLE_1(uint32_t Value, const uint8_t pDest[], int32_t szDest, int32_t Position);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromDWordBE(uint32_t Value, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromDWordBE_1(uint32_t Value, const uint8_t pDest[], int32_t szDest, int32_t Position);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromInt64LE(int64_t Value, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromInt64LE_1(int64_t Value, const uint8_t pDest[], int32_t szDest, int32_t Position);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromInt64BE(int64_t Value, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetByteArrayFromInt64BE_1(int64_t Value, const uint8_t pDest[], int32_t szDest, int32_t Position);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetWordLEFromByteArray(const uint8_t pSource[], int32_t szSource, int32_t Position, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetWordBEFromByteArray(const uint8_t pSource[], int32_t szSource, int32_t Position, uint16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetDWordLEFromByteArray(const uint8_t pSource[], int32_t szSource, int32_t Position, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetDWordLEFromByteArray_1(const uint8_t pSource[], int32_t szSource, int32_t Position, int32_t Count, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetDWordBEFromByteArray(const uint8_t pSource[], int32_t szSource, int32_t Position, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetInt64LEFromByteArray(const uint8_t pSource[], int32_t szSource, int32_t Position, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetInt64BEFromByteArray(const uint8_t pSource[], int32_t szSource, int32_t Position, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBBoolToStr(int8_t B, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBStrToBool(const char * pcS, int32_t szS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_WideStringOf(const uint8_t pValue[], int32_t szValue, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_WideBytesOf(const char * pcValue, int32_t szValue, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBConcatArrays(const uint8_t pBuf1[], int32_t szBuf1, const uint8_t pBuf2[], int32_t szBuf2, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBConcatArrays_1(const uint8_t pBuf1[], int32_t szBuf1, const uint8_t pBuf2[], int32_t szBuf2, const uint8_t pBuf3[], int32_t szBuf3, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBConcatArrays_2(const uint8_t pBuf1[], int32_t szBuf1, uint8_t Buf2, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBConcatArrays_3(uint8_t Buf1, const uint8_t pBuf2[], int32_t szBuf2, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBConcatArrays_4(uint8_t Buf1, uint8_t Buf2, const uint8_t pBuf3[], int32_t szBuf3, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBConcatArrays_5(uint8_t Buf1, const uint8_t pBuf2[], int32_t szBuf2, const uint8_t pBuf3[], int32_t szBuf3, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBConcatArrays_6(const uint8_t pBuf1[], int32_t szBuf1, uint8_t Buf2, uint8_t Buf3, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ArrayEndsWith(const uint8_t pBuffer[], int32_t szBuffer, const uint8_t pSubstr[], int32_t szSubstr, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateStrToDate(const char * pcTime, int32_t szTime, int64_t * ADateTime, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ParseRFC822TimeString(const char * pcRFC822TimeString, int32_t szRFC822TimeString, int64_t * ADateTime, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_RFC822TimeToDateTime(const char * pcRFC822Time, int32_t szRFC822Time, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_UTCTimeToDate(const char * pcUTCTime, int32_t szUTCTime, int8_t FourDigitYear, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_UTCTimeToTime(const char * pcUTCTime, int32_t szUTCTime, int8_t FourDigitYear, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_UTCTimeToDateTime(const char * pcUTCTime, int32_t szUTCTime, int8_t FourDigitYear, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GeneralizedTimeToDate(const char * pcGenTime, int32_t szGenTime, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GeneralizedTimeToTime(const char * pcGenTime, int32_t szGenTime, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GeneralizedTimeToDateTime(const char * pcGenTime, int32_t szGenTime, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeToUTCTime(int64_t ADateTime, int8_t FourDigitYear, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeToGeneralizedTime(int64_t ADateTime, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeToGeneralizedTime_1(int64_t ADateTime, const char * pcDateTimeSplitPtn, int32_t szDateTimeSplitPtn, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_UniversalDateTimeToRFC822DateTimeString(int64_t DT, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_RFC822TimeStringToUniversalTime(const char * pcTS, int32_t szTS, int64_t * DT, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_LocalDateTimeToRFC822DateTimeString(int64_t ADateTime, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SystemDateTimeToRFC822DateTimeString(int64_t ADateTime, char * pcOutResult, int32_t * szOutResult);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY SBUtils_FileTimeToDateTime(windows_FILETIME * Value, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeToFileTime(int64_t Value, windows_FILETIME * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY SBUtils_FileTimeToUnixTime(_FILETIME * Value, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_UnixTimeToFileTime(int64_t Value, _FILETIME * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_FileTimeToDateTime(_FILETIME * Value, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeToFileTime(int64_t Value, _FILETIME * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY SBUtils_UnixTimeToDateTime(int64_t Value, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeToUnixTime(int64_t Value, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ConstLength(const uint8_t pArr[], int32_t szArr, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_TickDiff(uint32_t Previous, uint32_t Current, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GenerateGUID(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_IsTextualOID(const char * pcS, int32_t szS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_IsWindowsOS(int8_t * OutResult);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY SBUtils_WaitFor(uint32_t Handle, uint32_t * OutResult);
#else
SB_IMPORT uint32_t SB_APIENTRY SBUtils_WaitFor(TThreadHandle Thread, uint32_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY SBUtils_LocalTimeToUTCTime(int64_t LocalTime, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_UTCTimeToLocalTime(int64_t UtcTime, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_UTCNow(int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_RegisterGlobalObject(TObjectHandle O);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_UnregisterGlobalObject(TObjectHandle O);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CleanupRegisteredGlobalObjects(void);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_AcquireGlobalLock(void);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ReleaseGlobalLock(void);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_HexDump(const uint8_t pBuffer[], int32_t szBuffer, uint32_t Offset, uint32_t Len, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_HexDump_1(const uint8_t pBuffer[], int32_t szBuffer, uint32_t Offset, uint32_t Len, int8_t AddChars, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBSameDateTime(int64_t A, int64_t B, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBSameDate(int64_t A, int64_t B, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBSameTime(int64_t A, int64_t B, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SBEncodeDateTime(int32_t Year, int32_t Month, int32_t Day, int32_t Hour, int32_t Minute, int32_t Second, int32_t Millisecond, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetUTCOffsetDateTime(int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetUTCOffsetDateTime_1(int64_t ADateTime, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareContent(const uint8_t pContent[], int32_t szContent, const uint8_t pOID[], int32_t szOID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareContent_1(const uint8_t pContent[], int32_t szContent, int32_t ContentStartIndex, int32_t ContentLen, const uint8_t pOID[], int32_t szOID, int32_t OIDStartIndex, int32_t OIDLen, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_CompareContent_2(const uint8_t pContent[], int32_t szContent, int32_t ContentStartIndex, int32_t ContentLen, const uint8_t pOID[], int32_t szOID, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeToISO8601Time(int64_t Time, int8_t EncodeMilliseconds, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_ISO8601TimeToDateTime(const char * pcEncodedTime, int32_t szEncodedTime, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DateTimeToRFC3339(int64_t Value, int8_t EncodeMilliseconds, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SetLicenseKey(const char * pcKey, int32_t szKey);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_AppendSlash(const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_EnsureDirectoryExists(const char * pcDirName, int32_t szDirName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_DirectoryExists(const char * pcDirName, int32_t szDirName, int8_t * OutResult);
#ifndef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetCurrentThreadID(uint32_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SetDefaultExceptionHandler(TElCustomExceptionHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetDefaultExceptionHandler(TElCustomExceptionHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_SetDefaultGlobalLogger(TElCustomGlobalLoggerHandle Logger, int8_t FreeOnRemoval);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_GetDefaultGlobalLogger(TElCustomGlobalLoggerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBUtils_RecordEntryInGlobalLog(TSBGlobalLoggerLevelRaw Level, const char * pcSource, int32_t szSource, const char * pcLine, int32_t szLine);
#endif /* SB_USE_GLOBAL_PROCS_UTILS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBUTILS */
