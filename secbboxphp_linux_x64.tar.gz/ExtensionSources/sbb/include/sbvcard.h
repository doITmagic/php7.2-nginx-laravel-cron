#ifndef __INC_SBVCARD
#define __INC_SBVCARD

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstringlist.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbdictionary.h"
#include "sbstreams.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_VCARDCAL_ERROR_VERSION 	1
#define SB_VCARDCAL_ERROR_FORMAT 	2
#define SB_VCARDCAL_ERROR_INTERNAL 	3
#define SB_VCARDCAL_ERROR_NON_EXPANDABLE 	4
#define SB_VCARDCAL_ERROR_UNSUPPORTED_VERSION 	5
#define SB_VCARDCAL_VERSION_UNKNOWN 	-1
#define SB_VCARDCAL_VERSION_2_1 	0
#define SB_VCARDCAL_VERSION_3_0 	1
#define SB_VCARDCAL_VERSION_4_0 	2

typedef TElClassHandle TElDirInfoAttributeHandle;

typedef TElClassHandle TElDirInfoPropertyHandle;

typedef TElClassHandle TElDirInfoPropertiesListHandle;

typedef TElClassHandle TElDirInfoHandle;

typedef TElClassHandle TElVCardHandle;

typedef TElClassHandle TElVCalendarHandle;

#ifdef SB_USE_CLASS_TELDIRINFOATTRIBUTE
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoAttribute_get_Name(TElDirInfoAttributeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoAttribute_set_Name(TElDirInfoAttributeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoAttribute_get_Value(TElDirInfoAttributeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoAttribute_set_Value(TElDirInfoAttributeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoAttribute_Create(TElDirInfoAttributeHandle * OutResult);
#endif /* SB_USE_CLASS_TELDIRINFOATTRIBUTE */

#ifdef SB_USE_CLASS_TELDIRINFOPROPERTY
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoProperty_AddAttribute(TElDirInfoPropertyHandle _Handle, TElDirInfoAttributeHandle Attr);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoProperty_RemoveAttribute(TElDirInfoPropertyHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoProperty_AttributeByName(TElDirInfoPropertyHandle _Handle, const char * pcName, int32_t szName, TElDirInfoAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoProperty_get_Name(TElDirInfoPropertyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoProperty_set_Name(TElDirInfoPropertyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoProperty_get_Value(TElDirInfoPropertyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoProperty_set_Value(TElDirInfoPropertyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoProperty_get_FullName(TElDirInfoPropertyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoProperty_get_Attributes(TElDirInfoPropertyHandle _Handle, int32_t Index, TElDirInfoAttributeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoProperty_get_AttributeCount(TElDirInfoPropertyHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoProperty_Create(TElDirInfoPropertyHandle * OutResult);
#endif /* SB_USE_CLASS_TELDIRINFOPROPERTY */

#ifdef SB_USE_CLASS_TELDIRINFOPROPERTIESLIST
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoPropertiesList_Clear(TElDirInfoPropertiesListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoPropertiesList_Add(TElDirInfoPropertiesListHandle _Handle, TElDirInfoPropertyHandle Prop);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoPropertiesList_Insert(TElDirInfoPropertiesListHandle _Handle, int32_t Index, TElDirInfoPropertyHandle Prop);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoPropertiesList_Remove(TElDirInfoPropertiesListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoPropertiesList_get_SubProperties(TElDirInfoPropertiesListHandle _Handle, int32_t Index, TElDirInfoPropertyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoPropertiesList_get_SubPropertyCount(TElDirInfoPropertiesListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoPropertiesList_get_IsSingle(TElDirInfoPropertiesListHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoPropertiesList_get_SingleProperty(TElDirInfoPropertiesListHandle _Handle, TElDirInfoPropertyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfoPropertiesList_Create(TElDirInfoPropertiesListHandle * OutResult);
#endif /* SB_USE_CLASS_TELDIRINFOPROPERTIESLIST */

#ifdef SB_USE_CLASS_TELDIRINFO
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_LoadFromString(TElDirInfoHandle _Handle, const char * pcS, int32_t szS);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_SaveToString(TElDirInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_LoadFromStream(TElDirInfoHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_SaveToStream(TElDirInfoHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_LoadFromFile(TElDirInfoHandle _Handle, const char * pcFileName, int32_t szFileName);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_SaveToFile(TElDirInfoHandle _Handle, const char * pcFileName, int32_t szFileName);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_ToString(TElDirInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_AddSection(TElDirInfoHandle _Handle, const char * pcName, int32_t szName, TElDirInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_AddSection_1(TElDirInfoHandle _Handle, TElDirInfoHandle Sect);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_RemoveSection(TElDirInfoHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_AddProperty(TElDirInfoHandle _Handle, TElDirInfoPropertyHandle Prop);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_InsertProperty(TElDirInfoHandle _Handle, int32_t Index, TElDirInfoPropertyHandle Prop);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_RemoveProperty(TElDirInfoHandle _Handle, const char * pcName, int32_t szName);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_RemoveAndAddProperty(TElDirInfoHandle _Handle, TElDirInfoPropertyHandle Prop);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_GetPropertyNames(TElDirInfoHandle _Handle, TStringListHandle OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_SectionByName(TElDirInfoHandle _Handle, const char * pcName, int32_t szName, TElDirInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_GetPropertyValue(TElDirInfoHandle _Handle, const char * pcName, int32_t szName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_SetPropertyValue(TElDirInfoHandle _Handle, const char * pcName, int32_t szName, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_get_Parent(TElDirInfoHandle _Handle, TElDirInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_set_Parent(TElDirInfoHandle _Handle, TElDirInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_get_Name(TElDirInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_set_Name(TElDirInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_get_Include(TElDirInfoHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_get_FullPath(TElDirInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_get_FullPathEx(TElDirInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_get_GenerateUID(TElDirInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_set_GenerateUID(TElDirInfoHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_get_Properties(TElDirInfoHandle _Handle, const char * pcIndex, int32_t szIndex, TElDirInfoPropertiesListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_get_PropertyCount(TElDirInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_get_Sections(TElDirInfoHandle _Handle, int32_t Index, TElDirInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_get_SectionCount(TElDirInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElDirInfo_Create(TElDirInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELDIRINFO */

#ifdef SB_USE_CLASS_TELVCARD
SB_IMPORT uint32_t SB_APIENTRY TElVCard_get_Version(TElVCardHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVCard_set_Version(TElVCardHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElVCard_Create(TElVCardHandle * OutResult);
#endif /* SB_USE_CLASS_TELVCARD */

#ifdef SB_USE_CLASS_TELVCALENDAR
SB_IMPORT uint32_t SB_APIENTRY TElVCalendar_Create(TElVCalendarHandle * OutResult);
#endif /* SB_USE_CLASS_TELVCALENDAR */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElDirInfoAttribute_ce_ptr;
extern zend_class_entry *TElDirInfoProperty_ce_ptr;
extern zend_class_entry *TElDirInfoPropertiesList_ce_ptr;
extern zend_class_entry *TElDirInfo_ce_ptr;
extern zend_class_entry *TElVCard_ce_ptr;
extern zend_class_entry *TElVCalendar_ce_ptr;

void Register_TElDirInfoAttribute(TSRMLS_D);
void Register_TElDirInfoProperty(TSRMLS_D);
void Register_TElDirInfoPropertiesList(TSRMLS_D);
void Register_TElDirInfo(TSRMLS_D);
void Register_TElVCard(TSRMLS_D);
void Register_TElVCalendar(TSRMLS_D);
void Register_SBVCard_Constants(int module_number TSRMLS_DC);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBVCARD */

