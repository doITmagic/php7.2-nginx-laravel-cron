#ifndef __INC_SBWEBDAVCLIENT
#define __INC_SBWEBDAVCLIENT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstringlist.h"
#include "sbxmldefs.h"
#include "sbxmlutils.h"
#include "sbxmlcore.h"
#include "sbxmlcharsets.h"
#include "sbhttpscommon.h"
#include "sbencoding.h"
#include "sbhttpsconstants.h"
#include "sbhttpsclient.h"
#include "sbsslcommon.h"
#include "sbwebdavcommon.h"
#include "sbhttpswebdavclient.h"
#include "sbdiskfsadapter.h"
#include "sbcustomfsadapter.h"
#include "sbvcard.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SHTTPSWebDAVClientNotSet 	"You must set HTTPSWebDAVClient property first"
#define SB_SHTTPSWebDAVClientPrecondFailed 	"Precondition failed: %s: %s"
#define SB_SHTTPSWebDAVClientProtectedOrInheritedACE 	"Protected and inherited ACEs can\'t be used in ACL change request"
#define SB_WEBDAV_MULTI_STATUS_RESPONSE 	207
#define SB_WEBDAV_NO_CONTENT_RESPONSE 	204

typedef TElClassHandle TElWebDAVClientHandle;

typedef TElWebDAVClientHandle ElWebDAVClientHandle;

typedef TElClassHandle TElWebDAVLockListHandle;

typedef TElWebDAVLockListHandle ElWebDAVLockListHandle;

typedef TElClassHandle TElWebDAVMultistatusResponseHandle;

typedef TElWebDAVMultistatusResponseHandle ElWebDAVMultistatusResponseHandle;

typedef TElClassHandle TElWebDAVErrorHandle;

typedef TElClassHandle TElWebDAVPrivilegeSetHandle;

typedef TElClassHandle TElWebDAVSupportedPrivilegeHandle;

typedef TElClassHandle TElWebDAVSupportedPrivilegeSetHandle;

typedef TElClassHandle TElWebDAVPrincipalSearchPropertySetResponseHandle;

typedef TElClassHandle TElWebDAVStorageObjectHandle;

typedef TElWebDAVStorageObjectHandle ElWebDAVStorageObjectHandle;

typedef TElClassHandle TElWebDAVErrorResponseHandle;

typedef TElWebDAVErrorResponseHandle ElWebDAVErrorResponseHandle;

typedef TElClassHandle TElWebDAVObjectListHandle;

typedef TElWebDAVObjectListHandle ElWebDAVObjectListHandle;

typedef TElClassHandle TElWebDAVErrorListHandle;

typedef TElWebDAVErrorListHandle ElWebDAVErrorListHandle;

typedef TElClassHandle SBWebDAVClient_TElWebDAVPrincipalHandle;

typedef TElClassHandle TElWebDAVPrincipalListHandle;

typedef TElClassHandle TElCardDavSupportedAddressDataHandle;

typedef TElClassHandle TElCardDavAddressBookInfoHandle;

typedef TElClassHandle TElCardDavReportContextHandle;

typedef uint8_t TSBWebDAVClassRaw;

typedef enum
{
	wdcOne = 0,
	wdcTwo = 1,
	wdcThree = 2
} TSBWebDAVClass;

typedef uint32_t TSBWebDAVClassesRaw;

typedef enum 
{
	f_wdcOne = 1,
	f_wdcTwo = 2,
	f_wdcThree = 4
} TSBWebDAVClasses;

#ifdef SB_USE_CLASS_TELWEBDAVCLIENT
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_List(TElWebDAVClientHandle _Handle, TElWebDAVObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_List_1(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_List_2(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVObjectListHandle Objects, TSBWebDAVDepthRaw Depth);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_List_3(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, TElWebDAVObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_CreateCollection(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVLockListHandle Locks);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_CreateCollection_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Parent, const char * pcName, int32_t szName);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_DeleteObject(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_DeleteObject_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_CopyObject(TElWebDAVClientHandle _Handle, const char * pcSrcURL, int32_t szSrcURL, const char * pcDestURL, int32_t szDestURL, int8_t Overwrite, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_CopyObject_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Src, TElWebDAVStorageObjectHandle Dest, int8_t Overwrite, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_MoveObject(TElWebDAVClientHandle _Handle, const char * pcSrcURL, int32_t szSrcURL, const char * pcDestURL, int32_t szDestURL, int8_t Overwrite, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_MoveObject_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Src, TElWebDAVStorageObjectHandle Dest, int8_t Overwrite, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Rename(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcNewName, int32_t szNewName, int8_t MoveToRename, TElWebDAVLockListHandle Locks);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Rename_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, const char * pcNewName, int32_t szNewName, int8_t MoveToRename);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_ChangeProperties(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle SetProperties, TElWebDAVPropertyInfoListHandle RemoveProperties, TElWebDAVLockListHandle Locks);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_ChangeProperties_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, TElWebDAVPropertyInfoListHandle SetProperties, TElWebDAVPropertyInfoListHandle RemoveProperties);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_SetProperty(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoHandle PropInfo, TElWebDAVLockListHandle Locks);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_SetProperty_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, TElWebDAVPropertyInfoHandle PropInfo);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_RemoveProperty(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoHandle PropInfo, TElWebDAVLockListHandle Locks);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_RemoveProperty_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, TElWebDAVPropertyInfoHandle PropInfo);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_ReadProperties(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle Properties);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_ReadProperties_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, TElWebDAVPropertyInfoListHandle Properties);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_ReadProperty(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcPropName, int32_t szPropName, TElWebDAVPropertyInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_ReadProperty_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, const char * pcPropName, int32_t szPropName, TElWebDAVPropertyInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_GetSupportedProperties(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle Properties);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_GetSupportedProperties_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, TElWebDAVPropertyInfoListHandle Properties);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_ReadSupportedProperties(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle Properties);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_ReadSupportedProperties_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, TElWebDAVPropertyInfoListHandle Properties);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_ReadAllProperties(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle Properties);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_ReadAllProperties_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, TElWebDAVPropertyInfoListHandle Properties);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Upload(TElWebDAVClientHandle _Handle, const char * pcFilePath, int32_t szFilePath, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Upload_1(TElWebDAVClientHandle _Handle, const char * pcFilePath, int32_t szFilePath, TElWebDAVStorageObjectHandle Dest, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Upload_2(TElWebDAVClientHandle _Handle, const char * pcFilePath, int32_t szFilePath, const char * pcDestURL, int32_t szDestURL, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Upload_3(TElWebDAVClientHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, const char * pcDestURL, int32_t szDestURL, int64_t RestartFrom, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Upload_4(TElWebDAVClientHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count, TElWebDAVStorageObjectHandle Dest, int64_t RestartFrom, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Upload_5(TElWebDAVClientHandle _Handle, TStreamHandle Stream, const char * pcDestURL, int32_t szDestURL, int64_t RestartFrom, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Upload_6(TElWebDAVClientHandle _Handle, TStreamHandle Stream, TElWebDAVStorageObjectHandle Dest, int64_t RestartFrom, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_UploadDynamic(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Dest, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_UploadDynamic_1(TElWebDAVClientHandle _Handle, const char * pcDestURL, int32_t szDestURL, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_UploadDynamic_2(TElWebDAVClientHandle _Handle, const char * pcDestURL, int32_t szDestURL, int64_t ContentLength, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_UploadDynamic_3(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Dest, int64_t ContentLength, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_DownloadDynamic(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVLockListHandle Locks);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_DownloadDynamic_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, TElWebDAVLockListHandle Locks);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Download(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcFilePath, int32_t szFilePath, int8_t Overwrite);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Download_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, const char * pcFilePath, int32_t szFilePath, int8_t Overwrite);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Download_2(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TStreamHandle Stream, int32_t Count, int64_t RestartFrom);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Download_3(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, TStreamHandle Stream, int32_t Count, int64_t RestartFrom);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Download_4(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TStreamHandle Stream, int32_t Count, int64_t RestartFrom, TElWebDAVLockListHandle Locks);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Download_5(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, TStreamHandle Stream, int32_t Count, int64_t RestartFrom, TElWebDAVLockListHandle Locks);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_DownloadFile(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcLocalFileName, int32_t szLocalFileName);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_DownloadFile_1(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcLocalFileName, int32_t szLocalFileName, TSBFileTransferModeRaw Mode);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_DownloadFile_2(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcLocalFileName, int32_t szLocalFileName, TSBFileTransferModeRaw Mode, int64_t RestartFrom);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_DownloadStream(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TStreamHandle LocalStream, TSBFileTransferModeRaw Mode);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_DownloadStream_1(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TStreamHandle LocalStream, TSBFileTransferModeRaw Mode, int64_t RestartFrom);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_UploadFile(TElWebDAVClientHandle _Handle, const char * pcLocalFileName, int32_t szLocalFileName, const char * pcURL, int32_t szURL, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_UploadFile_1(TElWebDAVClientHandle _Handle, const char * pcLocalFileName, int32_t szLocalFileName, const char * pcURL, int32_t szURL, TSBFileTransferModeRaw Mode, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_UploadFile_2(TElWebDAVClientHandle _Handle, const char * pcLocalFileName, int32_t szLocalFileName, const char * pcURL, int32_t szURL, TSBFileTransferModeRaw Mode, int64_t RestartFrom, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_UploadStream(TElWebDAVClientHandle _Handle, TStreamHandle LocalStream, const char * pcURL, int32_t szURL, TSBFileTransferModeRaw Mode, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_UploadStream_1(TElWebDAVClientHandle _Handle, TStreamHandle LocalStream, const char * pcURL, int32_t szURL, TSBFileTransferModeRaw Mode, int64_t RestartFrom, TElWebDAVLockListHandle Locks, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_CancelRequest(TElWebDAVClientHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_GetFullURL(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_GetFileSize(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_GetFileSize_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_GetResourceType(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TSBFileTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_FileExists(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_DirectoryExists(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Lock(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcOwner, int32_t szOwner, TSBWebDAVLockScopeRaw Scope, TSBWebDAVDepthRaw Depth, int32_t Timeout, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Lock_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Obj, const char * pcOwner, int32_t szOwner, TSBWebDAVLockScopeRaw Scope, TSBWebDAVDepthRaw Depth, int32_t Timeout, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Unlock(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVLockHandle Lock);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Unlock_1(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVLockHandle Lock, TElWebDAVErrorListHandle Errors);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_RefreshLock(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVLockHandle Lock);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_PrincipalCollectionSet(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle URLs);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_ListPrincipals(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPrincipalListHandle List, TSBWebDAVDepthRaw Depth);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_AclPrincipalPropSetFirst(TElWebDAVClientHandle _Handle, void * * Ctx, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle Properties, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_AclPrincipalPropSetNext(TElWebDAVClientHandle _Handle, void * Ctx, TElWebDAVPropertyInfoListHandle Properties, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_AclPrincipalPropSetClose(TElWebDAVClientHandle _Handle, void * Ctx);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_PrincipalPropertySearchFirst(TElWebDAVClientHandle _Handle, void * * Ctx, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle MatchProperties, TElStringListHandle Matches, TElWebDAVPropertyInfoListHandle Properties, int8_t ApplyToPrincipalCollectionSet, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_PrincipalPropertySearchNext(TElWebDAVClientHandle _Handle, void * Ctx, TElWebDAVPropertyInfoListHandle Properties, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_PrincipalPropertySearchClose(TElWebDAVClientHandle _Handle, void * Ctx);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_PrincipalMatch(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoHandle PrincipalProperty, TElWebDAVPropertyInfoListHandle Properties, TElWebDAVObjectListHandle Objects);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_PrincipalSearchPropertySet(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle Properties);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_InheritedAclSet(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle URLs);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_AclRestrictions(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVACLRestrictionsHandle Restrictions);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_SupportedPrivilegeSet(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVSupportedPrivilegeSetHandle PrivilegeSet);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_CurrentUserPrivilegeSet(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, int32_t * Privileges);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_GetAcl(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVACLHandle CurrentAcl);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_SetAcl(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElWebDAVACLHandle NewAcl);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_CreateAddressBook(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcDisplayName, int32_t szDisplayName, const char * pcDescription, int32_t szDescription, const char * pcLang, int32_t szLang, TElWebDAVLockListHandle Locks);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_CreateAddressBook_1(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Parent, const char * pcName, int32_t szName, const char * pcDisplayName, int32_t szDisplayName, const char * pcDescription, int32_t szDescription, const char * pcLang, int32_t szLang);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_CreateAddressBook_2(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, const char * pcDisplayName, int32_t szDisplayName, const char * pcDescription, int32_t szDescription, TElWebDAVLockListHandle Locks);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_CreateAddressBook_3(TElWebDAVClientHandle _Handle, TElWebDAVStorageObjectHandle Parent, const char * pcName, int32_t szName, const char * pcDisplayName, int32_t szDisplayName, const char * pcDescription, int32_t szDescription);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_UploadVCard(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TStreamHandle Strm, char * pcETag, int32_t * szETag, TElWebDAVErrorListHandle Errors, TElWebDAVLockListHandle Locks);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_UploadVCard_1(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElVCardHandle VCard, char * pcETag, int32_t * szETag, TElWebDAVErrorListHandle Errors, TElWebDAVLockListHandle Locks);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_DownloadVCard(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElVCardHandle * VCard, TElWebDAVLockListHandle Locks);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_GetAddressBookInfo(TElWebDAVClientHandle _Handle, const char * pcURL, int32_t szURL, TElCardDavAddressBookInfoHandle Info);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_AddressBookQueryFirst(TElWebDAVClientHandle _Handle, void * * Ctx, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle Properties, TElStringListHandle AddressDataProps, TElCardDavFilterHandle Filter, int32_t Limit, int8_t All, TSBWebDAVDepthRaw Depth, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_AddressBookQueryNext(TElWebDAVClientHandle _Handle, void * Ctx, TElWebDAVPropertyInfoListHandle Properties, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_AddressBookQueryClose(TElWebDAVClientHandle _Handle, void * Ctx);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_AddressBookMultigetFirst(TElWebDAVClientHandle _Handle, void * * Ctx, const char * pcURL, int32_t szURL, TElWebDAVPropertyInfoListHandle Properties, TElStringListHandle AddressDataProps, TElStringListHandle Hrefs, int8_t All, TSBWebDAVDepthRaw Depth, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_AddressBookMultigetNext(TElWebDAVClientHandle _Handle, void * Ctx, TElWebDAVPropertyInfoListHandle Properties, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_AddressBookMultigetClose(TElWebDAVClientHandle _Handle, void * Ctx);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_get_CurrentUserPrincipal(TElWebDAVClientHandle _Handle, SBWebDAVClient_TElWebDAVPrincipalHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_get_Authenticated(TElWebDAVClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_get_AddressBookURLs(TElWebDAVClientHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_get_HTTPSWebDAVClient(TElWebDAVClientHandle _Handle, TElHTTPSWebDAVClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_set_HTTPSWebDAVClient(TElWebDAVClientHandle _Handle, TElHTTPSWebDAVClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_get_FileSystemAdapter(TElWebDAVClientHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_set_FileSystemAdapter(TElWebDAVClientHandle _Handle, TElCustomFileSystemAdapterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_get_BaseURL(TElWebDAVClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_set_BaseURL(TElWebDAVClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_get_Owner_AnsiString(TElWebDAVClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_set_Owner_AnsiString(TElWebDAVClientHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_get_LastListedURL(TElWebDAVClientHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_get_IncludeBackLinks(TElWebDAVClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_set_IncludeBackLinks(TElWebDAVClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_get_EncodeURL(TElWebDAVClientHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_set_EncodeURL(TElWebDAVClientHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_get_SupportedClasses(TElWebDAVClientHandle _Handle, TSBWebDAVClassesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_get_OnRedirection(TElWebDAVClientHandle _Handle, TSBHTTPRedirectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_set_OnRedirection(TElWebDAVClientHandle _Handle, TSBHTTPRedirectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_get_OnDynamicDataNeeded(TElWebDAVClientHandle _Handle, TSBHTTPDynamicDataNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_set_OnDynamicDataNeeded(TElWebDAVClientHandle _Handle, TSBHTTPDynamicDataNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_get_OnData(TElWebDAVClientHandle _Handle, TSBDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_set_OnData(TElWebDAVClientHandle _Handle, TSBDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVClient_Create(TComponentHandle AOwner, TElWebDAVClientHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVCLIENT */

#ifdef SB_USE_CLASS_TELWEBDAVLOCKLIST
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLockList_Merge(TElWebDAVLockListHandle _Handle, const TElWebDAVLockListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLockList_Clone(TElWebDAVLockListHandle _Handle, TElWebDAVLockListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLockList_Add(TElWebDAVLockListHandle _Handle, const TElWebDAVLockHandle Lock);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLockList_Remove(TElWebDAVLockListHandle _Handle, const TElWebDAVLockHandle Lock);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLockList_get_Locks(TElWebDAVLockListHandle _Handle, int32_t Idx, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLockList_get_Count(TElWebDAVLockListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLockList_get_ToIfHeader(TElWebDAVLockListHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLockList_Create(TComponentHandle AOwner, TElWebDAVLockListHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVLOCKLIST */

#ifdef SB_USE_CLASS_TELWEBDAVMULTISTATUSRESPONSE
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMultistatusResponse_LoadFromStream(TElWebDAVMultistatusResponseHandle _Handle, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMultistatusResponse_get_Responses(TElWebDAVMultistatusResponseHandle _Handle, int32_t Idx, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMultistatusResponse_get_Count(TElWebDAVMultistatusResponseHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMultistatusResponse_Create(TElWebDAVMultistatusResponseHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVMULTISTATUSRESPONSE */

#ifdef SB_USE_CLASS_TELWEBDAVERROR
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVError_LoadFromXML(TElWebDAVErrorHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVError_get_NS(TElWebDAVErrorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVError_set_NS(TElWebDAVErrorHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVError_get_Value(TElWebDAVErrorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVError_set_Value(TElWebDAVErrorHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVError_Create(TElWebDAVErrorHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVERROR */

#ifdef SB_USE_CLASS_TELWEBDAVPRIVILEGESET
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrivilegeSet_LoadFromXML(TElWebDAVPrivilegeSetHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrivilegeSet_get_Value(TElWebDAVPrivilegeSetHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrivilegeSet_set_Value(TElWebDAVPrivilegeSetHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrivilegeSet_Create(TElWebDAVPrivilegeSetHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVPRIVILEGESET */

#ifdef SB_USE_CLASS_TELWEBDAVSUPPORTEDPRIVILEGE
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_LoadFromXML(TElWebDAVSupportedPrivilegeHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_get_NS(TElWebDAVSupportedPrivilegeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_set_NS(TElWebDAVSupportedPrivilegeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_get_Name(TElWebDAVSupportedPrivilegeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_set_Name(TElWebDAVSupportedPrivilegeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_get_Description(TElWebDAVSupportedPrivilegeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_set_Description(TElWebDAVSupportedPrivilegeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_get_DescLang(TElWebDAVSupportedPrivilegeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_set_DescLang(TElWebDAVSupportedPrivilegeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_get__Abstract(TElWebDAVSupportedPrivilegeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_set__Abstract(TElWebDAVSupportedPrivilegeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_get_Value(TElWebDAVSupportedPrivilegeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_set_Value(TElWebDAVSupportedPrivilegeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_get_AggregatedPrivileges(TElWebDAVSupportedPrivilegeHandle _Handle, int32_t Index, TElWebDAVSupportedPrivilegeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_get_AggregatedPrivilegeCount(TElWebDAVSupportedPrivilegeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilege_Create(TElWebDAVSupportedPrivilegeHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVSUPPORTEDPRIVILEGE */

#ifdef SB_USE_CLASS_TELWEBDAVSUPPORTEDPRIVILEGESET
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilegeSet_LoadFromXML(TElWebDAVSupportedPrivilegeSetHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilegeSet_IsAbstract(TElWebDAVSupportedPrivilegeSetHandle _Handle, int32_t Privilege, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilegeSet_get_AggregatedPrivileges(TElWebDAVSupportedPrivilegeSetHandle _Handle, int32_t Index, TElWebDAVSupportedPrivilegeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilegeSet_get_AggregatedPrivilegeCount(TElWebDAVSupportedPrivilegeSetHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVSupportedPrivilegeSet_Create(TElWebDAVSupportedPrivilegeSetHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVSUPPORTEDPRIVILEGESET */

#ifdef SB_USE_CLASS_TELWEBDAVPRINCIPALSEARCHPROPERTYSETRESPONSE
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalSearchPropertySetResponse_LoadFromStream(TElWebDAVPrincipalSearchPropertySetResponseHandle _Handle, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalSearchPropertySetResponse_get_Responses(TElWebDAVPrincipalSearchPropertySetResponseHandle _Handle, int32_t Idx, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalSearchPropertySetResponse_get_Count(TElWebDAVPrincipalSearchPropertySetResponseHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalSearchPropertySetResponse_Create(TElWebDAVPrincipalSearchPropertySetResponseHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVPRINCIPALSEARCHPROPERTYSETRESPONSE */

#ifdef SB_USE_CLASS_TELWEBDAVSTORAGEOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_Clone(TElWebDAVStorageObjectHandle _Handle, TElWebDAVStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_ReadFromXML(TElWebDAVStorageObjectHandle _Handle, TElXMLDOMNodeHandle Node, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_Lock(TElWebDAVStorageObjectHandle _Handle, TSBWebDAVLockScopeRaw Scope, TSBWebDAVDepthRaw Depth, int32_t Timeout, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_Unlock(TElWebDAVStorageObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_Unlock_1(TElWebDAVStorageObjectHandle _Handle, int32_t Idx);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_GetIfHeader(TElWebDAVStorageObjectHandle _Handle, int8_t WithETag, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_Storage(TElWebDAVStorageObjectHandle _Handle, TElWebDAVClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_ParentURL(TElWebDAVStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_URL(TElWebDAVStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_FullURL(TElWebDAVStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_CreationDate(TElWebDAVStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_DisplayName(TElWebDAVStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_ContentLanguage(TElWebDAVStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_ContentLength(TElWebDAVStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_ContentType(TElWebDAVStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_ETag(TElWebDAVStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_LastModified(TElWebDAVStorageObjectHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_ResourceType(TElWebDAVStorageObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_Collection(TElWebDAVStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_IsAddressBook(TElWebDAVStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_BackLink(TElWebDAVStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_SupportsExclusiveLock(TElWebDAVStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_SupportsSharedLock(TElWebDAVStorageObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_get_Locks(TElWebDAVStorageObjectHandle _Handle, TElWebDAVLockListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_Create(const TElWebDAVClientHandle Storage, const char * pcURL, int32_t szURL, TElWebDAVStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVStorageObject_Create_1(const TElWebDAVClientHandle Storage, const char * pcURL, int32_t szURL, int8_t HrefOnly, TElWebDAVStorageObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVSTORAGEOBJECT */

#ifdef SB_USE_CLASS_TELWEBDAVERRORRESPONSE
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVErrorResponse_get_URL(TElWebDAVErrorResponseHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVErrorResponse_get_Status(TElWebDAVErrorResponseHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVErrorResponse_get_Error(TElWebDAVErrorResponseHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVErrorResponse_get_Description(TElWebDAVErrorResponseHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVErrorResponse_Create(const TElXMLDOMNodeHandle Node, TElWebDAVErrorResponseHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVERRORRESPONSE */

#ifdef SB_USE_CLASS_TELWEBDAVOBJECTLIST
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVObjectList_Clear(TElWebDAVObjectListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVObjectList_get_Objects(TElWebDAVObjectListHandle _Handle, int32_t Index, TElWebDAVStorageObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVObjectList_get_Count(TElWebDAVObjectListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVObjectList_Create(TElWebDAVObjectListHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVOBJECTLIST */

#ifdef SB_USE_CLASS_TELWEBDAVERRORLIST
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVErrorList_Clear(TElWebDAVErrorListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVErrorList_get_Objects(TElWebDAVErrorListHandle _Handle, int32_t Index, TElWebDAVErrorResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVErrorList_get_Count(TElWebDAVErrorListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVErrorList_Create(TElWebDAVErrorListHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVERRORLIST */

#ifdef SB_USE_CLASS_SBWEBDAVCLIENT_TELWEBDAVPRINCIPAL
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVClient_TElWebDAVPrincipal_ReadFromXML(SBWebDAVClient_TElWebDAVPrincipalHandle _Handle, TElXMLDOMNodeHandle Node, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVClient_TElWebDAVPrincipal_get_DisplayName(SBWebDAVClient_TElWebDAVPrincipalHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVClient_TElWebDAVPrincipal_get_URL(SBWebDAVClient_TElWebDAVPrincipalHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVClient_TElWebDAVPrincipal_get_PrincipalURL(SBWebDAVClient_TElWebDAVPrincipalHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVClient_TElWebDAVPrincipal_get_AlternateURISet(SBWebDAVClient_TElWebDAVPrincipalHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVClient_TElWebDAVPrincipal_get_GroupMemberSet(SBWebDAVClient_TElWebDAVPrincipalHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVClient_TElWebDAVPrincipal_get_GroupMembership(SBWebDAVClient_TElWebDAVPrincipalHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVClient_TElWebDAVPrincipal_get_AddressbookHomeSet(SBWebDAVClient_TElWebDAVPrincipalHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVClient_TElWebDAVPrincipal_get_AddressURL(SBWebDAVClient_TElWebDAVPrincipalHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVClient_TElWebDAVPrincipal_get_IsGroup(SBWebDAVClient_TElWebDAVPrincipalHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVClient_TElWebDAVPrincipal_Create(SBWebDAVClient_TElWebDAVPrincipalHandle * OutResult);
#endif /* SB_USE_CLASS_SBWEBDAVCLIENT_TELWEBDAVPRINCIPAL */

#ifdef SB_USE_CLASS_TELWEBDAVPRINCIPALLIST
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalList_Clear(TElWebDAVPrincipalListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalList_get_Principals(TElWebDAVPrincipalListHandle _Handle, int32_t Index, SBWebDAVClient_TElWebDAVPrincipalHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalList_get_Count(TElWebDAVPrincipalListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalList_Create(TElWebDAVPrincipalListHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVPRINCIPALLIST */

#ifdef SB_USE_CLASS_TELCARDDAVSUPPORTEDADDRESSDATA
SB_IMPORT uint32_t SB_APIENTRY TElCardDavSupportedAddressData_get_ContentType(TElCardDavSupportedAddressDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavSupportedAddressData_get_Version(TElCardDavSupportedAddressDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavSupportedAddressData_Create(TElCardDavSupportedAddressDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELCARDDAVSUPPORTEDADDRESSDATA */

#ifdef SB_USE_CLASS_TELCARDDAVADDRESSBOOKINFO
SB_IMPORT uint32_t SB_APIENTRY TElCardDavAddressBookInfo_get_Description(TElCardDavAddressBookInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavAddressBookInfo_get_SupportedAddressDataCount(TElCardDavAddressBookInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavAddressBookInfo_get_SupportedAddressData(TElCardDavAddressBookInfoHandle _Handle, int32_t Index, TElCardDavSupportedAddressDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavAddressBookInfo_get_MaxResourceSize(TElCardDavAddressBookInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavAddressBookInfo_Create(TElCardDavAddressBookInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELCARDDAVADDRESSBOOKINFO */

#ifdef SB_USE_CLASS_TELCARDDAVREPORTCONTEXT
SB_IMPORT uint32_t SB_APIENTRY TElCardDavReportContext_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELCARDDAVREPORTCONTEXT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElWebDAVClient_ce_ptr;
extern zend_class_entry *TElWebDAVLockList_ce_ptr;
extern zend_class_entry *TElWebDAVMultistatusResponse_ce_ptr;
extern zend_class_entry *TElWebDAVError_ce_ptr;
extern zend_class_entry *TElWebDAVPrivilegeSet_ce_ptr;
extern zend_class_entry *TElWebDAVSupportedPrivilege_ce_ptr;
extern zend_class_entry *TElWebDAVSupportedPrivilegeSet_ce_ptr;
extern zend_class_entry *TElWebDAVPrincipalSearchPropertySetResponse_ce_ptr;
extern zend_class_entry *TElWebDAVStorageObject_ce_ptr;
extern zend_class_entry *TElWebDAVErrorResponse_ce_ptr;
extern zend_class_entry *TElWebDAVObjectList_ce_ptr;
extern zend_class_entry *TElWebDAVErrorList_ce_ptr;
extern zend_class_entry *SBWebDAVClient_TElWebDAVPrincipal_ce_ptr;
extern zend_class_entry *TElWebDAVPrincipalList_ce_ptr;
extern zend_class_entry *TElCardDavSupportedAddressData_ce_ptr;
extern zend_class_entry *TElCardDavAddressBookInfo_ce_ptr;
extern zend_class_entry *TElCardDavReportContext_ce_ptr;

void Register_TElWebDAVClient(TSRMLS_D);
void Register_TElWebDAVLockList(TSRMLS_D);
void Register_TElWebDAVMultistatusResponse(TSRMLS_D);
void Register_TElWebDAVError(TSRMLS_D);
void Register_TElWebDAVPrivilegeSet(TSRMLS_D);
void Register_TElWebDAVSupportedPrivilege(TSRMLS_D);
void Register_TElWebDAVSupportedPrivilegeSet(TSRMLS_D);
void Register_TElWebDAVPrincipalSearchPropertySetResponse(TSRMLS_D);
void Register_TElWebDAVStorageObject(TSRMLS_D);
void Register_TElWebDAVErrorResponse(TSRMLS_D);
void Register_TElWebDAVObjectList(TSRMLS_D);
void Register_TElWebDAVErrorList(TSRMLS_D);
void Register_SBWebDAVClient_TElWebDAVPrincipal(TSRMLS_D);
void Register_TElWebDAVPrincipalList(TSRMLS_D);
void Register_TElCardDavSupportedAddressData(TSRMLS_D);
void Register_TElCardDavAddressBookInfo(TSRMLS_D);
void Register_TElCardDavReportContext(TSRMLS_D);
SB_PHP_FUNCTION(SBWebDAVClient, AddSlash);
SB_PHP_FUNCTION(SBWebDAVClient, HTTPSuccess);
SB_PHP_FUNCTION(SBWebDAVClient, Unauthorized);
void Register_SBWebDAVClient_Constants(int module_number TSRMLS_DC);
void Register_SBWebDAVClient_Enum_Flags(TSRMLS_D);
void Register_SBWebDAVClient_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_WEBDAVCLIENT
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVClient_AddSlash(const char * pcs, int32_t szs, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVClient_HTTPSuccess(int32_t Res, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVClient_Unauthorized(TElClassHandle Err, int8_t * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_WEBDAVCLIENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBWEBDAVCLIENT */

