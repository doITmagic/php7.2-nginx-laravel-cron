#ifndef __INC_SBWEBDAVCOMMON
#define __INC_SBWEBDAVCOMMON

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbencoding.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbsharedresource.h"
#include "sbhttpscommon.h"
#include "sbstringlist.h"
#include "sbxmldefs.h"
#include "sbxmlutils.h"
#include "sbxmlcore.h"
#include "sbxmlcharsets.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SNotImplemented 	"Not implemented"
#ifndef SB_SInternalError
#define SB_SInternalError 	"Internal error"
#endif
#define SB_SNotAllPropertiesSet 	"Not all standard WebDAV property classes set"
#define SB_SNotAllPropertyHandlersSet 	"Not all WebDAV property handlers set"
#define SB_SFSAdapterNotSet 	"FileSystemAdapter property is not set"
#define SB_SFSAdapterEventsNotSet 	"FileSystemAdapter events are not set"
#define SB_SInvalidDepthParameter 	"Invalid depth parameter"
#define SB_SInvalidMethodParameters 	"Invalid method parameters"
#define SB_SInvalidScopeParameter 	"Invalid scope parameter"
#define SB_SInvalidXML 	"Invalid XML structure"
#define SB_SInvalidLocksXML 	"Invalid serialized XML structure"
#define SB_SCollectionExpected 	"Collection object or URL is expected as a parameter"
#define SB_SDocumentExpected 	"Document object or URL is expected as a parameter"
#define SB_SInvalidTimeout 	"Invalid timeout"
#define SB_SHttpError 	"HTTP error"
#define SB_SWrongFileSize 	"Can not read file size"
#define SB_SResumeOffsetTooLarge 	"Resume offset %d is too large"
#define SB_SErrorStatusCode 	"Status code error: %s"
#define SB_SUsernameNotFound 	"Username not found"
#define SB_SGroupNotFound 	"Group name not found"
#define SB_SPreconditionError 	"Precondition error"
#define SB_SVCardContentType 	"text/vcard"
#define SB_SResourceAlreadyExistsOrProtected 	"Resource already exists or is protected"
#define SB_SFileSystemError 	"File system error: %s"
#define SB_wdpcRead 	1
#define SB_wdpcWrite 	2
#define SB_wdpcAll 	4
#define SB_wdpcCalReadFreeBusy 	2048
#define SB_WEBDAV_DEFAULT_PROPERTY_NAMESPACE 	"DAV:"
#define SB_CARDDAV_DEFAULT_PROPERTY_NAMESPACE 	"urn:ietf:params:xml:ns:carddav"
#define SB_CALDAV_DEFAULT_PROPERTY_NAMESPACE 	"urn:ietf:params:xml:ns:caldav"
#define SB_WEBDAV_LOCK_INFINITE_TIMEOUT 	0
#define SB_WEBDAV_LOCK_TOKEN_LEN 	32
#define SB_WEBDAV_ETAG_LEN 	20
#define SB_WEBDAV_IF_HEADER_MAX_RESOURCES 	256
#define SB_ERROR_FACILITY_WEBDAV 	176128
#define SB_ERROR_WEBDAV_ERROR_FLAG 	2048
#define SB_ERROR_WEBDAVCLI_ERROR_FLAG 	2304
#define SB_ERROR_WEBDAVSRV_ERROR_FLAG 	2560
#define SB_WEBDAV_ERROR_INVALID_XML 	178177
#define SB_WEBDAV_ERROR_INVALID_LOCKS_XML 	178178
#define SB_WEBDAV_ERROR_INTERNAL 	178256
#define SB_WEBDAV_CLIENT_ERROR_COLLECTION_EXPECTED 	178433
#define SB_WEBDAV_CLIENT_ERROR_DOCUMENT_EXPECTED 	178434
#define SB_WEBDAV_CLIENT_ERROR_HTTPSWEBDAVCLIENT 	178435
#define SB_WEBDAV_CLIENT_ERROR_STATUSCODE 	178436
#define SB_WEBDAV_CLIENT_ERROR_NO_FILESIZE 	178437
#define SB_WEBDAV_CLIENT_ERROR_OFFSET_TOO_LARGE 	178438
#define SB_WEBDAV_CLIENT_ERROR_PRECONDITION_FAILED 	178439
#define SB_WEBDAV_CLIENT_ERROR_PROTECTED_OR_INHERITED_ACE 	178440
#define SB_WEBDAV_CLIENT_ERROR_HTTP_ERROR 	178441
#define SB_WEBDAV_SERVER_ERROR_INVALID_DEPTH 	178689
#define SB_WEBDAV_SERVER_ERROR_INVALID_SCOPE 	178690
#define SB_WEBDAV_SERVER_ERROR_INVALID_TIMEOUT 	178691
#define SB_WEBDAV_PRECOND_ERROR_SUPPORTED_COLLATION 	178692
#define SB_WEBDAV_SERVER_ERROR_RESOUCE_EXISTS_OR_PROTECTED 	178693
#define SB_WEBDAV_SERVER_ERROR_FILESYSTEM 	178694
#define SB_WEBDAV_PROPERTY_FIRST 	1
#define SB_WEBDAV_PROPERTY_LAST 	10
#define SB_WEBDAV_PROTECTED_PROPERTY_FIRST 	1
#define SB_WEBDAV_PROTECTED_PROPERTY_LAST 	19
#define SB_WEBDAV_ACL_PROPERTY_FIRST 	1
#define SB_WEBDAV_ACL_PROPERTY_LAST 	12
#define SB_WEBDAV_PRINCIPAL_PROPERTY_FIRST 	1
#define SB_WEBDAV_PRINCIPAL_PROPERTY_LAST 	3

typedef TElClassHandle TElWebDAVPropertyInfoHandle;

typedef TElWebDAVPropertyInfoHandle ElWebDAVPropertyInfoHandle;

typedef TElClassHandle TElWebDAVPropertyInfoListHandle;

typedef TElWebDAVPropertyInfoListHandle ElWebDAVPropertyInfoListHandle;

typedef TElClassHandle TElWebDAVNamespacePrefixMapHandle;

typedef TElWebDAVNamespacePrefixMapHandle ElWebDAVNamespacePrefixMapHandle;

typedef TElClassHandle TElWebDAVLockHandle;

typedef TElWebDAVLockHandle ElWebDAVLockHandle;

typedef TElClassHandle TElWebDAVFilterHandle;

typedef TElClassHandle TElWebDAVTextMatchFilterHandle;

typedef TElClassHandle TElCardDavTextMatchFilterHandle;

typedef TElClassHandle TElCardDavPropFilterHandle;

typedef TElClassHandle TElCardDavFilterHandle;

typedef TElClassHandle TElCardDavParamFilterHandle;

typedef TElClassHandle TElWebDAVACEHandle;

typedef TElClassHandle TElWebDAVACLHandle;

typedef TElClassHandle TElWebDAVACLRestrictionsHandle;

typedef uint8_t TSBWebDAVDepthRaw;

typedef enum
{
	wddZero = 0,
	wddOne = 1,
	wddInfinity = 2
} TSBWebDAVDepth;

typedef uint8_t TSBWebDAVLockScopeRaw;

typedef enum
{
	wlsExclusive = 0,
	wlsShared = 1
} TSBWebDAVLockScope;

typedef uint8_t TSBWebDAVFilterTestRaw;

typedef enum
{
	wdftAnyOf = 0,
	wdftAllOf = 1
} TSBWebDAVFilterTest;

typedef uint8_t TSBWebDAVFilterTextMatchCollationRaw;

typedef enum
{
	wdfcAscii = 0,
	wdfcUnicode = 1,
	wdfcOctet = 2
} TSBWebDAVFilterTextMatchCollation;

typedef uint8_t TSBWebDAVFilterTextMatchTypeRaw;

typedef enum
{
	wdfmEquals = 0,
	wdfmContains = 1,
	wdfmStartsWith = 2,
	wdfmEndsWith = 3
} TSBWebDAVFilterTextMatchType;

typedef uint8_t TSBPrincipalTypeRaw;

typedef enum
{
	wptNone = 0,
	wptAll = 1,
	wptAuthenticated = 2,
	wptUnauthenticated = 3,
	wptSelf = 4,
	wptHref = 5,
	wptProperty = 6,
	wptPropertyOwner = 7,
	wptPropertyGroup = 8
} TSBPrincipalType;

typedef uint8_t TSBWebDAVACLErrorRaw;

typedef enum
{
	waeNone = 0,
	waeNoACEConflict = 1,
	waeNoProtectedACEConflict = 2,
	waeNoInheritedACEConflict = 3,
	waeLimitedNumberOfACEs = 4,
	waeDenyBeforeGrant = 5,
	waeGrantOnly = 6,
	waeNoInvert = 7,
	waeNoAbstract = 8,
	waeNoSupportedPrivilege = 9,
	waeMissingRequiredPrincipal = 10,
	waeRecognizedPrincipal = 11,
	wasAllowedPrincipal = 12
} TSBWebDAVACLError;

#ifdef SB_USE_CLASS_TELWEBDAVPROPERTYINFO
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_Clone(TElWebDAVPropertyInfoHandle _Handle, TElWebDAVPropertyInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_get_Inited(TElWebDAVPropertyInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_set_Inited(TElWebDAVPropertyInfoHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_get_NS(TElWebDAVPropertyInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_set_NS(TElWebDAVPropertyInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_get_Name(TElWebDAVPropertyInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_set_Name(TElWebDAVPropertyInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_get_Value(TElWebDAVPropertyInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_set_Value(TElWebDAVPropertyInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_get_Status(TElWebDAVPropertyInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_set_Status(TElWebDAVPropertyInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_get_Hrefs(TElWebDAVPropertyInfoHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_get_Description(TElWebDAVPropertyInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_set_Description(TElWebDAVPropertyInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfo_Create(const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, const char * pcValue, int32_t szValue, TElWebDAVPropertyInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVPROPERTYINFO */

#ifdef SB_USE_CLASS_TELWEBDAVPROPERTYINFOLIST
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfoList_Clear(TElWebDAVPropertyInfoListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfoList_Add(TElWebDAVPropertyInfoListHandle _Handle, const TElWebDAVPropertyInfoHandle PropInfo);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfoList_Remove(TElWebDAVPropertyInfoListHandle _Handle, const TElWebDAVPropertyInfoHandle PropInfo);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfoList_Find(TElWebDAVPropertyInfoListHandle _Handle, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, TElWebDAVPropertyInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfoList_get_Count(TElWebDAVPropertyInfoListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfoList_get_Item(TElWebDAVPropertyInfoListHandle _Handle, int32_t index, TElWebDAVPropertyInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPropertyInfoList_Create(TElWebDAVPropertyInfoListHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVPROPERTYINFOLIST */

#ifdef SB_USE_CLASS_TELWEBDAVNAMESPACEPREFIXMAP
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVNamespacePrefixMap_Clear(TElWebDAVNamespacePrefixMapHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVNamespacePrefixMap_AddNS(TElWebDAVNamespacePrefixMapHandle _Handle, const char * pcNS, int32_t szNS);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVNamespacePrefixMap_RemoveNS(TElWebDAVNamespacePrefixMapHandle _Handle, const char * pcNS, int32_t szNS);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVNamespacePrefixMap_GetPrefix(TElWebDAVNamespacePrefixMapHandle _Handle, const char * pcNS, int32_t szNS, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVNamespacePrefixMap_Create(int8_t WithDAV, TElWebDAVNamespacePrefixMapHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVNAMESPACEPREFIXMAP */

#ifdef SB_USE_CLASS_TELWEBDAVLOCK
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_TimeoutToString(int32_t Timeout, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_TimeoutToString_1(TElWebDAVLockHandle _Handle, int32_t Timeout, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_StringToTimeout(const char * pcS, int32_t szS, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_StringToTimeout_1(TElWebDAVLockHandle _Handle, const char * pcS, int32_t szS, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_ReadTokenFromXML(TStreamHandle Strm, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_ReadTokenFromXML_1(TElWebDAVLockHandle _Handle, TStreamHandle Strm, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_LoadFromXML(TElXMLDOMElementHandle Elem, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_LoadFromXML_1(TElWebDAVLockHandle _Handle, TElXMLDOMElementHandle Elem, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_Clone(TElWebDAVLockHandle _Handle, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_ToXML(TElWebDAVLockHandle _Handle, int8_t WithToken, const char * pcNS, int32_t szNS, int8_t EncodeURL, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_SaveToXML(TElWebDAVLockHandle _Handle, const TElXMLDOMDocumentHandle Doc, const TElXMLDOMNodeHandle Base, int8_t WithToken, int8_t EncodeURL);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_LocksURL(TElWebDAVLockHandle _Handle, const char * pcURL, int32_t szURL, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_CompatibleWith(TElWebDAVLockHandle _Handle, const TElWebDAVLockHandle Lock, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_ConflictsWith(TElWebDAVLockHandle _Handle, const TElWebDAVLockHandle Lock, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_Refresh(TElWebDAVLockHandle _Handle, int64_t Timeout);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_Unlock(TElWebDAVLockHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_BeginUse(TElWebDAVLockHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_EndUse(TElWebDAVLockHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_ToString(TElWebDAVLockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_get_URL(TElWebDAVLockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_get_Owner(TElWebDAVLockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_get_Token(TElWebDAVLockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_get_Scope(TElWebDAVLockHandle _Handle, TSBWebDAVLockScopeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_get_Depth(TElWebDAVLockHandle _Handle, TSBWebDAVDepthRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_get_TTL(TElWebDAVLockHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_get_Timeout(TElWebDAVLockHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_get_UnlockTime(TElWebDAVLockHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_get_Unlocked(TElWebDAVLockHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_get_InUse(TElWebDAVLockHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_get_ToIfHeader(TElWebDAVLockHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLock_Create(const char * pcURL, int32_t szURL, const char * pcOwner, int32_t szOwner, TSBWebDAVLockScopeRaw Scope, TSBWebDAVDepthRaw Depth, int64_t Timeout, const char * pcToken, int32_t szToken, TElWebDAVLockHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVLOCK */

#ifdef SB_USE_CLASS_TELWEBDAVFILTER
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVFilter_LoadFromXML(TElWebDAVFilterHandle _Handle, TElXMLDOMElementHandle Element, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVFilter_SaveToXML(TElWebDAVFilterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVFilter_get_Parent(TElWebDAVFilterHandle _Handle, TElWebDAVFilterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVFilter_set_Parent(TElWebDAVFilterHandle _Handle, TElWebDAVFilterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVFilter_get_Name(TElWebDAVFilterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVFilter_set_Name(TElWebDAVFilterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVFilter_get_FullPath(TElWebDAVFilterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVFilter_get_Empty(TElWebDAVFilterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVFilter_Create(TElWebDAVFilterHandle Parent, TElWebDAVFilterHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVFILTER */

#ifdef SB_USE_CLASS_TELWEBDAVTEXTMATCHFILTER
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTextMatchFilter_LoadFromXML(TElWebDAVTextMatchFilterHandle _Handle, TElXMLDOMElementHandle Element, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTextMatchFilter_SaveToXML(TElWebDAVTextMatchFilterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTextMatchFilter_get_Collation(TElWebDAVTextMatchFilterHandle _Handle, TSBWebDAVFilterTextMatchCollationRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTextMatchFilter_set_Collation(TElWebDAVTextMatchFilterHandle _Handle, TSBWebDAVFilterTextMatchCollationRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTextMatchFilter_get_MatchType(TElWebDAVTextMatchFilterHandle _Handle, TSBWebDAVFilterTextMatchTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTextMatchFilter_set_MatchType(TElWebDAVTextMatchFilterHandle _Handle, TSBWebDAVFilterTextMatchTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTextMatchFilter_get_NegateCondition(TElWebDAVTextMatchFilterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTextMatchFilter_set_NegateCondition(TElWebDAVTextMatchFilterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTextMatchFilter_get_Value(TElWebDAVTextMatchFilterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTextMatchFilter_set_Value(TElWebDAVTextMatchFilterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTextMatchFilter_Create(TElWebDAVFilterHandle Parent, TElWebDAVTextMatchFilterHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVTEXTMATCHFILTER */

#ifdef SB_USE_CLASS_TELCARDDAVTEXTMATCHFILTER
SB_IMPORT uint32_t SB_APIENTRY TElCardDavTextMatchFilter_Create(TElWebDAVFilterHandle Parent, TElCardDavTextMatchFilterHandle * OutResult);
#endif /* SB_USE_CLASS_TELCARDDAVTEXTMATCHFILTER */

#ifdef SB_USE_CLASS_TELCARDDAVPROPFILTER
SB_IMPORT uint32_t SB_APIENTRY TElCardDavPropFilter_LoadFromXML(TElCardDavPropFilterHandle _Handle, TElXMLDOMElementHandle Element, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavPropFilter_SaveToXML(TElCardDavPropFilterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavPropFilter_AddSubFilter(TElCardDavPropFilterHandle _Handle, TElWebDAVFilterHandle Filter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavPropFilter_RemoveSubFilter(TElCardDavPropFilterHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavPropFilter_get_Test(TElCardDavPropFilterHandle _Handle, TSBWebDAVFilterTestRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavPropFilter_set_Test(TElCardDavPropFilterHandle _Handle, TSBWebDAVFilterTestRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavPropFilter_get_IsNotDefined(TElCardDavPropFilterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavPropFilter_set_IsNotDefined(TElCardDavPropFilterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavPropFilter_get_SubFilterCount(TElCardDavPropFilterHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavPropFilter_get_SubFilters(TElCardDavPropFilterHandle _Handle, int32_t Index, TElWebDAVFilterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavPropFilter_Create(TElWebDAVFilterHandle Parent, TElCardDavPropFilterHandle * OutResult);
#endif /* SB_USE_CLASS_TELCARDDAVPROPFILTER */

#ifdef SB_USE_CLASS_TELCARDDAVFILTER
SB_IMPORT uint32_t SB_APIENTRY TElCardDavFilter_LoadFromXML(TElCardDavFilterHandle _Handle, TElXMLDOMElementHandle Element, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavFilter_SaveToXML(TElCardDavFilterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavFilter_AddPropFilter(TElCardDavFilterHandle _Handle, TElCardDavPropFilterHandle PropFilter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavFilter_RemovePropFilter(TElCardDavFilterHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavFilter_get_Test(TElCardDavFilterHandle _Handle, TSBWebDAVFilterTestRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavFilter_set_Test(TElCardDavFilterHandle _Handle, TSBWebDAVFilterTestRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavFilter_get_PropFilterCount(TElCardDavFilterHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavFilter_get_PropFilters(TElCardDavFilterHandle _Handle, int32_t Index, TElCardDavPropFilterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavFilter_Create(TElCardDavFilterHandle * OutResult);
#endif /* SB_USE_CLASS_TELCARDDAVFILTER */

#ifdef SB_USE_CLASS_TELCARDDAVPARAMFILTER
SB_IMPORT uint32_t SB_APIENTRY TElCardDavParamFilter_LoadFromXML(TElCardDavParamFilterHandle _Handle, TElXMLDOMElementHandle Element, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavParamFilter_SaveToXML(TElCardDavParamFilterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavParamFilter_get_TextMatch(TElCardDavParamFilterHandle _Handle, TElCardDavTextMatchFilterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavParamFilter_set_TextMatch(TElCardDavParamFilterHandle _Handle, TElCardDavTextMatchFilterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavParamFilter_get_OwnTextMatch(TElCardDavParamFilterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavParamFilter_set_OwnTextMatch(TElCardDavParamFilterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavParamFilter_get_IsNotDefined(TElCardDavParamFilterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavParamFilter_set_IsNotDefined(TElCardDavParamFilterHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCardDavParamFilter_Create(TElWebDAVFilterHandle Parent, TElCardDavParamFilterHandle * OutResult);
#endif /* SB_USE_CLASS_TELCARDDAVPARAMFILTER */

#ifdef SB_USE_CLASS_TELWEBDAVACE
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_LoadFromXML(TElWebDAVACEHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_SaveToXML(TElWebDAVACEHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_get_PrincipalType(TElWebDAVACEHandle _Handle, TSBPrincipalTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_set_PrincipalType(TElWebDAVACEHandle _Handle, TSBPrincipalTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_get_Value(TElWebDAVACEHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_set_Value(TElWebDAVACEHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_get__Property(TElWebDAVACEHandle _Handle, TElWebDAVPropertyInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_set__Property(TElWebDAVACEHandle _Handle, TElWebDAVPropertyInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_get_Invert(TElWebDAVACEHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_set_Invert(TElWebDAVACEHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_get__Protected(TElWebDAVACEHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_set__Protected(TElWebDAVACEHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_get__Inherited(TElWebDAVACEHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_set__Inherited(TElWebDAVACEHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_get_InheritedHref(TElWebDAVACEHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_set_InheritedHref(TElWebDAVACEHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_get_Grant(TElWebDAVACEHandle _Handle, int16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_set_Grant(TElWebDAVACEHandle _Handle, int16_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_get_Deny(TElWebDAVACEHandle _Handle, int16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_set_Deny(TElWebDAVACEHandle _Handle, int16_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACE_Create(TElWebDAVACEHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVACE */

#ifdef SB_USE_CLASS_TELWEBDAVACL
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACL_Add(TElWebDAVACLHandle _Handle, TElWebDAVACEHandle Ace, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACL_Remove(TElWebDAVACLHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACL_LoadFromXML(TElWebDAVACLHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACL_SaveToXML(TElWebDAVACLHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACL_get_Count(TElWebDAVACLHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACL_get_ACEs(TElWebDAVACLHandle _Handle, int32_t Index, TElWebDAVACEHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACL_Create(TElWebDAVACLHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVACL */

#ifdef SB_USE_CLASS_TELWEBDAVACLRESTRICTIONS
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLRestrictions_LoadFromXML(TElWebDAVACLRestrictionsHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLRestrictions_SaveToXML(TElWebDAVACLRestrictionsHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLRestrictions_get_GrantOnly(TElWebDAVACLRestrictionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLRestrictions_set_GrantOnly(TElWebDAVACLRestrictionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLRestrictions_get_NoInvert(TElWebDAVACLRestrictionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLRestrictions_set_NoInvert(TElWebDAVACLRestrictionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLRestrictions_get_DenyBeforeGrant(TElWebDAVACLRestrictionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLRestrictions_set_DenyBeforeGrant(TElWebDAVACLRestrictionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLRestrictions_get_RequiredPrincipal(TElWebDAVACLRestrictionsHandle _Handle, TSBPrincipalTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLRestrictions_set_RequiredPrincipal(TElWebDAVACLRestrictionsHandle _Handle, TSBPrincipalTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLRestrictions_get_Hrefs(TElWebDAVACLRestrictionsHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLRestrictions_get_Properties(TElWebDAVACLRestrictionsHandle _Handle, TElWebDAVPropertyInfoListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLRestrictions_Create(TElWebDAVACLRestrictionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVACLRESTRICTIONS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElWebDAVPropertyInfo_ce_ptr;
extern zend_class_entry *TElWebDAVPropertyInfoList_ce_ptr;
extern zend_class_entry *TElWebDAVNamespacePrefixMap_ce_ptr;
extern zend_class_entry *TElWebDAVLock_ce_ptr;
extern zend_class_entry *TElWebDAVFilter_ce_ptr;
extern zend_class_entry *TElWebDAVTextMatchFilter_ce_ptr;
extern zend_class_entry *TElCardDavTextMatchFilter_ce_ptr;
extern zend_class_entry *TElCardDavPropFilter_ce_ptr;
extern zend_class_entry *TElCardDavFilter_ce_ptr;
extern zend_class_entry *TElCardDavParamFilter_ce_ptr;
extern zend_class_entry *TElWebDAVACE_ce_ptr;
extern zend_class_entry *TElWebDAVACL_ce_ptr;
extern zend_class_entry *TElWebDAVACLRestrictions_ce_ptr;

void Register_TElWebDAVPropertyInfo(TSRMLS_D);
void Register_TElWebDAVPropertyInfoList(TSRMLS_D);
void Register_TElWebDAVNamespacePrefixMap(TSRMLS_D);
void Register_TElWebDAVLock(TSRMLS_D);
void Register_TElWebDAVFilter(TSRMLS_D);
void Register_TElWebDAVTextMatchFilter(TSRMLS_D);
void Register_TElCardDavTextMatchFilter(TSRMLS_D);
void Register_TElCardDavPropFilter(TSRMLS_D);
void Register_TElCardDavFilter(TSRMLS_D);
void Register_TElCardDavParamFilter(TSRMLS_D);
void Register_TElWebDAVACE(TSRMLS_D);
void Register_TElWebDAVACL(TSRMLS_D);
void Register_TElWebDAVACLRestrictions(TSRMLS_D);
SB_PHP_FUNCTION(SBWebDAVCommon, CalDAVTimeToDateTime);
SB_PHP_FUNCTION(SBWebDAVCommon, DateTimeToCalDAV);
SB_PHP_FUNCTION(SBWebDAVCommon, ISOTimeToDateTime);
SB_PHP_FUNCTION(SBWebDAVCommon, DateTimeToISOTime);
SB_PHP_FUNCTION(SBWebDAVCommon, DepthToStr);
SB_PHP_FUNCTION(SBWebDAVCommon, StrToDepth);
SB_PHP_FUNCTION(SBWebDAVCommon, ScopeToStr);
SB_PHP_FUNCTION(SBWebDAVCommon, StrToScope);
SB_PHP_FUNCTION(SBWebDAVCommon, Substring);
SB_PHP_FUNCTION(SBWebDAVCommon, URLComparePaths);
SB_PHP_FUNCTION(SBWebDAVCommon, URLChild);
SB_PHP_FUNCTION(SBWebDAVCommon, URLExtractParent);
SB_PHP_FUNCTION(SBWebDAVCommon, URLExtractExtension);
SB_PHP_FUNCTION(SBWebDAVCommon, URLExtractResourceName);
SB_PHP_FUNCTION(SBWebDAVCommon, CollectionURL);
SB_PHP_FUNCTION(SBWebDAVCommon, URLExtractPath);
SB_PHP_FUNCTION(SBWebDAVCommon, URLCalculateDestPath);
SB_PHP_FUNCTION(SBWebDAVCommon, URLAddPrefixSlash);
SB_PHP_FUNCTION(SBWebDAVCommon, URLAddPostfixSlash);
SB_PHP_FUNCTION(SBWebDAVCommon, URLRemoveSlash);
SB_PHP_FUNCTION(SBWebDAVCommon, URLFixSlashes);
SB_PHP_FUNCTION(SBWebDAVCommon, URLEncodeEx);
SB_PHP_FUNCTION(SBWebDAVCommon, URLConcat);
SB_PHP_FUNCTION(SBWebDAVCommon, CheckStatusCode);
SB_PHP_FUNCTION(SBWebDAVCommon, SingleChildElement);
SB_PHP_FUNCTION(SBWebDAVCommon, MaxDateTime);
SB_PHP_FUNCTION(SBWebDAVCommon, GenerateRandomStr);
SB_PHP_FUNCTION(SBWebDAVCommon, StrToPrivilege);
SB_PHP_FUNCTION(SBWebDAVCommon, PrivilegeToStr);
SB_PHP_FUNCTION(SBWebDAVCommon, PrivilegesArray);
void Register_SBWebDAVCommon_Constants(int module_number TSRMLS_DC);
void Register_SBWebDAVCommon_Enum_Flags(TSRMLS_D);
void Register_SBWebDAVCommon_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_WEBDAVCOMMON
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_CalDAVTimeToDateTime(const char * pcValue, int32_t szValue, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_DateTimeToCalDAV(int64_t DT, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_ISOTimeToDateTime(const char * pcs, int32_t szs, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_DateTimeToISOTime(int64_t DT, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_DepthToStr(TSBWebDAVDepthRaw Depth, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_StrToDepth(const char * pcDepth, int32_t szDepth, TSBWebDAVDepthRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_ScopeToStr(TSBWebDAVLockScopeRaw Scope, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_StrToScope(const char * pcScope, int32_t szScope, TSBWebDAVLockScopeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_Substring(const char * pcS, int32_t szS, int32_t StartIndex, int32_t EndIndex, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_URLComparePaths(const char * pcURL1, int32_t szURL1, const char * pcURL2, int32_t szURL2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_URLChild(const char * pcURL, int32_t szURL, const char * pcSubURL, int32_t szSubURL, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_URLExtractParent(const char * pcs, int32_t szs, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_URLExtractExtension(const char * pcs, int32_t szs, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_URLExtractResourceName(const char * pcs, int32_t szs, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_CollectionURL(const char * pcURL, int32_t szURL, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_URLExtractPath(const char * pcURL, int32_t szURL, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_URLCalculateDestPath(const char * pcSrcURL, int32_t szSrcURL, const char * pcDestURL, int32_t szDestURL, const char * pcURL, int32_t szURL, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_URLAddPrefixSlash(const char * pcURL, int32_t szURL, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_URLAddPostfixSlash(const char * pcURL, int32_t szURL, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_URLRemoveSlash(const char * pcURL, int32_t szURL, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_URLFixSlashes(const char * pcURL, int32_t szURL, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_URLEncodeEx(const char * pcData, int32_t szData, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_URLConcat(const char * pcURL, int32_t szURL, const char * pcPath, int32_t szPath, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_CheckStatusCode(const char * pcS, int32_t szS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_SingleChildElement(TElXMLDOMNodeHandle Elem, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_MaxDateTime(int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_GenerateRandomStr(int32_t Len, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_StrToPrivilege(const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, int16_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_PrivilegeToStr(int16_t Privilege, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVCommon_PrivilegesArray(int16_t Privileges, int8_t IncludeAll, int8_t IncludeRead, int8_t IncludeWrite, int16_t pOutResult[], int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_WEBDAVCOMMON */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBWEBDAVCOMMON */

