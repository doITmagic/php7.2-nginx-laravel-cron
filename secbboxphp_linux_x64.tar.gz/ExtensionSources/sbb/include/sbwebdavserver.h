#ifndef __INC_SBWEBDAVSERVER
#define __INC_SBWEBDAVSERVER

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstringlist.h"
#include "sbx509.h"
#include "sbcustomcertstorage.h"
#include "sbsslcommon.h"
#include "sbsslserver.h"
#include "sbsessionpool.h"
#include "sbxmldefs.h"
#include "sbxmlutils.h"
#include "sbxmlcore.h"
#include "sbxmlcharsets.h"
#include "sbhttpscommon.h"
#include "sbencoding.h"
#include "sbhttpsconstants.h"
#include "sbhttpsserver.h"
#include "sbsharedresource.h"
#include "sbrandom.h"
#include "sbwebdavcommon.h"
#include "sbcustomfsadapter.h"
#include "sbdiskfsadapter.h"
#include "sbhashfunction.h"
#include "sbsrp.h"
#include "sbsslconstants.h"
#include "sbdictionary.h"
#include "sbvcard.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SServerName 	"WebDAV Server"
#define SB_SAllowHeader 	"Allow: OPTIONS,PUT,POST,GET,HEAD,DELETE,PROPFIND,PROPPATCH,COPY,MOVE,LOCK,UNLOCK"
#define SB_SMsHeader 	"MS-Author-Via: DAV"
#define SB_SXMLContentType 	"application/xml"
#define SB_SDAV12Header 	"DAV: 1,2,3"
#define SB_SDAV1Header 	"DAV: 1,3"
#define SB_SACLHeader 	",access-control"
#define SB_SCardDAVHeader 	",addressbook"
#define SB_SCalDAVHeader 	",calendar-access"
#define SB_SExtendedMkColHeader 	"DAV: extended-mkcol"
#define SB_SAllowACLHeader 	",REPORT,ACL"
#define SB_SAllowCalDAVHeader 	",MKCALENDAR"
#define SB_SDirContentType 	"httpd/unix-directory"
#define SB_SLockTokenPrefix 	"opaquelocktoken"
#define SB_SSerializeName 	"WebDAVBlackbox"
#define SB_SSerializeNS 	"http://www.secureblackbox.com/"
#define SB_SLangEn 	"en"
#define SB_SWriteProperties 	"Write properties"
#define SB_SWriteResourceContent 	"Write resource content"
#define SB_SWriteACL 	"Write ACL"
#define SB_SBind 	"Bind"
#define SB_SUnbind 	"Unbind"
#define SB_SReadACL 	"Read ACL"
#define SB_SReadCurrentUserPrivilegeSetProperty 	"Read current user privilege set property"
#define SB_SUnlockResource 	"Unlock resource"
#define SB_SReadAnyObject 	"Read any object"
#define SB_SWriteAnyObject 	"Write any object"
#define SB_SAnyOperation 	"Any operation"
#define SB_wdpCalReadFreeBusy 	256

typedef TElClassHandle TElWebDAVServerHandle;

typedef TElWebDAVServerHandle ElWebDAVServerHandle;

typedef TElClassHandle TElWebDAVExpandHandle;

typedef TElClassHandle SBWebDAVServer_TElWebDAVPrincipalHandle;

typedef TElClassHandle TElWebDAVInMemoryPrincipalHandle;

typedef TElClassHandle TElWebDAVPrincipalBackendHandle;

typedef TElClassHandle TElWebDAVPrincipalMemoryBackendHandle;

typedef TElClassHandle TElCalDavTextMatchFilterHandle;

typedef TElClassHandle TElCalDavParamFilterHandle;

typedef TElClassHandle TElWebDAVTimeRangeBaseHandle;

typedef TElClassHandle TElWebDAVTimeRangeHandle;

typedef TElClassHandle TElCalDavPropFilterHandle;

typedef TElClassHandle TElCalDAVCompFilterHandle;

typedef TElClassHandle TElWebDAVExtendedRequestHandle;

typedef TElClassHandle TElWebDAVAddressBookRequestHandle;

typedef TElClassHandle TElWebDAVLimitRecurrenceSetHandle;

typedef TElClassHandle TElWebDAVLimitFreeBusySetHandle;

typedef TElClassHandle TElWebDAVCompHandle;

typedef TElClassHandle TElWebDAVCalendarRequestHandle;

typedef TElClassHandle TElWebDAVFreeBusyRequestHandle;

typedef TElClassHandle TElWebDAVPropertyHandle;

typedef TElWebDAVPropertyHandle ElWebDAVPropertyHandle;

typedef TElClassHandle TElWebDAVIfStateHandle;

typedef TElWebDAVIfStateHandle ElWebDAVIfStateHandle;

typedef TElClassHandle TElWebDAVIfResourceHandle;

typedef TElWebDAVIfResourceHandle ElWebDAVIfResourceHandle;

typedef TElClassHandle TElWebDAVIfHeaderHandle;

typedef TElWebDAVIfHeaderHandle ElWebDAVIfHeaderHandle;

typedef TObjectHandle TElWebDAVLockFindHandleHandle;

typedef TObjectHandle ElWebDAVLockFindHandleHandle;

typedef TElClassHandle TElWebDAVCustomLockListHandle;

typedef TElWebDAVCustomLockListHandle ElWebDAVCustomLockListHandle;

typedef TElClassHandle TElWebDAVFindMemoryLockHandleHandle;

typedef TElClassHandle TElWebDAVMemoryLockListHandle;

typedef TElWebDAVMemoryLockListHandle ElWebDAVMemoryLockListHandle;

typedef TElClassHandle TElWebDAVACLOptionsHandle;

typedef TElClassHandle TElCardDAVOptionsHandle;

typedef TElClassHandle TElCalDAVOptionsHandle;

typedef TElClassHandle TElWebDAVCollationHandle;

typedef TElClassHandle TElWebDAVUnicodeCollationHandle;

typedef TElClassHandle TElWebDAVAsciiCollationHandle;

typedef TElClassHandle TElWebDAVOctetCollationHandle;

typedef uint8_t TSBWebDAVPropfindModeRaw;

typedef enum
{
	pfmProp = 0,
	pfmPropname = 1,
	pfmAllprop = 2
} TSBWebDAVPropfindMode;

typedef uint8_t TSBWebDAVIfListTypeRaw;

typedef enum
{
	ltNoTagged = 0,
	ltTagged = 1,
	ltUnknown = 2
} TSBWebDAVIfListType;

typedef uint8_t TSBWebDAVIfStateTypeRaw;

typedef enum
{
	stLockToken = 0,
	stEtag = 1
} TSBWebDAVIfStateType;

typedef uint8_t TSBWebDAVFileOpenModeRaw;

typedef enum
{
	wdfmOpenRead = 0,
	wdfmOpenWrite = 1
} TSBWebDAVFileOpenMode;

typedef void (SB_CALLBACK *TSBWebDAVBeforeRequestEvent)(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle Params, int8_t * Accept, int32_t * StatusCode, char * pcReasonPhrase, int32_t * szReasonPhrase);

typedef void (SB_CALLBACK *TSBWebDAVRequestEvent)(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle Params, TMemoryStreamHandle Data);

typedef void (SB_CALLBACK *TSBWebDAVResponseEvent)(void * _ObjectData, TObjectHandle Sender, TElHTTPServerResponseParamsHandle Params, TMemoryStreamHandle Data);

typedef void (SB_CALLBACK *TSBWebDAVStatusCodeEvent)(void * _ObjectData, TObjectHandle Sender, int32_t * StatusCode, TElHTTPServerRequestParamsHandle ReqParams, TElHTTPServerResponseParamsHandle RespParams);

typedef void (SB_CALLBACK *TSBWebDAVBeforeDownloadEvent)(void * _ObjectData, TObjectHandle Sender, char * pcURL, int32_t * szURL, int8_t * Allow);

typedef void (SB_CALLBACK *TSBWebDAVBeforeUploadEvent)(void * _ObjectData, TObjectHandle Sender, char * pcURL, int32_t * szURL, int8_t * Allow);

typedef void (SB_CALLBACK *TSBWebDAVTransferFinishedEvent)(void * _ObjectData, TObjectHandle Sender);

typedef void (SB_CALLBACK *TSBWebDAVQueryQuotaEvent)(void * _ObjectData, TObjectHandle Sender, int64_t * Available, int64_t * Used);

typedef void (SB_CALLBACK *TSBWebDAVPropertyReadValueEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, char * pcValue, int32_t * szValue, TElXMLDOMElementHandle Element, int8_t * Success);

typedef void (SB_CALLBACK *TSBWebDAVPropertyReadExValueEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, char * pcValue, int32_t * szValue, TElXMLDOMElementHandle Element, TObjectHandle Param, int8_t * Success);

typedef void (SB_CALLBACK *TSBWebDAVPropertyAfterReadValueEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, char * pcValue, int32_t * szValue, TElXMLDOMElementHandle Element);

typedef void (SB_CALLBACK *TSBWebDAVPropertyBeforeWriteValueEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, char * pcValue, int32_t * szValue, int8_t * Success);

typedef void (SB_CALLBACK *TSBWebDAVPropertyWriteValueEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, const char * pcValue, int32_t szValue, int8_t * Success);

typedef void (SB_CALLBACK *TSBWebDAVPropertyRemoveEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, int8_t * Success);

typedef void (SB_CALLBACK *TSBWebDAVCheckIfAddressBookEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, int8_t * Success);

typedef void (SB_CALLBACK *TSBWebDAVSetAsAddressBookEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, int8_t * Success);

typedef void (SB_CALLBACK *TSBWebDAVCheckIfCalendarEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, int8_t * Success);

typedef void (SB_CALLBACK *TSBWebDAVSetAsCalendarEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, int8_t * Success);

typedef void (SB_CALLBACK *TSBWebDAVExpandCalendarEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, TElVCalendarHandle Calendar, TElWebDAVExpandHandle ExpandPeriod, int32_t Index, int32_t MaxRecurrenceInstances, TElVCalendarHandle * OutResult);

typedef void (SB_CALLBACK *TSBWebDAVCalculateFreeBusyEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, int64_t StartRange, int64_t EndRange, TElVCalendarHandle * OutResult);

typedef void (SB_CALLBACK *TSBWebDAVReadPrivilegesEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, int32_t * Privileges);

typedef void (SB_CALLBACK *TSBWebDAVReadOwnerEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle * Principal);

typedef void (SB_CALLBACK *TSBWebDAVReadSupportedPrivilegesEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, int32_t * Privileges);

typedef void (SB_CALLBACK *TSBWebDAVGetPrivilegeDescriptionEvent)(void * _ObjectData, TObjectHandle Sender, int16_t Privilege, char * pcDescription, int32_t * szDescription, char * pcLanguage, int32_t * szLanguage);

typedef void (SB_CALLBACK *TSBWebDAVGetACLRestrictionsEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, TElWebDAVACLRestrictionsHandle Restrictions);

typedef void (SB_CALLBACK *TSBWebDAVGetACLEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, TListHandle List, int8_t * OwnList);

typedef void (SB_CALLBACK *TSBWebDAVSetACLEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, TListHandle List, TSBWebDAVACLErrorRaw * Error, int32_t * StatusCode);

typedef void (SB_CALLBACK *TSBWebDAVGetURLSetEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, TElStringListHandle List);

typedef void (SB_CALLBACK *TSBCheckUIDUniquenessEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, TElDirInfoPropertiesListHandle PropList, int8_t * Unique);

#ifdef SB_USE_CLASS_TELWEBDAVSERVER
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_Open(TElWebDAVServerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_DataAvailable(TElWebDAVServerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_Close(TElWebDAVServerHandle _Handle, int8_t Silent);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_AddProperty(TElWebDAVServerHandle _Handle, const TElWebDAVPropertyHandle Prop, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_GetProperty(TElWebDAVServerHandle _Handle, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, TElWebDAVPropertyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_RemoveProperty(TElWebDAVServerHandle _Handle, const TElWebDAVPropertyHandle Prop, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_CreateCollection(TElWebDAVServerHandle _Handle, const char * pcURL, int32_t szURL);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_CreateAddressBook(TElWebDAVServerHandle _Handle, const char * pcURL, int32_t szURL, const char * pcDescription, int32_t szDescription, SBWebDAVServer_TElWebDAVPrincipalHandle Owner);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_CreateCalendar(TElWebDAVServerHandle _Handle, const char * pcURL, int32_t szURL, const char * pcDescription, int32_t szDescription, SBWebDAVServer_TElWebDAVPrincipalHandle Owner);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_PutVCard(TElWebDAVServerHandle _Handle, const char * pcURL, int32_t szURL, TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_PutVCard_1(TElWebDAVServerHandle _Handle, const char * pcURL, int32_t szURL, TElVCardHandle VCard);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_PutVCard_2(TElWebDAVServerHandle _Handle, const char * pcURL, int32_t szURL, const char * pcFileName, int32_t szFileName);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_AddCertTypeHandler(TElWebDAVServerHandle _Handle, TElSSLCertificateTypeHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_RemoveCertTypeHandler(TElWebDAVServerHandle _Handle, TElSSLCertificateTypeHandlerHandle Handler);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_GetCertTypeHandler(TElWebDAVServerHandle _Handle, TElSSLCertificateTypeRaw CertType, TElSSLCertificateTypeHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_MIMETypesMap(TElWebDAVServerHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_Properties(TElWebDAVServerHandle _Handle, int32_t Idx, TElWebDAVPropertyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_PropertiesCount(TElWebDAVServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_Control(TElWebDAVServerHandle _Handle, TElHTTPSServerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_ACLOptions(TElWebDAVServerHandle _Handle, TElWebDAVACLOptionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_CardDAVOptions(TElWebDAVServerHandle _Handle, TElCardDAVOptionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_CalDAVOptions(TElWebDAVServerHandle _Handle, TElCalDAVOptionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_Active(TElWebDAVServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_SSLMode(TElWebDAVServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_SSLMode(TElWebDAVServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_SSLClientAuthentication(TElWebDAVServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_SSLClientAuthentication(TElWebDAVServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_SSLAuthenticationLevel(TElWebDAVServerHandle _Handle, TSBAuthenticationLevelRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_SSLAuthenticationLevel(TElWebDAVServerHandle _Handle, TSBAuthenticationLevelRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_SSLForceCertificateChain(TElWebDAVServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_SSLForceCertificateChain(TElWebDAVServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_CertStorage(TElWebDAVServerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_CertStorage(TElWebDAVServerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_SSLSessionPool(TElWebDAVServerHandle _Handle, TElSessionPoolHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_SSLSessionPool(TElWebDAVServerHandle _Handle, TElSessionPoolHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_ClientCertStorage(TElWebDAVServerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_ClientCertStorage(TElWebDAVServerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_SSLVersions(TElWebDAVServerHandle _Handle, TSBVersionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_SSLVersions(TElWebDAVServerHandle _Handle, TSBVersionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_SSLExtensions(TElWebDAVServerHandle _Handle, TElServerSSLExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_SSLPeerExtensions(TElWebDAVServerHandle _Handle, TElCustomSSLExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_SSLSRPCredentialStore(TElWebDAVServerHandle _Handle, TElSRPCredentialStoreHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_SSLSRPCredentialStore(TElWebDAVServerHandle _Handle, TElSRPCredentialStoreHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_FileSystemAdapter(TElWebDAVServerHandle _Handle, TElCustomFileSystemAdapterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_FileSystemAdapter(TElWebDAVServerHandle _Handle, TElCustomFileSystemAdapterHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_GlobalLockList(TElWebDAVServerHandle _Handle, TElWebDAVCustomLockListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_GlobalLockList(TElWebDAVServerHandle _Handle, TElWebDAVCustomLockListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_SendBufferSize(TElWebDAVServerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_SendBufferSize(TElWebDAVServerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_DefaultLockTimeout(TElWebDAVServerHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_DefaultLockTimeout(TElWebDAVServerHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_AllowInfinity(TElWebDAVServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_AllowInfinity(TElWebDAVServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_PublishExclusiveLocks(TElWebDAVServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_PublishExclusiveLocks(TElWebDAVServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_PublishSharedLocks(TElWebDAVServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_PublishSharedLocks(TElWebDAVServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_ResponseContentType(TElWebDAVServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_ResponseContentType(TElWebDAVServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_MicrosoftCompatible(TElWebDAVServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_MicrosoftCompatible(TElWebDAVServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_ServerName(TElWebDAVServerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_ServerName(TElWebDAVServerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_UseWellKnownURIs(TElWebDAVServerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_UseWellKnownURIs(TElWebDAVServerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnGetSrpDb(TElWebDAVServerHandle _Handle, TSBServerSrpDbNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnGetSrpDb(TElWebDAVServerHandle _Handle, TSBServerSrpDbNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnBeforeRequest(TElWebDAVServerHandle _Handle, TSBWebDAVBeforeRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnBeforeRequest(TElWebDAVServerHandle _Handle, TSBWebDAVBeforeRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnRequest(TElWebDAVServerHandle _Handle, TSBWebDAVRequestEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnRequest(TElWebDAVServerHandle _Handle, TSBWebDAVRequestEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnResponse(TElWebDAVServerHandle _Handle, TSBWebDAVResponseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnResponse(TElWebDAVServerHandle _Handle, TSBWebDAVResponseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnStatusCode(TElWebDAVServerHandle _Handle, TSBWebDAVStatusCodeEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnStatusCode(TElWebDAVServerHandle _Handle, TSBWebDAVStatusCodeEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnBeforeUpload(TElWebDAVServerHandle _Handle, TSBWebDAVBeforeUploadEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnBeforeUpload(TElWebDAVServerHandle _Handle, TSBWebDAVBeforeUploadEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnBeforeDownload(TElWebDAVServerHandle _Handle, TSBWebDAVBeforeDownloadEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnBeforeDownload(TElWebDAVServerHandle _Handle, TSBWebDAVBeforeDownloadEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnTransferFinished(TElWebDAVServerHandle _Handle, TSBWebDAVTransferFinishedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnTransferFinished(TElWebDAVServerHandle _Handle, TSBWebDAVTransferFinishedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnGetUserPassword(TElWebDAVServerHandle _Handle, TSBOnGetUserPasswordEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnGetUserPassword(TElWebDAVServerHandle _Handle, TSBOnGetUserPasswordEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnQueryQuota(TElWebDAVServerHandle _Handle, TSBWebDAVQueryQuotaEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnQueryQuota(TElWebDAVServerHandle _Handle, TSBWebDAVQueryQuotaEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnSend(TElWebDAVServerHandle _Handle, TSBSendEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnSend(TElWebDAVServerHandle _Handle, TSBSendEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnReceive(TElWebDAVServerHandle _Handle, TSBReceiveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnReceive(TElWebDAVServerHandle _Handle, TSBReceiveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnOpenConnection(TElWebDAVServerHandle _Handle, TSBOpenConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnOpenConnection(TElWebDAVServerHandle _Handle, TSBOpenConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnCertificateValidate(TElWebDAVServerHandle _Handle, TSBCertificateValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnCertificateValidate(TElWebDAVServerHandle _Handle, TSBCertificateValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnCiphersNegotiated(TElWebDAVServerHandle _Handle, TNotifyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnCiphersNegotiated(TElWebDAVServerHandle _Handle, TNotifyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnSSLError(TElWebDAVServerHandle _Handle, TSBErrorEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnSSLError(TElWebDAVServerHandle _Handle, TSBErrorEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnExtensionsReceived(TElWebDAVServerHandle _Handle, TSBExtensionsReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnExtensionsReceived(TElWebDAVServerHandle _Handle, TSBExtensionsReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnExtensionsPrepared(TElWebDAVServerHandle _Handle, TSBExtensionsPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnExtensionsPrepared(TElWebDAVServerHandle _Handle, TSBExtensionsPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnKeyNeeded(TElWebDAVServerHandle _Handle, TSBServerKeyNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnKeyNeeded(TElWebDAVServerHandle _Handle, TSBServerKeyNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnCloseConnection(TElWebDAVServerHandle _Handle, TSBCloseConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnCloseConnection(TElWebDAVServerHandle _Handle, TSBCloseConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnRenegotiationStart(TElWebDAVServerHandle _Handle, TSBRenegotiationStartEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnRenegotiationStart(TElWebDAVServerHandle _Handle, TSBRenegotiationStartEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_get_OnCertificateURLs(TElWebDAVServerHandle _Handle, TSBCertificateURLsEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_set_OnCertificateURLs(TElWebDAVServerHandle _Handle, TSBCertificateURLsEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVServer_Create(TComponentHandle AOwner, TElWebDAVServerHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVSERVER */

#ifdef SB_USE_CLASS_TELWEBDAVTIMERANGEBASE
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTimeRangeBase_LoadFromXML(TElWebDAVTimeRangeBaseHandle _Handle, TElXMLDOMElementHandle Element, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTimeRangeBase_get_Start(TElWebDAVTimeRangeBaseHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTimeRangeBase_get_End_(TElWebDAVTimeRangeBaseHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTimeRangeBase_Create(TElWebDAVTimeRangeBaseHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVTIMERANGEBASE */

#ifdef SB_USE_CLASS_SBWEBDAVSERVER_TELWEBDAVPRINCIPAL
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_MemberOf(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, const char * pcURL, int32_t szURL, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_AddToGroup(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_get_Username(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_set_Username(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_get_DisplayName(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_set_DisplayName(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_get_URL(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_set_URL(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_get_AlternateURISet(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_get_Groups(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_get_IsGroup(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_set_IsGroup(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_get_Address(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_set_Address(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_get_ETag(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_set_ETag(SBWebDAVServer_TElWebDAVPrincipalHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_TElWebDAVPrincipal_Create(SBWebDAVServer_TElWebDAVPrincipalHandle * OutResult);
#endif /* SB_USE_CLASS_SBWEBDAVSERVER_TELWEBDAVPRINCIPAL */

#ifdef SB_USE_CLASS_TELWEBDAVINMEMORYPRINCIPAL
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVInMemoryPrincipal_get_AddressBookHomeSet(TElWebDAVInMemoryPrincipalHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVInMemoryPrincipal_get_CalendarHomeSet(TElWebDAVInMemoryPrincipalHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVInMemoryPrincipal_Create(TElWebDAVInMemoryPrincipalHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVINMEMORYPRINCIPAL */

#ifdef SB_USE_CLASS_TELWEBDAVPRINCIPALBACKEND
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_BeginRead(TElWebDAVPrincipalBackendHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_BeginWrite(TElWebDAVPrincipalBackendHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_Done(TElWebDAVPrincipalBackendHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_AddPrincipal(TElWebDAVPrincipalBackendHandle _Handle, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_RemovePrincipal(TElWebDAVPrincipalBackendHandle _Handle, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_RemovePrincipal_1(TElWebDAVPrincipalBackendHandle _Handle, const char * pcURL, int32_t szURL, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_PrincipalExists(TElWebDAVPrincipalBackendHandle _Handle, const char * pcURL, int32_t szURL, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_FindPrincipalByURL(TElWebDAVPrincipalBackendHandle _Handle, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_FindPrincipalByName(TElWebDAVPrincipalBackendHandle _Handle, const char * pcName, int32_t szName, SBWebDAVServer_TElWebDAVPrincipalHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_GetGroupMemberSet(TElWebDAVPrincipalBackendHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle List, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_GetGroupMembership(TElWebDAVPrincipalBackendHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle List, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_GetPrincipalCollectionSet(TElWebDAVPrincipalBackendHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle List, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_GetPrincipalAddressBookHomeSet(TElWebDAVPrincipalBackendHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle List, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_GetPrincipalCalendarHomeSet(TElWebDAVPrincipalBackendHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle List, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_EnumPrincipals(TElWebDAVPrincipalBackendHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle List, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_CollectionExists(TElWebDAVPrincipalBackendHandle _Handle, const char * pcURL, int32_t szURL, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalBackend_Create(TElWebDAVPrincipalBackendHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVPRINCIPALBACKEND */

#ifdef SB_USE_CLASS_TELWEBDAVPRINCIPALMEMORYBACKEND
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_BeginRead(TElWebDAVPrincipalMemoryBackendHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_BeginWrite(TElWebDAVPrincipalMemoryBackendHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_Done(TElWebDAVPrincipalMemoryBackendHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_AddPrincipal(TElWebDAVPrincipalMemoryBackendHandle _Handle, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_RemovePrincipal(TElWebDAVPrincipalMemoryBackendHandle _Handle, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_RemovePrincipal_1(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcURL, int32_t szURL, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_PrincipalExists(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcURL, int32_t szURL, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_FindPrincipalByURL(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_FindPrincipalByName(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcName, int32_t szName, SBWebDAVServer_TElWebDAVPrincipalHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_GetGroupMemberSet(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle List, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_GetGroupMembership(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle List, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_GetPrincipalCollectionSet(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle List, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_GetPrincipalAddressBookHomeSet(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle List, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_GetPrincipalCalendarHomeSet(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle List, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_EnumPrincipals(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcURL, int32_t szURL, TElStringListHandle List, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_get_CardDAVPrefix(TElWebDAVPrincipalMemoryBackendHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_set_CardDAVPrefix(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_get_CalDAVPrefix(TElWebDAVPrincipalMemoryBackendHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_set_CalDAVPrefix(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_get_PrincipalBaseURL(TElWebDAVPrincipalMemoryBackendHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_set_PrincipalBaseURL(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_get_GroupBaseURL(TElWebDAVPrincipalMemoryBackendHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_set_GroupBaseURL(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_get_ContactFileName(TElWebDAVPrincipalMemoryBackendHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_set_ContactFileName(TElWebDAVPrincipalMemoryBackendHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVPrincipalMemoryBackend_Create(TElWebDAVPrincipalMemoryBackendHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVPRINCIPALMEMORYBACKEND */

#ifdef SB_USE_CLASS_TELCALDAVTEXTMATCHFILTER
SB_IMPORT uint32_t SB_APIENTRY TElCalDavTextMatchFilter_Create(TElWebDAVFilterHandle Parent, TElCalDavTextMatchFilterHandle * OutResult);
#endif /* SB_USE_CLASS_TELCALDAVTEXTMATCHFILTER */

#ifdef SB_USE_CLASS_TELCALDAVPARAMFILTER
SB_IMPORT uint32_t SB_APIENTRY TElCalDavParamFilter_LoadFromXML(TElCalDavParamFilterHandle _Handle, TElXMLDOMElementHandle Element, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDavParamFilter_get_IsNotDefined(TElCalDavParamFilterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDavParamFilter_get_TextMatch(TElCalDavParamFilterHandle _Handle, TElCalDavTextMatchFilterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDavParamFilter_Create(TElWebDAVFilterHandle Parent, TElCalDavParamFilterHandle * OutResult);
#endif /* SB_USE_CLASS_TELCALDAVPARAMFILTER */

#ifdef SB_USE_CLASS_TELWEBDAVEXPAND
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVExpand_Create(TElWebDAVTimeRangeBaseHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVEXPAND */

#ifdef SB_USE_CLASS_TELWEBDAVTIMERANGE
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVTimeRange_Create(TElWebDAVTimeRangeBaseHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVTIMERANGE */

#ifdef SB_USE_CLASS_TELCALDAVPROPFILTER
SB_IMPORT uint32_t SB_APIENTRY TElCalDavPropFilter_LoadFromXML(TElCalDavPropFilterHandle _Handle, TElXMLDOMElementHandle Element, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDavPropFilter_get_SubFilters(TElCalDavPropFilterHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDavPropFilter_get_IsNotDefined(TElCalDavPropFilterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDavPropFilter_get_TimeRange(TElCalDavPropFilterHandle _Handle, TElWebDAVTimeRangeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDavPropFilter_get_TextMatch(TElCalDavPropFilterHandle _Handle, TElCalDavTextMatchFilterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDavPropFilter_Create(TElWebDAVFilterHandle Parent, TElCalDavPropFilterHandle * OutResult);
#endif /* SB_USE_CLASS_TELCALDAVPROPFILTER */

#ifdef SB_USE_CLASS_TELCALDAVCOMPFILTER
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVCompFilter_LoadFromXML(TElCalDAVCompFilterHandle _Handle, TElXMLDOMElementHandle Element, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVCompFilter_get_SubFilters(TElCalDAVCompFilterHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVCompFilter_get_IsNotDefined(TElCalDAVCompFilterHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVCompFilter_get_TimeRange(TElCalDAVCompFilterHandle _Handle, TElWebDAVTimeRangeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVCompFilter_Create(TElWebDAVFilterHandle Parent, TElCalDAVCompFilterHandle * OutResult);
#endif /* SB_USE_CLASS_TELCALDAVCOMPFILTER */

#ifdef SB_USE_CLASS_TELWEBDAVEXTENDEDREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVExtendedRequest_LoadFromXML(TElWebDAVExtendedRequestHandle _Handle, TElXMLDOMElementHandle Element, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVExtendedRequest_get_ReportName(TElWebDAVExtendedRequestHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVExtendedRequest_set_ReportName(TElWebDAVExtendedRequestHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVExtendedRequest_get_Hrefs(TElWebDAVExtendedRequestHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVExtendedRequest_get_AllProp(TElWebDAVExtendedRequestHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVExtendedRequest_set_AllProp(TElWebDAVExtendedRequestHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVExtendedRequest_get_EvaluationResult(TElWebDAVExtendedRequestHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVExtendedRequest_set_EvaluationResult(TElWebDAVExtendedRequestHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVExtendedRequest_Create(TElWebDAVExtendedRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVEXTENDEDREQUEST */

#ifdef SB_USE_CLASS_TELWEBDAVADDRESSBOOKREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVAddressBookRequest_LoadFromXML(TElWebDAVAddressBookRequestHandle _Handle, TElXMLDOMElementHandle Element, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVAddressBookRequest_get_Test(TElWebDAVAddressBookRequestHandle _Handle, TSBWebDAVFilterTestRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVAddressBookRequest_set_Test(TElWebDAVAddressBookRequestHandle _Handle, TSBWebDAVFilterTestRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVAddressBookRequest_get_Filters(TElWebDAVAddressBookRequestHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVAddressBookRequest_get_Limit(TElWebDAVAddressBookRequestHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVAddressBookRequest_set_Limit(TElWebDAVAddressBookRequestHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVAddressBookRequest_get_Names(TElWebDAVAddressBookRequestHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVAddressBookRequest_Create(TElWebDAVAddressBookRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVADDRESSBOOKREQUEST */

#ifdef SB_USE_CLASS_TELWEBDAVLIMITRECURRENCESET
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLimitRecurrenceSet_Create(TElWebDAVTimeRangeBaseHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVLIMITRECURRENCESET */

#ifdef SB_USE_CLASS_TELWEBDAVLIMITFREEBUSYSET
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVLimitFreeBusySet_Create(TElWebDAVTimeRangeBaseHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVLIMITFREEBUSYSET */

#ifdef SB_USE_CLASS_TELWEBDAVCOMP
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVComp_LoadFromXML(TElWebDAVCompHandle _Handle, TElXMLDOMElementHandle Element, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVComp_get_Parent(TElWebDAVCompHandle _Handle, TElWebDAVCompHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVComp_get_Name(TElWebDAVCompHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVComp_set_Name(TElWebDAVCompHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVComp_get_AllProp(TElWebDAVCompHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVComp_set_AllProp(TElWebDAVCompHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVComp_get_AllComp(TElWebDAVCompHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVComp_set_AllComp(TElWebDAVCompHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVComp_get_Props(TElWebDAVCompHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVComp_get_Comps(TElWebDAVCompHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVComp_get_FullPath(TElWebDAVCompHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVComp_Create(TElWebDAVCompHandle Parent, TElWebDAVCompHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVCOMP */

#ifdef SB_USE_CLASS_TELWEBDAVCALENDARREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCalendarRequest_LoadFromXML(TElWebDAVCalendarRequestHandle _Handle, TElXMLDOMElementHandle Element, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCalendarRequest_get_CompFilter(TElWebDAVCalendarRequestHandle _Handle, TElCalDAVCompFilterHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCalendarRequest_get_Timezone(TElWebDAVCalendarRequestHandle _Handle, TElVCalendarHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCalendarRequest_get_Comp(TElWebDAVCalendarRequestHandle _Handle, TElWebDAVCompHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCalendarRequest_get_Expand(TElWebDAVCalendarRequestHandle _Handle, TElWebDAVExpandHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCalendarRequest_get_LimitRecurrenceSet(TElWebDAVCalendarRequestHandle _Handle, TElWebDAVLimitRecurrenceSetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCalendarRequest_get_LimitFreebusySet(TElWebDAVCalendarRequestHandle _Handle, TElWebDAVLimitFreeBusySetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCalendarRequest_Create(TElWebDAVCalendarRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVCALENDARREQUEST */

#ifdef SB_USE_CLASS_TELWEBDAVFREEBUSYREQUEST
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVFreeBusyRequest_LoadFromXML(TElWebDAVFreeBusyRequestHandle _Handle, TElXMLDOMElementHandle Element, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVFreeBusyRequest_get_TimeRange(TElWebDAVFreeBusyRequestHandle _Handle, TElWebDAVTimeRangeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVFreeBusyRequest_Create(TElWebDAVFreeBusyRequestHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVFREEBUSYREQUEST */

#ifdef SB_USE_CLASS_TELWEBDAVPROPERTY
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_Write(TElWebDAVPropertyHandle _Handle, const char * pcURL, int32_t szURL, const char * pcValue, int32_t szValue, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_Read(TElWebDAVPropertyHandle _Handle, const char * pcURL, int32_t szURL, char * pcValue, int32_t * szValue, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_Read_1(TElWebDAVPropertyHandle _Handle, const char * pcURL, int32_t szURL, char * pcValue, int32_t * szValue, TElXMLDOMElementHandle Element, TObjectHandle Param, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_Remove(TElWebDAVPropertyHandle _Handle, const char * pcURL, int32_t szURL, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_NS(TElWebDAVPropertyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_Name(TElWebDAVPropertyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_Live(TElWebDAVPropertyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_Protect(TElWebDAVPropertyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_AsXML(TElWebDAVPropertyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_PrincipalMatch(TElWebDAVPropertyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_Principal(TElWebDAVPropertyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_AddressBook(TElWebDAVPropertyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_Calendar(TElWebDAVPropertyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_Copy(TElWebDAVPropertyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_Search(TElWebDAVPropertyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_set_Search(TElWebDAVPropertyHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_Description(TElWebDAVPropertyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_set_Description(TElWebDAVPropertyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_DescLang(TElWebDAVPropertyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_set_DescLang(TElWebDAVPropertyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_OnReadValue(TElWebDAVPropertyHandle _Handle, TSBWebDAVPropertyReadValueEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_set_OnReadValue(TElWebDAVPropertyHandle _Handle, TSBWebDAVPropertyReadValueEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_OnReadExValue(TElWebDAVPropertyHandle _Handle, TSBWebDAVPropertyReadExValueEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_set_OnReadExValue(TElWebDAVPropertyHandle _Handle, TSBWebDAVPropertyReadExValueEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_OnWriteValue(TElWebDAVPropertyHandle _Handle, TSBWebDAVPropertyWriteValueEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_set_OnWriteValue(TElWebDAVPropertyHandle _Handle, TSBWebDAVPropertyWriteValueEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_OnAfterReadValue(TElWebDAVPropertyHandle _Handle, TSBWebDAVPropertyAfterReadValueEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_set_OnAfterReadValue(TElWebDAVPropertyHandle _Handle, TSBWebDAVPropertyAfterReadValueEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_OnBeforeWriteValue(TElWebDAVPropertyHandle _Handle, TSBWebDAVPropertyBeforeWriteValueEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_set_OnBeforeWriteValue(TElWebDAVPropertyHandle _Handle, TSBWebDAVPropertyBeforeWriteValueEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_get_OnRemove(TElWebDAVPropertyHandle _Handle, TSBWebDAVPropertyRemoveEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_set_OnRemove(TElWebDAVPropertyHandle _Handle, TSBWebDAVPropertyRemoveEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVProperty_Create(TElWebDAVServerHandle Server, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, int8_t Live, int8_t Protect, int8_t AsXML, int8_t PrincipalMatch, int8_t Principal, int8_t AddressBook, int8_t Calendar, int8_t Copy, TElWebDAVPropertyHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVPROPERTY */

#ifdef SB_USE_CLASS_TELWEBDAVIFSTATE
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVIfState_get_AType(TElWebDAVIfStateHandle _Handle, TSBWebDAVIfStateTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVIfState_get_Condition(TElWebDAVIfStateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVIfState_get_Value(TElWebDAVIfStateHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVIfState_Create(TSBWebDAVIfStateTypeRaw AType, int8_t Condition, const char * pcValue, int32_t szValue, TElWebDAVIfStateHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVIFSTATE */

#ifdef SB_USE_CLASS_TELWEBDAVIFRESOURCE
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVIfResource_get_URI(TElWebDAVIfResourceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVIfResource_get_States(TElWebDAVIfResourceHandle _Handle, int32_t Idx, TElWebDAVIfStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVIfResource_get_Count(TElWebDAVIfResourceHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVIfResource_Create(const char * pcURI, int32_t szURI, TElWebDAVIfResourceHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVIFRESOURCE */

#ifdef SB_USE_CLASS_TELWEBDAVIFHEADER
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVIfHeader_Process(TElWebDAVIfHeaderHandle _Handle, const char * pcS, int32_t szS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVIfHeader_get_URL(TElWebDAVIfHeaderHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVIfHeader_get_Resources(TElWebDAVIfHeaderHandle _Handle, int32_t Idx, TElWebDAVIfResourceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVIfHeader_get_Count(TElWebDAVIfHeaderHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVIfHeader_Create(const char * pcURL, int32_t szURL, TElWebDAVIfHeaderHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVIFHEADER */

#ifdef SB_USE_CLASS_TELWEBDAVCUSTOMLOCKLIST
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCustomLockList_Enter(TElWebDAVCustomLockListHandle _Handle, int8_t ReadOnly);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCustomLockList_Done(TElWebDAVCustomLockListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCustomLockList_Add(TElWebDAVCustomLockListHandle _Handle, const TElWebDAVLockHandle Lock);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCustomLockList_Remove(TElWebDAVCustomLockListHandle _Handle, const TElWebDAVLockHandle Lock);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCustomLockList_Find(TElWebDAVCustomLockListHandle _Handle, const char * pcToken, int32_t szToken, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCustomLockList_FindAll(TElWebDAVCustomLockListHandle _Handle, const char * pcURL, int32_t szURL, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCustomLockList_FindFirst(TElWebDAVCustomLockListHandle _Handle, TObjectHandle * Handle, const char * pcURL, int32_t szURL, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCustomLockList_FindNext(TElWebDAVCustomLockListHandle _Handle, TObjectHandle Handle, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCustomLockList_FindClose(TElWebDAVCustomLockListHandle _Handle, TObjectHandle Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCustomLockList_LoadFromStream(TElWebDAVCustomLockListHandle _Handle, TStreamHandle Stream, int8_t Clear);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCustomLockList_SaveToStream(TElWebDAVCustomLockListHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCustomLockList_get_Locks(TElWebDAVCustomLockListHandle _Handle, int32_t Idx, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCustomLockList_get_Count(TElWebDAVCustomLockListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCustomLockList_Create(TComponentHandle AOwner, TElWebDAVCustomLockListHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVCUSTOMLOCKLIST */

#ifdef SB_USE_CLASS_TELWEBDAVFINDMEMORYLOCKHANDLE
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVFindMemoryLockHandle_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVFINDMEMORYLOCKHANDLE */

#ifdef SB_USE_CLASS_TELWEBDAVMEMORYLOCKLIST
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_Enter(TElWebDAVMemoryLockListHandle _Handle, int8_t ReadOnly);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_Done(TElWebDAVMemoryLockListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_Add(TElWebDAVMemoryLockListHandle _Handle, const TElWebDAVLockHandle Lock);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_Remove(TElWebDAVMemoryLockListHandle _Handle, const TElWebDAVLockHandle Lock);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_Find(TElWebDAVMemoryLockListHandle _Handle, const char * pcToken, int32_t szToken, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_FindAll(TElWebDAVMemoryLockListHandle _Handle, const char * pcURL, int32_t szURL, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_FindFirst(TElWebDAVMemoryLockListHandle _Handle, TObjectHandle * Handle, const char * pcURL, int32_t szURL, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_FindNext(TElWebDAVMemoryLockListHandle _Handle, TObjectHandle Handle, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_FindClose(TElWebDAVMemoryLockListHandle _Handle, TObjectHandle Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_LoadFromStream(TElWebDAVMemoryLockListHandle _Handle, TStreamHandle Stream, int8_t Clear);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_SaveToStream(TElWebDAVMemoryLockListHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_Cleanup(TElWebDAVMemoryLockListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_get_Locks(TElWebDAVMemoryLockListHandle _Handle, int32_t Idx, TElWebDAVLockHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_get_Count(TElWebDAVMemoryLockListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVMemoryLockList_Create(TComponentHandle AOwner, TElWebDAVMemoryLockListHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVMEMORYLOCKLIST */

#ifdef SB_USE_CLASS_TELWEBDAVACLOPTIONS
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_get_UseACL(TElWebDAVACLOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_set_UseACL(TElWebDAVACLOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_get_PrincipalBackend(TElWebDAVACLOptionsHandle _Handle, TElWebDAVPrincipalBackendHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_set_PrincipalBackend(TElWebDAVACLOptionsHandle _Handle, TElWebDAVPrincipalBackendHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_get_AbstractPrivileges(TElWebDAVACLOptionsHandle _Handle, int16_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_set_AbstractPrivileges(TElWebDAVACLOptionsHandle _Handle, const int16_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_get_MatchingPrincipalsLimit(TElWebDAVACLOptionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_set_MatchingPrincipalsLimit(TElWebDAVACLOptionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_get_OnReadCurrentUserPrivileges(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVReadPrivilegesEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_set_OnReadCurrentUserPrivileges(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVReadPrivilegesEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_get_OnReadSupportedPrivileges(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVReadSupportedPrivilegesEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_set_OnReadSupportedPrivileges(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVReadSupportedPrivilegesEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_get_OnReadOwner(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVReadOwnerEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_set_OnReadOwner(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVReadOwnerEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_get_OnGetPrivilegeDescription(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVGetPrivilegeDescriptionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_set_OnGetPrivilegeDescription(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVGetPrivilegeDescriptionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_get_OnGetACLRestrictions(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVGetACLRestrictionsEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_set_OnGetACLRestrictions(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVGetACLRestrictionsEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_get_OnGetACL(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVGetACLEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_set_OnGetACL(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVGetACLEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_get_OnSetACL(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVSetACLEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_set_OnSetACL(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVSetACLEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_get_OnGetInheritedACLSet(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVGetURLSetEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_set_OnGetInheritedACLSet(TElWebDAVACLOptionsHandle _Handle, TSBWebDAVGetURLSetEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVACLOptions_Create(TElWebDAVACLOptionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVACLOPTIONS */

#ifdef SB_USE_CLASS_TELCARDDAVOPTIONS
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_get_UseCardDAV(TElCardDAVOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_set_UseCardDAV(TElCardDAVOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_get_AddressBookURLs(TElCardDAVOptionsHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_get_MaxResourceSize(TElCardDAVOptionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_set_MaxResourceSize(TElCardDAVOptionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_get_NumberOfMatchesLimit(TElCardDAVOptionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_set_NumberOfMatchesLimit(TElCardDAVOptionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_get_AllowExtendedMkCol(TElCardDAVOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_set_AllowExtendedMkCol(TElCardDAVOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_get_OnCheckIfAddressBook(TElCardDAVOptionsHandle _Handle, TSBWebDAVCheckIfAddressBookEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_set_OnCheckIfAddressBook(TElCardDAVOptionsHandle _Handle, TSBWebDAVCheckIfAddressBookEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_get_OnSetAsAddressBook(TElCardDAVOptionsHandle _Handle, TSBWebDAVSetAsAddressBookEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_set_OnSetAsAddressBook(TElCardDAVOptionsHandle _Handle, TSBWebDAVSetAsAddressBookEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_get_OnCheckUIDUniqueness(TElCardDAVOptionsHandle _Handle, TSBCheckUIDUniquenessEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_set_OnCheckUIDUniqueness(TElCardDAVOptionsHandle _Handle, TSBCheckUIDUniquenessEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCardDAVOptions_Create(TElCardDAVOptionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELCARDDAVOPTIONS */

#ifdef SB_USE_CLASS_TELCALDAVOPTIONS
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_get_UseCalDAV(TElCalDAVOptionsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_set_UseCalDAV(TElCalDAVOptionsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_get_MaxResourceSize(TElCalDAVOptionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_set_MaxResourceSize(TElCalDAVOptionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_get_MinDateTime(TElCalDAVOptionsHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_set_MinDateTime(TElCalDAVOptionsHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_get_MaxDateTime(TElCalDAVOptionsHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_set_MaxDateTime(TElCalDAVOptionsHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_get_MaxRecurrenceInstances(TElCalDAVOptionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_set_MaxRecurrenceInstances(TElCalDAVOptionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_get_MaxAttendeesPerInstance(TElCalDAVOptionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_set_MaxAttendeesPerInstance(TElCalDAVOptionsHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_get_OnCheckIfCalendar(TElCalDAVOptionsHandle _Handle, TSBWebDAVCheckIfCalendarEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_set_OnCheckIfCalendar(TElCalDAVOptionsHandle _Handle, TSBWebDAVCheckIfCalendarEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_get_OnSetAsCalendar(TElCalDAVOptionsHandle _Handle, TSBWebDAVSetAsCalendarEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_set_OnSetAsCalendar(TElCalDAVOptionsHandle _Handle, TSBWebDAVSetAsCalendarEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_get_OnCheckUIDUniqueness(TElCalDAVOptionsHandle _Handle, TSBCheckUIDUniquenessEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_set_OnCheckUIDUniqueness(TElCalDAVOptionsHandle _Handle, TSBCheckUIDUniquenessEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_get_OnExpandCalendar(TElCalDAVOptionsHandle _Handle, TSBWebDAVExpandCalendarEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_set_OnExpandCalendar(TElCalDAVOptionsHandle _Handle, TSBWebDAVExpandCalendarEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_get_OnCalculateFreeBusy(TElCalDAVOptionsHandle _Handle, TSBWebDAVCalculateFreeBusyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_set_OnCalculateFreeBusy(TElCalDAVOptionsHandle _Handle, TSBWebDAVCalculateFreeBusyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElCalDAVOptions_Create(TElCalDAVOptionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELCALDAVOPTIONS */

#ifdef SB_USE_CLASS_TELWEBDAVCOLLATION
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCollation_CreateInstance(TSBWebDAVFilterTextMatchCollationRaw Collation, TElWebDAVCollationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCollation_CreateInstance_1(TElWebDAVCollationHandle _Handle, TSBWebDAVFilterTextMatchCollationRaw Collation, TElWebDAVCollationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCollation_Compare(TElWebDAVCollationHandle _Handle, const char * pcS1, int32_t szS1, const char * pcS2, int32_t szS2, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCollation_StartsWith(TElWebDAVCollationHandle _Handle, const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCollation_EndsWith(TElWebDAVCollationHandle _Handle, const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCollation_Equals(TElWebDAVCollationHandle _Handle, const char * pcS1, int32_t szS1, const char * pcS2, int32_t szS2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCollation_IndexOf(TElWebDAVCollationHandle _Handle, const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVCollation_Create(TElWebDAVCollationHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVCOLLATION */

#ifdef SB_USE_CLASS_TELWEBDAVUNICODECOLLATION
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVUnicodeCollation_Compare(TElWebDAVUnicodeCollationHandle _Handle, const char * pcS1, int32_t szS1, const char * pcS2, int32_t szS2, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVUnicodeCollation_StartsWith(TElWebDAVUnicodeCollationHandle _Handle, const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVUnicodeCollation_EndsWith(TElWebDAVUnicodeCollationHandle _Handle, const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVUnicodeCollation_Equals(TElWebDAVUnicodeCollationHandle _Handle, const char * pcS1, int32_t szS1, const char * pcS2, int32_t szS2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVUnicodeCollation_IndexOf(TElWebDAVUnicodeCollationHandle _Handle, const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVUnicodeCollation_Create(TElWebDAVUnicodeCollationHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVUNICODECOLLATION */

#ifdef SB_USE_CLASS_TELWEBDAVASCIICOLLATION
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVAsciiCollation_Compare(TElWebDAVAsciiCollationHandle _Handle, const char * pcS1, int32_t szS1, const char * pcS2, int32_t szS2, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVAsciiCollation_StartsWith(TElWebDAVAsciiCollationHandle _Handle, const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVAsciiCollation_EndsWith(TElWebDAVAsciiCollationHandle _Handle, const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVAsciiCollation_Equals(TElWebDAVAsciiCollationHandle _Handle, const char * pcS1, int32_t szS1, const char * pcS2, int32_t szS2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVAsciiCollation_IndexOf(TElWebDAVAsciiCollationHandle _Handle, const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVAsciiCollation_Create(TElWebDAVAsciiCollationHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVASCIICOLLATION */

#ifdef SB_USE_CLASS_TELWEBDAVOCTETCOLLATION
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVOctetCollation_Compare(TElWebDAVOctetCollationHandle _Handle, const char * pcS1, int32_t szS1, const char * pcS2, int32_t szS2, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVOctetCollation_StartsWith(TElWebDAVOctetCollationHandle _Handle, const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVOctetCollation_EndsWith(TElWebDAVOctetCollationHandle _Handle, const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVOctetCollation_Equals(TElWebDAVOctetCollationHandle _Handle, const char * pcS1, int32_t szS1, const char * pcS2, int32_t szS2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVOctetCollation_IndexOf(TElWebDAVOctetCollationHandle _Handle, const char * pcS, int32_t szS, const char * pcSubS, int32_t szSubS, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebDAVOctetCollation_Create(TElWebDAVOctetCollationHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBDAVOCTETCOLLATION */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElWebDAVServer_ce_ptr;
extern zend_class_entry *TElWebDAVTimeRangeBase_ce_ptr;
extern zend_class_entry *SBWebDAVServer_TElWebDAVPrincipal_ce_ptr;
extern zend_class_entry *TElWebDAVInMemoryPrincipal_ce_ptr;
extern zend_class_entry *TElWebDAVPrincipalBackend_ce_ptr;
extern zend_class_entry *TElWebDAVPrincipalMemoryBackend_ce_ptr;
extern zend_class_entry *TElCalDavTextMatchFilter_ce_ptr;
extern zend_class_entry *TElCalDavParamFilter_ce_ptr;
extern zend_class_entry *TElWebDAVExpand_ce_ptr;
extern zend_class_entry *TElWebDAVTimeRange_ce_ptr;
extern zend_class_entry *TElCalDavPropFilter_ce_ptr;
extern zend_class_entry *TElCalDAVCompFilter_ce_ptr;
extern zend_class_entry *TElWebDAVExtendedRequest_ce_ptr;
extern zend_class_entry *TElWebDAVAddressBookRequest_ce_ptr;
extern zend_class_entry *TElWebDAVLimitRecurrenceSet_ce_ptr;
extern zend_class_entry *TElWebDAVLimitFreeBusySet_ce_ptr;
extern zend_class_entry *TElWebDAVComp_ce_ptr;
extern zend_class_entry *TElWebDAVCalendarRequest_ce_ptr;
extern zend_class_entry *TElWebDAVFreeBusyRequest_ce_ptr;
extern zend_class_entry *TElWebDAVProperty_ce_ptr;
extern zend_class_entry *TElWebDAVIfState_ce_ptr;
extern zend_class_entry *TElWebDAVIfResource_ce_ptr;
extern zend_class_entry *TElWebDAVIfHeader_ce_ptr;
extern zend_class_entry *TElWebDAVCustomLockList_ce_ptr;
extern zend_class_entry *TElWebDAVFindMemoryLockHandle_ce_ptr;
extern zend_class_entry *TElWebDAVMemoryLockList_ce_ptr;
extern zend_class_entry *TElWebDAVACLOptions_ce_ptr;
extern zend_class_entry *TElCardDAVOptions_ce_ptr;
extern zend_class_entry *TElCalDAVOptions_ce_ptr;
extern zend_class_entry *TElWebDAVCollation_ce_ptr;
extern zend_class_entry *TElWebDAVUnicodeCollation_ce_ptr;
extern zend_class_entry *TElWebDAVAsciiCollation_ce_ptr;
extern zend_class_entry *TElWebDAVOctetCollation_ce_ptr;

void SB_CALLBACK TSBWebDAVBeforeRequestEventRaw(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle Params, int8_t * Accept, int32_t * StatusCode, char * pcReasonPhrase, int32_t * szReasonPhrase);
void SB_CALLBACK TSBWebDAVRequestEventRaw(void * _ObjectData, TObjectHandle Sender, TElHTTPServerRequestParamsHandle Params, TMemoryStreamHandle Data);
void SB_CALLBACK TSBWebDAVResponseEventRaw(void * _ObjectData, TObjectHandle Sender, TElHTTPServerResponseParamsHandle Params, TMemoryStreamHandle Data);
void SB_CALLBACK TSBWebDAVStatusCodeEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t * StatusCode, TElHTTPServerRequestParamsHandle ReqParams, TElHTTPServerResponseParamsHandle RespParams);
void SB_CALLBACK TSBWebDAVBeforeDownloadEventRaw(void * _ObjectData, TObjectHandle Sender, char * pcURL, int32_t * szURL, int8_t * Allow);
void SB_CALLBACK TSBWebDAVBeforeUploadEventRaw(void * _ObjectData, TObjectHandle Sender, char * pcURL, int32_t * szURL, int8_t * Allow);
void SB_CALLBACK TSBWebDAVTransferFinishedEventRaw(void * _ObjectData, TObjectHandle Sender);
void SB_CALLBACK TSBWebDAVQueryQuotaEventRaw(void * _ObjectData, TObjectHandle Sender, int64_t * Available, int64_t * Used);
void SB_CALLBACK TSBWebDAVPropertyReadValueEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, char * pcValue, int32_t * szValue, TElXMLDOMElementHandle Element, int8_t * Success);
void SB_CALLBACK TSBWebDAVPropertyReadExValueEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, char * pcValue, int32_t * szValue, TElXMLDOMElementHandle Element, TObjectHandle Param, int8_t * Success);
void SB_CALLBACK TSBWebDAVPropertyAfterReadValueEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, char * pcValue, int32_t * szValue, TElXMLDOMElementHandle Element);
void SB_CALLBACK TSBWebDAVPropertyBeforeWriteValueEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, char * pcValue, int32_t * szValue, int8_t * Success);
void SB_CALLBACK TSBWebDAVPropertyWriteValueEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, const char * pcValue, int32_t szValue, int8_t * Success);
void SB_CALLBACK TSBWebDAVPropertyRemoveEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, const char * pcNS, int32_t szNS, const char * pcName, int32_t szName, int8_t * Success);
void SB_CALLBACK TSBWebDAVCheckIfAddressBookEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, int8_t * Success);
void SB_CALLBACK TSBWebDAVSetAsAddressBookEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, int8_t * Success);
void SB_CALLBACK TSBWebDAVCheckIfCalendarEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, int8_t * Success);
void SB_CALLBACK TSBWebDAVSetAsCalendarEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, int8_t * Success);
void SB_CALLBACK TSBWebDAVExpandCalendarEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, TElVCalendarHandle Calendar, TElWebDAVExpandHandle ExpandPeriod, int32_t Index, int32_t MaxRecurrenceInstances, TElVCalendarHandle * OutResult);
void SB_CALLBACK TSBWebDAVCalculateFreeBusyEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, int64_t StartRange, int64_t EndRange, TElVCalendarHandle * OutResult);
void SB_CALLBACK TSBWebDAVReadPrivilegesEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, int32_t * Privileges);
void SB_CALLBACK TSBWebDAVReadOwnerEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle * Principal);
void SB_CALLBACK TSBWebDAVReadSupportedPrivilegesEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, int32_t * Privileges);
void SB_CALLBACK TSBWebDAVGetPrivilegeDescriptionEventRaw(void * _ObjectData, TObjectHandle Sender, int16_t Privilege, char * pcDescription, int32_t * szDescription, char * pcLanguage, int32_t * szLanguage);
void SB_CALLBACK TSBWebDAVGetACLRestrictionsEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, TElWebDAVACLRestrictionsHandle Restrictions);
void SB_CALLBACK TSBWebDAVGetACLEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, TListHandle List, int8_t * OwnList);
void SB_CALLBACK TSBWebDAVSetACLEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, TListHandle List, TSBWebDAVACLErrorRaw * Error, int32_t * StatusCode);
void SB_CALLBACK TSBWebDAVGetURLSetEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, TElStringListHandle List);
void SB_CALLBACK TSBCheckUIDUniquenessEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, SBWebDAVServer_TElWebDAVPrincipalHandle Principal, TElDirInfoPropertiesListHandle PropList, int8_t * Unique);
void Register_TElWebDAVServer(TSRMLS_D);
void Register_TElWebDAVTimeRangeBase(TSRMLS_D);
void Register_SBWebDAVServer_TElWebDAVPrincipal(TSRMLS_D);
void Register_TElWebDAVInMemoryPrincipal(TSRMLS_D);
void Register_TElWebDAVPrincipalBackend(TSRMLS_D);
void Register_TElWebDAVPrincipalMemoryBackend(TSRMLS_D);
void Register_TElCalDavTextMatchFilter(TSRMLS_D);
void Register_TElCalDavParamFilter(TSRMLS_D);
void Register_TElWebDAVExpand(TSRMLS_D);
void Register_TElWebDAVTimeRange(TSRMLS_D);
void Register_TElCalDavPropFilter(TSRMLS_D);
void Register_TElCalDAVCompFilter(TSRMLS_D);
void Register_TElWebDAVExtendedRequest(TSRMLS_D);
void Register_TElWebDAVAddressBookRequest(TSRMLS_D);
void Register_TElWebDAVLimitRecurrenceSet(TSRMLS_D);
void Register_TElWebDAVLimitFreeBusySet(TSRMLS_D);
void Register_TElWebDAVComp(TSRMLS_D);
void Register_TElWebDAVCalendarRequest(TSRMLS_D);
void Register_TElWebDAVFreeBusyRequest(TSRMLS_D);
void Register_TElWebDAVProperty(TSRMLS_D);
void Register_TElWebDAVIfState(TSRMLS_D);
void Register_TElWebDAVIfResource(TSRMLS_D);
void Register_TElWebDAVIfHeader(TSRMLS_D);
void Register_TElWebDAVCustomLockList(TSRMLS_D);
void Register_TElWebDAVFindMemoryLockHandle(TSRMLS_D);
void Register_TElWebDAVMemoryLockList(TSRMLS_D);
void Register_TElWebDAVACLOptions(TSRMLS_D);
void Register_TElCardDAVOptions(TSRMLS_D);
void Register_TElCalDAVOptions(TSRMLS_D);
void Register_TElWebDAVCollation(TSRMLS_D);
void Register_TElWebDAVUnicodeCollation(TSRMLS_D);
void Register_TElWebDAVAsciiCollation(TSRMLS_D);
void Register_TElWebDAVOctetCollation(TSRMLS_D);
SB_PHP_FUNCTION(SBWebDAVServer, FindLockInList);
void Register_SBWebDAVServer_Constants(int module_number TSRMLS_DC);
void Register_SBWebDAVServer_Enum_Flags(TSRMLS_D);
void Register_SBWebDAVServer_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_WEBDAVSERVER
SB_IMPORT uint32_t SB_APIENTRY SBWebDAVServer_FindLockInList(const TListHandle List, const char * pcToken, int32_t szToken, TElWebDAVLockHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_WEBDAVSERVER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBWEBDAVSERVER */

