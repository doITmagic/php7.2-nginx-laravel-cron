#ifndef __INC_SBWEBSOCKETCOMMON
#define __INC_SBWEBSOCKETCOMMON

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbrandom.h"
#include "sbsslcommon.h"
#include "sbtypes.h"
#include "sbsharedresource.h"
#include "sbstrutils.h"
#include "sbhashfunction.h"
#include "sbencoding.h"
#include "sbstringlist.h"
#include "sbutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_WS_VERSION 	13
#define SB_WS_VERSION_STR 	"13"
#define SB_DEFAULT_FRAME_LEN 	1024
#define SB_WS_MODE_CLIENT 	0
#define SB_WS_MODE_SERVER 	1
#define SB_WS_NO_CLOSE_DESC 	-1
#define SB_WS_STATUS_OK 	1000
#define SB_WS_STATUS_GOING_AWAY 	1001
#define SB_WS_STATUS_PROTOCOL_ERROR 	1002
#define SB_WS_STATUS_CANT_ACCEPT_DATA 	1003
#define SB_WS_STATUS_RESERVED 	1004
#define SB_WS_STATUS_NO_STATUS_CODE 	1005
#define SB_WS_STATUS_CONN_CLOSED_ABNORMALLY 	1006
#define SB_WS_STATUS_NOT_CONSISTENT_DATA 	1007
#define SB_WS_STATUS_POLICY_VIOLATION 	1008
#define SB_WS_STATUS_TOO_BIG_MESSAGE 	1009
#define SB_WS_STATUS_CLIENT_EXTENSIONS_EXPECTED 	1010
#define SB_WS_STATUS_UNEXPECTED 	1011
#define SB_WS_STATUS_TLS_HANDSHAKE_FAILURE 	1015
#define SB_WS_OP_CONTINUATION 	0
#define SB_WS_OP_TEXT 	1
#define SB_WS_OP_BINARY 	2
#define SB_WS_OP_CLOSE 	8
#define SB_WS_OP_PING 	9
#define SB_WS_OP_PONG 	10

typedef TElClassHandle TElWebSocketMessageHandle;

typedef TElClassHandle TElWebSocketOptionHandle;

typedef TElClassHandle TElWebSocketExtensionHandle;

typedef TElClassHandle TElWebSocketBaseHandle;

typedef TElClassHandle TElWebSocketSubProtocolHandle;

typedef TElClassHandle TElWebSocketExtensionsHandle;

typedef TElClassHandle TElWebSocketSubProtocolsHandle;

typedef uint8_t TSBMsgTypeRaw;

typedef enum
{
	wmtNone = 0,
	wmtBinary = 1,
	wmtText = 2
} TSBMsgType;

typedef void (SB_CALLBACK *TSBWSBeforeMsgSendEvent)(void * _ObjectData, TObjectHandle Sender, TElWebSocketMessageHandle Msg);

typedef void (SB_CALLBACK *TSBWSMsgReceivedEvent)(void * _ObjectData, TObjectHandle Sender, TElWebSocketMessageHandle Msg);

typedef void (SB_CALLBACK *TSBWSPongEvent)(void * _ObjectData, TObjectHandle Sender);

typedef void (SB_CALLBACK *TSBWSTextDataEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcText, int32_t szText, int8_t Last);

typedef void (SB_CALLBACK *TSBWSCloseConnectionEvent)(void * _ObjectData, TObjectHandle Sender, int8_t Remote, int32_t CloseDescription);

typedef void (SB_CALLBACK *TSBWSBinaryDataEvent)(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size, int8_t Last);

#ifdef SB_USE_CLASS_TELWEBSOCKETMESSAGE
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_Clone(TElWebSocketMessageHandle _Handle, TElWebSocketMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_Clear(TElWebSocketMessageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_SaveToBuffer(TElWebSocketMessageHandle _Handle, uint8_t pBuffer[], int32_t * szBuffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_LoadFromBuffer(TElWebSocketMessageHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t Offset, int32_t Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_get_IsFinal(TElWebSocketMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_set_IsFinal(TElWebSocketMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_get_RSV1(TElWebSocketMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_set_RSV1(TElWebSocketMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_get_RSV2(TElWebSocketMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_set_RSV2(TElWebSocketMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_get_RSV3(TElWebSocketMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_set_RSV3(TElWebSocketMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_get_OpCode(TElWebSocketMessageHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_set_OpCode(TElWebSocketMessageHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_get_Mask(TElWebSocketMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_set_Mask(TElWebSocketMessageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_get_PayloadLen(TElWebSocketMessageHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_get_Fragmented(TElWebSocketMessageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_get_MaskKey(TElWebSocketMessageHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_set_MaskKey(TElWebSocketMessageHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_get_PayloadData(TElWebSocketMessageHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_set_PayloadData(TElWebSocketMessageHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_get_FullSize(TElWebSocketMessageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketMessage_Create(TElWebSocketMessageHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBSOCKETMESSAGE */

#ifdef SB_USE_CLASS_TELWEBSOCKETOPTION
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketOption_Assign(TElWebSocketOptionHandle _Handle, TElWebSocketOptionHandle Option);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketOption_Clone(TElWebSocketOptionHandle _Handle, TElWebSocketOptionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketOption_get_Name(TElWebSocketOptionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketOption_get_Active(TElWebSocketOptionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketOption_set_Active(TElWebSocketOptionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketOption_get_Priority(TElWebSocketOptionHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketOption_set_Priority(TElWebSocketOptionHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketOption_get_ParamStr(TElWebSocketOptionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketOption_set_ParamStr(TElWebSocketOptionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketOption_Create(TElWebSocketOptionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketOption_Create_1(int32_t APriority, TElWebSocketOptionHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBSOCKETOPTION */

#ifdef SB_USE_CLASS_TELWEBSOCKETEXTENSION
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketExtension_Clone(TElWebSocketExtensionHandle _Handle, TElWebSocketExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketExtension_Encode(TElWebSocketExtensionHandle _Handle, TElWebSocketMessageHandle Msg, TElWebSocketMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketExtension_Decode(TElWebSocketExtensionHandle _Handle, TElWebSocketMessageHandle Msg, TElWebSocketMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketExtension_Create(TElWebSocketOptionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketExtension_Create_1(int32_t APriority, TElWebSocketOptionHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBSOCKETEXTENSION */

#ifdef SB_USE_CLASS_TELWEBSOCKETBASE
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_SetControl(TElWebSocketBaseHandle _Handle, TElSSLClassHandle Control);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_CreateWebSocketAccept(const char * pcKey, int32_t szKey, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_CreateWebSocketAccept_1(TElWebSocketBaseHandle _Handle, const char * pcKey, int32_t szKey, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_Close(TElWebSocketBaseHandle _Handle, int8_t Silent);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_Close_1(TElWebSocketBaseHandle _Handle, int8_t Silent, int32_t CloseDescription);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_SendData(TElWebSocketBaseHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_SendData_1(TElWebSocketBaseHandle _Handle, const uint8_t pBuffer[], int32_t szBuffer, int32_t StartIndex, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_SendData_2(TElWebSocketBaseHandle _Handle, const TStreamHandle Strm);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_SendData_3(TElWebSocketBaseHandle _Handle, const TStreamHandle Strm, int32_t OpCode);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_SendText(TElWebSocketBaseHandle _Handle, const char * pcText, int32_t szText);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_Ping(TElWebSocketBaseHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_SubProtocols(TElWebSocketBaseHandle _Handle, TElWebSocketSubProtocolsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_SubProtocol(TElWebSocketBaseHandle _Handle, TElWebSocketSubProtocolHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_Extensions(TElWebSocketBaseHandle _Handle, TElWebSocketExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_ParentObject(TElWebSocketBaseHandle _Handle, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_set_ParentObject(TElWebSocketBaseHandle _Handle, TObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_Active(TElWebSocketBaseHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_ProtocolStr(TElWebSocketBaseHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_PeerSubProtocolStr(TElWebSocketBaseHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_set_PeerSubProtocolStr(TElWebSocketBaseHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_ExtensionsStr(TElWebSocketBaseHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_PeerExtensionsStr(TElWebSocketBaseHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_set_PeerExtensionsStr(TElWebSocketBaseHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_FrameLength(TElWebSocketBaseHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_set_FrameLength(TElWebSocketBaseHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_OnBeforeMessageSend(TElWebSocketBaseHandle _Handle, TSBWSBeforeMsgSendEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_set_OnBeforeMessageSend(TElWebSocketBaseHandle _Handle, TSBWSBeforeMsgSendEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_OnMessageReceived(TElWebSocketBaseHandle _Handle, TSBWSMsgReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_set_OnMessageReceived(TElWebSocketBaseHandle _Handle, TSBWSMsgReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_OnBinaryData(TElWebSocketBaseHandle _Handle, TSBWSBinaryDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_set_OnBinaryData(TElWebSocketBaseHandle _Handle, TSBWSBinaryDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_OnTextData(TElWebSocketBaseHandle _Handle, TSBWSTextDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_set_OnTextData(TElWebSocketBaseHandle _Handle, TSBWSTextDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_OnPong(TElWebSocketBaseHandle _Handle, TSBWSPongEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_set_OnPong(TElWebSocketBaseHandle _Handle, TSBWSPongEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_get_OnCloseConnection(TElWebSocketBaseHandle _Handle, TSBWSCloseConnectionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_set_OnCloseConnection(TElWebSocketBaseHandle _Handle, TSBWSCloseConnectionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_Create(TElWebSocketBaseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketBase_Create_1(TElSSLClassHandle Control, TElWebSocketBaseHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBSOCKETBASE */

#ifdef SB_USE_CLASS_TELWEBSOCKETSUBPROTOCOL
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketSubProtocol_Clone(TElWebSocketSubProtocolHandle _Handle, TElWebSocketSubProtocolHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketSubProtocol_get_Owner(TElWebSocketSubProtocolHandle _Handle, TElWebSocketBaseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketSubProtocol_get_OnMessageReceived(TElWebSocketSubProtocolHandle _Handle, TSBWSMsgReceivedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketSubProtocol_set_OnMessageReceived(TElWebSocketSubProtocolHandle _Handle, TSBWSMsgReceivedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketSubProtocol_Create(TElWebSocketOptionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketSubProtocol_Create_1(int32_t APriority, TElWebSocketOptionHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBSOCKETSUBPROTOCOL */

#ifdef SB_USE_CLASS_TELWEBSOCKETEXTENSIONS
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketExtensions_CopyTo(TElWebSocketExtensionsHandle _Handle, TElWebSocketExtensionsHandle Exts);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketExtensions_Encode(TElWebSocketExtensionsHandle _Handle, TElWebSocketMessageHandle Msg, TElWebSocketMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketExtensions_Decode(TElWebSocketExtensionsHandle _Handle, TElWebSocketMessageHandle Msg, TElWebSocketMessageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketExtensions_Add(TElWebSocketExtensionsHandle _Handle, TElWebSocketExtensionHandle Ext, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketExtensions_Remove(TElWebSocketExtensionsHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketExtensions_Sort(TElWebSocketExtensionsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketExtensions_get_Items(TElWebSocketExtensionsHandle _Handle, int32_t Index, TElWebSocketExtensionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketExtensions_get_Count(TElWebSocketExtensionsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketExtensions_Create(TElWebSocketExtensionsHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBSOCKETEXTENSIONS */

#ifdef SB_USE_CLASS_TELWEBSOCKETSUBPROTOCOLS
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketSubProtocols_CopyTo(TElWebSocketSubProtocolsHandle _Handle, TElWebSocketSubProtocolsHandle Protos);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketSubProtocols_Add(TElWebSocketSubProtocolsHandle _Handle, TElWebSocketSubProtocolHandle Proto, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketSubProtocols_Remove(TElWebSocketSubProtocolsHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketSubProtocols_Sort(TElWebSocketSubProtocolsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketSubProtocols_get_Items(TElWebSocketSubProtocolsHandle _Handle, int32_t Index, TElWebSocketSubProtocolHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketSubProtocols_get_Count(TElWebSocketSubProtocolsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketSubProtocols_get_Owner(TElWebSocketSubProtocolsHandle _Handle, TElWebSocketBaseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWebSocketSubProtocols_Create(TElWebSocketSubProtocolsHandle * OutResult);
#endif /* SB_USE_CLASS_TELWEBSOCKETSUBPROTOCOLS */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElWebSocketMessage_ce_ptr;
extern zend_class_entry *TElWebSocketOption_ce_ptr;
extern zend_class_entry *TElWebSocketExtension_ce_ptr;
extern zend_class_entry *TElWebSocketBase_ce_ptr;
extern zend_class_entry *TElWebSocketSubProtocol_ce_ptr;
extern zend_class_entry *TElWebSocketExtensions_ce_ptr;
extern zend_class_entry *TElWebSocketSubProtocols_ce_ptr;

void SB_CALLBACK TSBWSBeforeMsgSendEventRaw(void * _ObjectData, TObjectHandle Sender, TElWebSocketMessageHandle Msg);
void SB_CALLBACK TSBWSMsgReceivedEventRaw(void * _ObjectData, TObjectHandle Sender, TElWebSocketMessageHandle Msg);
void SB_CALLBACK TSBWSPongEventRaw(void * _ObjectData, TObjectHandle Sender);
void SB_CALLBACK TSBWSTextDataEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcText, int32_t szText, int8_t Last);
void SB_CALLBACK TSBWSCloseConnectionEventRaw(void * _ObjectData, TObjectHandle Sender, int8_t Remote, int32_t CloseDescription);
void SB_CALLBACK TSBWSBinaryDataEventRaw(void * _ObjectData, TObjectHandle Sender, void * Buffer, int32_t Size, int8_t Last);
void Register_TElWebSocketMessage(TSRMLS_D);
void Register_TElWebSocketOption(TSRMLS_D);
void Register_TElWebSocketExtension(TSRMLS_D);
void Register_TElWebSocketBase(TSRMLS_D);
void Register_TElWebSocketSubProtocol(TSRMLS_D);
void Register_TElWebSocketExtensions(TSRMLS_D);
void Register_TElWebSocketSubProtocols(TSRMLS_D);
void Register_SBWebSocketCommon_Constants(int module_number TSRMLS_DC);
void Register_SBWebSocketCommon_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBWEBSOCKETCOMMON */

