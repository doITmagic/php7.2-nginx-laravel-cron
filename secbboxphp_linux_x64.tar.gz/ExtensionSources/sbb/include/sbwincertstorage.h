#ifndef __INC_SBWINCERTSTORAGE
#define __INC_SBWINCERTSTORAGE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#ifdef SB_WINDOWS
#include "sbtypes.h"
#include "sbcustomcertstorage.h"
#include "sbx509.h"
#include "sbwincrypt.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbalgorithmidentifier.h"
#include "sbconstants.h"
#include "sbsharedresource.h"
#include "sbcryptoprov.h"
#include "sbmskeyblob.h"
#endif

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef SB_WINDOWS
typedef TElClassHandle TElWinCertStorageHandle;

typedef TElWinCertStorageHandle ElWinCertStorageHandle;

typedef uint8_t TSBStorageTypeRaw;

typedef enum
{
	stSystem = 0,
	stRegistry = 1,
	stLDAP = 2,
	stMemory = 3
} TSBStorageType;

typedef uint8_t TSBStorageAccessTypeRaw;

typedef enum
{
	atCurrentService = 0,
	atCurrentUser = 1,
	atCurrentUserGroupPolicy = 2,
	atLocalMachine = 3,
	atLocalMachineEnterprise = 4,
	atLocalMachineGroupPolicy = 5,
	atServices = 6,
	atUsers = 7
} TSBStorageAccessType;

typedef uint8_t TSBStorageProviderTypeRaw;

typedef enum
{
	ptDefault = 0,
	ptBaseDSSDH = 1,
	ptBaseDSS = 2,
	ptBase = 3,
	ptRSASchannel = 4,
	ptRSASignature = 5,
	ptEnhancedDSSDH = 6,
	ptEnhancedRSAAES = 7,
	ptEnhanced = 8,
	ptBaseSmartCard = 9,
	ptStrong = 10,
	ptCryptoProGOST94 = 11,
	ptCryptoProGOST2001 = 12
} TSBStorageProviderType;

#ifdef SB_USE_CLASS_TELWINCERTSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_GetAvailableStores(TStringsHandle Stores, TSBStorageAccessTypeRaw AccessType);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_GetAvailableStores_1(TElWinCertStorageHandle _Handle, TStringsHandle Stores, TSBStorageAccessTypeRaw AccessType);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_GetAvailablePhysicalStores(const char * pcSystemStore, int32_t szSystemStore, TStringsHandle Stores, TSBStorageAccessTypeRaw AccessType);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_GetAvailablePhysicalStores_1(TElWinCertStorageHandle _Handle, const char * pcSystemStore, int32_t szSystemStore, TStringsHandle Stores, TSBStorageAccessTypeRaw AccessType);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_GetStoreFriendlyName(const char * pcStoreName, int32_t szStoreName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_GetStoreFriendlyName_1(TElWinCertStorageHandle _Handle, const char * pcStoreName, int32_t szStoreName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_Add(TElWinCertStorageHandle _Handle, TElX509CertificateHandle Certificate, int8_t CopyPrivateKey);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_Add_1(TElWinCertStorageHandle _Handle, TElX509CertificateHandle Certificate, const char * pcStoreName, int32_t szStoreName, int8_t CopyPrivateKey, int8_t Exportable, int8_t Protected);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_Add_2(TElWinCertStorageHandle _Handle, TElX509CertificateHandle Certificate, int8_t BindToExistingPrivateKey, const char * pcStoreName, int32_t szStoreName, const char * pcPrivateKeyContainerName, int32_t szPrivateKeyContainerName);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_Remove(TElWinCertStorageHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_Refresh(TElWinCertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_PreloadCertificates(TElWinCertStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_CreateStore(TElWinCertStorageHandle _Handle, const char * pcStoreName, int32_t szStoreName);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_DeleteStore(TElWinCertStorageHandle _Handle, const char * pcStoreName, int32_t szStoreName);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_ListKeyContainers(TElWinCertStorageHandle _Handle, TElStringListHandle List);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_ListKeyContainers_1(TElWinCertStorageHandle _Handle, TElStringListHandle List, TSBStorageProviderTypeRaw ProvType);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_DeleteKeyContainer(TElWinCertStorageHandle _Handle, const char * pcContainerName, int32_t szContainerName);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_Select(TElWinCertStorageHandle _Handle, uint32_t Owner, TElCustomCertStorageHandle SelectedList, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_ImportWizard(uint32_t Owner, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_ImportWizard_1(TElWinCertStorageHandle _Handle, uint32_t Owner, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_get_Count(TElWinCertStorageHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_get_Certificates(TElWinCertStorageHandle _Handle, int32_t Index, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_get_TryCurrentUser(TElWinCertStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_set_TryCurrentUser(TElWinCertStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_get_SystemStores(TElWinCertStorageHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_set_SystemStores(TElWinCertStorageHandle _Handle, TStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_get_PhysicalStores(TElWinCertStorageHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_set_PhysicalStores(TElWinCertStorageHandle _Handle, TStringListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_get_StorageType(TElWinCertStorageHandle _Handle, TSBStorageTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_set_StorageType(TElWinCertStorageHandle _Handle, TSBStorageTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_get_AccessType(TElWinCertStorageHandle _Handle, TSBStorageAccessTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_set_AccessType(TElWinCertStorageHandle _Handle, TSBStorageAccessTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_get_Provider(TElWinCertStorageHandle _Handle, TSBStorageProviderTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_set_Provider(TElWinCertStorageHandle _Handle, TSBStorageProviderTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_get_ReadOnly(TElWinCertStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_set_ReadOnly(TElWinCertStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_get_CryptoProvider(TElWinCertStorageHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_set_CryptoProvider(TElWinCertStorageHandle _Handle, TElCustomCryptoProviderHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_get_AllowDuplicates(TElWinCertStorageHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_set_AllowDuplicates(TElWinCertStorageHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElWinCertStorage_Create(TComponentHandle Owner, TElWinCertStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELWINCERTSTORAGE */
#endif

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef SB_WINDOWS
extern zend_class_entry *TElWinCertStorage_ce_ptr;

void Register_TElWinCertStorage(TSRMLS_D);
void Register_SBWinCertStorage_Enum_Flags(TSRMLS_D);
void Register_SBWinCertStorage_Aliases(TSRMLS_D);
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBWINCERTSTORAGE */
