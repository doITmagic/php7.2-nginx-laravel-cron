#ifndef __INC_SBWINCRYPT
#define __INC_SBWINCRYPT

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#ifdef SB_WINDOWS
#include "sbtypes.h"
#include "sbutils.h"
#include "sbrandom.h"
#include "sbconstants.h"
#endif

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef SB_WINDOWS
#define SB_CERT_STORE_ADD_NEW 	1
#define SB_CERT_STORE_ADD_REPLACE_EXISTING 	3
#define SB_CERT_STORE_ADD_ALWAYS 	4
#define SB_CERT_STORE_READONLY_FLAG 	32768
#define SB_CRYPT_ASN_ENCODING 	1
#define SB_CRYPT_NDR_ENCODING 	2
#define SB_CRYPT_E_UNKNOWN_ALGO 	2148077570
#define SB_CRYPT_E_EXISTS 	2148081669
#define SB_X509_ASN_ENCODING 	1
#define SB_X509_NDR_ENCODING 	2
#define SB_PKCS_7_ASN_ENCODING 	65536
#define SB_PKCS_7_NDR_ENCODING 	131072
#define SB_CERT_INFO_VERSION_FLAG 	1
#define SB_CERT_INFO_SERIAL_NUMBER_FLAG 	2
#define SB_CERT_INFO_SIGNATURE_ALGORITHM_FLAG 	3
#define SB_CERT_INFO_ISSUER_FLAG 	4
#define SB_CERT_INFO_NOT_BEFORE_FLAG 	5
#define SB_CERT_INFO_NOT_AFTER_FLAG 	6
#define SB_CERT_INFO_SUBJECT_FLAG 	7
#define SB_CERT_INFO_SUBJECT_PUBLIC_KEY_INFO_FLAG 	8
#define SB_CERT_INFO_ISSUER_UNIQUE_ID_FLAG 	9
#define SB_CERT_INFO_SUBJECT_UNIQUE_ID_FLAG 	10
#define SB_CERT_INFO_EXTENSION_FLAG 	11
#define SB_CERT_COMPARE_SHIFT 	16
#define SB_CERT_COMPARE_ANY 	0
#define SB_CERT_COMPARE_SHA1_HASH 	1
#define SB_CERT_COMPARE_NAME 	2
#define SB_CERT_COMPARE_ATTR 	3
#define SB_CERT_COMPARE_MD5_HASH 	4
#define SB_CERT_COMPARE_PROPERTY 	5
#define SB_CERT_COMPARE_PUBLIC_KEY 	6
#define SB_CERT_COMPARE_HASH 	1
#define SB_CERT_COMPARE_NAME_STR_A 	7
#define SB_CERT_COMPARE_NAME_STR_W 	8
#define SB_CERT_COMPARE_KEY_SPEC 	9
#define SB_CERT_COMPARE_ENHKEY_USAGE 	10
#define SB_CERT_COMPARE_CTL_USAGE 	10
#define SB_CERT_FIND_ANY 	0
#define SB_CERT_FIND_SHA1_HASH 	65536
#define SB_CERT_FIND_MD5_HASH 	262144
#define SB_CERT_FIND_HASH 	65536
#define SB_CERT_FIND_PROPERTY 	327680
#define SB_CERT_FIND_PUBLIC_KEY 	393216
#define SB_CERT_FIND_SUBJECT_NAME 	131079
#define SB_CERT_FIND_SUBJECT_ATTR 	196615
#define SB_CERT_FIND_ISSUER_NAME 	131076
#define SB_CERT_FIND_ISSUER_ATTR 	196612
#define SB_CERT_FIND_SUBJECT_STR_A 	458759
#define SB_CERT_FIND_SUBJECT_STR_W 	524295
#define SB_CERT_FIND_SUBJECT_STR 	524295
#define SB_CERT_FIND_ISSUER_STR_A 	458756
#define SB_CERT_FIND_ISSUER_STR_W 	524292
#define SB_CERT_FIND_ISSUER_STR 	524292
#define SB_CERT_FIND_KEY_SPEC 	589824
#define SB_CERT_FIND_ENHKEY_USAGE 	655360
#define SB_CERT_FIND_CTL_USAGE 	655360
#define SB_CERT_SYSTEM_STORE_LOCATION_MASK 	16711680
#define SB_CERT_SYSTEM_STORE_LOCATION_SHIFT 	16
#define SB_CERT_SYSTEM_STORE_CURRENT_USER_ID 	1
#define SB_CERT_SYSTEM_STORE_LOCAL_MACHINE_ID 	2
#define SB_CERT_SYSTEM_STORE_CURRENT_SERVICE_ID 	4
#define SB_CERT_SYSTEM_STORE_SERVICES_ID 	5
#define SB_CERT_SYSTEM_STORE_USERS_ID 	6
#define SB_CERT_SYSTEM_STORE_CURRENT_USER_GROUP_POLICY_ID 	7
#define SB_CERT_SYSTEM_STORE_LOCAL_MACHINE_GROUP_POLICY_ID 	8
#define SB_CERT_SYSTEM_STORE_LOCAL_MACHINE_ENTERPRISE_ID 	9
#define SB_CERT_SYSTEM_STORE_CURRENT_USER 	65536
#define SB_CERT_SYSTEM_STORE_LOCAL_MACHINE 	131072
#define SB_CERT_SYSTEM_STORE_CURRENT_SERVICE 	262144
#define SB_CERT_SYSTEM_STORE_SERVICES 	327680
#define SB_CERT_SYSTEM_STORE_USERS 	393216
#define SB_CERT_SYSTEM_STORE_CURRENT_USER_GROUP_POLICY 	458752
#define SB_CERT_SYSTEM_STORE_LOCAL_MACHINE_ENTERPRISE 	589824
#define SB_CERT_SYSTEM_STORE_LOCAL_MACHINE_GROUP_POLICY 	524288
#define SB_CERT_STORE_OPEN_EXISTING_FLAG 	16384
#define SB_CERT_STORE_CREATE_NEW_FLAG 	8192
#define SB_CERT_STORE_DELETE_FLAG 	16
#define SB_CRYPT_OID_OPEN_STORE_PROV_FUNC 	"CertDllOpenStoreProv"
#define SB_CERT_STORE_PROV_PHYSICAL 	14
#define SB_CERT_KEY_PROV_INFO_PROP_ID 	2
#define SB_CERT_KEY_CONTEXT_PROP_ID 	5
#define SB_CERT_KEY_SPEC_PROP_ID 	6
#define SB_CERT_FRIENDLY_NAME_PROP_ID 	11
#define SB_CERT_NCRYPT_KEY_HANDLE_TRANSFER_PROP_ID 	99
#define SB_AT_KEYEXCHANGE 	1
#define SB_AT_SIGNATURE 	2
#define SB_PUBLICKEYBLOB 	6
#define SB_PRIVATEKEYBLOB 	7
#define SB_PLAINTEXTKEYBLOB 	8
#define SB_CRYPT_SILENT 	64
#define SB_CRYPT_MESSAGE_SILENT_KEYSET_FLAG 	64
#define SB_szOID_RSA_MD5 	"1.2.840.113549.2.5"
#define SB_CRYPT_MODE_CBC 	1
#define SB_CRYPT_MODE_ECB 	2
#define SB_CRYPT_MODE_OFB 	3
#define SB_CRYPT_MODE_CFB 	4
#define SB_CRYPT_MODE_CTS 	5
#define SB_ALG_CLASS_HASH 	32768
#define SB_ALG_CLASS_KEY_EXCHANGE 	40960
#define SB_ALG_CLASS_SIGNATURE 	8192
#define SB_ALG_CLASS_MSG_ENCRYPT 	16384
#define SB_ALG_TYPE_ANY 	0
#define SB_ALG_TYPE_DH 	2560
#define SB_ALG_TYPE_DSS 	512
#define SB_ALG_TYPE_RSA 	1024
#define SB_ALG_TYPE_SECURECHANNEL 	3072
#define SB_ALG_TYPE_GR3410 	3584
#define SB_ALG_SID_SSL3SHAMD5 	8
#define SB_ALG_SID_SHA1 	4
#define SB_ALG_SID_MD2 	1
#define SB_ALG_SID_MD4 	2
#define SB_ALG_SID_MD5 	3
#define SB_ALG_SID_MAC 	5
#define SB_CALG_SSL3_SHAMD5 	32776
#define SB_CALG_SHA1 	32772
#define SB_CALG_MAC 	32773
#define SB_CALG_MD2 	32769
#define SB_CALG_MD4 	32770
#define SB_CALG_MD5 	32771
#define SB_ALG_SID_AES 	17
#define SB_ALG_SID_AES_128 	14
#define SB_ALG_SID_AES_192 	15
#define SB_ALG_SID_AES_256 	16
#define SB_ALG_SID_SHA_256 	12
#define SB_ALG_SID_SHA_384 	13
#define SB_ALG_SID_SHA_512 	14
#define SB_ALG_SID_DH_EPHEM 	2
#define SB_ALG_SID_DSS_ANY 	0
#define SB_ALG_SID_RSA_ANY 	0
#define SB_ALG_SID_SHA 	4
#define SB_ALG_SID_ANY 	0
#define SB_ALG_SID_3DES_112 	9
#define SB_ALG_SID_DESX 	4
#define SB_ALG_SID_SEAL 	2
#define SB_ALG_SID_DH_SANDF 	1
#define SB_ALG_SID_AGREED_KEY_ANY 	3
#define SB_ALG_SID_KEA 	4
#define SB_ALG_SID_SKIPJACK 	10
#define SB_ALG_SID_TEK 	11
#define SB_ALG_SID_CYLINK_MEK 	12
#define SB_ALG_SID_SSL3_MASTER 	1
#define SB_ALG_SID_SCHANNEL_MASTER_HASH 	2
#define SB_ALG_SID_SCHANNEL_MAC_KEY 	3
#define SB_ALG_SID_SCHANNEL_ENC_KEY 	7
#define SB_ALG_SID_PCT1_MASTER 	4
#define SB_ALG_SID_SSL2_MASTER 	5
#define SB_ALG_SID_TLS1_MASTER 	6
#define SB_ALG_SID_RC5 	13
#define SB_ALG_SID_HMAC 	9
#define SB_ALG_SID_TLS1PRF 	10
#define SB_ALG_SID_HASH_REPLACE_OWF 	11
#define SB_ALG_SID_GR3411 	30
#define SB_ALG_SID_GR3410 	30
#define SB_ALG_SID_GR3410EL 	35
#define SB_ALG_SID_G28147 	30
#define SB_ALG_SID_PRODIVERS 	38
#define SB_ALG_SID_PRO_EXP 	31
#define SB_CALG_3DES 	26115
#define SB_CALG_AES 	26129
#define SB_CALG_AES_128 	26126
#define SB_CALG_AES_192 	26127
#define SB_CALG_AES_256 	26128
#define SB_CALG_SHA_256 	32780
#define SB_CALG_SHA_384 	32781
#define SB_CALG_SHA_512 	32782
#define SB_CALG_DH_EPHEM 	43522
#define SB_CALG_DSS_SIGN 	8704
#define SB_CALG_RSA_KEYX 	41984
#define SB_CALG_RSA_SIGN 	9216
#define SB_CALG_SHA 	32772
#define SB_CALG_NO_SIGN 	8192
#define SB_CALG_3DES_112 	26121
#define SB_CALG_DESX 	26116
#define SB_CALG_SEAL 	26626
#define SB_CALG_DH_SF 	43521
#define SB_CALG_AGREEDKEY_ANY 	43523
#define SB_CALG_KEA_KEYX 	43524
#define SB_CALG_HUGHES_MD5 	40963
#define SB_CALG_SKIPJACK 	26122
#define SB_CALG_TEK 	26123
#define SB_CALG_CYLINK_MEK 	26124
#define SB_CALG_SSL3_MASTER 	19457
#define SB_CALG_SCHANNEL_MASTER_HASH 	19458
#define SB_CALG_SCHANNEL_MAC_KEY 	19459
#define SB_CALG_SCHANNEL_ENC_KEY 	19463
#define SB_CALG_PCT1_MASTER 	19460
#define SB_CALG_SSL2_MASTER 	19461
#define SB_CALG_TLS1_MASTER 	19462
#define SB_CALG_RC5 	26125
#define SB_CALG_HMAC 	32777
#define SB_CALG_TLS1PRF 	32778
#define SB_CALG_HASH_REPLACE_OWF 	32779
#define SB_CALG_ECDH 	43525
#define SB_CALG_ECDSA 	8707
#define SB_CALG_GR3411 	32798
#define SB_CALG_GR3410 	11806
#define SB_CALG_GR3410EL 	11811
#define SB_CALG_G28147 	26142
#define SB_CALG_PRO_DIVERS 	26150
#define SB_CALG_PRO_EXPORT 	26143
#define SB_HP_HASHSIZE 	4
#define SB_HP_HASHVAL 	2
#define SB_HP_HMAC_INFO 	5
#define SB_KP_KEYLEN 	9
#define SB_KP_ALGID 	7
#define SB_KP_BLOCKLEN 	8
#define SB_KP_PERMISSIONS 	6
#define SB_KP_CERTIFICATE 	26
#define SB_CRYPT_E_UNEXPECTED_MSG_TYPE 	2148081674
#define SB__NTE_BAD_ALGID 	2148073480
#define SB_CRYPT_E_NO_DECRYPT_CERT 	2148081676
#define SB_CRYPT_IPSEC_HMAC_KEY 	256
#define SB_NTE_BAD_SIGNATURE 	2148073478
#define SB_NTE_INVALID_HANDLE 	2148073510
#define SB_PP_ENUMALGS 	1
#define SB_PP_ENUMCONTAINERS 	2
#define SB_PP_KEYEXCHANGE_PIN 	32
#define SB_PP_SIGNATURE_PIN 	33
#define SB_CRYPT_FIRST 	1
#define SB_CRYPT_NEXT 	2
#define SB_CRYPT_EXPORTABLE 	1
#define SB_CRYPT_USER_PROTECTED 	2
#define SB_CRYPT_NO_SALT 	16
#define SB_CRYPT_VERIFYCONTEXT 	4026531840
#define SB_PROV_RSA 	1
#define SB_PROV_DSS 	3
#define SB_PROV_SSL 	6
#define SB_PROV_RSA_SCHANNEL 	12
#define SB_PROV_RSA_SIG 	2
#define SB_PROV_DSS_DH 	13
#define SB_PROV_DH_SCHANNEL 	18
#define SB_PROV_RSA_AES 	24
#define SB_PROV_RSA_FULL 	1
#define SB_PROV_EC_ECDSA_SIG 	14
#define SB_PROV_EC_ECNRA_SIG 	15
#define SB_PROV_EC_ECDSA_FULL 	16
#define SB_PROV_EC_ECNRA_FULL 	17
#define SB_PROV_GOST_94_DH 	71
#define SB_PROV_GOST_2001_DH 	75
#define SB_CRYPT_NEWKEYSET 	8
#define SB_CRYPT_MACHINE_KEYSET 	32
#define SB_CRYPT_DELETEKEYSET 	16
#define SB_CERT_KEY_PROV_HANDLE_PROP_ID 	1
#define SB_CERT_STORE_PROV_MSG 	1
#define SB_CERT_STORE_PROV_MEMORY 	2
#define SB_CERT_STORE_PROV_FILE 	3
#define SB_CERT_STORE_PROV_REG 	4
#define SB_CERT_STORE_PROV_PKCS7 	5
#define SB_CERT_STORE_PROV_SERIALIZED 	6
#define SB_CERT_STORE_PROV_FILENAME_A 	7
#define SB_CERT_STORE_PROV_FILENAME_W 	8
#define SB_CERT_STORE_PROV_FILENAME 	8
#define SB_CERT_STORE_PROV_SYSTEM_A 	9
#define SB_CERT_STORE_PROV_SYSTEM_W 	10
#define SB_CERT_STORE_PROV_SYSTEM 	10
#define SB_CERT_STORE_PROV_LDAP_W 	16
#define SB_CERT_STORE_PROV_LDAP 	16
#define SB_CRYPT_MACHINE_DEFAULT 	1
#define SB_CRYPT_USER_DEFAULT 	2
#define SB_PP_NAME 	4
#define SB_MS_DEF_PROV 	"Microsoft Base Cryptographic Provider v1.0"
#define SB_MS_ENHANCED_PROV 	"Microsoft Enhanced Cryptographic Provider v1.0"
#define SB_MS_ENH_DSS_DH_PROV 	"Microsoft Enhanced DSS and Diffie-Hellman Cryptographic Provider"
#define SB_MS_DEF_RSA_SIG_PROV 	"Microsoft RSA Signature Cryptographic Provider"
#define SB_MS_DEF_RSA_SCHANNEL_PROV 	"Microsoft RSA SChannel Cryptographic Provider"
#define SB_MS_ENHANCED_RSA_SCHANNEL_PROV 	"Microsoft Enhanced RSA SChannel Cryptographic Provider"
#define SB_MS_DEF_DSS_PROV 	"Microsoft Base DSS Cryptographic Provider"
#define SB_MS_DEF_DSS_DH_PROV 	"Microsoft Base DSS and Diffie-Hellman Cryptographic Provider"
#define SB_MS_ENH_RSA_AES_PROV 	"Microsoft Enhanced RSA and AES Cryptographic Provider"
#define SB_MS_ENH_RSA_AES_PROV_XP 	"Microsoft Enhanced RSA and AES Cryptographic Provider (Prototype)"
#define SB_MS_SCARD_PROV 	"Microsoft Base Smart Card Crypto Provider"
#define SB_MS_STRONG_PROV 	"Microsoft Strong Cryptographic Provider"
#define SB_MS_DEF_DH_SCHANNEL_PROV 	"Microsoft DH SChannel Cryptographic Provider"
#define SB_CP_GR3410_94_PROV 	"Crypto-Pro GOST R 34.10-94 Cryptographic Service Provider"
#define SB_CP_GR3410_2001_PROV 	"Crypto-Pro GOST R 34.10-2001 Cryptographic Service Provider"
#define SB_BCRYPT_SHA1_ALGORITHM 	"SHA1"
#define SB_BCRYPT_SHA256_ALGORITHM 	"SHA256"
#define SB_BCRYPT_SHA384_ALGORITHM 	"SHA384"
#define SB_BCRYPT_SHA512_ALGORITHM 	"SHA512"
#define SB_BCRYPT_MD2_ALGORITHM 	"MD2"
#define SB_BCRYPT_MD5_ALGORITHM 	"MD5"
#define SB_BCRYPT_ECDSA_PUBLIC_P256_MAGIC 	827540293
#define SB_BCRYPT_ECDSA_PUBLIC_P384_MAGIC 	861094725
#define SB_BCRYPT_ECDSA_PUBLIC_P521_MAGIC 	894649157
#define SB_BCRYPT_ECCPUBLIC_BLOB 	"ECCPUBLICBLOB"
#define SB_BCRYPT_PAD_NONE 	1
#define SB_BCRYPT_PAD_PKCS1 	2
#define SB_BCRYPT_PAD_OAEP 	4
#define SB_BCRYPT_PAD_PSS 	8
#define SB_NCRYPT_PAD_PKCS1_FLAG 	2
#define SB_NCRYPT_ALLOW_DECRYPT_FLAG 	1
#define SB_NCRYPT_ALLOW_SIGNING_FLAG 	2

typedef Pointer HCRYPTOIDFUNCADDR;

typedef Pointer HCERTSTOREPROV;

#pragma pack(8)
typedef struct 
{
	uint32_t cbData;
#ifdef CPU64
	int32_t _dummy0;
#endif
	uint8_t * pbData;
} CRYPTOAPI_BLOB, * PCRYPTOAPI_BLOB, * PCRYPT_INTEGER_BLOB, * PCRYPT_UINT_BLOB, * PCRYPT_OBJID_BLOB, * PCERT_NAME_BLOB, * PCERT_RDN_VALUE_BLOB, * PCERT_BLOB, * PCRL_BLOB, * PDATA_BLOB, * PCRYPT_DATA_BLOB, * PCRYPT_HASH_BLOB, * PCRYPT_DIGEST_BLOB, * PCRYPT_DER_BLOB, * PCRYPT_ATTR_BLOB;

typedef CRYPTOAPI_BLOB CRYPT_INTEGER_BLOB;

typedef CRYPTOAPI_BLOB CRYPT_UINT_BLOB;

typedef CRYPTOAPI_BLOB CRYPT_OBJID_BLOB;

typedef CRYPTOAPI_BLOB CERT_NAME_BLOB;

typedef CRYPTOAPI_BLOB CERT_RDN_VALUE_BLOB;

typedef CRYPTOAPI_BLOB CERT_BLOB;

typedef CRYPTOAPI_BLOB CRL_BLOB;

typedef CRYPTOAPI_BLOB DATA_BLOB;

typedef CRYPTOAPI_BLOB CRYPT_DATA_BLOB;

typedef CRYPTOAPI_BLOB CRYPT_HASH_BLOB;

typedef CRYPTOAPI_BLOB CRYPT_DIGEST_BLOB;

typedef CRYPTOAPI_BLOB CRYPT_DER_BLOB;

typedef CRYPTOAPI_BLOB CRYPT_ATTR_BLOB;

#pragma pack(8)
typedef struct 
{
	uint32_t cbData;
#ifdef CPU64
	int32_t _dummy0;
#endif
	uint8_t * pbData;
	uint32_t cUnusedBits;
} CRYPT_BIT_BLOB, * PCRYPT_BIT_BLOB;

#pragma pack(8)
typedef struct 
{
	char * pszObjId;
	CRYPTOAPI_BLOB Parameters;
} CRYPT_ALGORITHM_IDENTIFIER, * PCRYPT_ALGORITHM_IDENTIFIER;

#pragma pack(8)
typedef struct 
{
	CRYPT_ALGORITHM_IDENTIFIER Algorithm;
	CRYPT_BIT_BLOB PublicKey;
} CERT_PUBLIC_KEY_INFO, * PCERT_PUBLIC_KEY_INFO;

#pragma pack(8)
typedef struct 
{
	char * pszObjId;
	int32_t fCritical;
	CRYPTOAPI_BLOB Value;
} CERT_EXTENSION, * PCERT_EXTENSION;

#pragma pack(8)
typedef struct 
{
	uint32_t dwVersion;
	CRYPTOAPI_BLOB SerialNumber;
	CRYPT_ALGORITHM_IDENTIFIER SignatureAlgorithm;
	CRYPTOAPI_BLOB Issuer;
	windows_FILETIME NotBefore;
	windows_FILETIME NotAfter;
	CRYPTOAPI_BLOB Subject;
	CERT_PUBLIC_KEY_INFO SubjectPublicKeyInfo;
	CRYPT_BIT_BLOB IssuerUniqueId;
	CRYPT_BIT_BLOB SubjectUniqueId;
	uint32_t cExtension;
#ifdef CPU64
	int32_t _dummy0;
#endif
	PCERT_EXTENSION rgExtension;
} CERT_INFO, * PCERT_INFO;

typedef Pointer PVOID;

typedef PChar LPAWSTR;

typedef Pointer HCERTSTORE;

#pragma pack(8)
typedef struct 
{
	uint32_t dwCertEncodingType;
#ifdef CPU64
	int32_t _dummy0;
#endif
	uint8_t * pbCertEncoded;
	uint32_t cbCertEncoded;
#ifdef CPU64
	int32_t _dummy1;
#endif
	PCERT_INFO pCertInfo;
	void * hCertStore;
} CERT_CONTEXT, * PCERT_CONTEXT, * PCCERT_CONTEXT;

#pragma pack(8)
typedef struct 
{
	uint32_t dwSize;
	uint32_t hwndParent;
	uint32_t dwFlags;
#ifdef CPU64
	int32_t _dummy0;
#endif
	sb_char16_t * szTitle;
	PCCERT_CONTEXT pCertContext;
	char * rgszPurposes;
	uint32_t cPurposes;
#ifdef CPU64
	int32_t _dummy1;
#endif
	void * Union;
	int32_t fpCryptProviderDataTrustedUsage;
	uint32_t idxSigner;
	uint32_t idxCert;
	int32_t fCounterSigner;
	uint32_t idxCounterSigner;
	uint32_t cStores;
	void * (* rghStores);
	uint32_t cPropSheetPages;
#ifdef CPU64
	int32_t _dummy2;
#endif
	void * rgPropSheetPages;
	uint32_t nStartPage;
} CRYPTUI_VIEWCERTIFICATE_STRUCT, * PCRYPTUI_VIEWCERTIFICATE_STRUCT, * PCCRYPTUI_VIEWCERTIFICATE_STRUCT;

#pragma pack(8)
typedef struct 
{
	uint32_t dwSize;
	uint32_t hwndParent;
	uint32_t dwFlags;
#ifdef CPU64
	int32_t _dummy0;
#endif
	sb_char16_t * szTitle;
	uint32_t dwDontUseColumn;
#ifdef CPU64
	int32_t _dummy1;
#endif
	sb_char16_t * szDisplayString;
	void * pFilterCallback;
	void * pDisplayCallback;
	void * pvCallbackData;
	uint32_t cDisplayStores;
#ifdef CPU64
	int32_t _dummy2;
#endif
	void * (* rghDisplayStores);
	uint32_t cStores;
#ifdef CPU64
	int32_t _dummy3;
#endif
	void * (* rghStores);
	uint32_t cPropSheetPages;
#ifdef CPU64
	int32_t _dummy4;
#endif
	void * rgPropSheetPages;
	void * hSelectedCertStore;
} CRYPTUI_SELECTCERTIFICATE_STRUCT, * PCRYPTUI_SELECTCERTIFICATE_STRUCT, * PCCRYPTUI_SELECTCERTIFICATE_STRUCT;

#ifndef CPU64
typedef uint32_t * PHCRYPTPROV;
#else
typedef uint64_t * PHCRYPTPROV;
#endif

#ifndef CPU64
typedef uint32_t * PHCRYPTKEY;
#else
typedef uint64_t * PHCRYPTKEY;
#endif

#ifndef CPU64
typedef uint32_t * PHCRYPTHASH;
#else
typedef uint64_t * PHCRYPTHASH;
#endif

#pragma pack(8)
typedef struct 
{
	uint32_t cbSize;
} _CERT_SYSTEM_STORE_INFO, * PCERT_SYSTEM_STORE_INFO;

typedef _CERT_SYSTEM_STORE_INFO CERT_SYSTEM_STORE_INFO;

typedef _CERT_SYSTEM_STORE_INFO TCertSystemStoreInfo;

#pragma pack(8)
typedef struct 
{
	sb_char16_t * pwszContainerName;
	sb_char16_t * pwszProvName;
	uint32_t dwProvType;
	uint32_t dwFlags;
	uint32_t cProvParam;
#ifdef CPU64
	int32_t _dummy0;
#endif
	void * rgProvParam;
	uint32_t dwKeySpec;
} _CRYPT_KEY_PROV_INFO, * PCRYPT_KEY_PROV_INFO;

typedef _CRYPT_KEY_PROV_INFO CRYPT_KEY_PROV_INFO;

#pragma pack(8)
typedef struct 
{
	char * pszObjId;
	uint32_t cValue;
#ifdef CPU64
	int32_t _dummy0;
#endif
	PCRYPT_ATTR_BLOB rgValue;
} _CRYPT_ATTRIBUTE, * PCRYPT_ATTRIBUTE;

typedef _CRYPT_ATTRIBUTE CRYPT_ATTRIBUTE;

#pragma pack(8)
typedef struct 
{
	uint32_t cbSize;
	uint32_t dwMsgEncodingType;
	PCCERT_CONTEXT pSigningCert;
	CRYPT_ALGORITHM_IDENTIFIER HashAlgorithm;
#ifdef CPU64
	int32_t _dummy0;
#endif
	void * pvHashAuxInfo;
	uint32_t cMsgCert;
#ifdef CPU64
	int32_t _dummy1;
#endif
	PCCERT_CONTEXT (* rgpMsgCert);
	uint32_t cMsgCrl;
#ifdef CPU64
	int32_t _dummy2;
#endif
	PCCERT_CONTEXT (* rgpMsgCrl);
	uint32_t cAuthAttr;
#ifdef CPU64
	int32_t _dummy3;
#endif
	PCRYPT_ATTRIBUTE rgAuthAttr;
	uint32_t cUnauthAttr;
#ifdef CPU64
	int32_t _dummy4;
#endif
	PCRYPT_ATTRIBUTE rgUnauthAttr;
	uint32_t dwFlags;
	uint32_t dwInnerContentType;
	CRYPT_ALGORITHM_IDENTIFIER HashEncryptionAlgorithm;
#ifdef CPU64
	int32_t _dummy5;
#endif
	void * pvHashEncryptionAuxInfo;
} _CRYPT_SIGN_MESSAGE_PARA, * PCRYPT_SIGN_MESSAGE_PARA;

typedef _CRYPT_SIGN_MESSAGE_PARA CRYPT_SIGN_MESSAGE_PARA;

#pragma pack(8)
typedef struct 
{
	uint32_t cbSize;
	uint32_t dwMsgAndCertEncodingType;
	uint32_t cCertStore;
#ifdef CPU64
	int32_t _dummy0;
#endif
	void * (* rghCertStore);
} _CRYPT_DECRYPT_MESSAGE_PARA, * PCRYPT_DECRYPT_MESSAGE_PARA;

typedef _CRYPT_DECRYPT_MESSAGE_PARA CRYPT_DECRYPT_MESSAGE_PARA;

#pragma pack(8)
typedef struct 
{
	uint32_t aiAlgId;
	uint32_t dwBitLen;
	uint32_t dwNameLen;
	char szName[20];
} _PROV_ENUMALGS, * PPROV_ENUMALGS;

typedef _PROV_ENUMALGS PROV_ENUMALGS;

#pragma pack(8)
typedef struct 
{
	char * pszOID;
	void * pvFuncAddr;
} _CRYPT_OID_FUNC_ENTRY, * PCRYPT_OID_FUNC_ENTRY;

typedef _CRYPT_OID_FUNC_ENTRY CRYPT_OID_FUNC_ENTRY;

#pragma pack(8)
typedef struct 
{
	uint32_t cbSize;
	uint32_t cStoreProvFunc;
	void * rgpvStoreProvFunc;
	void * hStoreProv;
	uint32_t dwStoreProvFlags;
#ifdef CPU64
	int32_t _dummy0;
#endif
	void * hStoreProvFuncAddr2;
} _CERT_STORE_PROV_INFO, * PCERT_STORE_PROV_INFO;

typedef _CERT_STORE_PROV_INFO CERT_STORE_PROV_INFO;

typedef void (SB_CALLBACK *PFN_CERT_ENUM_SYSTEM_STORE)(void * pvSystemStore, uint32_t dwFlags, PCERT_SYSTEM_STORE_INFO pStoreInfo, void * pvReserved, void * pvArg, int32_t * OutResult);

typedef PFN_CERT_ENUM_SYSTEM_STORE PfnCertEnumSystemStore;

typedef void (SB_CALLBACK *TCertEnumSystemStore)(uint32_t dwFlags, void * pvSystemStoreLocationPara, void * pvArg, PFN_CERT_ENUM_SYSTEM_STORE pfnEnum, int32_t * OutResult);

typedef void (SB_CALLBACK *PFN_CERT_ENUM_PHYSICAL_STORE)(void * pvSystemStore, uint32_t dwFlags, sb_char16_t * pwszStoreName, PCERT_SYSTEM_STORE_INFO pStoreInfo, void * pvReserver, void * pvArg, int32_t * OutResult);

typedef void (SB_CALLBACK *TCertEnumPhysicalStore)(void * pvSystemStore, uint32_t dwFlags, void * pvArg, PFN_CERT_ENUM_PHYSICAL_STORE pfnEnum, int32_t * OutResult);

typedef void (SB_CALLBACK *TCryptSignMessage)(PCRYPT_SIGN_MESSAGE_PARA pSignPara, int32_t fDetachedSignature, uint32_t cToBeSigned, const uint8_t * (* rgpbToBeSigned), uint32_t * rgcbToBeSigned, uint8_t * pbSignedBlob, uint32_t * pcbSignedBlob, int32_t * OutResult);

typedef void (SB_CALLBACK *TCryptFindLocalizedName)(const sb_char16_t * pwszCryptName, sb_char16_t * (* OutResult));

#ifndef CPU64
typedef void (SB_CALLBACK *TCryptAcquireCertificatePrivateKey)(PCCERT_CONTEXT pCert, uint32_t dwFlags, void * pvReserved, uint32_t * phCryptProv, uint32_t * pdwKeySpec, int32_t * pfCallerFreeProv, int32_t * OutResult);
#else
typedef void (SB_CALLBACK *TCryptAcquireCertificatePrivateKey)(PCCERT_CONTEXT pCert, uint32_t dwFlags, void * pvReserved, uint64_t * phCryptProv, uint32_t * pdwKeySpec, int32_t * pfCallerFreeProv, int32_t * OutResult);
#endif

typedef Pointer PLPSTR;

typedef Pointer PPCERT_INFO;

typedef Pointer PPVOID;

typedef Pointer PPCCTL_CONTEXT;

typedef Pointer PPCCRL_CONTEXT;

typedef Pointer HCRYPTMSG;

#pragma pack(8)
typedef struct 
{
	uint32_t cUsageIdentifier;
#ifdef CPU64
	int32_t _dummy0;
#endif
	void * rgpszUsageIdentifier;
} CTL_USAGE, * PCTL_USAGE;

#pragma pack(8)
typedef struct 
{
	CRYPTOAPI_BLOB SubjectIdentifier;
	uint32_t cAttribute;
#ifdef CPU64
	int32_t _dummy0;
#endif
	PCRYPT_ATTRIBUTE rgAttribute;
} CTL_ENTRY, * PCTL_ENTRY;

#pragma pack(8)
typedef struct 
{
	CRYPTOAPI_BLOB SerialNumber;
	windows_FILETIME RevocationDate;
	uint32_t cExtension;
#ifdef CPU64
	int32_t _dummy0;
#endif
	PCERT_EXTENSION rgExtension;
} CRL_ENTRY, * PCRL_ENTRY;

#pragma pack(8)
typedef struct 
{
	uint32_t dwVersion;
	CTL_USAGE SubjectUsage;
	CRYPTOAPI_BLOB ListIdentifier;
	CRYPTOAPI_BLOB SequenceNumber;
	windows_FILETIME ThisUpdate;
	windows_FILETIME NextUpdate;
	CRYPT_ALGORITHM_IDENTIFIER SubjectAlgorithm;
	uint32_t cCTLEntry;
#ifdef CPU64
	int32_t _dummy0;
#endif
	PCTL_ENTRY rgCTLEntry;
	uint32_t cExtension;
#ifdef CPU64
	int32_t _dummy1;
#endif
	PCERT_EXTENSION rgExtension;
} CTL_INFO, * PCTL_INFO;

#pragma pack(8)
typedef struct 
{
	uint32_t dwVersion;
	CRYPT_ALGORITHM_IDENTIFIER SignatureAlgorithm;
	CRYPTOAPI_BLOB Issuer;
	windows_FILETIME ThisUpdate;
	windows_FILETIME NextUpdate;
	uint32_t cCRLEntry;
#ifdef CPU64
	int32_t _dummy0;
#endif
	PCRL_ENTRY rgCRLEntry;
	uint32_t cExtension;
#ifdef CPU64
	int32_t _dummy1;
#endif
	PCERT_EXTENSION rgExtension;
} CRL_INFO, * PCRL_INFO;

#pragma pack(8)
typedef struct 
{
	uint32_t dwCertEncodingType;
#ifdef CPU64
	int32_t _dummy0;
#endif
	uint8_t * pbCrlEncoded;
	uint32_t cbCrlEncoded;
#ifdef CPU64
	int32_t _dummy1;
#endif
	PCRL_INFO pCrlInfo;
	void * hCertStore;
} CRL_CONTEXT, * PCRL_CONTEXT, * PCCRL_CONTEXT;

#pragma pack(8)
typedef struct 
{
	uint32_t dwMsgAndCertEncodingType;
#ifdef CPU64
	int32_t _dummy0;
#endif
	uint8_t * pbCtlEncoded;
	uint32_t cbCtlEncoded;
#ifdef CPU64
	int32_t _dummy1;
#endif
	PCTL_INFO pCtlInfo;
	void * hCertStore;
	void * hCryptMsg;
	uint8_t * pbCtlContent;
	uint32_t cbCtlContent;
} CTL_CONTEXT, * PCTL_CONTEXT, * PCCTL_CONTEXT;

#pragma pack(8)
typedef struct 
{
	uint32_t cbSize;
	uint32_t dwMsgAndCertEncodingType;
	uint32_t dwFindFlags;
	uint32_t dwFindType;
	void * pvFindPara;
} CERT_STORE_PROV_FIND_INFO, * PCERT_STORE_PROV_FIND_INFO, * PCCERT_STORE_PROV_FIND_INFO;

typedef CERT_STORE_PROV_FIND_INFO CCERT_STORE_PROV_FIND_INFO;

#pragma pack(8)
typedef struct 
{
	uint32_t Data1;
	uint16_t Data2;
	uint16_t Data3;
	uint8_t Data4[8];
} SBWinCrypt__GUID, * PGUID;

typedef SBWinCrypt__GUID SBWinCrypt_GUID;

#pragma pack(8)
typedef struct 
{
	uint32_t HashAlgid;
#ifdef CPU64
	int32_t _dummy0;
#endif
	uint8_t * pbInnerString;
	uint32_t cbInnerString;
#ifdef CPU64
	int32_t _dummy1;
#endif
	uint8_t * pbOuterString;
	uint32_t cbOuterString;
} HMAC_INFO;

typedef uint32_t * SBWinCrypt_ULONG_PTR;

typedef SBWinCrypt_ULONG_PTR NCRYPT_HANDLE;

typedef SBWinCrypt_ULONG_PTR NCRYPT_PROV_HANDLE;

typedef SBWinCrypt_ULONG_PTR NCRYPT_KEY_HANDLE;

typedef SBWinCrypt_ULONG_PTR NCRYPT_HASH_HANDLE;

typedef SBWinCrypt_ULONG_PTR NCRYPT_SECRET_HANDLE;

#pragma pack(8)
typedef struct 
{
	uint32_t cbBuffer;
	uint32_t BufferType;
	void * pvBuffer;
} NCryptBuffer, * PNCryptBuffer;

#pragma pack(8)
typedef struct 
{
	uint32_t ulVersion;
	uint32_t cBuffers;
	PNCryptBuffer pBuffers;
} NCryptBufferDesc, * PNCryptBufferDesc;

#pragma pack(8)
typedef struct 
{
	sb_char16_t * pszName;
	uint32_t dwClass;
	uint32_t dwAlgOperations;
	uint32_t dwFlags;
} NCryptAlgorithmName, * PNCryptAlgorithmName;

#pragma pack(8)
typedef struct 
{
	sb_char16_t * pszName;
	sb_char16_t * pszAlgid;
	uint32_t dwLegacyKeySpec;
	uint32_t dwFlags;
} NCryptKeyName, * PNCryptKeyName;

#pragma pack(8)
typedef struct 
{
	sb_char16_t * pszName;
	sb_char16_t * pszComment;
} NCryptProviderName, * PNCryptProviderName;

#pragma pack(8)
typedef struct 
{
	sb_char16_t * pszAlgId;
} BCRYPT_PKCS1_PADDING_INFO;

typedef uint8_t * (* PPBYTE);

typedef void * (* PHCERTSTORE);

typedef PCCERT_CONTEXT (* PPCCERT_CONTEXT);

typedef PCERT_SYSTEM_STORE_INFO PCertSystemStoreInfo;

typedef uint32_t * (* PNCRYPT_HANDLE);

typedef uint32_t * (* PNCRYPT_PROV_HANDLE);

typedef uint32_t * (* PNCRYPT_KEY_HANDLE);

typedef uint32_t * (* PNCRYPT_HASH_HANDLE);

typedef uint32_t * (* PNCRYPT_SECRET_HANDLE);

typedef PNCryptAlgorithmName (* PPNCryptAlgorithmName);

typedef PNCryptKeyName (* PPNCryptKeyName);

typedef PNCryptProviderName (* PPNCryptProviderName);

typedef void * (* SBWinCrypt_PPointer);
#endif

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef SB_WINDOWS
extern zend_class_entry *CRYPTOAPI_BLOB_ce_ptr;
extern zend_class_entry *CRYPT_BIT_BLOB_ce_ptr;
extern zend_class_entry *CRYPT_ALGORITHM_IDENTIFIER_ce_ptr;
extern zend_class_entry *CERT_PUBLIC_KEY_INFO_ce_ptr;
extern zend_class_entry *CERT_EXTENSION_ce_ptr;
extern zend_class_entry *CERT_INFO_ce_ptr;
extern zend_class_entry *CERT_CONTEXT_ce_ptr;
extern zend_class_entry *CRYPTUI_VIEWCERTIFICATE_STRUCT_ce_ptr;
extern zend_class_entry *CRYPTUI_SELECTCERTIFICATE_STRUCT_ce_ptr;
extern zend_class_entry *_CERT_SYSTEM_STORE_INFO_ce_ptr;
extern zend_class_entry *_CRYPT_KEY_PROV_INFO_ce_ptr;
extern zend_class_entry *_CRYPT_ATTRIBUTE_ce_ptr;
extern zend_class_entry *_CRYPT_SIGN_MESSAGE_PARA_ce_ptr;
extern zend_class_entry *_CRYPT_DECRYPT_MESSAGE_PARA_ce_ptr;
extern zend_class_entry *_PROV_ENUMALGS_ce_ptr;
extern zend_class_entry *_CRYPT_OID_FUNC_ENTRY_ce_ptr;
extern zend_class_entry *_CERT_STORE_PROV_INFO_ce_ptr;
extern zend_class_entry *CTL_USAGE_ce_ptr;
extern zend_class_entry *CTL_ENTRY_ce_ptr;
extern zend_class_entry *CRL_ENTRY_ce_ptr;
extern zend_class_entry *CTL_INFO_ce_ptr;
extern zend_class_entry *CRL_INFO_ce_ptr;
extern zend_class_entry *CRL_CONTEXT_ce_ptr;
extern zend_class_entry *CTL_CONTEXT_ce_ptr;
extern zend_class_entry *CERT_STORE_PROV_FIND_INFO_ce_ptr;
extern zend_class_entry *SBWinCrypt__GUID_ce_ptr;
extern zend_class_entry *HMAC_INFO_ce_ptr;
extern zend_class_entry *NCryptBuffer_ce_ptr;
extern zend_class_entry *NCryptBufferDesc_ce_ptr;
extern zend_class_entry *NCryptAlgorithmName_ce_ptr;
extern zend_class_entry *NCryptKeyName_ce_ptr;
extern zend_class_entry *NCryptProviderName_ce_ptr;
extern zend_class_entry *BCRYPT_PKCS1_PADDING_INFO_ce_ptr;

void Register_CRYPTOAPI_BLOB(TSRMLS_D);
void Register_CRYPT_BIT_BLOB(TSRMLS_D);
void Register_CRYPT_ALGORITHM_IDENTIFIER(TSRMLS_D);
void Register_CERT_PUBLIC_KEY_INFO(TSRMLS_D);
void Register_CERT_EXTENSION(TSRMLS_D);
void Register_CERT_INFO(TSRMLS_D);
void Register_CERT_CONTEXT(TSRMLS_D);
void Register_CRYPTUI_VIEWCERTIFICATE_STRUCT(TSRMLS_D);
void Register_CRYPTUI_SELECTCERTIFICATE_STRUCT(TSRMLS_D);
void Register__CERT_SYSTEM_STORE_INFO(TSRMLS_D);
void Register__CRYPT_KEY_PROV_INFO(TSRMLS_D);
void Register__CRYPT_ATTRIBUTE(TSRMLS_D);
void Register__CRYPT_SIGN_MESSAGE_PARA(TSRMLS_D);
void Register__CRYPT_DECRYPT_MESSAGE_PARA(TSRMLS_D);
void Register__PROV_ENUMALGS(TSRMLS_D);
void Register__CRYPT_OID_FUNC_ENTRY(TSRMLS_D);
void Register__CERT_STORE_PROV_INFO(TSRMLS_D);
void Register_CTL_USAGE(TSRMLS_D);
void Register_CTL_ENTRY(TSRMLS_D);
void Register_CRL_ENTRY(TSRMLS_D);
void Register_CTL_INFO(TSRMLS_D);
void Register_CRL_INFO(TSRMLS_D);
void Register_CRL_CONTEXT(TSRMLS_D);
void Register_CTL_CONTEXT(TSRMLS_D);
void Register_CERT_STORE_PROV_FIND_INFO(TSRMLS_D);
void Register_SBWinCrypt__GUID(TSRMLS_D);
void Register_HMAC_INFO(TSRMLS_D);
void Register_NCryptBuffer(TSRMLS_D);
void Register_NCryptBufferDesc(TSRMLS_D);
void Register_NCryptAlgorithmName(TSRMLS_D);
void Register_NCryptKeyName(TSRMLS_D);
void Register_NCryptProviderName(TSRMLS_D);
void Register_BCRYPT_PKCS1_PADDING_INFO(TSRMLS_D);
void Register_SBWinCrypt_Constants(int module_number TSRMLS_DC);
void Register_SBWinCrypt_Aliases(TSRMLS_D);
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBWINCRYPT */
