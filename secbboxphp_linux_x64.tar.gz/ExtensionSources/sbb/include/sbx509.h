#ifndef __INC_SBX509
#define __INC_SBX509

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#ifdef SB_WINDOWS
#include "sbwincrypt.h"
#endif
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbencoding.h"
#include "sbmath.h"
#include "sbrdn.h"
#include "sbasn1.h"
#include "sbpem.h"
#include "sbhashfunction.h"
#include "sbpkiasync.h"
#include "sbx509ext.h"
#include "sbcustomcrypto.h"
#include "sbsymmetriccrypto.h"
#include "sbpublickeycrypto.h"
#include "sbalgorithmidentifier.h"
#include "sbcryptoprov.h"
#include "sbasn1tree.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ERROR_FACILITY_X509 	20480
#define SB_X509_ERROR_INVALID_PVK_FILE 	20481
#define SB_X509_ERROR_INVALID_PASSWORD 	20482
#define SB_X509_ERROR_NO_PRIVATE_KEY 	20483
#define SB_X509_ERROR_UNSUPPORTED_ALGORITHM 	20484
#define SB_X509_ERROR_INVALID_PRIVATE_KEY 	20485
#define SB_X509_ERROR_INTERNAL_ERROR 	20486
#define SB_X509_ERROR_BUFFER_TOO_SMALL 	20487
#define SB_X509_ERROR_NO_CERTIFICATE 	20488
#define SB_X509_ERROR_UNRECOGNIZED_FORMAT 	20489
#define SB_X509_ERROR_EMPTY_ISSUER 	20490
#define SB_X509_ERROR_EMPTY_SUBJECT 	20491
#define SB_X509_ERROR_BLOB_SIZE_TOO_SMALL 	20492
#define SB_X509_ERROR_INVALID_TBS_CERTIFICATE 	20493
#define SB_X509_ERROR_CERTIFICATE_TOO_LONG 	20494
#define SB_X509_ERROR_INVALID_KEY_MATERIAL 	20495
#define SB_X509_ERROR_INVALID_PUBKEY_PARAMS 	20496
#define SB_X509_ERROR_CANT_SET_FRIENDLY_NAME 	20497
#define SB_X509_ERROR_UNSUPPORTED_KEY_TYPE 	20498
#define SB_X509_ERROR_FAILED_TO_CLONE_CONTEXT 	20499
#define SB_X509_ERROR_PRIVATE_KEY_NONEXTRACTABLE 	20500
#define SB_BT_WINDOWS 	1
#define SB_BT_PKCS11 	2
#define SB_BT_WAB 	4
#define SB_BT_OUTLOOK 	8
#define SB_BT_FILE 	16
#define SB_BT_APPLE 	32
#define SB_sInvalidPVKFormat 	"Invalid file format (possibly not a PVK\?)"
#define SB_sIncorrectPassphrase 	"Incorrect password"
#define SB_sNotEnoughBufferSpace 	"Not enough buffer space"
#define SB_SInvalidtbsCert 	"Invalid certificate data"
#define SB_SPrivateKeyNotFound 	"Private key not found"
#define SB_SPrivateKeyNotExtractable 	"Private key not extractable"
#define SB_SInvalidPointer 	"Invalid pointer"
#define SB_SInvalidRequestSignature 	"Invalid request signature"
#define SB_SUnknownAlgorithm 	"Unknown algorithm"
#ifndef SB_SInternalError
#define SB_SInternalError 	"Internal Error. Please contact SecureBlackbox support for details."
#endif
#define SB_SNoCertificateFound 	"No certificate found"
#define SB_SInvalidCertificate 	"No X.509 certificate data found"
#define SB_SInvalidPrivateKey 	"No private key found"
#define SB_SInvalidAlgorithmIdentifier 	"Invalid algorithm identifier"
#define SB_SCertAlgorithmMismatch 	"Certificate algorithm mismatch"
#define SB_SInvalidPublicKeyAlgorithm 	"Invalid public key algorithm"
#define SB_SInvalidSignatureAlgorithm 	"Invalid signature algorithm"
#define SB_SCertIsNotBeingGenerated 	"Certificate is not being generated (use BeginGenerate() method)"
#define SB_SCertificateTooLong 	"Certificate is too long"
#define SB_SPublicKeyTooLong 	"Public key is too long"
#define SB_SInvalidPKCS15ASN1Data 	"Invalid PKCS#15 ASN.1 data"
#define SB_SInvalidPassword 	"Invalid password"
#define SB_SInvalidParameter 	"Invalid parameter"
#define SB_SInvalidPublicKey 	"Invalid public key"
#define SB_SFailedToSetFriendlyName 	"Failed to set certificate friendly name"
#define SB_SInvalidPublicKeyPar 	"Invalid or unsupported public key in certificate <%s>"
#define SB_SInvalidPublicKeyParInnEx 	"Invalid or unsupported public key in certificate <%s> (inner exception: %s)"
#define SB_SAlgorithmUnsupportedByCryptoProvider 	"Algorithm unsupported by the underlying cryptographic provider"

typedef TElClassHandle TElX509CertificateHandle;

typedef TElX509CertificateHandle ElX509CertificateHandle;

typedef TElClassHandle TElSubjectPublicKeyInfoHandle;

typedef TElSubjectPublicKeyInfoHandle ElSubjectPublicKeyInfoHandle;

typedef TElClassHandle TElTBSCertificateHandle;

typedef TElTBSCertificateHandle ElTBSCertificateHandle;

typedef TElClassHandle TElX509CertificateChainHandle;

typedef TElX509CertificateChainHandle ElX509CertificateChainHandle;

typedef TElClassHandle TElBaseCertStorageHandle;

typedef TElBaseCertStorageHandle ElBaseCertStorageHandle;

typedef uint8_t TSBCertificateValidityRaw;

typedef enum
{
	cvOk = 0,
	cvSelfSigned = 1,
	cvInvalid = 2,
	cvStorageError = 3,
	cvChainUnvalidated = 4
} TSBCertificateValidity;

typedef uint32_t TSBCertificateValidityReasonRaw;

typedef enum 
{
	f_vrBadData = 1,
	f_vrRevoked = 2,
	f_vrNotYetValid = 4,
	f_vrExpired = 8,
	f_vrInvalidSignature = 16,
	f_vrUnknownCA = 32,
	f_vrCAUnauthorized = 64,
	f_vrCRLNotVerified = 128,
	f_vrOCSPNotVerified = 256,
	f_vrIdentityMismatch = 512,
	f_vrNoKeyUsage = 1024,
	f_vrBlocked = 2048,
	f_vrFailure = 4096,
	f_vrChainLoop = 8192,
	f_vrWeakAlgorithm = 16384,
	f_vrUnused1 = 32768,
	f_vrUnused2 = 65536,
	f_vrUnused3 = 131072,
	f_vrUnused4 = 262144,
	f_vrUserEnforced = 524288
} TSBCertificateValidityReason;

typedef uint8_t TSBCertFileFormatRaw;

typedef enum
{
	cfUnknown = 0,
	cfDER = 1,
	cfPEM = 2,
	cfPFX = 3,
	cfSPC = 4
} TSBCertFileFormat;

typedef uint8_t TSBX509KeyFileFormatRaw;

typedef enum
{
	kffUnknown = 0,
	kffDER = 1,
	kffPEM = 2,
	kffPFX = 3,
	kffPVK = 4,
	kffNET = 5,
	kffPKCS8 = 6
} TSBX509KeyFileFormat;

typedef void (SB_CALLBACK *TSBCertificateValidateEvent)(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle X509Certificate, TSBCertificateValidityRaw * Validity, TSBCertificateValidityReasonRaw * Reason);

#pragma pack(8)
typedef struct 
{
	double NotBefore;
	double NotAfter;
} TValidity;

#pragma pack(8)
typedef struct 
{
	void * Country;
	void * StateOrProvince;
	void * Locality;
	void * Organization;
	void * OrganizationUnit;
	void * CommonName;
	void * EMailAddress;
} TName;

typedef uint8_t TSBCertSecurityLevelRaw;

typedef enum
{
	cslLow = 0,
	cslMedium = 1,
	cslHigh = 2
} TSBCertSecurityLevel;

typedef TElClassHandle TElX509CertificateClassHandle;

typedef TElX509CertificateClassHandle ElX509CertificateClassHandle;

#pragma pack(1)
typedef struct 
{
	uint32_t magic;
	uint32_t reserved;
	uint32_t keytype;
	uint32_t encrypted;
	uint32_t saltlen;
	uint32_t keylen;
} TPVKHeader;

#ifdef SB_USE_CLASS_TELX509CERTIFICATE
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_DetectCertFileFormat(const char * pcFileName, int32_t szFileName, TSBCertFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_DetectCertFileFormat_1(TElX509CertificateHandle _Handle, const char * pcFileName, int32_t szFileName, TSBCertFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_DetectCertFileFormat_2(TStreamHandle Stream, TSBCertFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_DetectCertFileFormat_3(TElX509CertificateHandle _Handle, TStreamHandle Stream, TSBCertFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_DetectCertFileFormat_4(void * Buffer, int32_t Size, TSBCertFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_DetectCertFileFormat_5(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size, TSBCertFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_DetectKeyFileFormat(TStreamHandle Stream, const char * pcPassword, int32_t szPassword, TSBX509KeyFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_DetectKeyFileFormat_1(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, TSBX509KeyFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_DetectKeyFileFormat_2(const char * pcFileName, int32_t szFileName, const char * pcPassword, int32_t szPassword, TSBX509KeyFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_DetectKeyFileFormat_3(TElX509CertificateHandle _Handle, const char * pcFileName, int32_t szFileName, const char * pcPassword, int32_t szPassword, TSBX509KeyFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_DetectKeyFileFormat_4(void * Buffer, int32_t Size, const char * pcPassword, int32_t szPassword, TSBX509KeyFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_DetectKeyFileFormat_5(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size, const char * pcPassword, int32_t szPassword, TSBX509KeyFileFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_Equals(TElX509CertificateHandle _Handle, TElX509CertificateHandle Other, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SameCertificate(TElX509CertificateHandle _Handle, TElX509CertificateHandle Other, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_Clone(TElX509CertificateHandle _Handle, TElX509CertificateHandle Dest, int8_t CopyPrivateKey);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_Clone_1(TElX509CertificateHandle _Handle, TElX509CertificateHandle Dest, TElCustomCryptoProviderHandle CryptoProvider);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_ChangeSecurityLevel(TElX509CertificateHandle _Handle, TSBCertSecurityLevelRaw Level, const char * pcPassword, int32_t szPassword);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_Invalidate(TElX509CertificateHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_KeyCorresponds(TElX509CertificateHandle _Handle, void * KeyBuffer, int32_t KeySize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadFromBuffer(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadFromBufferPEM(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size, const char * pcPassPhrase, int32_t szPassPhrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromBuffer(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromBufferPEM(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size, const char * pcPassPhrase, int32_t szPassPhrase, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadFromBufferPFX(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadFromBufferSPC(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromBufferMS(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromBufferPKCS8(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadFromBufferAuto(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromBufferAuto(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromBufferNET(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromBufferPVK(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromBufferPKCS15(TElX509CertificateHandle _Handle, void * Buffer, int32_t Size, const char * pcPassword, int32_t szPassword);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromStreamPKCS15(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadFromStream(TElX509CertificateHandle _Handle, TStreamHandle Stream, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromStream(TElX509CertificateHandle _Handle, TStreamHandle Stream, int32_t Count);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromStreamPEM(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassPhrase, int32_t szPassPhrase, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadFromStreamPEM(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassPhrase, int32_t szPassPhrase, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadFromStreamPFX(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadFromStreamSPC(TElX509CertificateHandle _Handle, TStreamHandle Stream, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromStreamMS(TElX509CertificateHandle _Handle, TStreamHandle Stream, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromStreamPKCS8(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromStreamPVK(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadFromStreamAuto(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromStreamAuto(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromStreamNET(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadFromFileAuto(TElX509CertificateHandle _Handle, const char * pcFilename, int32_t szFilename, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_LoadKeyFromFileAuto(TElX509CertificateHandle _Handle, const char * pcFilename, int32_t szFilename, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveToBuffer(TElX509CertificateHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToBuffer(TElX509CertificateHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveToBufferPEM(TElX509CertificateHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassPhrase, int32_t szPassPhrase, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToBufferPEM(TElX509CertificateHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassPhrase, int32_t szPassPhrase, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToBufferPEM_1(TElX509CertificateHandle _Handle, void * Buffer, int32_t * Size, int32_t EncryptionAlgorithm, TSBSymmetricCryptoModeRaw EncryptionMode, const char * pcPassPhrase, int32_t szPassPhrase, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveToBufferPFX(TElX509CertificateHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassword, int32_t szPassword, int32_t KeyEncryptionAlgorithm, int32_t CertEncryptionAlgorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveToBufferPFX_1(TElX509CertificateHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveToBufferSPC(TElX509CertificateHandle _Handle, void * Buffer, int32_t * Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToBufferMS(TElX509CertificateHandle _Handle, void * Buffer, int32_t * Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToBufferNET(TElX509CertificateHandle _Handle, void * Buffer, int32_t * Size, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToBufferPVK(TElX509CertificateHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassword, int32_t szPassword, int8_t UseStrongEncryption, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToBufferPKCS8(TElX509CertificateHandle _Handle, void * Buffer, int32_t * Size, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveToStream(TElX509CertificateHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToStream(TElX509CertificateHandle _Handle, TStreamHandle Stream);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveToStreamPEM(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassPhrase, int32_t szPassPhrase);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToStreamPEM(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassPhrase, int32_t szPassPhrase);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToStreamPEM_1(TElX509CertificateHandle _Handle, TStreamHandle Stream, int32_t EncryptionAlgorithm, TSBSymmetricCryptoModeRaw EncryptionMode, const char * pcPassPhrase, int32_t szPassPhrase);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveToStreamPFX(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t KeyEncryptionAlgorithm, int32_t CertEncryptionAlgorithm, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveToStreamPFX_1(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveToStreamSPC(TElX509CertificateHandle _Handle, TStreamHandle Stream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyValueToBuffer(TElX509CertificateHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToStreamMS(TElX509CertificateHandle _Handle, TStreamHandle Stream, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToStreamNET(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToStreamPVK(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int8_t UseStrongEncryption, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToStreamPKCS8(TElX509CertificateHandle _Handle, TStreamHandle Stream, const char * pcPassword, int32_t szPassword, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveToFile(TElX509CertificateHandle _Handle, const char * pcFilename, int32_t szFilename, const char * pcPassword, int32_t szPassword, TSBCertFileFormatRaw Format, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SaveKeyToFile(TElX509CertificateHandle _Handle, const char * pcFilename, int32_t szFilename, const char * pcPassword, int32_t szPassword, TSBX509KeyFileFormatRaw Format, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_Validate(TElX509CertificateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_ValidateWithCA(TElX509CertificateHandle _Handle, TElX509CertificateHandle CACertificate, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_GetRSAParams(TElX509CertificateHandle _Handle, void * RSAModulus, int32_t * RSAModulusSize, void * RSAPublicKey, int32_t * RSAPublicKeySize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_GetDSSParams(TElX509CertificateHandle _Handle, void * DSSP, int32_t * DSSPSize, void * DSSQ, int32_t * DSSQSize, void * DSSG, int32_t * DSSGSize, void * DSSY, int32_t * DSSYSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_GetDHParams(TElX509CertificateHandle _Handle, void * DHP, int32_t * DHPSize, void * DHG, int32_t * DHGSize, void * DHY, int32_t * DHYSize, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_GetPublicKeyBlob(TElX509CertificateHandle _Handle, void * Buffer, int32_t * Size, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_GetPublicKeyBlob_1(TElX509CertificateHandle _Handle, uint8_t pBuffer[], int32_t * szBuffer);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_GetFullPublicKeyInfo(TElX509CertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_GetHashMD5(TElX509CertificateHandle _Handle, TMessageDigest128 * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_GetHashSHA1(TElX509CertificateHandle _Handle, TMessageDigest160 * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_GetHashSHA256(TElX509CertificateHandle _Handle, TMessageDigest256 * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_GetKeyHashSHA1(TElX509CertificateHandle _Handle, TMessageDigest160 * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_GetKeyHashSHA256(TElX509CertificateHandle _Handle, TMessageDigest256 * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_GetCertificateHash(TElX509CertificateHandle _Handle, int32_t Alg, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_GetZIPCertIdentifier(TElX509CertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_GetPublicKeySize(TElX509CertificateHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_IsKeyValid(TElX509CertificateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_WriteSerialNumber(TElX509CertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_WriteExtensionSubjectKeyIdentifier(TElX509CertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_WriteSubject(TElX509CertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_WriteIssuer(TElX509CertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_SetKeyMaterial(TElX509CertificateHandle _Handle, TElPublicKeyMaterialHandle Value);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_View(TElX509CertificateHandle _Handle, uint32_t Owner, int8_t * OutResult);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_CertificateSize(TElX509CertificateHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_SignatureAlgorithm(TElX509CertificateHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_SignatureAlgorithmIdentifier(TElX509CertificateHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_Signature(TElX509CertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_Version(TElX509CertificateHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_Version(TElX509CertificateHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_SerialNumber(TElX509CertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_SerialNumber(TElX509CertificateHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_ValidFrom(TElX509CertificateHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_ValidFrom(TElX509CertificateHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_ValidTo(TElX509CertificateHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_ValidTo(TElX509CertificateHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_BelongsTo(TElX509CertificateHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_BelongsTo(TElX509CertificateHandle _Handle, int32_t Value);
#ifdef SB_WINDOWS
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_CertHandle(TElX509CertificateHandle _Handle, PCCERT_CONTEXT * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_CertHandle(TElX509CertificateHandle _Handle, PCCERT_CONTEXT Value);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_FriendlyName(TElX509CertificateHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_FriendlyName(TElX509CertificateHandle _Handle, const char * pcValue, int32_t szValue);
#endif
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_IssuerUniqueID(TElX509CertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_SubjectUniqueID(TElX509CertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_PublicKeyAlgorithm(TElX509CertificateHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_PublicKeyAlgorithmIdentifier(TElX509CertificateHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_PrivateKeyExists(TElX509CertificateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_PrivateKeyExtractable(TElX509CertificateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_CAAvailable(TElX509CertificateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_CAAvailable(TElX509CertificateHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_SelfSigned(TElX509CertificateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_IssuerName(TElX509CertificateHandle _Handle, TName * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_SubjectName(TElX509CertificateHandle _Handle, TName * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_IssuerRDN(TElX509CertificateHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_SubjectRDN(TElX509CertificateHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_Extensions(TElX509CertificateHandle _Handle, TElCertificateExtensionsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_CertStorage(TElX509CertificateHandle _Handle, TElBaseCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_CertStorage(TElX509CertificateHandle _Handle, TElBaseCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_StorageName(TElX509CertificateHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_StorageName(TElX509CertificateHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_CanEncrypt(TElX509CertificateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_CanSign(TElX509CertificateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_StrictMode(TElX509CertificateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_StrictMode(TElX509CertificateHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_UseUTF8(TElX509CertificateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_UseUTF8(TElX509CertificateHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_Chain(TElX509CertificateHandle _Handle, TElX509CertificateChainHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_Chain(TElX509CertificateHandle _Handle, TElX509CertificateChainHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_KeyMaterial(TElX509CertificateHandle _Handle, TElPublicKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_NegativeSerial(TElX509CertificateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_ReportErrorOnPartialLoad(TElX509CertificateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_ReportErrorOnPartialLoad(TElX509CertificateHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_CryptoProvider(TElX509CertificateHandle _Handle, TElCustomCryptoProviderHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_CryptoProvider(TElX509CertificateHandle _Handle, TElCustomCryptoProviderHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_CryptoProviderManager(TElX509CertificateHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_CryptoProviderManager(TElX509CertificateHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_IgnoreVersion(TElX509CertificateHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_IgnoreVersion(TElX509CertificateHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_PKCS11Label(TElX509CertificateHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_PKCS11Label(TElX509CertificateHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_PKCS11Handle(TElX509CertificateHandle _Handle, uint64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_PKCS11Handle(TElX509CertificateHandle _Handle, uint64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_get_PKCS11ObjectID(TElX509CertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_set_PKCS11ObjectID(TElX509CertificateHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElX509Certificate_Create(TComponentHandle Owner, TElX509CertificateHandle * OutResult);
#endif /* SB_USE_CLASS_TELX509CERTIFICATE */

#ifdef SB_USE_CLASS_TELSUBJECTPUBLICKEYINFO
SB_IMPORT uint32_t SB_APIENTRY TElSubjectPublicKeyInfo_Clear(TElSubjectPublicKeyInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSubjectPublicKeyInfo_get_PublicKeyAlgorithmIdentifier(TElSubjectPublicKeyInfoHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSubjectPublicKeyInfo_get_PublicKeyAlgorithm(TElSubjectPublicKeyInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSubjectPublicKeyInfo_get_RawData(TElSubjectPublicKeyInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSubjectPublicKeyInfo_Create(TElSubjectPublicKeyInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELSUBJECTPUBLICKEYINFO */

#ifdef SB_USE_CLASS_TELTBSCERTIFICATE
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_Clear(TElTBSCertificateHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_get_Version(TElTBSCertificateHandle _Handle, uint8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_set_Version(TElTBSCertificateHandle _Handle, uint8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_get_SerialNumber(TElTBSCertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_set_SerialNumber(TElTBSCertificateHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_get_SignatureIdentifier(TElTBSCertificateHandle _Handle, TElAlgorithmIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_get_Issuer(TElTBSCertificateHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_get_Subject(TElTBSCertificateHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_get_SubjectPublicKeyInfo(TElTBSCertificateHandle _Handle, TElSubjectPublicKeyInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_get_IssuerUniqueID(TElTBSCertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_set_IssuerUniqueID(TElTBSCertificateHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_get_SubjectUniqueID(TElTBSCertificateHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_set_SubjectUniqueID(TElTBSCertificateHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_get_Validity(TElTBSCertificateHandle _Handle, TValidity * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_set_Validity(TElTBSCertificateHandle _Handle, TValidity * Value);
SB_IMPORT uint32_t SB_APIENTRY TElTBSCertificate_Create(TElTBSCertificateHandle * OutResult);
#endif /* SB_USE_CLASS_TELTBSCERTIFICATE */

#ifdef SB_USE_CLASS_TELX509CERTIFICATECHAIN
SB_IMPORT uint32_t SB_APIENTRY TElX509CertificateChain_Add(TElX509CertificateChainHandle _Handle, TElX509CertificateHandle Certificate, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509CertificateChain_Validate(TElX509CertificateChainHandle _Handle, TSBCertificateValidityReasonRaw * Reason, int64_t ValidityMoment, TSBCertificateValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509CertificateChain_Validate_1(TElX509CertificateChainHandle _Handle, TSBCertificateValidityReasonRaw * Reason, int8_t CheckCACertDates, int64_t ValidityMoment, TSBCertificateValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509CertificateChain_get_Certificates(TElX509CertificateChainHandle _Handle, int32_t Index, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509CertificateChain_get_Complete(TElX509CertificateChainHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509CertificateChain_get_Count(TElX509CertificateChainHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElX509CertificateChain_Create(TComponentHandle Owner, TElX509CertificateChainHandle * OutResult);
#endif /* SB_USE_CLASS_TELX509CERTIFICATECHAIN */

#ifdef SB_USE_CLASS_TELBASECERTSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElBaseCertStorage_Create(TComponentHandle AOwner, TComponentHandle * OutResult);
#endif /* SB_USE_CLASS_TELBASECERTSTORAGE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TValidity_ce_ptr;
extern zend_class_entry *TName_ce_ptr;
extern zend_class_entry *TElX509CertificateClass_ce_ptr;
extern zend_class_entry *TPVKHeader_ce_ptr;
extern zend_class_entry *TElX509Certificate_ce_ptr;
extern zend_class_entry *TElSubjectPublicKeyInfo_ce_ptr;
extern zend_class_entry *TElTBSCertificate_ce_ptr;
extern zend_class_entry *TElX509CertificateChain_ce_ptr;
extern zend_class_entry *TElBaseCertStorage_ce_ptr;

void SB_CALLBACK TSBCertificateValidateEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle X509Certificate, TSBCertificateValidityRaw * Validity, TSBCertificateValidityReasonRaw * Reason);
void Register_TValidity(TSRMLS_D);
void Register_TName(TSRMLS_D);
void Register_TPVKHeader(TSRMLS_D);
void Register_TElX509Certificate(TSRMLS_D);
void Register_TElSubjectPublicKeyInfo(TSRMLS_D);
void Register_TElTBSCertificate(TSRMLS_D);
void Register_TElX509CertificateChain(TSRMLS_D);
void Register_TElBaseCertStorage(TSRMLS_D);
SB_PHP_FUNCTION(SBX509, PVKHeaderToByteArray);
SB_PHP_FUNCTION(SBX509, PVK_DeriveKey);
SB_PHP_FUNCTION(SBX509, RaiseX509Error);
SB_PHP_FUNCTION(SBX509, SerialNumberCorresponds);
SB_PHP_FUNCTION(SBX509, GetOriginalSerialNumber);
SB_PHP_FUNCTION(SBX509, GetX509NegativeSerialWorkaround);
SB_PHP_FUNCTION(SBX509, SetX509NegativeSerialWorkaround);
void Register_SBX509_Constants(int module_number TSRMLS_DC);
void Register_SBX509_Enum_Flags(TSRMLS_D);
void Register_SBX509_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_X509
SB_IMPORT uint32_t SB_APIENTRY SBX509_PVKHeaderToByteArray(const TPVKHeader * Header, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBX509_PVK_DeriveKey(const uint8_t pPassword[], int32_t szPassword, const uint8_t pSalt[], int32_t szSalt, int8_t AWeakMethod, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBX509_RaiseX509Error(int32_t ErrorCode);
SB_IMPORT uint32_t SB_APIENTRY SBX509_SerialNumberCorresponds(TElX509CertificateHandle Cert, const uint8_t pSerial[], int32_t szSerial, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBX509_GetOriginalSerialNumber(TElX509CertificateHandle Cert, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBX509_GetX509NegativeSerialWorkaround(int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBX509_SetX509NegativeSerialWorkaround(int8_t Value);
#endif /* SB_USE_GLOBAL_PROCS_X509 */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBX509 */
