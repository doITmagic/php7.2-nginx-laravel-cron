#ifndef __INC_SBXMLADES
#define __INC_SBXMLADES

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcrl.h"
#include "sbcryptoprov.h"
#include "sbhashfunction.h"
#include "sbtspclient.h"
#include "sbocspcommon.h"
#include "sbocspclient.h"
#include "sbrdn.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbstrutils.h"
#include "sbx509.h"
#include "sbpkcs7utils.h"
#include "sbxmldefs.h"
#include "sbxmlcore.h"
#include "sbxmlsec.h"
#include "sbxmltransform.h"
#include "sbxmlutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_xmlPKIDataEncodingDER 	"http://uri.etsi.org/01903/v1.2.2#DER"
#define SB_xmlPKIDataEncodingBER 	"http://uri.etsi.org/01903/v1.2.2#BER"
#define SB_xmlPKIDataEncodingCER 	"http://uri.etsi.org/01903/v1.2.2#CER"
#define SB_xmlPKIDataEncodingPER 	"http://uri.etsi.org/01903/v1.2.2#PER"
#define SB_xmlPKIDataEncodingXER 	"http://uri.etsi.org/01903/v1.2.2#XER"
#define SB_xmlCTIProofOfOrigin 	"http://uri.etsi.org/01903/v1.2.2#ProofOfOrigin"
#define SB_xmlCTIProofOfReceipt 	"http://uri.etsi.org/01903/v1.2.2#ProofOfReceipt"
#define SB_xmlCTIProofOfDelivery 	"http://uri.etsi.org/01903/v1.2.2#ProofOfDelivery"
#define SB_xmlCTIProofOfSender 	"http://uri.etsi.org/01903/v1.2.2#ProofOfSender"
#define SB_xmlCTIProofOfApproval 	"http://uri.etsi.org/01903/v1.2.2#ProofOfApproval"
#define SB_xmlCTIProofOfCreation 	"http://uri.etsi.org/01903/v1.2.2#ProofOfCreation"
#define SB_SXMLUnsupportedXAdESForm 	"XAdES form not supported by this XAdES version."

typedef TElClassHandle TElXMLAdESElementHandle;

typedef TElXMLAdESElementHandle ElXMLAdESElementHandle;

typedef TElClassHandle TElXMLAnyTypeHandle;

typedef TElXMLAnyTypeHandle ElXMLAnyTypeHandle;

typedef TElClassHandle TElXMLAnyTypeListHandle;

typedef TElXMLAnyTypeListHandle ElXMLAnyTypeListHandle;

typedef TElClassHandle TElXMLObjectIdentifierHandle;

typedef TElXMLObjectIdentifierHandle ElXMLObjectIdentifierHandle;

typedef TElClassHandle TElXMLEncapsulatedPKIDataHandle;

typedef TElXMLEncapsulatedPKIDataHandle ElXMLEncapsulatedPKIDataHandle;

typedef TElClassHandle TElXMLEncapsulatedPKIDataListHandle;

typedef TElXMLEncapsulatedPKIDataListHandle ElXMLEncapsulatedPKIDataListHandle;

typedef TElClassHandle TElXMLHashDataInfoHandle;

typedef TElXMLHashDataInfoHandle ElXMLHashDataInfoHandle;

typedef TElClassHandle TElXMLHashDataInfoListHandle;

typedef TElXMLHashDataInfoListHandle ElXMLHashDataInfoListHandle;

typedef TElClassHandle TElXMLCustomTimestampHandle;

typedef TElXMLCustomTimestampHandle ElXMLCustomTimestampHandle;

typedef TElClassHandle TElXMLCustomTimestampListHandle;

typedef TElXMLCustomTimestampListHandle ElXMLCustomTimestampListHandle;

typedef TElClassHandle TElXMLTimestampHandle;

typedef TElXMLTimestampHandle ElXMLTimestampHandle;

typedef TElClassHandle TElXMLTimestampListHandle;

typedef TElXMLTimestampListHandle ElXMLTimestampListHandle;

typedef TElClassHandle TElXMLIncludeHandle;

typedef TElXMLIncludeHandle ElXMLIncludeHandle;

typedef TElClassHandle TElXMLIncludeListHandle;

typedef TElXMLIncludeListHandle ElXMLIncludeListHandle;

typedef TElClassHandle TElXMLTimestamp_v1_2_2Handle;

typedef TElXMLTimestamp_v1_2_2Handle ElXMLTimestamp_v1_2_2Handle;

typedef TElClassHandle TElXMLTimestampList_v1_2_2Handle;

typedef TElXMLTimestampList_v1_2_2Handle ElXMLTimestampList_v1_2_2Handle;

typedef TElClassHandle TElCustomTSPClientListHandle;

typedef TElCustomTSPClientListHandle ElCustomTSPClientListHandle;

typedef TElClassHandle TElXMLGenericTimestampHandle;

typedef TElXMLGenericTimestampHandle ElXMLGenericTimestampHandle;

typedef TElClassHandle TElXMLGenericTimestampListHandle;

typedef TElXMLGenericTimestampListHandle ElXMLGenericTimestampListHandle;

typedef TElXMLGenericTimestampHandle TElXMLAdESTimestampHandle;

typedef TElXMLGenericTimestampHandle ElXMLXAdESTimestampHandle;

typedef TElXMLGenericTimestampListHandle TElXMLAdESTimestampListHandle;

typedef TElXMLGenericTimestampListHandle ElXMLXAdESTimestampListHandle;

typedef TElClassHandle TElXMLDigestAlgAndValueHandle;

typedef TElXMLDigestAlgAndValueHandle ElXMLDigestAlgAndValueHandle;

typedef TElClassHandle TElXMLCertIDHandle;

typedef TElXMLCertIDHandle ElXMLCertIDHandle;

typedef TElClassHandle TElXMLCertIDListHandle;

typedef TElXMLCertIDListHandle ElXMLCertIDListHandle;

typedef TElClassHandle TElXMLCertIDV2Handle;

typedef TElXMLCertIDV2Handle ElXMLCertIDV2Handle;

typedef TElClassHandle TElXMLCertIDListV2Handle;

typedef TElXMLCertIDListV2Handle ElXMLCertIDListV2Handle;

typedef TElClassHandle TElXMLNoticeReferenceHandle;

typedef TElXMLNoticeReferenceHandle ElXMLNoticeReferenceHandle;

typedef TElClassHandle TElXMLSPUserNoticeHandle;

typedef TElXMLSPUserNoticeHandle ElXMLSPUserNoticeHandle;

typedef TElClassHandle TElXMLSPURIHandle;

typedef TElXMLSPURIHandle ElXMLSPURIHandle;

typedef TElClassHandle TElXMLSigPolicyQualifierHandle;

typedef TElXMLSigPolicyQualifierHandle ElXMLSigPolicyQualifierHandle;

typedef TElXMLAnyTypeListHandle TElXMLSigPolicyQualifierListHandle;

typedef TElXMLAnyTypeListHandle ElXMLSigPolicyQualifierListHandle;

typedef TElClassHandle TElXMLSignaturePolicyIdHandle;

typedef TElXMLSignaturePolicyIdHandle ElXMLSignaturePolicyIdHandle;

typedef TElClassHandle TElXMLSignaturePolicyIdentifierHandle;

typedef TElXMLSignaturePolicyIdentifierHandle ElXMLSignaturePolicyIdentifierHandle;

typedef TElClassHandle TElXMLCounterSignatureHandle;

typedef TElXMLCounterSignatureHandle ElXMLCounterSignatureHandle;

typedef TElClassHandle TElXMLCounterSignatureListHandle;

typedef TElXMLCounterSignatureListHandle ElXMLCounterSignatureListHandle;

typedef TElClassHandle TElXMLDataObjectFormatHandle;

typedef TElXMLDataObjectFormatHandle ElXMLDataObjectFormatHandle;

typedef TElClassHandle TElXMLDataObjectFormatListHandle;

typedef TElXMLDataObjectFormatListHandle ElXMLDataObjectFormatListHandle;

typedef TElClassHandle TElXMLCommitmentTypeQualifierHandle;

typedef TElXMLCommitmentTypeQualifierHandle ElXMLCommitmentTypeQualifierHandle;

typedef TElXMLAnyTypeListHandle TElXMLCommitmentTypeQualifierListHandle;

typedef TElXMLAnyTypeListHandle ElXMLCommitmentTypeQualifierListHandle;

typedef TElClassHandle TElXMLCommitmentTypeIndicationHandle;

typedef TElXMLCommitmentTypeIndicationHandle ElXMLCommitmentTypeIndicationHandle;

typedef TElClassHandle TElXMLCommitmentTypeIndicationListHandle;

typedef TElXMLCommitmentTypeIndicationListHandle ElXMLCommitmentTypeIndicationListHandle;

typedef TElClassHandle TElXMLSignatureProductionPlaceHandle;

typedef TElXMLSignatureProductionPlaceHandle ElXMLSignatureProductionPlaceHandle;

typedef TElClassHandle TElXMLSignatureProductionPlaceV2Handle;

typedef TElXMLSignatureProductionPlaceV2Handle ElXMLSignatureProductionPlaceV2Handle;

typedef TElClassHandle TElXMLEncapsulatedX509CertificatesHandle;

typedef TElXMLEncapsulatedX509CertificatesHandle ElXMLEncapsulatedX509CertificatesHandle;

typedef TElClassHandle TElXMLCertifiedRoleHandle;

typedef TElXMLCertifiedRoleHandle ElXMLCertifiedRoleHandle;

typedef TElClassHandle TElXMLCertifiedRolesListHandle;

typedef TElXMLCertifiedRolesListHandle ElXMLCertifiedRolesListHandle;

typedef TElClassHandle TElXMLCertifiedRoleV2Handle;

typedef TElXMLCertifiedRoleV2Handle ElXMLCertifiedRoleV2Handle;

typedef TElClassHandle TElXMLCertifiedRolesListV2Handle;

typedef TElXMLCertifiedRolesListV2Handle ElXMLCertifiedRolesListV2Handle;

typedef TElClassHandle TElXMLClaimedRoleHandle;

typedef TElXMLClaimedRoleHandle ElXMLClaimedRoleHandle;

typedef TElClassHandle TElXMLClaimedRolesListHandle;

typedef TElXMLClaimedRolesListHandle ElXMLClaimedRolesListHandle;

typedef TElClassHandle TElXMLSignedAssertionHandle;

typedef TElXMLSignedAssertionHandle ElXMLSignedAssertionHandle;

typedef TElClassHandle TElXMLSignedAssertionsListHandle;

typedef TElXMLSignedAssertionsListHandle ElXMLSignedAssertionsListHandle;

typedef TElClassHandle TElXMLSignerRoleHandle;

typedef TElXMLSignerRoleHandle ElXMLSignerRoleHandle;

typedef TElClassHandle TElXMLSignerRoleV2Handle;

typedef TElXMLSignerRoleV2Handle ElXMLSignerRoleV2Handle;

typedef TElClassHandle TElXMLCompleteCertificateRefsHandle;

typedef TElXMLCompleteCertificateRefsHandle ElXMLCompleteCertificateRefsHandle;

typedef TElClassHandle TElXMLCRLIdentifierHandle;

typedef TElXMLCRLIdentifierHandle ElXMLCRLIdentifierHandle;

typedef TElClassHandle TElXMLCRLRefHandle;

typedef TElXMLCRLRefHandle ElXMLCRLRefHandle;

typedef TElClassHandle TElXMLCRLRefsHandle;

typedef TElXMLCRLRefsHandle ElXMLCRLRefsHandle;

typedef TElClassHandle TElXMLOCSPIdentifierHandle;

typedef TElXMLOCSPIdentifierHandle ElXMLOCSPIdentifierHandle;

typedef TElClassHandle TElXMLOCSPRefHandle;

typedef TElXMLOCSPRefHandle ElXMLOCSPRefHandle;

typedef TElClassHandle TElXMLOCSPRefsHandle;

typedef TElXMLOCSPRefsHandle ElXMLOCSPRefsHandle;

typedef TElClassHandle TElXMLOtherRefHandle;

typedef TElXMLOtherRefHandle ElXMLOtherRefHandle;

typedef TElXMLAnyTypeListHandle TElXMLOtherCertStatusRefsHandle;

typedef TElXMLAnyTypeListHandle ElXMLOtherCertStatusRefsHandle;

typedef TElClassHandle TElXMLCompleteRevocationRefsHandle;

typedef TElXMLCompleteRevocationRefsHandle ElXMLCompleteRevocationRefsHandle;

typedef TElClassHandle TElXMLCertificateValuesHandle;

typedef TElXMLCertificateValuesHandle ElXMLCertificateValuesHandle;

typedef TElClassHandle TElXMLEncapsulatedCRLValueHandle;

typedef TElXMLEncapsulatedCRLValueHandle ElXMLEncapsulatedCRLValueHandle;

typedef TElClassHandle TElXMLCRLValuesHandle;

typedef TElXMLCRLValuesHandle ElXMLCRLValuesHandle;

typedef TElClassHandle TElXMLEncapsulatedOCSPValueHandle;

typedef TElXMLEncapsulatedOCSPValueHandle ElXMLEncapsulatedOCSPValueHandle;

typedef TElClassHandle TElXMLOCSPValuesHandle;

typedef TElXMLOCSPValuesHandle ElXMLOCSPValuesHandle;

typedef TElXMLAnyTypeListHandle TElXMLOtherCertStatusValuesHandle;

typedef TElXMLAnyTypeListHandle ElXMLOtherCertStatusValuesHandle;

typedef TElClassHandle TElXMLRevocationValuesHandle;

typedef TElXMLRevocationValuesHandle ElXMLRevocationValuesHandle;

typedef TElClassHandle TElXMLTimeStampValidationDataHandle;

typedef TElXMLTimeStampValidationDataHandle ElXMLTimeStampValidationDataHandle;

typedef TElClassHandle TElXMLTimeStampValidationDataListHandle;

typedef TElXMLTimeStampValidationDataListHandle ElXMLTimeStampValidationDataListHandle;

typedef TElClassHandle TElXMLSignedDataObjectPropertiesHandle;

typedef TElXMLSignedDataObjectPropertiesHandle ElXMLSignedDataObjectPropertiesHandle;

typedef TElClassHandle TElXMLUnsignedDataObjectPropertyHandle;

typedef TElXMLUnsignedDataObjectPropertyHandle ElXMLUnsignedDataObjectPropertyHandle;

typedef TElXMLAnyTypeListHandle TElXMLUnsignedDataObjectPropertiesHandle;

typedef TElXMLAnyTypeListHandle ElXMLUnsignedDataObjectPropertiesHandle;

typedef TElClassHandle TElXMLSignedSignaturePropertiesHandle;

typedef TElXMLSignedSignaturePropertiesHandle ElXMLSignedSignaturePropertiesHandle;

typedef TElClassHandle TElXMLUnsignedSignaturePropertiesHandle;

typedef TElXMLUnsignedSignaturePropertiesHandle ElXMLUnsignedSignaturePropertiesHandle;

typedef TElClassHandle TElXMLSignedPropertiesHandle;

typedef TElXMLSignedPropertiesHandle ElXMLSignedPropertiesHandle;

typedef TElClassHandle TElXMLUnsignedPropertiesHandle;

typedef TElXMLUnsignedPropertiesHandle ElXMLUnsignedPropertiesHandle;

typedef TElClassHandle TElXMLQualifyingPropertiesHandle;

typedef TElXMLQualifyingPropertiesHandle ElXMLQualifyingPropertiesHandle;

typedef TElClassHandle TElXMLQualifyingPropertiesReferenceHandle;

typedef TElXMLQualifyingPropertiesReferenceHandle ElXMLQualifyingPropertiesReferenceHandle;

typedef TElClassHandle TElXMLQualifyingPropertiesReferenceListHandle;

typedef TElXMLQualifyingPropertiesReferenceListHandle ElXMLQualifyingPropertiesReferenceListHandle;

typedef uint8_t TSBXAdESVersionRaw;

typedef enum
{
	XAdES_v1_1_1 = 0,
	XAdES_v1_2_2 = 1,
	XAdES_v1_3_2 = 2,
	XAdES_v1_4_1 = 3
} TSBXAdESVersion;

typedef uint8_t TSBXAdESFormRaw;

typedef enum
{
	XAdES = 0,
	XAdES_BES = 1,
	XAdES_EPES = 2,
	XAdES_T = 3,
	XAdES_C = 4,
	XAdES_X = 5,
	XAdES_X_L = 6,
	XAdES_A = 7,
	XAdES_E_BES = 8,
	XAdES_E_EPES = 9,
	XAdES_E_T = 10,
	XAdES_E_C = 11,
	XAdES_E_X = 12,
	XAdES_E_X_Long = 13,
	XAdES_E_X_L = 14,
	XAdES_E_A = 15
} TSBXAdESForm;

typedef uint8_t TSBXAdESQualifierTypeRaw;

typedef enum
{
	xqtNone = 0,
	xqtOIDAsURN = 1,
	xqtOIDAsURI = 2
} TSBXAdESQualifierType;

typedef uint8_t TSBXAdESEncodingMethodRaw;

typedef enum
{
	xemDER = 0,
	xemCER = 1,
	xemBER = 2,
	xemPER = 3,
	xemXER = 4
} TSBXAdESEncodingMethod;

typedef uint8_t TSBXAdESResponderIDTypeRaw;

typedef enum
{
	xrtByName = 0,
	xrtByKey = 1
} TSBXAdESResponderIDType;

#ifdef SB_USE_CLASS_TELXMLADESELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElXMLAdESElement_Assign(TElXMLAdESElementHandle _Handle, TElXMLAdESElementHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAdESElement_IsEmpty(TElXMLAdESElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAdESElement_get_XAdESVersion(TElXMLAdESElementHandle _Handle, TSBXAdESVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAdESElement_Create(TSBXAdESVersionRaw AVersion, TElXMLAdESElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAdESElement_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLAdESElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAdESElement_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLAdESElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLADESELEMENT */

#ifdef SB_USE_CLASS_TELXMLANYTYPE
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyType_Assign(TElXMLAnyTypeHandle _Handle, TElXMLAdESElementHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyType_Clear(TElXMLAnyTypeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyType_IsEmpty(TElXMLAnyTypeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyType_LoadFromXML(TElXMLAnyTypeHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyType_SaveToXML(TElXMLAnyTypeHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyType_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyType_get_Value(TElXMLAnyTypeHandle _Handle, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyType_set_Value(TElXMLAnyTypeHandle _Handle, TElXMLDOMNodeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyType_Create(TSBXAdESVersionRaw AVersion, TElXMLAdESElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyType_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLAdESElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyType_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLAdESElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLANYTYPE */

#ifdef SB_USE_CLASS_TELXMLANYTYPELIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyTypeList_Assign(TElXMLAnyTypeListHandle _Handle, TElXMLAnyTypeListHandle Source, TSBXAdESVersionRaw AVersion);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyTypeList_Add(TElXMLAnyTypeListHandle _Handle, TElXMLAnyTypeHandle AItem, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyTypeList_Insert(TElXMLAnyTypeListHandle _Handle, int32_t Index, TElXMLAnyTypeHandle AItem);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyTypeList_Delete(TElXMLAnyTypeListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyTypeList_Clear(TElXMLAnyTypeListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyTypeList_get_Count(TElXMLAnyTypeListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyTypeList_get_Item(TElXMLAnyTypeListHandle _Handle, int32_t Index, TElXMLAnyTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAnyTypeList_Create(TElXMLAnyTypeListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLANYTYPELIST */

#ifdef SB_USE_CLASS_TELXMLOBJECTIDENTIFIER
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_Assign(TElXMLObjectIdentifierHandle _Handle, TElXMLAdESElementHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_Clear(TElXMLObjectIdentifierHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_IsEmpty(TElXMLObjectIdentifierHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_LoadFromXML(TElXMLObjectIdentifierHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_SaveToXML(TElXMLObjectIdentifierHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_get_Description(TElXMLObjectIdentifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_set_Description(TElXMLObjectIdentifierHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_get_DocumentationReferences(TElXMLObjectIdentifierHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_get_Identifier(TElXMLObjectIdentifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_set_Identifier(TElXMLObjectIdentifierHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_get_IdentifierQualifier(TElXMLObjectIdentifierHandle _Handle, TSBXAdESQualifierTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_set_IdentifierQualifier(TElXMLObjectIdentifierHandle _Handle, TSBXAdESQualifierTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_Create(TSBXAdESVersionRaw AVersion, TElXMLObjectIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLObjectIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectIdentifier_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLObjectIdentifierHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLOBJECTIDENTIFIER */

#ifdef SB_USE_CLASS_TELXMLENCAPSULATEDPKIDATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_Assign(TElXMLEncapsulatedPKIDataHandle _Handle, TElXMLAdESElementHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_Clear(TElXMLEncapsulatedPKIDataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_IsEmpty(TElXMLEncapsulatedPKIDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_LoadFromXML(TElXMLEncapsulatedPKIDataHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_SaveToXML(TElXMLEncapsulatedPKIDataHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_get_Data(TElXMLEncapsulatedPKIDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_set_Data(TElXMLEncapsulatedPKIDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_get_ID(TElXMLEncapsulatedPKIDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_set_ID(TElXMLEncapsulatedPKIDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_get_Encoding(TElXMLEncapsulatedPKIDataHandle _Handle, TSBXAdESEncodingMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_set_Encoding(TElXMLEncapsulatedPKIDataHandle _Handle, TSBXAdESEncodingMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_Create(TSBXAdESVersionRaw AVersion, TElXMLEncapsulatedPKIDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLEncapsulatedPKIDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIData_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLEncapsulatedPKIDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLENCAPSULATEDPKIDATA */

#ifdef SB_USE_CLASS_TELXMLENCAPSULATEDPKIDATALIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIDataList_Assign(TElXMLEncapsulatedPKIDataListHandle _Handle, TElXMLEncapsulatedPKIDataListHandle Source, TSBXAdESVersionRaw AVersion);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIDataList_Add(TElXMLEncapsulatedPKIDataListHandle _Handle, TElXMLEncapsulatedPKIDataHandle APKIData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIDataList_Insert(TElXMLEncapsulatedPKIDataListHandle _Handle, int32_t Index, TElXMLEncapsulatedPKIDataHandle APKIData);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIDataList_Delete(TElXMLEncapsulatedPKIDataListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIDataList_Clear(TElXMLEncapsulatedPKIDataListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIDataList_get_Count(TElXMLEncapsulatedPKIDataListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIDataList_get_PKIData(TElXMLEncapsulatedPKIDataListHandle _Handle, int32_t Index, TElXMLEncapsulatedPKIDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedPKIDataList_Create(TElXMLEncapsulatedPKIDataListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLENCAPSULATEDPKIDATALIST */

#ifdef SB_USE_CLASS_TELXMLHASHDATAINFO
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_Clear(TElXMLHashDataInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_IsEmpty(TElXMLHashDataInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_LoadFromXML(TElXMLHashDataInfoHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_SaveToXML(TElXMLHashDataInfoHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_GetHashData(TElXMLHashDataInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_get_TransformChain(TElXMLHashDataInfoHandle _Handle, TElXMLTransformChainHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_set_TransformChain(TElXMLHashDataInfoHandle _Handle, TElXMLTransformChainHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_get_URI(TElXMLHashDataInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_set_URI(TElXMLHashDataInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_get_URIData(TElXMLHashDataInfoHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_set_URIData(TElXMLHashDataInfoHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_get_URINode(TElXMLHashDataInfoHandle _Handle, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_set_URINode(TElXMLHashDataInfoHandle _Handle, TElXMLDOMNodeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_Create(TSBXAdESVersionRaw AVersion, TElXMLHashDataInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLHashDataInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfo_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLHashDataInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLHASHDATAINFO */

#ifdef SB_USE_CLASS_TELXMLHASHDATAINFOLIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfoList_Add(TElXMLHashDataInfoListHandle _Handle, TElXMLHashDataInfoHandle AHashDataInfo, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfoList_Insert(TElXMLHashDataInfoListHandle _Handle, int32_t Index, TElXMLHashDataInfoHandle AHashDataInfo);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfoList_Delete(TElXMLHashDataInfoListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfoList_Clear(TElXMLHashDataInfoListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfoList_get_Count(TElXMLHashDataInfoListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfoList_get_HashDataInfo(TElXMLHashDataInfoListHandle _Handle, int32_t Index, TElXMLHashDataInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLHashDataInfoList_Create(TElXMLHashDataInfoListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLHASHDATAINFOLIST */

#ifdef SB_USE_CLASS_TELXMLCUSTOMTIMESTAMP
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestamp_GetTimestampInfo(TElXMLCustomTimestampHandle _Handle, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestamp_CheckTimestamp(TElXMLCustomTimestampHandle _Handle, TElClientTSPInfoHandle Info, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestamp_CheckTimestamp_1(TElXMLCustomTimestampHandle _Handle, TElClientTSPInfoHandle Info, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestamp_Timestamp(TElXMLCustomTimestampHandle _Handle, TElCustomTSPClientHandle TSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestamp_Timestamp_1(TElXMLCustomTimestampHandle _Handle, TElCustomTSPClientHandle TSPClient, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestamp_Create(TSBXAdESVersionRaw AVersion, TElXMLAdESElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestamp_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLAdESElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestamp_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLAdESElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCUSTOMTIMESTAMP */

#ifdef SB_USE_CLASS_TELXMLCUSTOMTIMESTAMPLIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestampList_Add(TElXMLCustomTimestampListHandle _Handle, TElXMLCustomTimestampHandle ATimestamp, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestampList_Insert(TElXMLCustomTimestampListHandle _Handle, int32_t Index, TElXMLCustomTimestampHandle ATimestamp);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestampList_Delete(TElXMLCustomTimestampListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestampList_Clear(TElXMLCustomTimestampListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestampList_get_Count(TElXMLCustomTimestampListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestampList_get_Timestamp(TElXMLCustomTimestampListHandle _Handle, int32_t Index, TElXMLCustomTimestampHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomTimestampList_Create(TElXMLCustomTimestampListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCUSTOMTIMESTAMPLIST */

#ifdef SB_USE_CLASS_TELXMLTIMESTAMP
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_Clear(TElXMLTimestampHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_IsEmpty(TElXMLTimestampHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_LoadFromXML(TElXMLTimestampHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_SaveToXML(TElXMLTimestampHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_GetTimestampInfo(TElXMLTimestampHandle _Handle, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_CheckTimestamp(TElXMLTimestampHandle _Handle, TElClientTSPInfoHandle Info, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_CheckTimestamp_1(TElXMLCustomTimestampHandle _Handle, TElClientTSPInfoHandle Info, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_Timestamp(TElXMLTimestampHandle _Handle, TElCustomTSPClientHandle TSPClient, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_Timestamp_1(TElXMLCustomTimestampHandle _Handle, TElCustomTSPClientHandle TSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_get_HashDataInfos(TElXMLTimestampHandle _Handle, TElXMLHashDataInfoListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_get_EncapsulatedTimestamp(TElXMLTimestampHandle _Handle, TElXMLEncapsulatedPKIDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_set_EncapsulatedTimestamp(TElXMLTimestampHandle _Handle, TElXMLEncapsulatedPKIDataHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_get_XMLTimestamp(TElXMLTimestampHandle _Handle, TElXMLAnyTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_set_XMLTimestamp(TElXMLTimestampHandle _Handle, TElXMLAnyTypeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_Create(TSBXAdESVersionRaw AVersion, TElXMLTimestampHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLTimestampHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLTimestampHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLTIMESTAMP */

#ifdef SB_USE_CLASS_TELXMLTIMESTAMPLIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestampList_Add(TElXMLTimestampListHandle _Handle, TElXMLTimestampHandle ATimestamp, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestampList_Insert(TElXMLTimestampListHandle _Handle, int32_t Index, TElXMLTimestampHandle ATimestamp);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestampList_get_Timestamp_TElXMLTimestamp(TElXMLTimestampListHandle _Handle, int32_t Index, TElXMLTimestampHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestampList_Create(TElXMLCustomTimestampListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLTIMESTAMPLIST */

#ifdef SB_USE_CLASS_TELXMLINCLUDE
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_Clear(TElXMLIncludeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_IsEmpty(TElXMLIncludeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_LoadFromXML(TElXMLIncludeHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_SaveToXML(TElXMLIncludeHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_ProcessIncludeData(TElXMLIncludeHandle _Handle, TElXMLCanonicalizationMethodRaw CanonicalizationMethod, TElHashFunctionHandle HashFunc);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_get_ReferencedData(TElXMLIncludeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_set_ReferencedData(TElXMLIncludeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_get_URI(TElXMLIncludeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_set_URI(TElXMLIncludeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_get_URIData(TElXMLIncludeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_set_URIData(TElXMLIncludeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_get_URINode(TElXMLIncludeHandle _Handle, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_set_URINode(TElXMLIncludeHandle _Handle, TElXMLDOMNodeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_get_URIReference(TElXMLIncludeHandle _Handle, TElXMLReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_set_URIReference(TElXMLIncludeHandle _Handle, TElXMLReferenceHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_Create(TSBXAdESVersionRaw AVersion, TElXMLIncludeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLIncludeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLInclude_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLIncludeHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLINCLUDE */

#ifdef SB_USE_CLASS_TELXMLINCLUDELIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLIncludeList_Add(TElXMLIncludeListHandle _Handle, TElXMLIncludeHandle AInclude, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIncludeList_Insert(TElXMLIncludeListHandle _Handle, int32_t Index, TElXMLIncludeHandle AInclude);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIncludeList_Delete(TElXMLIncludeListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIncludeList_Clear(TElXMLIncludeListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIncludeList_get_Count(TElXMLIncludeListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIncludeList_get_Includes(TElXMLIncludeListHandle _Handle, int32_t Index, TElXMLIncludeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIncludeList_Create(TElXMLIncludeListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLINCLUDELIST */

#ifdef SB_USE_CLASS_TELXMLTIMESTAMP_V1_2_2
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_Clear(TElXMLTimestamp_v1_2_2Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_IsEmpty(TElXMLTimestamp_v1_2_2Handle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_LoadFromXML(TElXMLTimestamp_v1_2_2Handle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_SaveToXML(TElXMLTimestamp_v1_2_2Handle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_GetTimestampInfo(TElXMLTimestamp_v1_2_2Handle _Handle, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_CheckTimestamp(TElXMLTimestamp_v1_2_2Handle _Handle, TElClientTSPInfoHandle Info, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_CheckTimestamp_1(TElXMLCustomTimestampHandle _Handle, TElClientTSPInfoHandle Info, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_Timestamp(TElXMLTimestamp_v1_2_2Handle _Handle, TElCustomTSPClientHandle TSPClient, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_Timestamp_1(TElXMLCustomTimestampHandle _Handle, TElCustomTSPClientHandle TSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_get_ID(TElXMLTimestamp_v1_2_2Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_set_ID(TElXMLTimestamp_v1_2_2Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_get_CanonicalizationMethod(TElXMLTimestamp_v1_2_2Handle _Handle, TElXMLCanonicalizationMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_set_CanonicalizationMethod(TElXMLTimestamp_v1_2_2Handle _Handle, TElXMLCanonicalizationMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_get_EncapsulatedTimestamp(TElXMLTimestamp_v1_2_2Handle _Handle, TElXMLEncapsulatedPKIDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_set_EncapsulatedTimestamp(TElXMLTimestamp_v1_2_2Handle _Handle, TElXMLEncapsulatedPKIDataHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_get_XMLTimestamp(TElXMLTimestamp_v1_2_2Handle _Handle, TElXMLAnyTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_set_XMLTimestamp(TElXMLTimestamp_v1_2_2Handle _Handle, TElXMLAnyTypeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_get_Includes(TElXMLTimestamp_v1_2_2Handle _Handle, TElXMLIncludeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_Create(TSBXAdESVersionRaw AVersion, TElXMLTimestamp_v1_2_2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLTimestamp_v1_2_2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestamp_v1_2_2_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLTimestamp_v1_2_2Handle * OutResult);
#endif /* SB_USE_CLASS_TELXMLTIMESTAMP_V1_2_2 */

#ifdef SB_USE_CLASS_TELXMLTIMESTAMPLIST_V1_2_2
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestampList_v1_2_2_Add(TElXMLTimestampList_v1_2_2Handle _Handle, TElXMLTimestamp_v1_2_2Handle ATimestamp, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestampList_v1_2_2_Insert(TElXMLTimestampList_v1_2_2Handle _Handle, int32_t Index, TElXMLTimestamp_v1_2_2Handle ATimestamp);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestampList_v1_2_2_get_Timestamp_TElXMLTimestamp_v1_2_2(TElXMLTimestampList_v1_2_2Handle _Handle, int32_t Index, TElXMLTimestamp_v1_2_2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimestampList_v1_2_2_Create(TElXMLCustomTimestampListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLTIMESTAMPLIST_V1_2_2 */

#ifdef SB_USE_CLASS_TELCUSTOMTSPCLIENTLIST
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPClientList_Add(TElCustomTSPClientListHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPClientList_Insert(TElCustomTSPClientListHandle _Handle, int32_t Index, TElCustomTSPClientHandle ATSPClient);
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPClientList_Delete(TElCustomTSPClientListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPClientList_Clear(TElCustomTSPClientListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPClientList_get_Count(TElCustomTSPClientListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPClientList_get_OwnItems(TElCustomTSPClientListHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPClientList_get_TSPClients(TElCustomTSPClientListHandle _Handle, int32_t Index, TElCustomTSPClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomTSPClientList_Create(int8_t AOwnItems, TElCustomTSPClientListHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMTSPCLIENTLIST */

#ifdef SB_USE_CLASS_TELXMLGENERICTIMESTAMP
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_Clear(TElXMLGenericTimestampHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_IsEmpty(TElXMLGenericTimestampHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_LoadFromXML(TElXMLGenericTimestampHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_SaveToXML(TElXMLGenericTimestampHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_GetTimestampInfo(TElXMLGenericTimestampHandle _Handle, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_GetTimestampInfo_1(TElXMLGenericTimestampHandle _Handle, int32_t Index, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_AddTimestampData(TElXMLGenericTimestampHandle _Handle, const uint8_t pData[], int32_t szData);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_AddTimestampData_1(TElXMLGenericTimestampHandle _Handle, const TElXMLDOMNodeHandle Node);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_AddTimestampData_2(TElXMLGenericTimestampHandle _Handle, const TElXMLReferenceHandle Ref);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_StartTimestampCheck(TElXMLGenericTimestampHandle _Handle, TElClientTSPInfoHandle Info);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_FinishTimestampCheck(TElXMLGenericTimestampHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_CheckTimestamp(TElXMLGenericTimestampHandle _Handle, TElClientTSPInfoHandle Info, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_CheckTimestamp_1(TElXMLCustomTimestampHandle _Handle, TElClientTSPInfoHandle Info, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_Timestamp(TElXMLGenericTimestampHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_Timestamp_1(TElXMLGenericTimestampHandle _Handle, TElCustomTSPClientHandle TSPClient, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_Timestamp_2(TElXMLCustomTimestampHandle _Handle, TElCustomTSPClientHandle TSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_get_TimestampInfoCount(TElXMLGenericTimestampHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_get_TSPClients(TElXMLGenericTimestampHandle _Handle, TElCustomTSPClientListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_get_CryptoProviderManager(TElXMLGenericTimestampHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_set_CryptoProviderManager(TElXMLGenericTimestampHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_get_ID(TElXMLGenericTimestampHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_set_ID(TElXMLGenericTimestampHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_get_CanonicalizationMethod(TElXMLGenericTimestampHandle _Handle, TElXMLCanonicalizationMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_set_CanonicalizationMethod(TElXMLGenericTimestampHandle _Handle, TElXMLCanonicalizationMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_get_EncapsulatedTimestamps(TElXMLGenericTimestampHandle _Handle, TElXMLEncapsulatedPKIDataListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_get_XMLTimestamps(TElXMLGenericTimestampHandle _Handle, TElXMLAnyTypeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_get_Includes(TElXMLGenericTimestampHandle _Handle, TElXMLIncludeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_Create(TSBXAdESVersionRaw AVersion, TElXMLGenericTimestampHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLGenericTimestampHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestamp_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLGenericTimestampHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLGENERICTIMESTAMP */

#ifdef SB_USE_CLASS_TELXMLGENERICTIMESTAMPLIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestampList_Add(TElXMLGenericTimestampListHandle _Handle, TElXMLGenericTimestampHandle ATimestamp, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestampList_Insert(TElXMLGenericTimestampListHandle _Handle, int32_t Index, TElXMLGenericTimestampHandle ATimestamp);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestampList_get_Timestamp_TElXMLGenericTimestamp(TElXMLGenericTimestampListHandle _Handle, int32_t Index, TElXMLGenericTimestampHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGenericTimestampList_Create(TElXMLCustomTimestampListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLGENERICTIMESTAMPLIST */

#ifdef SB_USE_CLASS_TELXMLDIGESTALGANDVALUE
SB_IMPORT uint32_t SB_APIENTRY TElXMLDigestAlgAndValue_Assign(TElXMLDigestAlgAndValueHandle _Handle, TElXMLAdESElementHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDigestAlgAndValue_Clear(TElXMLDigestAlgAndValueHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDigestAlgAndValue_IsEmpty(TElXMLDigestAlgAndValueHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDigestAlgAndValue_LoadFromXML(TElXMLDigestAlgAndValueHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDigestAlgAndValue_SaveToXML(TElXMLDigestAlgAndValueHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDigestAlgAndValue_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDigestAlgAndValue_get_DigestMethod(TElXMLDigestAlgAndValueHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDigestAlgAndValue_set_DigestMethod(TElXMLDigestAlgAndValueHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDigestAlgAndValue_get_DigestValue(TElXMLDigestAlgAndValueHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDigestAlgAndValue_set_DigestValue(TElXMLDigestAlgAndValueHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDigestAlgAndValue_Create(TSBXAdESVersionRaw AVersion, TElXMLDigestAlgAndValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDigestAlgAndValue_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLDigestAlgAndValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDigestAlgAndValue_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLDigestAlgAndValueHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDIGESTALGANDVALUE */

#ifdef SB_USE_CLASS_TELXMLCERTID
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertID_Clear(TElXMLCertIDHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertID_IsEmpty(TElXMLCertIDHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertID_LoadFromXML(TElXMLCertIDHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertID_SaveToXML(TElXMLCertIDHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertID_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertID_IsMatch(TElXMLCertIDHandle _Handle, TElX509CertificateHandle Cert, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertID_IsMatch_1(TElXMLCertIDHandle _Handle, TElX509CertificateHandle Cert, int8_t LiberalMode, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertID_get_CertDigest(TElXMLCertIDHandle _Handle, TElXMLDigestAlgAndValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertID_get_IssuerSerial(TElXMLCertIDHandle _Handle, TElXMLIssuerSerialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertID_get_URI(TElXMLCertIDHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertID_set_URI(TElXMLCertIDHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertID_Create(TSBXAdESVersionRaw AVersion, TElXMLCertIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertID_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLCertIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertID_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLCertIDHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCERTID */

#ifdef SB_USE_CLASS_TELXMLCERTIDLIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDList_HasCertificate(TElXMLCertIDListHandle _Handle, TElX509CertificateHandle ACertificate, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDList_AddCertificate(TElXMLCertIDListHandle _Handle, TElX509CertificateHandle ACertificate, TSBXAdESVersionRaw AXAdESVersion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDList_AddCertificate_1(TElXMLCertIDListHandle _Handle, TElX509CertificateHandle ACertificate, TElXMLDigestMethodRaw DigestMethod, TSBXAdESVersionRaw AXAdESVersion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDList_AddCertificate_2(TElXMLCertIDListHandle _Handle, TElX509CertificateHandle ACertificate, TElXMLDigestMethodRaw DigestMethod, int8_t HexSerialNumber, TSBXAdESVersionRaw AXAdESVersion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDList_Add(TElXMLCertIDListHandle _Handle, TElXMLCertIDHandle ACertID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDList_Insert(TElXMLCertIDListHandle _Handle, int32_t Index, TElXMLCertIDHandle ACertID);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDList_Delete(TElXMLCertIDListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDList_Clear(TElXMLCertIDListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDList_get_Count(TElXMLCertIDListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDList_get_CertIDs(TElXMLCertIDListHandle _Handle, int32_t Index, TElXMLCertIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDList_Create(TElXMLCertIDListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCERTIDLIST */

#ifdef SB_USE_CLASS_TELXMLCERTIDV2
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDV2_Clear(TElXMLCertIDV2Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDV2_IsEmpty(TElXMLCertIDV2Handle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDV2_LoadFromXML(TElXMLCertIDV2Handle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDV2_SaveToXML(TElXMLCertIDV2Handle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDV2_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDV2_IsMatch(TElXMLCertIDV2Handle _Handle, TElX509CertificateHandle Cert, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDV2_get_CertDigest(TElXMLCertIDV2Handle _Handle, TElXMLDigestAlgAndValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDV2_get_IssuerSerialV2(TElXMLCertIDV2Handle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDV2_set_IssuerSerialV2(TElXMLCertIDV2Handle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDV2_get_URI(TElXMLCertIDV2Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDV2_set_URI(TElXMLCertIDV2Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDV2_Create(TSBXAdESVersionRaw AVersion, TElXMLCertIDV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDV2_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLCertIDV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDV2_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLCertIDV2Handle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCERTIDV2 */

#ifdef SB_USE_CLASS_TELXMLCERTIDLISTV2
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_IsEmpty(TElXMLCertIDListV2Handle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_LoadFromXML(TElXMLCertIDListV2Handle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_SaveToXML(TElXMLCertIDListV2Handle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_AddCertificate(TElXMLCertIDListV2Handle _Handle, TElX509CertificateHandle ACertificate, TSBXAdESVersionRaw AXAdESVersion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_AddCertificate_1(TElXMLCertIDListV2Handle _Handle, TElX509CertificateHandle ACertificate, TElXMLDigestMethodRaw DigestMethod, TSBXAdESVersionRaw AXAdESVersion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_HasCertificate(TElXMLCertIDListV2Handle _Handle, TElX509CertificateHandle ACertificate, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_Add(TElXMLCertIDListV2Handle _Handle, TElXMLCertIDV2Handle ACertID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_Insert(TElXMLCertIDListV2Handle _Handle, int32_t Index, TElXMLCertIDV2Handle ACertID);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_Delete(TElXMLCertIDListV2Handle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_Clear(TElXMLCertIDListV2Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_get_Count(TElXMLCertIDListV2Handle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_get_CertIDs(TElXMLCertIDListV2Handle _Handle, int32_t Index, TElXMLCertIDV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_Create(TSBXAdESVersionRaw AVersion, TElXMLCertIDListV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLCertIDListV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertIDListV2_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLCertIDListV2Handle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCERTIDLISTV2 */

#ifdef SB_USE_CLASS_TELXMLNOTICEREFERENCE
SB_IMPORT uint32_t SB_APIENTRY TElXMLNoticeReference_Clear(TElXMLNoticeReferenceHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNoticeReference_IsEmpty(TElXMLNoticeReferenceHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNoticeReference_LoadFromXML(TElXMLNoticeReferenceHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNoticeReference_SaveToXML(TElXMLNoticeReferenceHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNoticeReference_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNoticeReference_get_Organization(TElXMLNoticeReferenceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNoticeReference_set_Organization(TElXMLNoticeReferenceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNoticeReference_get_NoticeNumbers(TElXMLNoticeReferenceHandle _Handle, int32_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNoticeReference_set_NoticeNumbers(TElXMLNoticeReferenceHandle _Handle, const int32_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNoticeReference_Create(TSBXAdESVersionRaw AVersion, TElXMLAdESElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNoticeReference_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLAdESElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNoticeReference_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLAdESElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLNOTICEREFERENCE */

#ifdef SB_USE_CLASS_TELXMLSPUSERNOTICE
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPUserNotice_Clear(TElXMLSPUserNoticeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPUserNotice_IsEmpty(TElXMLSPUserNoticeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPUserNotice_LoadFromXML(TElXMLSPUserNoticeHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPUserNotice_SaveToXML(TElXMLSPUserNoticeHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPUserNotice_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPUserNotice_get_NoticeRef(TElXMLSPUserNoticeHandle _Handle, TElXMLNoticeReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPUserNotice_set_NoticeRef(TElXMLSPUserNoticeHandle _Handle, TElXMLNoticeReferenceHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPUserNotice_get_ExplicitTex(TElXMLSPUserNoticeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPUserNotice_set_ExplicitTex(TElXMLSPUserNoticeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPUserNotice_Create(TSBXAdESVersionRaw AVersion, TElXMLSPUserNoticeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPUserNotice_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLSPUserNoticeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPUserNotice_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLSPUserNoticeHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSPUSERNOTICE */

#ifdef SB_USE_CLASS_TELXMLSPURI
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPURI_Clear(TElXMLSPURIHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPURI_IsEmpty(TElXMLSPURIHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPURI_LoadFromXML(TElXMLSPURIHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPURI_SaveToXML(TElXMLSPURIHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPURI_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPURI_get_URI(TElXMLSPURIHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPURI_set_URI(TElXMLSPURIHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPURI_Create(TSBXAdESVersionRaw AVersion, TElXMLSPURIHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPURI_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLSPURIHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSPURI_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLSPURIHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSPURI */

#ifdef SB_USE_CLASS_TELXMLSIGPOLICYQUALIFIER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigPolicyQualifier_Create(TSBXAdESVersionRaw AVersion, TElXMLSigPolicyQualifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigPolicyQualifier_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLSigPolicyQualifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigPolicyQualifier_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLSigPolicyQualifierHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGPOLICYQUALIFIER */

#ifdef SB_USE_CLASS_TELXMLSIGNATUREPOLICYID
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyId_Assign(TElXMLSignaturePolicyIdHandle _Handle, TElXMLAdESElementHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyId_Clear(TElXMLSignaturePolicyIdHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyId_IsEmpty(TElXMLSignaturePolicyIdHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyId_LoadFromXML(TElXMLSignaturePolicyIdHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyId_SaveToXML(TElXMLSignaturePolicyIdHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyId_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyId_get_SigPolicyId(TElXMLSignaturePolicyIdHandle _Handle, TElXMLObjectIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyId_get_SigPolicyHash(TElXMLSignaturePolicyIdHandle _Handle, TElXMLDigestAlgAndValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyId_get_SigPolicyQualifiers(TElXMLSignaturePolicyIdHandle _Handle, TElXMLAnyTypeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyId_get_TransformChain(TElXMLSignaturePolicyIdHandle _Handle, TElXMLTransformChainHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyId_Create(TSBXAdESVersionRaw AVersion, TElXMLSignaturePolicyIdHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyId_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLSignaturePolicyIdHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyId_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLSignaturePolicyIdHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNATUREPOLICYID */

#ifdef SB_USE_CLASS_TELXMLSIGNATUREPOLICYIDENTIFIER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyIdentifier_Assign(TElXMLSignaturePolicyIdentifierHandle _Handle, TElXMLAdESElementHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyIdentifier_Clear(TElXMLSignaturePolicyIdentifierHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyIdentifier_IsEmpty(TElXMLSignaturePolicyIdentifierHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyIdentifier_LoadFromXML(TElXMLSignaturePolicyIdentifierHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyIdentifier_SaveToXML(TElXMLSignaturePolicyIdentifierHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyIdentifier_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyIdentifier_get_SignaturePolicyId(TElXMLSignaturePolicyIdentifierHandle _Handle, TElXMLSignaturePolicyIdHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyIdentifier_set_SignaturePolicyId(TElXMLSignaturePolicyIdentifierHandle _Handle, TElXMLSignaturePolicyIdHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyIdentifier_get_SignaturePolicyImplied(TElXMLSignaturePolicyIdentifierHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyIdentifier_set_SignaturePolicyImplied(TElXMLSignaturePolicyIdentifierHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyIdentifier_Create(TSBXAdESVersionRaw AVersion, TElXMLSignaturePolicyIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyIdentifier_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLSignaturePolicyIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignaturePolicyIdentifier_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLSignaturePolicyIdentifierHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNATUREPOLICYIDENTIFIER */

#ifdef SB_USE_CLASS_TELXMLCOUNTERSIGNATURE
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignature_Clear(TElXMLCounterSignatureHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignature_IsEmpty(TElXMLCounterSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignature_LoadFromXML(TElXMLCounterSignatureHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignature_SaveToXML(TElXMLCounterSignatureHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignature_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignature_get_Signature(TElXMLCounterSignatureHandle _Handle, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignature_set_Signature(TElXMLCounterSignatureHandle _Handle, TElXMLDOMElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignature_Create(TSBXAdESVersionRaw AVersion, TElXMLCounterSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignature_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLCounterSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignature_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLCounterSignatureHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCOUNTERSIGNATURE */

#ifdef SB_USE_CLASS_TELXMLCOUNTERSIGNATURELIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignatureList_Add(TElXMLCounterSignatureListHandle _Handle, TElXMLCounterSignatureHandle ACounterSignature, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignatureList_Insert(TElXMLCounterSignatureListHandle _Handle, int32_t Index, TElXMLCounterSignatureHandle ACounterSignature);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignatureList_Delete(TElXMLCounterSignatureListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignatureList_Clear(TElXMLCounterSignatureListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignatureList_get_Count(TElXMLCounterSignatureListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignatureList_get_CounterSignature(TElXMLCounterSignatureListHandle _Handle, int32_t Index, TElXMLCounterSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCounterSignatureList_Create(TElXMLCounterSignatureListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCOUNTERSIGNATURELIST */

#ifdef SB_USE_CLASS_TELXMLDATAOBJECTFORMAT
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_Clear(TElXMLDataObjectFormatHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_IsEmpty(TElXMLDataObjectFormatHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_LoadFromXML(TElXMLDataObjectFormatHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_SaveToXML(TElXMLDataObjectFormatHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_get_Description(TElXMLDataObjectFormatHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_set_Description(TElXMLDataObjectFormatHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_get_ObjectIdentifier(TElXMLDataObjectFormatHandle _Handle, TElXMLObjectIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_set_ObjectIdentifier(TElXMLDataObjectFormatHandle _Handle, TElXMLObjectIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_get_MimeType(TElXMLDataObjectFormatHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_set_MimeType(TElXMLDataObjectFormatHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_get_Encoding(TElXMLDataObjectFormatHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_set_Encoding(TElXMLDataObjectFormatHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_get_ObjectReference(TElXMLDataObjectFormatHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_set_ObjectReference(TElXMLDataObjectFormatHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_Create(TSBXAdESVersionRaw AVersion, TElXMLDataObjectFormatHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLDataObjectFormatHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormat_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLDataObjectFormatHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDATAOBJECTFORMAT */

#ifdef SB_USE_CLASS_TELXMLDATAOBJECTFORMATLIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormatList_Add(TElXMLDataObjectFormatListHandle _Handle, TElXMLDataObjectFormatHandle ADataObjectFormat, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormatList_Insert(TElXMLDataObjectFormatListHandle _Handle, int32_t Index, TElXMLDataObjectFormatHandle ADataObjectFormat);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormatList_Delete(TElXMLDataObjectFormatListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormatList_Clear(TElXMLDataObjectFormatListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormatList_get_Count(TElXMLDataObjectFormatListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormatList_get_DataObjectFormat(TElXMLDataObjectFormatListHandle _Handle, int32_t Index, TElXMLDataObjectFormatHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDataObjectFormatList_Create(TElXMLDataObjectFormatListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDATAOBJECTFORMATLIST */

#ifdef SB_USE_CLASS_TELXMLCOMMITMENTTYPEQUALIFIER
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeQualifier_Create(TSBXAdESVersionRaw AVersion, TElXMLCommitmentTypeQualifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeQualifier_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLCommitmentTypeQualifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeQualifier_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLCommitmentTypeQualifierHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCOMMITMENTTYPEQUALIFIER */

#ifdef SB_USE_CLASS_TELXMLCOMMITMENTTYPEINDICATION
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndication_Clear(TElXMLCommitmentTypeIndicationHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndication_IsEmpty(TElXMLCommitmentTypeIndicationHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndication_LoadFromXML(TElXMLCommitmentTypeIndicationHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndication_SaveToXML(TElXMLCommitmentTypeIndicationHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndication_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndication_get_AllSignedDataObjects(TElXMLCommitmentTypeIndicationHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndication_set_AllSignedDataObjects(TElXMLCommitmentTypeIndicationHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndication_get_CommitmentTypeId(TElXMLCommitmentTypeIndicationHandle _Handle, TElXMLObjectIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndication_get_CommitmentTypeQualifiers(TElXMLCommitmentTypeIndicationHandle _Handle, TElXMLAnyTypeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndication_get_ObjectReference(TElXMLCommitmentTypeIndicationHandle _Handle, TStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndication_Create(TSBXAdESVersionRaw AVersion, TElXMLCommitmentTypeIndicationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndication_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLCommitmentTypeIndicationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndication_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLCommitmentTypeIndicationHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCOMMITMENTTYPEINDICATION */

#ifdef SB_USE_CLASS_TELXMLCOMMITMENTTYPEINDICATIONLIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndicationList_Add(TElXMLCommitmentTypeIndicationListHandle _Handle, TElXMLCommitmentTypeIndicationHandle ACommitmentTypeIndication, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndicationList_Insert(TElXMLCommitmentTypeIndicationListHandle _Handle, int32_t Index, TElXMLCommitmentTypeIndicationHandle ACommitmentTypeIndication);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndicationList_Delete(TElXMLCommitmentTypeIndicationListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndicationList_Clear(TElXMLCommitmentTypeIndicationListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndicationList_get_Count(TElXMLCommitmentTypeIndicationListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndicationList_get_CommitmentTypeIndication(TElXMLCommitmentTypeIndicationListHandle _Handle, int32_t Index, TElXMLCommitmentTypeIndicationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCommitmentTypeIndicationList_Create(TElXMLCommitmentTypeIndicationListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCOMMITMENTTYPEINDICATIONLIST */

#ifdef SB_USE_CLASS_TELXMLSIGNATUREPRODUCTIONPLACE
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_Assign(TElXMLSignatureProductionPlaceHandle _Handle, TElXMLAdESElementHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_Clear(TElXMLSignatureProductionPlaceHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_IsEmpty(TElXMLSignatureProductionPlaceHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_LoadFromXML(TElXMLSignatureProductionPlaceHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_SaveToXML(TElXMLSignatureProductionPlaceHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_get_City(TElXMLSignatureProductionPlaceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_set_City(TElXMLSignatureProductionPlaceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_get_StateOrProvince(TElXMLSignatureProductionPlaceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_set_StateOrProvince(TElXMLSignatureProductionPlaceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_get_PostalCode(TElXMLSignatureProductionPlaceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_set_PostalCode(TElXMLSignatureProductionPlaceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_get_CountryName(TElXMLSignatureProductionPlaceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_set_CountryName(TElXMLSignatureProductionPlaceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_Create(TSBXAdESVersionRaw AVersion, TElXMLSignatureProductionPlaceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLSignatureProductionPlaceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlace_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLSignatureProductionPlaceHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNATUREPRODUCTIONPLACE */

#ifdef SB_USE_CLASS_TELXMLSIGNATUREPRODUCTIONPLACEV2
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_Assign(TElXMLSignatureProductionPlaceV2Handle _Handle, TElXMLAdESElementHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_Clear(TElXMLSignatureProductionPlaceV2Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_IsEmpty(TElXMLSignatureProductionPlaceV2Handle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_LoadFromXML(TElXMLSignatureProductionPlaceV2Handle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_SaveToXML(TElXMLSignatureProductionPlaceV2Handle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_get_StreetAddress(TElXMLSignatureProductionPlaceV2Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_set_StreetAddress(TElXMLSignatureProductionPlaceV2Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_get_City(TElXMLSignatureProductionPlaceV2Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_set_City(TElXMLSignatureProductionPlaceV2Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_get_StateOrProvince(TElXMLSignatureProductionPlaceV2Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_set_StateOrProvince(TElXMLSignatureProductionPlaceV2Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_get_PostalCode(TElXMLSignatureProductionPlaceV2Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_set_PostalCode(TElXMLSignatureProductionPlaceV2Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_get_CountryName(TElXMLSignatureProductionPlaceV2Handle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_set_CountryName(TElXMLSignatureProductionPlaceV2Handle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_Create(TSBXAdESVersionRaw AVersion, TElXMLSignatureProductionPlaceV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLSignatureProductionPlaceV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProductionPlaceV2_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLSignatureProductionPlaceV2Handle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNATUREPRODUCTIONPLACEV2 */

#ifdef SB_USE_CLASS_TELXMLENCAPSULATEDX509CERTIFICATES
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedX509Certificates_AddCertificate(TElXMLEncapsulatedX509CertificatesHandle _Handle, TElX509CertificateHandle ACert, TSBXAdESVersionRaw AXAdESVersion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedX509Certificates_Clear(TElXMLEncapsulatedX509CertificatesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedX509Certificates_get_Certificates(TElXMLEncapsulatedX509CertificatesHandle _Handle, int32_t Index, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedX509Certificates_Create(TElXMLEncapsulatedX509CertificatesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLENCAPSULATEDX509CERTIFICATES */

#ifdef SB_USE_CLASS_TELXMLCERTIFIEDROLE
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRole_Create(TSBXAdESVersionRaw AVersion, TElXMLCertifiedRoleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRole_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLCertifiedRoleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRole_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLCertifiedRoleHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCERTIFIEDROLE */

#ifdef SB_USE_CLASS_TELXMLCERTIFIEDROLESLIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRolesList_Create(TElXMLEncapsulatedX509CertificatesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCERTIFIEDROLESLIST */

#ifdef SB_USE_CLASS_TELXMLCERTIFIEDROLEV2
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRoleV2_Assign(TElXMLCertifiedRoleV2Handle _Handle, TElXMLAdESElementHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRoleV2_Clear(TElXMLCertifiedRoleV2Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRoleV2_IsEmpty(TElXMLCertifiedRoleV2Handle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRoleV2_LoadFromXML(TElXMLCertifiedRoleV2Handle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRoleV2_SaveToXML(TElXMLCertifiedRoleV2Handle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRoleV2_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRoleV2_get_X509AttributeCertificate(TElXMLCertifiedRoleV2Handle _Handle, TElXMLEncapsulatedPKIDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRoleV2_get_OtherAttributeCertificate(TElXMLCertifiedRoleV2Handle _Handle, TElXMLAnyTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRoleV2_Create(TSBXAdESVersionRaw AVersion, TElXMLCertifiedRoleV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRoleV2_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLCertifiedRoleV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRoleV2_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLCertifiedRoleV2Handle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCERTIFIEDROLEV2 */

#ifdef SB_USE_CLASS_TELXMLCERTIFIEDROLESLISTV2
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRolesListV2_Assign(TElXMLCertifiedRolesListV2Handle _Handle, TElXMLCertifiedRolesListV2Handle Source, TSBXAdESVersionRaw AVersion);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRolesListV2_AddCertificate(TElXMLCertifiedRolesListV2Handle _Handle, TElX509CertificateHandle ACert, TSBXAdESVersionRaw AXAdESVersion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRolesListV2_Add(TElXMLCertifiedRolesListV2Handle _Handle, TElXMLCertifiedRoleV2Handle ARole, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRolesListV2_Insert(TElXMLCertifiedRolesListV2Handle _Handle, int32_t Index, TElXMLCertifiedRoleV2Handle ARole);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRolesListV2_Delete(TElXMLCertifiedRolesListV2Handle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRolesListV2_Clear(TElXMLCertifiedRolesListV2Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRolesListV2_get_Count(TElXMLCertifiedRolesListV2Handle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRolesListV2_get_CertifiedRoles(TElXMLCertifiedRolesListV2Handle _Handle, int32_t Index, TElXMLCertifiedRoleV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRolesListV2_get_Certificates(TElXMLCertifiedRolesListV2Handle _Handle, int32_t Index, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertifiedRolesListV2_Create(TElXMLCertifiedRolesListV2Handle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCERTIFIEDROLESLISTV2 */

#ifdef SB_USE_CLASS_TELXMLCLAIMEDROLE
SB_IMPORT uint32_t SB_APIENTRY TElXMLClaimedRole_Create(TSBXAdESVersionRaw AVersion, TElXMLClaimedRoleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLClaimedRole_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLClaimedRoleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLClaimedRole_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLClaimedRoleHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCLAIMEDROLE */

#ifdef SB_USE_CLASS_TELXMLCLAIMEDROLESLIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLClaimedRolesList_AddText(TElXMLClaimedRolesListHandle _Handle, TSBXAdESVersionRaw AVersion, TElXMLDOMDocumentHandle OwnerDocument, const char * pcText, int32_t szText, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLClaimedRolesList_Create(TElXMLAnyTypeListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCLAIMEDROLESLIST */

#ifdef SB_USE_CLASS_TELXMLSIGNEDASSERTION
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedAssertion_Create(TSBXAdESVersionRaw AVersion, TElXMLSignedAssertionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedAssertion_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLSignedAssertionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedAssertion_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLSignedAssertionHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNEDASSERTION */

#ifdef SB_USE_CLASS_TELXMLSIGNEDASSERTIONSLIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedAssertionsList_Create(TElXMLAnyTypeListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNEDASSERTIONSLIST */

#ifdef SB_USE_CLASS_TELXMLSIGNERROLE
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRole_Assign(TElXMLSignerRoleHandle _Handle, TElXMLAdESElementHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRole_Clear(TElXMLSignerRoleHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRole_IsEmpty(TElXMLSignerRoleHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRole_LoadFromXML(TElXMLSignerRoleHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRole_SaveToXML(TElXMLSignerRoleHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRole_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRole_get_ClaimedRoles(TElXMLSignerRoleHandle _Handle, TElXMLClaimedRolesListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRole_get_CertifiedRoles(TElXMLSignerRoleHandle _Handle, TElXMLCertifiedRolesListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRole_Create(TSBXAdESVersionRaw AVersion, TElXMLSignerRoleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRole_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLSignerRoleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRole_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLSignerRoleHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNERROLE */

#ifdef SB_USE_CLASS_TELXMLSIGNERROLEV2
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRoleV2_Assign(TElXMLSignerRoleV2Handle _Handle, TElXMLAdESElementHandle Source);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRoleV2_Clear(TElXMLSignerRoleV2Handle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRoleV2_IsEmpty(TElXMLSignerRoleV2Handle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRoleV2_LoadFromXML(TElXMLSignerRoleV2Handle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRoleV2_SaveToXML(TElXMLSignerRoleV2Handle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRoleV2_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRoleV2_get_ClaimedRoles(TElXMLSignerRoleV2Handle _Handle, TElXMLClaimedRolesListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRoleV2_get_CertifiedRolesV2(TElXMLSignerRoleV2Handle _Handle, TElXMLCertifiedRolesListV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRoleV2_get_SignedAssertions(TElXMLSignerRoleV2Handle _Handle, TElXMLSignedAssertionsListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRoleV2_Create(TSBXAdESVersionRaw AVersion, TElXMLSignerRoleV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRoleV2_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLSignerRoleV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignerRoleV2_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLSignerRoleV2Handle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNERROLEV2 */

#ifdef SB_USE_CLASS_TELXMLCOMPLETECERTIFICATEREFS
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteCertificateRefs_Clear(TElXMLCompleteCertificateRefsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteCertificateRefs_IsEmpty(TElXMLCompleteCertificateRefsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteCertificateRefs_LoadFromXML(TElXMLCompleteCertificateRefsHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteCertificateRefs_SaveToXML(TElXMLCompleteCertificateRefsHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteCertificateRefs_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteCertificateRefs_get_ID(TElXMLCompleteCertificateRefsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteCertificateRefs_set_ID(TElXMLCompleteCertificateRefsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteCertificateRefs_get_CertRefs(TElXMLCompleteCertificateRefsHandle _Handle, TElXMLCertIDListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteCertificateRefs_Create(TSBXAdESVersionRaw AVersion, TElXMLCompleteCertificateRefsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteCertificateRefs_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLCompleteCertificateRefsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteCertificateRefs_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLCompleteCertificateRefsHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCOMPLETECERTIFICATEREFS */

#ifdef SB_USE_CLASS_TELXMLCRLIDENTIFIER
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_Clear(TElXMLCRLIdentifierHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_IsEmpty(TElXMLCRLIdentifierHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_LoadFromXML(TElXMLCRLIdentifierHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_SaveToXML(TElXMLCRLIdentifierHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_get_Issuer(TElXMLCRLIdentifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_set_Issuer(TElXMLCRLIdentifierHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_get_IssueTime(TElXMLCRLIdentifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_set_IssueTime(TElXMLCRLIdentifierHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_get_IssueTimeUTC(TElXMLCRLIdentifierHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_set_IssueTimeUTC(TElXMLCRLIdentifierHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_get_Number(TElXMLCRLIdentifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_set_Number(TElXMLCRLIdentifierHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_get_URI(TElXMLCRLIdentifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_set_URI(TElXMLCRLIdentifierHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_Create(TSBXAdESVersionRaw AVersion, TElXMLCRLIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLCRLIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLIdentifier_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLCRLIdentifierHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCRLIDENTIFIER */

#ifdef SB_USE_CLASS_TELXMLCRLREF
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRef_Clear(TElXMLCRLRefHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRef_IsEmpty(TElXMLCRLRefHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRef_IsMatch(TElXMLCRLRefHandle _Handle, TElAbstractCRLHandle ACRL, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRef_LoadFromXML(TElXMLCRLRefHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRef_SaveToXML(TElXMLCRLRefHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRef_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRef_get_DigestAlgAndValue(TElXMLCRLRefHandle _Handle, TElXMLDigestAlgAndValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRef_get_CRLIdentifier(TElXMLCRLRefHandle _Handle, TElXMLCRLIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRef_set_CRLIdentifier(TElXMLCRLRefHandle _Handle, TElXMLCRLIdentifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRef_Create(TSBXAdESVersionRaw AVersion, TElXMLCRLRefHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRef_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLCRLRefHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRef_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLCRLRefHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCRLREF */

#ifdef SB_USE_CLASS_TELXMLCRLREFS
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRefs_AddCRL(TElXMLCRLRefsHandle _Handle, TElAbstractCRLHandle ACRL, TSBXAdESVersionRaw AXAdESVersion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRefs_AddCRL_1(TElXMLCRLRefsHandle _Handle, TElAbstractCRLHandle ACRL, TElXMLDigestMethodRaw DigestMethod, TSBXAdESVersionRaw AXAdESVersion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRefs_Add(TElXMLCRLRefsHandle _Handle, TElXMLCRLRefHandle ACRLRef, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRefs_Insert(TElXMLCRLRefsHandle _Handle, int32_t Index, TElXMLCRLRefHandle ACRLRef);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRefs_Delete(TElXMLCRLRefsHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRefs_Clear(TElXMLCRLRefsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRefs_get_Count(TElXMLCRLRefsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRefs_get_CRLRef(TElXMLCRLRefsHandle _Handle, int32_t Index, TElXMLCRLRefHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLRefs_Create(TElXMLCRLRefsHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCRLREFS */

#ifdef SB_USE_CLASS_TELXMLOCSPIDENTIFIER
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_Clear(TElXMLOCSPIdentifierHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_IsEmpty(TElXMLOCSPIdentifierHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_LoadFromXML(TElXMLOCSPIdentifierHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_SaveToXML(TElXMLOCSPIdentifierHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_get_ResponderID(TElXMLOCSPIdentifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_set_ResponderID(TElXMLOCSPIdentifierHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_get_ProducedAt(TElXMLOCSPIdentifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_set_ProducedAt(TElXMLOCSPIdentifierHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_get_ProducedAtUTC(TElXMLOCSPIdentifierHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_set_ProducedAtUTC(TElXMLOCSPIdentifierHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_get_URI(TElXMLOCSPIdentifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_set_URI(TElXMLOCSPIdentifierHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_get_ResponderIDType(TElXMLOCSPIdentifierHandle _Handle, TSBXAdESResponderIDTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_set_ResponderIDType(TElXMLOCSPIdentifierHandle _Handle, TSBXAdESResponderIDTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_Create(TSBXAdESVersionRaw AVersion, TElXMLOCSPIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLOCSPIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPIdentifier_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLOCSPIdentifierHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLOCSPIDENTIFIER */

#ifdef SB_USE_CLASS_TELXMLOCSPREF
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRef_Clear(TElXMLOCSPRefHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRef_IsEmpty(TElXMLOCSPRefHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRef_LoadFromXML(TElXMLOCSPRefHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRef_SaveToXML(TElXMLOCSPRefHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRef_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRef_IsMatch(TElXMLOCSPRefHandle _Handle, TElOCSPResponseHandle OCSPResponse, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRef_get_DigestAlgAndValue(TElXMLOCSPRefHandle _Handle, TElXMLDigestAlgAndValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRef_set_DigestAlgAndValue(TElXMLOCSPRefHandle _Handle, TElXMLDigestAlgAndValueHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRef_get_OCSPIdentifier(TElXMLOCSPRefHandle _Handle, TElXMLOCSPIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRef_Create(TSBXAdESVersionRaw AVersion, TElXMLOCSPRefHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRef_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLOCSPRefHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRef_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLOCSPRefHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLOCSPREF */

#ifdef SB_USE_CLASS_TELXMLOCSPREFS
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRefs_AddOCSP(TElXMLOCSPRefsHandle _Handle, TElOCSPResponseHandle OCSPResponse, int8_t ByKey, TSBXAdESVersionRaw AXAdESVersion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRefs_AddOCSP_1(TElXMLOCSPRefsHandle _Handle, TElOCSPResponseHandle OCSPResponse, int8_t ByKey, TElXMLDigestMethodRaw DigestMethod, TSBXAdESVersionRaw AXAdESVersion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRefs_Add(TElXMLOCSPRefsHandle _Handle, TElXMLOCSPRefHandle AOCSPRef, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRefs_Insert(TElXMLOCSPRefsHandle _Handle, int32_t Index, TElXMLOCSPRefHandle AOCSPRef);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRefs_Delete(TElXMLOCSPRefsHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRefs_Clear(TElXMLOCSPRefsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRefs_get_Count(TElXMLOCSPRefsHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRefs_get_OCSPRef(TElXMLOCSPRefsHandle _Handle, int32_t Index, TElXMLOCSPRefHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPRefs_Create(TElXMLOCSPRefsHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLOCSPREFS */

#ifdef SB_USE_CLASS_TELXMLOTHERREF
SB_IMPORT uint32_t SB_APIENTRY TElXMLOtherRef_Create(TSBXAdESVersionRaw AVersion, TElXMLOtherRefHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOtherRef_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLOtherRefHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOtherRef_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLOtherRefHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLOTHERREF */

#ifdef SB_USE_CLASS_TELXMLCOMPLETEREVOCATIONREFS
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteRevocationRefs_Clear(TElXMLCompleteRevocationRefsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteRevocationRefs_IsEmpty(TElXMLCompleteRevocationRefsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteRevocationRefs_LoadFromXML(TElXMLCompleteRevocationRefsHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteRevocationRefs_SaveToXML(TElXMLCompleteRevocationRefsHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteRevocationRefs_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteRevocationRefs_get_ID(TElXMLCompleteRevocationRefsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteRevocationRefs_set_ID(TElXMLCompleteRevocationRefsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteRevocationRefs_get_CRLRefs(TElXMLCompleteRevocationRefsHandle _Handle, TElXMLCRLRefsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteRevocationRefs_get_OCSPRefs(TElXMLCompleteRevocationRefsHandle _Handle, TElXMLOCSPRefsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteRevocationRefs_get_OtherRefs(TElXMLCompleteRevocationRefsHandle _Handle, TElXMLAnyTypeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteRevocationRefs_Create(TSBXAdESVersionRaw AVersion, TElXMLCompleteRevocationRefsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteRevocationRefs_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLCompleteRevocationRefsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCompleteRevocationRefs_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLCompleteRevocationRefsHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCOMPLETEREVOCATIONREFS */

#ifdef SB_USE_CLASS_TELXMLCERTIFICATEVALUES
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertificateValues_Clear(TElXMLCertificateValuesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertificateValues_IsEmpty(TElXMLCertificateValuesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertificateValues_LoadFromXML(TElXMLCertificateValuesHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertificateValues_SaveToXML(TElXMLCertificateValuesHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertificateValues_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertificateValues_get_ID(TElXMLCertificateValuesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertificateValues_set_ID(TElXMLCertificateValuesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertificateValues_get_EncapsulatedX509Certificates(TElXMLCertificateValuesHandle _Handle, TElXMLEncapsulatedX509CertificatesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertificateValues_get_OtherCertificates(TElXMLCertificateValuesHandle _Handle, TElXMLAnyTypeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertificateValues_Create(TSBXAdESVersionRaw AVersion, TElXMLCertificateValuesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertificateValues_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLCertificateValuesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCertificateValues_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLCertificateValuesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCERTIFICATEVALUES */

#ifdef SB_USE_CLASS_TELXMLENCAPSULATEDCRLVALUE
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedCRLValue_Create(TSBXAdESVersionRaw AVersion, TElXMLEncapsulatedCRLValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedCRLValue_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLEncapsulatedCRLValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedCRLValue_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLEncapsulatedCRLValueHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLENCAPSULATEDCRLVALUE */

#ifdef SB_USE_CLASS_TELXMLCRLVALUES
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLValues_AddCRL(TElXMLCRLValuesHandle _Handle, TElAbstractCRLHandle ACRL, TSBXAdESVersionRaw AXAdESVersion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLValues_Clear(TElXMLCRLValuesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLValues_get_CRLs(TElXMLCRLValuesHandle _Handle, int32_t Index, TElAbstractCRLHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCRLValues_Create(TElXMLCRLValuesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCRLVALUES */

#ifdef SB_USE_CLASS_TELXMLENCAPSULATEDOCSPVALUE
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedOCSPValue_Create(TSBXAdESVersionRaw AVersion, TElXMLEncapsulatedOCSPValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedOCSPValue_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLEncapsulatedOCSPValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncapsulatedOCSPValue_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLEncapsulatedOCSPValueHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLENCAPSULATEDOCSPVALUE */

#ifdef SB_USE_CLASS_TELXMLOCSPVALUES
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPValues_AddOCSPResponse(TElXMLOCSPValuesHandle _Handle, TElOCSPResponseHandle AOCSPResponse, TSBXAdESVersionRaw AXAdESVersion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPValues_Clear(TElXMLOCSPValuesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPValues_get_OCSPResponses(TElXMLOCSPValuesHandle _Handle, int32_t Index, TElOCSPResponseHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLOCSPValues_Create(TElXMLOCSPValuesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLOCSPVALUES */

#ifdef SB_USE_CLASS_TELXMLREVOCATIONVALUES
SB_IMPORT uint32_t SB_APIENTRY TElXMLRevocationValues_Clear(TElXMLRevocationValuesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRevocationValues_IsEmpty(TElXMLRevocationValuesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRevocationValues_LoadFromXML(TElXMLRevocationValuesHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRevocationValues_SaveToXML(TElXMLRevocationValuesHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRevocationValues_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRevocationValues_get_ID(TElXMLRevocationValuesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRevocationValues_set_ID(TElXMLRevocationValuesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRevocationValues_get_CRLValues(TElXMLRevocationValuesHandle _Handle, TElXMLCRLValuesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRevocationValues_get_OCSPValues(TElXMLRevocationValuesHandle _Handle, TElXMLOCSPValuesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRevocationValues_get_OtherValues(TElXMLRevocationValuesHandle _Handle, TElXMLAnyTypeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRevocationValues_Create(TSBXAdESVersionRaw AVersion, TElXMLRevocationValuesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRevocationValues_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLRevocationValuesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRevocationValues_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLRevocationValuesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLREVOCATIONVALUES */

#ifdef SB_USE_CLASS_TELXMLTIMESTAMPVALIDATIONDATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_Clear(TElXMLTimeStampValidationDataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_IsEmpty(TElXMLTimeStampValidationDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_LoadFromXML(TElXMLTimeStampValidationDataHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_SaveToXML(TElXMLTimeStampValidationDataHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_get_ID(TElXMLTimeStampValidationDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_set_ID(TElXMLTimeStampValidationDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_get_URI(TElXMLTimeStampValidationDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_set_URI(TElXMLTimeStampValidationDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_get_CertificateValues(TElXMLTimeStampValidationDataHandle _Handle, TElXMLCertificateValuesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_set_CertificateValues(TElXMLTimeStampValidationDataHandle _Handle, TElXMLCertificateValuesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_get_RevocationValues(TElXMLTimeStampValidationDataHandle _Handle, TElXMLRevocationValuesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_set_RevocationValues(TElXMLTimeStampValidationDataHandle _Handle, TElXMLRevocationValuesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_Create(TSBXAdESVersionRaw AVersion, TElXMLTimeStampValidationDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLTimeStampValidationDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationData_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLTimeStampValidationDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLTIMESTAMPVALIDATIONDATA */

#ifdef SB_USE_CLASS_TELXMLTIMESTAMPVALIDATIONDATALIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationDataList_Add(TElXMLTimeStampValidationDataListHandle _Handle, TElXMLTimeStampValidationDataHandle ATSPValidationData, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationDataList_Insert(TElXMLTimeStampValidationDataListHandle _Handle, int32_t Index, TElXMLTimeStampValidationDataHandle ATSPValidationData);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationDataList_Delete(TElXMLTimeStampValidationDataListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationDataList_Clear(TElXMLTimeStampValidationDataListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationDataList_get_Count(TElXMLTimeStampValidationDataListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationDataList_get_TimeStampValidationData(TElXMLTimeStampValidationDataListHandle _Handle, int32_t Index, TElXMLTimeStampValidationDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLTimeStampValidationDataList_Create(TElXMLTimeStampValidationDataListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLTIMESTAMPVALIDATIONDATALIST */

#ifdef SB_USE_CLASS_TELXMLSIGNEDDATAOBJECTPROPERTIES
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedDataObjectProperties_Clear(TElXMLSignedDataObjectPropertiesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedDataObjectProperties_IsEmpty(TElXMLSignedDataObjectPropertiesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedDataObjectProperties_LoadFromXML(TElXMLSignedDataObjectPropertiesHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedDataObjectProperties_SaveToXML(TElXMLSignedDataObjectPropertiesHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedDataObjectProperties_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedDataObjectProperties_get_DataObjectFormats(TElXMLSignedDataObjectPropertiesHandle _Handle, TElXMLDataObjectFormatListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedDataObjectProperties_get_CommitmentTypeIndications(TElXMLSignedDataObjectPropertiesHandle _Handle, TElXMLCommitmentTypeIndicationListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedDataObjectProperties_get_AllDataObjectsTimestamps(TElXMLSignedDataObjectPropertiesHandle _Handle, TElXMLCustomTimestampListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedDataObjectProperties_get_IndividualDataObjectsTimestamps(TElXMLSignedDataObjectPropertiesHandle _Handle, TElXMLCustomTimestampListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedDataObjectProperties_get_ID(TElXMLSignedDataObjectPropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedDataObjectProperties_set_ID(TElXMLSignedDataObjectPropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedDataObjectProperties_Create(TSBXAdESVersionRaw AVersion, TElXMLSignedDataObjectPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedDataObjectProperties_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLSignedDataObjectPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedDataObjectProperties_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLSignedDataObjectPropertiesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNEDDATAOBJECTPROPERTIES */

#ifdef SB_USE_CLASS_TELXMLUNSIGNEDDATAOBJECTPROPERTY
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedDataObjectProperty_Create(TSBXAdESVersionRaw AVersion, TElXMLUnsignedDataObjectPropertyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedDataObjectProperty_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLUnsignedDataObjectPropertyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedDataObjectProperty_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLUnsignedDataObjectPropertyHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLUNSIGNEDDATAOBJECTPROPERTY */

#ifdef SB_USE_CLASS_TELXMLSIGNEDSIGNATUREPROPERTIES
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_Clear(TElXMLSignedSignaturePropertiesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_IsEmpty(TElXMLSignedSignaturePropertiesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_LoadFromXML(TElXMLSignedSignaturePropertiesHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_SaveToXML(TElXMLSignedSignaturePropertiesHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_get_SignedTime(TElXMLSignedSignaturePropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_set_SignedTime(TElXMLSignedSignaturePropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_get_SignedTimeUTC(TElXMLSignedSignaturePropertiesHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_set_SignedTimeUTC(TElXMLSignedSignaturePropertiesHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_get_SigningCertificate(TElXMLSignedSignaturePropertiesHandle _Handle, TElXMLCertIDListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_get_SignaturePolicyIdentifier(TElXMLSignedSignaturePropertiesHandle _Handle, TElXMLSignaturePolicyIdentifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_get_SignatureProductionPlace(TElXMLSignedSignaturePropertiesHandle _Handle, TElXMLSignatureProductionPlaceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_set_SignatureProductionPlace(TElXMLSignedSignaturePropertiesHandle _Handle, TElXMLSignatureProductionPlaceHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_get_SignerRole(TElXMLSignedSignaturePropertiesHandle _Handle, TElXMLSignerRoleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_set_SignerRole(TElXMLSignedSignaturePropertiesHandle _Handle, TElXMLSignerRoleHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_get_ID(TElXMLSignedSignaturePropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_set_ID(TElXMLSignedSignaturePropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_get_SigningCertificateV2(TElXMLSignedSignaturePropertiesHandle _Handle, TElXMLCertIDListV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_get_SignatureProductionPlaceV2(TElXMLSignedSignaturePropertiesHandle _Handle, TElXMLSignatureProductionPlaceV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_set_SignatureProductionPlaceV2(TElXMLSignedSignaturePropertiesHandle _Handle, TElXMLSignatureProductionPlaceV2Handle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_get_SignerRoleV2(TElXMLSignedSignaturePropertiesHandle _Handle, TElXMLSignerRoleV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_set_SignerRoleV2(TElXMLSignedSignaturePropertiesHandle _Handle, TElXMLSignerRoleV2Handle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_Create(TSBXAdESVersionRaw AVersion, TElXMLSignedSignaturePropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLSignedSignaturePropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedSignatureProperties_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLSignedSignaturePropertiesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNEDSIGNATUREPROPERTIES */

#ifdef SB_USE_CLASS_TELXMLUNSIGNEDSIGNATUREPROPERTIES
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_Clear(TElXMLUnsignedSignaturePropertiesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_IsEmpty(TElXMLUnsignedSignaturePropertiesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_LoadFromXML(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_SaveToXML(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_XAdESForm(TElXMLUnsignedSignaturePropertiesHandle _Handle, TSBXAdESFormRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_set_XAdESForm(TElXMLUnsignedSignaturePropertiesHandle _Handle, TSBXAdESFormRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_ID(TElXMLUnsignedSignaturePropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_set_ID(TElXMLUnsignedSignaturePropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_CounterSignatures(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCounterSignatureListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_SignatureTimestamps(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCustomTimestampListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_CompleteCertificateRefs(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCompleteCertificateRefsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_set_CompleteCertificateRefs(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCompleteCertificateRefsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_CompleteRevocationRefs(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCompleteRevocationRefsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_set_CompleteRevocationRefs(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCompleteRevocationRefsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_AttributeCertificateRefs(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCompleteCertificateRefsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_set_AttributeCertificateRefs(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCompleteCertificateRefsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_AttributeRevocationRefs(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCompleteRevocationRefsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_set_AttributeRevocationRefs(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCompleteRevocationRefsHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_SigAndRefsTimestamps(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCustomTimestampListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_RefsOnlyTimestamps(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCustomTimestampListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_CertificateValues(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCertificateValuesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_set_CertificateValues(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCertificateValuesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_RevocationValues(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLRevocationValuesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_set_RevocationValues(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLRevocationValuesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_AttrAuthoritiesCertValues(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCertificateValuesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_set_AttrAuthoritiesCertValues(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCertificateValuesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_AttributeRevocationValues(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLRevocationValuesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_set_AttributeRevocationValues(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLRevocationValuesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_ArchiveTimestamps(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCustomTimestampListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_ArchiveTimestampsV141(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCustomTimestampListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_TimeStampValidationDataList(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLTimeStampValidationDataListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_CompleteCertificateRefsV2(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCertIDListV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_set_CompleteCertificateRefsV2(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCertIDListV2Handle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_AttributeCertificateRefsV2(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCertIDListV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_set_AttributeCertificateRefsV2(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCertIDListV2Handle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_SigAndRefsTimestampsV2(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCustomTimestampListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_get_RefsOnlyTimestampsV2(TElXMLUnsignedSignaturePropertiesHandle _Handle, TElXMLCustomTimestampListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_Create(TSBXAdESVersionRaw AVersion, TElXMLUnsignedSignaturePropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLUnsignedSignaturePropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedSignatureProperties_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLUnsignedSignaturePropertiesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLUNSIGNEDSIGNATUREPROPERTIES */

#ifdef SB_USE_CLASS_TELXMLSIGNEDPROPERTIES
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedProperties_Clear(TElXMLSignedPropertiesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedProperties_IsEmpty(TElXMLSignedPropertiesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedProperties_LoadFromXML(TElXMLSignedPropertiesHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedProperties_SaveToXML(TElXMLSignedPropertiesHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedProperties_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedProperties_get_ID(TElXMLSignedPropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedProperties_set_ID(TElXMLSignedPropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedProperties_get_SignedSignatureProperties(TElXMLSignedPropertiesHandle _Handle, TElXMLSignedSignaturePropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedProperties_set_SignedSignatureProperties(TElXMLSignedPropertiesHandle _Handle, TElXMLSignedSignaturePropertiesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedProperties_get_SignedDataObjectProperties(TElXMLSignedPropertiesHandle _Handle, TElXMLSignedDataObjectPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedProperties_set_SignedDataObjectProperties(TElXMLSignedPropertiesHandle _Handle, TElXMLSignedDataObjectPropertiesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedProperties_Create(TSBXAdESVersionRaw AVersion, TElXMLSignedPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedProperties_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLSignedPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedProperties_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLSignedPropertiesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNEDPROPERTIES */

#ifdef SB_USE_CLASS_TELXMLUNSIGNEDPROPERTIES
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedProperties_Clear(TElXMLUnsignedPropertiesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedProperties_IsEmpty(TElXMLUnsignedPropertiesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedProperties_LoadFromXML(TElXMLUnsignedPropertiesHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedProperties_SaveToXML(TElXMLUnsignedPropertiesHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedProperties_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedProperties_get_ID(TElXMLUnsignedPropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedProperties_set_ID(TElXMLUnsignedPropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedProperties_get_UnsignedSignatureProperties(TElXMLUnsignedPropertiesHandle _Handle, TElXMLUnsignedSignaturePropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedProperties_set_UnsignedSignatureProperties(TElXMLUnsignedPropertiesHandle _Handle, TElXMLUnsignedSignaturePropertiesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedProperties_get_UnsignedDataObjectProperties(TElXMLUnsignedPropertiesHandle _Handle, TElXMLAnyTypeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedProperties_Create(TSBXAdESVersionRaw AVersion, TElXMLUnsignedPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedProperties_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLUnsignedPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnsignedProperties_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLUnsignedPropertiesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLUNSIGNEDPROPERTIES */

#ifdef SB_USE_CLASS_TELXMLQUALIFYINGPROPERTIES
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_Clear(TElXMLQualifyingPropertiesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_IsEmpty(TElXMLQualifyingPropertiesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_LoadFromXML(TElXMLQualifyingPropertiesHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_SaveToXML(TElXMLQualifyingPropertiesHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_get_XAdESPrefix(TElXMLQualifyingPropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_set_XAdESPrefix(TElXMLQualifyingPropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_get_XAdESv141Prefix(TElXMLQualifyingPropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_set_XAdESv141Prefix(TElXMLQualifyingPropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_get_ID(TElXMLQualifyingPropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_set_ID(TElXMLQualifyingPropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_get_Target(TElXMLQualifyingPropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_set_Target(TElXMLQualifyingPropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_get_SignedProperties(TElXMLQualifyingPropertiesHandle _Handle, TElXMLSignedPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_set_SignedProperties(TElXMLQualifyingPropertiesHandle _Handle, TElXMLSignedPropertiesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_get_UnsignedProperties(TElXMLQualifyingPropertiesHandle _Handle, TElXMLUnsignedPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_set_UnsignedProperties(TElXMLQualifyingPropertiesHandle _Handle, TElXMLUnsignedPropertiesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_Create(TSBXAdESVersionRaw AVersion, TElXMLQualifyingPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLQualifyingPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingProperties_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLQualifyingPropertiesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLQUALIFYINGPROPERTIES */

#ifdef SB_USE_CLASS_TELXMLQUALIFYINGPROPERTIESREFERENCE
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_Clear(TElXMLQualifyingPropertiesReferenceHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_IsEmpty(TElXMLQualifyingPropertiesReferenceHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_LoadFromXML(TElXMLQualifyingPropertiesReferenceHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_SaveToXML(TElXMLQualifyingPropertiesReferenceHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_get_ID(TElXMLQualifyingPropertiesReferenceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_set_ID(TElXMLQualifyingPropertiesReferenceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_get_URI(TElXMLQualifyingPropertiesReferenceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_set_URI(TElXMLQualifyingPropertiesReferenceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_get_TransformChain(TElXMLQualifyingPropertiesReferenceHandle _Handle, TElXMLTransformChainHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_get_QualifyingProperties(TElXMLQualifyingPropertiesReferenceHandle _Handle, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_set_QualifyingProperties(TElXMLQualifyingPropertiesReferenceHandle _Handle, TElXMLDOMElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_Create(TSBXAdESVersionRaw AVersion, TElXMLQualifyingPropertiesReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_Create_1(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, TElXMLQualifyingPropertiesReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReference_Create_2(TSBXAdESVersionRaw AVersion, const char * pcAName, int32_t szAName, int8_t SupportedV141, TElXMLQualifyingPropertiesReferenceHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLQUALIFYINGPROPERTIESREFERENCE */

#ifdef SB_USE_CLASS_TELXMLQUALIFYINGPROPERTIESREFERENCELIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReferenceList_Add(TElXMLQualifyingPropertiesReferenceListHandle _Handle, TElXMLQualifyingPropertiesReferenceHandle AQualifyingPropertiesRef, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReferenceList_Insert(TElXMLQualifyingPropertiesReferenceListHandle _Handle, int32_t Index, TElXMLQualifyingPropertiesReferenceHandle AQualifyingPropertiesRef);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReferenceList_Delete(TElXMLQualifyingPropertiesReferenceListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReferenceList_Clear(TElXMLQualifyingPropertiesReferenceListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReferenceList_get_Count(TElXMLQualifyingPropertiesReferenceListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReferenceList_get_QualifyingPropertiesReference(TElXMLQualifyingPropertiesReferenceListHandle _Handle, int32_t Index, TElXMLQualifyingPropertiesReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLQualifyingPropertiesReferenceList_Create(TElXMLQualifyingPropertiesReferenceListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLQUALIFYINGPROPERTIESREFERENCELIST */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElXMLAdESElement_ce_ptr;
extern zend_class_entry *TElXMLAnyType_ce_ptr;
extern zend_class_entry *TElXMLAnyTypeList_ce_ptr;
extern zend_class_entry *TElXMLObjectIdentifier_ce_ptr;
extern zend_class_entry *TElXMLEncapsulatedPKIData_ce_ptr;
extern zend_class_entry *TElXMLEncapsulatedPKIDataList_ce_ptr;
extern zend_class_entry *TElXMLHashDataInfo_ce_ptr;
extern zend_class_entry *TElXMLHashDataInfoList_ce_ptr;
extern zend_class_entry *TElXMLCustomTimestamp_ce_ptr;
extern zend_class_entry *TElXMLCustomTimestampList_ce_ptr;
extern zend_class_entry *TElXMLTimestamp_ce_ptr;
extern zend_class_entry *TElXMLTimestampList_ce_ptr;
extern zend_class_entry *TElXMLInclude_ce_ptr;
extern zend_class_entry *TElXMLIncludeList_ce_ptr;
extern zend_class_entry *TElXMLTimestamp_v1_2_2_ce_ptr;
extern zend_class_entry *TElXMLTimestampList_v1_2_2_ce_ptr;
extern zend_class_entry *TElCustomTSPClientList_ce_ptr;
extern zend_class_entry *TElXMLGenericTimestamp_ce_ptr;
extern zend_class_entry *TElXMLGenericTimestampList_ce_ptr;
extern zend_class_entry *TElXMLDigestAlgAndValue_ce_ptr;
extern zend_class_entry *TElXMLCertID_ce_ptr;
extern zend_class_entry *TElXMLCertIDList_ce_ptr;
extern zend_class_entry *TElXMLCertIDV2_ce_ptr;
extern zend_class_entry *TElXMLCertIDListV2_ce_ptr;
extern zend_class_entry *TElXMLNoticeReference_ce_ptr;
extern zend_class_entry *TElXMLSPUserNotice_ce_ptr;
extern zend_class_entry *TElXMLSPURI_ce_ptr;
extern zend_class_entry *TElXMLSigPolicyQualifier_ce_ptr;
extern zend_class_entry *TElXMLSignaturePolicyId_ce_ptr;
extern zend_class_entry *TElXMLSignaturePolicyIdentifier_ce_ptr;
extern zend_class_entry *TElXMLCounterSignature_ce_ptr;
extern zend_class_entry *TElXMLCounterSignatureList_ce_ptr;
extern zend_class_entry *TElXMLDataObjectFormat_ce_ptr;
extern zend_class_entry *TElXMLDataObjectFormatList_ce_ptr;
extern zend_class_entry *TElXMLCommitmentTypeQualifier_ce_ptr;
extern zend_class_entry *TElXMLCommitmentTypeIndication_ce_ptr;
extern zend_class_entry *TElXMLCommitmentTypeIndicationList_ce_ptr;
extern zend_class_entry *TElXMLSignatureProductionPlace_ce_ptr;
extern zend_class_entry *TElXMLSignatureProductionPlaceV2_ce_ptr;
extern zend_class_entry *TElXMLEncapsulatedX509Certificates_ce_ptr;
extern zend_class_entry *TElXMLCertifiedRole_ce_ptr;
extern zend_class_entry *TElXMLCertifiedRolesList_ce_ptr;
extern zend_class_entry *TElXMLCertifiedRoleV2_ce_ptr;
extern zend_class_entry *TElXMLCertifiedRolesListV2_ce_ptr;
extern zend_class_entry *TElXMLClaimedRole_ce_ptr;
extern zend_class_entry *TElXMLClaimedRolesList_ce_ptr;
extern zend_class_entry *TElXMLSignedAssertion_ce_ptr;
extern zend_class_entry *TElXMLSignedAssertionsList_ce_ptr;
extern zend_class_entry *TElXMLSignerRole_ce_ptr;
extern zend_class_entry *TElXMLSignerRoleV2_ce_ptr;
extern zend_class_entry *TElXMLCompleteCertificateRefs_ce_ptr;
extern zend_class_entry *TElXMLCRLIdentifier_ce_ptr;
extern zend_class_entry *TElXMLCRLRef_ce_ptr;
extern zend_class_entry *TElXMLCRLRefs_ce_ptr;
extern zend_class_entry *TElXMLOCSPIdentifier_ce_ptr;
extern zend_class_entry *TElXMLOCSPRef_ce_ptr;
extern zend_class_entry *TElXMLOCSPRefs_ce_ptr;
extern zend_class_entry *TElXMLOtherRef_ce_ptr;
extern zend_class_entry *TElXMLCompleteRevocationRefs_ce_ptr;
extern zend_class_entry *TElXMLCertificateValues_ce_ptr;
extern zend_class_entry *TElXMLEncapsulatedCRLValue_ce_ptr;
extern zend_class_entry *TElXMLCRLValues_ce_ptr;
extern zend_class_entry *TElXMLEncapsulatedOCSPValue_ce_ptr;
extern zend_class_entry *TElXMLOCSPValues_ce_ptr;
extern zend_class_entry *TElXMLRevocationValues_ce_ptr;
extern zend_class_entry *TElXMLTimeStampValidationData_ce_ptr;
extern zend_class_entry *TElXMLTimeStampValidationDataList_ce_ptr;
extern zend_class_entry *TElXMLSignedDataObjectProperties_ce_ptr;
extern zend_class_entry *TElXMLUnsignedDataObjectProperty_ce_ptr;
extern zend_class_entry *TElXMLSignedSignatureProperties_ce_ptr;
extern zend_class_entry *TElXMLUnsignedSignatureProperties_ce_ptr;
extern zend_class_entry *TElXMLSignedProperties_ce_ptr;
extern zend_class_entry *TElXMLUnsignedProperties_ce_ptr;
extern zend_class_entry *TElXMLQualifyingProperties_ce_ptr;
extern zend_class_entry *TElXMLQualifyingPropertiesReference_ce_ptr;
extern zend_class_entry *TElXMLQualifyingPropertiesReferenceList_ce_ptr;

void Register_TElXMLAdESElement(TSRMLS_D);
void Register_TElXMLAnyType(TSRMLS_D);
void Register_TElXMLAnyTypeList(TSRMLS_D);
void Register_TElXMLObjectIdentifier(TSRMLS_D);
void Register_TElXMLEncapsulatedPKIData(TSRMLS_D);
void Register_TElXMLEncapsulatedPKIDataList(TSRMLS_D);
void Register_TElXMLHashDataInfo(TSRMLS_D);
void Register_TElXMLHashDataInfoList(TSRMLS_D);
void Register_TElXMLCustomTimestamp(TSRMLS_D);
void Register_TElXMLCustomTimestampList(TSRMLS_D);
void Register_TElXMLTimestamp(TSRMLS_D);
void Register_TElXMLTimestampList(TSRMLS_D);
void Register_TElXMLInclude(TSRMLS_D);
void Register_TElXMLIncludeList(TSRMLS_D);
void Register_TElXMLTimestamp_v1_2_2(TSRMLS_D);
void Register_TElXMLTimestampList_v1_2_2(TSRMLS_D);
void Register_TElCustomTSPClientList(TSRMLS_D);
void Register_TElXMLGenericTimestamp(TSRMLS_D);
void Register_TElXMLGenericTimestampList(TSRMLS_D);
void Register_TElXMLDigestAlgAndValue(TSRMLS_D);
void Register_TElXMLCertID(TSRMLS_D);
void Register_TElXMLCertIDList(TSRMLS_D);
void Register_TElXMLCertIDV2(TSRMLS_D);
void Register_TElXMLCertIDListV2(TSRMLS_D);
void Register_TElXMLNoticeReference(TSRMLS_D);
void Register_TElXMLSPUserNotice(TSRMLS_D);
void Register_TElXMLSPURI(TSRMLS_D);
void Register_TElXMLSigPolicyQualifier(TSRMLS_D);
void Register_TElXMLSignaturePolicyId(TSRMLS_D);
void Register_TElXMLSignaturePolicyIdentifier(TSRMLS_D);
void Register_TElXMLCounterSignature(TSRMLS_D);
void Register_TElXMLCounterSignatureList(TSRMLS_D);
void Register_TElXMLDataObjectFormat(TSRMLS_D);
void Register_TElXMLDataObjectFormatList(TSRMLS_D);
void Register_TElXMLCommitmentTypeQualifier(TSRMLS_D);
void Register_TElXMLCommitmentTypeIndication(TSRMLS_D);
void Register_TElXMLCommitmentTypeIndicationList(TSRMLS_D);
void Register_TElXMLSignatureProductionPlace(TSRMLS_D);
void Register_TElXMLSignatureProductionPlaceV2(TSRMLS_D);
void Register_TElXMLEncapsulatedX509Certificates(TSRMLS_D);
void Register_TElXMLCertifiedRole(TSRMLS_D);
void Register_TElXMLCertifiedRolesList(TSRMLS_D);
void Register_TElXMLCertifiedRoleV2(TSRMLS_D);
void Register_TElXMLCertifiedRolesListV2(TSRMLS_D);
void Register_TElXMLClaimedRole(TSRMLS_D);
void Register_TElXMLClaimedRolesList(TSRMLS_D);
void Register_TElXMLSignedAssertion(TSRMLS_D);
void Register_TElXMLSignedAssertionsList(TSRMLS_D);
void Register_TElXMLSignerRole(TSRMLS_D);
void Register_TElXMLSignerRoleV2(TSRMLS_D);
void Register_TElXMLCompleteCertificateRefs(TSRMLS_D);
void Register_TElXMLCRLIdentifier(TSRMLS_D);
void Register_TElXMLCRLRef(TSRMLS_D);
void Register_TElXMLCRLRefs(TSRMLS_D);
void Register_TElXMLOCSPIdentifier(TSRMLS_D);
void Register_TElXMLOCSPRef(TSRMLS_D);
void Register_TElXMLOCSPRefs(TSRMLS_D);
void Register_TElXMLOtherRef(TSRMLS_D);
void Register_TElXMLCompleteRevocationRefs(TSRMLS_D);
void Register_TElXMLCertificateValues(TSRMLS_D);
void Register_TElXMLEncapsulatedCRLValue(TSRMLS_D);
void Register_TElXMLCRLValues(TSRMLS_D);
void Register_TElXMLEncapsulatedOCSPValue(TSRMLS_D);
void Register_TElXMLOCSPValues(TSRMLS_D);
void Register_TElXMLRevocationValues(TSRMLS_D);
void Register_TElXMLTimeStampValidationData(TSRMLS_D);
void Register_TElXMLTimeStampValidationDataList(TSRMLS_D);
void Register_TElXMLSignedDataObjectProperties(TSRMLS_D);
void Register_TElXMLUnsignedDataObjectProperty(TSRMLS_D);
void Register_TElXMLSignedSignatureProperties(TSRMLS_D);
void Register_TElXMLUnsignedSignatureProperties(TSRMLS_D);
void Register_TElXMLSignedProperties(TSRMLS_D);
void Register_TElXMLUnsignedProperties(TSRMLS_D);
void Register_TElXMLQualifyingProperties(TSRMLS_D);
void Register_TElXMLQualifyingPropertiesReference(TSRMLS_D);
void Register_TElXMLQualifyingPropertiesReferenceList(TSRMLS_D);
SB_PHP_FUNCTION(SBXMLAdES, GetXAdESVersion);
SB_PHP_FUNCTION(SBXMLAdES, GetXAdESNamespaceURI);
SB_PHP_FUNCTION(SBXMLAdES, GetXAdESReferenceType);
SB_PHP_FUNCTION(SBXMLAdES, XAdESVersionToString);
SB_PHP_FUNCTION(SBXMLAdES, XAdESFormToString);
SB_PHP_FUNCTION(SBXMLAdES, XAdESFormGreaterThan);
SB_PHP_FUNCTION(SBXMLAdES, XAdESFormGreaterOrEqual);
SB_PHP_FUNCTION(SBXMLAdES, IsExtendedXAdESForm);
SB_PHP_FUNCTION(SBXMLAdES, XAdESFormToExtendedForm);
SB_PHP_FUNCTION(SBXMLAdES, XAdESFormToStandardForm);
void Register_SBXMLAdES_Constants(int module_number TSRMLS_DC);
void Register_SBXMLAdES_Enum_Flags(TSRMLS_D);
void Register_SBXMLAdES_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_XMLADES
SB_IMPORT uint32_t SB_APIENTRY SBXMLAdES_GetXAdESVersion(const char * pcNamespaceURI, int32_t szNamespaceURI, TSBXAdESVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLAdES_GetXAdESNamespaceURI(TSBXAdESVersionRaw Version, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLAdES_GetXAdESNamespaceURI_1(TSBXAdESVersionRaw Version, int8_t SupportedV141, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLAdES_GetXAdESReferenceType(TSBXAdESVersionRaw Version, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLAdES_XAdESVersionToString(TSBXAdESVersionRaw XAdESVersion, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLAdES_XAdESFormToString(TSBXAdESFormRaw XAdESForm, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLAdES_XAdESFormGreaterThan(TSBXAdESFormRaw XAdESForm, TSBXAdESFormRaw XAdESForm2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLAdES_XAdESFormGreaterOrEqual(TSBXAdESFormRaw XAdESForm, TSBXAdESFormRaw XAdESForm2, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLAdES_IsExtendedXAdESForm(TSBXAdESFormRaw XAdESForm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLAdES_XAdESFormToExtendedForm(TSBXAdESFormRaw XAdESForm, TSBXAdESFormRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLAdES_XAdESFormToStandardForm(TSBXAdESFormRaw XAdESForm, TSBXAdESFormRaw * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_XMLADES */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLADES */

