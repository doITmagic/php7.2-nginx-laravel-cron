#ifndef __INC_SBXMLADESINTF
#define __INC_SBXMLADESINTF

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbcryptoprov.h"
#include "sbcustomcertstorage.h"
#include "sbcertvalidator.h"
#include "sbcrl.h"
#include "sbcrlstorage.h"
#include "sbocspclient.h"
#include "sbtspclient.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbx509.h"
#include "sbx509ext.h"
#include "sbxmlades.h"
#include "sbxmlcore.h"
#include "sbxmldefs.h"
#include "sbxmlsec.h"
#include "sbxmlutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElXAdESProcessorHandle;

typedef TElXAdESProcessorHandle ElXAdESProcessorHandle;

typedef TElClassHandle TElXAdESSignerHandle;

typedef TElXAdESSignerHandle ElXAdESSignerHandle;

typedef TElClassHandle TElXAdESVerifierHandle;

typedef TElXAdESVerifierHandle ElXAdESVerifierHandle;

typedef uint8_t TElXAdESIncludedPropertyRaw;

typedef enum
{
	xipSignerRole = 0,
	xipProductionPlace = 1,
	xipSignerRoleV2 = 2,
	xipProductionPlaceV2 = 3
} TElXAdESIncludedProperty;

typedef uint32_t TElXAdESIncludedPropertiesRaw;

typedef enum 
{
	f_xipSignerRole = 1,
	f_xipProductionPlace = 2,
	f_xipSignerRoleV2 = 4,
	f_xipProductionPlaceV2 = 8
} TElXAdESIncludedProperties;

typedef TElXAdESIncludedProperty ElXAdESIncludedProperty;

typedef TElXAdESIncludedProperties ElXAdESIncludedProperties;

typedef uint8_t TSBXAdESOptionRaw;

typedef enum
{
	xoUseHexSerialNumber = 0
} TSBXAdESOption;

typedef uint32_t TSBXAdESOptionsRaw;

typedef enum 
{
	f_xoUseHexSerialNumber = 1
} TSBXAdESOptions;

typedef uint8_t TSBXAdESValidityRaw;

typedef enum
{
	xsvInvalid = 0,
	xsvIncomplete = 1,
	xsvValid = 2
} TSBXAdESValidity;

typedef uint8_t TSBXAdESValidityReasonRaw;

typedef enum
{
	xvrInternalError = 0,
	xvrNotSigned = 1,
	xvrNoSigningCertificate = 2,
	xvrSigningCertificateNotSigned = 3,
	xvrSigningCertificateIncomplete = 4,
	xvrSigningCertificateInvalid = 5,
	xvrInconsistentSigningCertificate = 6,
	xvrIndividualDataObjectsTimestampInvalid = 16,
	xvrIndividualDataObjectsTimestampIncomplete = 17,
	xvrAllDataObjectsTimestampInvalid = 18,
	xvrAllDataObjectsTimestampIncomplete = 19,
	xvrSignatureTimestampInvalid = 20,
	xvrSignatureTimestampIncomplete = 21,
	xvrRefsOnlyTimestampInvalid = 22,
	xvrRefsOnlyTimestampIncomplete = 23,
	xvrSigAndRefsTimestampInvalid = 24,
	xvrSigAndRefsTimestampIncomplete = 25,
	xvrArchiveTimestampInvalid = 26,
	xvrArchiveTimestampIncomplete = 27
} TSBXAdESValidityReason;

typedef uint32_t TSBXAdESValidityReasonsRaw;

typedef enum 
{
	f_xvrInternalError = 1,
	f_xvrNotSigned = 2,
	f_xvrNoSigningCertificate = 4,
	f_xvrSigningCertificateNotSigned = 8,
	f_xvrSigningCertificateIncomplete = 16,
	f_xvrSigningCertificateInvalid = 32,
	f_xvrInconsistentSigningCertificate = 64,
	f_xvrIndividualDataObjectsTimestampInvalid = 65536,
	f_xvrIndividualDataObjectsTimestampIncomplete = 131072,
	f_xvrAllDataObjectsTimestampInvalid = 262144,
	f_xvrAllDataObjectsTimestampIncomplete = 524288,
	f_xvrSignatureTimestampInvalid = 1048576,
	f_xvrSignatureTimestampIncomplete = 2097152,
	f_xvrRefsOnlyTimestampInvalid = 4194304,
	f_xvrRefsOnlyTimestampIncomplete = 8388608,
	f_xvrSigAndRefsTimestampInvalid = 16777216,
	f_xvrSigAndRefsTimestampIncomplete = 33554432,
	f_xvrArchiveTimestampInvalid = 67108864,
	f_xvrArchiveTimestampIncomplete = 134217728
} TSBXAdESValidityReasons;

typedef void (SB_CALLBACK *TSBXAdESCertificateNeededEvent)(void * _ObjectData, TObjectHandle Sender, TElCertificateLookupHandle Lookup, TElX509CertificateHandle * Cert);

typedef void (SB_CALLBACK *TSBXAdESBeforeCertificateValidateEvent)(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle Cert, TElX509CertificateValidatorHandle CertValidator);

typedef void (SB_CALLBACK *TSBXAdESAfterCertificateValidateEvent)(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle Cert, TElX509CertificateValidatorHandle CertValidator, TSBCertificateValidityRaw Validity, TSBCertificateValidityReasonRaw Reason);

typedef void (SB_CALLBACK *TSBXAdESStoreCertificateEvent)(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle Cert, char * pcURI, int32_t * szURI);

typedef void (SB_CALLBACK *TSBXAdESStoreCRLEvent)(void * _ObjectData, TObjectHandle Sender, TElAbstractCRLHandle CRL, char * pcURI, int32_t * szURI);

typedef void (SB_CALLBACK *TSBXAdESStoreOCSPResponseEvent)(void * _ObjectData, TObjectHandle Sender, TElOCSPResponseHandle OCSPResponse, char * pcURI, int32_t * szURI);

typedef void (SB_CALLBACK *TSBXAdESRetrieveCertificateEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURI, int32_t szURI, TElXMLCertIDHandle CertID, TElX509CertificateHandle * Cert, int8_t * ReleaseObj);

typedef void (SB_CALLBACK *TSBXAdESRetrieveCertificateV2Event)(void * _ObjectData, TObjectHandle Sender, const char * pcURI, int32_t szURI, TElXMLCertIDV2Handle CertID, TElX509CertificateHandle * Cert, int8_t * ReleaseObj);

typedef void (SB_CALLBACK *TSBXAdESRetrieveCRLEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURI, int32_t szURI, TElXMLCRLRefHandle CRLRef, TElAbstractCRLHandle * CRL, int8_t * ReleaseObj);

typedef void (SB_CALLBACK *TSBXAdESRetrieveOCSPResponseEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURI, int32_t szURI, TElXMLOCSPRefHandle OCSPRef, TElOCSPResponseHandle * OCSPResponse, int8_t * ReleaseObj);

typedef void (SB_CALLBACK *TSBXAdESBeforeSaveUnsignedPropertyEvent)(void * _ObjectData, TObjectHandle Sender, TElXMLAdESElementHandle Element);

#ifdef SB_USE_CLASS_TELXADESPROCESSOR
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddTimestampValidationData(TElXAdESProcessorHandle _Handle, TSBXAdESValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddTimestampValidationData_1(TElXAdESProcessorHandle _Handle, TElXMLCustomFormatterHandle Formatter, TSBXAdESValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddTimestampValidationData_2(TElXAdESProcessorHandle _Handle, TElClientTSPInfoHandle TSPInfo, const char * pcURI, int32_t szURI, TElXMLCustomFormatterHandle Formatter, TSBXAdESValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddTimestampValidationData_3(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle Certs, TElCustomCRLStorageHandle CRLs, TListHandle OCSPResponses, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddTimestampValidationData_4(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle Certs, TElCustomCRLStorageHandle CRLs, TListHandle OCSPResponses, const char * pcURI, int32_t szURI, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddCounterSignature(TElXAdESProcessorHandle _Handle, TElXMLProcessorHandle Signer);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddCounterSignature_1(TElXAdESProcessorHandle _Handle, TElXMLProcessorHandle Signer, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddSignatureTimestamp(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddSignatureTimestamp_1(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddRefsOnlyTimestamp(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddRefsOnlyTimestamp_1(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddSigAndRefsTimestamp(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddSigAndRefsTimestamp_1(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddArchiveTimestamp(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddArchiveTimestamp_1(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddAttributeCertificateRefs(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle Certs);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddAttributeCertificateRefs_1(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle Certs, TElXMLDigestMethodRaw DigestMethod, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddCompleteCertificateRefs(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle Certs);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddCompleteCertificateRefs_1(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle Certs, TElXMLDigestMethodRaw DigestMethod, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddAttributeRevocationRefs(TElXAdESProcessorHandle _Handle, TElCustomCRLStorageHandle CRLs, TListHandle OCSPResponses);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddAttributeRevocationRefs_1(TElXAdESProcessorHandle _Handle, TElCustomCRLStorageHandle CRLs, TListHandle OCSPResponses, TElXMLDigestMethodRaw DigestMethod, int8_t ResponderIdByKey, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddCompleteRevocationRefs(TElXAdESProcessorHandle _Handle, TElCustomCRLStorageHandle CRLs, TListHandle OCSPResponses);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddCompleteRevocationRefs_1(TElXAdESProcessorHandle _Handle, TElCustomCRLStorageHandle CRLs, TListHandle OCSPResponses, TElXMLDigestMethodRaw DigestMethod, int8_t ResponderIdByKey, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddValidationDataRefs(TElXAdESProcessorHandle _Handle, TSBXAdESValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddValidationDataRefs_1(TElXAdESProcessorHandle _Handle, TElX509CertificateHandle SigningCertificate, TElXMLDigestMethodRaw DigestMethod, int8_t ResponderIdByKey, TElXMLCustomFormatterHandle Formatter, TSBXAdESValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddValidationDataRefs_2(TElXAdESProcessorHandle _Handle, TElX509CertificateHandle SigningCertificate, int8_t IncludeCRL, int8_t IncludeOCSP, TElXMLDigestMethodRaw DigestMethod, int8_t ResponderIdByKey, TElXMLCustomFormatterHandle Formatter, TSBXAdESValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddAttrAuthoritiesCertValues(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle Certs);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddAttrAuthoritiesCertValues_1(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle Certs, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddCertificateValues(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle Certs);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddCertificateValues_1(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle Certs, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddAttributeRevocationValues(TElXAdESProcessorHandle _Handle, TElCustomCRLStorageHandle CRLs, TListHandle OCSPResponses);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddAttributeRevocationValues_1(TElXAdESProcessorHandle _Handle, TElCustomCRLStorageHandle CRLs, TListHandle OCSPResponses, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddRevocationValues(TElXAdESProcessorHandle _Handle, TElCustomCRLStorageHandle CRLs, TListHandle OCSPResponses);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddRevocationValues_1(TElXAdESProcessorHandle _Handle, TElCustomCRLStorageHandle CRLs, TListHandle OCSPResponses, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddValidationDataValues(TElXAdESProcessorHandle _Handle, TSBXAdESValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddValidationDataValues_1(TElXAdESProcessorHandle _Handle, TElX509CertificateHandle SigningCertificate, TElXMLCustomFormatterHandle Formatter, TSBXAdESValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_AddValidationDataValues_2(TElXAdESProcessorHandle _Handle, TElX509CertificateHandle SigningCertificate, int8_t IncludeCRL, int8_t IncludeOCSP, TElXMLCustomFormatterHandle Formatter, TSBXAdESValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_GetSignerCertificate(TElXAdESProcessorHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_ClearPKICache(TElXAdESProcessorHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_ExtractAllCertificates(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle Certs);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_ExtractAllCRLs(TElXAdESProcessorHandle _Handle, TElCustomCRLStorageHandle CRLs);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_ExtractAllOCSPResponses(TElXAdESProcessorHandle _Handle, TListHandle OCSPResponses);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_GracePeriod(TElXAdESProcessorHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_GracePeriod(TElXAdESProcessorHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_OfflineMode(TElXAdESProcessorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_OfflineMode(TElXAdESProcessorHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_TimestampCanonicalizationMethod(TElXAdESProcessorHandle _Handle, TElXMLCanonicalizationMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_TimestampCanonicalizationMethod(TElXAdESProcessorHandle _Handle, TElXMLCanonicalizationMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_XAdESOptions(TElXAdESProcessorHandle _Handle, TSBXAdESOptionsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_XAdESOptions(TElXAdESProcessorHandle _Handle, TSBXAdESOptionsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_ValidationMoment(TElXAdESProcessorHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_ValidationMoment(TElXAdESProcessorHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_ForceCompleteChainValidation(TElXAdESProcessorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_ForceCompleteChainValidation(TElXAdESProcessorHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_IgnoreChainValidationErrors(TElXAdESProcessorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_IgnoreChainValidationErrors(TElXAdESProcessorHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_TrustedCertificates(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_TrustedCertificates(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_CryptoProviderManager(TElXAdESProcessorHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_CryptoProviderManager(TElXAdESProcessorHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_CertificateValidator(TElXAdESProcessorHandle _Handle, TElX509CertificateValidatorHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_CertificateValidator(TElXAdESProcessorHandle _Handle, TElX509CertificateValidatorHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_OnBeforeSaveUnsignedProperty(TElXAdESProcessorHandle _Handle, TSBXAdESBeforeSaveUnsignedPropertyEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_OnBeforeSaveUnsignedProperty(TElXAdESProcessorHandle _Handle, TSBXAdESBeforeSaveUnsignedPropertyEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_OnBeforeCertificateValidate(TElXAdESProcessorHandle _Handle, TSBXAdESBeforeCertificateValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_OnBeforeCertificateValidate(TElXAdESProcessorHandle _Handle, TSBXAdESBeforeCertificateValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_OnAfterCertificateValidate(TElXAdESProcessorHandle _Handle, TSBXAdESAfterCertificateValidateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_OnAfterCertificateValidate(TElXAdESProcessorHandle _Handle, TSBXAdESAfterCertificateValidateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_OnCertificateNeeded(TElXAdESProcessorHandle _Handle, TSBXAdESCertificateNeededEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_OnCertificateNeeded(TElXAdESProcessorHandle _Handle, TSBXAdESCertificateNeededEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_OnStoreCertificate(TElXAdESProcessorHandle _Handle, TSBXAdESStoreCertificateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_OnStoreCertificate(TElXAdESProcessorHandle _Handle, TSBXAdESStoreCertificateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_OnStoreCRL(TElXAdESProcessorHandle _Handle, TSBXAdESStoreCRLEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_OnStoreCRL(TElXAdESProcessorHandle _Handle, TSBXAdESStoreCRLEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_get_OnStoreOCSPResponse(TElXAdESProcessorHandle _Handle, TSBXAdESStoreOCSPResponseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_set_OnStoreOCSPResponse(TElXAdESProcessorHandle _Handle, TSBXAdESStoreOCSPResponseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESProcessor_Create(TComponentHandle AOwner, TElXAdESProcessorHandle * OutResult);
#endif /* SB_USE_CLASS_TELXADESPROCESSOR */

#ifdef SB_USE_CLASS_TELXADESSIGNER
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_TimestampDataObjects(TElXAdESSignerHandle _Handle, TElXMLReferenceListHandle AReferences, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_AddUnsignedObjects(TElXAdESSignerHandle _Handle, TElXMLDOMElementHandle SignedInfo, TElXMLDOMElementHandle SignatureValue, TElXMLKeyInfoHandle KeyInfo, TElXMLReferenceListHandle AReferences, TObjectHandle AObjects, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_SetSigningCertificates(TElXAdESSignerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_SetTSPClient(TElXAdESSignerHandle _Handle, TElCustomTSPClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_SetXAdESForm(TElXAdESSignerHandle _Handle, TSBXAdESFormRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_SetXAdESVersion(TElXAdESSignerHandle _Handle, TSBXAdESVersionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_SetQualifyingProperties(TElXAdESSignerHandle _Handle, TElXMLQualifyingPropertiesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_Clear(TElXAdESSignerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_Generate(TElXAdESSignerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_Generate_1(TElXAdESSignerHandle _Handle, TSBXAdESFormRaw AXAdESForm);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_AddCounterSignature(TElXAdESSignerHandle _Handle, TElXMLProcessorHandle Signer, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_AddCounterSignature_1(TElXAdESProcessorHandle _Handle, TElXMLProcessorHandle Signer);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_AddAllDataObjectsTimestamp(TElXAdESSignerHandle _Handle, TElCustomTSPClientHandle ATSPClient);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_AddSignatureTimestamp(TElXAdESSignerHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_AddSignatureTimestamp_1(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_AddRefsOnlyTimestamp(TElXAdESSignerHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_AddRefsOnlyTimestamp_1(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_AddSigAndRefsTimestamp(TElXAdESSignerHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_AddSigAndRefsTimestamp_1(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_AddArchiveTimestamp(TElXAdESSignerHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_AddArchiveTimestamp_1(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_PolicyId(TElXAdESSignerHandle _Handle, TElXMLSignaturePolicyIdHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_PolicyId(TElXAdESSignerHandle _Handle, TElXMLSignaturePolicyIdHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_ProductionPlace(TElXAdESSignerHandle _Handle, TElXMLSignatureProductionPlaceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_ProductionPlace(TElXAdESSignerHandle _Handle, TElXMLSignatureProductionPlaceHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_ProductionPlaceV2(TElXAdESSignerHandle _Handle, TElXMLSignatureProductionPlaceV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_ProductionPlaceV2(TElXAdESSignerHandle _Handle, TElXMLSignatureProductionPlaceV2Handle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_SignerRole(TElXAdESSignerHandle _Handle, TElXMLSignerRoleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_SignerRole(TElXAdESSignerHandle _Handle, TElXMLSignerRoleHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_SignerRoleV2(TElXAdESSignerHandle _Handle, TElXMLSignerRoleV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_SignerRoleV2(TElXAdESSignerHandle _Handle, TElXMLSignerRoleV2Handle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_QualifyingProperties(TElXAdESSignerHandle _Handle, TElXMLQualifyingPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_QualifyingProperties(TElXAdESSignerHandle _Handle, TElXMLQualifyingPropertiesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_QualifyingPropertiesReferences(TElXAdESSignerHandle _Handle, TElXMLQualifyingPropertiesReferenceListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_OwnSigningCertificates(TElXAdESSignerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_OwnSigningCertificates(TElXAdESSignerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_SigningCertificates(TElXAdESSignerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_SigningCertificates(TElXAdESSignerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_SigningTime(TElXAdESSignerHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_SigningTime(TElXAdESSignerHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_SigningCertificatesDigestMethod(TElXAdESSignerHandle _Handle, TElXMLDigestMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_SigningCertificatesDigestMethod(TElXAdESSignerHandle _Handle, TElXMLDigestMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_SignedPropertiesReferenceDigestMethod(TElXAdESSignerHandle _Handle, TElXMLDigestMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_SignedPropertiesReferenceDigestMethod(TElXAdESSignerHandle _Handle, TElXMLDigestMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_Included(TElXAdESSignerHandle _Handle, TElXAdESIncludedPropertiesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_Included(TElXAdESSignerHandle _Handle, TElXAdESIncludedPropertiesRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_TSPClient(TElXAdESSignerHandle _Handle, TElCustomTSPClientHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_TSPClient(TElXAdESSignerHandle _Handle, TElCustomTSPClientHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_IgnoreTimestampFailure(TElXAdESSignerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_IgnoreTimestampFailure(TElXAdESSignerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_XAdESForm(TElXAdESSignerHandle _Handle, TSBXAdESFormRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_XAdESForm(TElXAdESSignerHandle _Handle, TSBXAdESFormRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_get_XAdESVersion(TElXAdESSignerHandle _Handle, TSBXAdESVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_set_XAdESVersion(TElXAdESSignerHandle _Handle, TSBXAdESVersionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESSigner_Create(TComponentHandle AOwner, TElXAdESSignerHandle * OutResult);
#endif /* SB_USE_CLASS_TELXADESSIGNER */

#ifdef SB_USE_CLASS_TELXADESVERIFIER
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_Load(TElXAdESVerifierHandle _Handle, TElXMLProcessorHandle Verifier);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddCounterSignature(TElXAdESVerifierHandle _Handle, TElXMLProcessorHandle Signer, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddCounterSignature_1(TElXAdESProcessorHandle _Handle, TElXMLProcessorHandle Signer);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddSignatureTimestamp(TElXAdESVerifierHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddSignatureTimestamp_1(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddRefsOnlyTimestamp(TElXAdESVerifierHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddRefsOnlyTimestamp_1(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddRefsOnlyTimestampV2(TElXAdESVerifierHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddRefsOnlyTimestampV2_1(TElXAdESVerifierHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddSigAndRefsTimestamp(TElXAdESVerifierHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddSigAndRefsTimestamp_1(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddSigAndRefsTimestampV2(TElXAdESVerifierHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddSigAndRefsTimestampV2_1(TElXAdESVerifierHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddArchiveTimestamp(TElXAdESVerifierHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddArchiveTimestamp_1(TElXAdESProcessorHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddArchiveTimestampV141(TElXAdESVerifierHandle _Handle, TElCustomTSPClientHandle ATSPClient, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddArchiveTimestampV141_1(TElXAdESVerifierHandle _Handle, TElCustomTSPClientHandle ATSPClient, TElXMLCustomFormatterHandle Formatter, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddTimestampValidationData(TElXAdESVerifierHandle _Handle, TElXMLCustomFormatterHandle Formatter, TSBXAdESValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddTimestampValidationData_1(TElXAdESProcessorHandle _Handle, TSBXAdESValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddTimestampValidationData_2(TElXAdESProcessorHandle _Handle, TElClientTSPInfoHandle TSPInfo, const char * pcURI, int32_t szURI, TElXMLCustomFormatterHandle Formatter, TSBXAdESValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddTimestampValidationData_3(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle Certs, TElCustomCRLStorageHandle CRLs, TListHandle OCSPResponses, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_AddTimestampValidationData_4(TElXAdESProcessorHandle _Handle, TElCustomCertStorageHandle Certs, TElCustomCRLStorageHandle CRLs, TListHandle OCSPResponses, const char * pcURI, int32_t szURI, TElXMLCustomFormatterHandle Formatter);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_CheckTimestamp(TElXAdESVerifierHandle _Handle, TElClientTSPInfoHandle Info, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_ExtractAllCertificates(TElXAdESVerifierHandle _Handle, TElCustomCertStorageHandle Certs);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_UpgradeToXAdESv141(TElXAdESVerifierHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_Validate(TElXAdESVerifierHandle _Handle, TSBXAdESValidityReasonsRaw * Reasons, TSBXAdESValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_Validate_1(TElXAdESVerifierHandle _Handle, TElX509CertificateHandle SigningCertificate, TSBXAdESValidityReasonsRaw * Reasons, TSBXAdESValidityRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_IsEnabled(TElXAdESVerifierHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_Included(TElXAdESVerifierHandle _Handle, TElXAdESIncludedPropertiesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_CertIDs(TElXAdESVerifierHandle _Handle, int32_t Index, TElXMLCertIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_CertIDCount(TElXAdESVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_CertIDV2s(TElXAdESVerifierHandle _Handle, int32_t Index, TElXMLCertIDV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_CertIDV2Count(TElXAdESVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_PolicyId(TElXAdESVerifierHandle _Handle, TElXMLSignaturePolicyIdHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_ProductionPlace(TElXAdESVerifierHandle _Handle, TElXMLSignatureProductionPlaceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_ProductionPlaceV2(TElXAdESVerifierHandle _Handle, TElXMLSignatureProductionPlaceV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_SignerRole(TElXAdESVerifierHandle _Handle, TElXMLSignerRoleHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_SignerRoleV2(TElXAdESVerifierHandle _Handle, TElXMLSignerRoleV2Handle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_SigningCertificates(TElXAdESVerifierHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_SigningTime(TElXAdESVerifierHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_CertifiedSigningTime(TElXAdESVerifierHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_LastArchivalTime(TElXAdESVerifierHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_Timestamp(TElXAdESVerifierHandle _Handle, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_IndividualDataObjectsTimestampCount(TElXAdESVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_IndividualDataObjectsTimestamps(TElXAdESVerifierHandle _Handle, int32_t Index, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_AllDataObjectsTimestampCount(TElXAdESVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_AllDataObjectsTimestamps(TElXAdESVerifierHandle _Handle, int32_t Index, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_SignatureTimestampCount(TElXAdESVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_SignatureTimestamps(TElXAdESVerifierHandle _Handle, int32_t Index, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_RefsOnlyTimestampCount(TElXAdESVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_RefsOnlyTimestamps(TElXAdESVerifierHandle _Handle, int32_t Index, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_SigAndRefsTimestampCount(TElXAdESVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_SigAndRefsTimestamps(TElXAdESVerifierHandle _Handle, int32_t Index, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_ArchiveTimestampCount(TElXAdESVerifierHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_ArchiveTimestamps(TElXAdESVerifierHandle _Handle, int32_t Index, TElClientTSPInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_TimeStampValidationDataList(TElXAdESVerifierHandle _Handle, TElXMLTimeStampValidationDataListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_QualifyingProperties(TElXAdESVerifierHandle _Handle, TElXMLQualifyingPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_QualifyingPropertiesReferences(TElXAdESVerifierHandle _Handle, TElXMLQualifyingPropertiesReferenceListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_XAdESForm(TElXAdESVerifierHandle _Handle, TSBXAdESFormRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_XAdESVersion(TElXAdESVerifierHandle _Handle, TSBXAdESVersionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_CertStorage(TElXAdESVerifierHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_set_CertStorage(TElXAdESVerifierHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_OnRetrieveCertificate(TElXAdESVerifierHandle _Handle, TSBXAdESRetrieveCertificateEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_set_OnRetrieveCertificate(TElXAdESVerifierHandle _Handle, TSBXAdESRetrieveCertificateEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_OnRetrieveCertificateV2(TElXAdESVerifierHandle _Handle, TSBXAdESRetrieveCertificateV2Event * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_set_OnRetrieveCertificateV2(TElXAdESVerifierHandle _Handle, TSBXAdESRetrieveCertificateV2Event pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_OnRetrieveCRL(TElXAdESVerifierHandle _Handle, TSBXAdESRetrieveCRLEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_set_OnRetrieveCRL(TElXAdESVerifierHandle _Handle, TSBXAdESRetrieveCRLEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_get_OnRetrieveOCSPResponse(TElXAdESVerifierHandle _Handle, TSBXAdESRetrieveOCSPResponseEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_set_OnRetrieveOCSPResponse(TElXAdESVerifierHandle _Handle, TSBXAdESRetrieveOCSPResponseEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXAdESVerifier_Create(TComponentHandle AOwner, TElXAdESVerifierHandle * OutResult);
#endif /* SB_USE_CLASS_TELXADESVERIFIER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElXAdESProcessor_ce_ptr;
extern zend_class_entry *TElXAdESSigner_ce_ptr;
extern zend_class_entry *TElXAdESVerifier_ce_ptr;

void SB_CALLBACK TSBXAdESCertificateNeededEventRaw(void * _ObjectData, TObjectHandle Sender, TElCertificateLookupHandle Lookup, TElX509CertificateHandle * Cert);
void SB_CALLBACK TSBXAdESBeforeCertificateValidateEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle Cert, TElX509CertificateValidatorHandle CertValidator);
void SB_CALLBACK TSBXAdESAfterCertificateValidateEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle Cert, TElX509CertificateValidatorHandle CertValidator, TSBCertificateValidityRaw Validity, TSBCertificateValidityReasonRaw Reason);
void SB_CALLBACK TSBXAdESStoreCertificateEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateHandle Cert, char * pcURI, int32_t * szURI);
void SB_CALLBACK TSBXAdESStoreCRLEventRaw(void * _ObjectData, TObjectHandle Sender, TElAbstractCRLHandle CRL, char * pcURI, int32_t * szURI);
void SB_CALLBACK TSBXAdESStoreOCSPResponseEventRaw(void * _ObjectData, TObjectHandle Sender, TElOCSPResponseHandle OCSPResponse, char * pcURI, int32_t * szURI);
void SB_CALLBACK TSBXAdESRetrieveCertificateEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURI, int32_t szURI, TElXMLCertIDHandle CertID, TElX509CertificateHandle * Cert, int8_t * ReleaseObj);
void SB_CALLBACK TSBXAdESRetrieveCertificateV2EventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURI, int32_t szURI, TElXMLCertIDV2Handle CertID, TElX509CertificateHandle * Cert, int8_t * ReleaseObj);
void SB_CALLBACK TSBXAdESRetrieveCRLEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURI, int32_t szURI, TElXMLCRLRefHandle CRLRef, TElAbstractCRLHandle * CRL, int8_t * ReleaseObj);
void SB_CALLBACK TSBXAdESRetrieveOCSPResponseEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURI, int32_t szURI, TElXMLOCSPRefHandle OCSPRef, TElOCSPResponseHandle * OCSPResponse, int8_t * ReleaseObj);
void SB_CALLBACK TSBXAdESBeforeSaveUnsignedPropertyEventRaw(void * _ObjectData, TObjectHandle Sender, TElXMLAdESElementHandle Element);
void Register_TElXAdESProcessor(TSRMLS_D);
void Register_TElXAdESSigner(TSRMLS_D);
void Register_TElXAdESVerifier(TSRMLS_D);
void Register_SBXMLAdESIntf_Enum_Flags(TSRMLS_D);
void Register_SBXMLAdESIntf_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLADESINTF */

