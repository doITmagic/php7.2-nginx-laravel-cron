#ifndef __INC_SBXMLCHARSETS
#define __INC_SBXMLCHARSETS

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbconstants.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbstreams.h"
#include "sbchsconvbase.h"
#include "sbchsconv.h"
#include "sbxmldefs.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifndef SB_BUFFER_SIZE
#define SB_BUFFER_SIZE 	262144
#endif

typedef TElClassHandle TElXMLBufferingStreamHandle;

typedef TElClassHandle TElXMLCodecHandle;

typedef TElXMLCodecHandle ElXMLCodecHandle;

typedef TElClassHandle TElXML8BitCodecHandle;

typedef TElXML8BitCodecHandle ElXML8BitCodecHandle;

typedef TElClassHandle TElXMLUTF8CodecHandle;

typedef TElXMLUTF8CodecHandle ElXMLUTF8CodecHandle;

typedef TElClassHandle TElXMLUnicodeCodecHandle;

typedef TElXMLUnicodeCodecHandle ElXMLUnicodeCodecHandle;

typedef TElClassHandle TElXMLStringCodecHandle;

typedef TElXMLStringCodecHandle ElXMLStringCodecHandle;

#ifdef SB_USE_CLASS_TELXMLBUFFERINGSTREAM
SB_IMPORT uint32_t SB_APIENTRY TElXMLBufferingStream_Read(TElXMLBufferingStreamHandle _Handle, void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBufferingStream_Write(TElXMLBufferingStreamHandle _Handle, const void * Buffer, int32_t Count, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBufferingStream_Seek(TElXMLBufferingStreamHandle _Handle, int32_t Offset, uint16_t Origin, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBufferingStream_Seek_1(TElXMLBufferingStreamHandle _Handle, int64_t Offset, TSeekOriginRaw Origin, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBufferingStream_Flush(TElXMLBufferingStreamHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBufferingStream_get_Stream(TElXMLBufferingStreamHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBufferingStream_set_Stream(TElXMLBufferingStreamHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBufferingStream_get_EndOfFile(TElXMLBufferingStreamHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBufferingStream_Create(TElXMLBufferingStreamHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLBUFFERINGSTREAM */

#ifdef SB_USE_CLASS_TELXMLCODEC
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_MigrateTo(TElXMLCodecHandle _Handle, TElXMLCodecHandle Codec);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_Flush(TElXMLCodecHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_NextChar(TElXMLCodecHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_WriteChar(TElXMLCodecHandle _Handle, const char * pcc, int32_t szc);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_WriteStartup(TElXMLCodecHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_Detect(TElXMLCodecHandle _Handle, const char * pcDefaultEncoding, int32_t szDefaultEncoding, TElXMLCodecHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_Detect_1(TStreamHandle aStream, const char * pcDefaultEncoding, int32_t szDefaultEncoding, TElXMLCodecHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_Detect_2(TElXMLCodecHandle _Handle, TStreamHandle aStream, const char * pcDefaultEncoding, int32_t szDefaultEncoding, TElXMLCodecHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_GetCodec(const char * pcaEnc, int32_t szaEnc, TElXMLCodecHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_GetCodec_1(TElXMLCodecHandle _Handle, const char * pcaEnc, int32_t szaEnc, TElXMLCodecHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_get_Stream(TElXMLCodecHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_set_Stream(TElXMLCodecHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_get_sEOF(TElXMLCodecHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_get_sPos(TElXMLCodecHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_set_sPos(TElXMLCodecHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_get_sSize(TElXMLCodecHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_set_sSize(TElXMLCodecHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_get_Name(TElXMLCodecHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_get_WriteBOM(TElXMLCodecHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_set_WriteBOM(TElXMLCodecHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_Create(TElXMLCodecHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCodec_Create_1(TStreamHandle aStream, TElXMLCodecHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCODEC */

#ifdef SB_USE_CLASS_TELXML8BITCODEC
SB_IMPORT uint32_t SB_APIENTRY TElXML8BitCodec_get_Charset(TElXML8BitCodecHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXML8BitCodec_set_Charset(TElXML8BitCodecHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXML8BitCodec_Create(TElXML8BitCodecHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXML8BitCodec_Create_1(const char * pcaEncoding, int32_t szaEncoding, TElXML8BitCodecHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXML8BitCodec_Create_2(TStreamHandle aStream, TElXML8BitCodecHandle * OutResult);
#endif /* SB_USE_CLASS_TELXML8BITCODEC */

#ifdef SB_USE_CLASS_TELXMLUTF8CODEC
SB_IMPORT uint32_t SB_APIENTRY TElXMLUTF8Codec_Create(TElXMLUTF8CodecHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUTF8Codec_Create_1(TStreamHandle aStream, TElXMLUTF8CodecHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLUTF8CODEC */

#ifdef SB_USE_CLASS_TELXMLUNICODECODEC
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnicodeCodec_get_BigEndian(TElXMLUnicodeCodecHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnicodeCodec_set_BigEndian(TElXMLUnicodeCodecHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnicodeCodec_Create(TElXMLUnicodeCodecHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLUnicodeCodec_Create_1(TStreamHandle aStream, TElXMLUnicodeCodecHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLUNICODECODEC */

#ifdef SB_USE_CLASS_TELXMLSTRINGCODEC
SB_IMPORT uint32_t SB_APIENTRY TElXMLStringCodec_NextChar(TElXMLStringCodecHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLStringCodec_WriteChar(TElXMLStringCodecHandle _Handle, const char * pcc, int32_t szc);
SB_IMPORT uint32_t SB_APIENTRY TElXMLStringCodec_WriteStartup(TElXMLStringCodecHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLStringCodec_get_Data(TElXMLStringCodecHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLStringCodec_set_Data(TElXMLStringCodecHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLStringCodec_Create(TElXMLStringCodecHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLStringCodec_Create_1(TStreamHandle aStream, TElXMLStringCodecHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSTRINGCODEC */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElXMLBufferingStream_ce_ptr;
extern zend_class_entry *TElXMLCodec_ce_ptr;
extern zend_class_entry *TElXML8BitCodec_ce_ptr;
extern zend_class_entry *TElXMLUTF8Codec_ce_ptr;
extern zend_class_entry *TElXMLUnicodeCodec_ce_ptr;
extern zend_class_entry *TElXMLStringCodec_ce_ptr;

void Register_TElXMLBufferingStream(TSRMLS_D);
void Register_TElXMLCodec(TSRMLS_D);
void Register_TElXML8BitCodec(TSRMLS_D);
void Register_TElXMLUTF8Codec(TSRMLS_D);
void Register_TElXMLUnicodeCodec(TSRMLS_D);
void Register_TElXMLStringCodec(TSRMLS_D);
void Register_SBXMLCharsets_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLCHARSETS */

