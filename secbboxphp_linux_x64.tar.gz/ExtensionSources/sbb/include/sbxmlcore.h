#ifndef __INC_SBXMLCORE
#define __INC_SBXMLCORE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbxmldefs.h"
#include "sbxmlcharsets.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_ntElement 	1
#define SB_ntAttribute 	2
#define SB_ntText 	3
#define SB_ntCDataSection 	4
#define SB_ntEntityReference 	5
#define SB_ntEntity 	6
#define SB_ntProcessingInstruction 	7
#define SB_ntComment 	8
#define SB_ntDocument 	9
#define SB_ntDocumentType 	10
#define SB_ntDocumentFragment 	11
#define SB_ntNotation 	12

typedef TElClassHandle TElXMLDOMImplementationHandle;

typedef TElXMLDOMImplementationHandle ElXMLDOMImplementationHandle;

typedef TElClassHandle TElXMLDOMDocumentFragmentHandle;

typedef TElXMLDOMDocumentFragmentHandle ElXMLDOMDocumentFragmentHandle;

typedef TElClassHandle TElXMLDOMDocumentHandle;

typedef TElXMLDOMDocumentHandle ElXMLDOMDocumentHandle;

typedef TElClassHandle TElXMLDOMNodeHandle;

typedef TElXMLDOMNodeHandle ElXMLDOMNodeHandle;

typedef TElClassHandle TElXMLNodeSetHandle;

typedef TElXMLNodeSetHandle ElXMLNodeSetHandle;

typedef TElClassHandle TElXMLDOMNodeListHandle;

typedef TElXMLDOMNodeListHandle ElXMLDOMNodeListHandle;

typedef TElClassHandle TElXMLDOMNamedNodeMapHandle;

typedef TElXMLDOMNamedNodeMapHandle ElXMLDOMNamedNodeMapHandle;

typedef TElClassHandle TElXMLDOMCharacterDataHandle;

typedef TElXMLDOMCharacterDataHandle ElXMLDOMCharacterDataHandle;

typedef TElClassHandle TElXMLDOMAttrHandle;

typedef TElXMLDOMAttrHandle ElXMLDOMAttrHandle;

typedef TElClassHandle TElXMLDOMElementHandle;

typedef TElXMLDOMElementHandle ElXMLDOMElementHandle;

typedef TElClassHandle TElXMLDOMTextHandle;

typedef TElXMLDOMTextHandle ElXMLDOMTextHandle;

typedef TElClassHandle TElXMLDOMCommentHandle;

typedef TElXMLDOMCommentHandle ElXMLDOMCommentHandle;

typedef TElClassHandle TElXMLDOMCDATASectionHandle;

typedef TElXMLDOMCDATASectionHandle ElXMLDOMCDATASectionHandle;

typedef TElClassHandle TElXMLDOMDocumentTypeHandle;

typedef TElXMLDOMDocumentTypeHandle ElXMLDOMDocumentTypeHandle;

typedef TElClassHandle TElXMLDOMNotationHandle;

typedef TElXMLDOMNotationHandle ElXMLDOMNotationHandle;

typedef TElClassHandle TElXMLDOMEntityHandle;

typedef TElXMLDOMEntityHandle ElXMLDOMEntityHandle;

typedef TElClassHandle TElXMLDOMEntityReferenceHandle;

typedef TElXMLDOMEntityReferenceHandle ElXMLDOMEntityReferenceHandle;

typedef TElClassHandle TElXMLDOMProcessingInstructionHandle;

typedef TElXMLDOMProcessingInstructionHandle ElXMLDOMProcessingInstructionHandle;

typedef TElClassHandle TElXMLParserHandle;

typedef TElXMLParserHandle ElXMLParserHandle;

typedef TElClassHandle TElXMLNamespaceMapHandle;

typedef TElXMLNamespaceMapHandle ElXMLNamespaceMapHandle;

typedef TElClassHandle TElXMLCustomFormatterHandle;

typedef TElXMLCustomFormatterHandle ElXMLCustomFormatterHandle;

typedef TElClassHandle TElXMLCustomElementHandle;

typedef TElXMLCustomElementHandle ElXMLCustomElementHandle;

typedef uint8_t TElXMLDelayLoadModeTypeRaw;

typedef enum
{
	dlmCDATA = 0,
	dlmComment = 1,
	dlmText = 2
} TElXMLDelayLoadModeType;

typedef uint32_t TElXMLDelayLoadModeRaw;

typedef enum 
{
	f_dlmCDATA = 1,
	f_dlmComment = 2,
	f_dlmText = 4
} TElXMLDelayLoadMode;

typedef void (SB_CALLBACK *TElXMLValidationFunc)(const char * pcc, int32_t szc, int8_t * OutResult);

#ifdef SB_USE_CLASS_TELXMLDOMIMPLEMENTATION
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMImplementation_HasFeature(TElXMLDOMImplementationHandle _Handle, const char * pcFeature, int32_t szFeature, const char * pcVersion, int32_t szVersion, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMImplementation_CreateDocumentType(TElXMLDOMImplementationHandle _Handle, const char * pcQualifiedName, int32_t szQualifiedName, const char * pcPublicID, int32_t szPublicID, const char * pcSystemID, int32_t szSystemID, TElXMLDOMDocumentTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMImplementation_CreateDocumentType_1(TElXMLDOMImplementationHandle _Handle, const char * pcQualifiedName, int32_t szQualifiedName, const char * pcPublicID, int32_t szPublicID, const char * pcSystemID, int32_t szSystemID, const char * pcInternalSubset, int32_t szInternalSubset, TElXMLDOMDocumentTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMImplementation_CreateDocument(TElXMLDOMImplementationHandle _Handle, const char * pcNamespaceURI, int32_t szNamespaceURI, const char * pcQualifiedName, int32_t szQualifiedName, TElXMLDOMDocumentTypeHandle DocType, TElXMLDOMDocumentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMImplementation_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMIMPLEMENTATION */

#ifdef SB_USE_CLASS_TELXMLDOMNODE
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_ReloadData(TElXMLDOMNodeHandle _Handle, TElXMLDelayLoadModeRaw LoadedData, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_UnloadData(TElXMLDOMNodeHandle _Handle, TElXMLDelayLoadModeRaw DataToUnload);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_GetOuterXMLCanonical(TElXMLDOMNodeHandle _Handle, TElXMLCanonicalizationMethodRaw aMethod, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_GetOuterXMLCanonical_1(TElXMLDOMNodeHandle _Handle, TElXMLCanonicalizationMethodRaw aMethod, const char * pcInclNSPrefixList, int32_t szInclNSPrefixList, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_SelectNodes(TElXMLDOMNodeHandle _Handle, const char * pcXPath, int32_t szXPath, TElXMLNodeSetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_SelectNodes_1(TElXMLDOMNodeHandle _Handle, const char * pcXPath, int32_t szXPath, TElXMLNamespaceMapHandle NSMap, TElXMLNodeSetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_InsertBefore(TElXMLDOMNodeHandle _Handle, TElXMLDOMNodeHandle NewChild, TElXMLDOMNodeHandle RefChild, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_ReplaceChild(TElXMLDOMNodeHandle _Handle, TElXMLDOMNodeHandle NewChild, TElXMLDOMNodeHandle OldChild, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_RemoveChild(TElXMLDOMNodeHandle _Handle, TElXMLDOMNodeHandle OldChild);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_AppendChild(TElXMLDOMNodeHandle _Handle, TElXMLDOMNodeHandle NewChild, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_AppendChild_1(TElXMLDOMNodeHandle _Handle, TElXMLDOMNodeHandle NewChild, int8_t DisablePrefixUpdate, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_HasChildNodes(TElXMLDOMNodeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_CloneNode(TElXMLDOMNodeHandle _Handle, int8_t Deep, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_CloneNode_1(TElXMLDOMNodeHandle _Handle, int8_t Deep, TElXMLDOMDocumentHandle aCloneOwner, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_Normalize(TElXMLDOMNodeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_HasAttributes(TElXMLDOMNodeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_isSupported(TElXMLDOMNodeHandle _Handle, const char * pcFeature, int32_t szFeature, const char * pcVersion, int32_t szVersion, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_FindNode(TElXMLDOMNodeHandle _Handle, const char * pcaNodeName, int32_t szaNodeName, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_FindNode_1(TElXMLDOMNodeHandle _Handle, const char * pcaNodeName, int32_t szaNodeName, int8_t Deep, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_RelativeIndex(TElXMLDOMNodeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_NodeName(TElXMLDOMNodeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_NodeValue(TElXMLDOMNodeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_set_NodeValue(TElXMLDOMNodeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_NodeType(TElXMLDOMNodeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_ParentNode(TElXMLDOMNodeHandle _Handle, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_FirstChild(TElXMLDOMNodeHandle _Handle, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_LastChild(TElXMLDOMNodeHandle _Handle, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_ChildNodes(TElXMLDOMNodeHandle _Handle, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_PreviousSibling(TElXMLDOMNodeHandle _Handle, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_NextSibling(TElXMLDOMNodeHandle _Handle, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_Attributes(TElXMLDOMNodeHandle _Handle, TElXMLDOMNamedNodeMapHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_OwnerDocument(TElXMLDOMNodeHandle _Handle, TElXMLDOMDocumentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_RawData(TElXMLDOMNodeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_RawDataLength(TElXMLDOMNodeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_Loaded(TElXMLDOMNodeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_OuterXML(TElXMLDOMNodeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_NamespaceURI(TElXMLDOMNodeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_LocalName(TElXMLDOMNodeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_get_Prefix(TElXMLDOMNodeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNode_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMNODE */

#ifdef SB_USE_CLASS_TELXMLDOMDOCUMENT
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_LoadFromStream(TElXMLDOMDocumentHandle _Handle, TStreamHandle aStream);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_LoadFromStream_1(TElXMLDOMDocumentHandle _Handle, TStreamHandle aStream, const char * pcDefaultEncoding, int32_t szDefaultEncoding, int8_t NormalizeNEL);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_LoadFromStream_2(TElXMLDOMDocumentHandle _Handle, TStreamHandle aStream, int8_t OwnStream, TElXMLDelayLoadModeRaw DataToLoad);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_LoadFromStream_3(TElXMLDOMDocumentHandle _Handle, TStreamHandle aStream, int8_t OwnStream, TElXMLDelayLoadModeRaw DataToLoad, const char * pcDefaultEncoding, int32_t szDefaultEncoding, int8_t NormalizeNEL);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_SaveToStream(TElXMLDOMDocumentHandle _Handle, TStreamHandle aStream);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_SaveToStream_1(TElXMLDOMDocumentHandle _Handle, TStreamHandle aStream, TElXMLCanonicalizationMethodRaw aMethod);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_SaveToStream_2(TElXMLDOMDocumentHandle _Handle, TStreamHandle aStream, TElXMLCanonicalizationMethodRaw aMethod, TElXMLCodecHandle aEncoding);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_SaveToStream_3(TElXMLDOMDocumentHandle _Handle, TStreamHandle aStream, TElXMLCanonicalizationMethodRaw aMethod, const char * pcaCharset, int32_t szaCharset);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_LoadFromFile(TElXMLDOMDocumentHandle _Handle, const char * pcaFileName, int32_t szaFileName);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_LoadFromFile_1(TElXMLDOMDocumentHandle _Handle, const char * pcaFileName, int32_t szaFileName, const char * pcDefaultEncoding, int32_t szDefaultEncoding, int8_t NormalizeNEL);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_LoadFromFile_2(TElXMLDOMDocumentHandle _Handle, const char * pcaFileName, int32_t szaFileName, TElXMLDelayLoadModeRaw DataToLoad);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_LoadFromFile_3(TElXMLDOMDocumentHandle _Handle, const char * pcaFileName, int32_t szaFileName, TElXMLDelayLoadModeRaw DataToLoad, const char * pcDefaultEncoding, int32_t szDefaultEncoding, int8_t NormalizeNEL);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_SaveToFile(TElXMLDOMDocumentHandle _Handle, const char * pcaFileName, int32_t szaFileName);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_SaveToFile_1(TElXMLDOMDocumentHandle _Handle, const char * pcaFileName, int32_t szaFileName, TElXMLCanonicalizationMethodRaw aMethod);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_SaveToFile_2(TElXMLDOMDocumentHandle _Handle, const char * pcaFileName, int32_t szaFileName, TElXMLCanonicalizationMethodRaw aMethod, TElXMLCodecHandle aEncoding);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_SaveToFile_3(TElXMLDOMDocumentHandle _Handle, const char * pcaFileName, int32_t szaFileName, TElXMLCanonicalizationMethodRaw aMethod, const char * pcaCharset, int32_t szaCharset);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_ReloadAll(TElXMLDOMDocumentHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_LookupEntityByRef(TElXMLDOMDocumentHandle _Handle, const char * pcaRef, int32_t szaRef, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_CreateElement(TElXMLDOMDocumentHandle _Handle, const char * pcTagName, int32_t szTagName, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_CreateDocumentFragment(TElXMLDOMDocumentHandle _Handle, TElXMLDOMDocumentFragmentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_CreateTextNode(TElXMLDOMDocumentHandle _Handle, const char * pcData, int32_t szData, TElXMLDOMTextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_CreateComment(TElXMLDOMDocumentHandle _Handle, const char * pcData, int32_t szData, TElXMLDOMCommentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_CreateAttribute(TElXMLDOMDocumentHandle _Handle, const char * pcName, int32_t szName, TElXMLDOMAttrHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_GetElementsByTagName(TElXMLDOMDocumentHandle _Handle, const char * pcTagName, int32_t szTagName, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_GetElementsByTagName_1(TElXMLDOMDocumentHandle _Handle, const char * pcTagName, int32_t szTagName, int8_t Deep, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_ImportNode(TElXMLDOMDocumentHandle _Handle, const TElXMLDOMNodeHandle aNode, int8_t Deep, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_CreateElementNS(TElXMLDOMDocumentHandle _Handle, const char * pcaNSURI, int32_t szaNSURI, const char * pcaName, int32_t szaName, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_CreateAttributeNS(TElXMLDOMDocumentHandle _Handle, const char * pcaNSURi, int32_t szaNSURi, const char * pcaName, int32_t szaName, TElXMLDOMAttrHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_GetElementsByTagNameNS(TElXMLDOMDocumentHandle _Handle, const char * pcaNSURi, int32_t szaNSURi, const char * pcaName, int32_t szaName, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_GetElementsByTagNameNS_1(TElXMLDOMDocumentHandle _Handle, const char * pcaNSURi, int32_t szaNSURi, const char * pcaName, int32_t szaName, int8_t Deep, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_GetElementByID(TElXMLDOMDocumentHandle _Handle, const char * pcaElementID, int32_t szaElementID, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_CreateEntity(TElXMLDOMDocumentHandle _Handle, const char * pcData, int32_t szData, TElXMLDOMEntityHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_CreateCDATASection(TElXMLDOMDocumentHandle _Handle, const char * pcData, int32_t szData, TElXMLDOMCDATASectionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_CreateProcessingInstruction(TElXMLDOMDocumentHandle _Handle, const char * pcTarget, int32_t szTarget, const char * pcData, int32_t szData, TElXMLDOMProcessingInstructionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_CreateEntityReference(TElXMLDOMDocumentHandle _Handle, const char * pcName, int32_t szName, TElXMLDOMEntityReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_Clone(TElXMLDOMDocumentHandle _Handle, TElXMLDOMDocumentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_get_DocumentType(TElXMLDOMDocumentHandle _Handle, TElXMLDOMDocumentTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_get_Impl(TElXMLDOMDocumentHandle _Handle, TElXMLDOMImplementationHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_get_DocumentElement(TElXMLDOMDocumentHandle _Handle, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_get_XmlNS(TElXMLDOMDocumentHandle _Handle, TElXMLDOMAttrHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_get_InnerXML(TElXMLDOMDocumentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_set_InnerXML(TElXMLDOMDocumentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_get_OriginalEncoding(TElXMLDOMDocumentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_get_Version(TElXMLDOMDocumentHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_set_Version(TElXMLDOMDocumentHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_get_WriteBOM(TElXMLDOMDocumentHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_set_WriteBOM(TElXMLDOMDocumentHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocument_Create(TElXMLDOMDocumentHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMDOCUMENT */

#ifdef SB_USE_CLASS_TELXMLDOMDOCUMENTFRAGMENT
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocumentFragment_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMDOCUMENTFRAGMENT */

#ifdef SB_USE_CLASS_TELXMLNODESET
SB_IMPORT uint32_t SB_APIENTRY TElXMLNodeSet_Add(TElXMLNodeSetHandle _Handle, TElXMLDOMNodeHandle ANode, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNodeSet_Insert(TElXMLNodeSetHandle _Handle, int32_t Index, TElXMLDOMNodeHandle ANode);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNodeSet_Delete(TElXMLNodeSetHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNodeSet_Clear(TElXMLNodeSetHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNodeSet_HasNode(TElXMLNodeSetHandle _Handle, TElXMLDOMNodeHandle Node, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNodeSet_IndexOf(TElXMLNodeSetHandle _Handle, TElXMLDOMNodeHandle Node, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNodeSet_get_Count(TElXMLNodeSetHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNodeSet_get_Node(TElXMLNodeSetHandle _Handle, int32_t Index, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNodeSet_get_OwnNodes(TElXMLNodeSetHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNodeSet_set_OwnNodes(TElXMLNodeSetHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNodeSet_Create(int8_t AOwnNodes, TElXMLNodeSetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNodeSet_Create_1(TElXMLDOMNodeListHandle NodeList, TElXMLNodeSetHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLNODESET */

#ifdef SB_USE_CLASS_TELXMLDOMNODELIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNodeList_get_Item(TElXMLDOMNodeListHandle _Handle, int32_t Index, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNodeList_get_Length(TElXMLDOMNodeListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNodeList_Create(TElXMLDOMNodeHandle aNode, int8_t aOwnNode, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNodeList_Create_1(TElXMLDOMNodeHandle aNode, const char * pcaFilter, int32_t szaFilter, int8_t aOwnNode, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNodeList_Create_2(TElXMLDOMNodeHandle aNode, const char * pcaFilter, int32_t szaFilter, int8_t aAllNodes, int8_t aDeep, int8_t aOwnNode, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNodeList_Create_3(TElXMLDOMNodeHandle aNode, const char * pcaNSURI, int32_t szaNSURI, const char * pcaFilter, int32_t szaFilter, int8_t aOwnNode, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNodeList_Create_4(TElXMLDOMNodeHandle aNode, const char * pcaNSURI, int32_t szaNSURI, const char * pcaFilter, int32_t szaFilter, int8_t aAllNodes, int8_t aDeep, int8_t aOwnNode, TElXMLDOMNodeListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMNODELIST */

#ifdef SB_USE_CLASS_TELXMLDOMNAMEDNODEMAP
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNamedNodeMap_Clear(TElXMLDOMNamedNodeMapHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNamedNodeMap_GetNamedItem(TElXMLDOMNamedNodeMapHandle _Handle, const char * pcName, int32_t szName, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNamedNodeMap_SetNamedItem(TElXMLDOMNamedNodeMapHandle _Handle, TElXMLDOMNodeHandle arg, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNamedNodeMap_RemoveNamedItem(TElXMLDOMNamedNodeMapHandle _Handle, const char * pcName, int32_t szName, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNamedNodeMap_GetNamedItemNS(TElXMLDOMNamedNodeMapHandle _Handle, const char * pcaNSURI, int32_t szaNSURI, const char * pcaName, int32_t szaName, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNamedNodeMap_SetNamedItemNS(TElXMLDOMNamedNodeMapHandle _Handle, TElXMLDOMNodeHandle arg, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNamedNodeMap_RemoveNamedItemNS(TElXMLDOMNamedNodeMapHandle _Handle, const char * pcaNSURI, int32_t szaNSURI, const char * pcaName, int32_t szaName, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNamedNodeMap_get_Item(TElXMLDOMNamedNodeMapHandle _Handle, int32_t index, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNamedNodeMap_set_Item(TElXMLDOMNamedNodeMapHandle _Handle, int32_t index, TElXMLDOMNodeHandle aItem);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNamedNodeMap_get_Length(TElXMLDOMNamedNodeMapHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNamedNodeMap_Create(TListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMNAMEDNODEMAP */

#ifdef SB_USE_CLASS_TELXMLDOMCHARACTERDATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMCharacterData_UnloadData(TElXMLDOMCharacterDataHandle _Handle, TElXMLDelayLoadModeRaw DataToUnload);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMCharacterData_SubstringData(TElXMLDOMCharacterDataHandle _Handle, int32_t ofs, int32_t len, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMCharacterData_AppendData(TElXMLDOMCharacterDataHandle _Handle, const char * pcarg, int32_t szarg);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMCharacterData_InsertData(TElXMLDOMCharacterDataHandle _Handle, int32_t ofs, const char * pcarg, int32_t szarg);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMCharacterData_DeleteData(TElXMLDOMCharacterDataHandle _Handle, int32_t ofs, int32_t len);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMCharacterData_ReplaceData(TElXMLDOMCharacterDataHandle _Handle, int32_t ofs, int32_t len, const char * pcarg, int32_t szarg);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMCharacterData_get_Data(TElXMLDOMCharacterDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMCharacterData_get_Length(TElXMLDOMCharacterDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMCharacterData_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMCHARACTERDATA */

#ifdef SB_USE_CLASS_TELXMLDOMATTR
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMAttr_CloneNode(TElXMLDOMAttrHandle _Handle, int8_t Deep, TElXMLDOMDocumentHandle aCloneOwner, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMAttr_CloneNode_1(TElXMLDOMNodeHandle _Handle, int8_t Deep, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMAttr_get_Quote(TElXMLDOMAttrHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMAttr_set_Quote(TElXMLDOMAttrHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMAttr_get_Value(TElXMLDOMAttrHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMAttr_set_Value(TElXMLDOMAttrHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMAttr_get_OwnerElement(TElXMLDOMAttrHandle _Handle, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMAttr_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMATTR */

#ifdef SB_USE_CLASS_TELXMLDOMELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_CloneNode(TElXMLDOMElementHandle _Handle, int8_t Deep, TElXMLDOMDocumentHandle aCloneOwner, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_CloneNode_1(TElXMLDOMNodeHandle _Handle, int8_t Deep, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_RemoveAttribute(TElXMLDOMElementHandle _Handle, const char * pcaName, int32_t szaName);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_GetAttributeNode(TElXMLDOMElementHandle _Handle, const char * pcaName, int32_t szaName, TElXMLDOMAttrHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_SetAttributeNode(TElXMLDOMElementHandle _Handle, TElXMLDOMAttrHandle aNewAttr, TElXMLDOMAttrHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_RemoveAttributeNode(TElXMLDOMElementHandle _Handle, TElXMLDOMAttrHandle aOldAttr, TElXMLDOMAttrHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_GetElementsByTagName(TElXMLDOMElementHandle _Handle, const char * pcaName, int32_t szaName, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_GetElementsByTagName_1(TElXMLDOMElementHandle _Handle, const char * pcaName, int32_t szaName, int8_t Deep, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_HasAttributes(TElXMLDOMElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_GetOuterXMLCanonical(TElXMLDOMElementHandle _Handle, TElXMLCanonicalizationMethodRaw aMethod, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_GetOuterXMLCanonical_1(TElXMLDOMElementHandle _Handle, TElXMLCanonicalizationMethodRaw aMethod, const char * pcInclNSPrefixList, int32_t szInclNSPrefixList, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_GetOuterXMLCanonical_2(TElXMLDOMElementHandle _Handle, TElXMLCanonicalizationMethodRaw aMethod, TElXMLDOMNodeHandle ReferenceNode, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_GetOuterXMLCanonical_3(TElXMLDOMElementHandle _Handle, TElXMLCanonicalizationMethodRaw aMethod, const char * pcInclNSPrefixList, int32_t szInclNSPrefixList, TElXMLDOMNodeHandle ReferenceNode, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_InnerText(TElXMLDOMElementHandle _Handle, const char * pcSeparator, int32_t szSeparator, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_GetAttribute(TElXMLDOMElementHandle _Handle, const char * pcaName, int32_t szaName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_SetAttribute(TElXMLDOMElementHandle _Handle, const char * pcaName, int32_t szaName, const char * pcaValue, int32_t szaValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_GetAttributeNS(TElXMLDOMElementHandle _Handle, const char * pcaNSURI, int32_t szaNSURI, const char * pcaName, int32_t szaName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_SetAttributeNS(TElXMLDOMElementHandle _Handle, const char * pcaNSURI, int32_t szaNSURI, const char * pcaName, int32_t szaName, const char * pcaValue, int32_t szaValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_RemoveAttributeNS(TElXMLDOMElementHandle _Handle, const char * pcaNSURI, int32_t szaNSURI, const char * pcaName, int32_t szaName);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_GetAttributeNodeNS(TElXMLDOMElementHandle _Handle, const char * pcaNSURI, int32_t szaNSURI, const char * pcaName, int32_t szaName, TElXMLDOMAttrHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_SetAttributeNodeNS(TElXMLDOMElementHandle _Handle, TElXMLDOMAttrHandle aNewAttr, TElXMLDOMAttrHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_GetElementsByTagNameNS(TElXMLDOMElementHandle _Handle, const char * pcaNSURI, int32_t szaNSURI, const char * pcaName, int32_t szaName, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_GetElementsByTagNameNS_1(TElXMLDOMElementHandle _Handle, const char * pcaNSURI, int32_t szaNSURI, const char * pcaName, int32_t szaName, int8_t Deep, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_HasAttribute(TElXMLDOMElementHandle _Handle, const char * pcaName, int32_t szaName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_HasAttributeNS(TElXMLDOMElementHandle _Handle, const char * pcaNSURI, int32_t szaNSURI, const char * pcaName, int32_t szaName, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_GetCurrentNSURI(TElXMLDOMElementHandle _Handle, const char * pcs, int32_t szs, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_get_TextContent(TElXMLDOMElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_set_TextContent(TElXMLDOMElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_get_InnerXML(TElXMLDOMElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_set_InnerXML(TElXMLDOMElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_get_AttribStrings(TElXMLDOMElementHandle _Handle, const char * pcaName, int32_t szaName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_set_AttribStrings(TElXMLDOMElementHandle _Handle, const char * pcaName, int32_t szaName, const char * pcaValue, int32_t szaValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMElement_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMELEMENT */

#ifdef SB_USE_CLASS_TELXMLDOMTEXT
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMText_CloneNode(TElXMLDOMTextHandle _Handle, int8_t Deep, TElXMLDOMDocumentHandle aCloneOwner, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMText_CloneNode_1(TElXMLDOMNodeHandle _Handle, int8_t Deep, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMText_SplitText(TElXMLDOMTextHandle _Handle, int32_t ofs, TElXMLDOMTextHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMText_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMTEXT */

#ifdef SB_USE_CLASS_TELXMLDOMCOMMENT
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMComment_CloneNode(TElXMLDOMCommentHandle _Handle, int8_t Deep, TElXMLDOMDocumentHandle aCloneOwner, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMComment_CloneNode_1(TElXMLDOMNodeHandle _Handle, int8_t Deep, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMComment_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMCOMMENT */

#ifdef SB_USE_CLASS_TELXMLDOMCDATASECTION
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMCDATASection_CloneNode(TElXMLDOMCDATASectionHandle _Handle, int8_t Deep, TElXMLDOMDocumentHandle aCloneOwner, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMCDATASection_CloneNode_1(TElXMLDOMNodeHandle _Handle, int8_t Deep, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMCDATASection_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMCDATASECTION */

#ifdef SB_USE_CLASS_TELXMLDOMDOCUMENTTYPE
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocumentType_CloneNode(TElXMLDOMDocumentTypeHandle _Handle, int8_t Deep, TElXMLDOMDocumentHandle aCloneOwner, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocumentType_CloneNode_1(TElXMLDOMNodeHandle _Handle, int8_t Deep, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocumentType_ResolveExternalDTD(TElXMLDOMDocumentTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocumentType_get_Name(TElXMLDOMDocumentTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocumentType_get_Entities(TElXMLDOMDocumentTypeHandle _Handle, TElXMLDOMNamedNodeMapHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocumentType_get_Notations(TElXMLDOMDocumentTypeHandle _Handle, TElXMLDOMNamedNodeMapHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocumentType_get_PublicID(TElXMLDOMDocumentTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocumentType_get_SystemID(TElXMLDOMDocumentTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocumentType_get_InternalSubset(TElXMLDOMDocumentTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMDocumentType_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMDOCUMENTTYPE */

#ifdef SB_USE_CLASS_TELXMLDOMNOTATION
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNotation_CloneNode(TElXMLDOMNotationHandle _Handle, int8_t Deep, TElXMLDOMDocumentHandle aCloneOwner, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNotation_CloneNode_1(TElXMLDOMNodeHandle _Handle, int8_t Deep, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNotation_get_PublicID(TElXMLDOMNotationHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNotation_get_SystemID(TElXMLDOMNotationHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMNotation_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMNOTATION */

#ifdef SB_USE_CLASS_TELXMLDOMENTITY
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMEntity_CloneNode(TElXMLDOMEntityHandle _Handle, int8_t Deep, TElXMLDOMDocumentHandle aCloneOwner, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMEntity_CloneNode_1(TElXMLDOMNodeHandle _Handle, int8_t Deep, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMEntity_get_PublicID(TElXMLDOMEntityHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMEntity_get_SystemID(TElXMLDOMEntityHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMEntity_get_NotationName(TElXMLDOMEntityHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMEntity_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMENTITY */

#ifdef SB_USE_CLASS_TELXMLDOMENTITYREFERENCE
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMEntityReference_CloneNode(TElXMLDOMEntityReferenceHandle _Handle, int8_t Deep, TElXMLDOMDocumentHandle aCloneOwner, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMEntityReference_CloneNode_1(TElXMLDOMNodeHandle _Handle, int8_t Deep, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMEntityReference_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMENTITYREFERENCE */

#ifdef SB_USE_CLASS_TELXMLDOMPROCESSINGINSTRUCTION
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMProcessingInstruction_CloneNode(TElXMLDOMProcessingInstructionHandle _Handle, int8_t Deep, TElXMLDOMDocumentHandle aCloneOwner, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMProcessingInstruction_CloneNode_1(TElXMLDOMNodeHandle _Handle, int8_t Deep, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMProcessingInstruction_get_Target(TElXMLDOMProcessingInstructionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMProcessingInstruction_get_Data(TElXMLDOMProcessingInstructionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDOMProcessingInstruction_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDOMPROCESSINGINSTRUCTION */

#ifdef SB_USE_CLASS_TELXMLPARSER
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_RaiseExc(TElXMLParserHandle _Handle, const char * pcaMsg, int32_t szaMsg);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_InitStream(TElXMLParserHandle _Handle, const char * pcDefaultEncoding, int32_t szDefaultEncoding);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_bufInit(TElXMLParserHandle _Handle, char * pcaArg, int32_t * szaArg);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_bufAddChar(TElXMLParserHandle _Handle, char * pcaArg, int32_t * szaArg, const char * pcc, int32_t szc);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_bufFlush(TElXMLParserHandle _Handle, char * pcaArg, int32_t * szaArg);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_bufFree(TElXMLParserHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_sEOF(TElXMLParserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_NextChar(TElXMLParserHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_PushData(TElXMLParserHandle _Handle, const char * pcData, int32_t szData);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_PushData_1(TElXMLParserHandle _Handle, const char * pcData, int32_t szData, const char * pcMarker, int32_t szMarker, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_Write(TElXMLParserHandle _Handle, const char * pcaArg, int32_t szaArg);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_Write_1(TElXMLParserHandle _Handle, const char * pcc, int32_t szc);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_SkipBlank(TElXMLParserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_ExpectBlank(TElXMLParserHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_ExpectString(TElXMLParserHandle _Handle, const char * pcaArg, int32_t szaArg);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_UntilString(TElXMLParserHandle _Handle, const char * pcaArg, int32_t szaArg, int8_t LeaveString, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_UntilStringSkip(TElXMLParserHandle _Handle, const char * pcaArg, int32_t szaArg);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_CheckForMulti(TElXMLParserHandle _Handle, const int32_t pExpect[], int32_t szExpect, int8_t Recall, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_CheckFor(TElXMLParserHandle _Handle, const char * pcaArg, int32_t szaArg, int8_t Recall, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_GetWhile(TElXMLParserHandle _Handle, void * aFunc, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_GetWhile_1(TElXMLParserHandle _Handle, int32_t aCharKind, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_GetUntil(TElXMLParserHandle _Handle, void * aFunc, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_GetUntil_1(TElXMLParserHandle _Handle, int32_t aCharKind, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_GetUntilSkip(TElXMLParserHandle _Handle, void * aFunc);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_GetUntilSkip_1(TElXMLParserHandle _Handle, int32_t aCharKind);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_GetNMtok(TElXMLParserHandle _Handle, char * pcaArg, int32_t * szaArg, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_get_sPos(TElXMLParserHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_set_sPos(TElXMLParserHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_get_LastPos(TElXMLParserHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_get_Last(TElXMLParserHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_get_NormalizeNEL(TElXMLParserHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_set_NormalizeNEL(TElXMLParserHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_get_OEnc(TElXMLParserHandle _Handle, TElXMLCodecHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_set_OEnc(TElXMLParserHandle _Handle, TElXMLCodecHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLParser_Create(TElXMLDOMDocumentHandle aDoc, int8_t DoInitStream, const char * pcDefaultEncoding, int32_t szDefaultEncoding, int8_t NormNEL, TElXMLParserHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLPARSER */

#ifdef SB_USE_CLASS_TELXMLNAMESPACEMAP
SB_IMPORT uint32_t SB_APIENTRY TElXMLNamespaceMap_Clear(TElXMLNamespaceMapHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNamespaceMap_Add(TElXMLNamespaceMapHandle _Handle, TElXMLNamespaceMapHandle NSMap, int8_t OverwriteIfExists);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNamespaceMap_AddNamespace(TElXMLNamespaceMapHandle _Handle, const char * pcPrefix, int32_t szPrefix, const char * pcURI, int32_t szURI);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNamespaceMap_RemoveNamespace(TElXMLNamespaceMapHandle _Handle, const char * pcPrefix, int32_t szPrefix);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNamespaceMap_FindNamespace(TElXMLNamespaceMapHandle _Handle, const char * pcPrefix, int32_t szPrefix, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNamespaceMap_FindPrefix(TElXMLNamespaceMapHandle _Handle, const char * pcURI, int32_t szURI, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNamespaceMap_get_Count(TElXMLNamespaceMapHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNamespaceMap_get_Prefix(TElXMLNamespaceMapHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNamespaceMap_get_URI(TElXMLNamespaceMapHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLNamespaceMap_Create(TElXMLNamespaceMapHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLNAMESPACEMAP */

#ifdef SB_USE_CLASS_TELXMLCUSTOMFORMATTER
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomFormatter_AppendElement(TElXMLCustomFormatterHandle _Handle, TElXMLDOMElementHandle Parent, TElXMLDOMElementHandle Child);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomFormatter_AppendElement_1(TElXMLCustomFormatterHandle _Handle, TElXMLDOMElementHandle Parent, TElXMLCustomElementHandle Child, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomFormatter_AppendElementWithText(TElXMLCustomFormatterHandle _Handle, TElXMLDOMElementHandle Parent, TElXMLDOMElementHandle Child, const char * pcChildText, int32_t szChildText, TElXMLTextTypeRaw ChildTextType);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomFormatter_AppendText(TElXMLCustomFormatterHandle _Handle, TElXMLDOMElementHandle Parent, const char * pcText, int32_t szText, TElXMLTextTypeRaw TextType);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomFormatter_InsertBefore(TElXMLCustomFormatterHandle _Handle, TElXMLDOMElementHandle Parent, TElXMLDOMNodeHandle ChildRef, TElXMLCustomElementHandle Child, TElXMLDOMDocumentHandle Document);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomFormatter_Clear(TElXMLCustomFormatterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomFormatter_Push(TElXMLCustomFormatterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomFormatter_Pop(TElXMLCustomFormatterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomFormatter_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCUSTOMFORMATTER */

#ifdef SB_USE_CLASS_TELXMLCUSTOMELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomElement_Clear(TElXMLCustomElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomElement_LoadFromXML(TElXMLCustomElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomElement_SaveToXML(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomElement_get_XMLElement(TElXMLCustomElementHandle _Handle, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomElement_set_XMLElement(TElXMLCustomElementHandle _Handle, TElXMLDOMElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCUSTOMELEMENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElXMLDOMImplementation_ce_ptr;
extern zend_class_entry *TElXMLDOMNode_ce_ptr;
extern zend_class_entry *TElXMLDOMDocument_ce_ptr;
extern zend_class_entry *TElXMLDOMDocumentFragment_ce_ptr;
extern zend_class_entry *TElXMLNodeSet_ce_ptr;
extern zend_class_entry *TElXMLDOMNodeList_ce_ptr;
extern zend_class_entry *TElXMLDOMNamedNodeMap_ce_ptr;
extern zend_class_entry *TElXMLDOMCharacterData_ce_ptr;
extern zend_class_entry *TElXMLDOMAttr_ce_ptr;
extern zend_class_entry *TElXMLDOMElement_ce_ptr;
extern zend_class_entry *TElXMLDOMText_ce_ptr;
extern zend_class_entry *TElXMLDOMComment_ce_ptr;
extern zend_class_entry *TElXMLDOMCDATASection_ce_ptr;
extern zend_class_entry *TElXMLDOMDocumentType_ce_ptr;
extern zend_class_entry *TElXMLDOMNotation_ce_ptr;
extern zend_class_entry *TElXMLDOMEntity_ce_ptr;
extern zend_class_entry *TElXMLDOMEntityReference_ce_ptr;
extern zend_class_entry *TElXMLDOMProcessingInstruction_ce_ptr;
extern zend_class_entry *TElXMLParser_ce_ptr;
extern zend_class_entry *TElXMLNamespaceMap_ce_ptr;
extern zend_class_entry *TElXMLCustomFormatter_ce_ptr;
extern zend_class_entry *TElXMLCustomElement_ce_ptr;

void Register_TElXMLDOMImplementation(TSRMLS_D);
void Register_TElXMLDOMNode(TSRMLS_D);
void Register_TElXMLDOMDocument(TSRMLS_D);
void Register_TElXMLDOMDocumentFragment(TSRMLS_D);
void Register_TElXMLNodeSet(TSRMLS_D);
void Register_TElXMLDOMNodeList(TSRMLS_D);
void Register_TElXMLDOMNamedNodeMap(TSRMLS_D);
void Register_TElXMLDOMCharacterData(TSRMLS_D);
void Register_TElXMLDOMAttr(TSRMLS_D);
void Register_TElXMLDOMElement(TSRMLS_D);
void Register_TElXMLDOMText(TSRMLS_D);
void Register_TElXMLDOMComment(TSRMLS_D);
void Register_TElXMLDOMCDATASection(TSRMLS_D);
void Register_TElXMLDOMDocumentType(TSRMLS_D);
void Register_TElXMLDOMNotation(TSRMLS_D);
void Register_TElXMLDOMEntity(TSRMLS_D);
void Register_TElXMLDOMEntityReference(TSRMLS_D);
void Register_TElXMLDOMProcessingInstruction(TSRMLS_D);
void Register_TElXMLParser(TSRMLS_D);
void Register_TElXMLNamespaceMap(TSRMLS_D);
void Register_TElXMLCustomFormatter(TSRMLS_D);
void Register_TElXMLCustomElement(TSRMLS_D);
SB_PHP_FUNCTION(SBXMLCore, isXMLblank);
SB_PHP_FUNCTION(SBXMLCore, isXMLIdeographic);
SB_PHP_FUNCTION(SBXMLCore, isXMLBaseChar);
SB_PHP_FUNCTION(SBXMLCore, isXMLCombining);
SB_PHP_FUNCTION(SBXMLCore, isXMLDigit);
SB_PHP_FUNCTION(SBXMLCore, isXMLExtender);
SB_PHP_FUNCTION(SBXMLCore, XMLGetPrefix);
SB_PHP_FUNCTION(SBXMLCore, XMLGetLocalName);
void Register_SBXMLCore_Constants(int module_number TSRMLS_DC);
void Register_SBXMLCore_Enum_Flags(TSRMLS_D);
void Register_SBXMLCore_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_XMLCORE
SB_IMPORT uint32_t SB_APIENTRY SBXMLCore_isXMLblank(const char * pcc, int32_t szc, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLCore_isXMLIdeographic(const char * pcc, int32_t szc, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLCore_isXMLBaseChar(const char * pcc, int32_t szc, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLCore_isXMLCombining(const char * pcc, int32_t szc, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLCore_isXMLDigit(const char * pcc, int32_t szc, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLCore_isXMLExtender(const char * pcc, int32_t szc, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLCore_XMLGetPrefix(const char * pcAName, int32_t szAName, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLCore_XMLGetLocalName(const char * pcAName, int32_t szAName, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_XMLCORE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLCORE */

