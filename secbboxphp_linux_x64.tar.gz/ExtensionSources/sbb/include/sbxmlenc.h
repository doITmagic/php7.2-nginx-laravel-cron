#ifndef __INC_SBXMLENC
#define __INC_SBXMLENC

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbxmldefs.h"
#include "sbxmlcore.h"
#include "sbxmlsec.h"
#include "sbxmlcharsets.h"
#include "sbxmltransform.h"
#include "sbxmlutils.h"
#include "sbcryptoprov.h"
#include "sbpublickeycrypto.h"
#include "sbsymmetriccrypto.h"
#include "sbx509.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_XML_ENC_ERROR_OK 	0
#define SB_XML_ENC_ERROR_NO_ENCRYPTEDDATA 	34049
#define SB_XML_ENC_ERROR_BAD_DECRYPTED_DATA 	34050
#define SB_XML_ENC_ERROR_UNSUPPORTED_HASH_ALGORITHM 	34053
#define SB_XML_ENC_ERROR_BAD_KEYSIZE 	34054
#define SB_XML_ENC_ERROR_BAD_KEY_LENGTH 	34055
#define SB_XML_ENC_ERROR_NO_DOCUMENT 	34056
#define SB_XML_ENC_ERROR_INVALID_KEY 	34096
#define SB_XML_ENC_ERROR_NO_KEY_DATA 	34098
#define SB_XML_ENC_ERROR_INVALID_KEY_DATA 	34099
#define SB_XML_ENC_ERROR_INVALID_KEK 	34128
#define SB_XML_ENC_ERROR_KEK_NO_KEY_DATA 	34130
#define SB_XML_ENC_ERROR_KEK_INVALID_KEY_DATA 	34131
#define SB_XML_ENC_ERROR_UNKNOWN 	34303

typedef TElClassHandle TElXMLEncryptedDataHandle;

typedef TElXMLEncryptedDataHandle ElXMLEncryptedDataHandle;

typedef TElClassHandle TElXMLEncProcessorHandle;

typedef TElXMLEncProcessorHandle ElXMLEncProcessorHandle;

typedef TElClassHandle TElXMLEncryptorHandle;

typedef TElXMLEncryptorHandle ElXMLEncryptorHandle;

typedef TElClassHandle TElXMLDecryptorHandle;

typedef TElXMLDecryptorHandle ElXMLDecryptorHandle;

typedef TElClassHandle TElXMLCipherReferenceHandle;

typedef TElXMLCipherReferenceHandle ElXMLCipherReferenceHandle;

typedef TElClassHandle TElXMLCipherDataHandle;

typedef TElXMLCipherDataHandle ElXMLCipherDataHandle;

typedef TElClassHandle TElXMLEncryptionMethodTypeHandle;

typedef TElXMLEncryptionMethodTypeHandle ElXMLEncryptionMethodTypeHandle;

typedef TElClassHandle TElXMLEncryptionPropertiesHandle;

typedef TElXMLEncryptionPropertiesHandle ElXMLEncryptionPropertiesHandle;

typedef TElClassHandle TElXMLEncryptedTypeHandle;

typedef TElXMLEncryptedTypeHandle ElXMLEncryptedTypeHandle;

typedef TElClassHandle TElXMLEncryptedKeyHandle;

typedef TElXMLEncryptedKeyHandle ElXMLEncryptedKeyHandle;

typedef TElClassHandle TElXMLDecryptionExceptHandle;

typedef TElXMLDecryptionExceptHandle ElXMLDecryptionExceptHandle;

typedef TElClassHandle TElXMLCustomDecryptionTransformHandle;

typedef TElXMLCustomDecryptionTransformHandle ElXMLCustomDecryptionTransformHandle;

typedef TElClassHandle TElXMLDecryptionTransformHandle;

typedef TElXMLDecryptionTransformHandle ElXMLDecryptionTransformHandle;

typedef TElClassHandle TElXMLBinaryDecryptionTransformHandle;

typedef TElXMLBinaryDecryptionTransformHandle ElXMLBinaryDecryptionTransformHandle;

typedef void (SB_CALLBACK *TSBXMLDecryptKeyDataEvent)(void * _ObjectData, TObjectHandle Sender, TElXMLDOMElementHandle EncryptedData, TElXMLDecryptorHandle Decryptor, int32_t PrevResult, TElXMLKeyInfoDataHandle * KeyData, int8_t * OutResult);

#ifdef SB_USE_CLASS_TELXMLENCRYPTEDTYPE
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_Clear(TElXMLEncryptedTypeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_IsEmpty(TElXMLEncryptedTypeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_LoadFromXML(TElXMLEncryptedTypeHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_SaveToXML(TElXMLEncryptedTypeHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_get_EncryptionMethod(TElXMLEncryptedTypeHandle _Handle, TElXMLEncryptionMethodTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_set_EncryptionMethod(TElXMLEncryptedTypeHandle _Handle, TElXMLEncryptionMethodTypeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_get_CipherData(TElXMLEncryptedTypeHandle _Handle, TElXMLCipherDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_set_CipherData(TElXMLEncryptedTypeHandle _Handle, TElXMLCipherDataHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_get_KeyInfo(TElXMLEncryptedTypeHandle _Handle, TElXMLKeyInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_set_KeyInfo(TElXMLEncryptedTypeHandle _Handle, TElXMLKeyInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_get_EncryptionProperties(TElXMLEncryptedTypeHandle _Handle, TElXMLEncryptionPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_set_EncryptionProperties(TElXMLEncryptedTypeHandle _Handle, TElXMLEncryptionPropertiesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_get_ID(TElXMLEncryptedTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_set_ID(TElXMLEncryptedTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_get_DataType(TElXMLEncryptedTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_set_DataType(TElXMLEncryptedTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_get_MimeType(TElXMLEncryptedTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_set_MimeType(TElXMLEncryptedTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_get_Encoding(TElXMLEncryptedTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_set_Encoding(TElXMLEncryptedTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_get_CryptoProviderManager(TElXMLEncryptedTypeHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_set_CryptoProviderManager(TElXMLEncryptedTypeHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedType_Create(TElXMLEncryptedTypeHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLENCRYPTEDTYPE */

#ifdef SB_USE_CLASS_TELXMLENCPROCESSOR
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncProcessor_get_KeyEncryptionKeyData(TElXMLEncProcessorHandle _Handle, TElXMLKeyInfoDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncProcessor_set_KeyEncryptionKeyData(TElXMLEncProcessorHandle _Handle, TElXMLKeyInfoDataHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncProcessor_get_EncryptedData(TElXMLEncProcessorHandle _Handle, TElXMLEncryptedDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncProcessor_set_EncryptedData(TElXMLEncProcessorHandle _Handle, TElXMLEncryptedDataHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncProcessor_Create(TComponentHandle AOwner, TElXMLEncProcessorHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLENCPROCESSOR */

#ifdef SB_USE_CLASS_TELXMLENCRYPTOR
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_Encrypt(TElXMLEncryptorHandle _Handle, const TElXMLDOMNodeHandle Data);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_Encrypt_1(TElXMLEncryptorHandle _Handle, const TElXMLDOMNodeListHandle Data);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_Encrypt_2(TElXMLEncryptorHandle _Handle, const uint8_t pData[], int32_t szData);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_Save(TElXMLEncryptorHandle _Handle, const TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_SaveToDocument(TElXMLEncryptorHandle _Handle, TElXMLDOMDocumentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_get_KeyData(TElXMLEncryptorHandle _Handle, TElXMLKeyInfoDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_set_KeyData(TElXMLEncryptorHandle _Handle, TElXMLKeyInfoDataHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_get_EncryptKey(TElXMLEncryptorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_set_EncryptKey(TElXMLEncryptorHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_get_KeyName(TElXMLEncryptorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_set_KeyName(TElXMLEncryptorHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_get_EncryptedDataType(TElXMLEncryptorHandle _Handle, TElXMLEncryptedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_set_EncryptedDataType(TElXMLEncryptorHandle _Handle, TElXMLEncryptedDataTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_get_EncryptionMethod(TElXMLEncryptorHandle _Handle, TElXMLEncryptionMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_set_EncryptionMethod(TElXMLEncryptorHandle _Handle, TElXMLEncryptionMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_get_KeyEncryptionType(TElXMLEncryptorHandle _Handle, TElXMLKeyEncryptionTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_set_KeyEncryptionType(TElXMLEncryptorHandle _Handle, TElXMLKeyEncryptionTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_get_KeyTransportMethod(TElXMLEncryptorHandle _Handle, TElXMLKeyTransportMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_set_KeyTransportMethod(TElXMLEncryptorHandle _Handle, TElXMLKeyTransportMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_get_KeyWrapMethod(TElXMLEncryptorHandle _Handle, TElXMLKeyWrapMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_set_KeyWrapMethod(TElXMLEncryptorHandle _Handle, TElXMLKeyWrapMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_get_IncludeKeyEncryptionKey(TElXMLEncryptorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_set_IncludeKeyEncryptionKey(TElXMLEncryptorHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_get_MimeType(TElXMLEncryptorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_set_MimeType(TElXMLEncryptorHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_get_OnFormatElement(TElXMLEncryptorHandle _Handle, TSBXMLFormatElementEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_set_OnFormatElement(TElXMLEncryptorHandle _Handle, TSBXMLFormatElementEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_get_OnFormatText(TElXMLEncryptorHandle _Handle, TSBXMLFormatTextEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_set_OnFormatText(TElXMLEncryptorHandle _Handle, TSBXMLFormatTextEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptor_Create(TComponentHandle AOwner, TElXMLEncryptorHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLENCRYPTOR */

#ifdef SB_USE_CLASS_TELXMLDECRYPTOR
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_Decrypt(TElXMLDecryptorHandle _Handle, const TElXMLDOMDocumentHandle OwnerDocument, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_Load(TElXMLDecryptorHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_Load_1(TElXMLDecryptorHandle _Handle, TElXMLDOMDocumentHandle Document);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_get_DecryptedNode(TElXMLDecryptorHandle _Handle, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_set_DecryptedNode(TElXMLDecryptorHandle _Handle, TElXMLDOMNodeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_get_DecryptedNodeList(TElXMLDecryptorHandle _Handle, TElXMLDOMNodeListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_set_DecryptedNodeList(TElXMLDecryptorHandle _Handle, TElXMLDOMNodeListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_get_DecryptedData(TElXMLDecryptorHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_set_DecryptedData(TElXMLDecryptorHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_get_EncryptedDataType(TElXMLDecryptorHandle _Handle, TElXMLEncryptedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_get_EncryptionMethod(TElXMLDecryptorHandle _Handle, TElXMLEncryptionMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_get_EncryptKey(TElXMLDecryptorHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_get_KeyName(TElXMLDecryptorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_get_KeyEncryptionType(TElXMLDecryptorHandle _Handle, TElXMLKeyEncryptionTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_get_KeyTransportMethod(TElXMLDecryptorHandle _Handle, TElXMLKeyTransportMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_get_KeyWrapMethod(TElXMLDecryptorHandle _Handle, TElXMLKeyWrapMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_get_MimeType(TElXMLDecryptorHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_get_KeyData(TElXMLDecryptorHandle _Handle, TElXMLKeyInfoDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_set_KeyData(TElXMLDecryptorHandle _Handle, TElXMLKeyInfoDataHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptor_Create(TComponentHandle AOwner, TElXMLDecryptorHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDECRYPTOR */

#ifdef SB_USE_CLASS_TELXMLCIPHERREFERENCE
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherReference_Clear(TElXMLCipherReferenceHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherReference_IsEmpty(TElXMLCipherReferenceHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherReference_LoadFromXML(TElXMLCipherReferenceHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherReference_SaveToXML(TElXMLCipherReferenceHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherReference_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherReference_get_CipherValue(TElXMLCipherReferenceHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherReference_set_CipherValue(TElXMLCipherReferenceHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherReference_get_TransformChain(TElXMLCipherReferenceHandle _Handle, TElXMLTransformChainHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherReference_set_TransformChain(TElXMLCipherReferenceHandle _Handle, TElXMLTransformChainHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherReference_get_URI(TElXMLCipherReferenceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherReference_set_URI(TElXMLCipherReferenceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherReference_Create(TElXMLCipherReferenceHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCIPHERREFERENCE */

#ifdef SB_USE_CLASS_TELXMLCIPHERDATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherData_Clear(TElXMLCipherDataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherData_IsEmpty(TElXMLCipherDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherData_LoadFromXML(TElXMLCipherDataHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherData_SaveToXML(TElXMLCipherDataHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherData_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherData_get_CipherValue(TElXMLCipherDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherData_set_CipherValue(TElXMLCipherDataHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherData_get_CipherReference(TElXMLCipherDataHandle _Handle, TElXMLCipherReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherData_set_CipherReference(TElXMLCipherDataHandle _Handle, TElXMLCipherReferenceHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCipherData_Create(TElXMLCipherDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCIPHERDATA */

#ifdef SB_USE_CLASS_TELXMLENCRYPTIONMETHODTYPE
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionMethodType_Clear(TElXMLEncryptionMethodTypeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionMethodType_IsEmpty(TElXMLEncryptionMethodTypeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionMethodType_LoadFromXML(TElXMLEncryptionMethodTypeHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionMethodType_SaveToXML(TElXMLEncryptionMethodTypeHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionMethodType_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionMethodType_get_Algorithm(TElXMLEncryptionMethodTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionMethodType_set_Algorithm(TElXMLEncryptionMethodTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionMethodType_get_KeySize(TElXMLEncryptionMethodTypeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionMethodType_set_KeySize(TElXMLEncryptionMethodTypeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionMethodType_get_OAEPparams(TElXMLEncryptionMethodTypeHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionMethodType_set_OAEPparams(TElXMLEncryptionMethodTypeHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionMethodType_get_DigestMethod(TElXMLEncryptionMethodTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionMethodType_set_DigestMethod(TElXMLEncryptionMethodTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionMethodType_Create(TElXMLEncryptionMethodTypeHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLENCRYPTIONMETHODTYPE */

#ifdef SB_USE_CLASS_TELXMLENCRYPTIONPROPERTIES
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptionProperties_Create(TElXMLEncryptionPropertiesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLENCRYPTIONPROPERTIES */

#ifdef SB_USE_CLASS_TELXMLENCRYPTEDDATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedData_Clear(TElXMLEncryptedDataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedData_IsEmpty(TElXMLEncryptedDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedData_LoadFromXML(TElXMLEncryptedDataHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedData_SaveToXML(TElXMLEncryptedDataHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedData_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedData_get_EncryptionPrefix(TElXMLEncryptedDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedData_set_EncryptionPrefix(TElXMLEncryptedDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedData_get_SignaturePrefix(TElXMLEncryptedDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedData_set_SignaturePrefix(TElXMLEncryptedDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedData_get_EncryptedKey(TElXMLEncryptedDataHandle _Handle, TElXMLEncryptedKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedData_set_EncryptedKey(TElXMLEncryptedDataHandle _Handle, TElXMLEncryptedKeyHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedData_Create(TElXMLEncryptedDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLENCRYPTEDDATA */

#ifdef SB_USE_CLASS_TELXMLENCRYPTEDKEY
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedKey_Clear(TElXMLEncryptedKeyHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedKey_IsEmpty(TElXMLEncryptedKeyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedKey_LoadFromXML(TElXMLEncryptedKeyHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedKey_SaveToXML(TElXMLEncryptedKeyHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedKey_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedKey_get_CarriedKeyName(TElXMLEncryptedKeyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedKey_set_CarriedKeyName(TElXMLEncryptedKeyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedKey_get_Recipient(TElXMLEncryptedKeyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedKey_set_Recipient(TElXMLEncryptedKeyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLEncryptedKey_Create(TElXMLEncryptedKeyHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLENCRYPTEDKEY */

#ifdef SB_USE_CLASS_TELXMLDECRYPTIONEXCEPT
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionExcept_Clone(TElXMLDecryptionExceptHandle _Handle, TElXMLDecryptionExceptHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionExcept_get_ID(TElXMLDecryptionExceptHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionExcept_set_ID(TElXMLDecryptionExceptHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionExcept_get_URI(TElXMLDecryptionExceptHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionExcept_set_URI(TElXMLDecryptionExceptHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionExcept_Create(TElXMLDecryptionExceptHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDECRYPTIONEXCEPT */

#ifdef SB_USE_CLASS_TELXMLCUSTOMDECRYPTIONTRANSFORM
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_LoadFromXML(TElXMLCustomDecryptionTransformHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_SaveToXML(TElXMLCustomDecryptionTransformHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_Add(TElXMLCustomDecryptionTransformHandle _Handle, TElXMLDecryptionExceptHandle AExcept, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_Add_1(TElXMLCustomDecryptionTransformHandle _Handle, const char * pcExceptID, int32_t szExceptID, const char * pcExceptURI, int32_t szExceptURI, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_Insert(TElXMLCustomDecryptionTransformHandle _Handle, int32_t Index, TElXMLDecryptionExceptHandle AExcept);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_Delete(TElXMLCustomDecryptionTransformHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_Clear(TElXMLCustomDecryptionTransformHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_get_Count(TElXMLCustomDecryptionTransformHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_get_Excepts(TElXMLCustomDecryptionTransformHandle _Handle, int32_t Index, TElXMLDecryptionExceptHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_get_KeyData(TElXMLCustomDecryptionTransformHandle _Handle, TElXMLKeyInfoDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_set_KeyData(TElXMLCustomDecryptionTransformHandle _Handle, TElXMLKeyInfoDataHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_get_OnKeyData(TElXMLCustomDecryptionTransformHandle _Handle, TSBXMLDecryptKeyDataEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_set_OnKeyData(TElXMLCustomDecryptionTransformHandle _Handle, TSBXMLDecryptKeyDataEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLCustomDecryptionTransform_Create(TElXMLCustomDecryptionTransformHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLCUSTOMDECRYPTIONTRANSFORM */

#ifdef SB_USE_CLASS_TELXMLDECRYPTIONTRANSFORM
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionTransform_GetDefaultTransformAlgorithmURI(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionTransform_GetDefaultTransformAlgorithmURI_1(TElXMLDecryptionTransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionTransform_IsTransformAlgorithmSupported(const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionTransform_IsTransformAlgorithmSupported_1(TElXMLDecryptionTransformHandle _Handle, const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionTransform_TransformData(TElXMLDecryptionTransformHandle _Handle, const uint8_t pData[], int32_t szData, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionTransform_TransformData_1(TElXMLDecryptionTransformHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLDOMNodeHandle Reference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionTransform_TransformData_2(TElXMLDecryptionTransformHandle _Handle, TElXMLDOMNodeListHandle Nodes, const TElXMLDOMNodeHandle pReference[], int32_t szReference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionTransform_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDecryptionTransform_Create(TElXMLCustomDecryptionTransformHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDECRYPTIONTRANSFORM */

#ifdef SB_USE_CLASS_TELXMLBINARYDECRYPTIONTRANSFORM
SB_IMPORT uint32_t SB_APIENTRY TElXMLBinaryDecryptionTransform_GetDefaultTransformAlgorithmURI(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBinaryDecryptionTransform_GetDefaultTransformAlgorithmURI_1(TElXMLBinaryDecryptionTransformHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBinaryDecryptionTransform_IsTransformAlgorithmSupported(const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBinaryDecryptionTransform_IsTransformAlgorithmSupported_1(TElXMLBinaryDecryptionTransformHandle _Handle, const char * pcAlgorithm, int32_t szAlgorithm, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBinaryDecryptionTransform_TransformData(TElXMLBinaryDecryptionTransformHandle _Handle, const uint8_t pData[], int32_t szData, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBinaryDecryptionTransform_TransformData_1(TElXMLBinaryDecryptionTransformHandle _Handle, TElXMLDOMNodeHandle Node, TElXMLDOMNodeHandle Reference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBinaryDecryptionTransform_TransformData_2(TElXMLBinaryDecryptionTransformHandle _Handle, TElXMLDOMNodeListHandle Nodes, const TElXMLDOMNodeHandle pReference[], int32_t szReference, TSBTransformedDataTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBinaryDecryptionTransform_ClassType(TClassHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLBinaryDecryptionTransform_Create(TElXMLCustomDecryptionTransformHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLBINARYDECRYPTIONTRANSFORM */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElXMLEncryptedType_ce_ptr;
extern zend_class_entry *TElXMLEncProcessor_ce_ptr;
extern zend_class_entry *TElXMLEncryptor_ce_ptr;
extern zend_class_entry *TElXMLDecryptor_ce_ptr;
extern zend_class_entry *TElXMLCipherReference_ce_ptr;
extern zend_class_entry *TElXMLCipherData_ce_ptr;
extern zend_class_entry *TElXMLEncryptionMethodType_ce_ptr;
extern zend_class_entry *TElXMLEncryptionProperties_ce_ptr;
extern zend_class_entry *TElXMLEncryptedData_ce_ptr;
extern zend_class_entry *TElXMLEncryptedKey_ce_ptr;
extern zend_class_entry *TElXMLDecryptionExcept_ce_ptr;
extern zend_class_entry *TElXMLCustomDecryptionTransform_ce_ptr;
extern zend_class_entry *TElXMLDecryptionTransform_ce_ptr;
extern zend_class_entry *TElXMLBinaryDecryptionTransform_ce_ptr;

void SB_CALLBACK TSBXMLDecryptKeyDataEventRaw(void * _ObjectData, TObjectHandle Sender, TElXMLDOMElementHandle EncryptedData, TElXMLDecryptorHandle Decryptor, int32_t PrevResult, TElXMLKeyInfoDataHandle * KeyData, int8_t * OutResult);
void Register_TElXMLEncryptedType(TSRMLS_D);
void Register_TElXMLEncProcessor(TSRMLS_D);
void Register_TElXMLEncryptor(TSRMLS_D);
void Register_TElXMLDecryptor(TSRMLS_D);
void Register_TElXMLCipherReference(TSRMLS_D);
void Register_TElXMLCipherData(TSRMLS_D);
void Register_TElXMLEncryptionMethodType(TSRMLS_D);
void Register_TElXMLEncryptionProperties(TSRMLS_D);
void Register_TElXMLEncryptedData(TSRMLS_D);
void Register_TElXMLEncryptedKey(TSRMLS_D);
void Register_TElXMLDecryptionExcept(TSRMLS_D);
void Register_TElXMLCustomDecryptionTransform(TSRMLS_D);
void Register_TElXMLDecryptionTransform(TSRMLS_D);
void Register_TElXMLBinaryDecryptionTransform(TSRMLS_D);
void Register_SBXMLEnc_Constants(int module_number TSRMLS_DC);
void Register_SBXMLEnc_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLENC */

