#ifndef __INC_SBXMLPATH
#define __INC_SBXMLPATH

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbxmlcore.h"
#include "sbxmldefs.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbconstants.h"
#include "sbstrutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElXPathHandle;

typedef TElXPathHandle ElXPathHandle;

typedef TElClassHandle TElNumberHandle;

typedef TElNumberHandle ElNumberHandle;

typedef TElClassHandle TElBooleanHandle;

typedef TElBooleanHandle ElBooleanHandle;

typedef TElClassHandle TElStringHandle;

typedef TElStringHandle ElStringHandle;

typedef TElClassHandle TElXMLVarMapHandle;

typedef TElXMLVarMapHandle ElXMLVarMapHandle;

typedef TElClassHandle TElXPathNodeHandle;

typedef TElXPathNodeHandle ElXPathNodeHandle;

typedef TElClassHandle TElUnionExprNodeHandle;

typedef TElUnionExprNodeHandle ElUnionExprNodeHandle;

typedef TElClassHandle TElPathExprNodeHandle;

typedef TElPathExprNodeHandle ElPathExprNodeHandle;

typedef TElClassHandle TElLocationPathNodeHandle;

typedef TElLocationPathNodeHandle ElLocationPathNodeHandle;

typedef TElClassHandle TElAbsoluteLocationPathNodeHandle;

typedef TElAbsoluteLocationPathNodeHandle ElAbsoluteLocationPathNodeHandle;

typedef TElClassHandle TElRelativeLocationPathNodeHandle;

typedef TElRelativeLocationPathNodeHandle ElRelativeLocationPathNodeHandle;

typedef TElClassHandle TElStepNodeHandle;

typedef TElStepNodeHandle ElStepNodeHandle;

typedef TElClassHandle TElPredicateNodeHandle;

typedef TElPredicateNodeHandle ElPredicateNodeHandle;

typedef TElClassHandle TElOrExprNodeHandle;

typedef TElOrExprNodeHandle ElOrExprNodeHandle;

typedef TElClassHandle TElAndExprNodeHandle;

typedef TElAndExprNodeHandle ElAndExprNodeHandle;

typedef TElClassHandle TElEqualityExprNodeHandle;

typedef TElEqualityExprNodeHandle ElEqualityExprNodeHandle;

typedef TElClassHandle TElRelationalExprNodeHandle;

typedef TElRelationalExprNodeHandle ElRelationalExprNodeHandle;

typedef TElClassHandle TElAdditiveExprNodeHandle;

typedef TElAdditiveExprNodeHandle ElAdditiveExprNodeHandle;

typedef TElClassHandle TElMultiplicativeExprNodeHandle;

typedef TElMultiplicativeExprNodeHandle ElMultiplicativeExprNodeHandle;

typedef TElClassHandle TElUnaryExprNodeHandle;

typedef TElUnaryExprNodeHandle ElUnaryExprNodeHandle;

typedef TElClassHandle TElFilterExprNodeHandle;

typedef TElFilterExprNodeHandle ElFilterExprNodeHandle;

typedef TElClassHandle TElPrimaryExprNodeHandle;

typedef TElPrimaryExprNodeHandle ElPrimaryExprNodeHandle;

typedef TElClassHandle TElVariableReferenceNodeHandle;

typedef TElVariableReferenceNodeHandle ElVariableReferenceNodeHandle;

typedef TElClassHandle TElLiteralNodeHandle;

typedef TElLiteralNodeHandle ElLiteralNodeHandle;

typedef TElClassHandle TElNumberNodeHandle;

typedef TElNumberNodeHandle ElNumberNodeHandle;

typedef TElClassHandle TElFunctionCallNodeHandle;

typedef TElFunctionCallNodeHandle ElFunctionCallNodeHandle;

typedef uint8_t TXPathNodeTypeRaw;

typedef enum
{
	pntUnknown = 0,
	pntUnionExpr = 1,
	pntPathExpr = 2,
	pntFilterExpr = 3,
	pntAbsoluteLocationPath = 4,
	pntRelativeLocationPath = 5,
	pntStep = 6,
	pntPredicate = 7,
	pntOrExpr = 8,
	pntAndExpr = 9,
	pntEqualityExpr = 10,
	pntRelationalExpr = 11,
	pntAdditiveExpr = 12,
	pntMultiplicativeExpr = 13,
	pntUnaryExpr = 14,
	pntPrimaryExpr = 15,
	pntVariableReference = 16,
	pntLiteral = 17,
	pntNumber = 18,
	pntFunctionCall = 19
} TXPathNodeType;

typedef uint8_t TElAxisTypeRaw;

typedef enum
{
	atAncestor = 0,
	atAncestor_or_self = 1,
	atAttribute = 2,
	atChild = 3,
	atDescendant = 4,
	atDescendant_or_self = 5,
	atFollowing = 6,
	atFollowing_sibling = 7,
	atNamespace = 8,
	atParent = 9,
	atPreceding = 10,
	atPreceding_sibling = 11,
	atSelf = 12
} TElAxisType;

typedef uint8_t TElNodeTestTypeRaw;

typedef enum
{
	ntNameTest = 0,
	ntNodeTypeComent = 1,
	ntNodeTypeText = 2,
	ntNodeTypeProcessingInstruction = 3,
	ntNodeTypeNode = 4
} TElNodeTestType;

typedef uint8_t TElEqualityExprTypeRaw;

typedef enum
{
	eetEqual = 0,
	eetUnequal = 1
} TElEqualityExprType;

typedef uint8_t TElRelationalExprTypeRaw;

typedef enum
{
	retLess = 0,
	retAdvance = 1,
	retLessOrEqual = 2,
	retAdvanceOrEqual = 3
} TElRelationalExprType;

typedef uint8_t TElAdditiveExprTypeRaw;

typedef enum
{
	aetAdd = 0,
	retSub = 1
} TElAdditiveExprType;

typedef uint8_t TElMultiplicativeExprTypeRaw;

typedef enum
{
	metMul = 0,
	metDiv = 1,
	metMod = 2
} TElMultiplicativeExprType;

typedef void (SB_CALLBACK *TSBXPathCustomFunctionEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcFunctionName, int32_t szFunctionName, TListHandle * List);

#ifdef SB_USE_CLASS_TELXPATH
SB_IMPORT uint32_t SB_APIENTRY TElXPath_ProcessQuery(TElXPathHandle _Handle, const char * pcXPathQuery, int32_t szXPathQuery, TElXMLNodeSetHandle List, TElXMLDOMNodeHandle Node, TElXMLNamespaceMapHandle NSList, TElXMLVarMapHandle VarMap);
SB_IMPORT uint32_t SB_APIENTRY TElXPath_get_OnCustomFunction(TElXPathHandle _Handle, TSBXPathCustomFunctionEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXPath_set_OnCustomFunction(TElXPathHandle _Handle, TSBXPathCustomFunctionEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXPath_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXPATH */

#ifdef SB_USE_CLASS_TELNUMBER
SB_IMPORT uint32_t SB_APIENTRY TElNumber_IsNaN(TElNumberHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElNumber_IsInteger(TElNumberHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElNumber_GetInteger(TElNumberHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElNumber_GetReal(TElNumberHandle _Handle, double * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElNumber_SetReal(TElNumberHandle _Handle, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElNumber_Create(TElNumberHandle * OutResult);
#endif /* SB_USE_CLASS_TELNUMBER */

#ifdef SB_USE_CLASS_TELBOOLEAN
SB_IMPORT uint32_t SB_APIENTRY TElBoolean_IsNaN(TElBooleanHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoolean_GetValue(TElBooleanHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElBoolean_Create(TElBooleanHandle * OutResult);
#endif /* SB_USE_CLASS_TELBOOLEAN */

#ifdef SB_USE_CLASS_TELSTRING
SB_IMPORT uint32_t SB_APIENTRY TElString_IsNaN(TElStringHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElString_GetValue(TElStringHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElString_Create(TElStringHandle * OutResult);
#endif /* SB_USE_CLASS_TELSTRING */

#ifdef SB_USE_CLASS_TELXMLVARMAP
SB_IMPORT uint32_t SB_APIENTRY TElXMLVarMap_Add(TElXMLVarMapHandle _Handle, const char * pcVarName, int32_t szVarName, TObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVarMap_AddNodeList(TElXMLVarMapHandle _Handle, const char * pcVarName, int32_t szVarName, TElXMLNodeSetHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVarMap_AddBoolean(TElXMLVarMapHandle _Handle, const char * pcVarName, int32_t szVarName, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVarMap_AddNumber(TElXMLVarMapHandle _Handle, const char * pcVarName, int32_t szVarName, double Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVarMap_AddString(TElXMLVarMapHandle _Handle, const char * pcVarName, int32_t szVarName, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVarMap_Clear(TElXMLVarMapHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVarMap_Delete(TElXMLVarMapHandle _Handle, const char * pcVarName, int32_t szVarName);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVarMap_GetValue(TElXMLVarMapHandle _Handle, const char * pcVarName, int32_t szVarName, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVarMap_Create(TElXMLVarMapHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLVARMAP */

#ifdef SB_USE_CLASS_TELXPATHNODE
SB_IMPORT uint32_t SB_APIENTRY TElXPathNode_DestroyNode(TElXPathNodeHandle Node);
SB_IMPORT uint32_t SB_APIENTRY TElXPathNode_DestroyNode_1(TElXPathNodeHandle _Handle, TElXPathNodeHandle Node);
SB_IMPORT uint32_t SB_APIENTRY TElXPathNode_GetResultList(TElXPathNodeHandle _Handle, TListHandle List, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXPathNode_GetResultNumber(TElXPathNodeHandle _Handle, TElXMLDOMNodeHandle Context, TListHandle List, TElNumberHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXPathNode_GetResultBoolean(TElXPathNodeHandle _Handle, TElXMLDOMNodeHandle Context, TListHandle List, TElBooleanHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXPathNode_GetResultString(TElXPathNodeHandle _Handle, TElXMLDOMNodeHandle Context, TListHandle List, TElStringHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXPathNode_GetResult(TElXPathNodeHandle _Handle, TElXMLDOMNodeHandle Context, TListHandle InList, int32_t * iType, TListHandle * List, TElBooleanHandle * Boolean, TElNumberHandle * Number, TElStringHandle * sString);
SB_IMPORT uint32_t SB_APIENTRY TElXPathNode_Create(TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELXPATHNODE */

#ifdef SB_USE_CLASS_TELUNIONEXPRNODE
SB_IMPORT uint32_t SB_APIENTRY TElUnionExprNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUnionExprNode_CreateNode_1(TElUnionExprNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUnionExprNode_GetResList(TElUnionExprNodeHandle _Handle, TListHandle List, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUnionExprNode_Create(TElXPathHandle XPath, TElUnionExprNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELUNIONEXPRNODE */

#ifdef SB_USE_CLASS_TELPATHEXPRNODE
SB_IMPORT uint32_t SB_APIENTRY TElPathExprNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPathExprNode_CreateNode_1(TElPathExprNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPathExprNode_GetResList(TElPathExprNodeHandle _Handle, TListHandle List, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPathExprNode_Create(TElXPathHandle XPath, TElPathExprNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELPATHEXPRNODE */

#ifdef SB_USE_CLASS_TELLOCATIONPATHNODE
SB_IMPORT uint32_t SB_APIENTRY TElLocationPathNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLocationPathNode_CreateNode_1(TElLocationPathNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLocationPathNode_Create(TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELLOCATIONPATHNODE */

#ifdef SB_USE_CLASS_TELABSOLUTELOCATIONPATHNODE
SB_IMPORT uint32_t SB_APIENTRY TElAbsoluteLocationPathNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbsoluteLocationPathNode_CreateNode_1(TElAbsoluteLocationPathNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbsoluteLocationPathNode_GetResList(TElAbsoluteLocationPathNodeHandle _Handle, TListHandle List, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAbsoluteLocationPathNode_Create(TElXPathHandle XPath, TElAbsoluteLocationPathNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELABSOLUTELOCATIONPATHNODE */

#ifdef SB_USE_CLASS_TELRELATIVELOCATIONPATHNODE
SB_IMPORT uint32_t SB_APIENTRY TElRelativeLocationPathNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeLocationPathNode_CreateNode_1(TElRelativeLocationPathNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeLocationPathNode_GetResList(TElRelativeLocationPathNodeHandle _Handle, TListHandle List, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelativeLocationPathNode_Create(TElXPathHandle XPath, TElRelativeLocationPathNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELRELATIVELOCATIONPATHNODE */

#ifdef SB_USE_CLASS_TELSTEPNODE
SB_IMPORT uint32_t SB_APIENTRY TElStepNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStepNode_CreateNode_1(TElStepNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStepNode_GetResList(TElStepNodeHandle _Handle, TListHandle List, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElStepNode_Create(TElXPathHandle XPath, TElStepNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSTEPNODE */

#ifdef SB_USE_CLASS_TELPREDICATENODE
SB_IMPORT uint32_t SB_APIENTRY TElPredicateNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPredicateNode_CreateNode_1(TElPredicateNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPredicateNode_GetResList(TElPredicateNodeHandle _Handle, TListHandle List, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPredicateNode_Create(TElXPathHandle XPath, TElPredicateNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELPREDICATENODE */

#ifdef SB_USE_CLASS_TELOREXPRNODE
SB_IMPORT uint32_t SB_APIENTRY TElOrExprNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOrExprNode_CreateNode_1(TElOrExprNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOrExprNode_GetResBoolean(TElOrExprNodeHandle _Handle, TElXMLDOMNodeHandle Context, TListHandle List, TElBooleanHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElOrExprNode_Create(TElXPathHandle XPath, TElOrExprNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELOREXPRNODE */

#ifdef SB_USE_CLASS_TELANDEXPRNODE
SB_IMPORT uint32_t SB_APIENTRY TElAndExprNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAndExprNode_CreateNode_1(TElAndExprNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAndExprNode_GetResBoolean(TElAndExprNodeHandle _Handle, TElXMLDOMNodeHandle Context, TListHandle List, TElBooleanHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAndExprNode_Create(TElXPathHandle XPath, TElAndExprNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELANDEXPRNODE */

#ifdef SB_USE_CLASS_TELEQUALITYEXPRNODE
SB_IMPORT uint32_t SB_APIENTRY TElEqualityExprNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElEqualityExprNode_CreateNode_1(TElEqualityExprNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElEqualityExprNode_GetResBoolean(TElEqualityExprNodeHandle _Handle, TElXMLDOMNodeHandle Context, TListHandle List, TElBooleanHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElEqualityExprNode_Create(TElXPathHandle XPath, TElEqualityExprNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELEQUALITYEXPRNODE */

#ifdef SB_USE_CLASS_TELRELATIONALEXPRNODE
SB_IMPORT uint32_t SB_APIENTRY TElRelationalExprNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelationalExprNode_CreateNode_1(TElRelationalExprNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelationalExprNode_GetResBoolean(TElRelationalExprNodeHandle _Handle, TElXMLDOMNodeHandle Context, TListHandle List, TElBooleanHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElRelationalExprNode_Create(TElXPathHandle XPath, TElRelationalExprNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELRELATIONALEXPRNODE */

#ifdef SB_USE_CLASS_TELADDITIVEEXPRNODE
SB_IMPORT uint32_t SB_APIENTRY TElAdditiveExprNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAdditiveExprNode_CreateNode_1(TElAdditiveExprNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAdditiveExprNode_GetResNumber(TElAdditiveExprNodeHandle _Handle, TElXMLDOMNodeHandle Context, TListHandle List, TElNumberHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElAdditiveExprNode_Create(TElXPathHandle XPath, TElAdditiveExprNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELADDITIVEEXPRNODE */

#ifdef SB_USE_CLASS_TELMULTIPLICATIVEEXPRNODE
SB_IMPORT uint32_t SB_APIENTRY TElMultiplicativeExprNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultiplicativeExprNode_CreateNode_1(TElMultiplicativeExprNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultiplicativeExprNode_GetResNumber(TElMultiplicativeExprNodeHandle _Handle, TElXMLDOMNodeHandle Context, TListHandle List, TElNumberHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMultiplicativeExprNode_Create(TElXPathHandle XPath, TElMultiplicativeExprNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELMULTIPLICATIVEEXPRNODE */

#ifdef SB_USE_CLASS_TELUNARYEXPRNODE
SB_IMPORT uint32_t SB_APIENTRY TElUnaryExprNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUnaryExprNode_CreateNode_1(TElUnaryExprNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUnaryExprNode_GetResNumber(TElUnaryExprNodeHandle _Handle, TElXMLDOMNodeHandle Context, TListHandle List, TElNumberHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElUnaryExprNode_Create(TElXPathHandle XPath, TElUnaryExprNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELUNARYEXPRNODE */

#ifdef SB_USE_CLASS_TELFILTEREXPRNODE
SB_IMPORT uint32_t SB_APIENTRY TElFilterExprNode_CreateNode(const char * pcsQuery, int32_t szsQuery, char * pcsQueryTail, int32_t * szsQueryTail, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFilterExprNode_CreateNode_1(TElFilterExprNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, char * pcsQueryTail, int32_t * szsQueryTail, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFilterExprNode_GetResList(TElFilterExprNodeHandle _Handle, TListHandle List, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFilterExprNode_Create(TElXPathHandle XPath, TElFilterExprNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELFILTEREXPRNODE */

#ifdef SB_USE_CLASS_TELPRIMARYEXPRNODE
SB_IMPORT uint32_t SB_APIENTRY TElPrimaryExprNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPrimaryExprNode_CreateNode_1(TElPrimaryExprNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElPrimaryExprNode_Create(TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELPRIMARYEXPRNODE */

#ifdef SB_USE_CLASS_TELVARIABLEREFERENCENODE
SB_IMPORT uint32_t SB_APIENTRY TElVariableReferenceNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVariableReferenceNode_CreateNode_1(TElVariableReferenceNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElVariableReferenceNode_GetResultLocal(TElVariableReferenceNodeHandle _Handle, TElXMLDOMNodeHandle Context, TListHandle InList, int32_t * iType, TListHandle * List, TElBooleanHandle * bBoolean, TElNumberHandle * nNumber, TElStringHandle * sString);
SB_IMPORT uint32_t SB_APIENTRY TElVariableReferenceNode_Create(TElXPathHandle XPath, TElVariableReferenceNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELVARIABLEREFERENCENODE */

#ifdef SB_USE_CLASS_TELLITERALNODE
SB_IMPORT uint32_t SB_APIENTRY TElLiteralNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLiteralNode_CreateNode_1(TElLiteralNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElLiteralNode_Create(TElXPathHandle XPath, TElLiteralNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELLITERALNODE */

#ifdef SB_USE_CLASS_TELNUMBERNODE
SB_IMPORT uint32_t SB_APIENTRY TElNumberNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElNumberNode_CreateNode_1(TElNumberNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElNumberNode_GetResNumber(TElNumberNodeHandle _Handle, TElNumberHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElNumberNode_Create(TElXPathHandle XPath, TElNumberNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELNUMBERNODE */

#ifdef SB_USE_CLASS_TELFUNCTIONCALLNODE
SB_IMPORT uint32_t SB_APIENTRY TElFunctionCallNode_CreateNode(const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFunctionCallNode_CreateNode_1(TElFunctionCallNodeHandle _Handle, const char * pcsQuery, int32_t szsQuery, TElXPathHandle XPath, TElXPathNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElFunctionCallNode_GetResultLocal(TElFunctionCallNodeHandle _Handle, TElXMLDOMNodeHandle Context, TListHandle InList, int32_t * iType, TListHandle * List, TElBooleanHandle * bBoolean, TElNumberHandle * nNumber, TElStringHandle * sString);
SB_IMPORT uint32_t SB_APIENTRY TElFunctionCallNode_Create(TElXPathHandle XPath, TElFunctionCallNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELFUNCTIONCALLNODE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElXPath_ce_ptr;
extern zend_class_entry *TElNumber_ce_ptr;
extern zend_class_entry *TElBoolean_ce_ptr;
extern zend_class_entry *TElString_ce_ptr;
extern zend_class_entry *TElXMLVarMap_ce_ptr;
extern zend_class_entry *TElXPathNode_ce_ptr;
extern zend_class_entry *TElUnionExprNode_ce_ptr;
extern zend_class_entry *TElPathExprNode_ce_ptr;
extern zend_class_entry *TElLocationPathNode_ce_ptr;
extern zend_class_entry *TElAbsoluteLocationPathNode_ce_ptr;
extern zend_class_entry *TElRelativeLocationPathNode_ce_ptr;
extern zend_class_entry *TElStepNode_ce_ptr;
extern zend_class_entry *TElPredicateNode_ce_ptr;
extern zend_class_entry *TElOrExprNode_ce_ptr;
extern zend_class_entry *TElAndExprNode_ce_ptr;
extern zend_class_entry *TElEqualityExprNode_ce_ptr;
extern zend_class_entry *TElRelationalExprNode_ce_ptr;
extern zend_class_entry *TElAdditiveExprNode_ce_ptr;
extern zend_class_entry *TElMultiplicativeExprNode_ce_ptr;
extern zend_class_entry *TElUnaryExprNode_ce_ptr;
extern zend_class_entry *TElFilterExprNode_ce_ptr;
extern zend_class_entry *TElPrimaryExprNode_ce_ptr;
extern zend_class_entry *TElVariableReferenceNode_ce_ptr;
extern zend_class_entry *TElLiteralNode_ce_ptr;
extern zend_class_entry *TElNumberNode_ce_ptr;
extern zend_class_entry *TElFunctionCallNode_ce_ptr;

void SB_CALLBACK TSBXPathCustomFunctionEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcFunctionName, int32_t szFunctionName, TListHandle * List);
void Register_TElXPath(TSRMLS_D);
void Register_TElNumber(TSRMLS_D);
void Register_TElBoolean(TSRMLS_D);
void Register_TElString(TSRMLS_D);
void Register_TElXMLVarMap(TSRMLS_D);
void Register_TElXPathNode(TSRMLS_D);
void Register_TElUnionExprNode(TSRMLS_D);
void Register_TElPathExprNode(TSRMLS_D);
void Register_TElLocationPathNode(TSRMLS_D);
void Register_TElAbsoluteLocationPathNode(TSRMLS_D);
void Register_TElRelativeLocationPathNode(TSRMLS_D);
void Register_TElStepNode(TSRMLS_D);
void Register_TElPredicateNode(TSRMLS_D);
void Register_TElOrExprNode(TSRMLS_D);
void Register_TElAndExprNode(TSRMLS_D);
void Register_TElEqualityExprNode(TSRMLS_D);
void Register_TElRelationalExprNode(TSRMLS_D);
void Register_TElAdditiveExprNode(TSRMLS_D);
void Register_TElMultiplicativeExprNode(TSRMLS_D);
void Register_TElUnaryExprNode(TSRMLS_D);
void Register_TElFilterExprNode(TSRMLS_D);
void Register_TElPrimaryExprNode(TSRMLS_D);
void Register_TElVariableReferenceNode(TSRMLS_D);
void Register_TElLiteralNode(TSRMLS_D);
void Register_TElNumberNode(TSRMLS_D);
void Register_TElFunctionCallNode(TSRMLS_D);
void Register_SBXMLPath_Enum_Flags(TSRMLS_D);
void Register_SBXMLPath_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLPATH */

