#ifndef __INC_SBXMLSAMLCOMMON
#define __INC_SBXMLSAMLCOMMON

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbstringlist.h"
#include "sbstreams.h"
#include "sbconstants.h"
#include "sbdictionary.h"
#include "sbxmlcore.h"
#include "sbxmlsig.h"
#include "sbxmlenc.h"
#include "sbxmlsec.h"
#include "sbxmlutils.h"
#include "sbxmldefs.h"
#include "sbstrutils.h"
#include "sbxmlsamlmetadata.h"
#include "sbxmlsamlprotocol.h"
#include "sbxmlsamlcore.h"
#include "sbxmlsamlbind.h"
#include "sbhttpscommon.h"
#include "sbsharedresource.h"
#include "sbcustomcertstorage.h"
#include "sbx509.h"
#include "sbutils.h"
#include "sbtypes.h"
#include "sbrandom.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SFailedToDownloadMetadata 	"Failed to download metadata: "
#define SB_SWrongEntityID 	"Wrong entityID attribute: "
#define SB_SWrongKeyDescriptor 	"Metadata: wrong KeyDescriptor element"
#define SB_SMetadataIncomplete 	"Metadata is incomplete"
#define SB_SMetadataExpired 	"Matadata expired"
#define SB_SMetadataMultipleDescriptorsAvailable 	"Multiple descriptors are stored in metadata file. Please assign OnChooseMetadataIDPDescriptor event handler to choose the one to use."
#ifndef SB_SDecryptionError
#define SB_SDecryptionError 	"Failed to decrypt encrypted XML element"
#endif
#ifndef SB_SFeatureNotAvailable
#define SB_SFeatureNotAvailable 	"The feature is not available on this platform"
#endif

typedef TElClassHandle TElSAMLClientSettingsHandle;

typedef TElClassHandle TElSAMLSessionHandle;

typedef TElClassHandle TElCustomSessionManagerHandle;

typedef TElClassHandle TElMemorySessionManagerHandle;

typedef TElClassHandle SBXMLSAMLCommon_TElStringValueHandle;

typedef TElClassHandle TElCustomArtifactStorageHandle;

typedef TElClassHandle TElMemoryArtifactStorageHandle;

typedef TElClassHandle TElSAMLAdapterHandle;

typedef uint8_t TSBSAMLClientProfileRaw;

typedef enum
{
	scpWebSSO = 0
} TSBSAMLClientProfile;

typedef uint32_t TSBSAMLClientProfilesRaw;

typedef enum 
{
	f_scpWebSSO = 1
} TSBSAMLClientProfiles;

typedef uint8_t TSBSAMLClientStateRaw;

typedef enum
{
	scsStart = 0,
	scsSAMLRequestRecv = 1,
	scsSAMLRequestSent = 2,
	scsIdentRecv = 3,
	scsIdentSent = 4,
	scsResponseRecv = 5,
	scsResponseSent = 6
} TSBSAMLClientState;

typedef uint8_t TSBSAMLAccessLevelRaw;

typedef enum
{
	salDomain = 0,
	salExactURL = 1
} TSBSAMLAccessLevel;

typedef void (SB_CALLBACK *TSBSAMLResourceOpenEvent)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, void * (* Handle));

typedef void (SB_CALLBACK *TSBSAMLResourceReadEvent)(void * _ObjectData, TObjectHandle Sender, void * Handle, uint8_t pBuf[], int32_t * szBuf, int32_t * Size);

typedef void (SB_CALLBACK *TSBSAMLResourceCloseEvent)(void * _ObjectData, TObjectHandle Sender, void * Handle);

typedef void (SB_CALLBACK *TSBSAMLMetadataPreparedEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLMetadataHandle Metadata);

typedef void (SB_CALLBACK *TSBSAMLBeforeBindingUseEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLBindingHandle Binding);

typedef void (SB_CALLBACK *SBXMLSAMLCommon_TSBSAMLBeforeHTTPSServerUseEvent)(void * _ObjectData, TObjectHandle Sender, TObjectHandle HTTPSServer);

typedef void (SB_CALLBACK *TSBSAMLBeforeHTTPSClientUseEvent)(void * _ObjectData, TObjectHandle Sender, TObjectHandle HTTPSClient);

typedef void (SB_CALLBACK *TSBSAMLResponderErrorEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLStatusElementHandle Status, int32_t * StatusCode, char * pcRedirectLocation, int32_t * szRedirectLocation);

typedef void (SB_CALLBACK *TSBSAMLResponseStatusCodeEvent)(void * _ObjectData, TObjectHandle Sender, int32_t * StatusCode, char * pcErrorMessage, int32_t * szErrorMessage, int8_t * DestroySession);

typedef void (SB_CALLBACK *TSBSAMLRequestPreparedEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLRequestAbstractTypeHandle Request);

typedef void (SB_CALLBACK *TSBSAMLResponsePreparedEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLStatusResponseTypeHandle Request);

typedef void (SB_CALLBACK *TSBSAMLResponseReceivedEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLStatusResponseTypeHandle Response, int8_t * Accept);

typedef void (SB_CALLBACK *TSBSAMLRequestReceivedEvent)(void * _ObjectData, TObjectHandle Sender, TElSAMLRequestAbstractTypeHandle Request, int8_t * Accept);

typedef void (SB_CALLBACK *TSBHTTPSAMLStateChanged)(void * _ObjectData, TObjectHandle Sender, TSBSAMLClientStateRaw State);

typedef void (SB_CALLBACK *TSBHTTPSAMLCredentialsChallenge)(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, const uint8_t pBody[], int32_t szBody, char * pcTargetURL, int32_t * szTargetURL, TElStringListHandle Fields);

#ifdef SB_USE_CLASS_TELSAMLCLIENTSETTINGS
SB_IMPORT uint32_t SB_APIENTRY TElSAMLClientSettings_Reset(TElSAMLClientSettingsHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLClientSettings_get_Enabled(TElSAMLClientSettingsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLClientSettings_set_Enabled(TElSAMLClientSettingsHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLClientSettings_get_Profiles(TElSAMLClientSettingsHandle _Handle, TSBSAMLClientProfilesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLClientSettings_set_Profiles(TElSAMLClientSettingsHandle _Handle, TSBSAMLClientProfilesRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLClientSettings_get_State(TElSAMLClientSettingsHandle _Handle, TSBSAMLClientStateRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLClientSettings_set_State(TElSAMLClientSettingsHandle _Handle, TSBSAMLClientStateRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLClientSettings_get_Proto(TElSAMLClientSettingsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLClientSettings_set_Proto(TElSAMLClientSettingsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLClientSettings_get_IdPURL(TElSAMLClientSettingsHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLClientSettings_set_IdPURL(TElSAMLClientSettingsHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLClientSettings_get_WebSSOEnabled(TElSAMLClientSettingsHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLClientSettings_Create(TElSAMLClientSettingsHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLCLIENTSETTINGS */

#ifdef SB_USE_CLASS_TELSAMLSESSION
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSession_Generate(TElSAMLSessionHandle _Handle, int32_t TTL);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSession_get_URL(TElSAMLSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSession_set_URL(TElSAMLSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSession_get_Session(TElSAMLSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSession_set_Session(TElSAMLSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSession_get_CookieSet(TElSAMLSessionHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSession_set_CookieSet(TElSAMLSessionHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSession_get_RelayState(TElSAMLSessionHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSession_set_RelayState(TElSAMLSessionHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSession_get_Request(TElSAMLSessionHandle _Handle, TElSAMLRequestAbstractTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSession_set_Request(TElSAMLSessionHandle _Handle, TElSAMLRequestAbstractTypeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSession_get_Expires(TElSAMLSessionHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSession_Create(TElSAMLSessionHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSESSION */

#ifdef SB_USE_CLASS_TELCUSTOMSESSIONMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElCustomSessionManager_Lock(TElCustomSessionManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSessionManager_Unlock(TElCustomSessionManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSessionManager_Clear(TElCustomSessionManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSessionManager_Add(TElCustomSessionManagerHandle _Handle, TElSAMLSessionHandle Session, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSessionManager_Remove(TElCustomSessionManagerHandle _Handle, int32_t Index, TElSAMLSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSessionManager_Remove_1(TElCustomSessionManagerHandle _Handle, const char * pcSession, int32_t szSession, TElSAMLSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSessionManager_Find(TElCustomSessionManagerHandle _Handle, const char * pcSession, int32_t szSession, TElSAMLSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSessionManager_get_Count(TElCustomSessionManagerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSessionManager_get_Sessions(TElCustomSessionManagerHandle _Handle, int32_t Index, TElSAMLSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomSessionManager_Create(TElCustomSessionManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMSESSIONMANAGER */

#ifdef SB_USE_CLASS_TELMEMORYSESSIONMANAGER
SB_IMPORT uint32_t SB_APIENTRY TElMemorySessionManager_Lock(TElMemorySessionManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElMemorySessionManager_Unlock(TElMemorySessionManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElMemorySessionManager_Clear(TElMemorySessionManagerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElMemorySessionManager_Add(TElMemorySessionManagerHandle _Handle, TElSAMLSessionHandle Session, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMemorySessionManager_Remove(TElMemorySessionManagerHandle _Handle, int32_t Index, TElSAMLSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMemorySessionManager_Remove_1(TElMemorySessionManagerHandle _Handle, const char * pcSession, int32_t szSession, TElSAMLSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMemorySessionManager_Find(TElMemorySessionManagerHandle _Handle, const char * pcSession, int32_t szSession, TElSAMLSessionHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMemorySessionManager_Create(TElMemorySessionManagerHandle * OutResult);
#endif /* SB_USE_CLASS_TELMEMORYSESSIONMANAGER */

#ifdef SB_USE_CLASS_SBXMLSAMLCOMMON_TELSTRINGVALUE
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCommon_TElStringValue_get_Value(SBXMLSAMLCommon_TElStringValueHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCommon_TElStringValue_set_Value(SBXMLSAMLCommon_TElStringValueHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCommon_TElStringValue_Create(const char * pcValue, int32_t szValue, SBXMLSAMLCommon_TElStringValueHandle * OutResult);
#endif /* SB_USE_CLASS_SBXMLSAMLCOMMON_TELSTRINGVALUE */

#ifdef SB_USE_CLASS_TELCUSTOMARTIFACTSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElCustomArtifactStorage_Clear(TElCustomArtifactStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElCustomArtifactStorage_Add(TElCustomArtifactStorageHandle _Handle, const uint8_t pHandle[], int32_t szHandle, const char * pcBody, int32_t szBody, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomArtifactStorage_Get(TElCustomArtifactStorageHandle _Handle, const uint8_t pHandle[], int32_t szHandle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElCustomArtifactStorage_Create(TElCustomArtifactStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELCUSTOMARTIFACTSTORAGE */

#ifdef SB_USE_CLASS_TELMEMORYARTIFACTSTORAGE
SB_IMPORT uint32_t SB_APIENTRY TElMemoryArtifactStorage_Clear(TElMemoryArtifactStorageHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElMemoryArtifactStorage_Add(TElMemoryArtifactStorageHandle _Handle, const uint8_t pHandle[], int32_t szHandle, const char * pcBody, int32_t szBody, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMemoryArtifactStorage_Get(TElMemoryArtifactStorageHandle _Handle, const uint8_t pHandle[], int32_t szHandle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElMemoryArtifactStorage_Create(TElMemoryArtifactStorageHandle * OutResult);
#endif /* SB_USE_CLASS_TELMEMORYARTIFACTSTORAGE */

#ifdef SB_USE_CLASS_TELSAMLADAPTER
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdapter_HandleDocumentEnd(TElSAMLAdapterHandle _Handle, TElHTTPSClientParamsHandle Param);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdapter_Reset(TElSAMLAdapterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdapter_HandlePerformExchange(TElSAMLAdapterHandle _Handle, TElHTTPSClientParamsHandle Param);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdapter_HandleRedirection(TElSAMLAdapterHandle _Handle, TElHTTPSClientParamsHandle Param);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdapter_HandleReadyData(TElSAMLAdapterHandle _Handle, const uint8_t pBuf[], int32_t szBuf);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdapter_get_SAMLSettings(TElSAMLAdapterHandle _Handle, TElSAMLClientSettingsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdapter_get_OnSAMLStateChanged(TElSAMLAdapterHandle _Handle, TSBHTTPSAMLStateChanged * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdapter_set_OnSAMLStateChanged(TElSAMLAdapterHandle _Handle, TSBHTTPSAMLStateChanged pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdapter_get_OnSAMLParseForm(TElSAMLAdapterHandle _Handle, TSBSAMLPOSTBindingParseForm * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdapter_set_OnSAMLParseForm(TElSAMLAdapterHandle _Handle, TSBSAMLPOSTBindingParseForm pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdapter_get_OnSAMLCredentialsChallenge(TElSAMLAdapterHandle _Handle, TSBHTTPSAMLCredentialsChallenge * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdapter_set_OnSAMLCredentialsChallenge(TElSAMLAdapterHandle _Handle, TSBHTTPSAMLCredentialsChallenge pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdapter_Create(TElSAMLAdapterHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLADAPTER */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSAMLClientSettings_ce_ptr;
extern zend_class_entry *TElSAMLSession_ce_ptr;
extern zend_class_entry *TElCustomSessionManager_ce_ptr;
extern zend_class_entry *TElMemorySessionManager_ce_ptr;
extern zend_class_entry *SBXMLSAMLCommon_TElStringValue_ce_ptr;
extern zend_class_entry *TElCustomArtifactStorage_ce_ptr;
extern zend_class_entry *TElMemoryArtifactStorage_ce_ptr;
extern zend_class_entry *TElSAMLAdapter_ce_ptr;

void SB_CALLBACK TSBSAMLResourceOpenEventRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, void * (* Handle));
void SB_CALLBACK TSBSAMLResourceReadEventRaw(void * _ObjectData, TObjectHandle Sender, void * Handle, uint8_t pBuf[], int32_t * szBuf, int32_t * Size);
void SB_CALLBACK TSBSAMLResourceCloseEventRaw(void * _ObjectData, TObjectHandle Sender, void * Handle);
void SB_CALLBACK TSBSAMLMetadataPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLMetadataHandle Metadata);
void SB_CALLBACK TSBSAMLBeforeBindingUseEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLBindingHandle Binding);
void SB_CALLBACK SBXMLSAMLCommon_TSBSAMLBeforeHTTPSServerUseEventRaw(void * _ObjectData, TObjectHandle Sender, TObjectHandle HTTPSServer);
void SB_CALLBACK TSBSAMLBeforeHTTPSClientUseEventRaw(void * _ObjectData, TObjectHandle Sender, TObjectHandle HTTPSClient);
void SB_CALLBACK TSBSAMLResponderErrorEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLStatusElementHandle Status, int32_t * StatusCode, char * pcRedirectLocation, int32_t * szRedirectLocation);
void SB_CALLBACK TSBSAMLResponseStatusCodeEventRaw(void * _ObjectData, TObjectHandle Sender, int32_t * StatusCode, char * pcErrorMessage, int32_t * szErrorMessage, int8_t * DestroySession);
void SB_CALLBACK TSBSAMLRequestPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLRequestAbstractTypeHandle Request);
void SB_CALLBACK TSBSAMLResponsePreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLStatusResponseTypeHandle Request);
void SB_CALLBACK TSBSAMLResponseReceivedEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLStatusResponseTypeHandle Response, int8_t * Accept);
void SB_CALLBACK TSBSAMLRequestReceivedEventRaw(void * _ObjectData, TObjectHandle Sender, TElSAMLRequestAbstractTypeHandle Request, int8_t * Accept);
void SB_CALLBACK TSBHTTPSAMLStateChangedRaw(void * _ObjectData, TObjectHandle Sender, TSBSAMLClientStateRaw State);
void SB_CALLBACK TSBHTTPSAMLCredentialsChallengeRaw(void * _ObjectData, TObjectHandle Sender, const char * pcURL, int32_t szURL, const uint8_t pBody[], int32_t szBody, char * pcTargetURL, int32_t * szTargetURL, TElStringListHandle Fields);
void Register_TElSAMLClientSettings(TSRMLS_D);
void Register_TElSAMLSession(TSRMLS_D);
void Register_TElCustomSessionManager(TSRMLS_D);
void Register_TElMemorySessionManager(TSRMLS_D);
void Register_SBXMLSAMLCommon_TElStringValue(TSRMLS_D);
void Register_TElCustomArtifactStorage(TSRMLS_D);
void Register_TElMemoryArtifactStorage(TSRMLS_D);
void Register_TElSAMLAdapter(TSRMLS_D);
SB_PHP_FUNCTION(SBXMLSAMLCommon, XMLDocToStr);
void Register_SBXMLSAMLCommon_Constants(int module_number TSRMLS_DC);
void Register_SBXMLSAMLCommon_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_XMLSAMLCOMMON
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCommon_XMLDocToStr(TElXMLDOMDocumentHandle Doc, char * pcOutResult, int32_t * szOutResult);
#endif /* SB_USE_GLOBAL_PROCS_XMLSAMLCOMMON */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLSAMLCOMMON */

