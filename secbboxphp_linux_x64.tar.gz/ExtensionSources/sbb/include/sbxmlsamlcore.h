#ifndef __INC_SBXMLSAMLCORE
#define __INC_SBXMLSAMLCORE

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbconstants.h"
#include "sbcertvalidator.h"
#include "sbcustomcertstorage.h"
#include "sbx509.h"
#include "sbsharedresource.h"
#include "sbxmlcore.h"
#include "sbxmlsig.h"
#include "sbxmlenc.h"
#include "sbxmlsec.h"
#include "sbxmlutils.h"
#include "sbxmldefs.h"
#include "sbxmltransform.h"
#include "sbxmlcharsets.h"
#include "sbstreams.h"
#include "sbstrutils.h"
#include "sbrandom.h"
#include "sbutils.h"
#include "sbtypes.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_BUF_SZ 	102400
#define SB_SAML_TIMEZONE_UTC 	0
#define SB_SAML_TIMEZONE_LOCAL 	-1
#define SB_SAMLVersion 	"2.0"
#define SB_xmlSAMLAssertionNamespace 	"urn:oasis:names:tc:SAML:2.0:assertion"
#define SB_xmlSAMLProtocolNamespace 	"urn:oasis:names:tc:SAML:2.0:protocol"
#define SB_xmlSAMLMetadataNamespace 	"urn:oasis:names:tc:SAML:2.0:metadata"
#define SB_xmlSAMLMDPrefix 	"md"
#define SB_xmlSAMLNameIDFormatUnspecified 	"urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified"
#define SB_xmlSAMLNameIDFormatEmailAddress11 	"urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress"
#define SB_xmlSAMLNameIDFormatEmailAddress 	"urn:oasis:names:tc:SAML:2.0:nameid-format:email"
#define SB_xmlSAMLNameIDFormatX509SubjectName 	"urn:oasis:names:tc:SAML:1.1:nameid-format:X509SubjectName"
#define SB_xmlSAMLNameIDFormatWindowsDomainQualifiedName 	"urn:oasis:names:tc:SAML:1.1:nameid-format:WindowsDomainQualifiedName"
#define SB_xmlSAMLNameIDFormatKerberos 	"urn:oasis:names:tc:SAML:2.0:nameid-format:kerberos"
#define SB_xmlSAMLNameIDFormatEntity 	"urn:oasis:names:tc:SAML:2.0:nameid-format:entity"
#define SB_xmlSAMLNameIDFormatPersistent 	"urn:oasis:names:tc:SAML:2.0:nameid-format:persistent"
#define SB_xmlSAMLNameIDFormatTransient 	"urn:oasis:names:tc:SAML:2.0:nameid-format:transient"
#define SB_xmlSAMLKeyInfoConfirmationDataType 	"saml:KeyInfoConfirmationDataType"
#define SB_xmlSAMLPrefix 	"saml"
#define SB_xmlSAMLProtocolPrefix 	"samlp"
#define SB_SNotImplemented 	"Not implemented"
#define SB_SMissingAttribute 	"Missing required attribute"
#define SB_SMissingElement 	"Missing required element"
#ifndef SB_SInvalidAttributeValue
#define SB_SInvalidAttributeValue 	"Invalid attribute value"
#endif
#define SB_SEncryptionError 	"Encryption error"
#ifndef SB_SDecryptionError
#define SB_SDecryptionError 	"Decryption error %d"
#endif
#ifndef SB_SInvalidSignature
#define SB_SInvalidSignature 	"Element signature is invalid"
#endif
#define SB_SPermit 	"Permit"
#define SB_SDeny 	"Deny"
#define SB_SIndeterminate 	"Indeterminate"
#define SB_STrue1 	"true"
#define SB_STrue2 	"1"
#define SB_SFalse1 	"false"
#define SB_SFalse2 	"0"

typedef TElClassHandle TElSAMLSubjectElementHandle;

typedef TElClassHandle TElSAMLConditionsElementHandle;

typedef TElClassHandle TElSAMLAdviceElementHandle;

typedef TElClassHandle TElSAMLSubjectConfirmationDataElementHandle;

typedef TElClassHandle TElSAMLStatementAbstractTypeHandle;

typedef TElClassHandle TElSAMLSubjectConfirmationElementHandle;

typedef TElClassHandle TElSAMLSecurityHandlerHandle;

typedef TElClassHandle TElSAMLSignatureHandlerHandle;

typedef TElClassHandle TElSAMLEncryptionHandlerHandle;

typedef TElClassHandle TElSAMLElementHandle;

typedef TElClassHandle TElSAMLIDHandle;

typedef TElClassHandle TElSAMLBaseIDElementHandle;

typedef TElClassHandle TElSAMLNameIDElementHandle;

typedef TElClassHandle TElSAMLEncryptedElementHandle;

typedef TElClassHandle TElSAMLEncryptedIDElementHandle;

typedef TElClassHandle TElSAMLIssuerElementHandle;

typedef TElClassHandle TElSAMLAssertionTypeHandle;

typedef TElClassHandle TElSAMLAssertionIDRefElementHandle;

typedef TElClassHandle TElSAMLAssertionURIRefElementHandle;

typedef TElClassHandle TElSAMLAssertionElementHandle;

typedef TElClassHandle TElSAMLEncryptedAssertionElementHandle;

typedef TElClassHandle TElSAMLConditionAbstractTypeHandle;

typedef TElClassHandle TElSAMLAudienceElementHandle;

typedef TElClassHandle TElSAMLAudienceRestrictionElementHandle;

typedef TElClassHandle TElSAMLOneTimeUseElementHandle;

typedef TElClassHandle TElSAMLProxyRestrictionElementHandle;

typedef TElClassHandle TElSAMLSubjectLocalityElementHandle;

typedef TElSAMLElementHandle TElSAMLAuthnContextDeclHandle;

typedef TElClassHandle TElSAMLAuthnContextElementHandle;

typedef TElClassHandle TElSAMLAuthnStatementElementHandle;

typedef TElClassHandle TElSAMLAttributeTypeHandle;

typedef TElClassHandle TElSAMLAttributeValueHandle;

typedef TElClassHandle TElSAMLAttributeElementHandle;

typedef TElClassHandle TElSAMLEncryptedAttributeElementHandle;

typedef TElClassHandle TElSAMLAttributeStatementElementHandle;

typedef TElClassHandle TElSAMLActionElementHandle;

typedef TElClassHandle TElSAMLEvidenceElementHandle;

typedef TElClassHandle TElSAMLAuthzDecisionStatementElementHandle;

typedef void (SB_CALLBACK *TSBSAMLCertValidatorPreparedEvent)(void * _ObjectData, TObjectHandle Sender, TElX509CertificateValidatorHandle * CertValidator, TElX509CertificateHandle Cert);

typedef void (SB_CALLBACK *TSBSAMLXMLSignerPreparedEvent)(void * _ObjectData, TObjectHandle Sender, TElXMLSignerHandle * Signer);

typedef void (SB_CALLBACK *TSBSAMLXMLVerifierPreparedEvent)(void * _ObjectData, TObjectHandle Sender, TElXMLVerifierHandle * Verifier);

typedef void (SB_CALLBACK *TSBSAMLXMLEncryptorPreparedEvent)(void * _ObjectData, TObjectHandle Sender, TElXMLEncryptorHandle * Encryptor);

typedef void (SB_CALLBACK *TSBSAMLXMLDecryptorPreparedEvent)(void * _ObjectData, TObjectHandle Sender, TElXMLDecryptorHandle * Decryptor);

typedef uint8_t TSBSAMLAuthnContextChoiceRaw;

typedef enum
{
	sacV1 = 0,
	sacV2 = 1
} TSBSAMLAuthnContextChoice;

typedef uint8_t TSBSAMLDecisionRaw;

typedef enum
{
	sadnPermit = 0,
	sadnDeny = 1,
	sadnIndeterminate = 2
} TSBSAMLDecision;

#ifdef SB_USE_CLASS_TELSAMLELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLElement_Assign(TElSAMLElementHandle _Handle, TElSAMLElementHandle Other);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLElement_LoadFromXML(TElSAMLElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLElement_SaveToXML(TElSAMLElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLElement_get_Tag(TElSAMLElementHandle _Handle, TObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLElement_set_Tag(TElSAMLElementHandle _Handle, TObjectHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLElement_get_Handler(TElSAMLElementHandle _Handle, TElSAMLSecurityHandlerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLElement_set_Handler(TElSAMLElementHandle _Handle, TElSAMLSecurityHandlerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLElement_get_TextValue(TElSAMLElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLELEMENT */

#ifdef SB_USE_CLASS_TELSAMLCONDITIONSELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_Clear(TElSAMLConditionsElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_LoadFromXML(TElSAMLConditionsElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_SaveToXML(TElSAMLConditionsElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_AddCondition(TElSAMLConditionsElementHandle _Handle, TElSAMLConditionAbstractTypeHandle Cond, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_RemoveCondition(TElSAMLConditionsElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_get_OneTimeUse(TElSAMLConditionsElementHandle _Handle, TElSAMLOneTimeUseElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_get_ProxyRestriction(TElSAMLConditionsElementHandle _Handle, TElSAMLProxyRestrictionElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_get_NotBefore(TElSAMLConditionsElementHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_set_NotBefore(TElSAMLConditionsElementHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_get_NotOnOrAfter(TElSAMLConditionsElementHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_set_NotOnOrAfter(TElSAMLConditionsElementHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_get_Conditions(TElSAMLConditionsElementHandle _Handle, int32_t Index, TElSAMLConditionAbstractTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_get_ConditionCount(TElSAMLConditionsElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionsElement_Create(TElSAMLConditionsElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLCONDITIONSELEMENT */

#ifdef SB_USE_CLASS_TELSAMLADVICEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdviceElement_Clear(TElSAMLAdviceElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdviceElement_LoadFromXML(TElSAMLAdviceElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdviceElement_SaveToXML(TElSAMLAdviceElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdviceElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdviceElement_AddAssertion(TElSAMLAdviceElementHandle _Handle, TElSAMLAssertionTypeHandle Assertion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdviceElement_RemoveAssertion(TElSAMLAdviceElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdviceElement_get_Others(TElSAMLAdviceElementHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdviceElement_get_Assertions(TElSAMLAdviceElementHandle _Handle, int32_t Index, TElSAMLAssertionTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdviceElement_get_AssertionCount(TElSAMLAdviceElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAdviceElement_Create(TElSAMLAdviceElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLADVICEELEMENT */

#ifdef SB_USE_CLASS_TELSAMLSUBJECTCONFIRMATIONDATAELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_Clear(TElSAMLSubjectConfirmationDataElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_LoadFromXML(TElSAMLSubjectConfirmationDataElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_SaveToXML(TElSAMLSubjectConfirmationDataElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_AddArbitraryElement(TElSAMLSubjectConfirmationDataElementHandle _Handle, TElXMLCustomElementHandle Elem, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_AddArbitraryAttribute(TElSAMLSubjectConfirmationDataElementHandle _Handle, TElXMLDOMAttrHandle Attr, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_RemoveArbitraryElement(TElSAMLSubjectConfirmationDataElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_RemoveArbitraryAttribute(TElSAMLSubjectConfirmationDataElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_get_AType(TElSAMLSubjectConfirmationDataElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_set_AType(TElSAMLSubjectConfirmationDataElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_get_NotBefore(TElSAMLSubjectConfirmationDataElementHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_set_NotBefore(TElSAMLSubjectConfirmationDataElementHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_get_NotOnOrAfter(TElSAMLSubjectConfirmationDataElementHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_set_NotOnOrAfter(TElSAMLSubjectConfirmationDataElementHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_get_Recipient(TElSAMLSubjectConfirmationDataElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_set_Recipient(TElSAMLSubjectConfirmationDataElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_get_InResponseTo(TElSAMLSubjectConfirmationDataElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_set_InResponseTo(TElSAMLSubjectConfirmationDataElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_get_Address(TElSAMLSubjectConfirmationDataElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_set_Address(TElSAMLSubjectConfirmationDataElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_get_ArbitraryElements(TElSAMLSubjectConfirmationDataElementHandle _Handle, int32_t Index, TElXMLCustomElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_get_ArbitraryAttributes(TElSAMLSubjectConfirmationDataElementHandle _Handle, int32_t Index, TElXMLDOMAttrHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_get_ArbitraryElementCount(TElSAMLSubjectConfirmationDataElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_get_ArbitraryAttributeCount(TElSAMLSubjectConfirmationDataElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationDataElement_Create(TElSAMLSubjectConfirmationDataElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSUBJECTCONFIRMATIONDATAELEMENT */

#ifdef SB_USE_CLASS_TELSAMLSTATEMENTABSTRACTTYPE
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatementAbstractType_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSTATEMENTABSTRACTTYPE */

#ifdef SB_USE_CLASS_TELSAMLSUBJECTCONFIRMATIONELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationElement_Clear(TElSAMLSubjectConfirmationElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationElement_LoadFromXML(TElSAMLSubjectConfirmationElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationElement_SaveToXML(TElSAMLSubjectConfirmationElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationElement_get_ID(TElSAMLSubjectConfirmationElementHandle _Handle, TElSAMLIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationElement_set_ID(TElSAMLSubjectConfirmationElementHandle _Handle, TElSAMLIDHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationElement_get_SubjectConfirmationData(TElSAMLSubjectConfirmationElementHandle _Handle, TElSAMLSubjectConfirmationDataElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationElement_set_SubjectConfirmationData(TElSAMLSubjectConfirmationElementHandle _Handle, TElSAMLSubjectConfirmationDataElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationElement_get__Method(TElSAMLSubjectConfirmationElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationElement_set__Method(TElSAMLSubjectConfirmationElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectConfirmationElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSUBJECTCONFIRMATIONELEMENT */

#ifdef SB_USE_CLASS_TELSAMLSECURITYHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSecurityHandler_Protect(TElSAMLSecurityHandlerHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle Node, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSecurityHandler_Unprotect(TElSAMLSecurityHandlerHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle Input, TElXMLDOMElementHandle * Output, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSecurityHandler_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSECURITYHANDLER */

#ifdef SB_USE_CLASS_TELSAMLSIGNATUREHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_Protect(TElSAMLSignatureHandlerHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle Elem, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_Unprotect(TElSAMLSignatureHandlerHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle Input, TElXMLDOMElementHandle * Output, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_get_CertStorage(TElSAMLSignatureHandlerHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_set_CertStorage(TElSAMLSignatureHandlerHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_get_Certificate(TElSAMLSignatureHandlerHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_set_Certificate(TElSAMLSignatureHandlerHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_get_VerificationResult(TElSAMLSignatureHandlerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_get_ValidateCertificate(TElSAMLSignatureHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_set_ValidateCertificate(TElSAMLSignatureHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_get_ValidateReferences(TElSAMLSignatureHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_set_ValidateReferences(TElSAMLSignatureHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_get_CanonicalizationMethod(TElSAMLSignatureHandlerHandle _Handle, TElXMLCanonicalizationMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_set_CanonicalizationMethod(TElSAMLSignatureHandlerHandle _Handle, TElXMLCanonicalizationMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_get_SignatureAfterIssuer(TElSAMLSignatureHandlerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_set_SignatureAfterIssuer(TElSAMLSignatureHandlerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_get_SignatureMethod(TElSAMLSignatureHandlerHandle _Handle, TElXMLSignatureMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_set_SignatureMethod(TElSAMLSignatureHandlerHandle _Handle, TElXMLSignatureMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_get_DigestMethod(TElSAMLSignatureHandlerHandle _Handle, TElXMLDigestMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_set_DigestMethod(TElSAMLSignatureHandlerHandle _Handle, TElXMLDigestMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_get_OnValidatorPrepared(TElSAMLSignatureHandlerHandle _Handle, TSBSAMLCertValidatorPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_set_OnValidatorPrepared(TElSAMLSignatureHandlerHandle _Handle, TSBSAMLCertValidatorPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_get_OnSignerPrepared(TElSAMLSignatureHandlerHandle _Handle, TSBSAMLXMLSignerPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_set_OnSignerPrepared(TElSAMLSignatureHandlerHandle _Handle, TSBSAMLXMLSignerPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_get_OnVerifierPrepared(TElSAMLSignatureHandlerHandle _Handle, TSBSAMLXMLVerifierPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_set_OnVerifierPrepared(TElSAMLSignatureHandlerHandle _Handle, TSBSAMLXMLVerifierPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSignatureHandler_Create(TElSAMLSignatureHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSIGNATUREHANDLER */

#ifdef SB_USE_CLASS_TELSAMLENCRYPTIONHANDLER
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptionHandler_Protect(TElSAMLEncryptionHandlerHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle Elem, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptionHandler_Unprotect(TElSAMLEncryptionHandlerHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle Input, TElXMLDOMElementHandle * Output, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptionHandler_get_Certificate(TElSAMLEncryptionHandlerHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptionHandler_set_Certificate(TElSAMLEncryptionHandlerHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptionHandler_get_DecryptionResult(TElSAMLEncryptionHandlerHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptionHandler_set_DecryptionResult(TElSAMLEncryptionHandlerHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptionHandler_get_OnXMLEncryptorPrepared(TElSAMLEncryptionHandlerHandle _Handle, TSBSAMLXMLEncryptorPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptionHandler_set_OnXMLEncryptorPrepared(TElSAMLEncryptionHandlerHandle _Handle, TSBSAMLXMLEncryptorPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptionHandler_get_OnXMLDecryptorPrepared(TElSAMLEncryptionHandlerHandle _Handle, TSBSAMLXMLDecryptorPreparedEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptionHandler_set_OnXMLDecryptorPrepared(TElSAMLEncryptionHandlerHandle _Handle, TSBSAMLXMLDecryptorPreparedEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptionHandler_Create(TElSAMLEncryptionHandlerHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLENCRYPTIONHANDLER */

#ifdef SB_USE_CLASS_TELSAMLSUBJECTELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectElement_Clear(TElSAMLSubjectElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectElement_LoadFromXML(TElSAMLSubjectElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectElement_SaveToXML(TElSAMLSubjectElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectElement_AddSubjectConfirmation(TElSAMLSubjectElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectElement_RemoveSubjectConfirmation(TElSAMLSubjectElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectElement_get_Sequence(TElSAMLSubjectElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectElement_get_ID(TElSAMLSubjectElementHandle _Handle, TElSAMLIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectElement_set_ID(TElSAMLSubjectElementHandle _Handle, TElSAMLIDHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectElement_get_SubjectConfirmations(TElSAMLSubjectElementHandle _Handle, int32_t Index, TElSAMLSubjectConfirmationElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectElement_get_SubjectConfirmationCount(TElSAMLSubjectElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectElement_Create(TElSAMLSubjectElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSUBJECTELEMENT */

#ifdef SB_USE_CLASS_TELSAMLID
SB_IMPORT uint32_t SB_APIENTRY TElSAMLID_CompareTo(TElSAMLIDHandle _Handle, TElSAMLIDHandle Other, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLID_CreateByName(const char * pcName, int32_t szName, TElSAMLIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLID_CreateByName_1(TElSAMLIDHandle _Handle, const char * pcName, int32_t szName, TElSAMLIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLID_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLID */

#ifdef SB_USE_CLASS_TELSAMLBASEIDELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLBaseIDElement_Clear(TElSAMLBaseIDElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLBaseIDElement_CompareTo(TElSAMLBaseIDElementHandle _Handle, TElSAMLIDHandle Other, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLBaseIDElement_LoadFromXML(TElSAMLBaseIDElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLBaseIDElement_SaveToXML(TElSAMLBaseIDElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLBaseIDElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLBaseIDElement_get_NameQualifier(TElSAMLBaseIDElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLBaseIDElement_set_NameQualifier(TElSAMLBaseIDElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLBaseIDElement_get_SPNameQualifier(TElSAMLBaseIDElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLBaseIDElement_set_SPNameQualifier(TElSAMLBaseIDElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLBaseIDElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLBASEIDELEMENT */

#ifdef SB_USE_CLASS_TELSAMLNAMEIDELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_Assign(TElSAMLNameIDElementHandle _Handle, TElSAMLElementHandle Other);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_Clear(TElSAMLNameIDElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_CompareTo(TElSAMLNameIDElementHandle _Handle, TElSAMLIDHandle Other, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_LoadFromXML(TElSAMLNameIDElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_SaveToXML(TElSAMLNameIDElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_get_Value(TElSAMLNameIDElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_set_Value(TElSAMLNameIDElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_get_NameQualifier(TElSAMLNameIDElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_set_NameQualifier(TElSAMLNameIDElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_get_SPNameQualifier(TElSAMLNameIDElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_set_SPNameQualifier(TElSAMLNameIDElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_get_Format(TElSAMLNameIDElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_set_Format(TElSAMLNameIDElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_get_SPProvidedID(TElSAMLNameIDElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_set_SPProvidedID(TElSAMLNameIDElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDElement_Create(TElSAMLNameIDElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLNAMEIDELEMENT */

#ifdef SB_USE_CLASS_TELSAMLENCRYPTEDELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedElement_Clear(TElSAMLEncryptedElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedElement_LoadFromXML(TElSAMLEncryptedElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedElement_SaveToXML(TElSAMLEncryptedElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedElement_Encrypt(TElSAMLEncryptedElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedElement_Decrypt(TElSAMLEncryptedElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedElement_get_ElementName(TElSAMLEncryptedElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedElement_set_ElementName(TElSAMLEncryptedElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedElement_get_Decrypted(TElSAMLEncryptedElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedElement_set_Decrypted(TElSAMLEncryptedElementHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedElement_Create(TElSAMLEncryptedElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLENCRYPTEDELEMENT */

#ifdef SB_USE_CLASS_TELSAMLENCRYPTEDIDELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedIDElement_Clear(TElSAMLEncryptedIDElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedIDElement_CompareTo(TElSAMLEncryptedIDElementHandle _Handle, TElSAMLIDHandle Other, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedIDElement_LoadFromXML(TElSAMLEncryptedIDElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedIDElement_SaveToXML(TElSAMLEncryptedIDElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedIDElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedIDElement_Encrypt(TElSAMLEncryptedIDElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedIDElement_Decrypt(TElSAMLEncryptedIDElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedIDElement_get_EncryptedElement(TElSAMLEncryptedIDElementHandle _Handle, TElSAMLEncryptedElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedIDElement_set_EncryptedElement(TElSAMLEncryptedIDElementHandle _Handle, TElSAMLEncryptedElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedIDElement_get_ID(TElSAMLEncryptedIDElementHandle _Handle, TElSAMLIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedIDElement_set_ID(TElSAMLEncryptedIDElementHandle _Handle, TElSAMLIDHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedIDElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLENCRYPTEDIDELEMENT */

#ifdef SB_USE_CLASS_TELSAMLISSUERELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIssuerElement_LoadFromXML(TElSAMLIssuerElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIssuerElement_Create(TElSAMLIssuerElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLISSUERELEMENT */

#ifdef SB_USE_CLASS_TELSAMLASSERTIONTYPE
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionType_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLASSERTIONTYPE */

#ifdef SB_USE_CLASS_TELSAMLASSERTIONIDREFELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRefElement_Clear(TElSAMLAssertionIDRefElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRefElement_LoadFromXML(TElSAMLAssertionIDRefElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRefElement_SaveToXML(TElSAMLAssertionIDRefElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRefElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRefElement_get_Value(TElSAMLAssertionIDRefElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRefElement_set_Value(TElSAMLAssertionIDRefElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRefElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLASSERTIONIDREFELEMENT */

#ifdef SB_USE_CLASS_TELSAMLASSERTIONURIREFELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionURIRefElement_Clear(TElSAMLAssertionURIRefElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionURIRefElement_LoadFromXML(TElSAMLAssertionURIRefElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionURIRefElement_SaveToXML(TElSAMLAssertionURIRefElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionURIRefElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionURIRefElement_get_Value(TElSAMLAssertionURIRefElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionURIRefElement_set_Value(TElSAMLAssertionURIRefElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionURIRefElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLASSERTIONURIREFELEMENT */

#ifdef SB_USE_CLASS_TELSAMLASSERTIONELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_Clear(TElSAMLAssertionElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_LoadFromXML(TElSAMLAssertionElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_LoadFromXML_1(TElSAMLAssertionElementHandle _Handle, TElXMLDOMElementHandle Element, int8_t ClearBefore);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_SaveToXML(TElSAMLAssertionElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_AddStatement(TElSAMLAssertionElementHandle _Handle, TElSAMLStatementAbstractTypeHandle St, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_RemoveStatement(TElSAMLAssertionElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_get_Signed(TElSAMLAssertionElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_set_Signed(TElSAMLAssertionElementHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_get_Version(TElSAMLAssertionElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_set_Version(TElSAMLAssertionElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_get_ID(TElSAMLAssertionElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_set_ID(TElSAMLAssertionElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_get_IssueInstant(TElSAMLAssertionElementHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_set_IssueInstant(TElSAMLAssertionElementHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_get_Issuer(TElSAMLAssertionElementHandle _Handle, TElSAMLIssuerElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_set_Issuer(TElSAMLAssertionElementHandle _Handle, TElSAMLIssuerElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_get_Signature(TElSAMLAssertionElementHandle _Handle, TElXMLSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_get_Subject(TElSAMLAssertionElementHandle _Handle, TElSAMLSubjectElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_set_Subject(TElSAMLAssertionElementHandle _Handle, TElSAMLSubjectElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_get_Conditions(TElSAMLAssertionElementHandle _Handle, TElSAMLConditionsElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_set_Conditions(TElSAMLAssertionElementHandle _Handle, TElSAMLConditionsElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_get_Advice(TElSAMLAssertionElementHandle _Handle, TElSAMLAdviceElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_set_Advice(TElSAMLAssertionElementHandle _Handle, TElSAMLAdviceElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_get_Statements(TElSAMLAssertionElementHandle _Handle, int32_t Index, TElSAMLStatementAbstractTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_get_StatementCount(TElSAMLAssertionElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionElement_Create(TElSAMLAssertionElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLASSERTIONELEMENT */

#ifdef SB_USE_CLASS_TELSAMLENCRYPTEDASSERTIONELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAssertionElement_Clear(TElSAMLEncryptedAssertionElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAssertionElement_LoadFromXML(TElSAMLEncryptedAssertionElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAssertionElement_LoadFromXML_1(TElSAMLAssertionElementHandle _Handle, TElXMLDOMElementHandle Element, int8_t ClearBefore);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAssertionElement_SaveToXML(TElSAMLEncryptedAssertionElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAssertionElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAssertionElement_Decrypt(TElSAMLEncryptedAssertionElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAssertionElement_get_Decrypted(TElSAMLEncryptedAssertionElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAssertionElement_get_EncryptedElement(TElSAMLEncryptedAssertionElementHandle _Handle, TElSAMLEncryptedElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAssertionElement_Create(TElSAMLEncryptedAssertionElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLENCRYPTEDASSERTIONELEMENT */

#ifdef SB_USE_CLASS_TELSAMLCONDITIONABSTRACTTYPE
SB_IMPORT uint32_t SB_APIENTRY TElSAMLConditionAbstractType_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLCONDITIONABSTRACTTYPE */

#ifdef SB_USE_CLASS_TELSAMLAUDIENCEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceElement_Clear(TElSAMLAudienceElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceElement_LoadFromXML(TElSAMLAudienceElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceElement_SaveToXML(TElSAMLAudienceElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceElement_get_Value(TElSAMLAudienceElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceElement_set_Value(TElSAMLAudienceElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLAUDIENCEELEMENT */

#ifdef SB_USE_CLASS_TELSAMLAUDIENCERESTRICTIONELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceRestrictionElement_Clear(TElSAMLAudienceRestrictionElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceRestrictionElement_LoadFromXML(TElSAMLAudienceRestrictionElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceRestrictionElement_SaveToXML(TElSAMLAudienceRestrictionElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceRestrictionElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceRestrictionElement_AddAudience(TElSAMLAudienceRestrictionElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceRestrictionElement_RemoveAudience(TElSAMLAudienceRestrictionElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceRestrictionElement_get_AudienceList(TElSAMLAudienceRestrictionElementHandle _Handle, int32_t Index, TElSAMLAudienceElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceRestrictionElement_get_AudienceCount(TElSAMLAudienceRestrictionElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAudienceRestrictionElement_Create(TElSAMLAudienceRestrictionElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLAUDIENCERESTRICTIONELEMENT */

#ifdef SB_USE_CLASS_TELSAMLONETIMEUSEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLOneTimeUseElement_LoadFromXML(TElSAMLOneTimeUseElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLOneTimeUseElement_SaveToXML(TElSAMLOneTimeUseElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLOneTimeUseElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLOneTimeUseElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLONETIMEUSEELEMENT */

#ifdef SB_USE_CLASS_TELSAMLPROXYRESTRICTIONELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLProxyRestrictionElement_Clear(TElSAMLProxyRestrictionElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLProxyRestrictionElement_LoadFromXML(TElSAMLProxyRestrictionElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLProxyRestrictionElement_SaveToXML(TElSAMLProxyRestrictionElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLProxyRestrictionElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLProxyRestrictionElement_AddAudience(TElSAMLProxyRestrictionElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLProxyRestrictionElement_RemoveAudience(TElSAMLProxyRestrictionElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLProxyRestrictionElement_get_Count(TElSAMLProxyRestrictionElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLProxyRestrictionElement_get_AudienceList(TElSAMLProxyRestrictionElementHandle _Handle, int32_t Index, TElSAMLAudienceElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLProxyRestrictionElement_get_AudienceCount(TElSAMLProxyRestrictionElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLProxyRestrictionElement_Create(TElSAMLProxyRestrictionElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLPROXYRESTRICTIONELEMENT */

#ifdef SB_USE_CLASS_TELSAMLSUBJECTLOCALITYELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectLocalityElement_Clear(TElSAMLSubjectLocalityElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectLocalityElement_LoadFromXML(TElSAMLSubjectLocalityElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectLocalityElement_SaveToXML(TElSAMLSubjectLocalityElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectLocalityElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectLocalityElement_get_Address(TElSAMLSubjectLocalityElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectLocalityElement_set_Address(TElSAMLSubjectLocalityElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectLocalityElement_get_DNSName(TElSAMLSubjectLocalityElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectLocalityElement_set_DNSName(TElSAMLSubjectLocalityElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectLocalityElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSUBJECTLOCALITYELEMENT */

#ifdef SB_USE_CLASS_TELSAMLAUTHNCONTEXTELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnContextElement_Clear(TElSAMLAuthnContextElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnContextElement_LoadFromXML(TElSAMLAuthnContextElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnContextElement_SaveToXML(TElSAMLAuthnContextElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnContextElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnContextElement_get_Choice(TElSAMLAuthnContextElementHandle _Handle, TSBSAMLAuthnContextChoiceRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnContextElement_set_Choice(TElSAMLAuthnContextElementHandle _Handle, TSBSAMLAuthnContextChoiceRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnContextElement_get_AuthnContextClassRef(TElSAMLAuthnContextElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnContextElement_set_AuthnContextClassRef(TElSAMLAuthnContextElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnContextElement_get_AuthnContextDecl(TElSAMLAuthnContextElementHandle _Handle, TElSAMLElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnContextElement_set_AuthnContextDecl(TElSAMLAuthnContextElementHandle _Handle, TElSAMLElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnContextElement_get_AuthnContextDeclRef(TElSAMLAuthnContextElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnContextElement_set_AuthnContextDeclRef(TElSAMLAuthnContextElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnContextElement_get_AuthenticatingAuthorities(TElSAMLAuthnContextElementHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnContextElement_Create(TElSAMLAuthnContextElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLAUTHNCONTEXTELEMENT */

#ifdef SB_USE_CLASS_TELSAMLAUTHNSTATEMENTELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_Clear(TElSAMLAuthnStatementElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_LoadFromXML(TElSAMLAuthnStatementElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_SaveToXML(TElSAMLAuthnStatementElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_get_AuthnInstant(TElSAMLAuthnStatementElementHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_set_AuthnInstant(TElSAMLAuthnStatementElementHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_get_SessionIndex(TElSAMLAuthnStatementElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_set_SessionIndex(TElSAMLAuthnStatementElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_get_SessionNotOnOrAfter(TElSAMLAuthnStatementElementHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_set_SessionNotOnOrAfter(TElSAMLAuthnStatementElementHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_get_SubjectLocality(TElSAMLAuthnStatementElementHandle _Handle, TElSAMLSubjectLocalityElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_set_SubjectLocality(TElSAMLAuthnStatementElementHandle _Handle, TElSAMLSubjectLocalityElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_get_AuthnContext(TElSAMLAuthnStatementElementHandle _Handle, TElSAMLAuthnContextElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_set_AuthnContext(TElSAMLAuthnStatementElementHandle _Handle, TElSAMLAuthnContextElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnStatementElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLAUTHNSTATEMENTELEMENT */

#ifdef SB_USE_CLASS_TELSAMLATTRIBUTETYPE
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeType_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLATTRIBUTETYPE */

#ifdef SB_USE_CLASS_TELSAMLATTRIBUTEVALUE
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeValue_Clear(TElSAMLAttributeValueHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeValue_LoadFromXML(TElSAMLAttributeValueHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeValue_SaveToXML(TElSAMLAttributeValueHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeValue_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeValue_get_Value(TElSAMLAttributeValueHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeValue_set_Value(TElSAMLAttributeValueHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeValue_get_ContentType(TElSAMLAttributeValueHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeValue_set_ContentType(TElSAMLAttributeValueHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeValue_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLATTRIBUTEVALUE */

#ifdef SB_USE_CLASS_TELSAMLATTRIBUTEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_Clear(TElSAMLAttributeElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_LoadFromXML(TElSAMLAttributeElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_SaveToXML(TElSAMLAttributeElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_AddArbitraryAttribute(TElSAMLAttributeElementHandle _Handle, TElXMLDOMAttrHandle Attr, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_RemoveArbitraryAttribute(TElSAMLAttributeElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_AddValue(TElSAMLAttributeElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_RemoveValue(TElSAMLAttributeElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_get_Name(TElSAMLAttributeElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_set_Name(TElSAMLAttributeElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_get_NameFormat(TElSAMLAttributeElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_set_NameFormat(TElSAMLAttributeElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_get_FriendlyName(TElSAMLAttributeElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_set_FriendlyName(TElSAMLAttributeElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_get_Values(TElSAMLAttributeElementHandle _Handle, int32_t Index, TElSAMLAttributeValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_get_ValueCount(TElSAMLAttributeElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_get_ArbitraryAttributes(TElSAMLAttributeElementHandle _Handle, int32_t Index, TElXMLDOMAttrHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_get_ArbitraryAttributeCount(TElSAMLAttributeElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeElement_Create(TElSAMLAttributeElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLATTRIBUTEELEMENT */

#ifdef SB_USE_CLASS_TELSAMLENCRYPTEDATTRIBUTEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAttributeElement_Clear(TElSAMLEncryptedAttributeElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAttributeElement_LoadFromXML(TElSAMLEncryptedAttributeElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAttributeElement_SaveToXML(TElSAMLEncryptedAttributeElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAttributeElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAttributeElement_get_EncryptedElement(TElSAMLEncryptedAttributeElementHandle _Handle, TElSAMLEncryptedElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAttributeElement_set_EncryptedElement(TElSAMLEncryptedAttributeElementHandle _Handle, TElSAMLEncryptedElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEncryptedAttributeElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLENCRYPTEDATTRIBUTEELEMENT */

#ifdef SB_USE_CLASS_TELSAMLATTRIBUTESTATEMENTELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeStatementElement_Clear(TElSAMLAttributeStatementElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeStatementElement_LoadFromXML(TElSAMLAttributeStatementElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeStatementElement_SaveToXML(TElSAMLAttributeStatementElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeStatementElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeStatementElement_AddAttribute(TElSAMLAttributeStatementElementHandle _Handle, TElSAMLAttributeTypeHandle Attr, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeStatementElement_RemoveAttribute(TElSAMLAttributeStatementElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeStatementElement_get_Attributes(TElSAMLAttributeStatementElementHandle _Handle, int32_t Index, TElSAMLAttributeTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeStatementElement_get_AttributeCount(TElSAMLAttributeStatementElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeStatementElement_Create(TElSAMLAttributeStatementElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLATTRIBUTESTATEMENTELEMENT */

#ifdef SB_USE_CLASS_TELSAMLACTIONELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLActionElement_Clear(TElSAMLActionElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLActionElement_LoadFromXML(TElSAMLActionElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLActionElement_SaveToXML(TElSAMLActionElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLActionElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLActionElement_get__Namespace(TElSAMLActionElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLActionElement_set__Namespace(TElSAMLActionElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLActionElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLACTIONELEMENT */

#ifdef SB_USE_CLASS_TELSAMLEVIDENCEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEvidenceElement_Clear(TElSAMLEvidenceElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEvidenceElement_LoadFromXML(TElSAMLEvidenceElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEvidenceElement_SaveToXML(TElSAMLEvidenceElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEvidenceElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEvidenceElement_AddAssertion(TElSAMLEvidenceElementHandle _Handle, TElSAMLAssertionTypeHandle Assertion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEvidenceElement_RemoveAssertion(TElSAMLEvidenceElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEvidenceElement_get_Assertions(TElSAMLEvidenceElementHandle _Handle, int32_t Index, TElSAMLAssertionTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEvidenceElement_get_AssertionCount(TElSAMLEvidenceElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLEvidenceElement_Create(TElSAMLEvidenceElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLEVIDENCEELEMENT */

#ifdef SB_USE_CLASS_TELSAMLAUTHZDECISIONSTATEMENTELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_Clear(TElSAMLAuthzDecisionStatementElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_LoadFromXML(TElSAMLAuthzDecisionStatementElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_SaveToXML(TElSAMLAuthzDecisionStatementElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_AddAction(TElSAMLAuthzDecisionStatementElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_RemoveAction(TElSAMLAuthzDecisionStatementElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_get_Resource(TElSAMLAuthzDecisionStatementElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_set_Resource(TElSAMLAuthzDecisionStatementElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_get_Decision(TElSAMLAuthzDecisionStatementElementHandle _Handle, TSBSAMLDecisionRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_set_Decision(TElSAMLAuthzDecisionStatementElementHandle _Handle, TSBSAMLDecisionRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_get_Evidence(TElSAMLAuthzDecisionStatementElementHandle _Handle, TElSAMLEvidenceElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_set_Evidence(TElSAMLAuthzDecisionStatementElementHandle _Handle, TElSAMLEvidenceElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_get_Actions(TElSAMLAuthzDecisionStatementElementHandle _Handle, int32_t Index, TElSAMLActionElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_get_ActionCount(TElSAMLAuthzDecisionStatementElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionStatementElement_Create(TElSAMLAuthzDecisionStatementElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLAUTHZDECISIONSTATEMENTELEMENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSAMLElement_ce_ptr;
extern zend_class_entry *TElSAMLConditionsElement_ce_ptr;
extern zend_class_entry *TElSAMLAdviceElement_ce_ptr;
extern zend_class_entry *TElSAMLSubjectConfirmationDataElement_ce_ptr;
extern zend_class_entry *TElSAMLStatementAbstractType_ce_ptr;
extern zend_class_entry *TElSAMLSubjectConfirmationElement_ce_ptr;
extern zend_class_entry *TElSAMLSecurityHandler_ce_ptr;
extern zend_class_entry *TElSAMLSignatureHandler_ce_ptr;
extern zend_class_entry *TElSAMLEncryptionHandler_ce_ptr;
extern zend_class_entry *TElSAMLSubjectElement_ce_ptr;
extern zend_class_entry *TElSAMLID_ce_ptr;
extern zend_class_entry *TElSAMLBaseIDElement_ce_ptr;
extern zend_class_entry *TElSAMLNameIDElement_ce_ptr;
extern zend_class_entry *TElSAMLEncryptedElement_ce_ptr;
extern zend_class_entry *TElSAMLEncryptedIDElement_ce_ptr;
extern zend_class_entry *TElSAMLIssuerElement_ce_ptr;
extern zend_class_entry *TElSAMLAssertionType_ce_ptr;
extern zend_class_entry *TElSAMLAssertionIDRefElement_ce_ptr;
extern zend_class_entry *TElSAMLAssertionURIRefElement_ce_ptr;
extern zend_class_entry *TElSAMLAssertionElement_ce_ptr;
extern zend_class_entry *TElSAMLEncryptedAssertionElement_ce_ptr;
extern zend_class_entry *TElSAMLConditionAbstractType_ce_ptr;
extern zend_class_entry *TElSAMLAudienceElement_ce_ptr;
extern zend_class_entry *TElSAMLAudienceRestrictionElement_ce_ptr;
extern zend_class_entry *TElSAMLOneTimeUseElement_ce_ptr;
extern zend_class_entry *TElSAMLProxyRestrictionElement_ce_ptr;
extern zend_class_entry *TElSAMLSubjectLocalityElement_ce_ptr;
extern zend_class_entry *TElSAMLAuthnContextElement_ce_ptr;
extern zend_class_entry *TElSAMLAuthnStatementElement_ce_ptr;
extern zend_class_entry *TElSAMLAttributeType_ce_ptr;
extern zend_class_entry *TElSAMLAttributeValue_ce_ptr;
extern zend_class_entry *TElSAMLAttributeElement_ce_ptr;
extern zend_class_entry *TElSAMLEncryptedAttributeElement_ce_ptr;
extern zend_class_entry *TElSAMLAttributeStatementElement_ce_ptr;
extern zend_class_entry *TElSAMLActionElement_ce_ptr;
extern zend_class_entry *TElSAMLEvidenceElement_ce_ptr;
extern zend_class_entry *TElSAMLAuthzDecisionStatementElement_ce_ptr;

void SB_CALLBACK TSBSAMLCertValidatorPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElX509CertificateValidatorHandle * CertValidator, TElX509CertificateHandle Cert);
void SB_CALLBACK TSBSAMLXMLSignerPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElXMLSignerHandle * Signer);
void SB_CALLBACK TSBSAMLXMLVerifierPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElXMLVerifierHandle * Verifier);
void SB_CALLBACK TSBSAMLXMLEncryptorPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElXMLEncryptorHandle * Encryptor);
void SB_CALLBACK TSBSAMLXMLDecryptorPreparedEventRaw(void * _ObjectData, TObjectHandle Sender, TElXMLDecryptorHandle * Decryptor);
void Register_TElSAMLElement(TSRMLS_D);
void Register_TElSAMLConditionsElement(TSRMLS_D);
void Register_TElSAMLAdviceElement(TSRMLS_D);
void Register_TElSAMLSubjectConfirmationDataElement(TSRMLS_D);
void Register_TElSAMLStatementAbstractType(TSRMLS_D);
void Register_TElSAMLSubjectConfirmationElement(TSRMLS_D);
void Register_TElSAMLSecurityHandler(TSRMLS_D);
void Register_TElSAMLSignatureHandler(TSRMLS_D);
void Register_TElSAMLEncryptionHandler(TSRMLS_D);
void Register_TElSAMLSubjectElement(TSRMLS_D);
void Register_TElSAMLID(TSRMLS_D);
void Register_TElSAMLBaseIDElement(TSRMLS_D);
void Register_TElSAMLNameIDElement(TSRMLS_D);
void Register_TElSAMLEncryptedElement(TSRMLS_D);
void Register_TElSAMLEncryptedIDElement(TSRMLS_D);
void Register_TElSAMLIssuerElement(TSRMLS_D);
void Register_TElSAMLAssertionType(TSRMLS_D);
void Register_TElSAMLAssertionIDRefElement(TSRMLS_D);
void Register_TElSAMLAssertionURIRefElement(TSRMLS_D);
void Register_TElSAMLAssertionElement(TSRMLS_D);
void Register_TElSAMLEncryptedAssertionElement(TSRMLS_D);
void Register_TElSAMLConditionAbstractType(TSRMLS_D);
void Register_TElSAMLAudienceElement(TSRMLS_D);
void Register_TElSAMLAudienceRestrictionElement(TSRMLS_D);
void Register_TElSAMLOneTimeUseElement(TSRMLS_D);
void Register_TElSAMLProxyRestrictionElement(TSRMLS_D);
void Register_TElSAMLSubjectLocalityElement(TSRMLS_D);
void Register_TElSAMLAuthnContextElement(TSRMLS_D);
void Register_TElSAMLAuthnStatementElement(TSRMLS_D);
void Register_TElSAMLAttributeType(TSRMLS_D);
void Register_TElSAMLAttributeValue(TSRMLS_D);
void Register_TElSAMLAttributeElement(TSRMLS_D);
void Register_TElSAMLEncryptedAttributeElement(TSRMLS_D);
void Register_TElSAMLAttributeStatementElement(TSRMLS_D);
void Register_TElSAMLActionElement(TSRMLS_D);
void Register_TElSAMLEvidenceElement(TSRMLS_D);
void Register_TElSAMLAuthzDecisionStatementElement(TSRMLS_D);
SB_PHP_FUNCTION(SBXMLSAMLCore, GetSAMLNSMap);
SB_PHP_FUNCTION(SBXMLSAMLCore, SetSAMLNSMap);
SB_PHP_FUNCTION(SBXMLSAMLCore, CreateElementNS);
SB_PHP_FUNCTION(SBXMLSAMLCore, StreamToStr);
SB_PHP_FUNCTION(SBXMLSAMLCore, StreamToStrUTF8);
SB_PHP_FUNCTION(SBXMLSAMLCore, StreamToArray);
SB_PHP_FUNCTION(SBXMLSAMLCore, FindChildElement);
SB_PHP_FUNCTION(SBXMLSAMLCore, FreeList);
SB_PHP_FUNCTION(SBXMLSAMLCore, XMLStrToBool);
SB_PHP_FUNCTION(SBXMLSAMLCore, BoolToXMLStr);
SB_PHP_FUNCTION(SBXMLSAMLCore, GenerateID);
SB_PHP_FUNCTION(SBXMLSAMLCore, RandomString);
SB_PHP_FUNCTION(SBXMLSAMLCore, DateTimeToString);
SB_PHP_FUNCTION(SBXMLSAMLCore, CurrentDateTime);
void Register_SBXMLSAMLCore_Constants(int module_number TSRMLS_DC);
void Register_SBXMLSAMLCore_Enum_Flags(TSRMLS_D);
void Register_SBXMLSAMLCore_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_XMLSAMLCORE
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_GetSAMLNSMap(TElXMLNamespaceMapHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_SetSAMLNSMap(TElXMLNamespaceMapHandle Value);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_CreateElementNS(TElXMLDOMDocumentHandle Document, const char * pcURI, int32_t szURI, const char * pcName, int32_t szName, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_StreamToStr(TStreamHandle Input, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_StreamToStrUTF8(TStreamHandle Input, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_StreamToArray(TStreamHandle Input, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_FindChildElement(const TElXMLDOMElementHandle Element, const char * pcName, int32_t szName, const char * pcNamespaceURI, int32_t szNamespaceURI, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_FreeList(TListHandle List);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_XMLStrToBool(const char * pcS, int32_t szS, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_BoolToXMLStr(int8_t B, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_GenerateID(int32_t Len, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_GenerateID_1(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_RandomString(int32_t Len, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_RandomString_1(char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_DateTimeToString(int64_t DT, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSAMLCore_CurrentDateTime(int64_t * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_XMLSAMLCORE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLSAMLCORE */

