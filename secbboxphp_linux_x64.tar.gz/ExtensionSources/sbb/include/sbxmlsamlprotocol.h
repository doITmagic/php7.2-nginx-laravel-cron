#ifndef __INC_SBXMLSAMLPROTOCOL
#define __INC_SBXMLSAMLPROTOCOL

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbxmlcore.h"
#include "sbxmlsig.h"
#include "sbxmlenc.h"
#include "sbxmlsec.h"
#include "sbxmlutils.h"
#include "sbxmldefs.h"
#include "sbxmlcharsets.h"
#include "sbxmlsamlcore.h"
#include "sbstreams.h"
#include "sbconstants.h"
#include "sbstrutils.h"
#include "sbutils.h"
#include "sbtypes.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_xmlSAMLStatusSuccess 	"urn:oasis:names:tc:SAML:2.0:status:Success"
#define SB_xmlSAMLStatusRequester 	"urn:oasis:names:tc:SAML:2.0:status:Requester"
#define SB_xmlSAMLStatusResponder 	"urn:oasis:names:tc:SAML:2.0:status:Responder"
#define SB_xmlSAMLStatusVersionMismatch 	"urn:oasis:names:tc:SAML:2.0:status:VersionMismatch"
#define SB_xmlSAMLConsentUnspecified 	"urn:oasis:names:tc:SAML:2.0:consent:unspecified"
#define SB_xmlSAMLConsentObtained 	"urn:oasis:names:tc:SAML:2.0:consent:obtained"
#define SB_xmlSAMLConsentPrior 	"urn:oasis:names:tc:SAML:2.0:consent:prior"
#define SB_xmlSAMLConsentImplicit 	"urn:oasis:names:tc:SAML:2.0:consent:current-implicit"
#define SB_xmlSAMLConsentExplicit 	"urn:oasis:names:tc:SAML:2.0:consent:current-explicit"
#define SB_xmlSAMLConsentUnavailable 	"urn:oasis:names:tc:SAML:2.0:consent:unavailable"
#define SB_xmlSAMLConsentInapplicable 	"urn:oasis:names:tc:SAML:2.0:consent:inapplicable"
#define SB_xmlSAMLStatusAuthnFailed 	"urn:oasis:names:tc:SAML:2.0:status:AuthnFailed"
#define SB_xmlSAMLStatusInvalidAttrNameOrValue 	"urn:oasis:names:tc:SAML:2.0:status:InvalidAttrNameOrValue"
#define SB_xmlSAMLStatusInvalidNameIDPolicy 	"urn:oasis:names:tc:SAML:2.0:status:InvalidNameIDPolicy"
#define SB_xmlSAMLStatusNoAuthnContext 	"urn:oasis:names:tc:SAML:2.0:status:NoAuthnContext"
#define SB_xmlSAMLStatusNoAvailableIDP 	"urn:oasis:names:tc:SAML:2.0:status:NoAvailableIDP"
#define SB_xmlSAMLStatusNoPassive 	"urn:oasis:names:tc:SAML:2.0:status:NoPassive"
#define SB_xmlSAMLStatusNoSupportedIDP 	"urn:oasis:names:tc:SAML:2.0:status:NoSupportedIDP"
#define SB_xmlSAMLStatusPartialLogout 	"urn:oasis:names:tc:SAML:2.0:status:PartialLogout"
#define SB_xmlSAMLStatusProxyCountExceeded 	"urn:oasis:names:tc:SAML:2.0:status:ProxyCountExceeded"
#define SB_xmlSAMLStatusRequestDenied 	"urn:oasis:names:tc:SAML:2.0:status:RequestDenied"
#define SB_xmlSAMLStatusRequestUnsupported 	"urn:oasis:names:tc:SAML:2.0:status:RequestUnsupported"
#define SB_xmlSAMLStatusRequestVersionDeprecated 	"urn:oasis:names:tc:SAML:2.0:status:RequestVersionDeprecated"
#define SB_xmlSAMLStatusRequestVersionTooHigh 	"urn:oasis:names:tc:SAML:2.0:status:RequestVersionTooHigh"
#define SB_xmlSAMLStatusRequestVersionTooLow 	"urn:oasis:names:tc:SAML:2.0:status:RequestVersionTooLow"
#define SB_xmlSAMLStatusResourceNotRecognized 	"urn:oasis:names:tc:SAML:2.0:status:ResourceNotRecognized"
#define SB_xmlSAMLStatusTooManyResponses 	"urn:oasis:names:tc:SAML:2.0:status:TooManyResponses"
#define SB_xmlSAMLStatusUnknownAttrProfile 	"urn:oasis:names:tc:SAML:2.0:status:UnknownAttrProfile"
#define SB_xmlSAMLStatusUnknownPrincipal 	"urn:oasis:names:tc:SAML:2.0:status:UnknownPrincipal"
#define SB_xmlSAMLStatusUnsupportedBinding 	"urn:oasis:names:tc:SAML:2.0:status:UnsupportedBinding"
#define SB_xmlSAMLNameIDPolicyFormatUnspecified 	"urn:oasis:names:tc:SAML:2.0:nameidformat:unspecified"
#define SB_xmlSAMLNameIDPolicyFormatEncrypted 	"urn:oasis:names:tc:SAML:2.0:nameid-format:encrypted"
#define SB_xmlSAMLConfirmationHolderOfKey 	"urn:oasis:names:tc:SAML:2.0:cm:holder-of-key"
#define SB_xmlSAMLConfirmationMethodSenderVouches 	"urn:oasis:names:tc:SAML:2.0:cm:sender-vouches"
#define SB_xmlSAMLConfirmationMethodBearer 	"urn:oasis:names:tc:SAML:2.0:cm:bearer"
#define SB_xmlSAMLLogoutReasonUser 	"urn:oasis:names:tc:SAML:2.0:logout:user"
#define SB_xmlSAMLLogoutReasonAdmin 	"urn:oasis:names:tc:SAML:2.0:logout:admin"
#define SB_xmlSAMLAuthnContextClassInternetProtocol 	"urn:oasis:names:tc:SAML:2.0:ac:classes:InternetProtocol"
#define SB_xmlSAMLAuthnContextClassInternetProtocolPassword 	"urn:oasis:names:tc:SAML:2.0:ac:classes:InternetProtocolPassword"
#define SB_xmlSAMLAuthnContextClassPassword 	"urn:oasis:names:tc:SAML:2.0:ac:classes:Password"
#define SB_xmlSAMLAuthnContextClassPasswordProtectedTransport 	"urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport"
#define SB_xmlSAMLAuthnContextClassTLSClient 	"urn:oasis:names:tc:SAML:2.0:ac:classes:TLSClient"
#define SB_xmlSAMLAuthnContextClassUnspecified 	"urn:oasis:names:tc:SAML:2.0:ac:classes:unspecified"
#define SB_SExact 	"exact"
#define SB_SMinimum 	"minimum"
#define SB_SMaximum 	"maximum"
#define SB_SBetter 	"better"
#define SB_SUnknownRequestType 	"Unknown request type"
#define SB_SUnknownResponseType 	"Unknown response type"
#define SB_SWrongResponseName 	"Wrong response name"
#define SB_SWrongRequestType 	"Wrong request type"

typedef TElClassHandle TElSAMLExtensionsElementHandle;

typedef TElClassHandle TElSAMLRequestAbstractTypeHandle;

typedef TElClassHandle TElSAMLStatusCodeElementHandle;

typedef TElClassHandle TElSAMLStatusMessageElementHandle;

typedef TElClassHandle TElSAMLStatusDetailElementHandle;

typedef TElClassHandle TElSAMLStatusElementHandle;

typedef TElClassHandle TElSAMLStatusResponseTypeHandle;

typedef TElClassHandle TElSAMLAssertionIDRequestElementHandle;

typedef TElClassHandle TElSAMLSubjectQueryAbstractTypeHandle;

typedef TElClassHandle TElSAMLSubjectQueryElementHandle;

typedef TElClassHandle TElSAMLRequestedAuthnContextElementHandle;

typedef TElClassHandle TElSAMLAuthnQueryElementHandle;

typedef TElClassHandle TElSAMLAttributeQueryElementHandle;

typedef TElClassHandle TElSAMLAuthzDecisionQueryElementHandle;

typedef TElClassHandle TElSAMLResponseElementHandle;

typedef TElClassHandle TElSAMLNameIDPolicyElementHandle;

typedef TElClassHandle TElSAMLIDPEntryElementHandle;

typedef TElClassHandle TElSAMLIDPListElementHandle;

typedef TElClassHandle TElSAMLScopingElementHandle;

typedef TElClassHandle TElSAMLAuthnRequestElementHandle;

typedef TElClassHandle TElSAMLArtifactResolveElementHandle;

typedef TElClassHandle TElSAMLArtifactResponseElementHandle;

typedef TElClassHandle TElSAMLManageNameIDRequestElementHandle;

typedef TElClassHandle TElSAMLManageNameIDResponseElementHandle;

typedef TElClassHandle TElSAMLLogoutRequestElementHandle;

typedef TElClassHandle TElSAMLLogoutResponseElementHandle;

typedef TElClassHandle TElSAMLNameIDMappingRequestElementHandle;

typedef TElClassHandle TElSAMLNameIDMappingResponseElementHandle;

typedef uint8_t TSBSAMLAuthnContextComparisonTypeRaw;

typedef enum
{
	acctNone = 0,
	acctExact = 1,
	acctMinimum = 2,
	acctMaximum = 3,
	acctBetter = 4
} TSBSAMLAuthnContextComparisonType;

typedef uint8_t TSBSAMLAuthnContextRefTypeRaw;

typedef enum
{
	acrtUnknown = 0,
	acrtClass = 1,
	acrtDecl = 2
} TSBSAMLAuthnContextRefType;

typedef uint8_t TSBSAMLConsentRaw;

typedef enum
{
	sctUnspecified = 0,
	sctObtained = 1,
	sctPrior = 2,
	sctImplicit = 3,
	sctExplicit = 4,
	sctUnavailable = 5,
	sctInapplicable = 6
} TSBSAMLConsent;

#ifdef SB_USE_CLASS_TELSAMLEXTENSIONSELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLExtensionsElement_LoadFromXML(TElSAMLExtensionsElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLExtensionsElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLEXTENSIONSELEMENT */

#ifdef SB_USE_CLASS_TELSAMLREQUESTABSTRACTTYPE
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_GetInstance(TElXMLDOMDocumentHandle Doc, TElSAMLRequestAbstractTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_GetInstance_1(TElSAMLRequestAbstractTypeHandle _Handle, TElXMLDOMDocumentHandle Doc, TElSAMLRequestAbstractTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_Clear(TElSAMLRequestAbstractTypeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_LoadFromXML(TElSAMLRequestAbstractTypeHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_SaveToXML(TElSAMLRequestAbstractTypeHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_get_ElementName(TElSAMLRequestAbstractTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_set_ElementName(TElSAMLRequestAbstractTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_get_Signed(TElSAMLRequestAbstractTypeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_set_Signed(TElSAMLRequestAbstractTypeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_get_ID(TElSAMLRequestAbstractTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_set_ID(TElSAMLRequestAbstractTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_get_Version(TElSAMLRequestAbstractTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_set_Version(TElSAMLRequestAbstractTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_get_IssueInstant(TElSAMLRequestAbstractTypeHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_set_IssueInstant(TElSAMLRequestAbstractTypeHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_get_Destination(TElSAMLRequestAbstractTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_set_Destination(TElSAMLRequestAbstractTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_get_Consent(TElSAMLRequestAbstractTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_set_Consent(TElSAMLRequestAbstractTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_get_Issuer(TElSAMLRequestAbstractTypeHandle _Handle, TElSAMLIssuerElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_set_Issuer(TElSAMLRequestAbstractTypeHandle _Handle, TElSAMLIssuerElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_get_Signature(TElSAMLRequestAbstractTypeHandle _Handle, TElXMLSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_get_Extensions(TElSAMLRequestAbstractTypeHandle _Handle, TElSAMLExtensionsElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_set_Extensions(TElSAMLRequestAbstractTypeHandle _Handle, TElSAMLExtensionsElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestAbstractType_Create(TElSAMLRequestAbstractTypeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLREQUESTABSTRACTTYPE */

#ifdef SB_USE_CLASS_TELSAMLSTATUSCODEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusCodeElement_Assign(TElSAMLStatusCodeElementHandle _Handle, TElSAMLElementHandle Other);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusCodeElement_Clear(TElSAMLStatusCodeElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusCodeElement_LoadFromXML(TElSAMLStatusCodeElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusCodeElement_SaveToXML(TElSAMLStatusCodeElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusCodeElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusCodeElement_get_Value(TElSAMLStatusCodeElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusCodeElement_set_Value(TElSAMLStatusCodeElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusCodeElement_get_SubValue(TElSAMLStatusCodeElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusCodeElement_set_SubValue(TElSAMLStatusCodeElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusCodeElement_Create(TElSAMLStatusCodeElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSTATUSCODEELEMENT */

#ifdef SB_USE_CLASS_TELSAMLSTATUSMESSAGEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusMessageElement_Assign(TElSAMLStatusMessageElementHandle _Handle, TElSAMLElementHandle Other);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusMessageElement_Clear(TElSAMLStatusMessageElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusMessageElement_LoadFromXML(TElSAMLStatusMessageElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusMessageElement_SaveToXML(TElSAMLStatusMessageElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusMessageElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusMessageElement_get_StatusMessage(TElSAMLStatusMessageElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusMessageElement_set_StatusMessage(TElSAMLStatusMessageElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusMessageElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSTATUSMESSAGEELEMENT */

#ifdef SB_USE_CLASS_TELSAMLSTATUSDETAILELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusDetailElement_Assign(TElSAMLStatusDetailElementHandle _Handle, TElSAMLElementHandle Other);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusDetailElement_Clear(TElSAMLStatusDetailElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusDetailElement_LoadFromXML(TElSAMLStatusDetailElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusDetailElement_SaveToXML(TElSAMLStatusDetailElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusDetailElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusDetailElement_AddElement(TElSAMLStatusDetailElementHandle _Handle, TElSAMLElementHandle Elem, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusDetailElement_RemoveElement(TElSAMLStatusDetailElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusDetailElement_get_Elements(TElSAMLStatusDetailElementHandle _Handle, int32_t Index, TElSAMLElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusDetailElement_get_ElementCount(TElSAMLStatusDetailElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusDetailElement_Create(TElSAMLStatusDetailElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSTATUSDETAILELEMENT */

#ifdef SB_USE_CLASS_TELSAMLSTATUSELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusElement_Assign(TElSAMLStatusElementHandle _Handle, TElSAMLElementHandle Other);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusElement_Clear(TElSAMLStatusElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusElement_LoadFromXML(TElSAMLStatusElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusElement_SaveToXML(TElSAMLStatusElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusElement_get_StatusCode(TElSAMLStatusElementHandle _Handle, TElSAMLStatusCodeElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusElement_set_StatusCode(TElSAMLStatusElementHandle _Handle, TElSAMLStatusCodeElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusElement_get_StatusMessage(TElSAMLStatusElementHandle _Handle, TElSAMLStatusMessageElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusElement_set_StatusMessage(TElSAMLStatusElementHandle _Handle, TElSAMLStatusMessageElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusElement_get_StatusDetail(TElSAMLStatusElementHandle _Handle, TElSAMLStatusDetailElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusElement_set_StatusDetail(TElSAMLStatusElementHandle _Handle, TElSAMLStatusDetailElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSTATUSELEMENT */

#ifdef SB_USE_CLASS_TELSAMLSTATUSRESPONSETYPE
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_Clear(TElSAMLStatusResponseTypeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_CreateByName(const char * pcName, int32_t szName, TElSAMLStatusResponseTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_CreateByName_1(TElSAMLStatusResponseTypeHandle _Handle, const char * pcName, int32_t szName, TElSAMLStatusResponseTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_CreateByRequest(TElSAMLRequestAbstractTypeHandle Req, TElSAMLStatusResponseTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_CreateByRequest_1(TElSAMLStatusResponseTypeHandle _Handle, TElSAMLRequestAbstractTypeHandle Req, TElSAMLStatusResponseTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_LoadFromXML(TElSAMLStatusResponseTypeHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_SaveToXML(TElSAMLStatusResponseTypeHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_get_ElementName(TElSAMLStatusResponseTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_set_ElementName(TElSAMLStatusResponseTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_get_Signed(TElSAMLStatusResponseTypeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_set_Signed(TElSAMLStatusResponseTypeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_get_ID(TElSAMLStatusResponseTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_set_ID(TElSAMLStatusResponseTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_get_InResponseTo(TElSAMLStatusResponseTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_set_InResponseTo(TElSAMLStatusResponseTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_get_Version(TElSAMLStatusResponseTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_set_Version(TElSAMLStatusResponseTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_get_IssueInstant(TElSAMLStatusResponseTypeHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_set_IssueInstant(TElSAMLStatusResponseTypeHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_get_Destination(TElSAMLStatusResponseTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_set_Destination(TElSAMLStatusResponseTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_get_Consent(TElSAMLStatusResponseTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_set_Consent(TElSAMLStatusResponseTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_get_Issuer(TElSAMLStatusResponseTypeHandle _Handle, TElSAMLIssuerElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_set_Issuer(TElSAMLStatusResponseTypeHandle _Handle, TElSAMLIssuerElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_get_Signature(TElSAMLStatusResponseTypeHandle _Handle, TElXMLSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_get_Extensions(TElSAMLStatusResponseTypeHandle _Handle, TElSAMLExtensionsElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_set_Extensions(TElSAMLStatusResponseTypeHandle _Handle, TElSAMLExtensionsElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_get_Status(TElSAMLStatusResponseTypeHandle _Handle, TElSAMLStatusElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_set_Status(TElSAMLStatusResponseTypeHandle _Handle, TElSAMLStatusElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLStatusResponseType_Create(TElSAMLStatusResponseTypeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSTATUSRESPONSETYPE */

#ifdef SB_USE_CLASS_TELSAMLASSERTIONIDREQUESTELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRequestElement_Clear(TElSAMLAssertionIDRequestElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRequestElement_LoadFromXML(TElSAMLAssertionIDRequestElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRequestElement_SaveToXML(TElSAMLAssertionIDRequestElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRequestElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRequestElement_AddReference(TElSAMLAssertionIDRequestElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRequestElement_RemoveReference(TElSAMLAssertionIDRequestElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRequestElement_get_References(TElSAMLAssertionIDRequestElementHandle _Handle, int32_t Index, TElSAMLAssertionIDRefElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRequestElement_get_ReferenceCount(TElSAMLAssertionIDRequestElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAssertionIDRequestElement_Create(TElSAMLAssertionIDRequestElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLASSERTIONIDREQUESTELEMENT */

#ifdef SB_USE_CLASS_TELSAMLSUBJECTQUERYABSTRACTTYPE
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectQueryAbstractType_Clear(TElSAMLSubjectQueryAbstractTypeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectQueryAbstractType_LoadFromXML(TElSAMLSubjectQueryAbstractTypeHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectQueryAbstractType_SaveToXML(TElSAMLSubjectQueryAbstractTypeHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectQueryAbstractType_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectQueryAbstractType_get_Subject(TElSAMLSubjectQueryAbstractTypeHandle _Handle, TElSAMLSubjectElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectQueryAbstractType_set_Subject(TElSAMLSubjectQueryAbstractTypeHandle _Handle, TElSAMLSubjectElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectQueryAbstractType_Create(TElSAMLSubjectQueryAbstractTypeHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSUBJECTQUERYABSTRACTTYPE */

#ifdef SB_USE_CLASS_TELSAMLSUBJECTQUERYELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLSubjectQueryElement_Create(TElSAMLSubjectQueryElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSUBJECTQUERYELEMENT */

#ifdef SB_USE_CLASS_TELSAMLREQUESTEDAUTHNCONTEXTELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestedAuthnContextElement_Clear(TElSAMLRequestedAuthnContextElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestedAuthnContextElement_LoadFromXML(TElSAMLRequestedAuthnContextElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestedAuthnContextElement_SaveToXML(TElSAMLRequestedAuthnContextElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestedAuthnContextElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestedAuthnContextElement_get_RefType(TElSAMLRequestedAuthnContextElementHandle _Handle, TSBSAMLAuthnContextRefTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestedAuthnContextElement_set_RefType(TElSAMLRequestedAuthnContextElementHandle _Handle, TSBSAMLAuthnContextRefTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestedAuthnContextElement_get_List(TElSAMLRequestedAuthnContextElementHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestedAuthnContextElement_get_Comparison(TElSAMLRequestedAuthnContextElementHandle _Handle, TSBSAMLAuthnContextComparisonTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestedAuthnContextElement_set_Comparison(TElSAMLRequestedAuthnContextElementHandle _Handle, TSBSAMLAuthnContextComparisonTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLRequestedAuthnContextElement_Create(TElSAMLRequestedAuthnContextElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLREQUESTEDAUTHNCONTEXTELEMENT */

#ifdef SB_USE_CLASS_TELSAMLAUTHNQUERYELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnQueryElement_Clear(TElSAMLAuthnQueryElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnQueryElement_LoadFromXML(TElSAMLAuthnQueryElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnQueryElement_SaveToXML(TElSAMLAuthnQueryElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnQueryElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnQueryElement_get_RequestedAuthnContext(TElSAMLAuthnQueryElementHandle _Handle, TElSAMLRequestedAuthnContextElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnQueryElement_set_RequestedAuthnContext(TElSAMLAuthnQueryElementHandle _Handle, TElSAMLRequestedAuthnContextElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnQueryElement_get_SessionIndex(TElSAMLAuthnQueryElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnQueryElement_set_SessionIndex(TElSAMLAuthnQueryElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnQueryElement_Create(TElSAMLAuthnQueryElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLAUTHNQUERYELEMENT */

#ifdef SB_USE_CLASS_TELSAMLATTRIBUTEQUERYELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeQueryElement_Clear(TElSAMLAttributeQueryElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeQueryElement_LoadFromXML(TElSAMLAttributeQueryElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeQueryElement_SaveToXML(TElSAMLAttributeQueryElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeQueryElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeQueryElement_AddAttribute(TElSAMLAttributeQueryElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeQueryElement_RemoveAttribute(TElSAMLAttributeQueryElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeQueryElement_get_Attributes(TElSAMLAttributeQueryElementHandle _Handle, int32_t Index, TElSAMLAttributeElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeQueryElement_get_AttributeCount(TElSAMLAttributeQueryElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAttributeQueryElement_Create(TElSAMLAttributeQueryElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLATTRIBUTEQUERYELEMENT */

#ifdef SB_USE_CLASS_TELSAMLAUTHZDECISIONQUERYELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionQueryElement_Clear(TElSAMLAuthzDecisionQueryElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionQueryElement_LoadFromXML(TElSAMLAuthzDecisionQueryElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionQueryElement_SaveToXML(TElSAMLAuthzDecisionQueryElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionQueryElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionQueryElement_AddAction(TElSAMLAuthzDecisionQueryElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionQueryElement_RemoveAction(TElSAMLAuthzDecisionQueryElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionQueryElement_get_Resource(TElSAMLAuthzDecisionQueryElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionQueryElement_set_Resource(TElSAMLAuthzDecisionQueryElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionQueryElement_get_Evidence(TElSAMLAuthzDecisionQueryElementHandle _Handle, TElSAMLEvidenceElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionQueryElement_set_Evidence(TElSAMLAuthzDecisionQueryElementHandle _Handle, TElSAMLEvidenceElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionQueryElement_get_Actions(TElSAMLAuthzDecisionQueryElementHandle _Handle, int32_t Index, TElSAMLActionElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionQueryElement_get_ActionCount(TElSAMLAuthzDecisionQueryElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthzDecisionQueryElement_Create(TElSAMLAuthzDecisionQueryElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLAUTHZDECISIONQUERYELEMENT */

#ifdef SB_USE_CLASS_TELSAMLRESPONSEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLResponseElement_GetInstance(TElXMLDOMDocumentHandle Doc, TElSAMLStatusResponseTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLResponseElement_GetInstance_1(TElSAMLResponseElementHandle _Handle, TElXMLDOMDocumentHandle Doc, TElSAMLStatusResponseTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLResponseElement_Clear(TElSAMLResponseElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLResponseElement_LoadFromXML(TElSAMLResponseElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLResponseElement_SaveToXML(TElSAMLResponseElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLResponseElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLResponseElement_AddAssertion(TElSAMLResponseElementHandle _Handle, TElSAMLAssertionTypeHandle Assertion, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLResponseElement_RemoveAssertion(TElSAMLResponseElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLResponseElement_get_Assertions(TElSAMLResponseElementHandle _Handle, int32_t Index, TElSAMLAssertionTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLResponseElement_get_AssertionCount(TElSAMLResponseElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLResponseElement_Create(TElSAMLResponseElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLRESPONSEELEMENT */

#ifdef SB_USE_CLASS_TELSAMLNAMEIDPOLICYELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDPolicyElement_Clear(TElSAMLNameIDPolicyElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDPolicyElement_LoadFromXML(TElSAMLNameIDPolicyElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDPolicyElement_SaveToXML(TElSAMLNameIDPolicyElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDPolicyElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDPolicyElement_get_Format(TElSAMLNameIDPolicyElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDPolicyElement_set_Format(TElSAMLNameIDPolicyElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDPolicyElement_get_SPNameQualifier(TElSAMLNameIDPolicyElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDPolicyElement_set_SPNameQualifier(TElSAMLNameIDPolicyElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDPolicyElement_get_AllowCreate(TElSAMLNameIDPolicyElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDPolicyElement_set_AllowCreate(TElSAMLNameIDPolicyElementHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDPolicyElement_get_UseAllowCreate(TElSAMLNameIDPolicyElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDPolicyElement_set_UseAllowCreate(TElSAMLNameIDPolicyElementHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDPolicyElement_Create(TElSAMLNameIDPolicyElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLNAMEIDPOLICYELEMENT */

#ifdef SB_USE_CLASS_TELSAMLIDPENTRYELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPEntryElement_Clear(TElSAMLIDPEntryElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPEntryElement_LoadFromXML(TElSAMLIDPEntryElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPEntryElement_SaveToXML(TElSAMLIDPEntryElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPEntryElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPEntryElement_get_ProviderID(TElSAMLIDPEntryElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPEntryElement_set_ProviderID(TElSAMLIDPEntryElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPEntryElement_get_Name(TElSAMLIDPEntryElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPEntryElement_set_Name(TElSAMLIDPEntryElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPEntryElement_get_Loc(TElSAMLIDPEntryElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPEntryElement_set_Loc(TElSAMLIDPEntryElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPEntryElement_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLIDPENTRYELEMENT */

#ifdef SB_USE_CLASS_TELSAMLIDPLISTELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPListElement_Clear(TElSAMLIDPListElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPListElement_LoadFromXML(TElSAMLIDPListElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPListElement_SaveToXML(TElSAMLIDPListElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPListElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPListElement_AddIDPEntry(TElSAMLIDPListElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPListElement_RemoveIDPEntry(TElSAMLIDPListElementHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPListElement_get_GetComplete(TElSAMLIDPListElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPListElement_set_GetComplete(TElSAMLIDPListElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPListElement_get_IDPEntries(TElSAMLIDPListElementHandle _Handle, int32_t Index, TElSAMLIDPEntryElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPListElement_get_IDPEntryCount(TElSAMLIDPListElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLIDPListElement_Create(TElSAMLIDPListElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLIDPLISTELEMENT */

#ifdef SB_USE_CLASS_TELSAMLSCOPINGELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLScopingElement_Clear(TElSAMLScopingElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLScopingElement_LoadFromXML(TElSAMLScopingElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLScopingElement_SaveToXML(TElSAMLScopingElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLScopingElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLScopingElement_get_ProxyCount(TElSAMLScopingElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLScopingElement_set_ProxyCount(TElSAMLScopingElementHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLScopingElement_get_IDPList(TElSAMLScopingElementHandle _Handle, TElSAMLIDPListElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLScopingElement_set_IDPList(TElSAMLScopingElementHandle _Handle, TElSAMLIDPListElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLScopingElement_get_RequesterIDs(TElSAMLScopingElementHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLScopingElement_Create(TElSAMLScopingElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLSCOPINGELEMENT */

#ifdef SB_USE_CLASS_TELSAMLAUTHNREQUESTELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_Clear(TElSAMLAuthnRequestElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_LoadFromXML(TElSAMLAuthnRequestElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_SaveToXML(TElSAMLAuthnRequestElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_get_ForceAuthn(TElSAMLAuthnRequestElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_set_ForceAuthn(TElSAMLAuthnRequestElementHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_get_IsPassive(TElSAMLAuthnRequestElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_set_IsPassive(TElSAMLAuthnRequestElementHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_get_UseForceAuthn(TElSAMLAuthnRequestElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_set_UseForceAuthn(TElSAMLAuthnRequestElementHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_get_UseIsPassive(TElSAMLAuthnRequestElementHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_set_UseIsPassive(TElSAMLAuthnRequestElementHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_get_ProtocolBinding(TElSAMLAuthnRequestElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_set_ProtocolBinding(TElSAMLAuthnRequestElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_get_AssertionConsumerServiceIndex(TElSAMLAuthnRequestElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_set_AssertionConsumerServiceIndex(TElSAMLAuthnRequestElementHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_get_AssertionConsumerServiceURL(TElSAMLAuthnRequestElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_set_AssertionConsumerServiceURL(TElSAMLAuthnRequestElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_get_AttributeConsumingServiceIndex(TElSAMLAuthnRequestElementHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_set_AttributeConsumingServiceIndex(TElSAMLAuthnRequestElementHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_get_ProviderName(TElSAMLAuthnRequestElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_set_ProviderName(TElSAMLAuthnRequestElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_get_Subject(TElSAMLAuthnRequestElementHandle _Handle, TElSAMLSubjectElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_set_Subject(TElSAMLAuthnRequestElementHandle _Handle, TElSAMLSubjectElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_get_NameIDPolicy(TElSAMLAuthnRequestElementHandle _Handle, TElSAMLNameIDPolicyElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_set_NameIDPolicy(TElSAMLAuthnRequestElementHandle _Handle, TElSAMLNameIDPolicyElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_get_Conditions(TElSAMLAuthnRequestElementHandle _Handle, TElSAMLConditionsElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_set_Conditions(TElSAMLAuthnRequestElementHandle _Handle, TElSAMLConditionsElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_get_RequestedAuthnContext(TElSAMLAuthnRequestElementHandle _Handle, TElSAMLRequestedAuthnContextElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_set_RequestedAuthnContext(TElSAMLAuthnRequestElementHandle _Handle, TElSAMLRequestedAuthnContextElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_get_Scoping(TElSAMLAuthnRequestElementHandle _Handle, TElSAMLScopingElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_set_Scoping(TElSAMLAuthnRequestElementHandle _Handle, TElSAMLScopingElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLAuthnRequestElement_Create(TElSAMLAuthnRequestElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLAUTHNREQUESTELEMENT */

#ifdef SB_USE_CLASS_TELSAMLARTIFACTRESOLVEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLArtifactResolveElement_Clear(TElSAMLArtifactResolveElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLArtifactResolveElement_LoadFromXML(TElSAMLArtifactResolveElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLArtifactResolveElement_SaveToXML(TElSAMLArtifactResolveElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLArtifactResolveElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLArtifactResolveElement_get_Artifact(TElSAMLArtifactResolveElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLArtifactResolveElement_set_Artifact(TElSAMLArtifactResolveElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLArtifactResolveElement_Create(TElSAMLArtifactResolveElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLARTIFACTRESOLVEELEMENT */

#ifdef SB_USE_CLASS_TELSAMLARTIFACTRESPONSEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLArtifactResponseElement_Clear(TElSAMLArtifactResponseElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLArtifactResponseElement_LoadFromXML(TElSAMLArtifactResponseElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLArtifactResponseElement_SaveToXML(TElSAMLArtifactResponseElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLArtifactResponseElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLArtifactResponseElement_get_Optional(TElSAMLArtifactResponseElementHandle _Handle, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLArtifactResponseElement_set_Optional(TElSAMLArtifactResponseElementHandle _Handle, TElXMLDOMElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLArtifactResponseElement_Create(TElSAMLArtifactResponseElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLARTIFACTRESPONSEELEMENT */

#ifdef SB_USE_CLASS_TELSAMLMANAGENAMEIDREQUESTELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLManageNameIDRequestElement_Clear(TElSAMLManageNameIDRequestElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLManageNameIDRequestElement_LoadFromXML(TElSAMLManageNameIDRequestElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLManageNameIDRequestElement_SaveToXML(TElSAMLManageNameIDRequestElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLManageNameIDRequestElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLManageNameIDRequestElement_get_NameID(TElSAMLManageNameIDRequestElementHandle _Handle, TElSAMLIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLManageNameIDRequestElement_set_NameID(TElSAMLManageNameIDRequestElementHandle _Handle, TElSAMLIDHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLManageNameIDRequestElement_get_NewID(TElSAMLManageNameIDRequestElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLManageNameIDRequestElement_set_NewID(TElSAMLManageNameIDRequestElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLManageNameIDRequestElement_get_NewEncryptedID(TElSAMLManageNameIDRequestElementHandle _Handle, TElSAMLEncryptedElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLManageNameIDRequestElement_set_NewEncryptedID(TElSAMLManageNameIDRequestElementHandle _Handle, TElSAMLEncryptedElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLManageNameIDRequestElement_get_Terminate(TElSAMLManageNameIDRequestElementHandle _Handle, TElSAMLElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLManageNameIDRequestElement_set_Terminate(TElSAMLManageNameIDRequestElementHandle _Handle, TElSAMLElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLManageNameIDRequestElement_Create(TElSAMLManageNameIDRequestElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLMANAGENAMEIDREQUESTELEMENT */

#ifdef SB_USE_CLASS_TELSAMLMANAGENAMEIDRESPONSEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLManageNameIDResponseElement_Create(TElSAMLManageNameIDResponseElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLMANAGENAMEIDRESPONSEELEMENT */

#ifdef SB_USE_CLASS_TELSAMLLOGOUTREQUESTELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLLogoutRequestElement_Clear(TElSAMLLogoutRequestElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLLogoutRequestElement_LoadFromXML(TElSAMLLogoutRequestElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLLogoutRequestElement_SaveToXML(TElSAMLLogoutRequestElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLLogoutRequestElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLLogoutRequestElement_get_NameID(TElSAMLLogoutRequestElementHandle _Handle, TElSAMLIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLLogoutRequestElement_set_NameID(TElSAMLLogoutRequestElementHandle _Handle, TElSAMLIDHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLLogoutRequestElement_get_Reason(TElSAMLLogoutRequestElementHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLLogoutRequestElement_set_Reason(TElSAMLLogoutRequestElementHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLLogoutRequestElement_get_NotOnOrAfter(TElSAMLLogoutRequestElementHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLLogoutRequestElement_set_NotOnOrAfter(TElSAMLLogoutRequestElementHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLLogoutRequestElement_get_SessionIndexes(TElSAMLLogoutRequestElementHandle _Handle, TElStringListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLLogoutRequestElement_Create(TElSAMLLogoutRequestElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLLOGOUTREQUESTELEMENT */

#ifdef SB_USE_CLASS_TELSAMLLOGOUTRESPONSEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLLogoutResponseElement_Create(TElSAMLLogoutResponseElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLLOGOUTRESPONSEELEMENT */

#ifdef SB_USE_CLASS_TELSAMLNAMEIDMAPPINGREQUESTELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingRequestElement_Clear(TElSAMLNameIDMappingRequestElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingRequestElement_LoadFromXML(TElSAMLNameIDMappingRequestElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingRequestElement_SaveToXML(TElSAMLNameIDMappingRequestElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingRequestElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingRequestElement_get_NameID(TElSAMLNameIDMappingRequestElementHandle _Handle, TElSAMLIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingRequestElement_set_NameID(TElSAMLNameIDMappingRequestElementHandle _Handle, TElSAMLIDHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingRequestElement_get_NameIDPolicy(TElSAMLNameIDMappingRequestElementHandle _Handle, TElSAMLNameIDPolicyElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingRequestElement_set_NameIDPolicy(TElSAMLNameIDMappingRequestElementHandle _Handle, TElSAMLNameIDPolicyElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingRequestElement_Create(TElSAMLNameIDMappingRequestElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLNAMEIDMAPPINGREQUESTELEMENT */

#ifdef SB_USE_CLASS_TELSAMLNAMEIDMAPPINGRESPONSEELEMENT
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingResponseElement_Clear(TElSAMLNameIDMappingResponseElementHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingResponseElement_LoadFromXML(TElSAMLNameIDMappingResponseElementHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingResponseElement_SaveToXML(TElSAMLNameIDMappingResponseElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingResponseElement_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingResponseElement_get_NameID(TElSAMLNameIDMappingResponseElementHandle _Handle, TElSAMLIDHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingResponseElement_set_NameID(TElSAMLNameIDMappingResponseElementHandle _Handle, TElSAMLIDHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElSAMLNameIDMappingResponseElement_Create(TElSAMLNameIDMappingResponseElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELSAMLNAMEIDMAPPINGRESPONSEELEMENT */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElSAMLExtensionsElement_ce_ptr;
extern zend_class_entry *TElSAMLRequestAbstractType_ce_ptr;
extern zend_class_entry *TElSAMLStatusCodeElement_ce_ptr;
extern zend_class_entry *TElSAMLStatusMessageElement_ce_ptr;
extern zend_class_entry *TElSAMLStatusDetailElement_ce_ptr;
extern zend_class_entry *TElSAMLStatusElement_ce_ptr;
extern zend_class_entry *TElSAMLStatusResponseType_ce_ptr;
extern zend_class_entry *TElSAMLAssertionIDRequestElement_ce_ptr;
extern zend_class_entry *TElSAMLSubjectQueryAbstractType_ce_ptr;
extern zend_class_entry *TElSAMLSubjectQueryElement_ce_ptr;
extern zend_class_entry *TElSAMLRequestedAuthnContextElement_ce_ptr;
extern zend_class_entry *TElSAMLAuthnQueryElement_ce_ptr;
extern zend_class_entry *TElSAMLAttributeQueryElement_ce_ptr;
extern zend_class_entry *TElSAMLAuthzDecisionQueryElement_ce_ptr;
extern zend_class_entry *TElSAMLResponseElement_ce_ptr;
extern zend_class_entry *TElSAMLNameIDPolicyElement_ce_ptr;
extern zend_class_entry *TElSAMLIDPEntryElement_ce_ptr;
extern zend_class_entry *TElSAMLIDPListElement_ce_ptr;
extern zend_class_entry *TElSAMLScopingElement_ce_ptr;
extern zend_class_entry *TElSAMLAuthnRequestElement_ce_ptr;
extern zend_class_entry *TElSAMLArtifactResolveElement_ce_ptr;
extern zend_class_entry *TElSAMLArtifactResponseElement_ce_ptr;
extern zend_class_entry *TElSAMLManageNameIDRequestElement_ce_ptr;
extern zend_class_entry *TElSAMLManageNameIDResponseElement_ce_ptr;
extern zend_class_entry *TElSAMLLogoutRequestElement_ce_ptr;
extern zend_class_entry *TElSAMLLogoutResponseElement_ce_ptr;
extern zend_class_entry *TElSAMLNameIDMappingRequestElement_ce_ptr;
extern zend_class_entry *TElSAMLNameIDMappingResponseElement_ce_ptr;

void Register_TElSAMLExtensionsElement(TSRMLS_D);
void Register_TElSAMLRequestAbstractType(TSRMLS_D);
void Register_TElSAMLStatusCodeElement(TSRMLS_D);
void Register_TElSAMLStatusMessageElement(TSRMLS_D);
void Register_TElSAMLStatusDetailElement(TSRMLS_D);
void Register_TElSAMLStatusElement(TSRMLS_D);
void Register_TElSAMLStatusResponseType(TSRMLS_D);
void Register_TElSAMLAssertionIDRequestElement(TSRMLS_D);
void Register_TElSAMLSubjectQueryAbstractType(TSRMLS_D);
void Register_TElSAMLSubjectQueryElement(TSRMLS_D);
void Register_TElSAMLRequestedAuthnContextElement(TSRMLS_D);
void Register_TElSAMLAuthnQueryElement(TSRMLS_D);
void Register_TElSAMLAttributeQueryElement(TSRMLS_D);
void Register_TElSAMLAuthzDecisionQueryElement(TSRMLS_D);
void Register_TElSAMLResponseElement(TSRMLS_D);
void Register_TElSAMLNameIDPolicyElement(TSRMLS_D);
void Register_TElSAMLIDPEntryElement(TSRMLS_D);
void Register_TElSAMLIDPListElement(TSRMLS_D);
void Register_TElSAMLScopingElement(TSRMLS_D);
void Register_TElSAMLAuthnRequestElement(TSRMLS_D);
void Register_TElSAMLArtifactResolveElement(TSRMLS_D);
void Register_TElSAMLArtifactResponseElement(TSRMLS_D);
void Register_TElSAMLManageNameIDRequestElement(TSRMLS_D);
void Register_TElSAMLManageNameIDResponseElement(TSRMLS_D);
void Register_TElSAMLLogoutRequestElement(TSRMLS_D);
void Register_TElSAMLLogoutResponseElement(TSRMLS_D);
void Register_TElSAMLNameIDMappingRequestElement(TSRMLS_D);
void Register_TElSAMLNameIDMappingResponseElement(TSRMLS_D);
void Register_SBXMLSAMLProtocol_Constants(int module_number TSRMLS_DC);
void Register_SBXMLSAMLProtocol_Enum_Flags(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLSAMLPROTOCOL */

