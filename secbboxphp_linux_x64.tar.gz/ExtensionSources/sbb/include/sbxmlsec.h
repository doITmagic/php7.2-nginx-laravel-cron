#ifndef __INC_SBXMLSEC
#define __INC_SBXMLSEC

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbrdn.h"
#include "sbx509.h"
#include "sbpgpkeys.h"
#include "sbpgputils.h"
#include "sbcryptoprov.h"
#include "sbcustomcertstorage.h"
#include "sbhashfunction.h"
#include "sbpublickeycrypto.h"
#include "sbsymmetriccrypto.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbstreams.h"
#include "sbrandom.h"
#include "sbxmldefs.h"
#include "sbxmlcore.h"
#include "sbxmltransform.h"
#include "sbxmlutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define SB_SXMLReferenceNoContext 	"Reference requires a context"
#define SB_SXMLUnsupportedECFieldType 	"Unsupported EC field type"
#define SB_SXMLNotSupportedAlgorithm 	"Unsupported algorithm"

typedef TElClassHandle TElXMLKeyInfoHandle;

typedef TElXMLKeyInfoHandle ElXMLKeyInfoHandle;

typedef TElClassHandle TElXMLAlgorithmParametersHandle;

typedef TElXMLAlgorithmParametersHandle ElXMLAlgorithmParametersHandle;

typedef TElClassHandle TElXMLReferenceHandle;

typedef TElXMLReferenceHandle ElXMLReferenceHandle;

typedef TElClassHandle TElXMLReferenceListHandle;

typedef TElXMLReferenceListHandle ElXMLReferenceListHandle;

typedef TElClassHandle TElXMLGOSTR3411ParametersHandle;

typedef TElClassHandle TElXMLRSAPSSParametersHandle;

typedef TElClassHandle TElXMLKeyInfoItemHandle;

typedef TElXMLKeyInfoItemHandle ElXMLKeyInfoItemHandle;

typedef TElClassHandle TElXMLKeyInfoDataHandle;

typedef TElXMLKeyInfoDataHandle ElXMLKeyInfoDataHandle;

typedef TElClassHandle TElXMLKeyInfoHMACDataHandle;

typedef TElXMLKeyInfoHMACDataHandle ElXMLKeyInfoHMACDataHandle;

typedef TElClassHandle TElXMLKeyInfoSymmetricDataHandle;

typedef TElXMLKeyInfoSymmetricDataHandle ElXMLKeyInfoSymmetricDataHandle;

typedef TElClassHandle TElXMLKeyInfoKeyDerivationMethodHandle;

typedef TElXMLKeyInfoKeyDerivationMethodHandle ElXMLKeyInfoKeyDerivationMethodHandle;

typedef TElClassHandle TElXMLKeyInfoPBKDF2DerivationMethodHandle;

typedef TElXMLKeyInfoPBKDF2DerivationMethodHandle ElXMLKeyInfoPBKDF2DerivationMethodHandle;

typedef TElClassHandle TElXMLKeyInfoConcatKDFDerivationMethodHandle;

typedef TElXMLKeyInfoConcatKDFDerivationMethodHandle ElXMLKeyInfoConcatKDFDerivationMethodHandle;

typedef TElClassHandle TElXMLPBKDF2SaltHandle;

typedef TElClassHandle TElXMLPRFAlgorithmIdentifierTypeHandle;

typedef TElClassHandle TElXMLKeyInfoDerivedKeyDataHandle;

typedef TElXMLKeyInfoDerivedKeyDataHandle ElXMLKeyInfoDerivedKeyDataHandle;

typedef TElClassHandle TElXMLKeyInfoAsymmetricDataHandle;

typedef TElXMLKeyInfoAsymmetricDataHandle ElXMLKeyInfoAsymmetricDataHandle;

typedef TElClassHandle TElXMLKeyInfoRSADataHandle;

typedef TElXMLKeyInfoRSADataHandle ElXMLKeyInfoRSADataHandle;

typedef TElClassHandle TElXMLKeyInfoDSADataHandle;

typedef TElXMLKeyInfoDSADataHandle ElXMLKeyInfoDSADataHandle;

typedef TElClassHandle TElXMLKeyInfoDHDataHandle;

typedef TElXMLKeyInfoDHDataHandle ElXMLKeyInfoDHDataHandle;

typedef TElClassHandle TElXMLKeyInfoGOST2001DataHandle;

typedef TElClassHandle TElXMLKeyInfoPGPDataHandle;

typedef TElXMLKeyInfoPGPDataHandle ElXMLKeyInfoPGPDataHandle;

typedef TElClassHandle TElXMLKeyInfoECDataHandle;

typedef TElClassHandle TElXMLIssuerSerialHandle;

typedef TElXMLIssuerSerialHandle ElXMLIssuerSerialHandle;

typedef TElClassHandle TElXMLKeyInfoX509DataHandle;

typedef TElXMLKeyInfoX509DataHandle ElXMLKeyInfoX509DataHandle;

typedef TElClassHandle TElXMLKeyInfoNodeHandle;

typedef TElXMLKeyInfoNodeHandle ElXMLKeyInfoNodeHandle;

typedef TElClassHandle TElXMLKeyInfoRetrievalMethodHandle;

typedef TElXMLKeyInfoRetrievalMethodHandle ElXMLKeyInfoRetrievalMethodHandle;

typedef TElClassHandle TElXMLKeyInfoAgreementMethodHandle;

typedef TElXMLKeyInfoAgreementMethodHandle ElXMLKeyInfoAgreementMethodHandle;

typedef TElClassHandle TElXMLPropertyHandle;

typedef TElXMLPropertyHandle ElXMLPropertyHandle;

typedef TElClassHandle TElXMLPropertiesHandle;

typedef TElXMLPropertiesHandle ElXMLPropertiesHandle;

typedef TElClassHandle TElXMLProcessorHandle;

typedef TElXMLProcessorHandle ElXMLProcessorHandle;

typedef TElClassHandle TElXMLFormatterHandle;

typedef TElXMLFormatterHandle ElXMLFormatterHandle;

typedef TElClassHandle TElXMLDescriptorMapHandle;

typedef uint8_t TElXMLSignatureTypeRaw;

typedef enum
{
	xstDetached = 0,
	xstEnveloping = 1,
	xstEnveloped = 2
} TElXMLSignatureType;

typedef uint32_t TElXMLSignatureTypesRaw;

typedef enum 
{
	f_xstDetached = 1,
	f_xstEnveloping = 2,
	f_xstEnveloped = 4
} TElXMLSignatureTypes;

typedef uint8_t TElXMLSignatureComplianceRaw;

typedef enum
{
	xscDSIG = 0,
	xscEBICS = 1
} TElXMLSignatureCompliance;

typedef uint8_t TElXMLSigMethodTypeRaw;

typedef enum
{
	xmtSig = 0,
	xmtMAC = 1
} TElXMLSigMethodType;

typedef uint8_t TElXMLDigestMethodRaw;

typedef enum
{
	xdmMD5 = 0,
	xdmSHA1 = 1,
	xdmSHA224 = 2,
	xdmSHA256 = 3,
	xdmSHA384 = 4,
	xdmSHA512 = 5,
	xdmRIPEMD160 = 6,
	xdmGOST = 7,
	xdmWhirlpool = 8,
	xdmSHA3_224 = 9,
	xdmSHA3_256 = 10,
	xdmSHA3_384 = 11,
	xdmSHA3_512 = 12
} TElXMLDigestMethod;

typedef uint8_t TElXMLMACMethodRaw;

typedef enum
{
	xmmHMAC_MD5 = 0,
	xmmHMAC_SHA1 = 1,
	xmmHMAC_SHA224 = 2,
	xmmHMAC_SHA256 = 3,
	xmmHMAC_SHA384 = 4,
	xmmHMAC_SHA512 = 5,
	xmmHMAC_RIPEMD160 = 6
} TElXMLMACMethod;

typedef uint8_t TElXMLSignatureMethodRaw;

typedef enum
{
	xsmDSS = 0,
	xsmRSA_MD5 = 1,
	xsmRSA_SHA1 = 2,
	xsmRSA_SHA256 = 3,
	xsmRSA_SHA384 = 4,
	xsmRSA_SHA512 = 5,
	xsmRSA_RIPEMD160 = 6,
	xsmECDSA_SHA1 = 7,
	xsmGOST1994 = 8,
	xsmGOST2001 = 9,
	xsmRSA_SHA224 = 10,
	xsmRSA_Whirlpool = 11,
	xsmDSA_SHA256 = 12,
	xsmECDSA_SHA224 = 13,
	xsmECDSA_SHA256 = 14,
	xsmECDSA_SHA384 = 15,
	xsmECDSA_SHA512 = 16,
	xsmECDSA_RIPEMD160 = 17,
	xsmECDSA_Whirlpool = 18,
	xsmRSA_PSS = 19,
	xsmRSA_PSS_MD5_MGF1 = 20,
	xsmRSA_PSS_SHA1_MGF1 = 21,
	xsmRSA_PSS_SHA224_MGF1 = 22,
	xsmRSA_PSS_SHA256_MGF1 = 23,
	xsmRSA_PSS_SHA384_MGF1 = 24,
	xsmRSA_PSS_SHA512_MGF1 = 25,
	xsmRSA_PSS_RIPEMD160_MGF1 = 26,
	xsmRSA_PSS_Whirlpool_MGF1 = 27
} TElXMLSignatureMethod;

typedef uint8_t TElXMLKeyInfoX509DataParamRaw;

typedef enum
{
	xkidX509IssuerSerial = 0,
	xkidX509SKI = 1,
	xkidX509SubjectName = 2,
	xkidX509Certificate = 3,
	xkidX509CRL = 4
} TElXMLKeyInfoX509DataParam;

typedef uint32_t TElXMLKeyInfoX509DataParamsRaw;

typedef enum 
{
	f_xkidX509IssuerSerial = 1,
	f_xkidX509SKI = 2,
	f_xkidX509SubjectName = 4,
	f_xkidX509Certificate = 8,
	f_xkidX509CRL = 16
} TElXMLKeyInfoX509DataParams;

typedef uint8_t TElXMLKeyInfoPGPDataParamRaw;

typedef enum
{
	xkidPGPKeyID = 0,
	xkidPGPKeyPacket = 1
} TElXMLKeyInfoPGPDataParam;

typedef uint8_t TElXMLEncryptedDataTypeRaw;

typedef enum
{
	xedtElement = 0,
	xedtContent = 1,
	xedtExternal = 2
} TElXMLEncryptedDataType;

typedef uint8_t TElXMLEncryptionMethodRaw;

typedef enum
{
	xem3DES = 0,
	xemAES = 1,
	xemCamellia = 2,
	xemDES = 3,
	xemRC4 = 4,
	xemSEED = 5,
	xemAES_GCM = 6
} TElXMLEncryptionMethod;

typedef uint8_t TElXMLKeyEncryptionTypeRaw;

typedef enum
{
	xetKeyTransport = 0,
	xetKeyWrap = 1
} TElXMLKeyEncryptionType;

typedef uint8_t TElXMLKeyTransportMethodRaw;

typedef enum
{
	xktRSA15 = 0,
	xktRSAOAEP = 1
} TElXMLKeyTransportMethod;

typedef uint8_t TElXMLKeyWrapMethodRaw;

typedef enum
{
	xwm3DES = 0,
	xwmAES128 = 1,
	xwmAES192 = 2,
	xwmAES256 = 3,
	xwmCamellia128 = 4,
	xwmCamellia192 = 5,
	xwmCamellia256 = 6,
	xwmSEED = 7
} TElXMLKeyWrapMethod;

typedef uint8_t TSBXMLECKeyValueFormatRaw;

typedef enum
{
	xekfRFC4050 = 0,
	xekfDSIG11 = 1
} TSBXMLECKeyValueFormat;

typedef uint8_t TSBXMLECPrimeNumberTypeRaw;

typedef enum
{
	xeptInteger = 0,
	xeptHex = 1
} TSBXMLECPrimeNumberType;

typedef void (SB_CALLBACK *TSBXMLFormatElementEvent)(void * _ObjectData, TObjectHandle Sender, TElXMLDOMElementHandle Element, int32_t Level, const char * pcPath, int32_t szPath, char * pcStartTagWhitespace, int32_t * szStartTagWhitespace, char * pcEndTagWhitespace, int32_t * szEndTagWhitespace);

typedef void (SB_CALLBACK *TSBXMLFormatTextEvent)(void * _ObjectData, TObjectHandle Sender, char * pcText, int32_t * szText, TElXMLTextTypeRaw TextType, int32_t Level, const char * pcPath, int32_t szPath);

typedef uint8_t TElXMLRDNCompatibilityModeRaw;

typedef enum
{
	cmRFC = 0,
	cmDotNET = 1,
	cmCustom = 2
} TElXMLRDNCompatibilityMode;

#ifdef SB_USE_CLASS_TELXMLKEYINFO
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_Add(TElXMLKeyInfoHandle _Handle, TElXMLKeyInfoItemHandle Item, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_Insert(TElXMLKeyInfoHandle _Handle, int32_t Index, TElXMLKeyInfoItemHandle Item);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_Delete(TElXMLKeyInfoHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_Exchange(TElXMLKeyInfoHandle _Handle, int32_t Index1, int32_t Index2);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_Clear(TElXMLKeyInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_IsEmpty(TElXMLKeyInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_LoadFromXML(TElXMLKeyInfoHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_SaveToXML(TElXMLKeyInfoHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_ExtractAllCertificates(TElXMLKeyInfoHandle _Handle, TElCustomCertStorageHandle Storage);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_SetKeyData(TElXMLKeyInfoHandle _Handle, const TElXMLKeyInfoDataHandle KeyData);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_get_Count(TElXMLKeyInfoHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_get_Items(TElXMLKeyInfoHandle _Handle, int32_t Index, TElXMLKeyInfoItemHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_get_CryptoProviderManager(TElXMLKeyInfoHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_set_CryptoProviderManager(TElXMLKeyInfoHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_get_KeyName(TElXMLKeyInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_set_KeyName(TElXMLKeyInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_get_ID(TElXMLKeyInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_set_ID(TElXMLKeyInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_Create(TElXMLKeyInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfo_Create_1(const char * pcAKeyName, int32_t szAKeyName, TElXMLKeyInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFO */

#ifdef SB_USE_CLASS_TELXMLALGORITHMPARAMETERS
SB_IMPORT uint32_t SB_APIENTRY TElXMLAlgorithmParameters_Clone(TElXMLAlgorithmParametersHandle _Handle, TElXMLAlgorithmParametersHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAlgorithmParameters_GetCryptoProviderParameters(TElXMLAlgorithmParametersHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLAlgorithmParameters_Create(TElXMLCustomElementHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLALGORITHMPARAMETERS */

#ifdef SB_USE_CLASS_TELXMLREFERENCE
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_UpdateDigestValue(TElXMLReferenceHandle _Handle, int32_t Mode);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_UpdateDigestValue_1(TElXMLReferenceHandle _Handle, int32_t Mode, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_UpdateDigestValue_2(TElXMLReferenceHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_UpdateDigestValue_3(TElXMLReferenceHandle _Handle, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_Clone(TElXMLReferenceHandle _Handle, TElXMLReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_Clear(TElXMLReferenceHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_LoadFromXML(TElXMLReferenceHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_SaveToXML(TElXMLReferenceHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_IsURIResolved(TElXMLReferenceHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_ProcessData(TElXMLReferenceHandle _Handle, TElHashFunctionHandle HashFunc);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_ProcessData_1(TElXMLReferenceHandle _Handle, TElHashFunctionHandle HashFunc, TElXMLCanonicalizationMethodRaw CanonicalizationMethod);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_get_TransformChain(TElXMLReferenceHandle _Handle, TElXMLTransformChainHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_get_DigestMethod(TElXMLReferenceHandle _Handle, TElXMLDigestMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_set_DigestMethod(TElXMLReferenceHandle _Handle, TElXMLDigestMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_get_DigestValue(TElXMLReferenceHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_set_DigestValue(TElXMLReferenceHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_get_DigestMethodParameters(TElXMLReferenceHandle _Handle, TElXMLAlgorithmParametersHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_get_ID(TElXMLReferenceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_set_ID(TElXMLReferenceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_get_URI(TElXMLReferenceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_set_URI(TElXMLReferenceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_get_RefType(TElXMLReferenceHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_set_RefType(TElXMLReferenceHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_get_HasURI(TElXMLReferenceHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_set_HasURI(TElXMLReferenceHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_get_URIData(TElXMLReferenceHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_set_URIData(TElXMLReferenceHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_get_URINode(TElXMLReferenceHandle _Handle, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_set_URINode(TElXMLReferenceHandle _Handle, TElXMLDOMNodeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_get_URINodes(TElXMLReferenceHandle _Handle, TElXMLNodeSetHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_set_URINodes(TElXMLReferenceHandle _Handle, TElXMLNodeSetHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_get_URIStream(TElXMLReferenceHandle _Handle, TStreamHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_set_URIStream(TElXMLReferenceHandle _Handle, TStreamHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_get_URIStreamOffset(TElXMLReferenceHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_set_URIStreamOffset(TElXMLReferenceHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_get_URIStreamCount(TElXMLReferenceHandle _Handle, int64_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_set_URIStreamCount(TElXMLReferenceHandle _Handle, int64_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReference_Create(TElXMLReferenceHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLREFERENCE */

#ifdef SB_USE_CLASS_TELXMLREFERENCELIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLReferenceList_Add(TElXMLReferenceListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReferenceList_Add_1(TElXMLReferenceListHandle _Handle, TElXMLReferenceHandle AReference, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReferenceList_Insert(TElXMLReferenceListHandle _Handle, int32_t Index, TElXMLReferenceHandle AReference);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReferenceList_Delete(TElXMLReferenceListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReferenceList_Clear(TElXMLReferenceListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReferenceList_IndexOf(TElXMLReferenceListHandle _Handle, TElXMLReferenceHandle AReference, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReferenceList_get_Count(TElXMLReferenceListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReferenceList_get_Reference(TElXMLReferenceListHandle _Handle, int32_t Index, TElXMLReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLReferenceList_Create(TElXMLReferenceListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLREFERENCELIST */

#ifdef SB_USE_CLASS_TELXMLGOSTR3411PARAMETERS
SB_IMPORT uint32_t SB_APIENTRY TElXMLGOSTR3411Parameters_Clear(TElXMLGOSTR3411ParametersHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGOSTR3411Parameters_Clone(TElXMLGOSTR3411ParametersHandle _Handle, TElXMLAlgorithmParametersHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGOSTR3411Parameters_LoadFromXML(TElXMLGOSTR3411ParametersHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGOSTR3411Parameters_SaveToXML(TElXMLGOSTR3411ParametersHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGOSTR3411Parameters_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGOSTR3411Parameters_GetCryptoProviderParameters(TElXMLGOSTR3411ParametersHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGOSTR3411Parameters_get_DigestParameter(TElXMLGOSTR3411ParametersHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGOSTR3411Parameters_set_DigestParameter(TElXMLGOSTR3411ParametersHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLGOSTR3411Parameters_Create(TElXMLGOSTR3411ParametersHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLGOSTR3411PARAMETERS */

#ifdef SB_USE_CLASS_TELXMLRSAPSSPARAMETERS
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_Clear(TElXMLRSAPSSParametersHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_Clone(TElXMLRSAPSSParametersHandle _Handle, TElXMLAlgorithmParametersHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_LoadFromXML(TElXMLRSAPSSParametersHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_SaveToXML(TElXMLRSAPSSParametersHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_GetCryptoProviderParameters(TElXMLRSAPSSParametersHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_get_DigestMethod(TElXMLRSAPSSParametersHandle _Handle, TElXMLDigestMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_set_DigestMethod(TElXMLRSAPSSParametersHandle _Handle, TElXMLDigestMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_get_MaskGenerationFunction(TElXMLRSAPSSParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_set_MaskGenerationFunction(TElXMLRSAPSSParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_get_SaltLength(TElXMLRSAPSSParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_set_SaltLength(TElXMLRSAPSSParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_get_TrailerField(TElXMLRSAPSSParametersHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_set_TrailerField(TElXMLRSAPSSParametersHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLRSAPSSParameters_Create(TElXMLRSAPSSParametersHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLRSAPSSPARAMETERS */

#ifdef SB_USE_CLASS_TELXMLKEYINFOITEM
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoItem_Create(TObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFOITEM */

#ifdef SB_USE_CLASS_TELXMLKEYINFODATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoData_get_OwnResources(TElXMLKeyInfoDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoData_set_OwnResources(TElXMLKeyInfoDataHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoData_Create(TElXMLKeyInfoDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoData_Create_1(int8_t AOwnResources, TElXMLKeyInfoDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoData_Create_2(int8_t AOwnResources, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElXMLKeyInfoDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFODATA */

#ifdef SB_USE_CLASS_TELXMLKEYINFOHMACDATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoHMACData_get_Key(TElXMLKeyInfoHMACDataHandle _Handle, TElHMACKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoHMACData_set_Key(TElXMLKeyInfoHMACDataHandle _Handle, TElHMACKeyMaterialHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoHMACData_Create(int8_t OwnResources, TElXMLKeyInfoHMACDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoHMACData_Create_1(int8_t AOwnResources, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElXMLKeyInfoHMACDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFOHMACDATA */

#ifdef SB_USE_CLASS_TELXMLKEYINFOSYMMETRICDATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoSymmetricData_get_Key(TElXMLKeyInfoSymmetricDataHandle _Handle, TElSymmetricKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoSymmetricData_set_Key(TElXMLKeyInfoSymmetricDataHandle _Handle, TElSymmetricKeyMaterialHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoSymmetricData_Create(int8_t OwnResources, TElXMLKeyInfoSymmetricDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoSymmetricData_Create_1(int8_t AOwnResources, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElXMLKeyInfoSymmetricDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFOSYMMETRICDATA */

#ifdef SB_USE_CLASS_TELXMLKEYINFOKEYDERIVATIONMETHOD
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoKeyDerivationMethod_LoadFromXML(TElXMLKeyInfoKeyDerivationMethodHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoKeyDerivationMethod_SaveToXML(TElXMLKeyInfoKeyDerivationMethodHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoKeyDerivationMethod_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoKeyDerivationMethod_Derive(TElXMLKeyInfoKeyDerivationMethodHandle _Handle, const uint8_t pSharedSecret[], int32_t szSharedSecret, int32_t KeyDataLen, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoKeyDerivationMethod_get_Algorithm(TElXMLKeyInfoKeyDerivationMethodHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoKeyDerivationMethod_Create(TElXMLKeyInfoKeyDerivationMethodHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFOKEYDERIVATIONMETHOD */

#ifdef SB_USE_CLASS_TELXMLKEYINFOPBKDF2DERIVATIONMETHOD
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPBKDF2DerivationMethod_LoadFromXML(TElXMLKeyInfoPBKDF2DerivationMethodHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPBKDF2DerivationMethod_SaveToXML(TElXMLKeyInfoPBKDF2DerivationMethodHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPBKDF2DerivationMethod_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPBKDF2DerivationMethod_Derive(TElXMLKeyInfoPBKDF2DerivationMethodHandle _Handle, const uint8_t pSharedSecret[], int32_t szSharedSecret, int32_t KeyDataLen, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPBKDF2DerivationMethod_get_Salt(TElXMLKeyInfoPBKDF2DerivationMethodHandle _Handle, TElXMLPBKDF2SaltHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPBKDF2DerivationMethod_set_Salt(TElXMLKeyInfoPBKDF2DerivationMethodHandle _Handle, TElXMLPBKDF2SaltHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPBKDF2DerivationMethod_get_IterationCount(TElXMLKeyInfoPBKDF2DerivationMethodHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPBKDF2DerivationMethod_set_IterationCount(TElXMLKeyInfoPBKDF2DerivationMethodHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPBKDF2DerivationMethod_get_KeyLength(TElXMLKeyInfoPBKDF2DerivationMethodHandle _Handle, uint32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPBKDF2DerivationMethod_set_KeyLength(TElXMLKeyInfoPBKDF2DerivationMethodHandle _Handle, uint32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPBKDF2DerivationMethod_get_PRFAlgorithm(TElXMLKeyInfoPBKDF2DerivationMethodHandle _Handle, TElXMLPRFAlgorithmIdentifierTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPBKDF2DerivationMethod_set_PRFAlgorithm(TElXMLKeyInfoPBKDF2DerivationMethodHandle _Handle, TElXMLPRFAlgorithmIdentifierTypeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPBKDF2DerivationMethod_Create(TElXMLKeyInfoPBKDF2DerivationMethodHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFOPBKDF2DERIVATIONMETHOD */

#ifdef SB_USE_CLASS_TELXMLKEYINFOCONCATKDFDERIVATIONMETHOD
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_LoadFromXML(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_SaveToXML(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_Derive(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, const uint8_t pSharedSecret[], int32_t szSharedSecret, int32_t KeyDataLen, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_get_AlgorithmID(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_set_AlgorithmID(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_get_PartyUInfo(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_set_PartyUInfo(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_get_PartyVInfo(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_set_PartyVInfo(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_get_SuppPubInfo(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_set_SuppPubInfo(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_get_SuppPrivInfo(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_set_SuppPrivInfo(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_get_DigestMethod(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_set_DigestMethod(TElXMLKeyInfoConcatKDFDerivationMethodHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoConcatKDFDerivationMethod_Create(TElXMLKeyInfoConcatKDFDerivationMethodHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFOCONCATKDFDERIVATIONMETHOD */

#ifdef SB_USE_CLASS_TELXMLPBKDF2SALT
SB_IMPORT uint32_t SB_APIENTRY TElXMLPBKDF2Salt_LoadFromXML(TElXMLPBKDF2SaltHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLPBKDF2Salt_SaveToXML(TElXMLPBKDF2SaltHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLPBKDF2Salt_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLPBKDF2Salt_get_Specified(TElXMLPBKDF2SaltHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLPBKDF2Salt_set_Specified(TElXMLPBKDF2SaltHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLPBKDF2Salt_Create(TElXMLPBKDF2SaltHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLPBKDF2SALT */

#ifdef SB_USE_CLASS_TELXMLPRFALGORITHMIDENTIFIERTYPE
SB_IMPORT uint32_t SB_APIENTRY TElXMLPRFAlgorithmIdentifierType_LoadFromXML(TElXMLPRFAlgorithmIdentifierTypeHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLPRFAlgorithmIdentifierType_SaveToXML(TElXMLPRFAlgorithmIdentifierTypeHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLPRFAlgorithmIdentifierType_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLPRFAlgorithmIdentifierType_get_Algorithm(TElXMLPRFAlgorithmIdentifierTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLPRFAlgorithmIdentifierType_set_Algorithm(TElXMLPRFAlgorithmIdentifierTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLPRFAlgorithmIdentifierType_Create(TElXMLPRFAlgorithmIdentifierTypeHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLPRFALGORITHMIDENTIFIERTYPE */

#ifdef SB_USE_CLASS_TELXMLKEYINFODERIVEDKEYDATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_Derive(TElXMLKeyInfoDerivedKeyDataHandle _Handle, const uint8_t pSharedSecret[], int32_t szSharedSecret, int32_t KeyDataLen);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_GenerateIV(TElXMLKeyInfoDerivedKeyDataHandle _Handle, int32_t IVLen);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_get_Key(TElXMLKeyInfoDerivedKeyDataHandle _Handle, TElSymmetricKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_set_Key(TElXMLKeyInfoDerivedKeyDataHandle _Handle, TElSymmetricKeyMaterialHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_get_DerivedKeyName(TElXMLKeyInfoDerivedKeyDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_set_DerivedKeyName(TElXMLKeyInfoDerivedKeyDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_get_MasterKeyName(TElXMLKeyInfoDerivedKeyDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_set_MasterKeyName(TElXMLKeyInfoDerivedKeyDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_get_Recipient(TElXMLKeyInfoDerivedKeyDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_set_Recipient(TElXMLKeyInfoDerivedKeyDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_get_Id(TElXMLKeyInfoDerivedKeyDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_set_Id(TElXMLKeyInfoDerivedKeyDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_get_AType(TElXMLKeyInfoDerivedKeyDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_set_AType(TElXMLKeyInfoDerivedKeyDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_get_KeyDerivationMethod(TElXMLKeyInfoDerivedKeyDataHandle _Handle, TElXMLKeyInfoKeyDerivationMethodHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_set_KeyDerivationMethod(TElXMLKeyInfoDerivedKeyDataHandle _Handle, TElXMLKeyInfoKeyDerivationMethodHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_Create(int8_t OwnResources, TElXMLKeyInfoDerivedKeyDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDerivedKeyData_Create_1(int8_t AOwnResources, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElXMLKeyInfoDerivedKeyDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFODERIVEDKEYDATA */

#ifdef SB_USE_CLASS_TELXMLKEYINFOASYMMETRICDATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAsymmetricData_Create(TElXMLKeyInfoDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAsymmetricData_Create_1(int8_t AOwnResources, TElXMLKeyInfoDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAsymmetricData_Create_2(int8_t AOwnResources, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElXMLKeyInfoDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFOASYMMETRICDATA */

#ifdef SB_USE_CLASS_TELXMLKEYINFORSADATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoRSAData_Update(TElXMLKeyInfoRSADataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoRSAData_get_RSAKeyMaterial(TElXMLKeyInfoRSADataHandle _Handle, TElRSAKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoRSAData_get_Exponent(TElXMLKeyInfoRSADataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoRSAData_get_Modulus(TElXMLKeyInfoRSADataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoRSAData_Create(int8_t OwnResources, TElXMLKeyInfoRSADataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoRSAData_Create_1(int8_t AOwnResources, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElXMLKeyInfoRSADataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFORSADATA */

#ifdef SB_USE_CLASS_TELXMLKEYINFODSADATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDSAData_Update(TElXMLKeyInfoDSADataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDSAData_get_DSAKeyMaterial(TElXMLKeyInfoDSADataHandle _Handle, TElDSAKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDSAData_get_P(TElXMLKeyInfoDSADataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDSAData_get_Q(TElXMLKeyInfoDSADataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDSAData_get_G(TElXMLKeyInfoDSADataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDSAData_get_Y(TElXMLKeyInfoDSADataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDSAData_get_J(TElXMLKeyInfoDSADataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDSAData_get_Seed(TElXMLKeyInfoDSADataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDSAData_get_PgenCounter(TElXMLKeyInfoDSADataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDSAData_Create(int8_t OwnResources, TElXMLKeyInfoDSADataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDSAData_Create_1(int8_t AOwnResources, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElXMLKeyInfoDSADataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFODSADATA */

#ifdef SB_USE_CLASS_TELXMLKEYINFODHDATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDHData_get_P(TElXMLKeyInfoDHDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDHData_get_Q(TElXMLKeyInfoDHDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDHData_get_Generator(TElXMLKeyInfoDHDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDHData_get_PublicKey(TElXMLKeyInfoDHDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDHData_get_Seed(TElXMLKeyInfoDHDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDHData_get_PgenCounter(TElXMLKeyInfoDHDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDHData_Create(int8_t OwnResources, TElXMLKeyInfoDHDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoDHData_Create_1(int8_t AOwnResources, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElXMLKeyInfoDHDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFODHDATA */

#ifdef SB_USE_CLASS_TELXMLKEYINFOGOST2001DATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoGOST2001Data_Update(TElXMLKeyInfoGOST2001DataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoGOST2001Data_get_GOST2001KeyMaterial(TElXMLKeyInfoGOST2001DataHandle _Handle, TElGOST2001KeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoGOST2001Data_get_PublicKey(TElXMLKeyInfoGOST2001DataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoGOST2001Data_get_PublicKeyParamSet(TElXMLKeyInfoGOST2001DataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoGOST2001Data_get_DigestParamSet(TElXMLKeyInfoGOST2001DataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoGOST2001Data_get_EncryptionParamSet(TElXMLKeyInfoGOST2001DataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoGOST2001Data_Create(int8_t OwnResources, TElXMLKeyInfoGOST2001DataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoGOST2001Data_Create_1(int8_t AOwnResources, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElXMLKeyInfoGOST2001DataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFOGOST2001DATA */

#ifdef SB_USE_CLASS_TELXMLKEYINFOPGPDATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_Update(TElXMLKeyInfoPGPDataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_get_IncludeDataParam(TElXMLKeyInfoPGPDataHandle _Handle, TElXMLKeyInfoPGPDataParamRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_set_IncludeDataParam(TElXMLKeyInfoPGPDataHandle _Handle, TElXMLKeyInfoPGPDataParamRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_get_IncludeKeyValue(TElXMLKeyInfoPGPDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_set_IncludeKeyValue(TElXMLKeyInfoPGPDataHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_get_PublicKey(TElXMLKeyInfoPGPDataHandle _Handle, TElPGPCustomPublicKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_set_PublicKey(TElXMLKeyInfoPGPDataHandle _Handle, TElPGPCustomPublicKeyHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_get_SecretKey(TElXMLKeyInfoPGPDataHandle _Handle, TElPGPCustomSecretKeyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_set_SecretKey(TElXMLKeyInfoPGPDataHandle _Handle, TElPGPCustomSecretKeyHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_get_Passphrase(TElXMLKeyInfoPGPDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_set_Passphrase(TElXMLKeyInfoPGPDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_get_KeyID(TElXMLKeyInfoPGPDataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_get_KeyPacketCount(TElXMLKeyInfoPGPDataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_get_KeyPackets(TElXMLKeyInfoPGPDataHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_Create(int8_t OwnResources, TElXMLKeyInfoPGPDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoPGPData_Create_1(int8_t AOwnResources, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElXMLKeyInfoPGPDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFOPGPDATA */

#ifdef SB_USE_CLASS_TELXMLKEYINFOECDATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_get_ECKeyMaterial(TElXMLKeyInfoECDataHandle _Handle, TElECKeyMaterialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_get_KeyValueFormat(TElXMLKeyInfoECDataHandle _Handle, TSBXMLECKeyValueFormatRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_set_KeyValueFormat(TElXMLKeyInfoECDataHandle _Handle, TSBXMLECKeyValueFormatRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_get_PrimeNumberType(TElXMLKeyInfoECDataHandle _Handle, TSBXMLECPrimeNumberTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_set_PrimeNumberType(TElXMLKeyInfoECDataHandle _Handle, TSBXMLECPrimeNumberTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_get_IncludeDomainParameters(TElXMLKeyInfoECDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_set_IncludeDomainParameters(TElXMLKeyInfoECDataHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_get_UseExplicitParameters(TElXMLKeyInfoECDataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_set_UseExplicitParameters(TElXMLKeyInfoECDataHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_get_ECDSAPrefix(TElXMLKeyInfoECDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_set_ECDSAPrefix(TElXMLKeyInfoECDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_get_DSIG11Prefix(TElXMLKeyInfoECDataHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_set_DSIG11Prefix(TElXMLKeyInfoECDataHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_Create(int8_t AOwnResources, TElXMLKeyInfoECDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoECData_Create_1(int8_t AOwnResources, TElCustomCryptoProviderManagerHandle AManager, TElCustomCryptoProviderHandle AProvider, TElXMLKeyInfoECDataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFOECDATA */

#ifdef SB_USE_CLASS_TELXMLISSUERSERIAL
SB_IMPORT uint32_t SB_APIENTRY TElXMLIssuerSerial_Clear(TElXMLIssuerSerialHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIssuerSerial_IsEmpty(TElXMLIssuerSerialHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIssuerSerial_LoadFromXML(TElXMLIssuerSerialHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIssuerSerial_SaveToXML(TElXMLIssuerSerialHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIssuerSerial_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIssuerSerial_get_IssuerRDN(TElXMLIssuerSerialHandle _Handle, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIssuerSerial_get_SerialNumber(TElXMLIssuerSerialHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIssuerSerial_set_SerialNumber(TElXMLIssuerSerialHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIssuerSerial_get_HexSerialNumber(TElXMLIssuerSerialHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIssuerSerial_set_HexSerialNumber(TElXMLIssuerSerialHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIssuerSerial_Create(TElXMLIssuerSerialHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLIssuerSerial_Create_1(const char * pcAName, int32_t szAName, const char * pcANamespaceURI, int32_t szANamespaceURI, const char * pcAPrefix, int32_t szAPrefix, TElXMLIssuerSerialHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLISSUERSERIAL */

#ifdef SB_USE_CLASS_TELXMLKEYINFOX509DATA
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_Update(TElXMLKeyInfoX509DataHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_get_IncludeDataParams(TElXMLKeyInfoX509DataHandle _Handle, TElXMLKeyInfoX509DataParamsRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_set_IncludeDataParams(TElXMLKeyInfoX509DataHandle _Handle, TElXMLKeyInfoX509DataParamsRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_get_IncludeKeyValue(TElXMLKeyInfoX509DataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_set_IncludeKeyValue(TElXMLKeyInfoX509DataHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_get_Certificate(TElXMLKeyInfoX509DataHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_set_Certificate(TElXMLKeyInfoX509DataHandle _Handle, TElX509CertificateHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_get_CertStorage(TElXMLKeyInfoX509DataHandle _Handle, TElCustomCertStorageHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_set_CertStorage(TElXMLKeyInfoX509DataHandle _Handle, TElCustomCertStorageHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_get_HexSerialNumber(TElXMLKeyInfoX509DataHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_set_HexSerialNumber(TElXMLKeyInfoX509DataHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_get_IssuerSerialCount(TElXMLKeyInfoX509DataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_get_SubjectRDNCount(TElXMLKeyInfoX509DataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_get_SKICount(TElXMLKeyInfoX509DataHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_get_IssuerRDNs(TElXMLKeyInfoX509DataHandle _Handle, int32_t Index, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_get_SerialNumbers(TElXMLKeyInfoX509DataHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_get_SubjectRDNs(TElXMLKeyInfoX509DataHandle _Handle, int32_t Index, TElRelativeDistinguishedNameHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_get_SKIs(TElXMLKeyInfoX509DataHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_get_CRLData(TElXMLKeyInfoX509DataHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_get_GeneratedKeyValue(TElXMLKeyInfoX509DataHandle _Handle, TElXMLKeyInfoDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_Create(int8_t OwnResources, TElXMLKeyInfoX509DataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoX509Data_Create_1(int8_t AOwnResources, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, TElXMLKeyInfoX509DataHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFOX509DATA */

#ifdef SB_USE_CLASS_TELXMLKEYINFONODE
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoNode_get_OwnNode(TElXMLKeyInfoNodeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoNode_set_OwnNode(TElXMLKeyInfoNodeHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoNode_get_Value(TElXMLKeyInfoNodeHandle _Handle, TElXMLDOMNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoNode_set_Value(TElXMLKeyInfoNodeHandle _Handle, TElXMLDOMNodeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoNode_Create(TElXMLKeyInfoNodeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoNode_Create_1(int8_t AOwnNode, TElXMLKeyInfoNodeHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFONODE */

#ifdef SB_USE_CLASS_TELXMLKEYINFORETRIEVALMETHOD
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoRetrievalMethod_get_DataType(TElXMLKeyInfoRetrievalMethodHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoRetrievalMethod_set_DataType(TElXMLKeyInfoRetrievalMethodHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoRetrievalMethod_get_URI(TElXMLKeyInfoRetrievalMethodHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoRetrievalMethod_set_URI(TElXMLKeyInfoRetrievalMethodHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoRetrievalMethod_Create(TElXMLKeyInfoRetrievalMethodHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFORETRIEVALMETHOD */

#ifdef SB_USE_CLASS_TELXMLKEYINFOAGREEMENTMETHOD
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAgreementMethod_get_Algorithm(TElXMLKeyInfoAgreementMethodHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAgreementMethod_set_Algorithm(TElXMLKeyInfoAgreementMethodHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAgreementMethod_get_DigestMethod(TElXMLKeyInfoAgreementMethodHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAgreementMethod_set_DigestMethod(TElXMLKeyInfoAgreementMethodHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAgreementMethod_get_KANonce(TElXMLKeyInfoAgreementMethodHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAgreementMethod_set_KANonce(TElXMLKeyInfoAgreementMethodHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAgreementMethod_get_CryptoProviderManager(TElXMLKeyInfoAgreementMethodHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAgreementMethod_set_CryptoProviderManager(TElXMLKeyInfoAgreementMethodHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAgreementMethod_get_OriginatorKeyInfo(TElXMLKeyInfoAgreementMethodHandle _Handle, TElXMLKeyInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAgreementMethod_set_OriginatorKeyInfo(TElXMLKeyInfoAgreementMethodHandle _Handle, TElXMLKeyInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAgreementMethod_get_RecipientKeyInfo(TElXMLKeyInfoAgreementMethodHandle _Handle, TElXMLKeyInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAgreementMethod_set_RecipientKeyInfo(TElXMLKeyInfoAgreementMethodHandle _Handle, TElXMLKeyInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLKeyInfoAgreementMethod_Create(TElXMLKeyInfoAgreementMethodHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLKEYINFOAGREEMENTMETHOD */

#ifdef SB_USE_CLASS_TELXMLPROPERTY
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperty_get_ID(TElXMLPropertyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperty_set_ID(TElXMLPropertyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperty_get_Target(TElXMLPropertyHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperty_set_Target(TElXMLPropertyHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperty_get_PropertyNode(TElXMLPropertyHandle _Handle, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperty_set_PropertyNode(TElXMLPropertyHandle _Handle, TElXMLDOMElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperty_get_OwnPropertyNode(TElXMLPropertyHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperty_set_OwnPropertyNode(TElXMLPropertyHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperty_Create(TElXMLPropertyHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLPROPERTY */

#ifdef SB_USE_CLASS_TELXMLPROPERTIES
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperties_IsEmpty(TElXMLPropertiesHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperties_LoadFromXML(TElXMLPropertiesHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperties_SaveToXML(TElXMLPropertiesHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperties_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperties_Add(TElXMLPropertiesHandle _Handle, TElXMLPropertyHandle AProperty, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperties_Insert(TElXMLPropertiesHandle _Handle, int32_t Index, TElXMLPropertyHandle AProperty);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperties_Delete(TElXMLPropertiesHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperties_Clear(TElXMLPropertiesHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperties_get_Count(TElXMLPropertiesHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperties_get_ID(TElXMLPropertiesHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperties_set_ID(TElXMLPropertiesHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperties_get_Properties(TElXMLPropertiesHandle _Handle, int32_t Index, TElXMLPropertyHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProperties_Create(TElXMLPropertiesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLPROPERTIES */

#ifdef SB_USE_CLASS_TELXMLPROCESSOR
SB_IMPORT uint32_t SB_APIENTRY TElXMLProcessor_get_CryptoProviderManager(TElXMLProcessorHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProcessor_set_CryptoProviderManager(TElXMLProcessorHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLProcessor_Create(TComponentHandle AOwner, TElXMLProcessorHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLPROCESSOR */

#ifdef SB_USE_CLASS_TELXMLFORMATTER
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_AppendElement(TElXMLFormatterHandle _Handle, TElXMLDOMElementHandle Parent, TElXMLDOMElementHandle Child);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_AppendElement_1(TElXMLFormatterHandle _Handle, TElXMLDOMElementHandle Parent, TElXMLCustomElementHandle Child, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_AppendElementWithText(TElXMLFormatterHandle _Handle, TElXMLDOMElementHandle Parent, TElXMLDOMElementHandle Child, const char * pcChildText, int32_t szChildText, TElXMLTextTypeRaw ChildTextType);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_AppendText(TElXMLFormatterHandle _Handle, TElXMLDOMElementHandle Parent, const char * pcText, int32_t szText, TElXMLTextTypeRaw TextType);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_InsertBefore(TElXMLFormatterHandle _Handle, TElXMLDOMElementHandle Parent, TElXMLDOMNodeHandle ChildRef, TElXMLCustomElementHandle Child, TElXMLDOMDocumentHandle Document);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_Clear(TElXMLFormatterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_Push(TElXMLFormatterHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_Pop(TElXMLFormatterHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_get_Level(TElXMLFormatterHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_set_Level(TElXMLFormatterHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_get_Path(TElXMLFormatterHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_set_Path(TElXMLFormatterHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_get_OnFormatElement(TElXMLFormatterHandle _Handle, TSBXMLFormatElementEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_set_OnFormatElement(TElXMLFormatterHandle _Handle, TSBXMLFormatElementEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_get_OnFormatText(TElXMLFormatterHandle _Handle, TSBXMLFormatTextEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_set_OnFormatText(TElXMLFormatterHandle _Handle, TSBXMLFormatTextEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLFormatter_Create(TElXMLFormatterHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLFORMATTER */

#ifdef SB_USE_CLASS_TELXMLDESCRIPTORMAP
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_Add(TElXMLDescriptorMapHandle _Handle, const uint8_t pOID[], int32_t szOID, const char * pcDescriptor, int32_t szDescriptor);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_ClearOID(TElXMLDescriptorMapHandle _Handle, const uint8_t pOID[], int32_t szOID);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_RemoveAt(TElXMLDescriptorMapHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_FindDescriptor(TElXMLDescriptorMapHandle _Handle, const uint8_t pOID[], int32_t szOID, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_FindOID(TElXMLDescriptorMapHandle _Handle, const char * pcDescriptor, int32_t szDescriptor, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_ClearOIDs(TElXMLDescriptorMapHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_ClearOrders(TElXMLDescriptorMapHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_GetOrder(TElXMLDescriptorMapHandle _Handle, const uint8_t pOID[], int32_t szOID, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_SetOrder(TElXMLDescriptorMapHandle _Handle, int32_t Index, const uint8_t pOID[], int32_t szOID);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_get_CompatibilityMode(TElXMLDescriptorMapHandle _Handle, TElXMLRDNCompatibilityModeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_set_CompatibilityMode(TElXMLDescriptorMapHandle _Handle, TElXMLRDNCompatibilityModeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_get_ReverseOrder(TElXMLDescriptorMapHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_set_ReverseOrder(TElXMLDescriptorMapHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_get_Separator(TElXMLDescriptorMapHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_set_Separator(TElXMLDescriptorMapHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_get_Count(TElXMLDescriptorMapHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_get_OID(TElXMLDescriptorMapHandle _Handle, int32_t Index, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_get_Descriptor(TElXMLDescriptorMapHandle _Handle, int32_t Index, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLDescriptorMap_Create(TElXMLDescriptorMapHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLDESCRIPTORMAP */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElXMLKeyInfo_ce_ptr;
extern zend_class_entry *TElXMLAlgorithmParameters_ce_ptr;
extern zend_class_entry *TElXMLReference_ce_ptr;
extern zend_class_entry *TElXMLReferenceList_ce_ptr;
extern zend_class_entry *TElXMLGOSTR3411Parameters_ce_ptr;
extern zend_class_entry *TElXMLRSAPSSParameters_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoItem_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoData_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoHMACData_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoSymmetricData_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoKeyDerivationMethod_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoPBKDF2DerivationMethod_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoConcatKDFDerivationMethod_ce_ptr;
extern zend_class_entry *TElXMLPBKDF2Salt_ce_ptr;
extern zend_class_entry *TElXMLPRFAlgorithmIdentifierType_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoDerivedKeyData_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoAsymmetricData_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoRSAData_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoDSAData_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoDHData_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoGOST2001Data_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoPGPData_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoECData_ce_ptr;
extern zend_class_entry *TElXMLIssuerSerial_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoX509Data_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoNode_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoRetrievalMethod_ce_ptr;
extern zend_class_entry *TElXMLKeyInfoAgreementMethod_ce_ptr;
extern zend_class_entry *TElXMLProperty_ce_ptr;
extern zend_class_entry *TElXMLProperties_ce_ptr;
extern zend_class_entry *TElXMLProcessor_ce_ptr;
extern zend_class_entry *TElXMLFormatter_ce_ptr;
extern zend_class_entry *TElXMLDescriptorMap_ce_ptr;

void SB_CALLBACK TSBXMLFormatElementEventRaw(void * _ObjectData, TObjectHandle Sender, TElXMLDOMElementHandle Element, int32_t Level, const char * pcPath, int32_t szPath, char * pcStartTagWhitespace, int32_t * szStartTagWhitespace, char * pcEndTagWhitespace, int32_t * szEndTagWhitespace);
void SB_CALLBACK TSBXMLFormatTextEventRaw(void * _ObjectData, TObjectHandle Sender, char * pcText, int32_t * szText, TElXMLTextTypeRaw TextType, int32_t Level, const char * pcPath, int32_t szPath);
void Register_TElXMLKeyInfo(TSRMLS_D);
void Register_TElXMLAlgorithmParameters(TSRMLS_D);
void Register_TElXMLReference(TSRMLS_D);
void Register_TElXMLReferenceList(TSRMLS_D);
void Register_TElXMLGOSTR3411Parameters(TSRMLS_D);
void Register_TElXMLRSAPSSParameters(TSRMLS_D);
void Register_TElXMLKeyInfoItem(TSRMLS_D);
void Register_TElXMLKeyInfoData(TSRMLS_D);
void Register_TElXMLKeyInfoHMACData(TSRMLS_D);
void Register_TElXMLKeyInfoSymmetricData(TSRMLS_D);
void Register_TElXMLKeyInfoKeyDerivationMethod(TSRMLS_D);
void Register_TElXMLKeyInfoPBKDF2DerivationMethod(TSRMLS_D);
void Register_TElXMLKeyInfoConcatKDFDerivationMethod(TSRMLS_D);
void Register_TElXMLPBKDF2Salt(TSRMLS_D);
void Register_TElXMLPRFAlgorithmIdentifierType(TSRMLS_D);
void Register_TElXMLKeyInfoDerivedKeyData(TSRMLS_D);
void Register_TElXMLKeyInfoAsymmetricData(TSRMLS_D);
void Register_TElXMLKeyInfoRSAData(TSRMLS_D);
void Register_TElXMLKeyInfoDSAData(TSRMLS_D);
void Register_TElXMLKeyInfoDHData(TSRMLS_D);
void Register_TElXMLKeyInfoGOST2001Data(TSRMLS_D);
void Register_TElXMLKeyInfoPGPData(TSRMLS_D);
void Register_TElXMLKeyInfoECData(TSRMLS_D);
void Register_TElXMLIssuerSerial(TSRMLS_D);
void Register_TElXMLKeyInfoX509Data(TSRMLS_D);
void Register_TElXMLKeyInfoNode(TSRMLS_D);
void Register_TElXMLKeyInfoRetrievalMethod(TSRMLS_D);
void Register_TElXMLKeyInfoAgreementMethod(TSRMLS_D);
void Register_TElXMLProperty(TSRMLS_D);
void Register_TElXMLProperties(TSRMLS_D);
void Register_TElXMLProcessor(TSRMLS_D);
void Register_TElXMLFormatter(TSRMLS_D);
void Register_TElXMLDescriptorMap(TSRMLS_D);
SB_PHP_FUNCTION(SBXMLSec, ToCryptoBinary);
SB_PHP_FUNCTION(SBXMLSec, FindChildElementEnc);
SB_PHP_FUNCTION(SBXMLSec, FindChildElementSig);
SB_PHP_FUNCTION(SBXMLSec, FindChildElementXAdES);
SB_PHP_FUNCTION(SBXMLSec, CalculateDigest);
SB_PHP_FUNCTION(SBXMLSec, CalculateDigestStream);
SB_PHP_FUNCTION(SBXMLSec, DigestMethodToHashAlgorithm);
SB_PHP_FUNCTION(SBXMLSec, DigestMethodToURI);
SB_PHP_FUNCTION(SBXMLSec, URIToDigestMethod);
SB_PHP_FUNCTION(SBXMLSec, GetDigestMethodFromSignatureMethod);
SB_PHP_FUNCTION(SBXMLSec, HashAlgorithmToDigestMethod);
SB_PHP_FUNCTION(SBXMLSec, FormatRDN);
SB_PHP_FUNCTION(SBXMLSec, ExtractRDN);
SB_PHP_FUNCTION(SBXMLSec, RDNDescriptorMap);
void Register_SBXMLSec_Constants(int module_number TSRMLS_DC);
void Register_SBXMLSec_Enum_Flags(TSRMLS_D);
void Register_SBXMLSec_Aliases(TSRMLS_D);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SB_USE_GLOBAL_PROCS_XMLSEC
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_ToCryptoBinary(const uint8_t pBuf[], int32_t szBuf, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_ToCryptoBinary_1(const uint8_t pBuf[], int32_t szBuf, int8_t KeepTrailingZero, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_FindChildElementEnc(const TElXMLDOMElementHandle Element, const char * pcName, int32_t szName, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_FindChildElementSig(const TElXMLDOMElementHandle Element, const char * pcName, int32_t szName, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_FindChildElementXAdES(const TElXMLDOMElementHandle Element, const char * pcName, int32_t szName, const char * pcNamespaceURI, int32_t szNamespaceURI, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_CalculateDigest(void * Buf, int32_t Size, TElXMLDigestMethodRaw aMethod, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_CalculateDigest_1(void * Buf, int32_t Size, TElXMLDigestMethodRaw aMethod, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_CalculateDigest_2(void * Buf, int32_t Size, TElXMLDigestMethodRaw aMethod, TElXMLAlgorithmParametersHandle Parameters, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_CalculateDigestStream(TStreamHandle Stream, int64_t Count, TElXMLDigestMethodRaw aMethod, TElCustomCryptoProviderManagerHandle Manager, TElCustomCryptoProviderHandle Prov, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_DigestMethodToHashAlgorithm(TElXMLDigestMethodRaw DigestMethod, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_DigestMethodToURI(TElXMLDigestMethodRaw DigestMethod, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_URIToDigestMethod(const char * pcDigestMethod, int32_t szDigestMethod, TElXMLDigestMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_GetDigestMethodFromSignatureMethod(TElXMLSignatureMethodRaw SignatureMethod, TElXMLDigestMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_HashAlgorithmToDigestMethod(int32_t HashAlgorithm, TElXMLDigestMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_FormatRDN(const TElRelativeDistinguishedNameHandle RDN, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_ExtractRDN(const char * pcData, int32_t szData, TElRelativeDistinguishedNameHandle RDN);
SB_IMPORT uint32_t SB_APIENTRY SBXMLSec_RDNDescriptorMap(TElXMLDescriptorMapHandle * OutResult);
#endif /* SB_USE_GLOBAL_PROCS_XMLSEC */

#ifdef __cplusplus
};	/* extern "C" */
#endif

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLSEC */

