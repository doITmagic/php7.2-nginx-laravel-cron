#ifndef __INC_SBXMLSIG
#define __INC_SBXMLSIG

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

#include "sbdefs.h"
#include "sbphpcore.h"
#include "sbsystem.h"
#include "sbtypes.h"
#include "sbutils.h"
#include "sbstrutils.h"
#include "sbconstants.h"
#include "sbhashfunction.h"
#include "sbpublickeycrypto.h"
#include "sbcryptoprov.h"
#include "sbx509.h"
#include "sbdc.h"
#include "sbdcdef.h"
#include "sbdcsec.h"
#include "sbdcpkiconstants.h"
#include "sbxmlades.h"
#include "sbxmladesintf.h"
#include "sbxmldefs.h"
#include "sbxmlcore.h"
#include "sbxmlsec.h"
#include "sbxmltransform.h"
#include "sbxmlutils.h"

#pragma pack(push, 1)

#ifdef __cplusplus
namespace SecureBlackbox {
#endif

#ifdef __cplusplus
extern "C" {
#endif
typedef TElClassHandle TElXMLSignatureHandle;

typedef TElXMLSignatureHandle ElXMLSignatureHandle;

typedef TElClassHandle TElXMLSigProcessorHandle;

typedef TElXMLSigProcessorHandle ElXMLSigProcessorHandle;

typedef TElClassHandle TElXMLSignerHandle;

typedef TElXMLSignerHandle ElXMLSignerHandle;

typedef TElClassHandle TElXMLVerifierHandle;

typedef TElXMLVerifierHandle ElXMLVerifierHandle;

typedef TElClassHandle TElXMLSignatureMethodTypeHandle;

typedef TElXMLSignatureMethodTypeHandle ElXMLSignatureMethodTypeHandle;

typedef TElClassHandle TElXMLSignedInfoHandle;

typedef TElXMLSignedInfoHandle ElXMLSignedInfoHandle;

typedef TElClassHandle TElXMLManifestHandle;

typedef TElXMLManifestHandle ElXMLManifestHandle;

typedef TElClassHandle TElXMLSignaturePropertiesHandle;

typedef TElXMLSignaturePropertiesHandle ElXMLSignaturePropertiesHandle;

typedef TElClassHandle TElXMLObjectHandle;

typedef TElXMLObjectHandle ElXMLObjectHandle;

typedef TElClassHandle TElXMLObjectListHandle;

typedef TElXMLObjectListHandle ElXMLObjectListHandle;

typedef TElClassHandle TElXMLSignatureValueHandle;

typedef TElXMLSignatureValueHandle ElXMLSignatureValueHandle;

typedef void (SB_CALLBACK *TSBXMLRemoteSignEvent)(void * _ObjectData, TObjectHandle Sender, const uint8_t pHash[], int32_t szHash, uint8_t pSignedHash[], int32_t * szSignedHash);

#ifdef SB_USE_CLASS_TELXMLSIGNATURE
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_Clear(TElXMLSignatureHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_IsEmpty(TElXMLSignatureHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_LoadFromXML(TElXMLSignatureHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_SaveToXML(TElXMLSignatureHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_get_ID(TElXMLSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_set_ID(TElXMLSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_get_SignedInfo(TElXMLSignatureHandle _Handle, TElXMLSignedInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_set_SignedInfo(TElXMLSignatureHandle _Handle, TElXMLSignedInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_get_SignatureValue(TElXMLSignatureHandle _Handle, TElXMLSignatureValueHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_set_SignatureValue(TElXMLSignatureHandle _Handle, TElXMLSignatureValueHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_get_KeyInfo(TElXMLSignatureHandle _Handle, TElXMLKeyInfoHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_set_KeyInfo(TElXMLSignatureHandle _Handle, TElXMLKeyInfoHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_get_Objects(TElXMLSignatureHandle _Handle, TElXMLObjectListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_get_SignaturePrefix(TElXMLSignatureHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_set_SignaturePrefix(TElXMLSignatureHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_get_SignatureCompliance(TElXMLSignatureHandle _Handle, TElXMLSignatureComplianceRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_set_SignatureCompliance(TElXMLSignatureHandle _Handle, TElXMLSignatureComplianceRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_get_CryptoProviderManager(TElXMLSignatureHandle _Handle, TElCustomCryptoProviderManagerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_set_CryptoProviderManager(TElXMLSignatureHandle _Handle, TElCustomCryptoProviderManagerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_get_QualifyingProperties(TElXMLSignatureHandle _Handle, TElXMLQualifyingPropertiesHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_set_QualifyingProperties(TElXMLSignatureHandle _Handle, TElXMLQualifyingPropertiesHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_get_QualifyingPropertiesReferences(TElXMLSignatureHandle _Handle, TElXMLQualifyingPropertiesReferenceListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_set_QualifyingPropertiesReferences(TElXMLSignatureHandle _Handle, TElXMLQualifyingPropertiesReferenceListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignature_Create(TElXMLSignatureHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNATURE */

#ifdef SB_USE_CLASS_TELXMLSIGPROCESSOR
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigProcessor_ClearSignatureMethodParameters(TElXMLSigProcessorHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigProcessor_get_KeyData(TElXMLSigProcessorHandle _Handle, TElXMLKeyInfoDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigProcessor_set_KeyData(TElXMLSigProcessorHandle _Handle, TElXMLKeyInfoDataHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigProcessor_get_Signature(TElXMLSigProcessorHandle _Handle, TElXMLSignatureHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigProcessor_get_SignatureMethodParameters(TElXMLSigProcessorHandle _Handle, TElXMLAlgorithmParametersHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigProcessor_set_SignatureMethodParameters(TElXMLSigProcessorHandle _Handle, TElXMLAlgorithmParametersHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigProcessor_Create(TComponentHandle AOwner, TElXMLSigProcessorHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGPROCESSOR */

#ifdef SB_USE_CLASS_TELXMLSIGNER
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_CompleteAsyncSign(TElXMLSignerHandle _Handle, TElXMLDOMDocumentHandle Document, TElDCAsyncStateHandle State);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_InitiateAsyncSign(TElXMLSignerHandle _Handle, TElXMLDOMNodeHandle * Node, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_InitiateAsyncSign_1(TElXMLSignerHandle _Handle, TElDCParametersHandle Pars, TElXMLDOMNodeHandle * Node, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_InitiateAsyncSign_2(TElXMLSignerHandle _Handle, TElXMLDOMNodeHandle * Node, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_InitiateAsyncSign_3(TElXMLSignerHandle _Handle, TElDCParametersHandle Pars, TElXMLDOMNodeHandle * Node, const uint8_t pAdditionalData[], int32_t szAdditionalData, TElDCAsyncStateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_GenerateSignature(TElXMLSignerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_GenerateSignatureAsync(TElXMLSignerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_Sign(TElXMLSignerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_Save(TElXMLSignerHandle _Handle, TElXMLDOMNodeHandle * Node);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_SaveDetached(TElXMLSignerHandle _Handle, TElXMLDOMDocumentHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_SaveEnveloped(TElXMLSignerHandle _Handle, TElXMLDOMElementHandle ParentElement, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_SaveEnveloping(TElXMLSignerHandle _Handle, TElXMLDOMNodeHandle EnvelopingNode, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_UpdateReferencesDigest(TElXMLSignerHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_References(TElXMLSignerHandle _Handle, TElXMLReferenceListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_References(TElXMLSignerHandle _Handle, TElXMLReferenceListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_RemoteSigningParams(TElXMLSignerHandle _Handle, TElRemoteSigningParamsHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_XAdESProcessor(TElXMLSignerHandle _Handle, TElXAdESSignerHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_XAdESProcessor(TElXMLSignerHandle _Handle, TElXAdESSignerHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_CanonicalizationMethod(TElXMLSignerHandle _Handle, TElXMLCanonicalizationMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_CanonicalizationMethod(TElXMLSignerHandle _Handle, TElXMLCanonicalizationMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_InclusiveNamespacesPrefixList(TElXMLSignerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_InclusiveNamespacesPrefixList(TElXMLSignerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_SignatureType(TElXMLSignerHandle _Handle, TElXMLSignatureTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_SignatureType(TElXMLSignerHandle _Handle, TElXMLSignatureTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_SignatureCompliance(TElXMLSignerHandle _Handle, TElXMLSignatureComplianceRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_SignatureCompliance(TElXMLSignerHandle _Handle, TElXMLSignatureComplianceRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_SignatureMethodType(TElXMLSignerHandle _Handle, TElXMLSigMethodTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_SignatureMethodType(TElXMLSignerHandle _Handle, TElXMLSigMethodTypeRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_MACMethod(TElXMLSignerHandle _Handle, TElXMLMACMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_MACMethod(TElXMLSignerHandle _Handle, TElXMLMACMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_SignatureMethod(TElXMLSignerHandle _Handle, TElXMLSignatureMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_SignatureMethod(TElXMLSignerHandle _Handle, TElXMLSignatureMethodRaw Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_IncludeKey(TElXMLSignerHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_IncludeKey(TElXMLSignerHandle _Handle, int8_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_KeyName(TElXMLSignerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_KeyName(TElXMLSignerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_EnvelopingObjectID(TElXMLSignerHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_EnvelopingObjectID(TElXMLSignerHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_OnFormatElement(TElXMLSignerHandle _Handle, TSBXMLFormatElementEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_OnFormatElement(TElXMLSignerHandle _Handle, TSBXMLFormatElementEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_OnFormatText(TElXMLSignerHandle _Handle, TSBXMLFormatTextEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_OnFormatText(TElXMLSignerHandle _Handle, TSBXMLFormatTextEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_get_OnRemoteSign(TElXMLSignerHandle _Handle, TSBXMLRemoteSignEvent * pMethodOutResult, void * * pDataOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_set_OnRemoteSign(TElXMLSignerHandle _Handle, TSBXMLRemoteSignEvent pMethodValue, void * pDataValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSigner_Create(TComponentHandle AOwner, TElXMLSignerHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNER */

#ifdef SB_USE_CLASS_TELXMLVERIFIER
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_Load(TElXMLVerifierHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_ValidateSignature(TElXMLVerifierHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_ValidateReference(TElXMLVerifierHandle _Handle, TElXMLReferenceHandle Reference, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_ValidateReferences(TElXMLVerifierHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_RemoveSignature(TElXMLVerifierHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_get_HMACKey(TElXMLVerifierHandle _Handle, TElXMLKeyInfoHMACDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_set_HMACKey(TElXMLVerifierHandle _Handle, TElXMLKeyInfoHMACDataHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_get_References(TElXMLVerifierHandle _Handle, TElXMLReferenceListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_get_CanonicalizationMethod(TElXMLVerifierHandle _Handle, TElXMLCanonicalizationMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_get_InclusiveNamespacesPrefixList(TElXMLVerifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_get_SignatureType(TElXMLVerifierHandle _Handle, TElXMLSignatureTypesRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_get_SignatureCompliance(TElXMLVerifierHandle _Handle, TElXMLSignatureComplianceRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_get_SignatureMethodType(TElXMLVerifierHandle _Handle, TElXMLSigMethodTypeRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_get_MACMethod(TElXMLVerifierHandle _Handle, TElXMLMACMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_get_SignatureMethod(TElXMLVerifierHandle _Handle, TElXMLSignatureMethodRaw * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_get_KeyDataNeeded(TElXMLVerifierHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_get_KeyName(TElXMLVerifierHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_get_SignerCertificate(TElXMLVerifierHandle _Handle, TElX509CertificateHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_get_SignerKeyData(TElXMLVerifierHandle _Handle, TElXMLKeyInfoDataHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_get_XAdESProcessor(TElXMLVerifierHandle _Handle, TElXAdESVerifierHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_set_XAdESProcessor(TElXMLVerifierHandle _Handle, TElXAdESVerifierHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLVerifier_Create(TComponentHandle AOwner, TElXMLVerifierHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLVERIFIER */

#ifdef SB_USE_CLASS_TELXMLSIGNATUREMETHODTYPE
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureMethodType_Clear(TElXMLSignatureMethodTypeHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureMethodType_IsEmpty(TElXMLSignatureMethodTypeHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureMethodType_LoadFromXML(TElXMLSignatureMethodTypeHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureMethodType_SaveToXML(TElXMLSignatureMethodTypeHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureMethodType_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureMethodType_get_Algorithm(TElXMLSignatureMethodTypeHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureMethodType_set_Algorithm(TElXMLSignatureMethodTypeHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureMethodType_get_HMACOutputLength(TElXMLSignatureMethodTypeHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureMethodType_set_HMACOutputLength(TElXMLSignatureMethodTypeHandle _Handle, int32_t Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureMethodType_get_Parameters(TElXMLSignatureMethodTypeHandle _Handle, TElXMLAlgorithmParametersHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureMethodType_set_Parameters(TElXMLSignatureMethodTypeHandle _Handle, TElXMLAlgorithmParametersHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureMethodType_Create(TElXMLSignatureMethodTypeHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNATUREMETHODTYPE */

#ifdef SB_USE_CLASS_TELXMLSIGNEDINFO
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_Clear(TElXMLSignedInfoHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_IsEmpty(TElXMLSignedInfoHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_LoadFromXML(TElXMLSignedInfoHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_SaveToXML(TElXMLSignedInfoHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_get_ID(TElXMLSignedInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_set_ID(TElXMLSignedInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_get_CanonicalizationMethod(TElXMLSignedInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_set_CanonicalizationMethod(TElXMLSignedInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_get_ExclusiveCanonicalizationPrefix(TElXMLSignedInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_set_ExclusiveCanonicalizationPrefix(TElXMLSignedInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_get_InclusiveNamespacesPrefixList(TElXMLSignedInfoHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_set_InclusiveNamespacesPrefixList(TElXMLSignedInfoHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_get_SignatureMethod(TElXMLSignedInfoHandle _Handle, TElXMLSignatureMethodTypeHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_set_SignatureMethod(TElXMLSignedInfoHandle _Handle, TElXMLSignatureMethodTypeHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_get_References(TElXMLSignedInfoHandle _Handle, TElXMLReferenceListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_set_References(TElXMLSignedInfoHandle _Handle, TElXMLReferenceListHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_get_SigPropRef(TElXMLSignedInfoHandle _Handle, TElXMLReferenceHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignedInfo_Create(TElXMLSignedInfoHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNEDINFO */

#ifdef SB_USE_CLASS_TELXMLMANIFEST
SB_IMPORT uint32_t SB_APIENTRY TElXMLManifest_Clear(TElXMLManifestHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLManifest_IsEmpty(TElXMLManifestHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLManifest_LoadFromXML(TElXMLManifestHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLManifest_SaveToXML(TElXMLManifestHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLManifest_get_XMLElement(TElXMLManifestHandle _Handle, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLManifest_set_XMLElement(TElXMLManifestHandle _Handle, TElXMLDOMElementHandle Value);
SB_IMPORT uint32_t SB_APIENTRY TElXMLManifest_get_ID(TElXMLManifestHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLManifest_set_ID(TElXMLManifestHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLManifest_Create(TElXMLManifestHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLMANIFEST */

#ifdef SB_USE_CLASS_TELXMLSIGNATUREPROPERTIES
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureProperties_Create(TElXMLSignaturePropertiesHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNATUREPROPERTIES */

#ifdef SB_USE_CLASS_TELXMLOBJECT
SB_IMPORT uint32_t SB_APIENTRY TElXMLObject_Clear(TElXMLObjectHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObject_IsEmpty(TElXMLObjectHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObject_LoadFromXML(TElXMLObjectHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObject_SaveToXML(TElXMLObjectHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObject_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObject_get_ID(TElXMLObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObject_set_ID(TElXMLObjectHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObject_get_MimeType(TElXMLObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObject_set_MimeType(TElXMLObjectHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObject_get_Encoding(TElXMLObjectHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObject_set_Encoding(TElXMLObjectHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObject_get_DataList(TElXMLObjectHandle _Handle, TListHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObject_Create(TElXMLObjectHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLOBJECT */

#ifdef SB_USE_CLASS_TELXMLOBJECTLIST
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectList_Add(TElXMLObjectListHandle _Handle, TElXMLObjectHandle AObject, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectList_Clear(TElXMLObjectListHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectList_Delete(TElXMLObjectListHandle _Handle, int32_t Index);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectList_Insert(TElXMLObjectListHandle _Handle, int32_t Index, TElXMLObjectHandle AObject);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectList_get_Count(TElXMLObjectListHandle _Handle, int32_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectList_get_Objects(TElXMLObjectListHandle _Handle, int32_t Index, TElXMLObjectHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLObjectList_Create(TElXMLObjectListHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLOBJECTLIST */

#ifdef SB_USE_CLASS_TELXMLSIGNATUREVALUE
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureValue_Clear(TElXMLSignatureValueHandle _Handle);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureValue_IsEmpty(TElXMLSignatureValueHandle _Handle, int8_t * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureValue_LoadFromXML(TElXMLSignatureValueHandle _Handle, TElXMLDOMElementHandle Element);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureValue_SaveToXML(TElXMLSignatureValueHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLCustomFormatterHandle Formatter, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureValue_SaveToXML_1(TElXMLCustomElementHandle _Handle, TElXMLDOMDocumentHandle Document, TElXMLDOMElementHandle * OutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureValue_get_ID(TElXMLSignatureValueHandle _Handle, char * pcOutResult, int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureValue_set_ID(TElXMLSignatureValueHandle _Handle, const char * pcValue, int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureValue_get_Value(TElXMLSignatureValueHandle _Handle, uint8_t pOutResult[], int32_t * szOutResult);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureValue_set_Value(TElXMLSignatureValueHandle _Handle, const uint8_t pValue[], int32_t szValue);
SB_IMPORT uint32_t SB_APIENTRY TElXMLSignatureValue_Create(TElXMLSignatureValueHandle * OutResult);
#endif /* SB_USE_CLASS_TELXMLSIGNATUREVALUE */

#ifdef __cplusplus
};	/* extern "C" */
#endif

extern zend_class_entry *TElXMLSignature_ce_ptr;
extern zend_class_entry *TElXMLSigProcessor_ce_ptr;
extern zend_class_entry *TElXMLSigner_ce_ptr;
extern zend_class_entry *TElXMLVerifier_ce_ptr;
extern zend_class_entry *TElXMLSignatureMethodType_ce_ptr;
extern zend_class_entry *TElXMLSignedInfo_ce_ptr;
extern zend_class_entry *TElXMLManifest_ce_ptr;
extern zend_class_entry *TElXMLSignatureProperties_ce_ptr;
extern zend_class_entry *TElXMLObject_ce_ptr;
extern zend_class_entry *TElXMLObjectList_ce_ptr;
extern zend_class_entry *TElXMLSignatureValue_ce_ptr;

void SB_CALLBACK TSBXMLRemoteSignEventRaw(void * _ObjectData, TObjectHandle Sender, const uint8_t pHash[], int32_t szHash, uint8_t pSignedHash[], int32_t * szSignedHash);
void Register_TElXMLSignature(TSRMLS_D);
void Register_TElXMLSigProcessor(TSRMLS_D);
void Register_TElXMLSigner(TSRMLS_D);
void Register_TElXMLVerifier(TSRMLS_D);
void Register_TElXMLSignatureMethodType(TSRMLS_D);
void Register_TElXMLSignedInfo(TSRMLS_D);
void Register_TElXMLManifest(TSRMLS_D);
void Register_TElXMLSignatureProperties(TSRMLS_D);
void Register_TElXMLObject(TSRMLS_D);
void Register_TElXMLObjectList(TSRMLS_D);
void Register_TElXMLSignatureValue(TSRMLS_D);
void Register_SBXMLSig_Aliases(TSRMLS_D);

#ifdef __cplusplus
};	/* namespace SecureBlackbox */
#endif

#pragma pack(pop)

#endif  /* __INC_SBXMLSIG */

